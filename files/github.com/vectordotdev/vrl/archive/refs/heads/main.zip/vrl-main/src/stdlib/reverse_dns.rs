use crate::compiler::prelude::*;

#[cfg(not(target_arch = "wasm32"))]
mod non_wasm {
    use crate::compiler::prelude::*;
    use crate::value::Value;
    use dns_lookup::lookup_addr;
    use std::net::IpAddr;

    fn reverse_dns(value: &Value) -> Resolved {
        let ip: IpAddr = value
            .try_bytes_utf8_lossy()?
            .parse()
            .map_err(|err| format!("unable to parse IP address: {err}"))?;
        let host = lookup_addr(&ip).map_err(|err| format!("unable to perform a lookup : {err}"))?;

        Ok(host.into())
    }

    #[derive(Debug, Clone)]
    pub(super) struct ReverseDnsFn {
        pub(super) value: Box<dyn Expression>,
    }

    impl FunctionExpression for ReverseDnsFn {
        fn resolve(&self, ctx: &mut Context) -> Resolved {
            let value = self.value.resolve(ctx)?;
            reverse_dns(&value)
        }

        fn type_def(&self, _: &state::TypeState) -> TypeDef {
            TypeDef::bytes().fallible()
        }
    }
}

#[allow(clippy::wildcard_imports)]
#[cfg(not(target_arch = "wasm32"))]
use non_wasm::*;

#[derive(Clone, Copy, Debug)]
pub struct ReverseDns;

impl Function for ReverseDns {
    fn identifier(&self) -> &'static str {
        "reverse_dns"
    }

    fn usage(&self) -> &'static str {
        "Performs a reverse DNS lookup on the provided IP address to retrieve the associated hostname."
    }

    fn notices(&self) -> &'static [&'static str] {
        &[super::util::NETWORK_CALL_NOTICE]
    }

    fn category(&self) -> &'static str {
        Category::System.as_ref()
    }

    fn return_kind(&self) -> u16 {
        kind::BYTES
    }

    fn parameters(&self) -> &'static [Parameter] {
        const PARAMETERS: &[Parameter] = &[Parameter::required(
            "value",
            kind::BYTES,
            "The IP address (IPv4 or IPv6) to perform the reverse DNS lookup on.",
        )];
        PARAMETERS
    }

    fn examples(&self) -> &'static [Example] {
        &[example! {
            title: "Example",
            source: r#"reverse_dns!("127.0.0.1")"#,
            result: Ok("localhost"),
        }]
    }

    #[cfg(not(target_arch = "wasm32"))]
    fn compile(
        &self,
        _state: &state::TypeState,
        _ctx: &mut FunctionCompileContext,
        arguments: ArgumentList,
    ) -> Compiled {
        let value = arguments.required("value");

        Ok(ReverseDnsFn { value }.as_expr())
    }

    #[cfg(target_arch = "wasm32")]
    fn compile(
        &self,
        _state: &state::TypeState,
        ctx: &mut FunctionCompileContext,
        _arguments: ArgumentList,
    ) -> Compiled {
        Ok(super::WasmUnsupportedFunction::new(ctx.span(), TypeDef::bytes().fallible()).as_expr())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::value;

    test_function![
        reverse_dns => ReverseDns;

        invalid_ip {
            args: func_args![value: value!("999.999.999.999")],
            want: Err("unable to parse IP address: invalid IP address syntax"),
            tdef: TypeDef::bytes().fallible(),
        }

        invalid_type {
            args: func_args![value: value!(1)],
            want: Err("expected string, got integer"),
            tdef: TypeDef::bytes().fallible(),
        }
    ];

    #[cfg(feature = "test")]
    fn execute_reverse_dns(ip_fn: &ReverseDnsFn) -> crate::value::Value {
        let tz = TimeZone::default();
        let mut object = value!({});
        let mut runtime_state = state::RuntimeState::default();
        let mut ctx = Context::new(&mut object, &mut runtime_state, &tz);
        ip_fn.resolve(&mut ctx).unwrap()
    }

    #[cfg(feature = "test")]
    #[test]
    fn google_ipv4() {
        let result = execute_reverse_dns(&ReverseDnsFn {
            value: expr!("8.8.8.8"),
        });
        assert_eq!(result, value!("dns.google"));
    }

    #[cfg(feature = "test")]
    #[test]
    fn google_ipv6() {
        let result = execute_reverse_dns(&ReverseDnsFn {
            value: expr!("2001:4860:4860::8844"),
        });
        assert_eq!(result, value!("dns.google"));
    }
}
