use super::util;
use crate::compiler::prelude::*;
use crate::stdlib::util::RegexWithCaptureInfo;
use regex::Regex;

static DEFAULT_NUMERIC_GROUPS: Value = Value::Boolean(false);

const PARAMETERS: &[Parameter] = &[
    Parameter::required("value", kind::BYTES, "The string to search."),
    Parameter::required(
        "pattern",
        kind::REGEX,
        "The regular expression pattern to search against.",
    ),
    Parameter::optional(
        "numeric_groups",
        kind::BOOLEAN,
        "If true, the index of each group in the regular expression is also captured. Index `0`
contains the whole match.",
    )
    .default(&DEFAULT_NUMERIC_GROUPS),
];

fn parse_regex(
    value: &Value,
    pattern: &Regex,
    capture_info: &[(KeyString, usize)],
    numeric_groups: bool,
) -> Resolved {
    let value = value.try_bytes_utf8_lossy()?;
    let parsed = pattern
        .captures(&value)
        .map(|capture| util::capture_regex_to_map(&capture, capture_info, numeric_groups))
        .ok_or("could not find any pattern matches")?;
    Ok(parsed.into())
}

#[derive(Clone, Copy, Debug)]
pub struct ParseRegex;

impl Function for ParseRegex {
    fn identifier(&self) -> &'static str {
        "parse_regex"
    }

    fn usage(&self) -> &'static str {
        indoc! {"
            Parses the `value` using the provided [Regex](https://en.wikipedia.org/wiki/Regular_expression) `pattern`.

            This function differs from the `parse_regex_all` function in that it returns only the first match.
        "}
    }

    fn category(&self) -> &'static str {
        Category::Parse.as_ref()
    }

    fn internal_failure_reasons(&self) -> &'static [&'static str] {
        &["`value` fails to parse using the provided `pattern`."]
    }

    fn return_kind(&self) -> u16 {
        kind::OBJECT
    }

    fn return_rules(&self) -> &'static [&'static str] {
        &[
            "Matches return all capture groups corresponding to the leftmost matches in the text.",
            "Raises an error if no match is found.",
        ]
    }

    fn notices(&self) -> &'static [&'static str] {
        &[
            indoc! {"
                VRL aims to provide purpose-specific [parsing functions](/docs/reference/vrl/functions/#parse-functions)
                for common log formats. Before reaching for the `parse_regex` function, see if a VRL
                [`parse_*` function](/docs/reference/vrl/functions/#parse-functions) already exists
                for your format. If not, we recommend
                [opening an issue](https://github.com/vectordotdev/vector/issues/new?labels=type%3A+new+feature)
                to request support for the desired format.
            "},
            indoc! {"
                All values are returned as strings. We recommend manually coercing values to desired
                types as you see fit.
            "},
            util::DYNAMIC_REGEX_NOTICE,
        ]
    }

    fn parameters(&self) -> &'static [Parameter] {
        PARAMETERS
    }

    fn compile(
        &self,
        state: &state::TypeState,
        _ctx: &mut FunctionCompileContext,
        arguments: ArgumentList,
    ) -> Compiled {
        let value = arguments.required("value");
        let pattern = match arguments.required_regex("pattern", state) {
            ConstOrExpr::Const(r) => ConstOrExpr::Const(RegexWithCaptureInfo::new(r)),
            ConstOrExpr::Expr(e) => ConstOrExpr::Expr(e),
        };
        let numeric_groups = arguments.optional("numeric_groups");

        Ok(ParseRegexFn {
            value,
            pattern,
            numeric_groups,
        }
        .as_expr())
    }

    fn examples(&self) -> &'static [Example] {
        &[
            example! {
                title: "Parse using Regex (with capture groups)",
                source: r#"parse_regex!("first group and second group.", r'(?P<number>.*?) group')"#,
                result: Ok(r#"{"number": "first"}"#),
            },
            example! {
                title: "Parse using Regex (without capture groups)",
                source: r#"parse_regex!("first group and second group.", r'(\w+) group', numeric_groups: true)"#,
                result: Ok(indoc! { r#"{
                "0": "first group",
                "1": "first"
            }"# }),
            },
            example! {
                title: "Parse using Regex with simple match",
                source: r#"parse_regex!("8.7.6.5 - zorp", r'^(?P<host>[\w\.]+) - (?P<user>[\w]+)')"#,
                result: Ok(indoc! { r#"{
                "host": "8.7.6.5",
                "user": "zorp"
            }"# }),
            },
            example! {
                title: "Parse using Regex with all numeric groups",
                source: r#"parse_regex!("8.7.6.5 - zorp", r'^(?P<host>[\w\.]+) - (?P<user>[\w]+)', numeric_groups: true)"#,
                result: Ok(indoc! { r#"{
                "0": "8.7.6.5 - zorp",
                "1": "8.7.6.5",
                "2": "zorp",
                "host": "8.7.6.5",
                "user": "zorp"
            }"# }),
            },
            example! {
                title: "Parse using Regex with variables",
                source: indoc! {r#"
                    variable = r'^(?P<host>[\w\.]+) - (?P<user>[\w]+)';
                    parse_regex!("8.7.6.5 - zorp", variable)
                "#},
                result: Ok(indoc! { r#"{
                "host": "8.7.6.5",
                "user": "zorp"
            }"# }),
            },
        ]
    }
}

#[derive(Debug, Clone)]
pub(crate) struct ParseRegexFn {
    value: Box<dyn Expression>,
    pattern: ConstOrExpr<RegexWithCaptureInfo>,
    numeric_groups: Option<Box<dyn Expression>>,
}

impl FunctionExpression for ParseRegexFn {
    fn resolve(&self, ctx: &mut Context) -> Resolved {
        let value = self.value.resolve(ctx)?;
        let numeric_groups = self
            .numeric_groups
            .map_resolve_with_default(ctx, || DEFAULT_NUMERIC_GROUPS.clone())?
            .try_boolean()?;

        match &self.pattern {
            ConstOrExpr::Const(pattern) => parse_regex(
                &value,
                &pattern.regex,
                &pattern.capture_info,
                numeric_groups,
            ),
            ConstOrExpr::Expr(expr) => {
                let resolved = expr.resolve(ctx)?;
                let pattern = resolved
                    .as_regex()
                    .ok_or_else(|| ExpressionError::from("failed to resolve regex"))?;
                let dynamic_capture_info = util::build_capture_info(pattern);
                parse_regex(&value, pattern, &dynamic_capture_info, numeric_groups)
            }
        }
    }

    fn type_def(&self, _: &state::TypeState) -> TypeDef {
        match &self.pattern {
            ConstOrExpr::Const(pattern) => {
                TypeDef::object(util::regex_kind(&pattern.regex)).fallible()
            }
            ConstOrExpr::Expr(_) => {
                TypeDef::object(Collection::from_unknown(Kind::bytes() | Kind::null())).fallible()
            }
        }
    }
}

#[cfg(test)]
#[allow(clippy::trivial_regex)]
mod tests {
    use super::*;
    use crate::{btreemap, value};

    test_function![
        find => ParseRegex;

        numeric_groups {
            args: func_args! [
                value: "5.86.210.12 - zieme4647 5667 [19/06/2019:17:20:49 -0400] \"GET /embrace/supply-chains/dynamic/vertical\" 201 20574",
                pattern: Regex::new(r#"^(?P<host>[\w\.]+) - (?P<user>[\w]+) (?P<bytes_in>[\d]+) \[(?P<timestamp>.*)\] "(?P<method>[\w]+) (?P<path>.*)" (?P<status>[\d]+) (?P<bytes_out>[\d]+)$"#)
                    .unwrap(),
                numeric_groups: true,
            ],
            want: Ok(value!({"bytes_in": "5667",
                             "host": "5.86.210.12",
                             "user": "zieme4647",
                             "timestamp": "19/06/2019:17:20:49 -0400",
                             "method": "GET",
                             "path": "/embrace/supply-chains/dynamic/vertical",
                             "status": "201",
                             "bytes_out": "20574",
                             "0": "5.86.210.12 - zieme4647 5667 [19/06/2019:17:20:49 -0400] \"GET /embrace/supply-chains/dynamic/vertical\" 201 20574",
                             "1": "5.86.210.12",
                             "2": "zieme4647",
                             "3": "5667",
                             "4": "19/06/2019:17:20:49 -0400",
                             "5": "GET",
                             "6": "/embrace/supply-chains/dynamic/vertical",
                             "7": "201",
                             "8": "20574",
            })),
            tdef: TypeDef::object(btreemap! {
                    Field::from("bytes_in") => Kind::bytes(),
                    Field::from("host") => Kind::bytes(),
                    Field::from("user") => Kind::bytes(),
                    Field::from("timestamp") => Kind::bytes(),
                    Field::from("method") => Kind::bytes(),
                    Field::from("path") => Kind::bytes(),
                    Field::from("status") => Kind::bytes(),
                    Field::from("bytes_out") => Kind::bytes(),
                    Field::from("0") => Kind::bytes() | Kind::null(),
                    Field::from("1") => Kind::bytes() | Kind::null(),
                    Field::from("2") => Kind::bytes() | Kind::null(),
                    Field::from("3") => Kind::bytes() | Kind::null(),
                    Field::from("4") => Kind::bytes() | Kind::null(),
                    Field::from("5") => Kind::bytes() | Kind::null(),
                    Field::from("6") => Kind::bytes() | Kind::null(),
                    Field::from("7") => Kind::bytes() | Kind::null(),
                    Field::from("8") => Kind::bytes() | Kind::null(),
                }).fallible(),
        }

        single_match {
            args: func_args! [
                value: "first group and second group",
                pattern: Regex::new("(?P<number>.*?) group").unwrap()
            ],
            want: Ok(value!({"number": "first"})),
            tdef: TypeDef::object(btreemap! {
                        Field::from("number") => Kind::bytes(),
                        Field::from("0") => Kind::bytes() | Kind::null(),
                        Field::from("1") => Kind::bytes() | Kind::null(),
                }).fallible(),
        }

        no_match {
            args: func_args! [
                value: "I don't match",
                pattern: Regex::new(r#"^(?P<host>[\w\.]+) - (?P<user>[\w]+) (?P<bytes_in>[\d]+) \[(?P<timestamp>.*)\] "(?P<method>[\w]+) (?P<path>.*)" (?P<status>[\d]+) (?P<bytes_out>[\d]+)$"#)
                            .unwrap()
            ],
            want: Err("could not find any pattern matches"),
            tdef: TypeDef::object(btreemap! {
                    Field::from("host") => Kind::bytes(),
                    Field::from("user") => Kind::bytes(),
                    Field::from("bytes_in") => Kind::bytes(),
                    Field::from("timestamp") => Kind::bytes(),
                    Field::from("method") => Kind::bytes(),
                    Field::from("path") => Kind::bytes(),
                    Field::from("status") => Kind::bytes(),
                    Field::from("bytes_out") => Kind::bytes(),
                    Field::from("0") => Kind::bytes() | Kind::null(),
                    Field::from("1") => Kind::bytes() | Kind::null(),
                    Field::from("2") => Kind::bytes() | Kind::null(),
                    Field::from("3") => Kind::bytes() | Kind::null(),
                    Field::from("4") => Kind::bytes() | Kind::null(),
                    Field::from("5") => Kind::bytes() | Kind::null(),
                    Field::from("6") => Kind::bytes() | Kind::null(),
                    Field::from("7") => Kind::bytes() | Kind::null(),
                    Field::from("8") => Kind::bytes() | Kind::null(),
                }).fallible(),
        }
    ];
}
