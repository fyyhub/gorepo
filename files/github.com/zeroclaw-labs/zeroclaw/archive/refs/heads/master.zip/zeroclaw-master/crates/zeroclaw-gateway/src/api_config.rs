//! Per-property CRUD endpoints for `/api/config/*`.

use axum::{
    Json,
    extract::{Query, State},
    http::{HeaderMap, HeaderValue, StatusCode, header},
    response::{IntoResponse, Response},
};
use serde::{Deserialize, Serialize};
use zeroclaw_config::api_error::{ConfigApiCode, ConfigApiError};
use zeroclaw_config::field_visibility;
use zeroclaw_config::sections::section_for_path;
use zeroclaw_config::traits::MaskSecrets;

use super::AppState;
use super::ConfigWriteGuard;
use std::sync::Arc;

// ── Request / response shapes ───────────────────────────────────────

/// `?path=...` query parameter shared by GET / DELETE / OPTIONS-with-path.
#[derive(Debug, Deserialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct PropQuery {
    pub path: String,
}

/// `?prefix=...` query parameter for list.
#[derive(Debug, Deserialize, Default)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct ListQuery {
    #[serde(default)]
    pub prefix: Option<String>,
}

/// PUT body. Value is `serde_json::Value` so typed values (booleans, arrays,
/// numbers) round-trip correctly without going through the CLI's
/// comma-delimited string parser.
#[derive(Debug, Deserialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct PropPutBody {
    pub path: String,
    pub value: serde_json::Value,
    #[serde(default)]
    pub comment: Option<String>,
}

/// One JSON Patch operation. Supports `add`, `remove`, `replace`, `test`, and
/// ZeroClaw's `comment` extension. Every operation requires `path`; `add`,
/// `replace`, and `test` require `value`, while `comment` requires `comment`.
#[derive(Debug, Deserialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct PatchOp {
    pub op: String,
    pub path: String,
    #[serde(default)]
    pub value: Option<serde_json::Value>,
    #[serde(default)]
    pub comment: Option<String>,
}

/// Single result entry in a successful PATCH response, one per applied op.
#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct PatchOpResult {
    pub op: String,
    pub path: String,
    /// The resulting value at the target path after the op applied.
    /// `None` for secret paths (per the secrets-handling boundary), and for
    /// `remove` ops where the field was reset to its default.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub value: Option<serde_json::Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub populated: Option<bool>,
    /// Comment that was applied alongside this op (if any). Echoed so
    /// clients can confirm the comment was actually written to disk
    /// without having to round-trip through `GET` and parse the TOML.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub comment: Option<String>,
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct PatchResponse {
    pub saved: bool,
    pub results: Vec<PatchOpResult>,
    /// Non-fatal validation warnings against the saved configuration.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub warnings: Vec<zeroclaw_config::validation_warnings::ValidationWarning>,
}

/// GET /api/config — compatibility whole-config read for older bundled
/// dashboard pages. New clients should prefer the per-property API, but
/// returning a masked snapshot here avoids a hard 405 when an older page is
/// served by a newer gateway.
pub async fn handle_config_get(State(state): State<AppState>) -> Response {
    let mut cfg = state.config.read().clone();
    cfg.mask_secrets();
    Json(cfg).into_response()
}

fn parse_patch_ops(value: serde_json::Value) -> Result<Vec<PatchOp>, ConfigApiError> {
    let ops = value.as_array().ok_or_else(|| {
        ConfigApiError::new(
            ConfigApiCode::ValueTypeMismatch,
            "JSON Patch body must be a JSON array of operations",
        )
    })?;

    let mut parsed = Vec::with_capacity(ops.len());
    for (idx, op) in ops.iter().enumerate() {
        let object = op.as_object().ok_or_else(|| {
            ConfigApiError::new(
                ConfigApiCode::ValueTypeMismatch,
                format!("JSON Patch op[{idx}] must be an object"),
            )
            .with_op_index(idx)
        })?;
        let op_name = object.get("op").and_then(|v| v.as_str()).ok_or_else(|| {
            ConfigApiError::new(
                ConfigApiCode::ValueTypeMismatch,
                format!("JSON Patch op[{idx}] requires string `op` field"),
            )
            .with_op_index(idx)
        })?;
        let path = object.get("path").and_then(|v| v.as_str()).ok_or_else(|| {
            ConfigApiError::new(
                ConfigApiCode::ValueTypeMismatch,
                format!("JSON Patch op[{idx}] requires string `path` field"),
            )
            .with_op_index(idx)
        })?;
        let comment = match object.get("comment") {
            Some(value) => Some(
                value
                    .as_str()
                    .ok_or_else(|| {
                        ConfigApiError::new(
                            ConfigApiCode::ValueTypeMismatch,
                            format!("JSON Patch op[{idx}] `comment` field must be a string"),
                        )
                        .with_path(json_pointer_to_dotted(path))
                        .with_op_index(idx)
                    })?
                    .to_string(),
            ),
            None => None,
        };

        parsed.push(PatchOp {
            op: op_name.to_string(),
            path: path.to_string(),
            value: object.get("value").cloned(),
            comment,
        });
    }

    Ok(parsed)
}

/// Response for a non-secret GET / PUT / DELETE.
#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct PropResponse {
    pub path: String,
    pub value: serde_json::Value,
    /// Non-fatal validation warnings against the current config state.
    /// On GET this surfaces warnings present in the loaded config; on PUT
    /// this surfaces warnings against the post-save state. Empty when
    /// nothing is flagged.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub warnings: Vec<zeroclaw_config::validation_warnings::ValidationWarning>,
}

/// Response for a secret GET / PUT / DELETE — never carries the value or its
/// length. `populated: true` means the secret has a non-empty value on disk;
/// `populated: false` means the field is unset or empty.
#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct SecretResponse {
    pub path: String,
    pub populated: bool,
}

/// Single entry in the list response for configuration properties.
#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct ListEntry {
    pub path: String,
    pub category: String,
    /// Stable kind tag — `string`, `bool`, `integer`, `float`, `enum`,
    /// `string-array`. Lowercase-kebab so it can be used directly as a CSS
    /// class or React key.
    pub kind: &'static str,
    /// Rust type signature, e.g. `Option<String>`, `Vec<String>`, `u64`.
    /// Render in tooltips / hover state for the technically-curious.
    pub type_hint: &'static str,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub value: Option<serde_json::Value>,
    pub populated: bool,
    pub is_secret: bool,
    /// Whether this field was populated by a `ZEROCLAW_*` env-var override
    /// at load time. The dashboard renders the 💉 badge and a persistent
    /// warning *"Edits here won't take effect — overridden by ZEROCLAW_..."*
    /// when this is `true`.
    #[serde(default, skip_serializing_if = "is_false")]
    pub is_env_overridden: bool,
    /// Variants for `enum`-kind fields — non-empty means the frontend should
    /// render a `<select>` with these options. Empty for non-enum fields.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub enum_variants: Vec<String>,
    /// Onboard section name derived from the path's first segment via
    /// `Section::from_path`. `None` for paths that aren't part of any wizard
    /// section. The dashboard groups list entries by this for per-section
    /// rendering — same source the CLI wizard uses, no schema attribute.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub section: Option<&'static str>,
    /// Tab grouping label from the field's `#[tab(...)]` annotation
    /// (`ConfigTab::label`). Absent for `ConfigTab::None`. Surfaces group
    /// list entries into a tab bar by this; the agent edit form depends on
    /// it to split General / Providers / Channels / etc.
    #[serde(skip_serializing_if = "str::is_empty")]
    pub tab: &'static str,
    /// Surface hint from `#[multiline]`: render a multi-line text area
    /// (e.g. a PEM key body) instead of a single-line input.
    #[serde(default, skip_serializing_if = "is_false")]
    pub multiline: bool,
}

/// Stable wire-form name for a `PropKind` variant. Matches the lower-kebab
/// convention the rest of the API uses for stable string IDs.
fn prop_kind_wire(kind: zeroclaw_config::traits::PropKind) -> &'static str {
    use zeroclaw_config::traits::PropKind;
    match kind {
        PropKind::String => "string",
        PropKind::Bool => "bool",
        PropKind::Integer => "integer",
        PropKind::Float => "float",
        PropKind::Enum => "enum",
        PropKind::AliasRef => "alias-ref",
        PropKind::StringArray => "string-array",
        PropKind::ObjectArray => "object-array",
        PropKind::Object => "object",
        PropKind::SecretMap => "secret-map",
    }
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct ListResponse {
    pub entries: Vec<ListEntry>,
    /// Properties where in-memory and on-disk values disagree. Empty when the
    /// daemon's view matches the file. Each entry follows the `DriftEntry`
    /// shape (secrets carry only `{path, secret: true, drifted: true}`).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub drifted: Vec<DriftEntry>,
}

/// One drift entry surfaced when in-memory Config diverges from the on-disk file.
#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct DriftEntry {
    pub path: String,
    /// `true` for secret fields where values cannot be exposed.
    #[serde(default, skip_serializing_if = "is_false")]
    pub secret: bool,
    /// Always `true` when surfaced. Present so secret entries unambiguously
    /// communicate the drift signal in shape `{path, secret: true, drifted: true}`.
    pub drifted: bool,
    /// In-memory value (the daemon's view). Absent for secrets.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub in_memory_value: Option<serde_json::Value>,
    /// On-disk value (what the file contains right now). Absent for secrets.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_disk_value: Option<serde_json::Value>,
}

fn is_false(b: &bool) -> bool {
    !*b
}

// ── Error helpers ───────────────────────────────────────────────────

/// Convert a `ConfigApiError` into an axum `Response` with the correct status.
fn error_response(err: ConfigApiError) -> Response {
    let status =
        StatusCode::from_u16(err.code.http_status()).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
    (status, axum::Json(err)).into_response()
}

/// Wrap an `anyhow::Error` from `Config::set_prop` / `get_prop` into a
/// `ConfigApiError`. Path-not-found errors get the specific code; everything
/// else falls through to ValidationFailed.
fn map_prop_error(err: anyhow::Error, path: &str) -> ConfigApiError {
    let msg = err.to_string();
    if msg.starts_with("Unknown property") {
        ConfigApiError::path_not_found(path)
    } else {
        ConfigApiError::from_validation(err).with_path(path)
    }
}

// ── Helpers ─────────────────────────────────────────────────────────

// Typed-value coercion lives in `zeroclaw_config::typed_value` — both the
// gateway PATCH/PUT handlers and the CLI `config patch` flow consume it.
// Single source of truth for the "JSON in, set_prop string out, validated
// against the declared PropKind" contract.
use zeroclaw_config::typed_value::coerce_for_set_prop as json_to_setprop_string;

use crate::principal_gate::{
    ConfigWriteAuthorization, ConfigWriteSet, RequestPrincipal, authorize_config_write,
    authorize_whole_config_write,
};
use zeroclaw_api::grants::Verb;

/// Look up the prop_field metadata for a path. Used by the per-prop GET / PUT
/// handlers to decide whether the field is a secret.
fn lookup_prop_field(
    config: &zeroclaw_config::schema::Config,
    path: &str,
) -> Option<zeroclaw_config::traits::PropFieldInfo> {
    config
        .prop_fields()
        .into_iter()
        .find(|info| info.name == path)
        .or_else(|| {
            zeroclaw_config::schema::Config::prop_is_secret(path).then(|| {
                zeroclaw_config::traits::PropFieldInfo {
                    name: path.to_string(),
                    category: "Secrets",
                    display_value: zeroclaw_config::traits::UNSET_DISPLAY.to_string(),
                    type_hint: "String",
                    kind: zeroclaw_config::traits::PropKind::String,
                    is_secret: true,
                    enum_variants: None,
                    description: "",
                    derived_from_secret: false,
                    credential_class: Some(
                        zeroclaw_config::traits::CredentialSurfaceClass::EncryptedSecret,
                    ),
                    tab: zeroclaw_config::traits::ConfigTab::None,
                    alias_source: None,
                    multiline: false,
                    setup: None,
                    application: Default::default(),
                }
            })
        })
}

fn scoped_validate(
    working: &zeroclaw_config::schema::Config,
) -> Result<Vec<zeroclaw_config::validation_warnings::ValidationWarning>, ConfigApiError> {
    if let Err(e) = working.validate() {
        let api_err = ConfigApiError::from_validation(e);
        let err_path = api_err.path.as_deref().unwrap_or("");
        let touches_dirty = !err_path.is_empty()
            && working.dirty_paths.iter().any(|d| {
                err_path == d.as_str()
                    || err_path.starts_with(&format!("{d}."))
                    || d.starts_with(&format!("{err_path}."))
            });
        if touches_dirty || err_path.is_empty() {
            return Err(api_err);
        }
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                .with_attrs(::serde_json::json!({"path": err_path})),
            &format!(
                "validate() failed on a path outside this PATCH's dirty set; saving anyway and \
             surfacing as a warning: {}",
                api_err.message
            )
        );
        return Ok(vec![
            zeroclaw_config::validation_warnings::ValidationWarning::new(
                "pre_existing_validation_error",
                api_err.message,
                err_path.to_string(),
            ),
        ]);
    }
    Ok(Vec::new())
}

/// Map a config-commit admission/allocate failure (generation closing,
/// exhausted revision space) to the HTTP error surface. Refused before
/// any disk state changed, so the message says exactly that.
fn config_commit_admission_error(
    error: zeroclaw_runtime::live_config_authority::ConfigCommitError,
) -> ConfigApiError {
    ConfigApiError::new(
        ConfigApiCode::ReloadFailed,
        format!("config commit refused without any change: {error}"),
    )
}

/// Map a publication refusal (non-successor revision) to the HTTP error
/// surface. The published pair is unchanged when this is returned.
fn config_commit_publish_error(
    error: zeroclaw_runtime::live_config_authority::ConfigCommitError,
) -> ConfigApiError {
    ConfigApiError::new(
        ConfigApiCode::ReloadFailed,
        format!("config publication failed: {error}"),
    )
}
fn channel_generation_projection(config: &zeroclaw_config::schema::Config) -> serde_json::Value {
    let agents: std::collections::BTreeMap<&str, serde_json::Value> = config
        .agents
        .iter()
        .map(|(alias, agent)| {
            (
                alias.as_str(),
                serde_json::json!({
                    "enabled": agent.enabled,
                    "channels": &agent.channels,
                }),
            )
        })
        .collect();
    serde_json::json!({
        "channels": &config.channels,
        "peer_groups": &config.peer_groups,
        "agents": agents,
    })
}

fn schedule_channel_generation_reload(
    pending_reload: Arc<std::sync::atomic::AtomicBool>,
    controls: zeroclaw_runtime::daemon::GatewayReloadControls,
) {
    zeroclaw_spawn::spawn!(async move {
        tokio::time::sleep(std::time::Duration::from_millis(200)).await;
        pending_reload.store(false, std::sync::atomic::Ordering::Relaxed);
        let _ = controls.shutdown_tx.send(true);
        let _ = controls.send(true);
    });
}

pub(crate) struct RetainedConfigWrite {
    _guard: ConfigWriteGuard,
    _agent_reservations: Vec<zeroclaw_runtime::live_config_authority::AgentAdmissionReservation>,
}

/// Save `new_config` to disk, publish its accepted policy, then install it live.
///
/// The retained job owns the admitted commit through save, publication,
/// channel retirement and annotation writes even if the request is dropped.
#[allow(clippy::result_large_err)]
pub(crate) async fn persist_and_swap(
    state: &AppState,
    authorization: ConfigWriteAuthorization,
    new_config: zeroclaw_config::schema::Config,
    guard: ConfigWriteGuard,
) -> Result<RetainedConfigWrite, Response> {
    persist_and_swap_retaining(
        state,
        authorization,
        new_config,
        guard,
        Vec::new(),
        Vec::new(),
    )
    .await
}

#[allow(clippy::result_large_err)]
async fn persist_and_swap_retaining(
    state: &AppState,
    authorization: ConfigWriteAuthorization,
    new_config: zeroclaw_config::schema::Config,
    guard: ConfigWriteGuard,
    agent_reservations: Vec<zeroclaw_runtime::live_config_authority::AgentAdmissionReservation>,
    annotations: Vec<(String, String)>,
) -> Result<RetainedConfigWrite, Response> {
    let config_path = new_config.config_path.clone();
    let pending_reload = Arc::clone(&state.pending_reload);
    let controls = state.reload_tx.clone();
    let task =
        zeroclaw_runtime::live_config_authority::spawn_agent_lifecycle_job(Box::pin(async move {
            let prepared = persist_and_swap_prepared(
                &guard,
                Arc::clone(&pending_reload),
                controls,
                new_config,
                authorization,
            )
            .await?;
            finish_prepared_channel_generation(prepared, pending_reload).await;
            if let Err(e) =
                zeroclaw_config::comment_writer::apply_comments(&config_path, &annotations).await
            {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                        .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                        .with_attrs(::serde_json::json!({ "error": format!("{e}") })),
                    "failed to apply config comments to config.toml"
                );
            }
            Ok(RetainedConfigWrite {
                _guard: guard,
                _agent_reservations: agent_reservations,
            })
        }));
    task.await.map_err(|e| {
        error_response(ConfigApiError::new(
            ConfigApiCode::ReloadFailed,
            format!("config completion task failed: {e}"),
        ))
    })?
}

#[cfg(test)]
mod test_pre_save_pause_gate {
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicBool, Ordering};
    use std::sync::{Arc, Mutex};

    use tokio::sync::Notify;

    struct Gate {
        target: PathBuf,
        reached: Notify,
        release: Notify,
        claimed: AtomicBool,
        released: AtomicBool,
    }

    static GATES: Mutex<Vec<Arc<Gate>>> = Mutex::new(Vec::new());

    fn disarm(gate: &Arc<Gate>) {
        gate.released.store(true, Ordering::Release);
        gate.release.notify_waiters();
        GATES
            .lock()
            .unwrap()
            .retain(|registered| !Arc::ptr_eq(registered, gate));
    }

    pub(super) struct GateHandle {
        gate: Arc<Gate>,
    }

    impl GateHandle {
        pub(super) async fn wait_paused(&self) {
            self.gate.reached.notified().await;
        }

        pub(super) fn release(&self) {
            disarm(&self.gate);
        }
    }

    impl Drop for GateHandle {
        fn drop(&mut self) {
            disarm(&self.gate);
        }
    }

    pub(super) fn arm(target: PathBuf) -> GateHandle {
        let gate = Arc::new(Gate {
            target,
            reached: Notify::new(),
            release: Notify::new(),
            claimed: AtomicBool::new(false),
            released: AtomicBool::new(false),
        });
        GATES.lock().unwrap().push(Arc::clone(&gate));
        GateHandle { gate }
    }

    pub(super) async fn pause(config_path: &Path) {
        let gate = GATES
            .lock()
            .unwrap()
            .iter()
            .find(|gate| gate.target == config_path)
            .cloned();
        if let Some(gate) = gate {
            if gate
                .claimed
                .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
                .is_err()
            {
                return;
            }
            gate.reached.notify_one();
            let released = gate.release.notified();
            tokio::pin!(released);
            released.as_mut().enable();
            if !gate.released.load(Ordering::Acquire) {
                released.await;
            }
        }
    }
}

/// Save-and-swap half of the config persistence sequence, split from the
/// channel-generation drain so the retained destructive transaction can commit
/// the alias generation synchronously after the live swap and before the
/// drain. Returns the prepared (not yet begun) channel-generation drain when
/// the mutation changed the channel-generation projection.
///
/// On a pre-commit save error the disk state is rolled back and the live
/// snapshot is left untouched. The caller must hold the config write lock.
#[allow(clippy::result_large_err)]
async fn persist_and_swap_prepared(
    commit: &ConfigWriteGuard,
    pending_reload: Arc<std::sync::atomic::AtomicBool>,
    reload_controls: Option<zeroclaw_runtime::daemon::GatewayReloadControls>,
    mut new_config: zeroclaw_config::schema::Config,
    authorization: ConfigWriteAuthorization,
) -> Result<
    Option<(
        zeroclaw_runtime::daemon::PreparedChannelGenerationDrain,
        zeroclaw_runtime::daemon::GatewayReloadControls,
    )>,
    Response,
> {
    authorization
        .covers_all(new_config.dirty_paths.iter().map(String::as_str))
        .map_err(IntoResponse::into_response)?;
    if let Err(e) = zeroclaw_runtime::rpc::auth::validate_accepted_auth_config(&new_config) {
        return Err(error_response(ConfigApiError::new(
            ConfigApiCode::ValidationFailed,
            format!("authorization policy would not compile: {e}"),
        )));
    }
    let channel_generation_changed = {
        let current = commit.current_config();
        channel_generation_projection(&current) != channel_generation_projection(&new_config)
    };
    let prepared_channel_generation = if channel_generation_changed {
        match reload_controls {
            Some(controls) => Some((
                controls
                    .prepare_channel_generation()
                    .ok_or_else(|| {
                        error_response(ConfigApiError::new(
                            ConfigApiCode::ReloadFailed,
                            "channel generation controls are unavailable; refusing a live channel mutation",
                        ))
                    })?,
                controls,
            )),
            None => None,
        }
    } else {
        None
    };
    let revision = commit
        .next_revision()
        .map_err(|e| error_response(config_commit_admission_error(e)))?;
    let config_path = new_config.config_path.clone();

    // Snapshot pre-write disk state (used for revert on save failure). Only
    // NotFound means the file was absent. Any other read failure must stop
    // before the save because treating an unreadable file as absent would
    // let the rollback path delete an existing canonical config.
    let snapshot = read_config_snapshot(&config_path)
        .await
        .map_err(error_response)?;

    #[cfg(test)]
    test_pre_save_pause_gate::pause(&config_path).await;

    if let Err(e) = new_config.save_dirty().await {
        if let Some(prev) = snapshot {
            let _ = tokio::fs::write(&config_path, prev).await;
        }
        // When the path was absent, the atomic writer either leaves it absent
        // on failure or reports a visible rename as success. Do not remove a
        // path here: an external writer may have created it after admission.
        return Err(error_response(ConfigApiError::new(
            ConfigApiCode::ReloadFailed,
            format!("save failed: {e}"),
        )));
    }

    authorization.publish_persisted(&new_config);
    commit
        .publish(revision, new_config)
        .map_err(|e| error_response(config_commit_publish_error(e)))?;
    pending_reload.store(true, std::sync::atomic::Ordering::Relaxed);
    Ok(prepared_channel_generation)
}

/// Drain the prepared channel generation and schedule the daemon reload.
/// Called by the retained commit task after its publication (and, for the
/// destructive cascades, after their alias-generation commit), while still
/// inside the commit's serialization, preserving the historical boundary
/// between config commits and channel retirement.
async fn finish_prepared_channel_generation(
    prepared: Option<(
        zeroclaw_runtime::daemon::PreparedChannelGenerationDrain,
        zeroclaw_runtime::daemon::GatewayReloadControls,
    )>,
    pending_reload: Arc<std::sync::atomic::AtomicBool>,
) {
    if let Some((prepared, controls)) = prepared {
        prepared.begin().wait().await;
        schedule_channel_generation_reload(pending_reload, controls);
    }
}

async fn read_config_snapshot(
    config_path: &std::path::Path,
) -> Result<Option<Vec<u8>>, ConfigApiError> {
    match tokio::fs::read(config_path).await {
        Ok(contents) => Ok(Some(contents)),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(error) => Err(ConfigApiError::new(
            ConfigApiCode::ReloadFailed,
            format!("failed to snapshot existing config before save: {error}"),
        )),
    }
}

/// Reject masked or empty values from writes to secret-bearing properties.
/// Dashboard surfaces may send the masked display sentinel when no real edit
/// was made; accepting it would replace the live secret with that sentinel.
fn reject_masked_secret_value(
    path: &str,
    is_sensitive: bool,
    value: &str,
) -> Result<(), ConfigApiError> {
    if is_sensitive
        && (value == zeroclaw_config::traits::MASKED_SECRET || value == "****" || value.is_empty())
    {
        return Err(ConfigApiError::new(
            ConfigApiCode::ValidationFailed,
            format!("Refusing to overwrite secret `{path}` with a masked or empty value"),
        )
        .with_path(path));
    }
    Ok(())
}

/// `POST /api/channels/bind` request body. The GUI/HTTP equivalent of
/// `zeroclaw channel bind-<type> <identity> --alias <alias>`: authorize an
/// operator-named identity on one channel alias without the in-chat
/// `/bind <code>` round trip.
#[derive(Debug, Deserialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct ChannelBindBody {
    pub channel_type: String,
    pub alias: String,
    pub identity: String,
}

/// POST /api/channels/bind — add an inbound identity to a pairing channel's
/// allowlist. Shares the exact bind core the CLI uses
/// (`bind_channel_identity_into`), writes ONLY to
/// `peer_groups.<type>_<alias>.external_peers`, and is gated by the same
/// bearer auth as every other config write. Publishes the shared config,
/// drains the supervised channel generation and schedules daemon reload
/// without requiring an in-chat `/bind` message.
pub async fn handle_api_channel_bind(
    State(state): State<AppState>,
    principal: RequestPrincipal,
    Json(body): Json<ChannelBindBody>,
) -> Response {
    // Serialize the whole read-mutate-swap section: acquired before the
    // read-for-modify below and held through the swap at the end of this
    // handler, so a concurrent config writer can't land between this
    // handler's read and its `save()`/swap.
    let _cfg_guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let channel_type = body.channel_type.trim();
    let alias = body.alias.trim();

    // Closed-set gate: only telegram/wechat/line have an operator-bind surface.
    if zeroclaw_channels::orchestrator::channel_identity_normalizer(channel_type).is_none() {
        return error_response(ConfigApiError::new(
            ConfigApiCode::ValidationFailed,
            format!(
                "channel type `{channel_type}` does not support identity binding \
                 (supported: telegram, wechat, line)"
            ),
        ));
    }

    let mut working = _cfg_guard.current_config();

    // Standalone compatibility handles can predate a completed policy save.
    // Refresh under the shared writer so an on-disk deny cannot be missed or
    // overwritten by binding from an older snapshot.
    match zeroclaw_config::schema::persisted_peer_groups(&working.config_path).await {
        Ok(Some(persisted)) => working.peer_groups = persisted,
        Ok(None) => {}
        Err(e) => {
            return error_response(ConfigApiError::new(
                ConfigApiCode::ReloadFailed,
                format!("could not read the persisted peer policy: {e}"),
            ));
        }
    }

    // Reject a phantom alias loudly (404) rather than minting a peer group the
    // runtime never reads.
    if !zeroclaw_channels::orchestrator::channel_alias_configured(&working, channel_type, alias) {
        return error_response(ConfigApiError::new(
            ConfigApiCode::PathNotFound,
            format!("channel `{channel_type}.{alias}` is not configured"),
        ));
    }

    let target = match zeroclaw_channels::orchestrator::bind_channel_identity_into(
        &mut working,
        channel_type,
        alias,
        &body.identity,
    ) {
        Ok(target) => target,
        Err(e) => {
            return error_response(ConfigApiError::new(
                ConfigApiCode::ValidationFailed,
                e.to_string(),
            ));
        }
    };

    let channel = format!("{channel_type}.{alias}");

    // The writer picks its target by the group's `channel` field, so the
    // destination may be any key, not the conventional `<type>_<alias>`.
    // Reporting the conventional name would name a group that need not exist.
    let Some(group) = target else {
        // Name the group that actually carries the grant, including a bare
        // type-wide one. Falling back to the conventional `<type>_<alias>` key
        // named a block that need not exist and sent operators to edit it.
        let source = zeroclaw_channels::orchestrator::channel_authorizing_group_key(
            &working,
            channel_type,
            alias,
            &body.identity,
        )
        .or_else(|| {
            zeroclaw_channels::orchestrator::channel_peer_group_key(&working, channel_type, alias)
        });
        return Json(serde_json::json!({
            "saved": false,
            "already_bound": true,
            "group": source,
            "channel": channel,
        }))
        .into_response();
    };

    // Persist only the refreshed peer policy while retaining the writer and
    // generation completion even if the HTTP caller disconnects.
    // Incremental: only `peer_groups` is applied onto the current on-disk
    // document, so the rest of this snapshot, which is still whatever this
    // handle last saw, cannot drop another writer's keys. A full `save` here
    // wrote the whole stale snapshot back. A direct peer-group mutation is not
    // dirty-tracked, so the explicit `mark_dirty` is what makes `save_dirty`
    // write it at all, and it materializes a brand-new table the same way.
    // Then swap the shared in-memory config so the channel authorizes live.
    // The bind writes exactly one path; a peer group that did not exist
    // before is the creation it is. Authorized before the save below.
    let before = state.config.read().clone();
    let external_peers = format!("peer_groups.{group}.external_peers");
    let authorization = match authorize_config_write(
        &principal,
        ConfigWriteSet::by_effect(&before, &working, [external_peers.as_str()]),
        &_cfg_guard,
    ) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };

    working.mark_dirty(&external_peers);
    if let Err(error) = persist_and_swap(&state, authorization, working, _cfg_guard).await {
        return error;
    }

    Json(serde_json::json!({
        "saved": true,
        "already_bound": false,
        "group": group,
        "channel": channel,
    }))
    .into_response()
}

/// Fields the gateway owns end-to-end (mints, rotates, persists itself).
/// They're skipped by [`compute_drift`] so the dashboard doesn't surface a
/// banner the operator can't act on. Add new entries here when a similar
/// gateway-managed field lands (e.g. webhook secret rotation).
fn is_gateway_managed_field(name: &str) -> bool {
    // Match the prop-field name actually emitted by the `Configurable` derive,
    // which preserves the Rust field's snake_case (`paired_tokens`), not kebab.
    matches!(name, "gateway.paired_tokens")
}

pub async fn compute_drift(in_memory: &zeroclaw_config::schema::Config) -> Vec<DriftEntry> {
    try_compute_drift(in_memory).await.unwrap_or_default()
}

pub(crate) async fn try_compute_drift(
    in_memory: &zeroclaw_config::schema::Config,
) -> Result<Vec<DriftEntry>, ConfigApiError> {
    let path = &in_memory.config_path;
    let raw = match tokio::fs::read_to_string(path).await {
        Ok(s) => s,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => {
            return Err(ConfigApiError::new(
                ConfigApiCode::ConfigChangedExternally,
                format!("cannot inspect the canonical config before comparing changes: {error}"),
            ));
        }
    };

    // Re-parse the on-disk form into a fresh Config for value-by-value comparison.
    let mut on_disk = toml::from_str::<zeroclaw_config::schema::Config>(&raw).map_err(|_| {
        ConfigApiError::new(
            ConfigApiCode::ConfigChangedExternally,
            "cannot compare changes because the canonical config is malformed",
        )
    })?;
    on_disk.config_path = path.clone();

    let in_memory_props: std::collections::HashMap<String, zeroclaw_config::traits::PropFieldInfo> =
        in_memory
            .prop_fields()
            .into_iter()
            .map(|p| (p.name.clone(), p))
            .collect();
    let on_disk_props: std::collections::HashMap<String, zeroclaw_config::traits::PropFieldInfo> =
        on_disk
            .prop_fields()
            .into_iter()
            .map(|p| (p.name.clone(), p))
            .collect();

    let mut drift: Vec<DriftEntry> = Vec::new();
    let mut all_names: std::collections::BTreeSet<&str> = std::collections::BTreeSet::new();
    all_names.extend(in_memory_props.keys().map(String::as_str));
    all_names.extend(on_disk_props.keys().map(String::as_str));
    for name in all_names {
        if is_gateway_managed_field(name) {
            continue;
        }
        // Env overrides (`ZEROCLAW_<path>`) apply in memory but never persist to
        // disk, so a disk comparison always reports drift the operator can't fix.
        if in_memory.prop_is_env_overridden(name) {
            continue;
        }
        let mem = in_memory_props.get(name);
        let disk = on_disk_props.get(name);
        let mem_display = mem
            .map(|p| p.display_value.as_str())
            .unwrap_or(zeroclaw_config::traits::UNSET_DISPLAY);
        let disk_display = disk
            .map(|p| p.display_value.as_str())
            .unwrap_or(zeroclaw_config::traits::UNSET_DISPLAY);
        if mem_display == disk_display {
            continue;
        }
        let is_sensitive = mem
            .or(disk)
            .map(|p| p.is_secret || p.derived_from_secret)
            .unwrap_or(false);
        if is_sensitive {
            use sha2::{Digest, Sha256};
            let mem_hash = Sha256::digest(mem_display.as_bytes());
            let disk_hash = Sha256::digest(disk_display.as_bytes());
            if mem_hash == disk_hash {
                continue;
            }
            drift.push(DriftEntry {
                path: name.to_string(),
                secret: true,
                drifted: true,
                in_memory_value: None,
                on_disk_value: None,
            });
        } else {
            drift.push(DriftEntry {
                path: name.to_string(),
                secret: false,
                drifted: true,
                in_memory_value: Some(serde_json::Value::String(mem_display.to_string())),
                on_disk_value: Some(serde_json::Value::String(disk_display.to_string())),
            });
        }
    }

    // Stable order so callers can diff snapshots.
    drift.sort_by(|a, b| a.path.cmp(&b.path));
    Ok(drift)
}

// ── Handlers ────────────────────────────────────────────────────────

pub async fn handle_prop_get(
    State(state): State<AppState>,
    Query(q): Query<PropQuery>,
) -> Response {
    let config = state.config.read().clone();
    let info = match lookup_prop_field(&config, &q.path) {
        Some(info) => info,
        None => return error_response(ConfigApiError::path_not_found(&q.path)),
    };

    if info.is_secret || info.derived_from_secret {
        let populated = info.display_value != zeroclaw_config::traits::UNSET_DISPLAY;
        return axum::Json(SecretResponse {
            path: q.path,
            populated,
        })
        .into_response();
    }

    match config.get_prop(&q.path) {
        Ok(value_str) => {
            // get_prop returns the display string; surface it as JSON.
            // For typed-value fidelity, callers should hit OPTIONS to learn
            // the type and parse client-side. Future iterations can route
            // typed values through serde directly.
            let warnings = config.collect_warnings();
            axum::Json(PropResponse {
                path: q.path,
                value: serde_json::Value::String(value_str),
                warnings,
            })
            .into_response()
        }
        Err(e) => error_response(map_prop_error(e, &q.path)),
    }
}

pub async fn handle_prop_put(
    State(state): State<AppState>,
    principal: RequestPrincipal,
    axum::Json(body): axum::Json<PropPutBody>,
) -> Response {
    let _cfg_guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let mut new_config = _cfg_guard.current_config();
    if new_config.ensure_map_key_for_path(&body.path) {
        // Refused to vivify the reserved `default` agent: surface the same
        // reserved error the explicit create surfaces do, not a generic 404.
        return error_response(
            ConfigApiError::new(
                ConfigApiCode::ValidationFailed,
                "alias `default` is reserved and cannot be created",
            )
            .with_path(&body.path),
        );
    }
    let info = match lookup_prop_field(&new_config, &body.path) {
        Some(info) => info,
        None => return error_response(ConfigApiError::path_not_found(&body.path)),
    };

    let value_str = match json_to_setprop_string(&body.value, Some(info.kind)) {
        Ok(s) => s,
        Err(e) => return error_response(e.with_path(&body.path)),
    };

    let is_sensitive = info.is_secret || info.derived_from_secret;
    if let Err(e) = reject_masked_secret_value(&body.path, is_sensitive, &value_str) {
        return error_response(e);
    }

    if let Err(e) = new_config.set_prop_persistent(&body.path, &value_str) {
        return error_response(map_prop_error(e, &body.path));
    }

    let scoped_validation_warnings = match scoped_validate(&new_config) {
        Ok(ws) => ws,
        Err(err) => return error_response(err),
    };

    let mut warnings = new_config.collect_warnings();
    warnings.extend(scoped_validation_warnings);
    // The complete write set, classified against the configuration being
    // replaced: a PUT under a map key that did not exist is the creation
    // it is. Authorized before the persist and the comment write below.
    let before = state.config.read().clone();
    let authorization = match authorize_config_write(
        &principal,
        ConfigWriteSet::by_effect(
            &before,
            &new_config,
            new_config.dirty_paths.iter().map(String::as_str),
        ),
        &_cfg_guard,
    ) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };
    let agent_config_reservation =
        match zeroclaw_config::alias_refs::agent_alias_for_prop_path(&body.path)
            .map(|alias| state.agent_lifecycle.reserve_config_mutation(alias))
            .transpose()
        {
            Ok(reservation) => reservation,
            Err(error) => {
                return error_response(
                    ConfigApiError::new(ConfigApiCode::ValidationFailed, error.to_string())
                        .with_path(&body.path),
                );
            }
        };
    let annotations = body
        .comment
        .as_ref()
        .map(|comment| vec![(body.path.clone(), comment.clone())])
        .unwrap_or_default();
    let _cfg_guard = match persist_and_swap_retaining(
        &state,
        authorization,
        new_config,
        _cfg_guard,
        agent_config_reservation.into_iter().collect(),
        annotations,
    )
    .await
    {
        Ok(guard) => guard,
        Err(error) => return error,
    };

    if info.is_secret || info.derived_from_secret {
        axum::Json(SecretResponse {
            path: body.path,
            populated: !value_str.is_empty(),
        })
        .into_response()
    } else {
        axum::Json(PropResponse {
            path: body.path,
            value: serde_json::Value::String(value_str),
            warnings,
        })
        .into_response()
    }
}

pub async fn handle_prop_delete(
    State(state): State<AppState>,
    principal: RequestPrincipal,
    Query(q): Query<PropQuery>,
) -> Response {
    let _cfg_guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let mut new_config = _cfg_guard.current_config();
    let info = match lookup_prop_field(&new_config, &q.path) {
        Some(info) => info,
        None => return error_response(ConfigApiError::path_not_found(&q.path)),
    };

    if let Err(e) = new_config.set_prop_persistent(&q.path, "") {
        return error_response(map_prop_error(e, &q.path));
    }

    let scoped_validation_warnings = match scoped_validate(&new_config) {
        Ok(ws) => ws,
        Err(err) => return error_response(err),
    };

    let mut warnings = new_config.collect_warnings();
    warnings.extend(scoped_validation_warnings);
    // Clearing a scalar prop leaves the field declared, so the effect diff
    // alone would read as an update; the route's semantics are a removal.
    let before = state.config.read().clone();
    let authorization = match authorize_config_write(
        &principal,
        ConfigWriteSet::by_effect(
            &before,
            &new_config,
            new_config.dirty_paths.iter().map(String::as_str),
        )
        .with(q.path.clone(), Verb::Delete),
        &_cfg_guard,
    ) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };
    let agent_config_reservation =
        match zeroclaw_config::alias_refs::agent_alias_for_prop_path(&q.path)
            .map(|alias| state.agent_lifecycle.reserve_config_mutation(alias))
            .transpose()
        {
            Ok(reservation) => reservation,
            Err(error) => {
                return error_response(
                    ConfigApiError::new(ConfigApiCode::ValidationFailed, error.to_string())
                        .with_path(&q.path),
                );
            }
        };
    if let Err(e) = persist_and_swap_retaining(
        &state,
        authorization,
        new_config,
        _cfg_guard,
        agent_config_reservation.into_iter().collect(),
        Vec::new(),
    )
    .await
    {
        return e;
    }

    if info.is_secret || info.derived_from_secret {
        axum::Json(SecretResponse {
            path: q.path,
            populated: false,
        })
        .into_response()
    } else {
        axum::Json(PropResponse {
            path: q.path,
            value: serde_json::Value::Null,
            warnings,
        })
        .into_response()
    }
}

pub async fn handle_list(State(state): State<AppState>, Query(q): Query<ListQuery>) -> Response {
    let config = state.config.read().clone();
    let prefix = q.prefix.as_deref();

    // Drop fields that don't apply to the current shape of the config —
    // azure_* on a non-azure model_provider, qdrant.* when memory.backend is
    // sqlite, etc. Keeps the form scoped to relevant inputs only.
    let excluded = field_visibility::excluded_paths(&config, prefix.unwrap_or(""));

    let entries: Vec<ListEntry> = config
        .prop_fields()
        .into_iter()
        .filter(|info| match prefix {
            Some(p) => field_visibility::path_matches_prefix(&info.name, p),
            None => true,
        })
        .filter(|info| !field_visibility::is_excluded(&info.name, &excluded))
        .map(|info| {
            let populated = info.display_value != zeroclaw_config::traits::UNSET_DISPLAY;
            let is_sensitive = info.is_secret || info.derived_from_secret;
            let value = if is_sensitive {
                None
            } else {
                Some(serde_json::Value::String(info.display_value.clone()))
            };
            let section = section_for_path(&info.name).map(|s| s.as_str());
            let enum_variants = info.enum_variants.map(|f| f()).unwrap_or_default();
            let is_env_overridden = config.prop_is_env_overridden(&info.name);
            ListEntry {
                path: info.name,
                category: info.category.to_string(),
                kind: prop_kind_wire(info.kind),
                type_hint: info.type_hint,
                value,
                populated,
                is_secret: is_sensitive,
                is_env_overridden,
                enum_variants,
                section,
                tab: info.tab.label(),
                multiline: info.multiline,
            }
        })
        .collect();

    let drifted = compute_drift(&config).await;
    axum::Json(ListResponse { entries, drifted }).into_response()
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct DriftResponse {
    pub drifted: Vec<DriftEntry>,
}

/// `GET /api/config/drift` — explicit drift summary for clients that want just
/// the diff. Same `DriftEntry` shape used in `ListResponse.drifted`.
pub async fn handle_drift(State(state): State<AppState>) -> Response {
    let config = state.config.read().clone();
    let drifted = compute_drift(&config).await;
    axum::Json(DriftResponse { drifted }).into_response()
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct ReloadStatusResponse {
    /// Whether any config write has landed since the last admin reload and may
    /// still require subsystem re-instantiation to take effect.
    pub pending_reload: bool,
    pub application: zeroclaw_runtime::config_application::ConfigApplicationStatus,
}

/// `GET /api/config/reload-status` — pending-reload flag for the dashboard's
/// reload banner. Goes true on any config write, false on `/admin/reload`.
pub async fn handle_reload_status(State(state): State<AppState>) -> Response {
    let pending_reload = state
        .pending_reload
        .load(std::sync::atomic::Ordering::Relaxed);
    let application = state.config_authority.application_status();
    axum::Json(ReloadStatusResponse {
        pending_reload,
        application,
    })
    .into_response()
}

#[derive(Debug, Deserialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct MapKeyQuery {
    /// Map-keyed section path, e.g. `providers.models`, `agents`, `risk_profiles`.
    pub path: String,
    /// New key to insert under that section, e.g. `anthropic`.
    pub key: String,
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct MapKeyResponse {
    pub path: String,
    pub key: String,
    pub created: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub warnings: Option<Vec<String>>,
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct TemplatesResponse {
    pub templates: Vec<TemplateEntry>,
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct TemplateEntry {
    pub path: &'static str,
    /// `map` for `HashMap<String, T>`, `list` for `Vec<T>`.
    pub kind: &'static str,
    /// Rust type name of the value, e.g. `ModelProviderConfig`.
    pub value_type: &'static str,
    /// Doc comment from the schema (description of what gets added).
    pub description: &'static str,
}

pub async fn handle_templates(State(state): State<AppState>) -> Response {
    let _ = state; // templates are static per build, but auth-gated for consistency

    let templates: Vec<TemplateEntry> = zeroclaw_config::schema::Config::map_key_sections()
        .into_iter()
        .map(|s| TemplateEntry {
            path: s.path,
            kind: match s.kind {
                zeroclaw_config::traits::MapKeyKind::Map => "map",
                zeroclaw_config::traits::MapKeyKind::List => "list",
            },
            value_type: s.value_type,
            description: s.description,
        })
        .collect();

    axum::Json(TemplatesResponse { templates }).into_response()
}

#[derive(Debug, Deserialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct MapPathQuery {
    pub path: String,
}

#[derive(Debug, Deserialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct AliasSourceQuery {
    pub source: zeroclaw_config::traits::AliasSource,
}

/// `GET /api/config/resolve-alias-source?source=<source>` — list the configured
/// alias values valid for an alias-reference field, resolved from the live
/// config via the shared `Config::resolve_alias_source`.
pub async fn handle_resolve_alias_source(
    State(state): State<AppState>,
    Query(q): Query<AliasSourceQuery>,
) -> Response {
    let cfg = state.config.read().clone();
    let values = cfg.resolve_alias_source(q.source);
    axum::Json(serde_json::json!({ "source": q.source, "values": values })).into_response()
}

/// `GET /api/config/map-keys?path=<section>` — list the current alias keys at
/// a map-keyed section path, e.g. `channels.discord` → `["default","work"]`.
pub async fn handle_get_map_keys(
    State(state): State<AppState>,
    Query(q): Query<MapPathQuery>,
) -> Response {
    let cfg = state.config.read().clone();
    match cfg.get_map_keys(&q.path) {
        Some(keys) => {
            axum::Json(serde_json::json!({ "path": q.path, "keys": keys })).into_response()
        }
        None => error_response(
            ConfigApiError::new(
                ConfigApiCode::PathNotFound,
                format!("no map-keyed section at `{}`", q.path),
            )
            .with_path(&q.path),
        ),
    }
}

/// `DELETE /api/config/map-key?path=<section>&key=<alias>` — remove an alias
/// from a map-keyed section. Aliased config sections with executable delete
/// support route through the same cascade engine as the delete preview;
/// non-aliased sections keep the generic raw key removal. Persists on success.
pub async fn handle_delete_map_key(
    State(state): State<AppState>,
    principal: RequestPrincipal,
    Query(q): Query<MapKeyQuery>,
) -> Response {
    let agent_lifecycle_lease = if q.path == "agents" {
        match state.agent_lifecycle.begin_delete(q.key.clone()) {
            Ok(lease) => Some(lease),
            Err(error) => {
                return error_response(
                    ConfigApiError::new(ConfigApiCode::ValidationFailed, error.to_string())
                        .with_path(format!("agents.{}", q.key)),
                );
            }
        }
    } else {
        None
    };
    if let Some(zeroclaw_config::alias_refs::AliasKind::Agent) =
        zeroclaw_config::alias_refs::alias_kind_for_map_path(&q.path)
    {
        // Agent deletion is special: it must scrub config references
        // (heartbeat, peer-groups, delegates, workspace.access, …) via
        // `delete_with_cascade` and cascade owned non-config state (memory /
        // cron / acp / session).
        return delete_agent_cascade(
            &state,
            &principal,
            &q.key,
            agent_lifecycle_lease.expect("agent path acquires lifecycle lease"),
        )
        .await;
    }
    // Acquired before this read-for-modify, threaded into the cascade
    // helpers below, and held through whichever branch's swap runs.
    let _cfg_guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let working = _cfg_guard.current_config();
    if let Some(kind) = zeroclaw_config::alias_refs::alias_kind_for_map_path(&q.path) {
        return delete_config_cascade(
            &state, &principal, working, &kind, &q.path, &q.key, _cfg_guard,
        )
        .await;
    }
    let mut working = working;
    let removed = match working.delete_map_key(&q.path, &q.key) {
        Ok(b) => b,
        Err(msg) => {
            return error_response(
                ConfigApiError::new(ConfigApiCode::PathNotFound, msg).with_path(&q.path),
            );
        }
    };
    if removed {
        let removed_path = format!("{}.{}", q.path, q.key);
        working.mark_dirty(&removed_path);
        let before = state.config.read().clone();
        let authorization = match authorize_config_write(
            &principal,
            ConfigWriteSet::by_effect(
                &before,
                &working,
                working.dirty_paths.iter().map(String::as_str),
            )
            .with(removed_path, Verb::Delete),
            &_cfg_guard,
        ) {
            Ok(authorization) => authorization,
            Err(denied) => return denied.into_response(),
        };
        if let Err(e) = persist_and_swap(&state, authorization, working, _cfg_guard).await {
            return e;
        }
    }
    axum::Json(MapKeyResponse {
        path: q.path,
        key: q.key,
        created: false,
        warnings: None,
    })
    .into_response()
}

/// Agent-deletion cascade: refuse on HARD references (enabled `heartbeat.agent`
/// or live ACP sessions), else scrub config refs + remove the entry via
/// `delete_with_cascade`, archive the workspace, run the owned-state cascade
/// (export-then-delete memory/cron/acp + clear session attribution), and persist.
async fn delete_agent_cascade(
    state: &AppState,
    principal: &RequestPrincipal,
    alias: &str,
    mut lifecycle_lease: zeroclaw_runtime::live_config_authority::AgentDeleteLease,
) -> Response {
    use zeroclaw_config::alias_refs::{self, AliasKind, CascadePolicy};

    let preflight_config = state.config.read().clone();
    let preflight_alias = alias.to_string();
    let live_acp = tokio::task::spawn_blocking(move || {
        crate::agent_owned_state::live_acp_session_count(&preflight_config, &preflight_alias)
            .map_err(|error| error.to_string())
    })
    .await
    .unwrap_or_else(|error| Err(format!("ACP preflight task failed: {error}")));
    let guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let mut working = guard.current_config();
    let preflight = zeroclaw_runtime::agent_lifecycle::plan_agent_delete_with_acp_count(
        &working, alias, live_acp,
    );
    if !preflight.allowed {
        let code = if working.agents.contains_key(alias) {
            ConfigApiCode::ValidationFailed
        } else {
            ConfigApiCode::PathNotFound
        };
        return error_response(
            ConfigApiError::new(
                code,
                format!(
                    "cannot delete agent `{alias}`: {}",
                    preflight.blockers.join("; ")
                ),
            )
            .with_path(format!("agents.{alias}")),
        );
    }

    let workspace = preflight
        .workspace
        .expect("an allowed configured agent has a workspace path");

    // Config cascade: scrub soft refs + remove the agents entry.
    let cascade = match alias_refs::delete_with_cascade(
        &mut working,
        &AliasKind::Agent,
        alias,
        CascadePolicy::RefuseOnHard,
    ) {
        Ok(report) => report,
        Err(e) => {
            return error_response(
                ConfigApiError::new(
                    ConfigApiCode::ValidationFailed,
                    format!("agent config cascade failed: {e}"),
                )
                .with_path(format!("agents.{alias}")),
            );
        }
    };

    for path in cascade.dirty_paths() {
        working.mark_dirty(&path);
    }
    // The complete write set is known only now: the entry itself plus every
    // reference the cascade scrubbed elsewhere. Authorized before the
    // persist, which is the first side effect; the archive and owned-state
    // cascade follow it.
    let before = state.config.read().clone();
    let authorization = match authorize_config_write(
        principal,
        ConfigWriteSet::by_effect(
            &before,
            &working,
            working.dirty_paths.iter().map(String::as_str),
        )
        .with(format!("agents.{alias}"), Verb::Delete),
        &guard,
    ) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };

    // Config is about to become externally visible: spawn the retained
    // transaction BEFORE the first persistence await. The config write guard,
    // the uncommitted reservation, the prepared config, and the prepared
    // channel-generation control all live in a task that request cancellation
    // cannot abort; the request only awaits the handle.
    let memory = Arc::clone(&state.mem);
    let session_backend = state.session_backend.clone();
    let pending_reload = Arc::clone(&state.pending_reload);
    let reload_controls = state.reload_tx.clone();
    let cleanup_alias = alias.to_string();
    let cleanup =
        zeroclaw_runtime::live_config_authority::spawn_agent_lifecycle_job(Box::pin(async move {
            // Save the prepared config and install the matching live snapshot;
            // a true pre-commit save error rolls back disk state and ends this
            // task with the reservation uncommitted and generations unchanged.
            let prepared = persist_and_swap_prepared(
                &guard,
                pending_reload.clone(),
                reload_controls,
                working.clone(),
                authorization,
            )
            .await?;
            // Committed: advance the alias generation exactly once.
            // Synchronous — no await between the live swap and this commit.
            lifecycle_lease.commit_destructive_mutation();
            // Retire and await the channel generation while still holding the
            // config write guard, then schedule the daemon reload.
            finish_prepared_channel_generation(prepared, pending_reload).await;
            // Release the gateway-wide config write lock before slow cleanup.
            drop(guard);
            let archive = crate::agent_owned_state::archive_agent_workspace(
                &working,
                &cleanup_alias,
                &workspace,
            )
            .await;
            let archive_dir = archive.archive_dir;
            let mut warnings = archive.warnings;
            let owned = crate::agent_owned_state::cascade_owned_state(
                &working,
                &memory,
                session_backend.as_ref(),
                &cleanup_alias,
                &archive_dir,
            )
            .await;
            warnings.extend(owned.warnings.iter().cloned());
            // The committed lease releases only when this future completes.
            Ok((archive_dir, warnings, owned))
        }));
    let (archive_dir, warnings, owned) = match cleanup.await {
        Ok(Ok(result)) => result,
        Ok(Err(error)) => return error,
        Err(error) => {
            return error_response(ConfigApiError::new(
                ConfigApiCode::InternalError,
                format!("agent cleanup task failed: {error}"),
            ));
        }
    };
    // Combine per-side-effect failures (archive dir / workspace rename) with
    // the per-store failures surfaced by `cascade_owned_state`, so the operator
    // sees the FULL partial-failure picture in the response, not just the
    // server log.
    ::zeroclaw_log::record!(INFO, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_attrs(::serde_json::json!({"agent": alias, "memory": owned.memory_purged, "cron": owned.cron_removed, "acp": owned.acp_removed, "sessions_cleared": owned.sessions_cleared, "archive": archive_dir.display().to_string(), "warnings": warnings.len()})), "agent deleted with owned-state cascade");

    axum::Json(MapKeyResponse {
        path: "agents".to_string(),
        key: alias.to_string(),
        created: false,
        warnings: if warnings.is_empty() {
            None
        } else {
            Some(warnings)
        },
    })
    .into_response()
}

/// Config-only delete cascade for providers/channels (no owned state): refuse
/// on hard refs, scrub soft refs, mark every touched path dirty, persist.
async fn delete_config_cascade(
    state: &AppState,
    principal: &RequestPrincipal,
    mut working: zeroclaw_config::schema::Config,
    kind: &zeroclaw_config::alias_refs::AliasKind,
    path: &str,
    key: &str,
    guard: ConfigWriteGuard,
) -> Response {
    let report = match zeroclaw_config::alias_refs::delete_with_cascade(
        &mut working,
        kind,
        key,
        zeroclaw_config::alias_refs::CascadePolicy::RefuseOnHard,
    ) {
        Ok(r) => r,
        Err(e) => return delete_error_response(path, key, e),
    };
    let dirty_paths = report.dirty_paths();
    for dirty_path in &dirty_paths {
        working.mark_dirty(dirty_path);
    }
    let before = state.config.read().clone();
    let authorization = match authorize_config_write(
        principal,
        ConfigWriteSet::by_effect(
            &before,
            &working,
            working.dirty_paths.iter().map(String::as_str),
        )
        .with(format!("{path}.{key}"), Verb::Delete),
        &guard,
    ) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };
    if let Err(e) = persist_and_swap(state, authorization, working, guard).await {
        return e;
    }
    ::zeroclaw_log::record!(
        INFO,
        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_attrs(
            ::serde_json::json!({"path": path, "key": key, "dirty_paths": dirty_paths.len()})
        ),
        "alias deleted with config-ref cascade"
    );
    axum::Json(MapKeyResponse {
        path: path.to_string(),
        key: key.to_string(),
        created: false,
        warnings: None,
    })
    .into_response()
}

pub async fn handle_map_key(
    State(state): State<AppState>,
    principal: RequestPrincipal,
    Query(q): Query<MapKeyQuery>,
) -> Response {
    let path = q.path.clone();
    let key = q.key.clone();
    let _cfg_guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let mut working = _cfg_guard.current_config();

    // Create through the shared guarded boundary so the reserved-agent rule (the
    // `default` runtime fallback) is enforced once for every surface. Reserved ->
    // 400 (validation_failed), symmetric with the rename guard; an unknown
    // section or invalid key stays 404 (path_not_found) as before.
    let created =
        match zeroclaw_config::alias_refs::create_map_key_checked(&mut working, &path, &key) {
            Ok(b) => b,
            Err(zeroclaw_config::alias_refs::CreateError::Reserved(a)) => {
                return error_response(
                    ConfigApiError::new(
                        ConfigApiCode::ValidationFailed,
                        format!("alias `{a}` is reserved and cannot be created"),
                    )
                    .with_path(format!("{path}.{key}")),
                );
            }
            Err(zeroclaw_config::alias_refs::CreateError::Invalid(msg)) => {
                return error_response(
                    ConfigApiError::new(ConfigApiCode::PathNotFound, msg).with_path(&path),
                );
            }
        };

    if created {
        let created_path = format!("{path}.{key}");
        working.mark_dirty(&created_path);
        // Authorized before the bundle directory below, the first side
        // effect of a creation.
        let before = state.config.read().clone();
        let authorization = match authorize_config_write(
            &principal,
            ConfigWriteSet::by_effect(
                &before,
                &working,
                working.dirty_paths.iter().map(String::as_str),
            )
            .with(created_path, Verb::Create),
            &_cfg_guard,
        ) {
            Ok(authorization) => authorization,
            Err(denied) => return denied.into_response(),
        };
        let agent_config_reservation = if path == "agents" {
            match state.agent_lifecycle.reserve_config_mutation(key.clone()) {
                Ok(reservation) => Some(reservation),
                Err(error) => {
                    return error_response(
                        ConfigApiError::new(ConfigApiCode::ValidationFailed, error.to_string())
                            .with_path(format!("agents.{key}")),
                    );
                }
            }
        } else {
            None
        };

        // skill-bundles: materialize the bundle's resolved directory so
        // skills have a home immediately. Run before persist so a failed
        // mkdir surfaces in logs alongside the config write.
        if path == "skill_bundles" {
            let install_root = working.install_root_dir();
            if let Ok(dir) =
                zeroclaw_config::skill_bundles::resolve_directory(&working, &install_root, &key)
                && let Err(e) = tokio::fs::create_dir_all(&dir).await
            {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                        .with_outcome(::zeroclaw_log::EventOutcome::Unknown),
                    &format!(
                        "skill-bundle '{key}' directory creation failed at {}: {e}",
                        dir.display().to_string()
                    )
                );
            }
        }

        if let Err(e) = persist_and_swap_retaining(
            &state,
            authorization,
            working,
            _cfg_guard,
            agent_config_reservation.into_iter().collect(),
            Vec::new(),
        )
        .await
        {
            return e;
        }
    }

    axum::Json(MapKeyResponse {
        path,
        key,
        created,
        warnings: None,
    })
    .into_response()
}

/// A single config reference site to an aliased entry, for the delete preview.
#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct RefSiteDto {
    /// Dotted config path that references the alias, e.g.
    /// `agents.forge.model_provider` or `heartbeat.agent`.
    pub path: String,
    /// The stored reference text, e.g. `anthropic.default`.
    pub raw_value: String,
}

/// Dry-run impact of deleting an aliased entry — the cascade preview a surface
/// renders before confirming. Pure/read-only: computed from `plan_delete` (the
/// same reference walk the real delete uses) plus the live-ACP gate for agents.
#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct DeletePlanResponse {
    pub path: String,
    pub key: String,
    /// True iff nothing HARD blocks the delete (no hard config reference and,
    /// for agents, no live ACP session). Mirrors the real delete's refusal gate.
    pub allowed: bool,
    /// HARD references that block the delete — the operator must change these
    /// first (e.g. an enabled `heartbeat.agent`).
    pub blockers: Vec<RefSiteDto>,
    /// SOFT references the delete would scrub automatically.
    pub scrubs: Vec<RefSiteDto>,
    /// Agent delete only: number of live ACP sessions (a non-zero count blocks
    /// the delete; `null` for non-agent sections or if the count couldn't be
    /// read — in which case the delete fails closed too).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub live_acp_sessions: Option<usize>,
    /// Agent delete only: the agent's owned non-config state (memory / cron /
    /// session history) is exported and removed on delete. Counts are not
    /// enumerated in the preview.
    pub cascades_owned_state: bool,
}

/// `GET /api/config/delete-plan?path=<section>&key=<alias>` — dry-run the delete
/// cascade for an aliased entry. Read-only; never mutates.
pub async fn handle_delete_plan(
    State(state): State<AppState>,
    Query(q): Query<MapKeyQuery>,
) -> Response {
    let config = state.config.read().clone();
    let to_dto = |s: &zeroclaw_config::alias_refs::RefSite| RefSiteDto {
        path: s.path.clone(),
        raw_value: s.raw_value.clone(),
    };
    let Some(kind) = zeroclaw_config::alias_refs::alias_kind_for_map_path(&q.path) else {
        // Non-aliased section (e.g. `mcp.servers`): generic key removal with no
        // reference cascade — nothing to preview.
        return axum::Json(DeletePlanResponse {
            path: q.path,
            key: q.key,
            allowed: true,
            blockers: Vec::new(),
            scrubs: Vec::new(),
            live_acp_sessions: None,
            cascades_owned_state: false,
        })
        .into_response();
    };
    if let Some(message) = unsupported_delete_cascade_message(&kind) {
        return error_response(
            ConfigApiError::new(ConfigApiCode::OpNotSupported, message)
                .with_path(format!("{}.{}", q.path, q.key)),
        );
    }
    let plan = zeroclaw_config::alias_refs::plan_delete(&config, &kind, &q.key);
    let is_agent = matches!(kind, zeroclaw_config::alias_refs::AliasKind::Agent);
    // For agents the live-ACP gate also blocks; it fails closed (an error
    // counting sessions ⇒ "not allowed"), matching the real delete.
    let live_acp = if is_agent {
        crate::agent_owned_state::live_acp_session_count(&config, &q.key).ok()
    } else {
        None
    };
    let lifecycle_blocker = is_agent
        .then(|| state.agent_lifecycle.delete_blocker(&q.key))
        .flatten();
    let allowed = plan.allowed && (!is_agent || live_acp == Some(0)) && lifecycle_blocker.is_none();
    let mut blockers: Vec<RefSiteDto> = plan.blockers.iter().map(to_dto).collect();
    if let Some(blocker) = lifecycle_blocker {
        blockers.push(RefSiteDto {
            path: format!("agents.{}", q.key),
            raw_value: blocker.to_string(),
        });
    }
    axum::Json(DeletePlanResponse {
        path: q.path,
        key: q.key,
        allowed,
        blockers,
        scrubs: plan.scrubs.iter().map(to_dto).collect(),
        live_acp_sessions: live_acp,
        cascades_owned_state: is_agent,
    })
    .into_response()
}

fn unsupported_delete_cascade_message(
    kind: &zeroclaw_config::alias_refs::AliasKind,
) -> Option<&'static str> {
    use zeroclaw_config::alias_refs::{AliasKind, ProviderCategory};
    match kind {
        AliasKind::Provider {
            category: ProviderCategory::Tts | ProviderCategory::Transcription,
            ..
        } => Some("TTS/transcription provider delete-with-cascade is not yet implemented"),
        _ => None,
    }
}

#[derive(Debug, Deserialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct RenameMapKeyBody {
    /// Section path, e.g. `channels.discord` or `model_providers.anthropic`.
    pub path: String,
    /// Current alias name.
    pub from: String,
    /// New alias name.
    pub to: String,
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct RenameMapKeyResponse {
    pub path: String,
    pub from: String,
    pub to: String,
    pub renamed: bool,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub warnings: Vec<String>,
}

/// Map a [`RenameError`](zeroclaw_config::alias_refs::RenameError) to the HTTP
/// error response (NotFound→404, InvalidName/Reserved→400, PostCondition→500).
fn rename_error_response(
    path: &str,
    from: &str,
    err: zeroclaw_config::alias_refs::RenameError,
) -> Response {
    use zeroclaw_config::alias_refs::RenameError;
    let (code, msg) = match err {
        RenameError::NotFound(p) => (
            ConfigApiCode::PathNotFound,
            format!("{p} is not configured"),
        ),
        RenameError::InvalidName(m) => (ConfigApiCode::ValidationFailed, m),
        RenameError::Reserved(a) => (
            ConfigApiCode::ValidationFailed,
            format!("alias `{a}` is reserved and cannot be renamed"),
        ),
        RenameError::PostCondition(m) => (
            ConfigApiCode::InternalError,
            format!("rename cascade post-condition failed: {m}"),
        ),
    };
    error_response(ConfigApiError::new(code, msg).with_path(format!("{path}.{from}")))
}

/// Map a [`CascadeError`](zeroclaw_config::alias_refs::CascadeError) to the
/// HTTP error response for config-only alias deletes. `Refused` and
/// `NotImplemented` are expected operator-facing outcomes, while
/// `PostCondition` is an internal guard failure and must not be persisted.
fn delete_error_response(
    path: &str,
    key: &str,
    err: zeroclaw_config::alias_refs::CascadeError,
) -> Response {
    use zeroclaw_config::alias_refs::CascadeError;
    let (code, msg) = match err {
        CascadeError::Refused(report) => {
            let blockers: Vec<_> = report.blockers.iter().map(|b| b.path.as_str()).collect();
            let detail = if blockers.is_empty() {
                "hard references remain".to_string()
            } else {
                format!("hard reference(s) remain: {}", blockers.join(", "))
            };
            (
                ConfigApiCode::ValidationFailed,
                format!("cannot delete alias `{key}`: {detail}"),
            )
        }
        CascadeError::NotFound(p) => (
            ConfigApiCode::PathNotFound,
            format!("{p} is not configured"),
        ),
        CascadeError::NotImplemented(m) => (ConfigApiCode::OpNotSupported, m),
        CascadeError::PostCondition(m) => (
            ConfigApiCode::InternalError,
            format!("delete cascade post-condition failed: {m}"),
        ),
    };
    error_response(ConfigApiError::new(code, msg).with_path(format!("{path}.{key}")))
}

pub async fn handle_rename_map_key(
    State(state): State<AppState>,
    principal: RequestPrincipal,
    axum::Json(body): axum::Json<RenameMapKeyBody>,
) -> Response {
    let agent_lifecycle_leases = if body.path == "agents" {
        let from = match state.agent_lifecycle.begin_delete(body.from.clone()) {
            Ok(lease) => lease,
            Err(error) => {
                return error_response(
                    ConfigApiError::new(ConfigApiCode::ValidationFailed, error.to_string())
                        .with_path(format!("agents.{}", body.from)),
                );
            }
        };
        let mut leases = vec![from];
        if body.to != body.from {
            match state.agent_lifecycle.begin_delete(body.to.clone()) {
                Ok(lease) => leases.push(lease),
                Err(error) => {
                    return error_response(
                        ConfigApiError::new(ConfigApiCode::ValidationFailed, error.to_string())
                            .with_path(format!("agents.{}", body.to)),
                    );
                }
            }
        }
        leases
    } else {
        Vec::new()
    };
    // Acquired before this read-for-modify, threaded into the cascade
    // helpers below, and held through whichever branch's swap runs.
    let _cfg_guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let working = _cfg_guard.current_config();

    match zeroclaw_config::alias_refs::alias_kind_for_map_path(&body.path) {
        Some(zeroclaw_config::alias_refs::AliasKind::Agent) => {
            rename_agent_cascade(
                &state,
                &principal,
                working,
                &body,
                _cfg_guard,
                agent_lifecycle_leases,
            )
            .await
        }
        Some(kind) => {
            rename_config_cascade(&state, &principal, working, &kind, &body, _cfg_guard).await
        }
        None => {
            // Non-aliased section: the generic key-swap rename (unchanged).
            let mut working = working;
            let renamed = match working.rename_map_key(&body.path, &body.from, &body.to) {
                Ok(b) => b,
                Err(msg) => {
                    return error_response(
                        ConfigApiError::new(ConfigApiCode::ValidationFailed, msg)
                            .with_path(&body.path),
                    );
                }
            };
            if renamed {
                let from_path = format!("{}.{}", body.path, body.from);
                let to_path = format!("{}.{}", body.path, body.to);
                working.mark_dirty(&from_path);
                working.mark_dirty(&to_path);
                // Source and destination are both in the write set: a
                // rename removes one entry and creates another.
                let before = state.config.read().clone();
                let authorization = match authorize_config_write(
                    &principal,
                    ConfigWriteSet::by_effect(
                        &before,
                        &working,
                        working.dirty_paths.iter().map(String::as_str),
                    )
                    .with(from_path, Verb::Delete)
                    .with(to_path, Verb::Create),
                    &_cfg_guard,
                ) {
                    Ok(authorization) => authorization,
                    Err(denied) => return denied.into_response(),
                };
                if let Err(e) = persist_and_swap(&state, authorization, working, _cfg_guard).await {
                    return e;
                }
            }
            axum::Json(RenameMapKeyResponse {
                path: body.path,
                from: body.from,
                to: body.to,
                renamed,
                warnings: Vec::new(),
            })
            .into_response()
        }
    }
}

/// Config-only rename cascade for providers/channels (no owned state): rewrite
/// references, mark every touched path dirty, persist.
async fn rename_config_cascade(
    state: &AppState,
    principal: &RequestPrincipal,
    mut working: zeroclaw_config::schema::Config,
    kind: &zeroclaw_config::alias_refs::AliasKind,
    body: &RenameMapKeyBody,
    guard: ConfigWriteGuard,
) -> Response {
    let report = match zeroclaw_config::alias_refs::rename_with_cascade(
        &mut working,
        kind,
        &body.from,
        &body.to,
    ) {
        Ok(r) => r,
        Err(e) => return rename_error_response(&body.path, &body.from, e),
    };
    for path in &report.dirty_paths {
        working.mark_dirty(path);
    }
    let before = state.config.read().clone();
    let authorization = match authorize_config_write(
        principal,
        rename_write_set(&before, &working, body),
        &guard,
    ) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };
    if let Err(e) = persist_and_swap(state, authorization, working, guard).await {
        return e;
    }
    ::zeroclaw_log::record!(INFO, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_attrs(::serde_json::json!({"path": body.path, "from": body.from, "to": body.to, "dirty_paths": report.dirty_paths.len()})), "alias renamed with config-ref cascade");
    axum::Json(RenameMapKeyResponse {
        path: body.path.clone(),
        from: body.from.clone(),
        to: body.to.clone(),
        renamed: true,
        warnings: Vec::new(),
    })
    .into_response()
}

/// A rename's complete write set: the source removed, the destination
/// created, and every reference the cascade rewrote elsewhere, each
/// classified by its effect on the configuration being replaced.
fn rename_write_set(
    before: &zeroclaw_config::schema::Config,
    working: &zeroclaw_config::schema::Config,
    body: &RenameMapKeyBody,
) -> ConfigWriteSet {
    ConfigWriteSet::by_effect(
        before,
        working,
        working.dirty_paths.iter().map(String::as_str),
    )
    .with(format!("{}.{}", body.path, body.from), Verb::Delete)
    .with(format!("{}.{}", body.path, body.to), Verb::Create)
}

async fn move_renamed_workspace(
    old_ws: &std::path::Path,
    new_ws: &std::path::Path,
) -> Option<String> {
    if old_ws == new_ws || !old_ws.exists() {
        return None;
    }
    if let Some(parent) = new_ws.parent() {
        let _ = tokio::fs::create_dir_all(parent).await;
    }
    match tokio::fs::rename(old_ws, new_ws).await {
        Ok(()) => None,
        Err(err) => {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({
                        "old": old_ws.display().to_string(),
                        "new": new_ws.display().to_string(),
                        "err": err.to_string()
                    })),
                "agent rename: workspace move failed"
            );
            Some(format!(
                "workspace move {} -> {} failed: {err}",
                old_ws.display(),
                new_ws.display()
            ))
        }
    }
}

async fn rename_residue_exists(
    state: &AppState,
    working: &zeroclaw_config::schema::Config,
    from: &str,
) -> bool {
    // Workspace: the default per-alias dir for `from`. A custom/alias-independent
    // path is not moved by the cascade, so it is not residue.
    if working.agent_workspace_dir(from).exists() {
        return true;
    }

    // Short-lived clone for the DB-backed stores - never hold the lock across an
    // `.await`.
    let cfg = state.config.read().clone();

    // Cron jobs still owned by `from`.
    if zeroclaw_runtime::cron::list_jobs_by_agent(&cfg, from)
        .map(|jobs| !jobs.is_empty())
        .unwrap_or(false)
    {
        return true;
    }

    // ACP sessions (live OR killed) still owned by `from`.
    if let Ok(store) = zeroclaw_infra::acp_session_store::AcpSessionStore::new(&cfg.data_dir)
        && store
            .list_sessions_by_agent(from)
            .map(|s| !s.is_empty())
            .unwrap_or(false)
    {
        return true;
    }

    // Memory rows still attributed to `from`.
    if state.mem.count_agent(from).await.unwrap_or(0) > 0 {
        return true;
    }

    // Session-metadata attribution still pointing at `from`.
    if let Some(backend) = state.session_backend.as_ref()
        && backend.count_agent_attribution(from).unwrap_or(0) > 0
    {
        return true;
    }

    false
}

async fn rename_agent_cascade(
    state: &AppState,
    principal: &RequestPrincipal,
    mut working: zeroclaw_config::schema::Config,
    body: &RenameMapKeyBody,
    guard: ConfigWriteGuard,
    mut lifecycle_leases: Vec<zeroclaw_runtime::live_config_authority::AgentDeleteLease>,
) -> Response {
    use zeroclaw_config::alias_refs::{self, AliasKind};
    let (from, to) = (&body.from, &body.to);

    // The rename's own intent is authorized before anything happens at
    // all, the residue re-run included (it writes no config but moves the
    // agent's owned state). The complete write set, once the cascade has
    // computed it, is authorized again below before the persist.
    let before = state.config.read().clone();
    if let Err(denied) = authorize_config_write(
        principal,
        ConfigWriteSet::default()
            .with(format!("{}.{from}", body.path), Verb::Delete)
            .with(format!("{}.{to}", body.path), Verb::Create),
        &guard,
    ) {
        return denied.into_response();
    }

    // Capture the OLD workspace path while the entry still lives under `from`
    // (custom paths are read off the entry, which is about to move).
    let old_ws = working.agent_workspace_dir(from);

    let committed_to = working.agent(from).is_none() && working.agent(to).is_some();
    let skip_persist = committed_to && rename_residue_exists(state, &working, from).await;
    let (dirty_count, authorization) = if skip_persist {
        (0, None)
    } else {
        match alias_refs::rename_with_cascade(&mut working, &AliasKind::Agent, from, to) {
            Ok(report) => {
                for path in &report.dirty_paths {
                    working.mark_dirty(path);
                }
                let dirty_count = report.dirty_paths.len();
                let authorization = match authorize_config_write(
                    principal,
                    rename_write_set(&before, &working, body),
                    &guard,
                ) {
                    Ok(authorization) => authorization,
                    Err(denied) => return denied.into_response(),
                };
                (dirty_count, Some(authorization))
            }
            Err(e) => return rename_error_response(&body.path, from, e),
        }
    };
    // The NEW workspace path off the prepared config (the rewritten `to`);
    // identical to the post-swap live config once persistence lands.
    let new_ws = working.agent_workspace_dir(to);

    // Config is about to become externally visible: spawn the retained
    // transaction BEFORE the first persistence await. The config write guard,
    // both uncommitted reservations, the prepared config, and the prepared
    // channel-generation control all live in a task that request cancellation
    // cannot abort; the request only awaits the handle.
    //
    // Move the workspace dir. For the default per-alias location this is
    // `<install>/agents/<from>/workspace` → `…/<to>/workspace`. A custom
    // workspace path is alias-independent, so `old_ws == new_ws` and we skip.
    let ws_existed = old_ws != new_ws && old_ws.exists();
    let memory = Arc::clone(&state.mem);
    let session_backend = state.session_backend.clone();
    let pending_reload = Arc::clone(&state.pending_reload);
    let reload_controls = state.reload_tx.clone();
    let cleanup_from = from.clone();
    let cleanup_to = to.clone();
    let cleanup = zeroclaw_runtime::live_config_authority::spawn_agent_lifecycle_job(async move {
        // Save the prepared config and install the matching live
        // snapshot; a true pre-commit save error rolls back disk state
        // and ends this task with both reservations uncommitted and
        // generations unchanged. A resume run (config already committed
        // `from -> to` by a prior crashed attempt) skips the persist.
        let prepared = if !skip_persist {
            persist_and_swap_prepared(
                &guard,
                pending_reload.clone(),
                reload_controls,
                working.clone(),
                authorization.expect("persisting rename was authorized"),
            )
            .await?
        } else {
            None
        };
        // Committed: advance both alias generations exactly once.
        // Synchronous — no await between the live swap and this commit.
        for lease in &mut lifecycle_leases {
            lease.commit_destructive_mutation();
        }
        // Retire and await the channel generation while still holding the
        // config write guard, then schedule the daemon reload.
        finish_prepared_channel_generation(prepared, pending_reload).await;
        // Release the gateway-wide config write lock before slow cleanup.
        drop(guard);
        let move_warning = move_renamed_workspace(&old_ws, &new_ws).await;
        let workspace_moved = ws_existed && move_warning.is_none();
        let mut warnings: Vec<String> = move_warning.into_iter().collect();
        let owned = crate::agent_owned_state::cascade_rename_agent(
            &working,
            Some(&memory),
            session_backend.as_ref(),
            &cleanup_from,
            &cleanup_to,
        )
        .await;
        warnings.extend(owned.warnings.iter().cloned());
        // Both committed leases release only when this future completes.
        Ok((workspace_moved, warnings, owned))
    });
    let (workspace_moved, warnings, owned) = match cleanup.await {
        Ok(Ok(result)) => result,
        Ok(Err(error)) => return error,
        Err(error) => {
            return error_response(ConfigApiError::new(
                ConfigApiCode::InternalError,
                format!("agent rename cleanup task failed: {error}"),
            ));
        }
    };

    // The config rename committed. A non-empty `warnings` means a post-persist
    // side-effect did not follow (config is `to`, some follower lags at `from`,
    // re-runnable) - escalate to WARN so that degraded outcome is visible
    // operationally instead of buried at INFO.
    if warnings.is_empty() {
        ::zeroclaw_log::record!(INFO, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_attrs(::serde_json::json!({"from": from, "to": to, "memory": owned.memory_rows, "cron": owned.cron_jobs, "acp": owned.acp_sessions, "sessions": owned.sessions_repointed, "workspace_moved": workspace_moved, "dirty_paths": dirty_count})), "agent renamed with owned-state cascade");
    } else {
        ::zeroclaw_log::record!(WARN, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_attrs(::serde_json::json!({"from": from, "to": to, "memory": owned.memory_rows, "cron": owned.cron_jobs, "acp": owned.acp_sessions, "sessions": owned.sessions_repointed, "workspace_moved": workspace_moved, "dirty_paths": dirty_count, "warnings": warnings})), "agent rename persisted but a post-persist side-effect did not follow; re-issue the rename to converge");
    }

    // Persisted rename. `warnings` carries any post-persist side-effect that did
    // not follow, so the split can be remediated rather than reported as a clean
    // success (207-style partial success).
    axum::Json(RenameMapKeyResponse {
        path: body.path.clone(),
        from: from.clone(),
        to: to.clone(),
        renamed: true,
        warnings,
    })
    .into_response()
}

pub async fn handle_refresh_context_window(
    State(state): State<AppState>,
    principal: RequestPrincipal,
    axum::extract::Path((provider_type, alias)): axum::extract::Path<(String, String)>,
) -> Response {
    let path = format!("providers.models.{provider_type}.{alias}");

    // Build the minimal provider config the fetch below needs from a brief,
    // un-witnessed read that clones what it needs out immediately (the
    // `parking_lot` guard never survives past this block, well before the
    // network `.await`). Deliberately NOT inside an admitted config commit:
    // the outbound provider fetch can be slow or hang, and holding the
    // daemon-wide writer serialization across it would block every other
    // gateway config write process-wide for the duration -- a
    // self-inflicted availability bottleneck.
    let provider_config = {
        let snapshot = state.config.read();
        if snapshot.get_prop(&format!("{path}.model")).is_err() {
            return error_response(
                ConfigApiError::new(
                    ConfigApiCode::PathNotFound,
                    format!("model provider '{provider_type}.{alias}' not found"),
                )
                .with_path(&path),
            );
        }
        let model = snapshot
            .get_prop(&format!("{path}.model"))
            .ok()
            .unwrap_or_default();
        let uri = snapshot.get_prop(&format!("{path}.uri")).ok();
        // Read api_key via JSON serialization to bypass #[secret] masking in get_prop.
        let api_key = serde_json::to_value(&snapshot.providers)
            .ok()
            .and_then(|v| {
                v.pointer(&format!("/models/{provider_type}/{alias}/api_key"))
                    .and_then(|v| v.as_str())
                    .filter(|s| !s.is_empty() && *s != "<unset>")
                    .map(String::from)
            });
        zeroclaw_config::schema::ModelProviderConfig {
            model: Some(model),
            uri,
            api_key,
            ..Default::default()
        }
    };

    // Fetch context window from provider. No config commit — nor any
    // reader guard — is held across this await.
    let context_window = match zeroclaw_providers::fetch_context_window(
        &provider_type,
        &provider_config,
    )
    .await
    {
        Some(ctx) => ctx,
        None => {
            return error_response(
                ConfigApiError::new(
                    ConfigApiCode::InvalidFormat,
                    format!("provider '{provider_type}' does not support context window auto-detection or fetch failed"),
                )
                .with_path(&path),
            );
        }
    };

    // The commit is admitted only now, spanning just the config mutation:
    // read-for-modify, apply the fetched value, save, publish.
    let _cfg_guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let mut working = _cfg_guard.current_config();

    // Re-verify: a concurrent writer could have removed this entry while
    // the un-witnessed fetch above was in flight.
    if working.get_prop(&format!("{path}.model")).is_err() {
        return error_response(
            ConfigApiError::new(
                ConfigApiCode::PathNotFound,
                format!("model provider '{provider_type}.{alias}' not found"),
            )
            .with_path(&path),
        );
    }

    if let Err(e) = working.set_prop_persistent(
        &format!("{path}.context_window"),
        &context_window.to_string(),
    ) {
        return error_response(
            ConfigApiError::new(
                ConfigApiCode::InternalError,
                format!("failed to persist context_window: {e}"),
            )
            .with_path(&path),
        );
    }

    working.mark_dirty(&format!("{path}.context_window"));
    let before = state.config.read().clone();
    let authorization = match authorize_config_write(
        &principal,
        ConfigWriteSet::by_effect(
            &before,
            &working,
            working.dirty_paths.iter().map(String::as_str),
        ),
        &_cfg_guard,
    ) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };
    if let Err(e) = persist_and_swap(&state, authorization, working, _cfg_guard).await {
        return e;
    }

    axum::Json(serde_json::json!({
        "path": path,
        "context_window": context_window,
    }))
    .into_response()
}

pub async fn handle_patch(
    State(state): State<AppState>,
    principal: RequestPrincipal,
    headers: HeaderMap,
    axum::Json(body): axum::Json<serde_json::Value>,
) -> Response {
    let ops = match parse_patch_ops(body) {
        Ok(ops) => ops,
        Err(e) => return error_response(e),
    };

    let agent_aliases: std::collections::BTreeSet<String> = ops
        .iter()
        .filter(|op| matches!(op.op.as_str(), "add" | "replace" | "remove"))
        .filter_map(|op| {
            let path = json_pointer_to_dotted(&op.path);
            zeroclaw_config::alias_refs::agent_alias_for_prop_path(&path).map(str::to_owned)
        })
        .collect();
    let _cfg_guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let working = _cfg_guard.current_config();

    let override_drift = headers
        .get("x-zeroclaw-override-drift")
        .and_then(|v| v.to_str().ok())
        .map(|v| v.eq_ignore_ascii_case("true"))
        .unwrap_or(false);
    if !override_drift {
        let drifted = compute_drift(&working).await;
        if !drifted.is_empty() {
            let touched: std::collections::HashSet<String> = ops
                .iter()
                .map(|op| json_pointer_to_dotted(&op.path))
                .collect();
            let conflicts: Vec<&DriftEntry> = drifted
                .iter()
                .filter(|d| touched.contains(&d.path))
                .collect();
            if !conflicts.is_empty() {
                let conflict_paths: Vec<String> =
                    conflicts.iter().map(|d| d.path.clone()).collect();
                return error_response(ConfigApiError::new(
                    ConfigApiCode::ConfigChangedExternally,
                    format!(
                        "on-disk config has drifted from in-memory state on \
                         {} path(s) being patched: {}. Send `X-ZeroClaw-Override-Drift: true` \
                         to overwrite, or GET /api/config/drift to inspect first.",
                        conflicts.len(),
                        conflict_paths.join(", "),
                    ),
                ));
            }
        }
    }

    let mut working = working;
    let mut results = Vec::with_capacity(ops.len());

    for (idx, op) in ops.iter().enumerate() {
        let path = json_pointer_to_dotted(&op.path);
        if matches!(op.op.as_str(), "add" | "replace") && working.ensure_map_key_for_path(&path) {
            // Refused to vivify the reserved `default` agent: surface the same
            // reserved error the explicit create surfaces do, not a generic 404.
            return error_response(
                ConfigApiError::new(
                    ConfigApiCode::ValidationFailed,
                    "alias `default` is reserved and cannot be created",
                )
                .with_path(&path)
                .with_op_index(idx),
            );
        }
        let info = lookup_prop_field(&working, &path);
        let is_sensitive = info
            .as_ref()
            .map(|i| i.is_secret || i.derived_from_secret)
            .unwrap_or(false);

        match op.op.as_str() {
            "test" => {
                // Secret values can't leave the server, so a differential
                // test response would be the only signal — ban the op.
                if is_sensitive {
                    return error_response(
                        ConfigApiError::secret_test_forbidden(&path).with_op_index(idx),
                    );
                }
                let want = match op.value.as_ref() {
                    Some(v) => v.clone(),
                    None => {
                        return error_response(
                            ConfigApiError::new(
                                ConfigApiCode::ValueTypeMismatch,
                                "JSON Patch `test` op requires `value` field",
                            )
                            .with_path(&path)
                            .with_op_index(idx),
                        );
                    }
                };
                let actual_str = match working.get_prop(&path) {
                    Ok(v) => v,
                    Err(e) => return error_response(map_prop_error(e, &path).with_op_index(idx)),
                };
                let want_str = match json_to_setprop_string(&want, info.as_ref().map(|i| i.kind)) {
                    Ok(s) => s,
                    Err(e) => return error_response(e.with_path(&path).with_op_index(idx)),
                };
                if actual_str != want_str {
                    return error_response(
                        ConfigApiError::new(
                            ConfigApiCode::ValidationFailed,
                            format!("`test` op failed: expected {want_str:?}, got {actual_str:?}"),
                        )
                        .with_path(&path)
                        .with_op_index(idx),
                    );
                }
                results.push(PatchOpResult {
                    op: op.op.clone(),
                    path,
                    value: Some(serde_json::Value::String(actual_str)),
                    populated: None,
                    comment: None, // `test` ops don't write
                });
            }
            "add" | "replace" => {
                let value = match op.value.as_ref() {
                    Some(v) => v.clone(),
                    None => {
                        return error_response(
                            ConfigApiError::new(
                                ConfigApiCode::ValueTypeMismatch,
                                format!("JSON Patch `{}` op requires `value` field", op.op),
                            )
                            .with_path(&path)
                            .with_op_index(idx),
                        );
                    }
                };
                let value_str = match json_to_setprop_string(&value, info.as_ref().map(|i| i.kind))
                {
                    Ok(s) => s,
                    Err(e) => {
                        return error_response(e.with_path(&path).with_op_index(idx));
                    }
                };
                if let Err(e) = reject_masked_secret_value(&path, is_sensitive, &value_str) {
                    return error_response(e.with_op_index(idx));
                }
                if let Err(e) = working.set_prop_persistent(&path, &value_str) {
                    return error_response(map_prop_error(e, &path).with_op_index(idx));
                }
                if is_sensitive {
                    results.push(PatchOpResult {
                        op: op.op.clone(),
                        path,
                        value: None,
                        populated: Some(!value_str.is_empty()),
                        comment: op.comment.clone(),
                    });
                } else {
                    results.push(PatchOpResult {
                        op: op.op.clone(),
                        path,
                        value: Some(serde_json::Value::String(value_str)),
                        populated: None,
                        comment: op.comment.clone(),
                    });
                }
            }
            "remove" => {
                if let Err(e) = working.set_prop_persistent(&path, "") {
                    return error_response(map_prop_error(e, &path).with_op_index(idx));
                }
                if is_sensitive {
                    results.push(PatchOpResult {
                        op: op.op.clone(),
                        path,
                        value: None,
                        populated: Some(false),
                        comment: op.comment.clone(),
                    });
                } else {
                    results.push(PatchOpResult {
                        op: op.op.clone(),
                        path,
                        value: Some(serde_json::Value::Null),
                        populated: None,
                        comment: op.comment.clone(),
                    });
                }
            }
            "comment" => {
                // Comment-only update: record the (path, comment) pair
                // for `apply_comments` after the patch commits, but
                // skip `set_prop` entirely. Lets the operator annotate
                // a secret without rotating its ciphertext.
                if info.is_none() {
                    return error_response(
                        ConfigApiError::path_not_found(&path).with_op_index(idx),
                    );
                }
                let Some(comment) = op.comment.clone() else {
                    return error_response(
                        ConfigApiError::new(
                            ConfigApiCode::ValueTypeMismatch,
                            "JSON Patch `comment` op requires `comment` field",
                        )
                        .with_path(&path)
                        .with_op_index(idx),
                    );
                };
                results.push(PatchOpResult {
                    op: op.op.clone(),
                    path,
                    value: None,
                    populated: None,
                    comment: Some(comment),
                });
            }
            "move" | "copy" => {
                return error_response(
                    ConfigApiError::op_not_supported(&op.op)
                        .with_path(&path)
                        .with_op_index(idx),
                );
            }
            other => {
                return error_response(
                    ConfigApiError::new(
                        ConfigApiCode::OpNotSupported,
                        format!("unknown JSON Patch operation `{other}`"),
                    )
                    .with_path(&path)
                    .with_op_index(idx),
                );
            }
        }
    }

    // Per-PATCH validation is scoped to the dirty paths. See
    // `scoped_validate` for the contract.
    let scoped_validation_warnings = match scoped_validate(&working) {
        Ok(ws) => ws,
        Err(err) => return error_response(err),
    };

    // Collect (path, comment) pairs from any op that supplied a non-None
    // comment. Applied after save() so the comment-preserving sync_table
    // pass doesn't strip them.
    let annotations: Vec<(String, String)> = ops
        .iter()
        .zip(results.iter())
        .filter_map(|(op, res)| op.comment.as_ref().map(|c| (res.path.clone(), c.clone())))
        .collect();

    // Collect non-fatal validation warnings against the post-save state
    // before working is moved into persist_and_swap. Same signal as
    // `zeroclaw_log::record!` from `validate()`, surfaced structured so dashboard
    // callers see it.
    let mut warnings = working.collect_warnings();
    warnings.extend(scoped_validation_warnings);
    // The batch's complete write set: every member's path classified by
    // effect against the configuration being replaced, `remove` pinned to
    // the removal it is. One unauthorized member refuses the whole batch
    // before anything is written.
    let before = state.config.read().clone();
    let mut writes = ConfigWriteSet::by_effect(
        &before,
        &working,
        working.dirty_paths.iter().map(String::as_str),
    );
    for op in ops.iter().filter(|op| op.op == "remove") {
        writes = writes.with(json_pointer_to_dotted(&op.path), Verb::Delete);
    }
    let authorization = match authorize_config_write(&principal, writes, &_cfg_guard) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };
    let mut agent_config_reservations = Vec::with_capacity(agent_aliases.len());
    for alias in agent_aliases {
        match state.agent_lifecycle.reserve_config_mutation(&alias) {
            Ok(reservation) => agent_config_reservations.push(reservation),
            Err(error) => {
                return error_response(
                    ConfigApiError::new(ConfigApiCode::ValidationFailed, error.to_string())
                        .with_path(format!("agents.{alias}")),
                );
            }
        }
    }
    let _cfg_guard = match persist_and_swap_retaining(
        &state,
        authorization,
        working,
        _cfg_guard,
        agent_config_reservations,
        annotations,
    )
    .await
    {
        Ok(guard) => guard,
        Err(error) => return error,
    };

    axum::Json(PatchResponse {
        saved: true,
        results,
        warnings,
    })
    .into_response()
}

fn json_pointer_to_dotted(path: &str) -> String {
    if path.starts_with('/') {
        path.trim_start_matches('/').replace('/', ".")
    } else {
        path.to_string()
    }
}

#[derive(Debug, Deserialize, Default)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct InitQuery {
    /// Optional section prefix to scope the init pass (e.g. `model_providers`).
    /// Without it, every uninitialized nested section gets its defaults.
    #[serde(default)]
    pub section: Option<String>,
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct InitResponse {
    pub initialized: Vec<String>,
}

/// POST /api/config/init?section=model_providers — instantiate `None` nested
/// sections with defaults, and only those: dynamic-map aliases are created
/// through `POST /api/config/map-key`. When every requested section is already
/// configured, returns `{initialized: []}`.
pub async fn handle_init(
    State(state): State<AppState>,
    principal: RequestPrincipal,
    Query(q): Query<InitQuery>,
) -> Response {
    let _cfg_guard = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let mut working = _cfg_guard.current_config();
    let initialized: Vec<String> = working
        .init_defaults(q.section.as_deref())
        .into_iter()
        .map(str::to_string)
        .collect();

    if initialized.is_empty() {
        return axum::Json(InitResponse { initialized }).into_response();
    }

    for section in &initialized {
        working.mark_dirty(section);
    }

    if let Err(err) = scoped_validate(&working) {
        return error_response(err);
    }
    // Initialization brings whole sections into being; each is a creation
    // in the write set.
    let before = state.config.read().clone();
    let writes = initialized.iter().fold(
        ConfigWriteSet::by_effect(
            &before,
            &working,
            working.dirty_paths.iter().map(String::as_str),
        ),
        |writes, section| writes.with(section.clone(), Verb::Create),
    );
    let authorization = match authorize_config_write(&principal, writes, &_cfg_guard) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };
    if let Err(e) = persist_and_swap(&state, authorization, working, _cfg_guard).await {
        return e;
    }

    axum::Json(InitResponse { initialized }).into_response()
}

#[derive(Debug, Serialize)]
#[cfg_attr(feature = "schema-export", derive(schemars::JsonSchema))]
pub struct MigrateResponse {
    pub migrated: bool,
    /// Backup path written when migration ran; absent when the config was
    /// already at the current schema version.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub backup_path: Option<String>,
    pub schema_version: u32,
    /// What the migration changed or assumed, one line each, as
    /// `zeroclaw config migrate` reports them: a retired key removed, or a
    /// missing `schema_version` read as V1 or V3. Key paths and reasons only,
    /// never values.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub notices: Vec<String>,
}

pub async fn handle_migrate(
    State(state): State<AppState>,
    principal: RequestPrincipal,
) -> Response {
    let commit = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(e) => return error_response(config_commit_admission_error(e)),
    };
    let authorization = match authorize_whole_config_write(&principal, &[Verb::Update], &commit) {
        Ok(authorization) => authorization,
        Err(denied) => return denied.into_response(),
    };
    let current = commit.current_config();
    let config_path = current.config_path.clone();
    let data_dir = current.data_dir.clone();
    // No reader guard survives the file reads; the commit retains serialization.

    let raw = match tokio::fs::read_to_string(&config_path).await {
        Ok(s) => s,
        Err(e) => {
            return error_response(ConfigApiError::new(
                ConfigApiCode::InternalError,
                format!("failed to read config file: {e}"),
            ));
        }
    };

    let migrated = match zeroclaw_config::migration::migrate_file_with_notices(&raw) {
        Ok(out) => out,
        Err(e) => {
            return error_response(ConfigApiError::new(
                ConfigApiCode::ValidationFailed,
                format!("migration failed: {e}"),
            ));
        }
    };

    match migrated {
        Some((new_content, notices)) => {
            // The `.bak` written below is replaced by the next save. Keep the
            // pre-upgrade original as well, once per version, as
            // `config migrate` and the save paths do.
            let from_version = toml::from_str::<toml::Value>(&raw)
                .ok()
                .and_then(|value| zeroclaw_config::migration::detect_version(&value).ok())
                .filter(|version| *version < zeroclaw_config::migration::CURRENT_SCHEMA_VERSION);
            let backup_path = config_path.with_extension("toml.bak");
            let parent = match config_path.parent() {
                Some(p) => p.to_path_buf(),
                None => {
                    return error_response(ConfigApiError::new(
                        ConfigApiCode::InternalError,
                        format!(
                            "config path has no parent: {}",
                            config_path.display().to_string()
                        ),
                    ));
                }
            };
            let file_name = match config_path.file_name().and_then(|n| n.to_str()) {
                Some(n) => n.to_string(),
                None => {
                    return error_response(ConfigApiError::new(
                        ConfigApiCode::InternalError,
                        format!(
                            "config path has no file name: {}",
                            config_path.display().to_string()
                        ),
                    ));
                }
            };
            let temp_path = parent.join(format!(".{file_name}.tmp-{}", uuid::Uuid::new_v4()));

            // Prepare the FULLY hydrated candidate BEFORE any disk
            // replacement: strict parse into the current schema, secrets
            // decrypted, env overrides applied, canonical config_path and
            // data_dir attached — exactly the config the next daemon
            // generation would load from the migrated file. A hydration
            // failure refuses the migration with the original file
            // untouched. There is no second save: the migrated file
            // written below IS the persisted config.
            let mut prepared = match zeroclaw_config::schema::Config::prepare_from_migrated_toml(
                &new_content,
                &config_path,
                &data_dir,
            )
            .await
            {
                Ok(config) => config,
                Err(e) => {
                    return error_response(ConfigApiError::new(
                        ConfigApiCode::ValidationFailed,
                        format!("migrated config failed to prepare: {e:#}"),
                    ));
                }
            };

            if let Err(e) = zeroclaw_runtime::rpc::auth::validate_accepted_auth_config(&prepared) {
                return error_response(ConfigApiError::new(
                    ConfigApiCode::ValidationFailed,
                    format!("authorization policy would not compile: {e}"),
                ));
            }
            // Checked revision before the irreversible replacement.
            let revision = match commit.next_revision() {
                Ok(revision) => revision,
                Err(e) => return error_response(config_commit_admission_error(e)),
            };

            // The replacement dance (temp write, backup, atomic rename)
            // plus the publication run retained on the admitted commit: a
            // dropped request cannot leave a replaced file without its
            // publication.
            let replace_config_path = config_path.clone();
            let replace_parent = parent.clone();
            let response_backup_path = backup_path.display().to_string();
            let pending_reload = Arc::clone(&state.pending_reload);
            let task = zeroclaw_runtime::live_config_authority::spawn_agent_lifecycle_job(
                Box::pin(async move {
                    // 1. Write migrated content to temp + fsync.
                    match tokio::fs::OpenOptions::new()
                        .create_new(true)
                        .write(true)
                        .open(&temp_path)
                        .await
                    {
                        Ok(mut temp) => {
                            use tokio::io::AsyncWriteExt;
                            if let Err(e) = temp.write_all(new_content.as_bytes()).await {
                                let _ = tokio::fs::remove_file(&temp_path).await;
                                return Err(ConfigApiError::new(
                                    ConfigApiCode::InternalError,
                                    format!("failed to write migrated config to temp: {e}"),
                                ));
                            }
                            if let Err(e) = temp.sync_all().await {
                                let _ = tokio::fs::remove_file(&temp_path).await;
                                return Err(ConfigApiError::new(
                                    ConfigApiCode::InternalError,
                                    format!("failed to fsync migrated config temp: {e}"),
                                ));
                            }
                        }
                        Err(e) => {
                            return Err(ConfigApiError::new(
                                ConfigApiCode::InternalError,
                                format!("failed to create temp config file: {e}"),
                            ));
                        }
                    }

                    // 2. Backup BEFORE replacing the original.
                    if let Some(version) = from_version
                        && let Err(e) = zeroclaw_config::schema::keep_pre_upgrade_backup(
                            &replace_config_path,
                            version,
                        )
                        .await
                    {
                        let _ = tokio::fs::remove_file(&temp_path).await;
                        return Err(ConfigApiError::new(
                            ConfigApiCode::InternalError,
                            format!("{e:#}"),
                        ));
                    }
                    if let Err(e) = tokio::fs::copy(&replace_config_path, &backup_path).await {
                        let _ = tokio::fs::remove_file(&temp_path).await;
                        return Err(ConfigApiError::new(
                            ConfigApiCode::InternalError,
                            format!("failed to write backup: {e}"),
                        ));
                    }

                    // 3. Atomic rename. On failure, restore from backup.
                    if let Err(e) = tokio::fs::rename(&temp_path, &replace_config_path).await {
                        let _ = tokio::fs::remove_file(&temp_path).await;
                        if backup_path.exists() {
                            let _ = tokio::fs::copy(&backup_path, &replace_config_path).await;
                        }
                        return Err(ConfigApiError::new(
                            ConfigApiCode::InternalError,
                            format!("failed to atomically replace config: {e}"),
                        ));
                    }

                    // 4. Fsync the parent directory so the rename is durable.
                    #[cfg(unix)]
                    if let Ok(dir) = tokio::fs::File::open(&replace_parent).await {
                        let _ = dir.sync_all().await;
                    }

                    // Publish the prepared candidate so subsequent requests
                    // observe the migrated state as one pair with its new
                    // revision. The disk replacement above is committed —
                    // it is not rolled back — and this publication is the
                    // same retained task, so the two cannot split.
                    // The prepared value now represents the file successfully replaced
                    // above, so later full saves retain that target's load provenance.
                    prepared.loaded_from = Some(replace_config_path.clone());
                    authorization.publish_persisted(&prepared);
                    commit
                        .publish(revision, prepared)
                        .map_err(config_commit_publish_error)?;
                    pending_reload.store(true, std::sync::atomic::Ordering::Relaxed);
                    Ok(())
                }),
            );
            match task.await {
                Ok(Ok(())) => {}
                Ok(Err(error)) => return error_response(error),
                Err(e) => {
                    return error_response(ConfigApiError::new(
                        ConfigApiCode::InternalError,
                        format!("config migrate task failed: {e}"),
                    ));
                }
            }

            axum::Json(MigrateResponse {
                migrated: true,
                backup_path: Some(response_backup_path),
                schema_version: zeroclaw_config::migration::CURRENT_SCHEMA_VERSION,
                notices: notices
                    .iter()
                    .map(zeroclaw_config::migration::MigrationNotice::message)
                    .collect(),
            })
            .into_response()
        }
        None => axum::Json(MigrateResponse {
            migrated: false,
            backup_path: None,
            schema_version: zeroclaw_config::migration::CURRENT_SCHEMA_VERSION,
            notices: Vec::new(),
        })
        .into_response(),
    }
}

pub async fn handle_options_config(headers: HeaderMap) -> Response {
    // CORS preflight short-circuit
    if headers.contains_key("access-control-request-method") {
        let mut response = StatusCode::NO_CONTENT.into_response();
        let h = response.headers_mut();
        h.insert(
            "Access-Control-Allow-Methods",
            HeaderValue::from_static("GET, PUT, PATCH, OPTIONS"),
        );
        h.insert(
            "Access-Control-Allow-Headers",
            HeaderValue::from_static("Authorization, Content-Type, If-None-Match"),
        );
        return response;
    }

    schema_response("zeroclaw_config_schema_full")
}

pub async fn handle_options_prop(
    State(state): State<AppState>,
    headers: HeaderMap,
    Query(q): Query<PropQuery>,
) -> Response {
    if headers.contains_key("access-control-request-method") {
        let mut response = StatusCode::NO_CONTENT.into_response();
        let h = response.headers_mut();
        h.insert(
            "Access-Control-Allow-Methods",
            HeaderValue::from_static("GET, PUT, DELETE, OPTIONS"),
        );
        h.insert(
            "Access-Control-Allow-Headers",
            HeaderValue::from_static("Authorization, Content-Type, If-None-Match"),
        );
        return response;
    }

    // Resolve the path against the in-memory config; 404 if it doesn't
    // exist. (No auth required for shape discovery — same as OPTIONS /api/config.)
    let config = state.config.read().clone();
    let info = match lookup_prop_field(&config, &q.path) {
        Some(info) => info,
        None => return error_response(ConfigApiError::path_not_found(&q.path)),
    };

    let (whole_body, etag) = cached_schema();
    let mut body = whole_body.clone();
    if let serde_json::Value::Object(ref mut map) = body {
        map.insert(
            "x-zeroclaw-requested-path".into(),
            serde_json::Value::String(q.path.clone()),
        );
        map.insert(
            "x-zeroclaw-prop".into(),
            serde_json::json!({
                "path": q.path,
                "kind": prop_kind_wire(info.kind),
                "type_hint": info.type_hint,
                "is_secret": info.is_secret || info.derived_from_secret,
                "enum_variants": info.enum_variants.map(|f| f()).unwrap_or_default(),
                "category": info.category,
            }),
        );
    }
    let mut response = (StatusCode::OK, axum::Json(body)).into_response();
    response.headers_mut().insert(
        header::ALLOW,
        HeaderValue::from_static("GET, PUT, DELETE, OPTIONS"),
    );
    insert_etag(&mut response, etag);
    response
}

fn schema_response(_label: &'static str) -> Response {
    let (body, etag) = cached_schema();
    let mut response = (StatusCode::OK, axum::Json(body.clone())).into_response();
    response.headers_mut().insert(
        header::ALLOW,
        HeaderValue::from_static("GET, PUT, PATCH, OPTIONS"),
    );
    insert_etag(&mut response, etag);
    response
}

fn insert_etag(response: &mut Response, etag: &str) {
    if let Ok(value) = HeaderValue::from_str(etag) {
        response.headers_mut().insert(header::ETAG, value);
    }
}

fn cached_schema() -> (&'static serde_json::Value, &'static str) {
    use std::sync::OnceLock;
    static CACHE: OnceLock<(serde_json::Value, String)> = OnceLock::new();
    let entry = CACHE.get_or_init(|| {
        let body = schema_body_value();
        let etag = build_etag_for(&body);
        (body, etag)
    });
    (&entry.0, entry.1.as_str())
}

#[cfg(feature = "schema-export")]
fn schema_body_value() -> serde_json::Value {
    let schema = schemars::schema_for!(zeroclaw_config::schema::Config);
    serde_json::to_value(schema).unwrap_or(serde_json::Value::Null)
}

#[cfg(not(feature = "schema-export"))]
fn schema_body_value() -> serde_json::Value {
    serde_json::json!({
        "error": "schema-export feature not enabled in this build",
    })
}

/// Stable ETag derived from the rendered schema bytes. Computed once via
/// `cached_schema()`; this helper is kept separate so tests can verify
/// determinism.
fn build_etag_for(body: &serde_json::Value) -> String {
    use std::hash::{Hash, Hasher};
    let bytes = body.to_string();
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    bytes.hash(&mut hasher);
    format!("\"{:016x}\"", hasher.finish())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{GatewayRateLimiter, IdempotencyStore, nodes};
    use async_trait::async_trait;
    use axum::http::StatusCode;
    use http_body_util::BodyExt;
    use std::time::Duration;
    use zeroclaw_providers::ModelProvider;
    use zeroclaw_runtime::security::pairing::PairingGuard;

    #[test]
    fn invalid_etag_value_is_omitted_instead_of_panicking() {
        let mut response = StatusCode::OK.into_response();
        insert_etag(&mut response, "invalid\nheader");
        assert!(!response.headers().contains_key(header::ETAG));
    }

    fn test_agent_rename_leases(
        state: &AppState,
        body: &RenameMapKeyBody,
    ) -> Vec<zeroclaw_runtime::live_config_authority::AgentDeleteLease> {
        let mut leases = vec![
            state
                .agent_lifecycle
                .begin_delete(body.from.clone())
                .unwrap(),
        ];
        if body.to != body.from {
            leases.push(state.agent_lifecycle.begin_delete(body.to.clone()).unwrap());
        }
        leases
    }

    fn test_agent_delete_lease(
        state: &AppState,
        alias: &str,
    ) -> zeroclaw_runtime::live_config_authority::AgentDeleteLease {
        state.agent_lifecycle.begin_delete(alias).unwrap()
    }

    // dirty_entry_for / CascadeReport::dirty_paths tests live in
    // zeroclaw_config::alias_refs — single source of truth (the gateway and CLI
    // both consume the promoted helper).

    #[derive(Default)]
    struct MockModelProvider;

    #[async_trait]
    impl ModelProvider for MockModelProvider {
        async fn chat_with_system(
            &self,
            _system_prompt: Option<&str>,
            _message: &str,
            _model: &str,
            _temperature: Option<f64>,
        ) -> anyhow::Result<String> {
            Ok("ok".into())
        }
    }

    impl ::zeroclaw_api::attribution::Attributable for MockModelProvider {
        fn role(&self) -> ::zeroclaw_api::attribution::Role {
            ::zeroclaw_api::attribution::Role::Provider(
                ::zeroclaw_api::attribution::ProviderKind::Model(
                    ::zeroclaw_api::attribution::ModelProviderKind::Custom,
                ),
            )
        }

        fn alias(&self) -> &str {
            "MockModelProvider"
        }
    }

    fn temp_config(tmp: &tempfile::TempDir) -> zeroclaw_config::schema::Config {
        let data_dir = tmp.path().join("data");
        std::fs::create_dir_all(&data_dir).unwrap();
        zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"),
            data_dir,
            ..Default::default()
        }
    }

    fn test_state(config: zeroclaw_config::schema::Config) -> AppState {
        let authority = zeroclaw_runtime::LiveConfigAuthority::new(config);
        test_state_from_authority(&authority)
    }

    fn test_state_from_authority(authority: &zeroclaw_runtime::LiveConfigAuthority) -> AppState {
        let memory: Arc<dyn zeroclaw_memory::Memory> =
            Arc::new(zeroclaw_memory::NoneMemory::new("api-config-test"));
        AppState {
            config: authority.live_handle(),
            config_authority: authority.clone(),
            agent_lifecycle: authority.agent_lifecycle(),
            model_provider: Arc::new(MockModelProvider),
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(
                zeroclaw_runtime::agent::memory_strategy::DefaultMemoryStrategy::with_config(
                    memory,
                    zeroclaw_config::schema::MemoryConfig::default(),
                    std::path::PathBuf::new(),
                ),
            ),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(
                false,
                &[],
                zeroclaw_config::pairing::PairingCodePolicy::default(),
            )),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(crate::auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: std::collections::HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: std::collections::HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: std::collections::HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: std::collections::HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: std::collections::HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: std::collections::HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(crate::sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: Arc::new(crate::session_queue::SessionActorQueue::new(8, 30, 600)),
            device_registry: None,
            canvas_store: zeroclaw_runtime::tools::CanvasStore::new(),
            #[cfg(feature = "webauthn")]
            webauthn: None,
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
        }
    }

    fn install_channel_generation_controls(
        state: &mut AppState,
        clear: Arc<dyn Fn() + Send + Sync>,
    ) -> tokio::sync::watch::Receiver<bool> {
        let (shutdown_tx, _) = tokio::sync::watch::channel(false);
        let (reload_tx, reload_rx) = tokio::sync::watch::channel(false);
        state.reload_tx = Some(
            zeroclaw_runtime::daemon::GatewayReloadControls::with_channel_generation(
                shutdown_tx,
                reload_tx,
                clear,
            ),
        );
        reload_rx
    }

    #[test]
    fn disabled_agent_binding_changes_channel_generation_projection() {
        let old = zeroclaw_config::schema::Config::default();
        let mut new = old.clone();
        new.agents.insert(
            "disabled-owner".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                enabled: false,
                channels: vec!["telegram.primary".into()],
                ..Default::default()
            },
        );

        assert_ne!(
            channel_generation_projection(&old),
            channel_generation_projection(&new),
            "disabled bindings still suppress legacy fallback routing"
        );
    }

    #[test]
    fn peer_group_changes_channel_generation_projection() {
        let old = zeroclaw_config::schema::Config::default();
        let mut new = old.clone();
        new.create_map_key("channels.telegram", "primary")
            .expect("create configured channel alias");
        zeroclaw_channels::orchestrator::bind_channel_identity_into(
            &mut new,
            "telegram",
            "primary",
            "123456789",
        )
        .expect("test peer group mutation");

        assert_ne!(
            channel_generation_projection(&old),
            channel_generation_projection(&new),
            "peer authorization is captured by the running channel generation"
        );
    }

    #[tokio::test]
    async fn channel_generation_is_not_retired_when_config_save_fails() {
        let tmp = tempfile::tempdir().unwrap();
        let config_path = tmp.path().join("config.toml");
        std::fs::create_dir_all(&config_path).unwrap();
        let mut config = temp_config(&tmp);
        config.config_path = config_path;
        let mut state = test_state(config.clone());
        let clears = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let clear_count = Arc::clone(&clears);
        let mut reload_rx = install_channel_generation_controls(
            &mut state,
            Arc::new(move || {
                clear_count.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            }),
        );
        let mut working = config;
        working.channels.cli = !working.channels.cli;
        working.mark_dirty("channels.cli");
        let guard = state.begin_config_commit().await.unwrap();

        let authorization =
            authorize_config_write(&None, ConfigWriteSet::default(), &guard).unwrap();
        assert!(
            persist_and_swap(&state, authorization, working, guard)
                .await
                .is_err()
        );
        assert_eq!(clears.load(std::sync::atomic::Ordering::SeqCst), 0);
        assert!(!*reload_rx.borrow_and_update());
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn unreadable_existing_config_survives_failed_save_rollback() {
        use std::os::unix::fs::PermissionsExt;

        let tmp = tempfile::tempdir().unwrap();
        let config_path = tmp.path().join("config.toml");
        let original = b"# original config bytes\n";
        std::fs::write(&config_path, original).unwrap();
        std::fs::set_permissions(&config_path, std::fs::Permissions::from_mode(0o000)).unwrap();

        let mut config = temp_config(&tmp);
        config.channels.cli = !config.channels.cli;
        config.mark_dirty("channels.cli");
        let state = test_state(config.clone());
        let guard = state.begin_config_commit().await.unwrap();
        let authorization =
            authorize_config_write(&None, ConfigWriteSet::default(), &guard).unwrap();
        let result = persist_and_swap(&state, authorization, config, guard).await;

        std::fs::set_permissions(&config_path, std::fs::Permissions::from_mode(0o600)).unwrap();
        assert!(
            result.is_err(),
            "the unreadable incremental source must fail"
        );
        assert_eq!(std::fs::read(&config_path).unwrap(), original);
    }

    #[tokio::test]
    async fn channel_generation_is_cleared_before_reload_is_signalled() {
        let tmp = tempfile::tempdir().unwrap();
        let config = temp_config(&tmp);
        let mut state = test_state(config.clone());
        let clears = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let clear_count = Arc::clone(&clears);
        let mut reload_rx = install_channel_generation_controls(
            &mut state,
            Arc::new(move || {
                clear_count.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            }),
        );
        let mut working = config;
        working.channels.cli = !working.channels.cli;
        working.mark_dirty("channels.cli");
        let guard = state.begin_config_commit().await.unwrap();

        let authorization =
            authorize_config_write(&None, ConfigWriteSet::default(), &guard).unwrap();
        let _guard = persist_and_swap(&state, authorization, working, guard)
            .await
            .unwrap();
        assert_eq!(clears.load(std::sync::atomic::Ordering::SeqCst), 1);
        assert!(!*reload_rx.borrow_and_update());
        tokio::time::timeout(std::time::Duration::from_secs(1), reload_rx.changed())
            .await
            .expect("reload must be signalled after the response flush delay")
            .unwrap();
        assert!(*reload_rx.borrow());
    }

    async fn response_json(response: Response) -> (StatusCode, serde_json::Value) {
        let status = response.status();
        let body = response
            .into_body()
            .collect()
            .await
            .expect("response body")
            .to_bytes();
        let json = serde_json::from_slice(&body).expect("valid json response");
        (status, json)
    }

    // Every config in this module must come from `temp_config`: the success-path
    // tests below fall through into real persistence (`persist_and_swap` ->
    // `save_dirty`), and a bare `Config::default()` would write the developer's
    // live `~/.zeroclaw/config.toml`.

    #[tokio::test]
    async fn config_application_reload_status_does_not_infer_adoption_from_flag_clearing() {
        use tower::ServiceExt;
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config.gateway.require_pairing = true;
        config.gateway.paired_tokens = vec!["zc_paired".into()];
        let mut state = test_state(config.clone());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &config.gateway.paired_tokens,
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        let auth = Arc::new(
            crate::principal_gate::GatewayInboundAuth::from_config(
                &config,
                Arc::clone(&state.pairing),
            )
            .unwrap(),
        );
        let router = crate::config_admin_router(crate::principal_gate::ConfigRouteAuth::new(
            &auth,
            &state.config,
        ))
        .with_state(state.clone());
        let read = || {
            axum::http::Request::builder()
                .uri("/api/config/reload-status")
                .header("authorization", "Bearer zc_paired")
                .body(axum::body::Body::empty())
                .unwrap()
        };
        let denied = router
            .clone()
            .oneshot(
                axum::http::Request::builder()
                    .uri("/api/config/reload-status")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(denied.status(), StatusCode::UNAUTHORIZED);
        let (status, initial) = response_json(router.clone().oneshot(read()).await.unwrap()).await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(initial["application"]["records"], serde_json::json!([]));
        let write = axum::http::Request::builder()
            .method("PUT")
            .uri("/api/config/prop")
            .header("authorization", "Bearer zc_paired")
            .header("content-type", "application/json")
            .body(axum::body::Body::from(
                r#"{"path":"gateway.port","value":42618}"#,
            ))
            .unwrap();
        let (status, _) = response_json(router.clone().oneshot(write).await.unwrap()).await;
        assert_eq!(status, StatusCode::OK);
        let (_, saved) = response_json(router.clone().oneshot(read()).await.unwrap()).await;
        assert_eq!(saved["pending_reload"], true);
        let records = saved["application"]["records"].as_array().unwrap();
        assert!(records.iter().any(|record| record["path"]
            == serde_json::json!(["gateway", "port"])
            && record["outcome"] == "queued_for_reload"));
        assert!(
            records
                .iter()
                .all(|record| record["target"]["kind"] == "daemon")
        );
        state
            .pending_reload
            .store(false, std::sync::atomic::Ordering::Relaxed);
        let (_, cleared) = response_json(router.oneshot(read()).await.unwrap()).await;
        assert_eq!(cleared["pending_reload"], false);
        assert_eq!(cleared["application"], saved["application"]);
    }

    #[tokio::test]
    async fn prop_get_surfaces_disabled_audit_warning() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config.security.audit.enabled = false;
        let state = test_state(config);

        let (status, json) = response_json(
            handle_prop_get(
                State(state),
                Query(PropQuery {
                    path: "security.audit.enabled".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert_eq!(json["value"], "false");
        let warning = json["warnings"]
            .as_array()
            .expect("warnings is an array")
            .iter()
            .find(|warning| warning["code"] == "security_audit_disabled_drops_certificate_record")
            .expect("gateway response includes the disabled-audit warning");
        assert_eq!(warning["path"], "security.audit.enabled");
        assert!(
            warning["message"]
                .as_str()
                .expect("warning message is a string")
                .contains("Command execution is not audited"),
            "the structured message must scope the gap to command execution"
        );
    }

    #[tokio::test]
    async fn prop_put_does_not_materialize_resource_keyed_rate_alias() {
        let tmp = tempfile::tempdir().unwrap();
        let state = test_state(temp_config(&tmp));
        let (status, json) = response_json(
            handle_prop_put(
                State(state.clone()),
                None,
                axum::Json(PropPutBody {
                    path: "cost.rates.providers.models.openai.gpt-5.input_per_mtok".to_string(),
                    value: serde_json::json!(1.5),
                    comment: None,
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::NOT_FOUND);
        assert_eq!(json["code"], "path_not_found");
        assert!(
            state
                .config
                .read()
                .cost
                .rates
                .providers
                .models
                .openai
                .is_empty()
        );
    }

    #[tokio::test]
    async fn prop_delete_refuses_agent_alias_under_destructive_lease_without_live_or_disk_mutation()
    {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config.create_map_key("agents", "blocked").unwrap();
        config
            .set_prop_persistent("agents.blocked.enabled", "true")
            .unwrap();
        config.save().await.unwrap();
        let state = test_state(config);
        let config_path = state.config.read().config_path.clone();
        let live_before = toml::to_string(&*state.config.read()).unwrap();
        let disk_before = std::fs::read(&config_path).unwrap();
        let _cleanup = test_agent_delete_lease(&state, "blocked");

        let (status, json) = response_json(
            handle_prop_delete(
                State(state.clone()),
                None,
                Query(PropQuery {
                    path: "agents.blocked.enabled".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(json["code"], "validation_failed");
        assert_eq!(
            toml::to_string(&*state.config.read()).unwrap(),
            live_before,
            "refused property DELETE must not change serialized live config"
        );
        assert_eq!(
            std::fs::read(&config_path).unwrap(),
            disk_before,
            "refused property DELETE must not change config.toml bytes"
        );
        assert!(state.config.read().agents["blocked"].enabled);
    }

    #[tokio::test]
    async fn prop_put_on_dotted_resource_id_does_not_plant_phantom_sibling() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config
            .create_map_key("cost.rates.providers.models.openai", "gpt-4.1")
            .unwrap();
        let state = test_state(config);
        let (status, _json) = response_json(
            handle_prop_put(
                State(state.clone()),
                None,
                axum::Json(PropPutBody {
                    path: "cost.rates.providers.models.openai.gpt-4.1.input_per_mtok".to_string(),
                    value: serde_json::json!(1.5),
                    comment: None,
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        // In-memory, not the saved TOML: a dotted map key never reaches disk
        // through the incremental dirty-path write, so a disk assertion would be
        // vacuous in both directions.
        assert_eq!(
            state
                .config
                .read()
                .get_map_keys("cost.rates.providers.models.openai")
                .expect("known section"),
            vec!["gpt-4.1".to_string()],
        );
    }

    #[tokio::test]
    async fn prop_put_still_materializes_operator_chosen_alias() {
        let tmp = tempfile::tempdir().unwrap();
        let state = test_state(temp_config(&tmp));
        // Secret path: the response envelope is `{path, populated}`, not `value`.
        let (status, _json) = response_json(
            handle_prop_put(
                State(state.clone()),
                None,
                axum::Json(PropPutBody {
                    path: "channels.telegram.newbot.bot_token".to_string(),
                    value: serde_json::json!("tok"),
                    comment: None,
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert!(state.config.read().channels.telegram.contains_key("newbot"));
    }

    #[tokio::test]
    async fn prop_put_cannot_recreate_agent_during_destructive_cleanup() {
        let tmp = tempfile::tempdir().unwrap();
        let state = test_state(temp_config(&tmp));
        let mut cleanup = state
            .agent_lifecycle
            .begin_delete("recreated")
            .expect("hold destructive cleanup lease");
        cleanup.commit_destructive_mutation();

        let (status, _json) = response_json(
            handle_prop_put(
                State(state.clone()),
                None,
                axum::Json(PropPutBody {
                    path: "agents.recreated.enabled".to_string(),
                    value: serde_json::json!(true),
                    comment: None,
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(!state.config.read().agents.contains_key("recreated"));
    }

    #[tokio::test]
    async fn patch_cannot_recreate_agent_during_destructive_cleanup() {
        let tmp = tempfile::tempdir().unwrap();
        let state = test_state(temp_config(&tmp));
        let mut cleanup = state
            .agent_lifecycle
            .begin_delete("recreated")
            .expect("hold destructive cleanup lease");
        cleanup.commit_destructive_mutation();

        let (status, _json) = response_json(
            handle_patch(
                State(state.clone()),
                None,
                HeaderMap::new(),
                axum::Json(serde_json::json!([{
                    "op": "add",
                    "path": "/agents/recreated/enabled",
                    "value": true,
                }])),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(!state.config.read().agents.contains_key("recreated"));
    }

    #[tokio::test]
    async fn map_key_create_cannot_recreate_agent_during_destructive_cleanup() {
        let tmp = tempfile::tempdir().unwrap();
        let state = test_state(temp_config(&tmp));
        let mut cleanup = state
            .agent_lifecycle
            .begin_delete("recreated")
            .expect("hold destructive cleanup lease");
        cleanup.commit_destructive_mutation();

        let (status, _json) = response_json(
            handle_map_key(
                State(state.clone()),
                None,
                Query(MapKeyQuery {
                    path: "agents".to_string(),
                    key: "recreated".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(!state.config.read().agents.contains_key("recreated"));
    }

    #[tokio::test]
    async fn authenticated_patch_route_rejects_masked_or_empty_secret_values_without_mutation() {
        use axum::body::Body;
        use axum::routing::patch;
        use tower::ServiceExt;

        let token = "patch-secret-test-token";
        for op in ["add", "replace"] {
            for value in [zeroclaw_config::traits::MASKED_SECRET, "****", ""] {
                let tmp = tempfile::tempdir().unwrap();
                let mut config = temp_config(&tmp);
                config.gateway.webhook_secret = Some("original-secret".into());
                config.save().await.unwrap();
                let disk_before = tokio::fs::read(&config.config_path).await.unwrap();
                let live_before = config.gateway.webhook_secret.clone();
                let mut state = test_state(config);
                state.pairing = Arc::new(PairingGuard::new(
                    true,
                    &[token.to_string()],
                    zeroclaw_config::pairing::PairingCodePolicy::default(),
                ));
                let app = axum::Router::new()
                    .route("/api/config", patch(handle_patch))
                    .with_state(state.clone());

                let (status, json) = response_json(
                    app.oneshot(
                        axum::http::Request::builder()
                            .method("PATCH")
                            .uri("/api/config")
                            .header(header::AUTHORIZATION, format!("Bearer {token}"))
                            .header(header::CONTENT_TYPE, "application/json")
                            .header("x-zeroclaw-override-drift", "true")
                            .body(Body::from(
                                serde_json::json!([{
                                    "op": op,
                                    "path": "/gateway/webhook_secret",
                                    "value": value,
                                }])
                                .to_string(),
                            ))
                            .unwrap(),
                    )
                    .await
                    .unwrap(),
                )
                .await;

                assert_eq!(status, StatusCode::BAD_REQUEST);
                assert_eq!(json["code"], "validation_failed");
                assert_eq!(json["path"], "gateway.webhook_secret");
                assert_eq!(json["op_index"], 0);
                let disk_path = state.config.read().config_path.clone();
                let disk_after = tokio::fs::read(disk_path).await.unwrap();
                assert_eq!(
                    disk_after, disk_before,
                    "rejected {op} value {value:?} must not change disk"
                );
                assert_eq!(
                    state.config.read().gateway.webhook_secret,
                    live_before,
                    "rejected {op} value {value:?} must not change live config"
                );
                assert!(
                    !state
                        .pending_reload
                        .load(std::sync::atomic::Ordering::Relaxed)
                );
            }
        }
    }

    /// The dashboard's migrate reports what it changed, as `config migrate`
    /// does, so an operator learns that a retired table was removed.
    #[tokio::test]
    async fn migration_reports_its_notices() {
        let tmp = tempfile::tempdir().unwrap();
        let config_path = tmp.path().join("config.toml");
        tokio::fs::write(
            &config_path,
            "schema_version = 3\n\n[security.nevis]\nenabled = true\n",
        )
        .await
        .unwrap();
        let state = test_state(zeroclaw_config::schema::Config {
            config_path: config_path.clone(),
            data_dir: tmp.path().join("data"),
            ..Default::default()
        });

        let (status, json) = response_json(handle_migrate(State(state), None).await).await;

        assert_eq!(status, StatusCode::OK);
        let notices = json["notices"].as_array().expect("notices are returned");
        assert!(
            notices.iter().any(|notice| notice
                .as_str()
                .is_some_and(|n| n.contains("security.nevis"))),
            "{json}"
        );
    }

    #[tokio::test]
    async fn migration_preserves_runtime_paths_and_publishes_schema_version() {
        let tmp = tempfile::tempdir().unwrap();
        let config_path = tmp.path().join("selected-config.toml");
        let data_dir = tmp.path().join("selected-data");
        let legacy = zeroclaw_config::migration::generate(
            2,
            &zeroclaw_config::migration::GenerateOptions::default(),
        )
        .unwrap();
        tokio::fs::write(&config_path, legacy).await.unwrap();
        let state = test_state(zeroclaw_config::schema::Config {
            config_path: config_path.clone(),
            data_dir: data_dir.clone(),
            ..Default::default()
        });

        let original = tokio::fs::read_to_string(&config_path).await.unwrap();
        let (status, json) = response_json(handle_migrate(State(state.clone()), None).await).await;

        assert_eq!(status, StatusCode::OK);
        assert_eq!(json["migrated"], true);
        assert_eq!(
            tokio::fs::read_to_string(tmp.path().join("selected-config.toml.v2.backup"))
                .await
                .unwrap(),
            original,
            "the pre-upgrade original is kept where the next save cannot replace it"
        );
        assert_eq!(
            state.config.read().config_path,
            config_path,
            "migration must retain the runtime-selected config path"
        );
        assert_eq!(
            state.config.read().data_dir,
            data_dir,
            "migration must retain the runtime-selected data directory"
        );
        assert!(
            state
                .pending_reload
                .load(std::sync::atomic::Ordering::Relaxed)
        );

        let raw = tokio::fs::read_to_string(&config_path).await.unwrap();
        let disk_value: toml::Value = toml::from_str(&raw).unwrap();
        let live_schema_version = state.config.read().schema_version;
        assert_eq!(
            live_schema_version,
            zeroclaw_config::migration::CURRENT_SCHEMA_VERSION,
            "migration must publish the upgraded schema version live"
        );
        assert_eq!(
            disk_value
                .get("schema_version")
                .and_then(toml::Value::as_integer),
            Some(i64::from(
                zeroclaw_config::migration::CURRENT_SCHEMA_VERSION
            ))
        );
    }

    /// Regression test for the lost-update race `persist_and_swap`
    /// callers must not reintroduce: a handler used to read-clone config,
    /// save the clone to disk (an `.await` with no lock held), then swap
    /// the clone back over live config wholesale. A write landed on the
    /// published config during that save window was silently erased by the
    /// swap.
    ///
    /// Drives `handle_prop_put` (a real `persist_and_swap` caller) with
    /// an admitted config commit held externally. A single Pending poll
    /// wouldn't distinguish "blocked on commit admission" from
    /// "transiently Pending on unrelated I/O", so this polls the handler
    /// repeatedly with a no-op waker while the commit stays admitted and
    /// asserts it never completes -- proving it stays parked on the
    /// daemon-wide writer serialization, not that it merely yielded once.
    /// Only after the external commit publishes and releases does the
    /// concurrent write become visible to the handler's own read, so both
    /// changes land instead of one clobbering the other.
    #[tokio::test]
    async fn config_commit_serializes_prop_put_against_concurrent_writer() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = test_state(temp_config(&tmp));

        // Simulate another in-flight config commit already holding the
        // daemon-wide writer serialization for its own
        // read-mutate-save-publish section.
        let held_commit = state.begin_config_commit().await.unwrap();

        let mut handler_fut = Box::pin(handle_prop_put(
            State(state.clone()),
            None,
            axum::Json(PropPutBody {
                path: "channels.telegram.newbot.bot_token".to_string(),
                value: serde_json::json!("tok"),
                comment: None,
            }),
        ));

        // Bounded, sleep-free: poll with a no-op waker 50 times while
        // `held_commit` stays live and assert Pending every time. The
        // handler must not race ahead of an externally admitted commit no
        // matter how many times it's polled.
        let waker = std::task::Waker::noop();
        let mut cx = std::task::Context::from_waker(waker);
        for _ in 0..50 {
            assert!(
                std::future::Future::poll(handler_fut.as_mut(), &mut cx).is_pending(),
                "handle_prop_put must stay parked on config commit admission \
                 for as long as another writer holds the serialization, not \
                 race ahead to read a stale config"
            );
        }

        // The concurrent writer's own publication: it holds the same
        // serialization, so it lands before the parked handler proceeds.
        let mut concurrent = held_commit.current_config();
        concurrent.gateway.port = 55555;
        let revision = held_commit.next_revision().unwrap();
        held_commit.publish(revision, concurrent).unwrap();
        drop(held_commit);

        let response = handler_fut.await;
        assert_eq!(response.status(), StatusCode::OK);

        let live = state.config.read();
        assert_eq!(
            live.gateway.port, 55555,
            "the concurrent writer's change must survive — no lost update"
        );
        assert!(
            live.channels.telegram.contains_key("newbot"),
            "handle_prop_put's own change must also land"
        );
    }

    async fn assert_cancelled_prop_save_blocks_generation_handoff(
        path: &str,
        value: serde_json::Value,
        expected_value: &str,
        expected_alias_reservation: Option<&str>,
    ) {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config.gateway.port = 41_000;
        config.agents.insert(
            "alpha".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                enabled: true,
                ..Default::default()
            },
        );
        config.save().await.unwrap();
        let config_path = config.config_path.clone();
        let authority = zeroclaw_runtime::LiveConfigAuthority::new_owned(config).unwrap();
        let state = test_state_from_authority(&authority);
        let gate = test_pre_save_pause_gate::arm(config_path.clone());
        let task_state = state.clone();
        let task_path = path.to_string();

        let request = zeroclaw_spawn::spawn!(handle_prop_put(
            State(task_state),
            None,
            axum::Json(PropPutBody {
                path: task_path,
                value,
                comment: None,
            }),
        ));
        tokio::time::timeout(Duration::from_secs(1), gate.wait_paused())
            .await
            .expect("real property save must reach the pre-replace pause");

        request.abort();
        let _ = request.await;
        if let Some(alias) = expected_alias_reservation {
            assert_eq!(
                state.agent_lifecycle.begin_delete(alias).err(),
                Some(
                    zeroclaw_runtime::live_config_authority::AgentDeleteBlocker::Reservations {
                        alias: alias.to_string(),
                        count: 1,
                    }
                ),
                "request cancellation must not release the agent reservation owned by the save"
            );
        }

        let mut drain = Box::pin(authority.drain_agent_lifecycle_retaining_ownership());
        assert!(
            tokio::time::timeout(Duration::from_millis(50), drain.as_mut())
                .await
                .is_err(),
            "generation ownership must not transfer while the retained save is paused"
        );
        assert_eq!(
            state.agent_lifecycle.reserve_config_write().err(),
            Some(zeroclaw_runtime::live_config_authority::AgentAdmissionError::GenerationClosing),
            "a closing generation must refuse another config writer"
        );

        gate.release();
        tokio::time::timeout(Duration::from_secs(1), drain.as_mut())
            .await
            .expect("generation drain must finish after persistence and publication");
        let ownership = authority
            .take_process_ownership()
            .expect("reload drain must retain process ownership for its successor");

        assert_eq!(state.config.read().get_prop(path).unwrap(), expected_value);
        let written = tokio::fs::read_to_string(&config_path).await.unwrap();
        let persisted = zeroclaw_config::migration::migrate_to_current(&written).unwrap();
        assert_eq!(persisted.get_prop(path).unwrap(), expected_value);
        let successor =
            zeroclaw_runtime::LiveConfigAuthority::new_with_ownership(persisted, ownership);
        assert_eq!(
            successor.live_handle().read().get_prop(path).unwrap(),
            expected_value
        );
    }

    #[tokio::test]
    async fn cancelled_prop_saves_block_generation_handoff_until_publication() {
        assert_cancelled_prop_save_blocks_generation_handoff(
            "agents.alpha.enabled",
            serde_json::json!(false),
            "false",
            Some("alpha"),
        )
        .await;
        assert_cancelled_prop_save_blocks_generation_handoff(
            "gateway.port",
            serde_json::json!(41_001),
            "41001",
            None,
        )
        .await;
    }

    #[tokio::test]
    async fn http_annotations_retain_commit_through_whole_file_rewrite() {
        for patch in [false, true] {
            let tmp = tempfile::tempdir().unwrap();
            let mut config = temp_config(&tmp);
            config.gateway.host = "127.0.0.2".into();
            config.save().await.unwrap();
            let config_path = config.config_path.clone();
            let state = test_state(config);
            let mut gate =
                zeroclaw_config::comment_writer::test_post_read_pause::arm(config_path.clone());
            let writer_state = state.clone();
            let writer = zeroclaw_spawn::spawn!(async move {
                if patch {
                    handle_patch(
                        State(writer_state),
                        None,
                        HeaderMap::new(),
                        axum::Json(serde_json::json!([{
                            "op": "comment",
                            "path": "/gateway/host",
                            "comment": "annotation overlap",
                        }])),
                    )
                    .await
                } else {
                    handle_prop_put(
                        State(writer_state),
                        None,
                        axum::Json(PropPutBody {
                            path: "gateway.host".into(),
                            value: serde_json::json!("127.0.0.2"),
                            comment: Some("annotation overlap".into()),
                        }),
                    )
                    .await
                }
            });
            tokio::time::timeout(std::time::Duration::from_secs(5), gate.wait_paused())
                .await
                .expect("HTTP annotation must reach the post-read pause");

            // Admission itself must park, not just a later asynchronous save.
            let next_commit = state.begin_config_commit();
            tokio::pin!(next_commit);
            let waker = std::task::Waker::noop();
            let mut cx = std::task::Context::from_waker(waker);
            assert!(std::future::Future::poll(next_commit.as_mut(), &mut cx).is_pending());
            assert!(state.config_authority.config_write_lock_is_held());

            gate.release();
            let response = tokio::time::timeout(std::time::Duration::from_secs(5), writer)
                .await
                .unwrap()
                .unwrap();
            assert_eq!(response.status(), StatusCode::OK);
            assert!(
                tokio::fs::read_to_string(&config_path)
                    .await
                    .unwrap()
                    .contains("# annotation overlap")
            );
            let commit = next_commit.await.unwrap();
            let mut later = commit.current_config();
            later
                .set_prop_persistent("gateway.websocket_ping_interval_secs", "45")
                .unwrap();
            let authorization =
                authorize_config_write(&None, ConfigWriteSet::default(), &commit).unwrap();
            persist_and_swap(&state, authorization, later, commit)
                .await
                .unwrap();

            assert_eq!(state.config.read().gateway.websocket_ping_interval_secs, 45);
            let raw = tokio::fs::read_to_string(&config_path).await.unwrap();
            let disk: toml::Value = toml::from_str(&raw).unwrap();
            assert_eq!(
                disk["gateway"]["websocket_ping_interval_secs"].as_integer(),
                Some(45)
            );
            assert!(raw.contains("# annotation overlap"));
        }
    }

    /// Real cross-surface composition: ONE shared `LiveConfigAuthority`
    /// behind BOTH transports, wired exactly as the daemon wires them —
    /// the gateway's `AppState` and the local-RPC `RpcContext` receive
    /// clones of the same authority. One actual HTTP mutation
    /// (`handle_prop_put`) and one actual RPC write (`config/set` driven
    /// through the real local-RPC listener and client, `initialize`
    /// handshake included) both persist and publish; afterwards both
    /// changes are live in the one published pair and both are on disk.
    /// The authority-level parking/serialization behavior is proven by
    /// `config_commit_serializes_prop_put_against_concurrent_writer` and
    /// the RPC-side blocking tests in `dispatch.rs`.
    #[cfg(unix)]
    #[tokio::test]
    async fn http_and_rpc_writers_compose_on_one_shared_authority() {
        let tmp = tempfile::TempDir::new().unwrap();
        let config = temp_config(&tmp);
        let config_path = config.config_path.clone();
        let state = test_state(config.clone());

        // The daemon hands this exact authority to both transports: the
        // HTTP AppState already carries it, and the local-RPC context
        // below shares the same publication domain.
        let authority = state.config_authority.clone();
        assert!(
            authority.live_handle().same_storage(&state.config),
            "AppState's handle and the shared authority must observe one storage"
        );

        // Real local-RPC server: a context sharing the authority, the
        // actual listener loop, and later the actual client handshake.
        let session_queue = std::sync::Arc::new(
            zeroclaw_infra::session_queue::SessionActorQueue::new(4, 10, 60),
        );
        let sessions = std::sync::Arc::new(zeroclaw_runtime::rpc::session::SessionStore::new(
            16,
            session_queue,
        ));
        let ctx = zeroclaw_runtime::rpc::context::RpcContext::for_authority(&authority, sessions);
        let cancel = tokio_util::sync::CancellationToken::new();
        let server_cancel = cancel.clone();
        let client_count = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let server = zeroclaw_spawn::spawn!(async move {
            zeroclaw_runtime::rpc::local::run_local_listener(ctx, server_cancel, client_count, None)
                .await
        });
        let sock_path = zeroclaw_runtime::rpc::local::socket_path(&config);
        for _ in 0..50 {
            if sock_path.exists() {
                break;
            }
            tokio::time::sleep(std::time::Duration::from_millis(20)).await;
        }
        assert!(
            sock_path.exists(),
            "local RPC socket must appear at {}",
            sock_path.display()
        );

        // One actual HTTP mutation through the real handler.
        let response = handle_prop_put(
            State(state.clone()),
            None,
            axum::Json(PropPutBody {
                path: "channels.telegram.reloader.bot_token".to_string(),
                value: serde_json::json!("http-token"),
                comment: None,
            }),
        )
        .await;
        assert_eq!(response.status(), StatusCode::OK);

        // One actual RPC write through the real transport (initialize
        // handshake + config/set).
        let value = zeroclaw_runtime::rpc::local::call_local(
            &config,
            "config/set",
            serde_json::json!({
                "prop": "gateway.websocket_ping_interval_secs",
                "value": "45",
            }),
        )
        .await
        .expect("local config/set must succeed over the real transport");

        cancel.cancel();
        server.await.unwrap().unwrap();
        let _ = value;

        // Both changes are live in the ONE published pair.
        let live = state.config.read();
        assert_eq!(
            live.channels
                .telegram
                .get("reloader")
                .map(|tg| tg.bot_token.as_str()),
            Some("http-token"),
            "the HTTP writer's change must be live in the published pair"
        );
        assert_eq!(
            live.gateway.websocket_ping_interval_secs, 45,
            "the RPC writer's change must be live in the published pair"
        );
        // ...and both persisted to the one config file.
        let on_disk = std::fs::read_to_string(&config_path).unwrap();
        let persisted: toml::Value = toml::from_str(&on_disk).unwrap();
        let stored_token = persisted["channels"]["telegram"]["reloader"]["bot_token"]
            .as_str()
            .unwrap();
        assert!(
            zeroclaw_config::secrets::SecretStore::is_encrypted(stored_token),
            "the HTTP writer's token must be encrypted on disk"
        );
        let store = zeroclaw_config::secrets::SecretStore::new(
            config_path.parent().unwrap(),
            config.secrets.encrypt,
        );
        assert_eq!(
            store.decrypt(stored_token).unwrap(),
            "http-token",
            "the HTTP writer's persisted token must survive the RPC write"
        );
        assert_eq!(
            persisted["gateway"]["websocket_ping_interval_secs"].as_integer(),
            Some(45),
            "the RPC writer's change must be on disk:\n{on_disk}"
        );
    }

    /// Migration refusal on a candidate that cannot hydrate: a v1 config
    /// whose secret was encrypted with a DIFFERENT install's key parses
    /// and migrates at the TOML level, but hydration (secret decryption
    /// through THIS install's store) fails. The migration must be refused
    /// BEFORE any disk replacement: the original file is byte-identical,
    /// no backup was written, no temp file remains, and the published
    /// pair (config AND revision) is unchanged.
    #[tokio::test]
    async fn migrate_refuses_an_unhydratable_candidate_before_replacement() {
        // A v1 fixture whose secret fields are encrypted against a
        // throwaway key store this install does not share.
        let keystore = tempfile::TempDir::new().unwrap();
        let v1 = zeroclaw_config::migration::generate(
            1,
            &zeroclaw_config::migration::GenerateOptions {
                encrypt_secrets: true,
                secret_store_dir: Some(keystore.path()),
            },
        )
        .expect("v1 fixture generation with encryption must succeed");
        assert!(
            v1.contains("enc2:"),
            "the generated fixture must carry encrypted secret material"
        );

        let install = tempfile::TempDir::new().unwrap();
        let config_path = install.path().join("config.toml");
        std::fs::write(&config_path, v1.as_bytes()).unwrap();
        let original = std::fs::read(&config_path).unwrap();

        let state = test_state(temp_config(&install));
        let revision_before = state.config.revision();

        let (status, body) = response_json(
            handle_migrate(State(state.clone()), None)
                .await
                .into_response(),
        )
        .await;

        assert_eq!(
            status,
            StatusCode::BAD_REQUEST,
            "an unhydratable migrated candidate must be refused, not applied: {body}"
        );
        assert_eq!(body["code"], "validation_failed");
        // The original file is untouched — no replacement happened.
        assert_eq!(
            std::fs::read(&config_path).unwrap(),
            original,
            "the original config file must be byte-identical after refusal"
        );
        // No backup and no temp residue: neither reaches disk before the
        // prepared candidate is accepted.
        assert!(
            !config_path.with_extension("toml.bak").exists(),
            "no backup may be written before the candidate is accepted"
        );
        assert!(
            !install.path().join("config.toml.v1.backup").exists(),
            "nor the lasting pre-upgrade copy"
        );
        let residue: Vec<std::ffi::OsString> = std::fs::read_dir(install.path())
            .unwrap()
            .filter_map(|entry| entry.ok())
            .map(|entry| entry.file_name())
            .filter(|name| name.to_string_lossy().starts_with(".config.toml.tmp-"))
            .collect();
        assert!(
            residue.is_empty(),
            "no temp migration file may remain after refusal: {residue:?}"
        );
        // The published pair is unchanged.
        assert_eq!(
            state.config.revision(),
            revision_before,
            "the published revision must not advance on a refused migration"
        );
        assert!(
            !state.config.read().agents.contains_key("migrated"),
            "the published config must be the pre-migration pair"
        );
    }

    /// Migration refusal on a candidate that parses and hydrates but
    /// fails STRICT validation: a v1 body carrying an insane cost rate
    /// (`input_per_mtok = -1`, rejected by `Config::validate()`'s
    /// hard-failure range check). The migrated content parses into the
    /// current schema and hydrates fully — the refusal comes from
    /// validation, which for migration acceptance is stricter than
    /// resilient boot. The original file, backup state, and published
    /// pair must all remain unchanged.
    #[tokio::test]
    async fn migrate_refuses_a_parsed_but_invalid_candidate_before_replacement() {
        // A valid, unencrypted v1 body; migration acceptance is tested,
        // not secret hydration.
        let v1 = zeroclaw_config::migration::generate(
            1,
            &zeroclaw_config::migration::GenerateOptions::default(),
        )
        .expect("v1 fixture generation must succeed");

        // Append an insane model cost rate under a known provider slot.
        // The migration chain leaves `cost.rates.*` untouched, so the
        // migrated content parses cleanly and only strict validation
        // rejects it.
        let v1 = format!(
            "{v1}\n[cost.rates.providers.models.openrouter.default]\ninput_per_mtok = -1.0\n"
        );

        let install = tempfile::TempDir::new().unwrap();
        let config_path = install.path().join("config.toml");
        std::fs::write(&config_path, v1.as_bytes()).unwrap();
        let original = std::fs::read(&config_path).unwrap();

        let state = test_state(temp_config(&install));
        let revision_before = state.config.revision();

        let (status, body) = response_json(
            handle_migrate(State(state.clone()), None)
                .await
                .into_response(),
        )
        .await;

        assert_eq!(
            status,
            StatusCode::BAD_REQUEST,
            "a parsed but invalid migrated candidate must be refused, not applied: {body}"
        );
        assert_eq!(body["code"], "validation_failed");
        assert!(
            body["message"]
                .as_str()
                .is_some_and(|message| message.contains("strict validation")),
            "the refusal must come from strict validation, not parse or hydration: {body}"
        );
        // The original file is untouched — no replacement happened.
        assert_eq!(
            std::fs::read(&config_path).unwrap(),
            original,
            "the original config file must be byte-identical after refusal"
        );
        // No backup and no temp residue.
        assert!(
            !config_path.with_extension("toml.bak").exists(),
            "no backup may be written before the candidate is accepted"
        );
        let residue: Vec<std::ffi::OsString> = std::fs::read_dir(install.path())
            .unwrap()
            .filter_map(|entry| entry.ok())
            .map(|entry| entry.file_name())
            .filter(|name| name.to_string_lossy().starts_with(".config.toml.tmp-"))
            .collect();
        assert!(
            residue.is_empty(),
            "no temp migration file may remain after refusal: {residue:?}"
        );
        // The published pair is unchanged.
        assert_eq!(
            state.config.revision(),
            revision_before,
            "the published revision must not advance on a refused migration"
        );
    }

    #[tokio::test]
    async fn patch_add_does_not_materialize_resource_keyed_rate_alias() {
        let tmp = tempfile::tempdir().unwrap();
        let config = temp_config(&tmp);
        // `compute_drift` reads the on-disk file, so it has to exist.
        config.save().await.unwrap();
        let state = test_state(config);
        let (status, json) = response_json(
            handle_patch(
                State(state.clone()),
                None,
                HeaderMap::new(),
                axum::Json(serde_json::json!([{
                    "op": "add",
                    "path": "/cost/rates/providers/models/openai/gpt-5/input_per_mtok",
                    "value": 1.5
                }])),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::NOT_FOUND);
        assert_eq!(json["code"], "path_not_found");
        assert!(
            state
                .config
                .read()
                .cost
                .rates
                .providers
                .models
                .openai
                .is_empty()
        );
    }

    /// Enabling an opt-in tool through the config API follows the build. A
    /// build without Microsoft 365 saves the section without its credentials
    /// and says once that the tool is compiled out; a build with it still
    /// refuses the section until its credentials are set.
    #[tokio::test]
    async fn patch_enabling_an_opt_in_tool_follows_whether_the_build_carries_it() {
        use zeroclaw_config::opt_in_tools::OptInTool;
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        // `[web_search]` defaults to enabled and reports its own
        // tool_compiled_out line in lean builds; this test counts the
        // microsoft365 warning only.
        config.web_search.enabled = false;
        config.save().await.unwrap();
        let state = test_state(config);
        let (status, json) = response_json(
            handle_patch(
                State(state.clone()),
                None,
                HeaderMap::new(),
                axum::Json(serde_json::json!([{
                    "op": "replace",
                    "path": "/microsoft365/enabled",
                    "value": true
                }])),
            )
            .await,
        )
        .await;

        if OptInTool::Microsoft365.compiled() {
            assert_ne!(status, StatusCode::OK, "{json}");
            assert!(
                json.to_string().contains("microsoft365.tenant_id"),
                "{json}"
            );
            assert!(!state.config.read().microsoft365.enabled);
        } else {
            assert_eq!(status, StatusCode::OK, "{json}");
            assert_eq!(json["saved"], true);
            assert!(state.config.read().microsoft365.enabled);
            let compiled_out: Vec<_> = json["warnings"]
                .as_array()
                .expect("warnings is an array")
                .iter()
                .filter(|warning| warning["code"] == "tool_compiled_out")
                .collect();
            assert_eq!(compiled_out.len(), 1, "{json}");
            assert_eq!(compiled_out[0]["path"], "microsoft365.enabled");
        }
    }

    /// A string that `str::parse` reads as infinity or NaN is refused for a
    /// float field with the field named, the whole patch is refused (an
    /// earlier op in it is not applied), and the stored values are unchanged
    /// in memory and on disk. A finite string still stores. Covers a plain
    /// float (`memory.vector_weight`) and an optional one
    /// (`runtime.docker.cpu_limit`).
    #[tokio::test]
    async fn patch_refuses_non_finite_float_text_and_keeps_the_stored_value() {
        let tmp = tempfile::tempdir().unwrap();
        let config = temp_config(&tmp);
        config.save().await.unwrap();
        let config_path = config.config_path.clone();
        let saved = std::fs::read_to_string(&config_path).unwrap();
        let (vector_weight, keyword_weight, cpu_limit) = (
            config.memory.vector_weight,
            config.memory.keyword_weight,
            config.runtime.docker.cpu_limit,
        );
        let state = test_state(config);
        let patch = |ops: serde_json::Value| {
            let state = state.clone();
            async move {
                response_json(
                    handle_patch(State(state), None, HeaderMap::new(), axum::Json(ops)).await,
                )
                .await
            }
        };

        for text in [
            "inf", "+inf", "-inf", "Infinity", "infinity", "NaN", "nan", "1e999", "-1e999",
        ] {
            for (pointer, prop) in [
                ("/memory/vector_weight", "memory.vector_weight"),
                ("/runtime/docker/cpu_limit", "runtime.docker.cpu_limit"),
            ] {
                let (status, json) = patch(serde_json::json!([
                    {"op": "replace", "path": "/memory/keyword_weight", "value": 0.5},
                    {"op": "replace", "path": pointer, "value": text}
                ]))
                .await;
                assert_eq!(status, StatusCode::BAD_REQUEST, "{text} {prop}: {json}");
                assert_eq!(json["code"], "value_type_mismatch", "{text} {prop}: {json}");
                assert_eq!(json["path"], prop, "{text}: {json}");
                assert_eq!(json["op_index"], 1, "{text} {prop}: {json}");
                {
                    let live = state.config.read();
                    assert_eq!(
                        live.memory.vector_weight.to_bits(),
                        vector_weight.to_bits(),
                        "{text} {prop}"
                    );
                    assert_eq!(
                        live.memory.keyword_weight.to_bits(),
                        keyword_weight.to_bits(),
                        "{text} {prop}"
                    );
                    assert_eq!(live.runtime.docker.cpu_limit, cpu_limit, "{text} {prop}");
                }
                assert_eq!(
                    std::fs::read_to_string(&config_path).unwrap(),
                    saved,
                    "{text} {prop}"
                );
            }
        }

        let (status, json) = patch(serde_json::json!([
            {"op": "replace", "path": "/memory/vector_weight", "value": "0.6"},
            {"op": "replace", "path": "/runtime/docker/cpu_limit", "value": "2.5"}
        ]))
        .await;
        assert_eq!(status, StatusCode::OK, "{json}");
        assert_eq!(state.config.read().memory.vector_weight, 0.6);
        assert_eq!(state.config.read().runtime.docker.cpu_limit, Some(2.5));
        let written = std::fs::read_to_string(&config_path).unwrap();
        assert!(written.contains("vector_weight = 0.6"), "{written}");
        assert!(written.contains("cpu_limit = 2.5"), "{written}");
    }

    /// `energy_threshold` is an `f32`. `1e39` is finite as an `f64`, so it
    /// passes coercion, but the field would store infinity. As a JSON string
    /// or a JSON number it is refused with the same code as other text that
    /// is not a usable number, and the stored value is kept.
    #[tokio::test]
    async fn patch_refuses_a_value_too_large_for_an_f32_field() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config.channels.voice_wake.insert(
            "test".to_string(),
            zeroclaw_config::schema::VoiceWakeConfig::default(),
        );
        config.save().await.unwrap();
        let before = config.channels.voice_wake["test"].energy_threshold;
        let state = test_state(config);

        for value in [serde_json::json!("1e39"), serde_json::json!(1e39)] {
            let (status, json) = response_json(
                handle_patch(
                    State(state.clone()),
                    None,
                    HeaderMap::new(),
                    axum::Json(serde_json::json!([{
                        "op": "replace",
                        "path": "/channels/voice_wake/test/energy_threshold",
                        "value": value
                    }])),
                )
                .await,
            )
            .await;
            assert_eq!(status, StatusCode::BAD_REQUEST, "{value}: {json}");
            assert_eq!(json["code"], "value_type_mismatch", "{value}: {json}");
            assert_eq!(
                json["path"], "channels.voice_wake.test.energy_threshold",
                "{value}: {json}"
            );
            assert_eq!(
                state.config.read().channels.voice_wake["test"]
                    .energy_threshold
                    .to_bits(),
                before.to_bits(),
                "{value}"
            );
        }
    }

    #[tokio::test]
    async fn patch_allow_from_deny_all_persists_and_reloads_tool_policy() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config.risk_profiles.insert(
            "default".to_string(),
            zeroclaw_config::schema::RiskProfileConfig {
                deny_all_tools: true,
                ..Default::default()
            },
        );
        config.save().await.unwrap();

        let state = test_state(config);
        let (status, json) = response_json(
            handle_patch(
                State(state),
                None,
                HeaderMap::new(),
                axum::Json(serde_json::json!([
                    {
                        "op": "replace",
                        "path": "/risk_profiles/default/allowed_tools",
                        "value": ["shell"]
                    },
                    {
                        "op": "replace",
                        "path": "/risk_profiles/default/deny_all_tools",
                        "value": false
                    }
                ])),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert_eq!(json["saved"], true);

        let written = std::fs::read_to_string(tmp.path().join("config.toml")).unwrap();
        let reloaded = zeroclaw_config::migration::migrate_to_current(&written).unwrap();
        let profile = reloaded.risk_profiles.get("default").unwrap();
        assert_eq!(profile.allowed_tools, vec!["shell"]);
        assert!(!profile.deny_all_tools);

        let policy =
            zeroclaw_config::policy::SecurityPolicy::from_profiles(profile, None, tmp.path());
        assert!(policy.is_tool_allowed("shell"));
        assert!(!policy.is_tool_allowed("memory_recall"));
    }

    #[tokio::test]
    async fn delete_map_key_handler_cascades_model_provider_and_persists() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config
            .providers
            .models
            .ensure("anthropic", "default")
            .unwrap();
        config
            .providers
            .models
            .ensure("openai", "main")
            .unwrap()
            .fallback = vec!["anthropic.default".into()];
        config.agents.insert(
            "triage".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                classifier_provider: "anthropic.default".into(),
                ..Default::default()
            },
        );
        config.save().await.unwrap();

        let state = test_state(config);
        let (status, json) = response_json(
            handle_delete_map_key(
                axum::extract::State(state.clone()),
                None,
                axum::extract::Query(MapKeyQuery {
                    path: "providers.models.anthropic".to_string(),
                    key: "default".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert_eq!(json["path"], "providers.models.anthropic");
        assert_eq!(json["key"], "default");
        let cfg = state.config.read();
        assert!(cfg.providers.models.find("anthropic", "default").is_none());
        assert!(cfg.agents["triage"].classifier_provider.is_empty());
        assert!(
            cfg.providers
                .models
                .find("openai", "main")
                .unwrap()
                .fallback
                .is_empty()
        );
        drop(cfg);
        let written = std::fs::read_to_string(tmp.path().join("config.toml")).unwrap();
        assert!(!written.contains("anthropic.default"));
    }

    #[tokio::test]
    async fn delete_map_key_handler_refuses_model_provider_hard_ref_without_mutation() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config
            .providers
            .models
            .ensure("anthropic", "default")
            .unwrap();
        config.agents.insert(
            "researcher".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                model_provider: "anthropic.default".into(),
                ..Default::default()
            },
        );
        config.save().await.unwrap();

        let state = test_state(config);
        let (status, json) = response_json(
            handle_delete_map_key(
                axum::extract::State(state.clone()),
                None,
                axum::extract::Query(MapKeyQuery {
                    path: "providers.models.anthropic".to_string(),
                    key: "default".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(json["code"], "validation_failed");
        let cfg = state.config.read();
        assert!(cfg.providers.models.find("anthropic", "default").is_some());
        assert_eq!(
            cfg.agents["researcher"].model_provider.as_str(),
            "anthropic.default"
        );
    }

    #[tokio::test]
    async fn delete_map_key_handler_cascades_channel_and_persists() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config.create_map_key("channels.discord", "main").unwrap();
        config.agents.insert(
            "ops".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                channels: vec!["discord.main".into()],
                ..Default::default()
            },
        );
        config
            .escalation
            .alert_channels
            .push("discord.main".to_string());
        config.save().await.unwrap();

        let state = test_state(config);
        let (status, json) = response_json(
            handle_delete_map_key(
                axum::extract::State(state.clone()),
                None,
                axum::extract::Query(MapKeyQuery {
                    path: "channels.discord".to_string(),
                    key: "main".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert_eq!(json["path"], "channels.discord");
        assert_eq!(json["key"], "main");
        let cfg = state.config.read();
        assert!(
            !cfg.get_map_keys("channels.discord")
                .unwrap_or_default()
                .iter()
                .any(|k| k == "main")
        );
        assert!(cfg.agents["ops"].channels.is_empty());
        assert!(cfg.escalation.alert_channels.is_empty());
        drop(cfg);
        let written = std::fs::read_to_string(tmp.path().join("config.toml")).unwrap();
        assert!(!written.contains("discord.main"));
    }

    #[tokio::test]
    async fn delete_plan_rejects_unsupported_tts_provider_delete() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config
            .create_map_key("providers.tts.elevenlabs", "default")
            .unwrap();
        config.agents.insert(
            "voice".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                tts_provider: "elevenlabs.default".into(),
                ..Default::default()
            },
        );

        let state = test_state(config);
        let (status, json) = response_json(
            handle_delete_plan(
                axum::extract::State(state),
                axum::extract::Query(MapKeyQuery {
                    path: "providers.tts.elevenlabs".to_string(),
                    key: "default".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(json["code"], "op_not_supported");
        assert_eq!(json["path"], "providers.tts.elevenlabs.default");
    }

    #[tokio::test]
    async fn delete_map_key_handler_rejects_unsupported_tts_without_raw_delete() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config
            .create_map_key("providers.tts.elevenlabs", "default")
            .unwrap();
        config.save().await.unwrap();

        let state = test_state(config);
        let (status, json) = response_json(
            handle_delete_map_key(
                axum::extract::State(state.clone()),
                None,
                axum::extract::Query(MapKeyQuery {
                    path: "providers.tts.elevenlabs".to_string(),
                    key: "default".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(json["code"], "op_not_supported");
        assert!(
            state
                .config
                .read()
                .get_map_keys("providers.tts.elevenlabs")
                .unwrap_or_default()
                .iter()
                .any(|k| k == "default"),
            "unsupported provider delete must not fall back to raw deletion"
        );
    }

    #[test]
    fn delete_cascade_resolves_custom_workspace_before_removing_entry() {
        let custom = std::path::PathBuf::from("/var/lib/zc-test/custom-victim-ws");
        let mut cfg = zeroclaw_config::schema::Config::default();
        cfg.agents.insert(
            "victim".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig::default(),
        );
        cfg.agents.get_mut("victim").unwrap().workspace.path = Some(custom.clone());

        // While the entry exists → the custom path (what the handler captures).
        assert_eq!(cfg.agent_workspace_dir("victim"), custom);

        // After the cascade removes the entry → it falls back to the DEFAULT
        // path; that is exactly why resolution must happen before the cascade.
        zeroclaw_config::alias_refs::delete_with_cascade(
            &mut cfg,
            &zeroclaw_config::alias_refs::AliasKind::Agent,
            "victim",
            zeroclaw_config::alias_refs::CascadePolicy::RefuseOnHard,
        )
        .expect("soft-only agent delete succeeds");
        assert!(!cfg.agents.contains_key("victim"));
        assert_ne!(
            cfg.agent_workspace_dir("victim"),
            custom,
            "after removal the custom workspace path defaults — resolve BEFORE the cascade"
        );
    }

    #[tokio::test]
    async fn renamed_workspace_move_failure_is_surfaced() {
        // A failed workspace move during rename must surface a warning (so the
        // caller learns config/DB moved to `to` while the workspace is stranded
        // at `from`), not be swallowed as a clean success.
        let tmp = tempfile::tempdir().unwrap();
        let old_ws = tmp.path().join("from-ws");
        std::fs::create_dir_all(&old_ws).unwrap();
        // Force the move to fail: new_ws's parent is a FILE, so create_dir_all
        // and rename both fail.
        let blocker = tmp.path().join("blocker");
        std::fs::write(&blocker, b"x").unwrap();
        let new_ws = blocker.join("to-ws");

        let warning = move_renamed_workspace(&old_ws, &new_ws).await;
        assert!(
            warning.is_some(),
            "a failed workspace move must surface a warning"
        );
        assert!(warning.unwrap().contains("workspace move"));
        assert!(old_ws.exists(), "source dir stays put when the move fails");

        // Nothing-to-move paths return None (no spurious warning).
        assert!(move_renamed_workspace(&old_ws, &old_ws).await.is_none());
        let missing = tmp.path().join("does-not-exist");
        assert!(move_renamed_workspace(&missing, &new_ws).await.is_none());
    }

    #[tokio::test]
    async fn agent_rename_leaves_owned_state_put_when_persist_fails() {
        let tmp = tempfile::tempdir().unwrap();
        // Force config persistence to FAIL by making `config_path` itself a
        // directory - save_dirty's atomic write can't replace a dir. Its parent
        // (the install root) stays a real dir, so the agent-workspace creation
        // and the cron seed below still work. data_dir is separate + writable.
        let cfg_dir = tmp.path().join("config.toml");
        std::fs::create_dir_all(&cfg_dir).unwrap();
        let mut config = zeroclaw_config::schema::Config {
            config_path: cfg_dir,
            data_dir: tmp.path().join("data"),
            ..Default::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        // Agent under `from` with a resolvable risk_profile + an allowed cron
        // command, so cron::add_job accepts a job tied to the agent.
        let from_agent = zeroclaw_config::schema::AliasedAgentConfig {
            risk_profile: "default".into(),
            ..Default::default()
        };
        config.agents.insert("from".to_string(), from_agent);
        config
            .risk_profiles
            .entry("default".into())
            .or_default()
            .allowed_commands = vec!["echo".into()];
        config.runtime_profiles.entry("default".into()).or_default();

        // Seed an owned-state row (a cron job) under `from` - the move-probe.
        zeroclaw_runtime::cron::add_job(&config, "from", "* * * * *", "echo hi")
            .expect("seed cron job");
        assert_eq!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "from")
                .unwrap()
                .len(),
            1
        );

        let state = crate::api::test_state(config.clone());
        let body = RenameMapKeyBody {
            path: "agents".to_string(),
            from: "from".to_string(),
            to: "to".to_string(),
        };
        let guard = state.begin_config_commit().await.unwrap();
        let resp = rename_agent_cascade(
            &state,
            &None,
            config.clone(),
            &body,
            guard,
            test_agent_rename_leases(&state, &body),
        )
        .await;

        // Persist failed -> error response, not a clean rename.
        assert!(
            !resp.status().is_success(),
            "a failed config persist must surface an error"
        );
        // Owned state did NOT move: the cron job stays under `from`.
        assert_eq!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "from")
                .unwrap()
                .len(),
            1,
            "cron must stay under `from` when persist fails (no premature move)"
        );
        assert!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "to")
                .unwrap()
                .is_empty(),
            "cron must NOT have moved to `to` when persist fails"
        );
        // In-memory config was never swapped: still names `from`.
        assert!(state.config.read().agents.contains_key("from"));
        assert!(!state.config.read().agents.contains_key("to"));
    }

    #[tokio::test]
    async fn agent_rename_moves_owned_state_after_successful_persist() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"), // writable -> persist OK
            data_dir: tmp.path().join("data"),
            ..Default::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        // Agent under `from` with a resolvable risk_profile + an allowed cron
        // command, so cron::add_job accepts a job tied to the agent.
        let from_agent = zeroclaw_config::schema::AliasedAgentConfig {
            risk_profile: "default".into(),
            ..Default::default()
        };
        config.agents.insert("from".to_string(), from_agent);
        config
            .risk_profiles
            .entry("default".into())
            .or_default()
            .allowed_commands = vec!["echo".into()];
        config.runtime_profiles.entry("default".into()).or_default();
        // Create the agent's default workspace dir so the move has something to move.
        let old_ws = config.agent_workspace_dir("from");
        std::fs::create_dir_all(&old_ws).unwrap();
        zeroclaw_runtime::cron::add_job(&config, "from", "* * * * *", "echo hi")
            .expect("seed cron job");

        let state = crate::api::test_state(config.clone());
        let body = RenameMapKeyBody {
            path: "agents".to_string(),
            from: "from".to_string(),
            to: "to".to_string(),
        };
        let guard = state.begin_config_commit().await.unwrap();
        let resp = rename_agent_cascade(
            &state,
            &None,
            config.clone(),
            &body,
            guard,
            test_agent_rename_leases(&state, &body),
        )
        .await;
        assert!(resp.status().is_success(), "a clean rename returns success");

        // Config swapped to `to`.
        assert!(state.config.read().agents.contains_key("to"));
        assert!(!state.config.read().agents.contains_key("from"));
        // Cron re-pointed to `to` - the move happened, after a successful persist.
        assert_eq!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "to")
                .unwrap()
                .len(),
            1,
            "cron moves to `to` once persist succeeds"
        );
        assert!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "from")
                .unwrap()
                .is_empty()
        );
        // Workspace moved to the new alias path.
        assert!(
            state.config.read().agent_workspace_dir("to").exists(),
            "workspace moved to `to`"
        );
        assert!(!old_ws.exists(), "old workspace no longer present");
        // (MockMemory.rename_agent is unsupported, so the response `warnings`
        // carries that one known memory line - cron + workspace prove the move.)
    }

    #[tokio::test]
    async fn agent_rename_resume_converges_when_config_already_to() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"), // writable
            data_dir: tmp.path().join("data"),
            ..Default::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        let from_agent = zeroclaw_config::schema::AliasedAgentConfig {
            risk_profile: "default".into(),
            ..Default::default()
        };
        config.agents.insert("from".to_string(), from_agent);
        config
            .risk_profiles
            .entry("default".into())
            .or_default()
            .allowed_commands = vec!["echo".into()];
        config.runtime_profiles.entry("default".into()).or_default();

        // Seed the lagging owned state + workspace under `from` (added while
        // `from` is still a known agent so cron::add_job validates).
        zeroclaw_runtime::cron::add_job(&config, "from", "* * * * *", "echo hi")
            .expect("seed lagged cron job under `from`");
        let old_ws = config.agent_workspace_dir("from");
        std::fs::create_dir_all(&old_ws).unwrap();

        // Simulate the post-persist window: config already committed the rename
        // to `to` (so `from` is gone from config), while the cron row + workspace
        // above still lag at `from`. The cron DB lives under data_dir and survives
        // this in-memory config edit.
        config.agents.remove("from");
        config.agents.insert(
            "to".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                risk_profile: "default".into(),
                ..Default::default()
            },
        );

        let state = crate::api::test_state(config.clone());
        let body = RenameMapKeyBody {
            path: "agents".to_string(),
            from: "from".to_string(),
            to: "to".to_string(),
        };
        // Re-issue the SAME rename. Beforethis returned 404 (from absent in
        // the committed config); now it resumes and re-runs the lagging effects.
        let guard = state.begin_config_commit().await.unwrap();
        let resp = rename_agent_cascade(
            &state,
            &None,
            config.clone(),
            &body,
            guard,
            test_agent_rename_leases(&state, &body),
        )
        .await;
        assert!(
            resp.status().is_success(),
            "re-issuing a rename after a post-persist lag must converge, not 404"
        );

        // Owned state converged onto `to`.
        assert_eq!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "to")
                .unwrap()
                .len(),
            1,
            "lagged cron re-points to `to` on resume"
        );
        assert!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "from")
                .unwrap()
                .is_empty(),
            "no cron left under `from` after convergence"
        );
        // Workspace converged onto `to`.
        assert!(
            state.config.read().agent_workspace_dir("to").exists(),
            "workspace moved to `to` on resume"
        );
        assert!(!old_ws.exists(), "old `from` workspace no longer present");
        // Config still names `to` and never regained `from` (no double-rename).
        assert!(state.config.read().agents.contains_key("to"));
        assert!(!state.config.read().agents.contains_key("from"));
    }

    #[tokio::test]
    async fn agent_rename_unrelated_collision_is_not_treated_as_resume() {
        let tmp = tempfile::tempdir().unwrap();
        let config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"), // writable
            data_dir: tmp.path().join("data"),
            ..Default::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();

        // Committed-`to` shape: config has `to`, the source `gone` is absent.
        // Crucially there is NO residue under `gone` - no workspace dir, no cron
        // job, no acp/memory/session rows. This is an unrelated request (or an
        // already-fully-converged duplicate), not a partial-failure resume.
        let mut config = config;
        config.agents.insert(
            "to".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                risk_profile: "default".into(),
                ..Default::default()
            },
        );
        config.risk_profiles.entry("default".into()).or_default();
        config.runtime_profiles.entry("default".into()).or_default();
        // Guard the test's own premise: the source workspace must not exist.
        assert!(
            !config.agent_workspace_dir("gone").exists(),
            "precondition: no residue workspace under the absent source"
        );

        let state = crate::api::test_state(config.clone());
        let body = RenameMapKeyBody {
            path: "agents".to_string(),
            from: "gone".to_string(),
            to: "to".to_string(),
        };
        let guard = state.begin_config_commit().await.unwrap();
        let resp = rename_agent_cascade(
            &state,
            &None,
            config.clone(),
            &body,
            guard,
            test_agent_rename_leases(&state, &body),
        )
        .await;

        // No residue → NOT a resume → the normal branch runs `rename_with_cascade`
        // with `gone` absent → NotFound → an error response, not a silent success.
        assert!(
            !resp.status().is_success(),
            "an unrelated `gone -> to` with no residue must surface an error, not be silently treated as a resume"
        );
        // Config untouched: no rename happened, `to` still present, `gone` absent.
        assert!(state.config.read().agents.contains_key("to"));
        assert!(!state.config.read().agents.contains_key("gone"));
    }

    #[test]
    fn map_prop_error_classifies_unknown_property() {
        let err = anyhow::Error::msg("Unknown property 'foo.bar'");
        let api_err = map_prop_error(err, "foo.bar");
        assert_eq!(api_err.code, ConfigApiCode::PathNotFound);
    }

    #[test]
    fn map_prop_error_classifies_type_mismatch() {
        // The classifier (config::api_error::classify_validation_message) now
        // matches "type mismatch" → ValueTypeMismatch; was ValidationFailed.
        let err = anyhow::Error::msg("type mismatch: expected u64");
        let api_err = map_prop_error(err, "scheduler.max_concurrent");
        assert_eq!(api_err.code, ConfigApiCode::ValueTypeMismatch);
    }

    #[test]
    fn map_prop_error_falls_back_to_validation_on_unknown_message() {
        let err = anyhow::Error::msg("some completely unrecognized validator message");
        let api_err = map_prop_error(err, "scheduler.max_concurrent");
        assert_eq!(api_err.code, ConfigApiCode::ValidationFailed);
    }

    #[test]
    fn json_pointer_to_dotted_handles_pointer_form() {
        assert_eq!(
            json_pointer_to_dotted("/providers/models/openrouter/api-key"),
            "providers.models.openrouter.api-key"
        );
    }

    #[test]
    fn json_pointer_to_dotted_passes_dotted_through() {
        assert_eq!(
            json_pointer_to_dotted("providers.models.openrouter.api-key"),
            "providers.models.openrouter.api-key"
        );
        assert_eq!(
            json_pointer_to_dotted("scheduler.max_concurrent"),
            "scheduler.max_concurrent"
        );
    }

    #[test]
    fn json_pointer_to_dotted_handles_empty_root() {
        assert_eq!(json_pointer_to_dotted(""), "");
        assert_eq!(json_pointer_to_dotted("/"), "");
    }

    use zeroclaw_config::traits::PropKind;

    #[test]
    fn test_op_coercion_bool_typed_value_matches_stored() {
        let mut cfg = zeroclaw_config::schema::Config::default();
        cfg.risk_profiles.insert(
            "default".into(),
            zeroclaw_config::schema::RiskProfileConfig::default(),
        );
        cfg.set_prop("risk_profiles.default.workspace_only", "true")
            .expect("set_prop bool");
        let actual = cfg
            .get_prop("risk_profiles.default.workspace_only")
            .expect("get_prop");
        let want_typed = json_to_setprop_string(&serde_json::json!(true), Some(PropKind::Bool))
            .expect("coerce bool true");
        assert_eq!(
            actual, want_typed,
            "bool field: typed JSON `true` must coerce to the same display string \
             as `get_prop` returns; got actual={actual:?} want_typed={want_typed:?}"
        );

        // Legacy string-form (`Value::String("true")`) for the same bool
        // field must also coerce to the same string — back-compat for
        // clients that send strings instead of booleans.
        let want_string = json_to_setprop_string(&serde_json::json!("true"), Some(PropKind::Bool))
            .expect("coerce bool from string");
        assert_eq!(actual, want_string);
    }

    #[test]
    fn test_op_coercion_integer_typed_value_matches_stored() {
        let mut cfg = zeroclaw_config::schema::Config::default();
        cfg.set_prop("gateway.port", "42617")
            .expect("set_prop integer");
        let actual = cfg.get_prop("gateway.port").expect("get_prop");
        let want_typed = json_to_setprop_string(&serde_json::json!(42617), Some(PropKind::Integer))
            .expect("coerce integer");
        assert_eq!(
            actual, want_typed,
            "integer field coercion: actual={actual:?} want_typed={want_typed:?}"
        );

        // Legacy string-form must also coerce equivalently.
        let want_string =
            json_to_setprop_string(&serde_json::json!("42617"), Some(PropKind::Integer))
                .expect("coerce integer from string");
        assert_eq!(actual, want_string);
    }

    #[test]
    fn test_op_coercion_float_typed_value_matches_stored() {
        let mut cfg = zeroclaw_config::schema::Config::default();
        // autonomy doesn't carry floats today; use a model_provider temperature
        // by setting a known model provider entry. The model providers map
        // is set up via map keys, so use a path that's unambiguously float.
        // Fall back to set_prop on a known float location:
        match cfg.set_prop("providers.models.openai.temperature", "0.7") {
            Ok(()) => {
                let actual = cfg
                    .get_prop("providers.models.openai.temperature")
                    .expect("get_prop float");
                let want_typed =
                    json_to_setprop_string(&serde_json::json!(0.7), Some(PropKind::Float))
                        .expect("coerce float typed");
                assert_eq!(
                    actual, want_typed,
                    "float field coercion: actual={actual:?} want_typed={want_typed:?}"
                );
            }
            Err(_) => {
                // Float path not available on default Config — skip without
                // failing. The bool and integer tests cover the same
                // invariant; float just pins the additional case.
            }
        }
    }

    #[test]
    fn test_op_coercion_string_field_no_regression() {
        let mut cfg = zeroclaw_config::schema::Config::default();
        cfg.set_prop("gateway.host", "10.0.0.1")
            .expect("set_prop string");
        let actual = cfg.get_prop("gateway.host").expect("get_prop string");
        let want_typed =
            json_to_setprop_string(&serde_json::json!("10.0.0.1"), Some(PropKind::String))
                .expect("coerce string");
        assert_eq!(actual, want_typed);
    }

    #[test]
    fn test_op_coercion_mismatched_value_correctly_fails() {
        let mut cfg = zeroclaw_config::schema::Config::default();
        cfg.risk_profiles.insert(
            "default".into(),
            zeroclaw_config::schema::RiskProfileConfig::default(),
        );
        cfg.set_prop("risk_profiles.default.workspace_only", "true")
            .expect("set_prop");
        let actual = cfg
            .get_prop("risk_profiles.default.workspace_only")
            .expect("get_prop");
        let want = json_to_setprop_string(&serde_json::json!(false), Some(PropKind::Bool))
            .expect("coerce bool false");
        assert_ne!(
            actual, want,
            "bool true must not match bool false after coercion — \
             a mismatched test op should fail with ValidationFailed"
        );
    }

    // ── Integration-flavored tests: drift detection + comment writing ──

    use std::path::PathBuf;

    fn temp_config_path() -> (tempfile::TempDir, PathBuf) {
        let tmp = tempfile::tempdir().expect("tempdir");
        let path = tmp.path().join("config.toml");
        (tmp, path)
    }

    #[tokio::test]
    async fn compute_drift_returns_empty_when_in_memory_matches_disk() {
        let (_tmp, path) = temp_config_path();
        let cfg = zeroclaw_config::schema::Config {
            config_path: path.clone(),
            ..Default::default()
        };
        // Write the in-memory state to disk first so they agree by definition.
        cfg.save().await.expect("save");

        let drift = compute_drift(&cfg).await;
        assert!(
            drift.is_empty(),
            "expected no drift right after save, got {drift:?}"
        );
    }

    #[tokio::test]
    async fn compute_drift_surfaces_mismatched_non_secret_field() {
        let (_tmp, path) = temp_config_path();
        let mut cfg = zeroclaw_config::schema::Config {
            config_path: path.clone(),
            ..Default::default()
        };
        cfg.save().await.expect("initial save");

        // Mutate the in-memory config without saving.
        cfg.set_prop("gateway.host", "10.0.0.1").expect("set_prop");

        let drift = compute_drift(&cfg).await;
        let entry = drift
            .iter()
            .find(|d| d.path == "gateway.host")
            .expect("expected gateway.host in drift summary");
        assert!(!entry.secret);
        assert!(entry.drifted);
        assert!(entry.in_memory_value.is_some());
        assert!(entry.on_disk_value.is_some());
    }

    #[tokio::test]
    async fn compute_drift_returns_empty_when_no_disk_file() {
        let (_tmp, path) = temp_config_path();
        let cfg = zeroclaw_config::schema::Config {
            config_path: path.clone(),
            ..Default::default()
        };
        // Don't save — file does not exist.
        let drift = compute_drift(&cfg).await;
        assert!(drift.is_empty());
    }

    /// An upgraded file without `[tools]`, or with a `[tools]` section that
    /// omits `optional`, loads full both through the loader and through the
    /// plain parse drift compares against, so it reports no drift.
    #[tokio::test]
    async fn compute_drift_ignores_an_omitted_tools_selector() {
        let version = zeroclaw_config::migration::CURRENT_SCHEMA_VERSION;
        for raw in [
            format!("schema_version = {version}\n"),
            format!("schema_version = {version}\n[tools]\n"),
        ] {
            let (_tmp, path) = temp_config_path();
            tokio::fs::write(&path, &raw).await.unwrap();
            let mut cfg = zeroclaw_config::migration::migrate_to_current_salvaged(&raw).config;
            cfg.config_path = path.clone();
            assert_eq!(cfg.tools.optional, ["*"], "{raw}");

            let drift = try_compute_drift(&cfg).await.expect("drift");
            assert!(
                drift.iter().all(|entry| !entry.path.starts_with("tools")),
                "{raw}: {drift:?}"
            );
            assert!(drift.is_empty(), "{raw}: {drift:?}");
        }
    }

    #[tokio::test]
    async fn apply_comments_writes_decoration_to_existing_value() {
        let (_tmp, path) = temp_config_path();
        let mut cfg = zeroclaw_config::schema::Config {
            config_path: path.clone(),
            ..Default::default()
        };
        cfg.set_prop("gateway.host", "10.0.0.5").expect("set_prop");
        cfg.save().await.expect("save");

        zeroclaw_config::comment_writer::apply_comments(
            &path,
            &[("gateway.host".into(), "raised after Q3 backlog".into())],
        )
        .await
        .expect("apply_comments");

        let raw = tokio::fs::read_to_string(&path).await.expect("read back");
        // Existence check: the comment text appears in the file.
        assert!(
            raw.contains("# raised after Q3 backlog"),
            "expected comment in file, got:\n{raw}"
        );

        // Positional check: the comment appears IMMEDIATELY ABOVE `host = ...`,
        // not somewhere else in the file. The previous version of the helper
        // wrote the prefix between `=` and the value, producing broken TOML —
        // this assertion would have caught that bug.
        let lines: Vec<&str> = raw.lines().collect();
        let host_line_idx = lines
            .iter()
            .position(|l| l.trim_start().starts_with("host"))
            .expect("host = line in saved config");
        assert!(
            host_line_idx > 0,
            "host line is at top — comment can't precede it"
        );
        let above = lines[host_line_idx - 1];
        assert_eq!(
            above.trim(),
            "# raised after Q3 backlog",
            "expected comment immediately above `host = ...`, got line above:\n  {above:?}\nfull file:\n{raw}"
        );

        // Round-trip check: re-parsing the file must succeed (broken
        // decoration target produces malformed TOML).
        let _: toml::Value = toml::from_str(&raw)
            .unwrap_or_else(|e| panic!("re-parse failed after apply_comments: {e}\nfile:\n{raw}"));
    }

    #[test]
    fn scrub_credentials_catches_credential_shaped_strings() {
        use zeroclaw_runtime::agent::loop_::scrub_credentials;

        let cases = [
            // Field=value style log line.
            (
                "api-key=sk-live-abcdef-1234567890",
                "sk-live-abcdef-1234567890",
            ),
            // JSON-ish quoted key-value pair.
            (
                r#""token": "sk-test-supersecret-12345""#,
                "sk-test-supersecret-12345",
            ),
            // Explicit secret key.
            (
                "secret: hunter2-not-a-real-password",
                "hunter2-not-a-real-password",
            ),
            // Bearer credential pair.
            (
                "credential: bearer-token-abcdef-9876",
                "bearer-token-abcdef-9876",
            ),
        ];
        for (input, raw_secret) in cases {
            let scrubbed = scrub_credentials(input);
            assert!(
                !scrubbed.contains(raw_secret),
                "scrubber missed `{raw_secret}` in:\n  input    : {input}\n  scrubbed : {scrubbed}"
            );
            assert!(
                scrubbed.contains("REDACTED"),
                "expected REDACTED marker in:\n  input    : {input}\n  scrubbed : {scrubbed}"
            );
        }
    }

    #[tokio::test]
    async fn compute_drift_detects_external_edit_to_field() {
        // Persist initial state, externally edit the file, drift surfaces
        // the touched path. This is the substrate the PATCH 409 guard fires on.
        let (_tmp, path) = temp_config_path();
        let mut cfg = zeroclaw_config::schema::Config {
            config_path: path.clone(),
            ..Default::default()
        };
        cfg.set_prop("gateway.host", "10.0.0.1").expect("set");
        cfg.save().await.expect("save");

        // Simulate a hand-edit while the daemon "wasn't looking".
        let on_disk = tokio::fs::read_to_string(&path).await.unwrap();
        let edited = on_disk.replace("10.0.0.1", "192.168.1.1");
        tokio::fs::write(&path, edited).await.unwrap();

        // In-memory still believes 10.0.0.1; on-disk now says 192.168.1.1.
        let drift = compute_drift(&cfg).await;
        let entry = drift
            .iter()
            .find(|d| d.path == "gateway.host")
            .expect("expected gateway.host in drift summary after external edit");
        assert!(entry.drifted);
        assert_eq!(
            entry.in_memory_value,
            Some(serde_json::Value::String("10.0.0.1".into()))
        );
        assert_eq!(
            entry.on_disk_value,
            Some(serde_json::Value::String("192.168.1.1".into()))
        );
    }

    #[test]
    fn secret_response_only_carries_path_and_populated_flag() {
        // Belt-and-braces: serialize a SecretResponse and assert the JSON
        // shape carries neither a `value` field nor a length-leaking string.
        // If anyone ever adds a field to SecretResponse, this test fires.
        let r = SecretResponse {
            path: "providers.models.ollama.api-key".into(),
            populated: true,
        };
        let json = serde_json::to_value(&r).expect("serialize");
        let obj = json.as_object().expect("object");
        let keys: Vec<&str> = obj.keys().map(String::as_str).collect();
        assert_eq!(
            keys,
            vec!["path", "populated"],
            "SecretResponse must carry only path + populated"
        );
        assert!(!obj.contains_key("value"));
        assert!(!obj.contains_key("length"));
        assert!(!obj.contains_key("hash"));
        assert!(!obj.contains_key("masked"));
    }

    #[test]
    fn lookup_prop_field_synthesizes_dynamic_http_request_secret_metadata() {
        let cfg = zeroclaw_config::schema::Config::default();
        let field = lookup_prop_field(&cfg, "http_request.secrets.api_token")
            .expect("dynamic http_request secret metadata");

        assert_eq!(field.kind, PropKind::String);
        assert!(field.is_secret);
        assert_eq!(
            field.credential_class,
            Some(zeroclaw_config::traits::CredentialSurfaceClass::EncryptedSecret)
        );
    }

    #[test]
    fn list_entry_for_secret_omits_value_field() {
        let entry = ListEntry {
            path: "providers.models.ollama.api-key".into(),
            category: "providers.models".into(),
            kind: "string",
            type_hint: "Option<String>",
            value: None,
            populated: true,
            is_secret: true,
            is_env_overridden: false,
            enum_variants: vec![],
            section: Some("providers.models"),
            tab: "",
            multiline: false,
        };
        let json = serde_json::to_value(&entry).expect("serialize");
        let obj = json.as_object().expect("object");
        // skip_serializing_if on `value` means it must be absent.
        assert!(
            !obj.contains_key("value"),
            "secret list entry leaks `value` field"
        );
        // is_secret marker must be present so the dashboard can render it as locked.
        assert_eq!(obj.get("is_secret"), Some(&serde_json::Value::Bool(true)));
        assert_eq!(obj.get("populated"), Some(&serde_json::Value::Bool(true)));
    }

    #[test]
    fn gateway_paired_tokens_is_gateway_managed() {
        // The `Configurable` derive emits prop-field names in the field's
        // snake_case form, so the canonical name is `gateway.paired_tokens`
        // (underscore). The matcher must use that exact string, otherwise the
        // guard never fires and the secret keeps surfacing as drift.
        assert!(
            is_gateway_managed_field("gateway.paired_tokens"),
            "gateway.paired_tokens must be treated as gateway-managed"
        );
        // The old hyphenated form never matched a real prop-field name.
        assert!(!is_gateway_managed_field("gateway.paired-tokens"));

        // Guard against the field being renamed or the derive changing its
        // naming convention out from under the matcher.
        let cfg = zeroclaw_config::schema::Config::default();
        assert!(
            cfg.prop_fields()
                .iter()
                .any(|p| p.name == "gateway.paired_tokens"),
            "expected a prop-field named gateway.paired_tokens"
        );
    }

    #[tokio::test]
    async fn compute_drift_excludes_gateway_paired_tokens() {
        let (_tmp, path) = temp_config_path();
        let mut cfg = zeroclaw_config::schema::Config {
            config_path: path.clone(),
            ..Default::default()
        };
        cfg.save().await.expect("initial save");

        // Mutate the gateway-managed secret in memory without saving. Drift
        // detection must not surface it because the gateway owns it.
        cfg.gateway.paired_tokens = vec!["minted-by-the-gateway".into()];

        let drift = compute_drift(&cfg).await;
        assert!(
            !drift.iter().any(|d| d.path == "gateway.paired_tokens"),
            "gateway.paired_tokens must never appear in drift, got {drift:?}"
        );
    }

    #[tokio::test]
    async fn compute_drift_excludes_env_overridden_secret() {
        let (_tmp, path) = temp_config_path();
        let mut cfg = zeroclaw_config::schema::Config {
            config_path: path.clone(),
            ..Default::default()
        };
        cfg.save().await.expect("initial save");

        cfg.composio.api_key = Some("injected-via-env".into());
        cfg.env_overridden_paths =
            std::collections::HashSet::from(["composio.api_key".to_string()]);

        let drift = compute_drift(&cfg).await;
        assert!(
            !drift.iter().any(|d| d.path == "composio.api_key"),
            "env-overridden secret must never appear in drift, got {drift:?}"
        );
    }

    #[test]
    fn every_gateway_secret_is_classified() {
        const OPERATOR_EDITED_GATEWAY_SECRETS: &[&str] = &["gateway.webhook_secret"];

        let cfg = zeroclaw_config::schema::Config::default();
        let unclassified: Vec<String> = cfg
            .prop_fields()
            .iter()
            .filter(|p| p.is_secret && p.name.starts_with("gateway."))
            .map(|p| p.name.clone())
            .filter(|name| {
                !is_gateway_managed_field(name)
                    && !OPERATOR_EDITED_GATEWAY_SECRETS.contains(&name.as_str())
            })
            .collect();

        assert!(
            unclassified.is_empty(),
            "new [gateway] secret field(s) {unclassified:?} are not classified.\n\
             If the gateway mints/rotates/persists this field itself, add it to \
             `is_gateway_managed_field`.\n\
             If operators edit it directly in config.toml, add it to the \
             OPERATOR_EDITED_GATEWAY_SECRETS list in this test."
        );
    }

    #[test]
    fn drift_entry_for_secret_omits_both_values() {
        let entry = DriftEntry {
            path: "providers.models.ollama.api-key".into(),
            secret: true,
            drifted: true,
            in_memory_value: None,
            on_disk_value: None,
        };
        let json = serde_json::to_value(&entry).expect("serialize");
        let obj = json.as_object().expect("object");
        assert!(
            !obj.contains_key("in_memory_value"),
            "secret drift entry leaks in_memory_value"
        );
        assert!(
            !obj.contains_key("on_disk_value"),
            "secret drift entry leaks on_disk_value"
        );
        assert_eq!(obj.get("secret"), Some(&serde_json::Value::Bool(true)));
        assert_eq!(obj.get("drifted"), Some(&serde_json::Value::Bool(true)));
    }

    #[tokio::test]
    async fn apply_comments_clears_existing_comment_when_passed_empty() {
        let (_tmp, path) = temp_config_path();
        let mut cfg = zeroclaw_config::schema::Config {
            config_path: path.clone(),
            ..Default::default()
        };
        cfg.set_prop("gateway.host", "10.0.0.5").expect("set_prop");
        cfg.save().await.expect("save");

        zeroclaw_config::comment_writer::apply_comments(
            &path,
            &[("gateway.host".into(), "first reason".into())],
        )
        .await
        .expect("apply first comment");
        zeroclaw_config::comment_writer::apply_comments(
            &path,
            &[("gateway.host".into(), String::new())],
        )
        .await
        .expect("apply empty");

        let raw = tokio::fs::read_to_string(&path).await.expect("read back");
        assert!(
            !raw.contains("first reason"),
            "expected the prior comment to be cleared, got:\n{raw}"
        );
    }

    #[tokio::test]
    async fn agent_delete_leaves_owned_state_intact_when_persist_fails() {
        let tmp = tempfile::tempdir().unwrap();
        let cfg_dir = tmp.path().join("config.toml");
        std::fs::create_dir_all(&cfg_dir).unwrap();
        let mut config = zeroclaw_config::schema::Config {
            config_path: cfg_dir,
            data_dir: tmp.path().join("data"),
            ..Default::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        // Real default-workspace dir for the agent so the archive step has
        // something to act on (and so a buggy pre-fix run would visibly move
        // it under `agents/_deleted/`).
        let agent = zeroclaw_config::schema::AliasedAgentConfig {
            risk_profile: "default".into(),
            ..Default::default()
        };
        config.agents.insert("victim".to_string(), agent);
        config
            .risk_profiles
            .entry("default".into())
            .or_default()
            .allowed_commands = vec!["echo".into()];
        config.runtime_profiles.entry("default".into()).or_default();
        let old_ws = config.agent_workspace_dir("victim");
        std::fs::create_dir_all(&old_ws).unwrap();
        // Seed an owned-state row (a cron job) under `victim` — the delete probe.
        zeroclaw_runtime::cron::add_job(&config, "victim", "* * * * *", "echo hi")
            .expect("seed cron job");
        assert_eq!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "victim")
                .unwrap()
                .len(),
            1
        );

        let state = crate::api::test_state(config.clone());
        let generation_before = state.agent_lifecycle.alias_generation("victim");
        let resp = delete_agent_cascade(
            &state,
            &None,
            "victim",
            test_agent_delete_lease(&state, "victim"),
        )
        .await;

        // Persist failed -> error response, not a clean delete.
        assert!(
            !resp.status().is_success(),
            "a failed config persist must surface an error"
        );
        // Owned state did NOT move: the cron job stays under `victim`.
        assert_eq!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "victim")
                .unwrap()
                .len(),
            1,
            "cron must stay under `victim` when persist fails (no premature purge)"
        );
        // Workspace was NOT archived: still on disk at the original path.
        assert!(
            old_ws.exists(),
            "workspace must NOT have been archived when persist fails"
        );
        let archive_root = config.data_dir.join("agents").join("_deleted");
        assert!(
            !archive_root.exists(),
            "no archive directory must be created when persist fails"
        );
        // In-memory config was never swapped: still names `victim`.
        assert!(state.config.read().agents.contains_key("victim"));
        // The reservation rolled back: the old generation stays usable.
        assert_eq!(
            state.agent_lifecycle.alias_generation("victim"),
            generation_before
        );
        let producer = state.agent_lifecycle.reserve_turn("victim").unwrap();
        drop(producer);
        assert!(
            state
                .agent_lifecycle
                .reserve_turn_at("victim", generation_before)
                .is_ok()
        );
    }

    #[tokio::test]
    async fn agent_delete_hard_reference_refusal_preserves_generation() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"),
            data_dir: tmp.path().join("data"),
            ..Default::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        config.agents.insert(
            "victim".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                risk_profile: "default".into(),
                ..Default::default()
            },
        );
        config.heartbeat.enabled = true;
        config.heartbeat.agent = "victim".to_string();

        let state = crate::api::test_state(config.clone());
        let generation_before = state.agent_lifecycle.alias_generation("victim");

        let resp = delete_agent_cascade(
            &state,
            &None,
            "victim",
            test_agent_delete_lease(&state, "victim"),
        )
        .await;

        assert!(
            !resp.status().is_success(),
            "a hard reference must refuse the delete"
        );
        assert!(state.config.read().agents.contains_key("victim"));
        // The dropped reservation left the generation and producers untouched:
        // an old-generation producer admits after the rollback.
        assert_eq!(
            state.agent_lifecycle.alias_generation("victim"),
            generation_before
        );
        let producer = state.agent_lifecycle.reserve_turn("victim").unwrap();
        drop(producer);
        assert!(
            state
                .agent_lifecycle
                .reserve_turn_at("victim", generation_before)
                .is_ok()
        );
    }

    #[tokio::test]
    async fn agent_delete_purges_owned_state_after_successful_persist() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"), // writable -> persist OK
            data_dir: tmp.path().join("data"),
            ..Default::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        let agent = zeroclaw_config::schema::AliasedAgentConfig {
            risk_profile: "default".into(),
            ..Default::default()
        };
        config.agents.insert("victim".to_string(), agent);
        config
            .risk_profiles
            .entry("default".into())
            .or_default()
            .allowed_commands = vec!["echo".into()];
        config.runtime_profiles.entry("default".into()).or_default();
        let old_ws = config.agent_workspace_dir("victim");
        std::fs::create_dir_all(&old_ws).unwrap();
        zeroclaw_runtime::cron::add_job(&config, "victim", "* * * * *", "echo hi")
            .expect("seed cron job");

        let state = crate::api::test_state(config.clone());
        let generation_before = state.agent_lifecycle.alias_generation("victim");
        let resp = delete_agent_cascade(
            &state,
            &None,
            "victim",
            test_agent_delete_lease(&state, "victim"),
        )
        .await;
        assert!(resp.status().is_success(), "a clean delete returns success");

        // Config swapped: `victim` is GONE.
        assert!(
            !state.config.read().agents.contains_key("victim"),
            "agent removed from persisted config"
        );
        // The committed deletion advanced the generation exactly once.
        assert_eq!(
            state.agent_lifecycle.alias_generation("victim"),
            generation_before.wrapping_add(1)
        );
        // Cron job purged: the cascade ran after a successful persist.
        assert!(
            zeroclaw_runtime::cron::list_jobs_by_agent(&config, "victim")
                .unwrap()
                .is_empty(),
            "cron purged once persist succeeds"
        );
        // Workspace archived: source dir gone, archive dir populated.
        assert!(
            !old_ws.exists(),
            "old workspace no longer at the original path"
        );
        let archive_root = config.data_dir.join("agents").join("_deleted");
        assert!(archive_root.exists(), "archive directory was created");
        let archived_ws = std::fs::read_dir(&archive_root)
            .unwrap()
            .filter_map(|e| e.ok())
            .find(|e| e.path().join("workspace").exists())
            .expect("an archive entry for `victim` with a workspace/ subdir");
        assert!(
            archived_ws
                .file_name()
                .to_string_lossy()
                .starts_with("victim-"),
            "archive entry name must start with `victim-`"
        );
    }

    #[tokio::test]
    async fn agent_delete_response_carries_partial_failure_warnings() {
        use axum::body::to_bytes;

        let tmp = tempfile::tempdir().unwrap();
        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"),
            data_dir: tmp.path().join("data"),
            ..Default::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        let agent = zeroclaw_config::schema::AliasedAgentConfig {
            risk_profile: "default".into(),
            ..Default::default()
        };
        config.agents.insert("victim".to_string(), agent);
        config
            .risk_profiles
            .entry("default".into())
            .or_default()
            .allowed_commands = vec!["echo".into()];
        config.runtime_profiles.entry("default".into()).or_default();
        let agents_dir = config.data_dir.join("agents");
        std::fs::create_dir_all(&agents_dir).unwrap();
        let deleted_marker = agents_dir.join("_deleted");
        std::fs::write(&deleted_marker, b"").expect("seed _deleted blocker file");
        let old_ws = config.agent_workspace_dir("victim");
        std::fs::create_dir_all(&old_ws).unwrap();
        // Drop a real file inside the workspace so the cascade has something
        // to archive (and so we can detect a successful archive).
        std::fs::write(old_ws.join("marker.txt"), b"hi").unwrap();
        zeroclaw_runtime::cron::add_job(&config, "victim", "* * * * *", "echo hi")
            .expect("seed cron job");

        let state = crate::api::test_state(config.clone());
        let resp = delete_agent_cascade(
            &state,
            &None,
            "victim",
            test_agent_delete_lease(&state, "victim"),
        )
        .await;

        // The HTTP call is still 200 OK — partial failure is not an error
        // response, it is a successful response with `warnings` populated.
        assert_eq!(resp.status(), axum::http::StatusCode::OK);

        // Parse the response body and assert the `warnings` field is present
        // and non-empty. We assert the SPECIFIC shape the operator sees:
        // an array of strings, one per failed side-effect.
        let body = to_bytes(resp.into_body(), 1024 * 1024).await.unwrap();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        let warnings = json
            .get("warnings")
            .and_then(|v| v.as_array())
            .expect("response must carry a `warnings` array");
        assert!(
            !warnings.is_empty(),
            "partial-failure response must surface at least one warning, got: {warnings:?}"
        );
        // At least one warning should mention the archive dir (creation or rename).
        let joined = warnings
            .iter()
            .map(|v| v.as_str().unwrap_or(""))
            .collect::<Vec<_>>()
            .join("\n");
        assert!(
            joined.contains("archive"),
            "warnings should mention archive-side failures, got: {joined}"
        );
    }

    fn config_with_telegram_alias(
        tmp: &tempfile::TempDir,
        alias: &str,
    ) -> zeroclaw_config::schema::Config {
        let mut config = temp_config(tmp);
        config.channels.telegram.insert(
            alias.to_string(),
            zeroclaw_config::schema::TelegramConfig {
                enabled: true,
                bot_token: "test-token".to_string(),
                api_base_url: zeroclaw_config::schema::TELEGRAM_OFFICIAL_API_BASE_URL.to_string(),
                ..Default::default()
            },
        );
        config
    }

    /// Trust-boundary regression: the bind route must reject an
    /// unauthenticated request before any config mutation. Pairing is
    /// required and no token is presented, so the handler returns 401 and
    /// leaves the peer group untouched.
    #[tokio::test]
    async fn channel_bind_rejects_unauthenticated_request() {
        use tower::ServiceExt;
        let tmp = tempfile::tempdir().unwrap();
        let config = config_with_telegram_alias(&tmp, "alerts");
        let mut state = test_state(config.clone());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));

        // Auth moved from the handler to the route layer: exercise the
        // bind route through the REAL layered router.
        let auth = Arc::new(
            crate::principal_gate::GatewayInboundAuth::from_config(
                &config,
                Arc::clone(&state.pairing),
            )
            .unwrap(),
        );
        let router = crate::config_admin_router(crate::principal_gate::ConfigRouteAuth::new(
            &auth,
            &state.config,
        ))
        .with_state(state.clone());
        let response = router
            .oneshot(
                axum::http::Request::builder()
                    .method("POST")
                    .uri("/api/channels/bind")
                    .header("content-type", "application/json")
                    .body(axum::body::Body::from(
                        serde_json::json!({
                            "channel_type": "telegram",
                            "alias": "alerts",
                            "identity": "123456789"
                        })
                        .to_string(),
                    ))
                    .unwrap(),
            )
            .await
            .unwrap();

        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        assert!(
            state
                .config
                .read()
                .channel_external_peers("telegram", "alerts")
                .is_empty(),
            "a rejected bind must not mutate the peer group"
        );
    }

    /// Trust-boundary regression: binding into a `[channels.telegram.<alias>]`
    /// that does not exist must 404 rather than mint a peer group the runtime
    /// never resolves authorization from.
    #[tokio::test]
    async fn channel_bind_phantom_alias_is_404() {
        let tmp = tempfile::tempdir().unwrap();
        let config = config_with_telegram_alias(&tmp, "alerts");
        let state = test_state(config);

        let (status, _json) = response_json(
            handle_api_channel_bind(
                axum::extract::State(state.clone()),
                None,
                axum::Json(ChannelBindBody {
                    channel_type: "telegram".to_string(),
                    alias: "ghost".to_string(),
                    identity: "123456789".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::NOT_FOUND);
        assert!(
            state
                .config
                .read()
                .channel_external_peers("telegram", "ghost")
                .is_empty(),
            "a phantom-alias bind must not create a peer group"
        );
    }

    /// Trust-boundary regression: an `ignore` naming the identity outranks the
    /// grant a bind writes, so the endpoint must say so rather than answer
    /// `saved` for a peer the running channel still rejects. The shared bind
    /// core appended the grant and returned `Ok(true)`, and this handler
    /// reported success on it.
    #[tokio::test]
    async fn channel_bind_refuses_an_identity_an_ignore_denies() {
        use zeroclaw_config::multi_agent::{PeerGroupConfig, PeerUsername};
        use zeroclaw_config::providers::ChannelRef;

        let tmp = tempfile::tempdir().unwrap();
        let mut config = config_with_telegram_alias(&tmp, "alerts");
        config.peer_groups.insert(
            "telegram_alerts_blocked".to_string(),
            PeerGroupConfig {
                channel: ChannelRef::new("telegram.alerts".to_string()),
                ignore: vec![PeerUsername::new("123456789".to_string())],
                ..PeerGroupConfig::default()
            },
        );
        let state = test_state(config);

        let (status, json) = response_json(
            handle_api_channel_bind(
                axum::extract::State(state.clone()),
                None,
                axum::Json(ChannelBindBody {
                    channel_type: "telegram".to_string(),
                    alias: "alerts".to_string(),
                    identity: "123456789".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        let message = json.to_string();
        assert!(
            message.contains("ignore"),
            "the operator has to be told what to edit, got: {message}"
        );
        assert!(
            state
                .config
                .read()
                .peer_groups
                .get("telegram_alerts")
                .is_none_or(|g| g.external_peers.is_empty()),
            "a refused bind must not mutate the peer group"
        );
    }

    /// The HTTP surface of the same rule: peer-group keys are arbitrary, so a
    /// group named `telegram_alerts` may be bound to a different instance. The
    /// endpoint must refuse rather than report `saved` for a write the
    /// requested channel's reader never sees.
    #[tokio::test]
    async fn channel_bind_refuses_a_group_key_bound_to_another_channel() {
        use zeroclaw_config::multi_agent::PeerGroupConfig;
        use zeroclaw_config::providers::ChannelRef;

        let tmp = tempfile::tempdir().unwrap();
        let mut config = config_with_telegram_alias(&tmp, "alerts");
        config.peer_groups.insert(
            "telegram_alerts".to_string(),
            PeerGroupConfig {
                channel: ChannelRef::new("telegram.other".to_string()),
                ..PeerGroupConfig::default()
            },
        );
        let state = test_state(config);

        let (status, json) = response_json(
            handle_api_channel_bind(
                axum::extract::State(state.clone()),
                None,
                axum::Json(ChannelBindBody {
                    channel_type: "telegram".to_string(),
                    alias: "alerts".to_string(),
                    identity: "123456789".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(
            json.to_string().contains("telegram.other"),
            "the operator has to be told which group owns the key, got: {json}"
        );
        assert!(
            state.config.read().peer_groups["telegram_alerts"]
                .external_peers
                .is_empty(),
            "a refused bind must not write into another channel's group"
        );
    }

    /// The inverse: an unrelated `ignore` must not block a legitimate bind, or
    /// the deny check would have turned the endpoint off.
    #[tokio::test]
    async fn channel_bind_still_binds_an_unignored_identity() {
        use zeroclaw_config::multi_agent::{PeerGroupConfig, PeerUsername};
        use zeroclaw_config::providers::ChannelRef;

        let tmp = tempfile::tempdir().unwrap();
        let mut config = config_with_telegram_alias(&tmp, "alerts");
        config.peer_groups.insert(
            "telegram_alerts_blocked".to_string(),
            PeerGroupConfig {
                channel: ChannelRef::new("telegram.alerts".to_string()),
                ignore: vec![PeerUsername::new("999999999".to_string())],
                ..PeerGroupConfig::default()
            },
        );
        let state = test_state(config);

        let (status, _json) = response_json(
            handle_api_channel_bind(
                axum::extract::State(state.clone()),
                None,
                axum::Json(ChannelBindBody {
                    channel_type: "telegram".to_string(),
                    alias: "alerts".to_string(),
                    identity: "123456789".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert!(
            state
                .config
                .read()
                .channel_external_peers("telegram", "alerts")
                .contains(&"123456789".to_string())
        );
    }

    /// The gateway and the RPC path hold separate `Config` copies of one file.
    /// An `ignore` saved through RPC is therefore absent from the gateway's
    /// snapshot, and a bind that trusted that snapshot both missed the deny and
    /// wrote the stale policy table back over it. The handler re-reads the
    /// persisted `peer_groups` under the write lock instead, so the deny is
    /// authoritative for the check and survives the save.
    #[tokio::test]
    async fn channel_bind_refuses_a_deny_only_the_other_handle_has_saved() {
        let tmp = tempfile::tempdir().unwrap();
        let gateway_config = config_with_telegram_alias(&tmp, "alerts");
        let config_path = gateway_config.config_path.clone();

        // What the RPC handle persisted after the gateway took its snapshot.
        // The gateway's own copy still has no `peer_groups` at all.
        std::fs::write(
            &config_path,
            "[peer_groups.telegram_alerts]\n\
             channel = \"telegram.alerts\"\n\
             ignore = [\"999999999\"]\n",
        )
        .unwrap();

        let state = test_state(gateway_config);
        assert!(
            state.config.read().peer_groups.is_empty(),
            "the gateway snapshot must start stale for this to test anything"
        );

        let (status, _json) = response_json(
            handle_api_channel_bind(
                axum::extract::State(state.clone()),
                None,
                axum::Json(ChannelBindBody {
                    channel_type: "telegram".to_string(),
                    alias: "alerts".to_string(),
                    identity: "999999999".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(
            status,
            StatusCode::BAD_REQUEST,
            "a deny this handle had not seen must still refuse the bind"
        );
        let on_disk = std::fs::read_to_string(&config_path).unwrap();
        assert!(
            on_disk.contains("999999999"),
            "the persisted deny must survive, got:\n{on_disk}"
        );
    }

    /// The other half: an unrelated bind still succeeds, and it must not drop
    /// the deny the gateway's snapshot never carried.
    #[tokio::test]
    async fn channel_bind_preserves_a_deny_saved_by_the_other_handle() {
        let tmp = tempfile::tempdir().unwrap();
        let gateway_config = config_with_telegram_alias(&tmp, "alerts");
        let config_path = gateway_config.config_path.clone();

        // `sops_dir` stands in for any unrelated key another writer persisted
        // after this handle took its snapshot. A full `save` of the stale
        // snapshot would drop it along with the deny.
        std::fs::write(
            &config_path,
            "sops_dir = \"/srv/written-by-the-other-handle\"\n\
             \n\
             [peer_groups.telegram_alerts]\n\
             channel = \"telegram.alerts\"\n\
             ignore = [\"999999999\"]\n",
        )
        .unwrap();

        let state = test_state(gateway_config);
        let (status, _json) = response_json(
            handle_api_channel_bind(
                axum::extract::State(state.clone()),
                None,
                axum::Json(ChannelBindBody {
                    channel_type: "telegram".to_string(),
                    alias: "alerts".to_string(),
                    identity: "123456789".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        let on_disk = std::fs::read_to_string(&config_path).unwrap();
        assert!(
            on_disk.contains("123456789"),
            "the new grant must be persisted, got:\n{on_disk}"
        );
        assert!(
            on_disk.contains("999999999"),
            "the other handle's deny must not be erased, got:\n{on_disk}"
        );
        assert!(
            on_disk.contains("/srv/written-by-the-other-handle"),
            "an unrelated persisted key must survive the bind, got:\n{on_disk}"
        );
    }

    #[tokio::test]
    async fn channel_bind_reports_the_custom_group_it_actually_wrote() {
        use zeroclaw_config::multi_agent::PeerGroupConfig;
        use zeroclaw_config::providers::ChannelRef;

        // The writer selects its target by the group's `channel` field, so a
        // custom key is a legitimate destination. Reporting the conventional
        // `telegram_alerts` would name a group that does not exist, and an
        // operator following the response would edit the wrong block.
        let tmp = tempfile::tempdir().unwrap();
        let mut config = config_with_telegram_alias(&tmp, "alerts");
        config.peer_groups.insert(
            "ops".to_string(),
            PeerGroupConfig {
                channel: ChannelRef::new("telegram.alerts".to_string()),
                ..PeerGroupConfig::default()
            },
        );
        let state = test_state(config);

        let bind = |state: AppState| async move {
            response_json(
                handle_api_channel_bind(
                    axum::extract::State(state),
                    None,
                    axum::Json(ChannelBindBody {
                        channel_type: "telegram".to_string(),
                        alias: "alerts".to_string(),
                        identity: "123456789".to_string(),
                    }),
                )
                .await,
            )
            .await
        };

        let (status, json) = bind(state.clone()).await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(json["saved"], true);
        assert_eq!(
            json["group"], "ops",
            "the response names the group the identity was written into"
        );
        assert!(
            state
                .config
                .read()
                .peer_groups
                .get("ops")
                .expect("the custom group is the destination")
                .external_peers
                .iter()
                .any(|peer| peer.as_str() == "123456789")
        );
        assert!(
            !state
                .config
                .read()
                .peer_groups
                .contains_key("telegram_alerts"),
            "the conventional group was never created, which is why naming it would mislead"
        );

        // The idempotent answer has to name the same real group.
        let (status, json) = bind(state.clone()).await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(json["already_bound"], true);
        assert_eq!(json["group"], "ops");
    }

    #[tokio::test]
    async fn channel_bind_clears_generation_before_returning_success() {
        let tmp = tempfile::tempdir().unwrap();
        let config = config_with_telegram_alias(&tmp, "alerts");
        config.save().await.unwrap();
        let mut state = test_state(config);
        let clears = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let clear_count = Arc::clone(&clears);
        let mut reload_rx = install_channel_generation_controls(
            &mut state,
            Arc::new(move || {
                clear_count.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            }),
        );

        let (status, json) = response_json(
            handle_api_channel_bind(
                axum::extract::State(state),
                None,
                axum::Json(ChannelBindBody {
                    channel_type: "telegram".to_string(),
                    alias: "alerts".to_string(),
                    identity: "123456789".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK, "{json}");
        assert_eq!(json["saved"], true);
        assert_eq!(clears.load(std::sync::atomic::Ordering::SeqCst), 1);
        assert!(!*reload_rx.borrow_and_update());
    }

    #[tokio::test]
    async fn delete_plan_reports_authoritative_agent_lifecycle_blocker() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = temp_config(&tmp);
        config.create_map_key("agents", "busy").unwrap();
        let state = test_state(config);
        let _reservation = state
            .agent_lifecycle
            .reserve_admission("busy")
            .expect("reserve in-flight admission");

        let (status, json) = response_json(
            handle_delete_plan(
                axum::extract::State(state),
                axum::extract::Query(MapKeyQuery {
                    path: "agents".to_string(),
                    key: "busy".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK, "{json}");
        assert_eq!(json["allowed"], false);
        assert!(json["blockers"].as_array().unwrap().iter().any(|blocker| {
            blocker["raw_value"]
                .as_str()
                .is_some_and(|message| message.contains("in-flight session admission"))
        }));
    }

    #[tokio::test]
    async fn channel_bind_save_failure_does_not_report_success_or_publish() {
        let tmp = tempfile::tempdir().unwrap();
        let mut config = config_with_telegram_alias(&tmp, "alerts");
        let blocked_parent = tmp.path().join("not-a-directory");
        std::fs::write(&blocked_parent, b"preserve").unwrap();
        config.config_path = blocked_parent.join("config.toml");
        let state = test_state(config);

        let (status, json) = response_json(
            handle_api_channel_bind(
                axum::extract::State(state.clone()),
                None,
                axum::Json(ChannelBindBody {
                    channel_type: "telegram".to_string(),
                    alias: "alerts".to_string(),
                    identity: "123456789".to_string(),
                }),
            )
            .await,
        )
        .await;

        assert!(status.is_server_error(), "{json}");
        assert_ne!(json.get("saved"), Some(&serde_json::Value::Bool(true)));
        assert!(
            state
                .config
                .read()
                .channel_external_peers("telegram", "alerts")
                .is_empty(),
            "a failed save must not publish the bound peer"
        );
        assert!(
            !state
                .pending_reload
                .load(std::sync::atomic::Ordering::Relaxed)
        );
        assert_eq!(std::fs::read(&blocked_parent).unwrap(), b"preserve");
    }

    #[tokio::test]
    async fn refresh_context_window_allows_slow_response_and_forwards_api_key() {
        use http_body_util::BodyExt;
        use tower::ServiceExt;
        use wiremock::matchers::{header, method, path};
        use wiremock::{Mock, MockServer, ResponseTemplate};

        let mock = MockServer::start().await;

        Mock::given(method("GET"))
            .and(path("/models"))
            .and(header("authorization", "Bearer test-api-key-123"))
            .respond_with(
                ResponseTemplate::new(200)
                    .set_delay(std::time::Duration::from_millis(3_100))
                    .set_body_json(serde_json::json!({
                        "data": [{
                            "id": "llama-3.1-70b",
                            "context_length": 4096
                        }]
                    })),
            )
            .expect(1)
            .mount(&mock)
            .await;

        let (_tmp, path) = temp_config_path();
        let mut cfg = zeroclaw_config::schema::Config {
            config_path: path.clone(),
            ..Default::default()
        };
        cfg.providers.models.groq.insert(
            "test".to_string(),
            zeroclaw_config::schema::GroqModelProviderConfig {
                base: zeroclaw_config::schema::ModelProviderConfig {
                    model: Some("llama-3.1-70b".into()),
                    api_key: Some("test-api-key-123".into()),
                    uri: Some(mock.uri()),
                    ..Default::default()
                },
            },
        );
        cfg.save().await.expect("initial save");

        let state = crate::api::test_state(cfg);

        let app = axum::Router::new()
            .route(
                "/api/config/model-providers/{type}/{alias}/refresh-context-window",
                axum::routing::post(handle_refresh_context_window),
            )
            .with_state(state);

        let response = app
            .oneshot(
                axum::http::Request::builder()
                    .method("POST")
                    .uri("/api/config/model-providers/groq/test/refresh-context-window")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();

        assert!(
            response.status().is_success(),
            "expected 200, got {}",
            response.status()
        );

        let body = response
            .into_body()
            .collect()
            .await
            .expect("response body")
            .to_bytes();
        let body_str = String::from_utf8(body.to_vec()).unwrap();
        let json: serde_json::Value = serde_json::from_str(&body_str).unwrap();

        assert_eq!(json["path"], "providers.models.groq.test");
        assert_eq!(json["context_window"], 4096);
        assert!(
            !body_str.contains("test-api-key-123"),
            "API key leaked in response body"
        );

        let requests = mock.received_requests().await.unwrap();
        assert_eq!(requests.len(), 1, "expected exactly one request to mock");
        assert_eq!(
            requests[0]
                .headers
                .get("authorization")
                .unwrap()
                .to_str()
                .unwrap(),
            "Bearer test-api-key-123"
        );
    }
}
