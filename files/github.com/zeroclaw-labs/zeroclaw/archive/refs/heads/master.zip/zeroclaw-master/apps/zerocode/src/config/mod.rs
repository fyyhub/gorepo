//! Local zerocode client configuration: theme and keybindings.
//! Always read from the local `<config_dir>/zerocode-config.toml`, independent
//! of the connection target. Layering: defaults -> file -> `ZEROCODE_*` env.

pub mod keybindings;

use std::collections::HashMap;
use std::io::ErrorKind;
use std::path::{Path, PathBuf};

use anyhow::{Context, Result, bail};
use serde::{Deserialize, Serialize};

use crate::keymap::{ChatTabAction, Chord, GlobalAction, overrides::OverrideTable};
use crate::theme::{self, Theme};

const FILE_NAME: &str = "zerocode-config.toml";
const ENV_PREFIX: &str = "ZEROCODE_";
const ENV_SEP: &str = "__";
/// Advisory lock identity for every read-modify-write of [`FILE_NAME`].
///
/// Left in the config directory after release. Deleting it would let a later
/// process lock a different inode while a holder of this one still has the
/// old file open.
const CONFIG_LOCK_FILE: &str = ".zerocode-config.lock";
/// A config rewrite is a few filesystem calls. The bound exists so a wedged
/// holder surfaces as an error instead of hanging login or startup renewal.
const CONFIG_LOCK_WAIT: std::time::Duration = std::time::Duration::from_secs(10);
const CONFIG_LOCK_POLL: std::time::Duration = std::time::Duration::from_millis(25);

#[cfg(test)]
std::thread_local! {
    static MIGRATION_LOCK_WAIT_OVERRIDE: std::cell::Cell<Option<std::time::Duration>> =
        const { std::cell::Cell::new(None) };
}

fn migration_lock_wait() -> std::time::Duration {
    #[cfg(test)]
    if let Some(wait) = MIGRATION_LOCK_WAIT_OVERRIDE.get() {
        return wait;
    }
    CONFIG_LOCK_WAIT
}

#[cfg(test)]
pub(crate) fn set_migration_lock_wait_for_test(wait: Option<std::time::Duration>) {
    MIGRATION_LOCK_WAIT_OVERRIDE.set(wait);
}

#[cfg(test)]
pub(crate) struct TestConfigLock {
    _inner: ConfigWriteLock,
}

#[cfg(test)]
pub(crate) fn hold_config_lock_for_test(config_dir: &Path) -> Result<TestConfigLock> {
    Ok(TestConfigLock {
        _inner: ConfigWriteLock::acquire(config_dir)?,
    })
}

/// One or more chords bound to an action. Accepts a bare string (one
/// chord) or an array on the wire; always serialized back as an array.
#[derive(Debug, Clone, Eq, PartialEq, Serialize, Deserialize)]
#[serde(untagged)]
enum ChordSpec {
    One(Chord),
    Many(Vec<Chord>),
}

impl ChordSpec {
    fn as_slice(&self) -> &[Chord] {
        match self {
            Self::One(c) => std::slice::from_ref(c),
            Self::Many(cs) => cs,
        }
    }

    fn into_vec(self) -> Vec<Chord> {
        match self {
            Self::One(c) => vec![c],
            Self::Many(cs) => cs,
        }
    }
}

fn migrate_legacy_ctrl_bindings(value: &mut toml::Value) -> bool {
    let Some(rows) = value.as_table_mut() else {
        return false;
    };
    let mut migrated = false;
    for (_, value) in rows.iter_mut() {
        migrated |= migrate_legacy_ctrl_value(value);
    }
    migrated
}

fn migrate_legacy_ctrl_value(value: &mut toml::Value) -> bool {
    match value {
        toml::Value::String(wire) => migrate_legacy_ctrl_wire(wire),
        toml::Value::Array(values) => {
            let mut migrated = false;
            for value in values {
                migrated |= migrate_legacy_ctrl_value(value);
            }
            migrated
        }
        _ => false,
    }
}

fn migrate_legacy_ctrl_wire(wire: &mut String) -> bool {
    let segments: Vec<&str> = wire.trim().split('+').collect();
    if segments.len() < 2 {
        return false;
    }
    let Some(key) = segments.last() else {
        return false;
    };
    let replacement = if matches!(
        key.to_ascii_lowercase().as_str(),
        "c" | "g" | "k" | "n" | "s" | "f1"
    ) {
        "control"
    } else {
        "primary"
    };
    let mut found_legacy = false;
    let migrated = segments
        .iter()
        .map(|segment| {
            if segment.eq_ignore_ascii_case("ctrl") {
                found_legacy = true;
                replacement
            } else {
                segment
            }
        })
        .collect::<Vec<_>>()
        .join("+");
    if found_legacy && migrated != wire.trim() {
        *wire = migrated;
        true
    } else {
        false
    }
}

fn migrate_legacy_help_binding(rows: &mut HashMap<String, ChordSpec>) -> bool {
    use crossterm::event::{KeyCode, KeyModifiers};

    let key = GlobalAction::Help.action_key();
    let legacy = [
        Chord::char('?'),
        Chord::key(KeyCode::F(1)),
        Chord::with(KeyCode::F(1), KeyModifiers::CONTROL),
    ];
    let Some(spec) = rows.get(&key) else {
        return false;
    };
    if spec.as_slice() != legacy {
        return false;
    }

    rows.insert(key, ChordSpec::Many(GlobalAction::Help.default_chords()));
    true
}

fn migrate_legacy_copy_binding(rows: &mut HashMap<String, ChordSpec>) -> bool {
    let key = ChatTabAction::CopySelection.action_key();
    let Some(ChordSpec::Many(chords)) = rows.get(&key) else {
        return false;
    };
    if chords.as_slice() != [Chord::char('y')] {
        return false;
    }

    rows.insert(
        key,
        ChordSpec::Many(ChatTabAction::CopySelection.default_chords()),
    );
    true
}

fn migrate_legacy_chat_jump_binding(
    rows: &mut HashMap<String, ChordSpec>,
    action: ChatTabAction,
    legacy: Chord,
) -> bool {
    let key = action.action_key();
    let Some(ChordSpec::Many(chords)) = rows.get(&key) else {
        return false;
    };
    if chords.as_slice() != std::slice::from_ref(&legacy) {
        return false;
    }

    rows.insert(key, ChordSpec::Many(action.default_chords()));
    true
}

/// The `[theme]` section.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct ThemeSection {
    #[serde(default = "default_theme")]
    pub name: String,
    /// Per-agent theme overrides keyed by agent alias. When the Code or Chat
    /// pane is focused on an agent listed here, that agent's theme replaces
    /// the base `name` while the pane is active. Sparse: agents not listed use
    /// the base theme.
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub agent_override: HashMap<String, AgentThemeOverride>,
}

/// One `[theme.agent_override.<alias>]` entry. Mirrors the `{ name }` shape of
/// the base `[theme]` section so the resolver path is identical.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct AgentThemeOverride {
    pub name: String,
}

impl Default for ThemeSection {
    fn default() -> Self {
        Self {
            name: default_theme(),
            agent_override: HashMap::new(),
        }
    }
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub(crate) struct ConnectionSection {
    #[serde(default, skip_serializing_if = "WssSection::is_empty")]
    pub wss: WssSection,
    /// OIDC logins keyed by normalized WSS URL. Credentials never follow a
    /// different --connect destination, even on the same hostname.
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub logins: HashMap<String, OidcLogin>,
}

impl ConnectionSection {
    fn is_empty(&self) -> bool {
        self.wss.is_empty() && self.logins.is_empty()
    }

    /// A saved login, or any other destination once logins exist, owns its own
    /// credential files. The legacy manual connection does not.
    pub(crate) fn uses_scoped_credentials(&self, selected: Option<&str>) -> bool {
        selected.is_some_and(|uri| {
            self.logins.contains_key(uri)
                || (!self.logins.is_empty()
                    && !same_wss_destination(Some(uri), self.wss.uri.as_deref()))
        })
    }
}

/// The canonical WSS destination, shared with login so a stored spelling and a
/// startup spelling of the same daemon compare equal. Not a user-facing error:
/// callers add their own message.
pub(crate) fn canonical_wss_target(target: &str) -> Result<String> {
    let target = if target.contains("://") {
        target.to_string()
    } else {
        // Remember an explicit :443 before URL normalization removes it.
        let url = url::Url::parse(&format!("wss://{target}")).context("invalid WSS target")?;
        let authority = target.split('/').next().unwrap_or(target);
        let explicit_port = authority
            .rsplit_once(':')
            .is_some_and(|(_, tail)| tail.parse::<u16>().is_ok());
        if explicit_port {
            url.to_string()
        } else {
            let mut url = url;
            url.set_port(Some(9781))
                .map_err(|()| anyhow::Error::msg("invalid WSS target"))?;
            url.to_string()
        }
    };
    let url = url::Url::parse(&target).context("invalid WSS target")?;
    if url.scheme() != "wss"
        || url.host_str().is_none()
        || !url.username().is_empty()
        || url.password().is_some()
        || url.query().is_some()
        || url.fragment().is_some()
    {
        bail!("invalid WSS target");
    }
    Ok(url.to_string())
}

/// True when both sides name the same daemon, including equivalent spellings
/// such as a missing trailing slash. An unparseable side falls back to an
/// exact compare so two different invalid strings are not treated as one
/// destination.
fn same_wss_destination(left: Option<&str>, right: Option<&str>) -> bool {
    match (left, right) {
        (Some(left), Some(right)) => {
            match (canonical_wss_target(left), canonical_wss_target(right)) {
                (Ok(canonical_left), Ok(canonical_right)) => canonical_left == canonical_right,
                _ => left == right,
            }
        }
        (None, None) => true,
        _ => false,
    }
}

#[derive(Debug)]
pub(crate) struct InvalidSavedLogin(anyhow::Error);

impl std::fmt::Display for InvalidSavedLogin {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&crate::i18n::t("zc-config-invalid-saved-login"))
    }
}
impl std::error::Error for InvalidSavedLogin {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        Some(self.0.as_ref())
    }
}

/// The persisted login is the credential authority for this exact URL. The
/// active `wss.uri` selects it; no copy of its token is written to `wss`.
#[derive(Clone, Serialize, Deserialize)]
pub(crate) struct OidcLogin {
    pub auth_provider: String,
    pub auth_token: String,
    pub enroll_url: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub expires_at: Option<i64>,
    #[serde(default)]
    pub tls: WssTlsSection,
    #[serde(default)]
    pub gateway_tls: WssTlsSection,
}

impl std::fmt::Debug for OidcLogin {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("OidcLogin")
            .field("auth_provider", &self.auth_provider)
            .field("auth_token", &"[REDACTED]")
            .field("enroll_url", &self.enroll_url)
            .field("expires_at", &self.expires_at)
            .field("tls", &self.tls)
            .field("gateway_tls", &self.gateway_tls)
            .finish()
    }
}

impl ConnectionSection {
    pub fn wss_for(&self, uri: Option<&str>) -> WssSection {
        let mut wss = self.wss.clone();
        let uri = uri.or(wss.uri.as_deref()).map(str::to_owned);
        if let Some(login) = uri.as_ref().and_then(|uri| self.logins.get(uri)) {
            wss.auth_token = Some(login.auth_token.clone());
            wss.auth_token_file = None;
            wss.auth_provider = Some(login.auth_provider.clone());
            wss.enroll_url = Some(login.enroll_url.clone());
            wss.tls = login.tls.clone();
            // A direct URL login must not inherit another daemon's relay.
            wss.relay_url = None;
            wss.relay_node = None;
        } else if !self.logins.is_empty()
            && !same_wss_destination(uri.as_deref(), self.wss.uri.as_deref())
        {
            // Compare canonical destinations. Startup normalizes the selected
            // URL, while a manual connection may still be stored as
            // `wss://host:9781` rather than `wss://host:9781/`. A spelling
            // difference is not a different daemon and must not drop the
            // manual token, provider, or TLS files.
            wss.auth_token = None;
            wss.auth_token_file = None;
            wss.auth_provider = None;
            wss.enroll_url = None;
            wss.tls = WssTlsSection::default();
            wss.relay_url = None;
            wss.relay_node = None;
        }
        wss.uri = uri;
        wss
    }
}

/// Hand-written so `auth_token` cannot reach a log, a panic message or a
/// diagnostic dump. Every other field is ordinary connection metadata and is
/// printed as usual.
impl std::fmt::Debug for WssSection {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("WssSection")
            .field("uri", &self.uri)
            .field(
                "auth_token",
                &self.auth_token.as_ref().map(|_| "[REDACTED]"),
            )
            .field("auth_token_file", &self.auth_token_file)
            .field("auth_provider", &self.auth_provider)
            .field("tls", &self.tls)
            .field("relay_url", &self.relay_url)
            .finish_non_exhaustive()
    }
}

#[derive(Clone, Default, Serialize, Deserialize)]
pub(crate) struct WssSection {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub uri: Option<String>,
    /// Bearer presented as `auth_token` in the initialize handshake (a
    /// gateway pairing token, or an OIDC access token together with
    /// `auth_provider`). Remote daemons require it since the RFC 7141
    /// enforcement boundary. The `ZEROCLAW_AUTH_TOKEN` environment
    /// variable overrides this value, so the token can stay out of the
    /// config file entirely.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub auth_token: Option<String>,
    /// Path to a file holding the bearer, as an alternative to writing it
    /// into this file. The file must be readable by its owner only; a
    /// group- or world-readable one is refused rather than used. Takes
    /// precedence over `auth_token` and yields to `ZEROCLAW_AUTH_TOKEN`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub auth_token_file: Option<String>,
    /// Provider selection for `auth_token` (e.g. `oidc.corp`). Defaults
    /// to the daemon's `native` pairing provider when unset.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub auth_provider: Option<String>,
    /// Gateway HTTP origin for interactive OIDC enrollment (e.g.
    /// `https://gateway.example.com:9090`). Used only when
    /// `auth_provider` names an `oidc.<alias>` provider and no
    /// `auth_token` is available: zerocode then runs the device grant
    /// through the gateway's enrollment API before connecting. The
    /// token is held for the session only, never stored.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub enroll_url: Option<String>,
    #[serde(default, skip_serializing_if = "WssTlsSection::is_empty")]
    pub tls: WssTlsSection,
    /// Reach the daemon through a nominated relay at this `host:port` instead of
    /// connecting to `uri` directly.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub relay_url: Option<String>,
    /// Node-id of the target daemon to request from the relay.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub relay_node: Option<String>,
    /// How many times to try the direct address before falling back to the relay
    /// (default 2). Only relevant when both a direct address and a relay exist.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub direct_attempts: Option<u32>,
    /// Per-attempt timeout, in seconds, for a direct connect before falling back
    /// to the relay (default 3).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub direct_timeout_secs: Option<u64>,
    /// While connected through the relay, how often (seconds) to re-probe the
    /// direct address and migrate back when it returns (default 30; 0 disables).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reprobe_secs: Option<u64>,
}

impl WssSection {
    fn is_empty(&self) -> bool {
        self.uri.is_none()
            && self.tls.is_empty()
            && self.relay_url.is_none()
            && self.relay_node.is_none()
            && self.direct_attempts.is_none()
            && self.direct_timeout_secs.is_none()
            && self.reprobe_secs.is_none()
            && self.auth_token.is_none()
            && self.auth_token_file.is_none()
            && self.auth_provider.is_none()
            && self.enroll_url.is_none()
    }
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub(crate) struct WssTlsSection {
    #[serde(default, skip_serializing_if = "is_false")]
    pub skip_verify: bool,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub skip_verify_routes: Vec<String>,
    /// PEM CA certificate used to verify the daemon (mutual TLS). When set, the
    /// server certificate is verified against this CA instead of the system roots.
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub ca_cert_path: String,
    /// PEM client certificate presented to the daemon (mutual TLS).
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub client_cert_path: String,
    /// PEM client private key for `client_cert_path`.
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub client_key_path: String,
}

impl WssTlsSection {
    pub fn route_acked(&self, uri: &str) -> bool {
        self.skip_verify_routes.iter().any(|r| r == uri)
    }

    fn is_empty(&self) -> bool {
        !self.skip_verify
            && self.skip_verify_routes.is_empty()
            && self.ca_cert_path.is_empty()
            && self.client_cert_path.is_empty()
            && self.client_key_path.is_empty()
    }
}

fn is_false(b: &bool) -> bool {
    !*b
}

/// Shared shell dock sizing bounds.
pub(crate) const SIDEBAR_WIDTH_MIN: u16 = 18;
pub(crate) const SIDEBAR_WIDTH_MAX: u16 = 40;
pub(crate) const SIDEBAR_SESSIONS_PERCENT_MIN: u16 = 20;
pub(crate) const SIDEBAR_SESSIONS_PERCENT_MAX: u16 = 80;
pub(crate) const SIDEBAR_QUEUE_PERCENT_MIN: u16 = 1;
pub(crate) const SIDEBAR_QUEUE_PERCENT_MAX: u16 = 99;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum SidebarSide {
    Left,
    Right,
}

impl SidebarSide {
    pub(crate) fn as_str(self) -> &'static str {
        match self {
            Self::Left => "left",
            Self::Right => "right",
        }
    }

    pub(crate) fn opposite(self) -> Self {
        match self {
            Self::Left => Self::Right,
            Self::Right => Self::Left,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct SidebarSection {
    /// Whether the Sessions dock section is shown. Toggled at runtime and persisted.
    #[serde(default = "default_sidebar_visible")]
    pub visible: bool,
    /// Dock section preferences only; Plan content and lifecycle stay pane-owned.
    #[serde(default = "default_true")]
    pub queue_visible: bool,
    #[serde(default = "default_true")]
    pub plan_visible: bool,
    /// Dock width in terminal columns, clamped at the shell boundary.
    #[serde(default = "default_sidebar_width")]
    pub width: u16,
    /// Explicit dock side. `None` preserves the legacy Todo location
    /// migration until the user switches the dock explicitly.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub side: Option<SidebarSide>,
    /// Percentage of the dock body allocated to Sessions when Plan is also
    /// visible. Clamped at the shell boundary.
    #[serde(default = "default_sidebar_sessions_percent")]
    pub sessions_percent: u16,
    /// Percentage of the lower dock region allocated to Queue while Plan is
    /// visible. Clamped at the shell boundary.
    #[serde(default = "default_sidebar_queue_percent")]
    pub queue_percent: u16,
}

impl Default for SidebarSection {
    fn default() -> Self {
        Self {
            visible: default_sidebar_visible(),
            queue_visible: true,
            plan_visible: true,
            width: default_sidebar_width(),
            side: None,
            sessions_percent: default_sidebar_sessions_percent(),
            queue_percent: default_sidebar_queue_percent(),
        }
    }
}

// ── Todo tracker ──────────────────────────────────────────────────────────────

/// Where the todo tracker renders inside the Code pane.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "lowercase")]
pub(crate) enum TodoTrackerLocation {
    Bottom,
    Left,
    #[default]
    Right,
}

/// The `[todotracker]` section.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct TodoTrackerSection {
    #[serde(default = "default_true")]
    pub enabled: bool,
    #[serde(default)]
    pub enabled_at_start: bool,
    #[serde(default)]
    pub location: TodoTrackerLocation,
    #[serde(default = "default_todotracker_width")]
    pub width: u16,
    #[serde(default = "default_todotracker_max_height")]
    pub max_height: u16,
}

impl Default for TodoTrackerSection {
    fn default() -> Self {
        Self {
            enabled: true,
            enabled_at_start: false,
            location: TodoTrackerLocation::Right,
            width: default_todotracker_width(),
            max_height: default_todotracker_max_height(),
        }
    }
}

fn default_sidebar_visible() -> bool {
    true
}

fn default_sidebar_width() -> u16 {
    24
}

fn default_sidebar_sessions_percent() -> u16 {
    60
}

fn default_sidebar_queue_percent() -> u16 {
    50
}

impl TodoTrackerSection {
    /// Legacy dimensions remain readable for compatibility, but the shell's
    /// sidebar settings now own geometry. They cannot invalidate Plan toggles.
    pub(crate) fn resolve(&self) -> TodoTrackerSettings {
        TodoTrackerSettings {
            enabled: self.enabled,
            enabled_at_start: self.enabled_at_start,
            location: match self.location {
                TodoTrackerLocation::Bottom => TodoLocation::Bottom,
                TodoTrackerLocation::Left => TodoLocation::Left,
                TodoTrackerLocation::Right => TodoLocation::Right,
            },
            width: self.width.max(1),
            max_height: self.max_height.max(1),
        }
    }
}

/// Where the todo tracker renders, as consumed by the
/// [`TodoTracker`](crate::todo_tracker::TodoTracker) widget. This is the
/// runtime mirror of [`TodoTrackerLocation`] (the serde section enum);
/// keeping them distinct lets the widget stay independent of the on-disk
/// serialization shape.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum TodoLocation {
    Bottom,
    Left,
    Right,
}

/// Runtime `[todotracker]` settings, resolved from the config section by
/// [`ZerocodeConfig::resolve_todo_tracker`]. Values are validated at that
/// boundary, so downstream consumers can trust them as-is.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct TodoTrackerSettings {
    pub enabled: bool,
    pub enabled_at_start: bool,
    pub location: TodoLocation,
    pub width: u16,
    pub max_height: u16,
}

impl Default for TodoTrackerSettings {
    fn default() -> Self {
        Self {
            enabled: true,
            enabled_at_start: false,
            location: TodoLocation::Right,
            width: default_todotracker_width(),
            max_height: default_todotracker_max_height(),
        }
    }
}

// ── Default helpers ───────────────────────────────────────────────────────────

fn default_true() -> bool {
    true
}

fn default_todotracker_width() -> u16 {
    32
}

fn default_todotracker_max_height() -> u16 {
    5
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct ZerocodeConfig {
    #[serde(default = "default_locale")]
    pub locale: Option<String>,
    #[serde(default)]
    pub theme: ThemeSection,
    #[serde(default, skip_serializing_if = "ConnectionSection::is_empty")]
    pub connection: ConnectionSection,
    #[serde(default)]
    pub sidebar: SidebarSection,
    /// Sparse keybinding overrides keyed `"<tag>.<variant>"`. Absent
    /// entries fall back to compile-time defaults.
    #[serde(default)]
    keybindings: HashMap<String, ChordSpec>,
    #[serde(default)]
    pub todotracker: TodoTrackerSection,
}

impl Default for ZerocodeConfig {
    fn default() -> Self {
        Self {
            locale: default_locale(),
            theme: ThemeSection::default(),
            connection: ConnectionSection::default(),
            sidebar: SidebarSection::default(),
            keybindings: HashMap::new(),
            todotracker: TodoTrackerSection::default(),
        }
    }
}

fn default_locale() -> Option<String> {
    Some("en".to_string())
}

fn default_theme() -> String {
    theme::DEFAULT_THEME_NAME.to_string()
}

impl ZerocodeConfig {
    pub fn resolve_theme(&self) -> Result<Theme> {
        let name = self.theme.name.trim();
        if name.is_empty() {
            return theme::theme_by_name(theme::DEFAULT_THEME_NAME)
                .context("default theme missing from registry");
        }
        // Unknown theme name (e.g. a config written by a newer build, or a
        // typo) falls back to the inherit-shell `terminal` theme rather than
        // aborting the TUI. The fallback is always present in the registry.
        Ok(theme::theme_by_name(name).unwrap_or_else(theme::fallback_theme))
    }

    pub fn resolve_agent_theme(&self, alias: &str) -> Result<Option<Theme>> {
        let Some(over) = self.theme.agent_override.get(alias) else {
            return Ok(None);
        };
        let name = over.name.trim();
        if name.is_empty() {
            return Ok(None);
        }
        Ok(Some(
            theme::theme_by_name(name).unwrap_or_else(theme::fallback_theme),
        ))
    }

    /// Resolve the stored keybindings into a validated override table.
    /// An empty section yields an empty table (compile-time defaults).
    pub fn resolve_keybindings(&self) -> Result<OverrideTable> {
        let rows: HashMap<String, Vec<Chord>> = self
            .keybindings
            .iter()
            .map(|(k, v)| (k.clone(), v.clone().into_vec()))
            .collect();
        keybindings::build_override_table(rows)
    }

    /// Aliases that have a `[theme.agent_override.<alias>]` entry. The single
    /// iteration point over the override map so callers never reach into the
    /// section's internals.
    pub fn agent_override_aliases(&self) -> impl Iterator<Item = &str> {
        self.theme.agent_override.keys().map(String::as_str)
    }

    /// The configured override theme name for `alias`, if any. Returns the raw
    /// stored name without validating it against the registry; for a resolved
    /// palette use `resolve_agent_theme`.
    pub fn agent_override_name(&self, alias: &str) -> Option<&str> {
        self.theme
            .agent_override
            .get(alias)
            .map(|o| o.name.as_str())
    }

    pub fn resolve_locale(&self) -> Option<String> {
        self.locale
            .as_deref()
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .map(|s| s.to_string())
    }

    /// Effective dock side, with the legacy Todo location providing the
    /// read-only migration fallback until the user explicitly switches side.
    pub(crate) fn effective_sidebar_side(&self) -> SidebarSide {
        self.sidebar
            .side
            .unwrap_or(match self.todotracker.location {
                TodoTrackerLocation::Left => SidebarSide::Left,
                TodoTrackerLocation::Right | TodoTrackerLocation::Bottom => SidebarSide::Right,
            })
    }

    pub(crate) fn effective_sidebar_width(&self) -> u16 {
        self.sidebar
            .width
            .clamp(SIDEBAR_WIDTH_MIN, SIDEBAR_WIDTH_MAX)
    }

    pub(crate) fn effective_sidebar_sessions_percent(&self) -> u16 {
        self.sidebar
            .sessions_percent
            .clamp(SIDEBAR_SESSIONS_PERCENT_MIN, SIDEBAR_SESSIONS_PERCENT_MAX)
    }

    pub(crate) fn effective_sidebar_queue_percent(&self) -> u16 {
        self.sidebar
            .queue_percent
            .clamp(SIDEBAR_QUEUE_PERCENT_MIN, SIDEBAR_QUEUE_PERCENT_MAX)
    }

    /// Convert the `[todotracker]` section into the runtime settings type
    /// used by [`TodoTracker`](crate::todo_tracker::TodoTracker).
    pub fn resolve_todo_tracker(&self) -> TodoTrackerSettings {
        self.todotracker.resolve()
    }
}

pub(crate) fn config_path(config_dir: &Path) -> PathBuf {
    config_dir.join(FILE_NAME)
}

/// The effective config: on-disk values with `ZEROCODE_*` env overrides
/// applied on top. This is what runtime consumers (sessions, rendering) read.
///
/// Env overrides are process-transient and must never be written back to disk,
/// so anything that *edits and saves* config must use [`load_persisted`]
/// instead — otherwise saving one field would bake an env-injected value for
/// an unrelated field into `zerocode-config.toml`.
pub(crate) fn ensure_and_load(config_dir: &Path) -> Result<ZerocodeConfig> {
    let mut config = load_persisted(config_dir)?;
    apply_env_overrides(&mut config)?;
    Ok(config)
}

/// Resolve the effective `[todotracker]` settings for a session boundary,
/// treating a **present-but-malformed** `[todotracker]` section as an error
/// rather than silently falling back to defaults.
///
/// [`load_persisted`] deliberately tolerates a malformed section (so one bad
/// block cannot blank unrelated config), which means a botched manual edit
/// would otherwise resolve to defaults and silently reset a user's live
/// tracker on restart/switch. This variant re-parses that one section strictly
/// so the caller can preserve the current settings on failure; a *valid* or
/// *absent* section resolves exactly as `ensure_and_load` would, with
/// `ZEROCODE_todotracker__*` overrides applied.
///
/// Legacy numeric dimensions no longer control the dock and do not reject
/// otherwise valid settings. Malformed fields and overrides still fail.
pub(crate) fn resolve_todo_tracker_checked(config_dir: &Path) -> Result<TodoTrackerSettings> {
    let path = config_path(config_dir);
    if path.exists() {
        let doc = load_document(&path)?;
        if let Some(v) = doc.get("todotracker") {
            // Strict parse: a malformed section is an error here, unlike the
            // tolerant `load_persisted` path.
            v.clone()
                .try_into::<TodoTrackerSection>()
                .with_context(|| format!("[todotracker] in {} is malformed", path.display()))?;
        }
    }
    let config = ensure_and_load(config_dir)?;
    Ok(config.resolve_todo_tracker())
}

/// The persisted `[todotracker]` section, parsed **strictly**.
///
/// [`load_persisted`] tolerates a malformed section by substituting defaults so
/// one bad block cannot blank unrelated config. That is right for rendering,
/// but wrong for an *editor*: editing a phantom default and saving it would
/// overwrite the user's unparseable canonical text — the very text they need in
/// order to repair it, on the supported manual-upgrade path. The Config pane
/// uses this instead so it can refuse edits and surface the error.
///
/// `Ok(None)` means the section is absent (a fresh file), which is editable
/// from defaults; `Err` means present-but-malformed.
pub(crate) fn load_persisted_todotracker_strict(
    config_dir: &Path,
) -> Result<Option<TodoTrackerSection>> {
    let path = config_path(config_dir);
    if !path.exists() {
        return Ok(None);
    }
    let doc = load_document(&path)?;
    let Some(v) = doc.get("todotracker") else {
        return Ok(None);
    };
    v.clone()
        .try_into::<TodoTrackerSection>()
        .map(Some)
        .with_context(|| format!("[todotracker] in {} is malformed", path.display()))
}

/// The on-disk config exactly as persisted, with **no** env overrides applied.
/// This is the correct base for read-modify-write edits (the Config pane), so
/// a transient `ZEROCODE_*` value can never leak into the saved file.
pub(crate) fn load_persisted(config_dir: &Path) -> Result<ZerocodeConfig> {
    std::fs::create_dir_all(config_dir)
        .with_context(|| format!("creating config dir {}", config_dir.display()))?;

    let path = config_path(config_dir);
    // Held only when a keybinding migration must rewrite the file. The
    // continue below re-reads under it; a pure read does not take the lock.
    let mut write_lock = None;
    loop {
        if !path.exists() {
            // Another writer may save a real config between the check above and
            // this write, so the default is only ever created, never swapped in
            // over a file that appeared meanwhile.
            let default = ZerocodeConfig::default();
            let body = toml::to_string_pretty(&default).context("serializing default config")?;
            crate::secure_file::create_private_if_absent(&path, body.as_bytes())
                .with_context(|| format!("writing default {}", path.display()))?;
        } else {
            // An existing file may predate the owner-only rule, and reading it
            // does not go through the write funnel.
            crate::secure_file::restrict_to_owner(&path, config_dir)?;
        }

        let mut doc = load_document(&path)?;
        let mut config = ZerocodeConfig::default();
        let mut migrated_keybindings = false;
        if let Some(v) = doc.get("locale").and_then(|v| v.as_str()) {
            let trimmed = v.trim();
            if !trimmed.is_empty() {
                config.locale = Some(trimmed.to_string());
            }
        }
        if let Some(v) = doc.get("theme") {
            match v.clone().try_into::<ThemeSection>() {
                Ok(section) => config.theme = section,
                Err(e) => eprintln!(
                    "zerocode: ignoring [theme] in {} ({e}); using default",
                    path.display()
                ),
            }
        }
        if let Some(v) = doc.get("connection") {
            match v.clone().try_into::<ConnectionSection>() {
                Ok(section) => config.connection = section,
                Err(e) if v.get("logins").is_some() => {
                    return Err(InvalidSavedLogin(e.into()).into());
                }
                Err(e) => eprintln!(
                    "zerocode: ignoring [connection] in {} ({e}); using default",
                    path.display()
                ),
            }
        }
        if let Some(v) = doc.get("sidebar") {
            match v.clone().try_into::<SidebarSection>() {
                Ok(section) => config.sidebar = section,
                Err(e) => eprintln!(
                    "zerocode: ignoring [sidebar] in {} ({e}); using default",
                    path.display()
                ),
            }
        }
        if let Some(v) = doc.get("keybindings") {
            let mut migrated_value = v.clone();
            let migrated_legacy = migrate_legacy_ctrl_bindings(&mut migrated_value);
            if migrated_legacy {
                // Rewrite legacy spellings before parsing the rows. A malformed,
                // unrelated row must not leave otherwise valid legacy values in
                // the file indefinitely; the tolerant loader still falls back to
                // defaults for the malformed section below.
                doc.insert("keybindings".to_string(), migrated_value.clone());
                migrated_keybindings = true;
            }
            match migrated_value
                .clone()
                .try_into::<HashMap<String, ChordSpec>>()
            {
                Ok(mut rows) => {
                    if migrate_legacy_help_binding(&mut rows) {
                        let key = GlobalAction::Help.action_key();
                        let value = toml::Value::try_from(
                            rows.get(&key)
                                .expect("migrated Help binding remains present")
                                .clone(),
                        )
                        .context("serializing migrated Help binding")?;
                        doc.get_mut("keybindings")
                            .and_then(toml::Value::as_table_mut)
                            .expect("parsed keybindings remain a table")
                            .insert(key, value);
                        migrated_keybindings = true;
                    }
                    if migrate_legacy_copy_binding(&mut rows) {
                        let key = ChatTabAction::CopySelection.action_key();
                        let value = toml::Value::try_from(ChordSpec::Many(
                            ChatTabAction::CopySelection.default_chords(),
                        ))
                        .context("serializing migrated Copy binding")?;
                        let bindings = doc
                            .get_mut("keybindings")
                            .and_then(toml::Value::as_table_mut)
                            .context("accessing parsed keybindings table")?;
                        bindings.insert(key, value);
                        migrated_keybindings = true;
                    }
                    for (action, legacy) in [
                        (ChatTabAction::JumpStart, Chord::char('g')),
                        (ChatTabAction::JumpEnd, Chord::char('G')),
                    ] {
                        if !migrate_legacy_chat_jump_binding(&mut rows, action, legacy) {
                            continue;
                        }
                        let key = action.action_key();
                        let value = toml::Value::try_from(ChordSpec::Many(action.default_chords()))
                            .context("serializing migrated chat jump binding")?;
                        let bindings = doc
                            .get_mut("keybindings")
                            .and_then(toml::Value::as_table_mut)
                            .context("accessing parsed keybindings table")?;
                        bindings.insert(key, value);
                        migrated_keybindings = true;
                    }
                    config.keybindings = rows;
                }
                Err(e) => eprintln!(
                    "zerocode: ignoring [keybindings] in {} ({e}); using defaults",
                    path.display()
                ),
            }
        }
        if let Some(v) = doc.get("todotracker") {
            match v.clone().try_into::<TodoTrackerSection>() {
                Ok(section) => config.todotracker = section,
                Err(e) => eprintln!(
                    "zerocode: ignoring [todotracker] in {} ({e}); using default",
                    path.display()
                ),
            }
        }

        if migrated_keybindings {
            match write_lock.as_ref() {
                // The first read ran without the lock. Do not publish that
                // snapshot: a login saved after it would be discarded. Re-read
                // under the same lock every other writer holds.
                None => match ConfigWriteLock::acquire_within(config_dir, migration_lock_wait()) {
                    Ok(lock) => {
                        write_lock = Some(lock);
                        continue;
                    }
                    // Contention and a filesystem that refuses locks take the
                    // same path. The snapshot already parsed is the saved
                    // config, including its remote target. Rewriting is
                    // optional; failing the load would make startup drop that
                    // target and dial the local socket.
                    Err(error) => {
                        // Format only after `i18n::init`. Doing it earlier
                        // caches a language and `CONFIG_DIR` that startup
                        // cannot replace. Later reads print immediately:
                        // `emit_startup_notices` runs only once.
                        record_skipped_migration(&path, &error);
                        return Ok(config);
                    }
                },
                Some(lock) => write_document(&path, &doc, lock)?,
            }
        }

        return Ok(config);
    }
}

/// A migration-lock failure kept for startup to print after `i18n::init`.
/// Formatting it inside the loader would cache the wrong language.
struct StartupNotice {
    path: String,
    failure: PendingLockFailure,
}

enum PendingLockFailure {
    Timeout {
        config: String,
        lock: String,
        seconds: u64,
    },
    NotRegular {
        path: String,
    },
    Other(String),
}

std::thread_local! {
    static STARTUP_NOTICES: std::cell::RefCell<Vec<StartupNotice>> =
        const { std::cell::RefCell::new(Vec::new()) };
    /// Formatted warning from a post-init skipped migration, for the caller
    /// that just loaded. Stderr is not visible once the alternate screen is up.
    static MIGRATION_WARNING: std::cell::RefCell<Option<String>> =
        const { std::cell::RefCell::new(None) };
    static MIGRATION_WARNING_GEN: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
    static MIGRATION_WARNING_PRINTED: std::cell::RefCell<Option<String>> =
        const { std::cell::RefCell::new(None) };
}

fn push_startup_notice(notice: StartupNotice) {
    STARTUP_NOTICES.with(|notices| notices.borrow_mut().push(notice));
}

fn record_skipped_migration(path: &Path, error: &anyhow::Error) {
    let notice = StartupNotice {
        path: path.display().to_string(),
        failure: pending_lock_failure(error),
    };
    if !crate::i18n::is_initialized() {
        push_startup_notice(notice);
        return;
    }
    let message = format_notice(&notice);
    let repeat = MIGRATION_WARNING_PRINTED
        .with(|printed| printed.borrow().as_deref() == Some(message.as_str()));
    MIGRATION_WARNING.with(|warning| *warning.borrow_mut() = Some(message.clone()));
    MIGRATION_WARNING_GEN.with(|generation| generation.set(generation.get().wrapping_add(1)));
    if repeat {
        return;
    }
    MIGRATION_WARNING_PRINTED.with(|printed| *printed.borrow_mut() = Some(message.clone()));
    eprintln!("{message}");
}

/// Generation of the latest post-init skipped-migration warning on this thread.
pub(crate) fn migration_warning_mark() -> u64 {
    MIGRATION_WARNING_GEN.with(|generation| generation.get())
}

/// The skipped-migration warning recorded after `mark`, if this thread's last
/// load hit one. A load that did not skip migration leaves an older warning
/// where it is, so a later caller does not report it as its own.
pub(crate) fn take_migration_warning_since(mark: u64) -> Option<String> {
    if MIGRATION_WARNING_GEN.with(|generation| generation.get()) == mark {
        return None;
    }
    MIGRATION_WARNING.with(|warning| warning.borrow_mut().take())
}

fn pending_lock_failure(error: &anyhow::Error) -> PendingLockFailure {
    if let Some(timeout) = error.downcast_ref::<ConfigLockTimeout>() {
        return PendingLockFailure::Timeout {
            config: timeout.config.clone(),
            lock: timeout.lock.clone(),
            seconds: timeout.seconds,
        };
    }
    if let Some(not_regular) = error.downcast_ref::<ConfigLockNotRegular>() {
        return PendingLockFailure::NotRegular {
            path: not_regular.path.clone(),
        };
    }
    PendingLockFailure::Other(format!("{error:#}"))
}

fn format_notice(notice: &StartupNotice) -> String {
    let detail = match &notice.failure {
        PendingLockFailure::Timeout {
            config,
            lock,
            seconds,
        } => {
            let seconds = seconds.to_string();
            crate::i18n::t_args(
                "zc-config-save-lock-timeout",
                &[
                    ("config", config.as_str()),
                    ("lock", lock.as_str()),
                    ("seconds", seconds.as_str()),
                ],
            )
        }
        PendingLockFailure::NotRegular { path } => {
            crate::i18n::t_args("zc-config-lock-not-regular", &[("path", path.as_str())])
        }
        PendingLockFailure::Other(message) => message.clone(),
    };
    crate::i18n::t_args(
        "zc-config-migration-lock-skipped",
        &[("path", notice.path.as_str()), ("error", detail.as_str())],
    )
}

/// Print migration-lock warnings using the locale startup just initialized.
pub(crate) fn emit_startup_notices() {
    let notices = STARTUP_NOTICES.with(|notices| std::mem::take(&mut *notices.borrow_mut()));
    for notice in notices {
        eprintln!("{}", format_notice(&notice));
    }
}

#[derive(Debug)]
struct ConfigLockTimeout {
    config: String,
    lock: String,
    seconds: u64,
}

impl std::fmt::Display for ConfigLockTimeout {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let seconds = self.seconds.to_string();
        formatter.write_str(&crate::i18n::t_args(
            "zc-config-save-lock-timeout",
            &[
                ("config", self.config.as_str()),
                ("lock", self.lock.as_str()),
                ("seconds", seconds.as_str()),
            ],
        ))
    }
}

impl std::error::Error for ConfigLockTimeout {}

#[derive(Debug)]
struct ConfigLockNotRegular {
    path: String,
}

impl std::fmt::Display for ConfigLockNotRegular {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str(&crate::i18n::t_args(
            "zc-config-lock-not-regular",
            &[("path", self.path.as_str())],
        ))
    }
}

impl std::error::Error for ConfigLockNotRegular {}

fn reject_non_regular_lock(path: &Path) -> Result<()> {
    match std::fs::symlink_metadata(path) {
        Ok(metadata) if metadata.is_file() => Ok(()),
        Ok(_) => Err(ConfigLockNotRegular {
            path: path.display().to_string(),
        }
        .into()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error).with_context(|| format!("reading {}", path.display())),
    }
}

/// Exclusive inter-process lock over one config directory's `zerocode-config.toml`.
///
/// Every persist rewrites the whole file from a snapshot. An atomic rename
/// keeps a reader from seeing a torn write, but two processes can still read
/// the same snapshot, add different URL logins, and both report success. The
/// last rename then deletes the other login. Startup renewal races a login
/// the same way, and a theme, sidebar, or keybinding save can erase a login
/// it never read.
///
/// The lock therefore covers the whole read-modify-write, not the rename.
/// `File::try_lock` is `flock(LOCK_EX)` on Unix and `LockFileEx` on Windows.
/// It is advisory: every zerocode writer takes it, and an operator editing
/// the file by hand is not blocked. The kernel releases it when this handle
/// closes, including on process death.
#[must_use = "the config write lock is released when this guard drops"]
struct ConfigWriteLock {
    file: std::fs::File,
}

impl ConfigWriteLock {
    fn acquire(config_dir: &Path) -> Result<Self> {
        Self::acquire_within(config_dir, CONFIG_LOCK_WAIT)
    }

    /// Wait up to `wait` for another writer to finish. A wedged holder must
    /// fail with the lock path, not hang login or renewal.
    fn acquire_within(config_dir: &Path, wait: std::time::Duration) -> Result<Self> {
        std::fs::create_dir_all(config_dir)
            .with_context(|| format!("creating config dir {}", config_dir.display()))?;
        let path = config_dir.join(CONFIG_LOCK_FILE);
        // A directory or symlink is rejected before open, including on
        // Windows where `O_NOFOLLOW` is unavailable. Opening it would either
        // fail with a generic `EISDIR` or follow the link onto another inode.
        reject_non_regular_lock(&path)?;
        let mut options = std::fs::OpenOptions::new();
        options.read(true).write(true).create(true).truncate(false);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt as _;
            options.mode(0o600);
            // Do not follow a symlink planted at the lock path. After an atomic
            // replace the followed target is a different inode, so two writers
            // would each believe they held the lock.
            options.custom_flags(libc::O_NOFOLLOW);
        }
        let file = options
            .open(&path)
            .with_context(|| format!("opening {}", path.display()))?;
        let metadata = file
            .metadata()
            .with_context(|| format!("reading metadata for {}", path.display()))?;
        if !metadata.is_file() {
            return Err(ConfigLockNotRegular {
                path: path.display().to_string(),
            }
            .into());
        }
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt as _;
            // fchmod the opened handle. A path-based chmod would follow a
            // symlink and change whatever file it points at.
            file.set_permissions(std::fs::Permissions::from_mode(0o600))
                .with_context(|| format!("restricting {}", path.display()))?;
        }
        let deadline = std::time::Instant::now() + wait;
        loop {
            match file.try_lock() {
                Ok(()) => return Ok(Self { file }),
                Err(std::fs::TryLockError::WouldBlock) => {
                    if std::time::Instant::now() >= deadline {
                        return Err(ConfigLockTimeout {
                            config: config_path(config_dir).display().to_string(),
                            lock: path.display().to_string(),
                            seconds: wait.as_secs(),
                        }
                        .into());
                    }
                    std::thread::sleep(CONFIG_LOCK_POLL);
                }
                Err(std::fs::TryLockError::Error(error)) => {
                    return Err(error).with_context(|| format!("locking {}", path.display()));
                }
            }
        }
    }
}

impl Drop for ConfigWriteLock {
    fn drop(&mut self) {
        // Closing the handle releases the lock on both platforms. Unlocking
        // first makes that release explicit rather than a side effect of drop
        // order. The lock file stays: it is the lock's identity.
        let _ = self.file.unlock();
    }
}

/// Load the on-disk file as a raw `toml::Table`. A missing or empty file
/// yields an empty table; any other section the running struct does not
/// model is carried through untouched so a partial write never clobbers it.
///
/// Any other read failure is an error, not an empty table: every persist
/// rebuilds the whole file from this document and publishes it by rename, so
/// treating an unreadable file as empty would replace the user's config,
/// its `[connection.wss]` bearer included, with whatever is being saved.
fn load_document(path: &Path) -> Result<toml::Table> {
    let raw = match std::fs::read_to_string(path) {
        Ok(raw) => raw,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => String::new(),
        Err(e) => return Err(e).with_context(|| format!("reading {}", path.display())),
    };
    if raw.trim().is_empty() {
        return Ok(toml::Table::new());
    }
    toml::from_str(&raw).with_context(|| format!("parsing {}", path.display()))
}

/// Serialize a mutated document table back to disk.
///
/// The configuration file carries a hand-written `[connection.wss]
/// auth_token` whenever the operator uses the persistent path instead of
/// `ZEROCLAW_AUTH_TOKEN`, and every persist here rewrites the whole file. So
/// this is the one funnel that decides the file's mode, and it writes
/// owner-only and atomically: a partial rewrite cannot lose a token that was
/// already there, and a file that predates this is repaired rather than left
/// world-readable.
///
/// `lock` must be the guard acquired before the snapshot in `doc` was read.
/// The rename is atomic, but it does not by itself stop a lost update.
fn write_document(path: &Path, doc: &toml::Table, _lock: &ConfigWriteLock) -> Result<()> {
    let body = toml::to_string_pretty(doc).context("serializing config")?;
    crate::secure_file::write_private_atomic(path, body.as_bytes())
}

/// Mutable borrow of `key`'s sub-table, inserting an empty one when absent.
fn section_mut<'a>(doc: &'a mut toml::Table, key: &str) -> Result<&'a mut toml::Table> {
    doc.entry(key)
        .or_insert_with(|| toml::Value::Table(toml::Table::new()))
        .as_table_mut()
        .ok_or_else(|| anyhow::Error::msg(format!("'{key}' is not a table")))
}

/// Persist one sidebar leaf without rewriting unrelated TOML formatting.
/// Returns whether a valid environment override will shadow the saved value on
/// the next effective load.
fn persist_sidebar_leaf(
    config_dir: &Path,
    leaf: &str,
    replacement: toml_edit::Item,
    shadowed: bool,
) -> Result<bool> {
    let _lock = ConfigWriteLock::acquire(config_dir)?;
    std::fs::create_dir_all(config_dir)
        .with_context(|| format!("creating config dir {}", config_dir.display()))?;
    let path = config_path(config_dir);
    let raw = match std::fs::read_to_string(&path) {
        Ok(raw) => raw,
        Err(error) if error.kind() == ErrorKind::NotFound => String::new(),
        Err(error) => {
            return Err(error).with_context(|| format!("reading {}", path.display()));
        }
    };
    let semantic: toml::Table = if raw.trim().is_empty() {
        toml::Table::new()
    } else {
        toml::from_str(&raw).with_context(|| format!("parsing {}", path.display()))?
    };
    if let Some(value) = semantic.get("sidebar") {
        value
            .clone()
            .try_into::<SidebarSection>()
            .with_context(|| {
                format!(
                    "refusing to update {leaf} in malformed [sidebar] section in {}",
                    path.display()
                )
            })?;
    }

    let mut doc = raw
        .parse::<toml_edit::DocumentMut>()
        .with_context(|| format!("parsing {} for an in-place edit", path.display()))?;
    let sidebar = doc
        .entry("sidebar")
        .or_insert_with(|| toml_edit::Item::Table(toml_edit::Table::new()));
    let sidebar = sidebar.as_table_like_mut().ok_or_else(|| {
        anyhow::Error::msg(format!(
            "refusing to update non-table [sidebar] in {}",
            path.display()
        ))
    })?;
    let mut replacement = replacement;
    if let Some(existing) = sidebar.get_mut(leaf) {
        if let (Some(existing), Some(replacement)) =
            (existing.as_value(), replacement.as_value_mut())
        {
            *replacement.decor_mut() = existing.decor().clone();
        }
        *existing = replacement;
    } else {
        sidebar.insert(leaf, replacement);
    }
    crate::secure_file::write_private_atomic(&path, doc.to_string().as_bytes())?;
    Ok(shadowed)
}

/// Persist the sidebar visibility toggle, writing only `[sidebar].visible`.
pub(crate) fn persist_sidebar_visible(config_dir: &Path, visible: bool) -> Result<bool> {
    let shadowed = std::env::var("ZEROCODE_sidebar__visible")
        .ok()
        .and_then(|value| value.parse::<bool>().ok())
        .is_some_and(|effective| effective != visible);
    persist_sidebar_leaf(config_dir, "visible", toml_edit::value(visible), shadowed)
}

pub(crate) fn persist_sidebar_side(config_dir: &Path, side: SidebarSide) -> Result<bool> {
    let shadowed = std::env::var("ZEROCODE_sidebar__side")
        .ok()
        .and_then(|value| match value.as_str() {
            "left" => Some(SidebarSide::Left),
            "right" => Some(SidebarSide::Right),
            _ => None,
        })
        .is_some_and(|effective| effective != side);
    persist_sidebar_leaf(
        config_dir,
        "side",
        toml_edit::value(side.as_str()),
        shadowed,
    )
}

pub(crate) fn persist_sidebar_queue_visible(config_dir: &Path, visible: bool) -> Result<bool> {
    let shadowed = std::env::var("ZEROCODE_sidebar__queue_visible")
        .ok()
        .and_then(|value| value.parse::<bool>().ok())
        .is_some_and(|effective| effective != visible);
    persist_sidebar_leaf(
        config_dir,
        "queue_visible",
        toml_edit::value(visible),
        shadowed,
    )
}

pub(crate) fn persist_sidebar_plan_visible(config_dir: &Path, visible: bool) -> Result<bool> {
    let shadowed = std::env::var("ZEROCODE_sidebar__plan_visible")
        .ok()
        .and_then(|value| value.parse::<bool>().ok())
        .is_some_and(|effective| effective != visible);
    persist_sidebar_leaf(
        config_dir,
        "plan_visible",
        toml_edit::value(visible),
        shadowed,
    )
}

pub(crate) fn persist_sidebar_width(config_dir: &Path, width: u16) -> Result<bool> {
    let shadowed = std::env::var("ZEROCODE_sidebar__width")
        .ok()
        .and_then(|value| value.parse::<u16>().ok())
        .map(|value| value.clamp(SIDEBAR_WIDTH_MIN, SIDEBAR_WIDTH_MAX))
        .is_some_and(|effective| effective != width);
    persist_sidebar_leaf(
        config_dir,
        "width",
        toml_edit::value(i64::from(width)),
        shadowed,
    )
}

pub(crate) fn persist_sidebar_sessions_percent(
    config_dir: &Path,
    sessions_percent: u16,
) -> Result<bool> {
    let shadowed = std::env::var("ZEROCODE_sidebar__sessions_percent")
        .ok()
        .and_then(|value| value.parse::<u16>().ok())
        .map(|value| value.clamp(SIDEBAR_SESSIONS_PERCENT_MIN, SIDEBAR_SESSIONS_PERCENT_MAX))
        .is_some_and(|effective| effective != sessions_percent);
    persist_sidebar_leaf(
        config_dir,
        "sessions_percent",
        toml_edit::value(i64::from(sessions_percent)),
        shadowed,
    )
}

pub(crate) fn persist_sidebar_queue_percent(config_dir: &Path, queue_percent: u16) -> Result<bool> {
    let shadowed = std::env::var("ZEROCODE_sidebar__queue_percent")
        .ok()
        .and_then(|value| value.parse::<u16>().ok())
        .map(|value| value.clamp(SIDEBAR_QUEUE_PERCENT_MIN, SIDEBAR_QUEUE_PERCENT_MAX))
        .is_some_and(|effective| effective != queue_percent);
    persist_sidebar_leaf(
        config_dir,
        "queue_percent",
        toml_edit::value(i64::from(queue_percent)),
        shadowed,
    )
}

/// Persist the selected theme name, editing only the `[theme]` section.
pub(crate) fn persist_theme(config_dir: &Path, theme_name: &str) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    section_mut(&mut doc, "theme")?.insert(
        "name".to_string(),
        toml::Value::String(theme_name.to_string()),
    );
    write_document(&path, &doc, &lock)
}

/// Persist a per-agent theme override, writing only
/// `[theme.agent_override.<alias>].name`. Other agents' overrides and every
/// other section are preserved.
pub(crate) fn persist_agent_theme(config_dir: &Path, alias: &str, theme_name: &str) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    section_mut_path(&mut doc, &["theme", "agent_override", alias])?.insert(
        "name".to_string(),
        toml::Value::String(theme_name.to_string()),
    );
    write_document(&path, &doc, &lock)
}

/// Remove a per-agent theme override, dropping the whole
/// `[theme.agent_override.<alias>]` entry (and the `agent_override` table if it
/// becomes empty). A no-op when the agent has no override. Other sections are
/// preserved.
pub(crate) fn persist_agent_theme_clear(config_dir: &Path, alias: &str) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    let Some(theme_tbl) = doc.get_mut("theme").and_then(toml::Value::as_table_mut) else {
        return write_document(&path, &doc, &lock);
    };
    let Some(over_tbl) = theme_tbl
        .get_mut("agent_override")
        .and_then(toml::Value::as_table_mut)
    else {
        return write_document(&path, &doc, &lock);
    };
    over_tbl.remove(alias);
    if over_tbl.is_empty() {
        theme_tbl.remove("agent_override");
    }
    write_document(&path, &doc, &lock)
}

fn section_mut_path<'a>(doc: &'a mut toml::Table, keys: &[&str]) -> Result<&'a mut toml::Table> {
    let mut cur = doc;
    for key in keys {
        cur = section_mut(cur, key)?;
    }
    Ok(cur)
}

pub(crate) fn persist_wss_route_ack(config_dir: &Path, uri: &str) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    let scoped = doc
        .get("connection")
        .and_then(|v| v.get("logins"))
        .and_then(|v| v.get(uri))
        .is_some();
    let tls = if scoped {
        section_mut_path(&mut doc, &["connection", "logins", uri, "tls"])?
    } else {
        section_mut_path(&mut doc, &["connection", "wss", "tls"])?
    };
    let routes = tls
        .entry("skip_verify_routes")
        .or_insert_with(|| toml::Value::Array(Vec::new()))
        .as_array_mut()
        .ok_or_else(|| anyhow::Error::msg("skip_verify_routes is not an array"))?;
    let already = routes.iter().any(|v| v.as_str().is_some_and(|s| s == uri));
    if !already {
        routes.push(toml::Value::String(uri.to_string()));
    }
    write_document(&path, &doc, &lock)
}

/// Persist the entire `[todotracker]` section, editing only that section.
/// Other sections (theme, keybindings, connection, etc.) are preserved.
///
/// This is the owning read-modify-write boundary. Refuse to replace a current
/// section that is unparseable, even if the caller's older snapshot
/// and proposed section are valid.
pub(crate) fn persist_todotracker(config_dir: &Path, section: &TodoTrackerSection) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    if let Some(value) = doc.get("todotracker") {
        value
            .clone()
            .try_into::<TodoTrackerSection>()
            .with_context(|| {
                format!(
                    "refusing to overwrite the malformed [todotracker] section in {}",
                    path.display()
                )
            })?;
    }
    let serialized = toml::Value::try_from(section)
        .context("serializing todotracker section")?
        .as_table()
        .cloned()
        .unwrap_or_default();
    doc.insert("todotracker".to_string(), toml::Value::Table(serialized));
    write_document(&path, &doc, &lock)
}

/// Save one URL's accepted login, optionally selecting it, in one owner-only
/// write. The read, mutation, and publish share [`ConfigWriteLock`] with every
/// other config writer, so a second login or a startup renewal cannot replace
/// this URL's entry with a snapshot that never contained it. Re-read the
/// persisted document so transient env overrides and other URLs' credentials
/// are never copied or lost.
pub(crate) fn persist_oidc_login(
    config_dir: &Path,
    uri: &str,
    login: &OidcLogin,
    select: bool,
) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    let connection = section_mut(&mut doc, "connection")?;
    if !connection.is_empty() {
        toml::Value::Table(connection.clone())
            .try_into::<ConnectionSection>()
            .context("refusing to overwrite malformed connection settings")?;
    }
    section_mut(connection, "logins")?.insert(uri.to_string(), toml::Value::try_from(login)?);
    if select {
        section_mut(connection, "wss")?.insert("uri".into(), toml::Value::String(uri.into()));
    }
    write_document(&path, &doc, &lock)
}

pub(crate) fn persist_connection_field(
    config_dir: &Path,
    leaf_path: &str,
    value: toml::Value,
) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    let mut segments: Vec<&str> = leaf_path.split('.').collect();
    let leaf = segments
        .pop()
        .ok_or_else(|| anyhow::Error::msg("empty connection field path"))?;
    let selected_login = doc
        .get("connection")
        .and_then(|c| c.get("wss"))
        .and_then(|w| w.get("uri"))
        .and_then(toml::Value::as_str)
        .map(str::to_owned)
        .filter(|uri| {
            doc.get("connection")
                .and_then(|c| c.get("logins"))
                .and_then(|l| l.get(uri))
                .is_some()
        });
    let mut prefix = if leaf_path.starts_with("tls.") {
        if let Some(uri) = selected_login.as_deref() {
            vec!["connection", "logins", uri]
        } else {
            vec!["connection", "wss"]
        }
    } else {
        vec!["connection", "wss"]
    };
    prefix.extend(segments);
    section_mut_path(&mut doc, &prefix)?.insert(leaf.to_string(), value);
    write_document(&path, &doc, &lock)
}

pub(crate) fn persist_locale(config_dir: &Path, locale: &str) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    doc.insert(
        "locale".to_string(),
        toml::Value::String(locale.to_string()),
    );
    write_document(&path, &doc, &lock)
}

/// Overwrite the `[keybindings]` section from a resolved override table
/// (preset pick). Sparse: only overridden actions are written; everything
/// else falls back to compile-time defaults on next load. Only the
/// `[keybindings]` section is touched; other sections are preserved.
pub(crate) fn persist_keybindings(config_dir: &Path, table: &OverrideTable) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    let rows = flatten_table(table);
    let serialized = toml::Value::try_from(&rows)
        .context("serializing keybindings")?
        .as_table()
        .cloned()
        .unwrap_or_default();
    doc.insert("keybindings".to_string(), toml::Value::Table(serialized));
    write_document(&path, &doc, &lock)
}

/// Insert or replace a single `"<tag>.<variant>"` row (capture-modal
/// save), leaving the rest of `[keybindings]` and all other sections intact.
pub(crate) fn persist_keybind_row(
    config_dir: &Path,
    action_key: &str,
    chords: Vec<Chord>,
) -> Result<()> {
    let lock = ConfigWriteLock::acquire(config_dir)?;
    let path = config_path(config_dir);
    let mut doc = load_document(&path)?;
    let value = toml::Value::try_from(ChordSpec::Many(chords)).context("serializing chords")?;
    section_mut(&mut doc, "keybindings")?.insert(action_key.to_string(), value);
    write_document(&path, &doc, &lock)
}

/// Collapse a nested `tag -> variant -> chords` table into the flat
/// `"<tag>.<variant>" -> ChordSpec` map the toml section stores.
fn flatten_table(table: &OverrideTable) -> HashMap<String, ChordSpec> {
    let mut out = HashMap::new();
    for (tag, variants) in table {
        for (variant, chords) in variants {
            out.insert(format!("{tag}.{variant}"), ChordSpec::Many(chords.clone()));
        }
    }
    out
}

/// Apply every `ZEROCODE_<dotted__path>=value` env var. Hard-errors on any var
/// that does not resolve to a known config path.
///
/// Canonical spelling: the `ZEROCODE_` prefix followed by the lowercase dotted
/// config path with `.` written as `__` — e.g. `ZEROCODE_todotracker__enabled=false`
/// sets `todotracker.enabled`. This mirrors the daemon's `ZEROCLAW_<path>` form.
/// Overrides are process-transient and are never written back to disk.
fn apply_env_overrides(config: &mut ZerocodeConfig) -> Result<()> {
    let mut entries: Vec<(String, String, String)> = std::env::vars()
        .filter_map(|(k, v)| {
            let tail = k.strip_prefix(ENV_PREFIX)?;
            (!tail.is_empty()
                && tail
                    .chars()
                    .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '_'))
            .then(|| (k.clone(), v, tail.replace(ENV_SEP, ".")))
        })
        .collect();
    entries.sort_by(|a, b| a.0.cmp(&b.0));

    for (env_name, value, path) in entries {
        set_prop(config, &path, &value).with_context(|| format!("{env_name} -> {path}"))?;
    }
    Ok(())
}

/// Set a leaf at a dotted `path` via a serde roundtrip through `toml::Value`.
/// No field names are hardcoded: the struct's serialized shape is the registry.
/// The string value is parsed into the correct TOML type by inspecting the
/// existing field value (string → string, bool → bool, integer → integer,
/// etc.).
fn set_prop<T: Serialize + serde::de::DeserializeOwned>(
    target: &mut T,
    path: &str,
    value: &str,
) -> Result<()> {
    let mut root = toml::Value::try_from(&*target).context("serializing config for set_prop")?;
    let segments: Vec<&str> = path.split('.').collect();
    let (leaf, parents) = segments
        .split_last()
        .ok_or_else(|| anyhow::Error::msg("empty config path"))?;

    let mut cursor = &mut root;
    for seg in parents {
        cursor = cursor
            .as_table_mut()
            .and_then(|t| t.get_mut(*seg))
            .ok_or_else(|| {
                anyhow::Error::msg(format!("path '{path}' did not resolve to a config field"))
            })?;
    }
    let table = cursor.as_table_mut().ok_or_else(|| {
        anyhow::Error::msg(format!("path '{path}' did not resolve to a config field"))
    })?;
    // Optional side is absent from the serialized shape until explicitly set.
    if *leaf == "side"
        && parents.len() == 1
        && parents[0] == "sidebar"
        && !table.contains_key(*leaf)
    {
        table.insert((*leaf).to_string(), toml::Value::String(value.to_string()));
    }
    if !table.contains_key(*leaf) {
        anyhow::bail!("path '{path}' did not resolve to a config field");
    }

    // Parse the string into the correct TOML type by inspecting the existing
    // field value. This lets env overrides like `ZEROCODE_todotracker__enabled=false`
    // set a boolean without the caller knowing the field type.
    let existing = table[*leaf].clone();
    let new_value = match existing {
        toml::Value::String(_) => toml::Value::String(value.to_string()),
        toml::Value::Boolean(_) => toml::Value::Boolean(
            value
                .parse()
                .with_context(|| format!("failed to parse '{value}' as bool for {path}"))?,
        ),
        toml::Value::Integer(_) => toml::Value::Integer(
            value
                .parse()
                .with_context(|| format!("failed to parse '{value}' as integer for {path}"))?,
        ),
        toml::Value::Float(_) => toml::Value::Float(
            value
                .parse()
                .with_context(|| format!("failed to parse '{value}' as float for {path}"))?,
        ),
        toml::Value::Array(_) => {
            let parsed: Vec<toml::Value> = toml::from_str(value)
                .with_context(|| format!("failed to parse '{value}' as array for {path}"))?;
            toml::Value::Array(parsed)
        }
        toml::Value::Datetime(_) => toml::Value::Datetime(
            value
                .parse()
                .with_context(|| format!("failed to parse '{value}' as datetime for {path}"))?,
        ),
        toml::Value::Table(_) => {
            anyhow::bail!("cannot set a table field via set_prop: {path}")
        }
    };
    table.insert((*leaf).to_string(), new_value);

    *target = root
        .try_into()
        .context("deserializing config after set_prop")?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_theme_is_registered() {
        let c = ZerocodeConfig::default();
        assert_eq!(c.theme.name, theme::DEFAULT_THEME_NAME);
        assert!(c.resolve_theme().is_ok());
    }

    #[test]
    fn default_config_emits_locale() {
        let body = toml::to_string_pretty(&ZerocodeConfig::default()).unwrap();
        assert!(
            body.contains("locale = \"en\""),
            "default config must surface the locale prop on disk; got:\n{body}"
        );
    }

    #[test]
    fn resolve_locale_trims_and_blanks_fall_back() {
        let c = ZerocodeConfig {
            locale: Some("  fr  ".to_string()),
            ..Default::default()
        };
        assert_eq!(c.resolve_locale().as_deref(), Some("fr"));
        let blank = ZerocodeConfig {
            locale: Some("   ".to_string()),
            ..Default::default()
        };
        assert_eq!(blank.resolve_locale(), None);
    }

    #[test]
    fn set_prop_locale_roundtrip() {
        let mut c = ZerocodeConfig::default();
        set_prop(&mut c, "locale", "ja").unwrap();
        assert_eq!(c.locale.as_deref(), Some("ja"));
    }

    #[test]
    fn persist_locale_preserves_other_sections() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "locale = \"en\"\n\n[theme]\nname = \"nord\"\n\n[future]\nkeep = true\n",
        );
        persist_locale(dir.path(), "fr").unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["locale"].as_str(), Some("fr"));
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord"));
        assert_eq!(doc["future"]["keep"].as_bool(), Some(true));
    }

    #[test]
    fn set_prop_roundtrip() {
        let mut c = ZerocodeConfig::default();
        set_prop(&mut c, "theme.name", "nord").unwrap();
        assert_eq!(c.theme.name, "nord");
    }

    #[test]
    fn set_prop_unknown_path_errors() {
        let mut c = ZerocodeConfig::default();
        let err = set_prop(&mut c, "no_such_field", "x").unwrap_err();
        assert!(err.to_string().contains("did not resolve"));
    }

    #[test]
    fn resolve_unknown_theme_falls_back_to_terminal() {
        let c = ZerocodeConfig {
            theme: ThemeSection {
                name: "bogus".to_string(),
                ..Default::default()
            },
            ..Default::default()
        };
        let resolved = c
            .resolve_theme()
            .expect("unknown theme falls back, never errors");
        assert_eq!(resolved.title, theme::fallback_theme().title);
        assert_eq!(resolved.background, theme::fallback_theme().background);
    }

    #[test]
    fn agent_override_resolves_known_theme() {
        let body =
            "[theme]\nname = \"nord_dark\"\n\n[theme.agent_override.coder]\nname = \"dracula\"\n";
        let c: ZerocodeConfig = toml::from_str(body).unwrap();
        let t = c
            .resolve_agent_theme("coder")
            .unwrap()
            .expect("override present");
        assert_eq!(t.title, theme::theme_by_name("dracula").unwrap().title);
    }

    #[test]
    fn agent_override_absent_alias_is_none() {
        let c: ZerocodeConfig = toml::from_str("[theme]\nname = \"nord_dark\"\n").unwrap();
        assert!(c.resolve_agent_theme("nobody").unwrap().is_none());
    }

    #[test]
    fn agent_override_unknown_theme_falls_back_to_terminal() {
        let body = "[theme.agent_override.coder]\nname = \"no_such_theme\"\n";
        let c: ZerocodeConfig = toml::from_str(body).unwrap();
        let t = c
            .resolve_agent_theme("coder")
            .expect("unknown override falls back, never errors")
            .expect("override present");
        assert_eq!(t.title, theme::fallback_theme().title);
        assert_eq!(t.background, theme::fallback_theme().background);
    }

    #[test]
    fn agent_override_blank_name_is_none() {
        let body = "[theme.agent_override.coder]\nname = \"  \"\n";
        let c: ZerocodeConfig = toml::from_str(body).unwrap();
        assert!(c.resolve_agent_theme("coder").unwrap().is_none());
    }

    #[test]
    fn agent_override_aliases_lists_configured() {
        let body = "[theme.agent_override.a]\nname = \"dracula\"\n[theme.agent_override.b]\nname = \"nord_dark\"\n";
        let c: ZerocodeConfig = toml::from_str(body).unwrap();
        let mut aliases: Vec<&str> = c.agent_override_aliases().collect();
        aliases.sort_unstable();
        assert_eq!(aliases, vec!["a", "b"]);
    }

    #[test]
    fn default_config_emits_no_agent_override() {
        let body = toml::to_string_pretty(&ZerocodeConfig::default()).unwrap();
        assert!(
            !body.contains("agent_override"),
            "default config must not scaffold agent_override; got:\n{body}"
        );
    }

    #[test]
    fn persist_agent_theme_writes_nested_and_preserves_others() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"nord_dark\"\n\n[future]\nkeep = true\n",
        );
        persist_agent_theme(dir.path(), "coder", "dracula").unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord_dark"));
        assert_eq!(
            doc["theme"]["agent_override"]["coder"]["name"].as_str(),
            Some("dracula")
        );
        assert_eq!(doc["future"]["keep"].as_bool(), Some(true));
    }

    #[test]
    fn persist_agent_theme_round_trips_through_resolver() {
        // Reads the environment via `ensure_and_load`; serialize against the
        // env-mutating tests so a stray override cannot leak in.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        persist_agent_theme(dir.path(), "coder", "dracula").unwrap();
        let cfg = ensure_and_load(dir.path()).unwrap();
        let t = cfg.resolve_agent_theme("coder").unwrap().unwrap();
        assert_eq!(t.title, theme::theme_by_name("dracula").unwrap().title);
    }

    #[test]
    fn persist_agent_theme_clear_removes_entry() {
        // Reads the environment via `ensure_and_load`; serialize against the
        // env-mutating tests so a stray override cannot leak in.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        persist_agent_theme(dir.path(), "a", "dracula").unwrap();
        persist_agent_theme(dir.path(), "b", "nord_dark").unwrap();
        persist_agent_theme_clear(dir.path(), "a").unwrap();
        let cfg = ensure_and_load(dir.path()).unwrap();
        assert!(cfg.resolve_agent_theme("a").unwrap().is_none());
        assert!(cfg.resolve_agent_theme("b").unwrap().is_some());
    }

    #[test]
    fn persist_agent_theme_clear_drops_empty_table() {
        let dir = tempfile::tempdir().unwrap();
        persist_agent_theme(dir.path(), "only", "dracula").unwrap();
        persist_agent_theme_clear(dir.path(), "only").unwrap();
        let on_disk = read(dir.path());
        assert!(
            !on_disk.contains("agent_override"),
            "clearing the last override must drop the table; got:\n{on_disk}"
        );
    }

    #[test]
    fn persist_agent_theme_clear_is_noop_when_absent() {
        // Reads the environment via `ensure_and_load`; serialize against the
        // env-mutating tests so a stray override cannot leak in.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(dir.path(), "[theme]\nname = \"nord_dark\"\n");
        persist_agent_theme_clear(dir.path(), "ghost").unwrap();
        let cfg = ensure_and_load(dir.path()).unwrap();
        assert_eq!(cfg.theme.name, "nord_dark");
    }

    #[test]
    fn resolve_empty_theme_recovers_to_default() {
        for blank in ["", "   "] {
            let c = ZerocodeConfig {
                theme: ThemeSection {
                    name: blank.to_string(),
                    ..Default::default()
                },
                ..Default::default()
            };
            let resolved = c.resolve_theme().expect("empty theme recovers to default");
            assert_eq!(resolved.title, theme::default_theme().title);
        }
    }

    fn seed(dir: &Path, body: &str) {
        std::fs::write(config_path(dir), body).unwrap();
    }

    fn read(dir: &Path) -> String {
        std::fs::read_to_string(config_path(dir)).unwrap()
    }

    #[test]
    fn a_config_that_cannot_be_read_is_not_replaced() {
        let dir = tempfile::tempdir().unwrap();
        // Not valid UTF-8, so the read fails for a reason other than absence.
        let bytes: &[u8] = b"[connection.wss]\nauth_token = \"keep-me\"\n\xff\xfe\n";
        std::fs::write(config_path(dir.path()), bytes).unwrap();

        assert!(
            persist_theme(dir.path(), "gruvbox").is_err(),
            "a persist must not treat an unreadable config as empty"
        );
        assert_eq!(
            std::fs::read(config_path(dir.path())).unwrap(),
            bytes,
            "the unreadable config must be left as it was"
        );
    }

    #[test]
    fn persist_theme_preserves_unmodeled_sections() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"nord\"\n\n[future]\nfield = 42\nnested = [\"a\", \"b\"]\n",
        );
        persist_theme(dir.path(), "gruvbox").unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("gruvbox"));
        assert_eq!(doc["future"]["field"].as_integer(), Some(42));
        assert_eq!(
            doc["future"]["nested"].as_array().unwrap().len(),
            2,
            "unmodeled section must survive a theme write"
        );
    }

    #[test]
    fn persist_keybind_row_preserves_theme_and_unmodeled() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"nord\"\n\n[future]\nkeep = true\n",
        );
        persist_keybind_row(dir.path(), "dashboard.up", vec![Chord::char('z')]).unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord"));
        assert_eq!(doc["future"]["keep"].as_bool(), Some(true));
        assert!(
            doc["keybindings"]
                .as_table()
                .unwrap()
                .contains_key("dashboard.up")
        );
    }

    #[test]
    fn persist_keybind_row_emits_only_canonical_modifier_wires() {
        let dir = tempfile::tempdir().unwrap();
        persist_keybind_row(
            dir.path(),
            "input_bar.clear_input",
            vec![Chord::ctrl('c'), Chord::primary('u')],
        )
        .unwrap();

        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        let row = doc["keybindings"]["input_bar.clear_input"]
            .as_array()
            .unwrap();
        assert_eq!(row[0].as_str(), Some("control+c"));
        assert_eq!(row[1].as_str(), Some("primary+u"));
        assert!(!read(dir.path()).contains("ctrl+"));
    }

    #[test]
    fn persist_keybindings_replaces_only_its_section() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"nord\"\n\n[keybindings]\nold = \"x\"\n\n[future]\nkeep = 1\n",
        );
        let mut table: OverrideTable = OverrideTable::new();
        table
            .entry("dashboard".to_string())
            .or_default()
            .insert("up".to_string(), vec![Chord::char('z')]);
        persist_keybindings(dir.path(), &table).unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord"));
        assert_eq!(doc["future"]["keep"].as_integer(), Some(1));
        let kb = doc["keybindings"].as_table().unwrap();
        assert!(kb.contains_key("dashboard.up"));
        assert!(!kb.contains_key("old"), "preset pick replaces the section");
    }

    #[test]
    fn bad_keybindings_do_not_blank_theme() {
        // Reads the environment via `ensure_and_load`; serialize against the
        // env-mutating tests so a stray override cannot leak in.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        // `"+"` was historically unparseable; even if a future bug
        // re-introduces that, the theme must still load.
        seed(
            dir.path(),
            "[theme]\nname = \"dracula\"\n\n[keybindings]\n\"logs.increase_level\" = [\"completely::bogus::token\"]\n",
        );
        let cfg = ensure_and_load(dir.path()).unwrap();
        assert_eq!(cfg.theme.name, "dracula");
        assert!(
            cfg.keybindings.is_empty(),
            "bad keybindings drop to default"
        );
    }

    #[test]
    fn bad_theme_does_not_blank_keybindings() {
        // Reads the environment via `ensure_and_load`; serialize against the
        // env-mutating tests so a stray override cannot leak in.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = 42\n\n[keybindings]\n\"dashboard.up\" = [\"k\"]\n",
        );
        let cfg = ensure_and_load(dir.path()).unwrap();
        assert_eq!(cfg.theme.name, theme::DEFAULT_THEME_NAME);
        assert!(cfg.keybindings.contains_key("dashboard.up"));
    }

    #[test]
    fn legacy_help_defaults_migrate_without_touching_other_config() {
        // Reads the environment via `ensure_and_load`; serialize against the
        // env-mutating tests so a stray override cannot leak in.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[keybindings]\n\"global.help\" = [\"?\", \"f1\", \"ctrl+f1\"]\n\"dashboard.up\" = [\"k\"]\n\n[future]\nkeep = 1\n",
        );

        let cfg = ensure_and_load(dir.path()).unwrap();
        let resolved = cfg.resolve_keybindings().unwrap();
        assert_eq!(
            resolved["global"]["help"],
            vec![Chord::char('?'), Chord::ctrl('g')]
        );
        assert_eq!(resolved["dashboard"]["up"], vec![Chord::char('k')]);

        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        let help: Vec<Chord> = doc["keybindings"]["global.help"]
            .clone()
            .try_into()
            .unwrap();
        assert_eq!(help, vec![Chord::char('?'), Chord::ctrl('g')]);
        assert_eq!(doc["future"]["keep"].as_integer(), Some(1));
    }

    #[test]
    fn customized_help_binding_migrates_legacy_primary() {
        // Reads the environment via `ensure_and_load`; serialize against the
        // env-mutating tests so a stray override cannot leak in.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[keybindings]\n\"global.help\" = [\"?\", \"ctrl+h\"]\n",
        );

        let cfg = ensure_and_load(dir.path()).unwrap();
        let resolved = cfg.resolve_keybindings().unwrap();
        assert_eq!(
            resolved["global"]["help"],
            vec![Chord::char('?'), Chord::primary('h')]
        );
        assert!(read(dir.path()).contains("primary+h"));
        assert!(!read(dir.path()).contains("ctrl+h"));
    }

    #[test]
    fn legacy_ctrl_migration_preserves_scalar_array_and_unrelated_config() {
        use crossterm::event::{KeyCode, KeyModifiers};

        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "locale = \"en\"\n\n[keybindings]\n\"input_bar.clear_input\" = \"ctrl+u\"\n\"global.help\" = [\"ctrl+c\", \"ctrl+f1\"]\n\n[future]\nkeep = true\n",
        );

        let cfg = ensure_and_load(dir.path()).unwrap();
        let resolved = cfg.resolve_keybindings().unwrap();
        assert_eq!(
            resolved["input_bar"]["clear_input"],
            vec![Chord::primary('u')]
        );
        assert_eq!(
            resolved["global"]["help"],
            vec![
                Chord::ctrl('c'),
                Chord::with(KeyCode::F(1), KeyModifiers::CONTROL),
            ]
        );

        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["locale"].as_str(), Some("en"));
        assert_eq!(doc["future"]["keep"].as_bool(), Some(true));
        assert_eq!(
            doc["keybindings"]["input_bar.clear_input"].as_str(),
            Some("primary+u")
        );
        let global = doc["keybindings"]["global.help"].as_array().unwrap();
        assert_eq!(global[0].as_str(), Some("control+c"));
        assert_eq!(global[1].as_str(), Some("control+f1"));
    }

    #[test]
    fn legacy_ctrl_migration_uses_the_frozen_key_split() {
        for key in ["c", "g", "k", "n", "s", "f1"] {
            let mut wire = format!("ctrl+{key}");
            assert!(migrate_legacy_ctrl_wire(&mut wire));
            assert_eq!(wire, format!("control+{key}"));
        }
        for key in [
            "a", "d", "e", "h", "p", "r", "u", "v", "w", "x", "enter", "up",
        ] {
            let mut wire = format!("ctrl+{key}");
            assert!(migrate_legacy_ctrl_wire(&mut wire));
            assert_eq!(wire, format!("primary+{key}"));
        }
        let mut canonical = "control+c".to_string();
        assert!(!migrate_legacy_ctrl_wire(&mut canonical));
        assert_eq!(canonical, "control+c");
    }

    #[test]
    fn legacy_ctrl_migration_rewrites_before_tolerant_parse() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[keybindings]\n\"input_bar.clear_input\" = \"ctrl+u\"\n\"broken\" = [42]\n\n[future]\nkeep = true\n",
        );

        let cfg = ensure_and_load(dir.path()).unwrap();
        assert!(
            cfg.keybindings.is_empty(),
            "malformed rows still use defaults"
        );

        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(
            doc["keybindings"]["input_bar.clear_input"].as_str(),
            Some("primary+u")
        );
        assert_eq!(doc["keybindings"]["broken"][0].as_integer(), Some(42));
        assert_eq!(doc["future"]["keep"].as_bool(), Some(true));
    }

    #[test]
    fn canonical_keybindings_reload_idempotently() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[keybindings]\n\"input_bar.clear_input\" = \"primary+u\"\n\n[future]\nkeep = 1\n",
        );

        let _ = ensure_and_load(dir.path()).unwrap();
        let first = read(dir.path());
        let _ = ensure_and_load(dir.path()).unwrap();
        assert_eq!(read(dir.path()), first);
    }

    #[test]
    fn legacy_copy_default_migrates_without_touching_other_config() {
        use crossterm::event::{KeyCode, KeyModifiers};

        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[keybindings]\n\"chat.copy_selection\" = [\"y\"]\n\"dashboard.up\" = [\"k\"]\n\n[future]\nkeep = 1\n",
        );

        let cfg = ensure_and_load(dir.path()).unwrap();
        let resolved = cfg.resolve_keybindings().unwrap();
        assert_eq!(
            resolved["chat"]["copy_selection"],
            vec![
                Chord::char('y'),
                Chord::with(KeyCode::Char('c'), KeyModifiers::SUPER),
            ]
        );
        assert_eq!(resolved["dashboard"]["up"], vec![Chord::char('k')]);

        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        let copy: Vec<Chord> = doc["keybindings"]["chat.copy_selection"]
            .clone()
            .try_into()
            .unwrap();
        assert_eq!(copy, ChatTabAction::CopySelection.default_chords());
        assert_eq!(doc["future"]["keep"].as_integer(), Some(1));
    }

    #[test]
    fn customized_copy_binding_is_not_migrated() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[keybindings]\n\"chat.copy_selection\" = [\"y\", \"alt+c\"]\n",
        );

        let cfg = ensure_and_load(dir.path()).unwrap();
        let resolved = cfg.resolve_keybindings().unwrap();
        assert_eq!(
            resolved["chat"]["copy_selection"],
            vec![Chord::char('y'), "alt+c".parse::<Chord>().unwrap()]
        );
        assert!(read(dir.path()).contains("alt+c"));
    }

    #[test]
    fn bare_copy_binding_is_not_migrated() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[keybindings]\n\"chat.copy_selection\" = \"y\"\n\"global.help\" = [\"?\", \"f1\", \"ctrl+f1\"]\n",
        );

        let cfg = ensure_and_load(dir.path()).unwrap();
        let resolved = cfg.resolve_keybindings().unwrap();
        assert_eq!(resolved["chat"]["copy_selection"], vec![Chord::char('y')]);
        assert_eq!(
            resolved["global"]["help"],
            vec![Chord::char('?'), Chord::ctrl('g')]
        );

        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(
            doc["keybindings"]["chat.copy_selection"].as_str(),
            Some("y")
        );
    }

    #[test]
    fn legacy_chat_jump_defaults_migrate_without_touching_other_config() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[keybindings]\n\"chat.jump_start\" = [\"g\"]\n\"chat.jump_end\" = [\"G\"]\n\"dashboard.up\" = [\"k\"]\n\n[future]\nkeep = 1\n",
        );

        let cfg = ensure_and_load(dir.path()).unwrap();
        let resolved = cfg.resolve_keybindings().unwrap();
        assert_eq!(
            resolved["chat"]["jump_start"],
            ChatTabAction::JumpStart.default_chords()
        );
        assert_eq!(
            resolved["chat"]["jump_end"],
            ChatTabAction::JumpEnd.default_chords()
        );
        assert_eq!(resolved["dashboard"]["up"], vec![Chord::char('k')]);

        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["future"]["keep"].as_integer(), Some(1));
    }

    #[test]
    fn customized_chat_jump_bindings_are_not_migrated() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[keybindings]\n\"chat.jump_start\" = [\"alt+home\"]\n\"chat.jump_end\" = \"G\"\n",
        );

        let cfg = ensure_and_load(dir.path()).unwrap();
        let resolved = cfg.resolve_keybindings().unwrap();
        assert_eq!(
            resolved["chat"]["jump_start"],
            vec!["alt+home".parse::<Chord>().unwrap()]
        );
        assert_eq!(resolved["chat"]["jump_end"], vec![Chord::char('G')]);
    }

    #[test]
    fn persist_theme_creates_file_when_absent() {
        let dir = tempfile::tempdir().unwrap();
        persist_theme(dir.path(), "gruvbox").unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("gruvbox"));
    }

    // ── The config file is owner-only and written atomically ─────────
    //
    // The operator may keep the WSS bearer in `[connection.wss] auth_token`
    // rather than `ZEROCLAW_AUTH_TOKEN`, and every persist rewrites the whole
    // file, so this one funnel decides the file's mode and its atomicity.

    #[cfg(unix)]
    #[test]
    fn write_document_creates_the_config_file_owner_only() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        persist_theme(dir.path(), "gruvbox").unwrap();

        let file_mode = std::fs::metadata(config_path(dir.path()))
            .unwrap()
            .permissions()
            .mode()
            & 0o777;
        let dir_mode = std::fs::metadata(dir.path()).unwrap().permissions().mode() & 0o777;
        assert_eq!(file_mode, 0o600, "a fresh config file must be owner-only");
        assert_eq!(dir_mode, 0o700, "the config dir must be owner-only");
    }

    #[cfg(unix)]
    #[test]
    fn write_document_repairs_a_world_readable_config_file() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[connection.wss]\nuri = \"wss://daemon.example:8443\"\nauth_token = \"hand-written-bearer\"\n",
        );
        std::fs::set_permissions(
            config_path(dir.path()),
            std::fs::Permissions::from_mode(0o644),
        )
        .unwrap();

        persist_theme(dir.path(), "gruvbox").unwrap();

        let mode = std::fs::metadata(config_path(dir.path()))
            .unwrap()
            .permissions()
            .mode()
            & 0o777;
        assert_eq!(
            mode, 0o600,
            "an existing world-readable file must be repaired"
        );
        let body = read(dir.path());
        assert!(
            body.contains("hand-written-bearer"),
            "repairing the mode must not lose the operator's token:\n{body}"
        );
    }

    #[test]
    fn write_document_is_atomic_and_leaves_no_temp_file() {
        let dir = tempfile::tempdir().unwrap();
        persist_theme(dir.path(), "gruvbox").unwrap();
        persist_locale(dir.path(), "fr").unwrap();

        let mut entries: Vec<String> = std::fs::read_dir(dir.path())
            .unwrap()
            .map(|e| e.unwrap().file_name().to_string_lossy().into_owned())
            .collect();
        entries.sort();
        assert_eq!(
            entries,
            vec![CONFIG_LOCK_FILE.to_string(), FILE_NAME.to_string()],
            "the publish must leave no staging file; the lock file stays as the lock identity: {entries:?}"
        );
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("gruvbox"));
        assert_eq!(doc["locale"].as_str(), Some("fr"));
    }

    #[test]
    fn persisted_auth_token_survives_unrelated_section_writes() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[connection.wss]\nuri = \"wss://daemon.example:8443\"\nauth_token = \"hand-written-bearer\"\n",
        );

        persist_locale(dir.path(), "fr").unwrap();

        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(
            doc["connection"]["wss"]["auth_token"].as_str(),
            Some("hand-written-bearer"),
            "an unrelated persist must carry the token through untouched"
        );
        assert_eq!(doc["locale"].as_str(), Some("fr"));
    }

    #[test]
    fn wss_section_debug_redacts_the_bearer() {
        let section = WssSection {
            uri: Some("wss://daemon.example:8443".into()),
            auth_token: Some("super-secret-bearer".into()),
            auth_provider: Some("oidc.corp".into()),
            ..WssSection::default()
        };
        let rendered = format!("{section:?}");
        assert!(
            !rendered.contains("super-secret-bearer"),
            "the bearer must never reach a diagnostic: {rendered}"
        );
        assert!(rendered.contains("REDACTED"), "{rendered}");
        assert!(
            rendered.contains("oidc.corp"),
            "ordinary connection metadata still prints: {rendered}"
        );
    }

    #[test]
    fn sidebar_section_round_trips() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(dir.path(), "[sidebar]\nvisible = false\nwidth = 30\n");
        let cfg = ensure_and_load(dir.path()).unwrap();
        assert!(!cfg.sidebar.visible);
        assert_eq!(cfg.sidebar.width, 30);
    }

    #[test]
    fn sidebar_partial_section_fills_field_defaults() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(dir.path(), "[sidebar]\nvisible = false\n");
        let cfg = ensure_and_load(dir.path()).unwrap();
        assert!(!cfg.sidebar.visible);
        assert_eq!(cfg.sidebar.width, 24, "unset width falls back to default");
    }

    #[test]
    fn bad_sidebar_does_not_blank_theme() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"dracula\"\n\n[sidebar]\nvisible = \"nope\"\n",
        );
        let cfg = ensure_and_load(dir.path()).unwrap();
        assert_eq!(cfg.theme.name, "dracula");
        assert!(cfg.sidebar.visible, "bad [sidebar] drops to default");
    }

    #[test]
    fn default_config_serializes_sidebar_for_env_overrides() {
        let body = toml::to_string_pretty(&ZerocodeConfig::default()).unwrap();
        assert!(
            body.contains("[sidebar]") && body.contains("visible = true"),
            "the default document must materialize [sidebar] so schema-mirror env overrides resolve; got:\n{body}"
        );
    }

    #[test]
    fn persist_sidebar_visible_preserves_other_sections() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"nord\"\n\n[future]\nkeep = true\n",
        );
        persist_sidebar_visible(dir.path(), false).unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["sidebar"]["visible"].as_bool(), Some(false));
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord"));
        assert_eq!(doc["future"]["keep"].as_bool(), Some(true));

        let cfg = ensure_and_load(dir.path()).unwrap();
        assert!(!cfg.sidebar.visible);
        persist_sidebar_visible(dir.path(), true).unwrap();
        let cfg = ensure_and_load(dir.path()).unwrap();
        assert!(cfg.sidebar.visible);
    }

    #[test]
    fn sidebar_leaf_writes_round_trip_side_width_and_split() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        persist_sidebar_side(dir.path(), SidebarSide::Left).unwrap();
        persist_sidebar_width(dir.path(), 31).unwrap();
        persist_sidebar_sessions_percent(dir.path(), 45).unwrap();
        persist_sidebar_queue_percent(dir.path(), 65).unwrap();

        let config = load_persisted(dir.path()).unwrap();
        assert_eq!(config.sidebar.side, Some(SidebarSide::Left));
        assert_eq!(config.sidebar.width, 31);
        assert_eq!(config.sidebar.sessions_percent, 45);
        assert_eq!(config.sidebar.queue_percent, 65);
    }

    #[test]
    fn sidebar_effective_size_clamps_to_shell_bounds() {
        let mut config = ZerocodeConfig::default();
        config.sidebar.width = 1;
        config.sidebar.sessions_percent = u16::MAX;
        config.sidebar.queue_percent = u16::MAX;
        assert_eq!(config.effective_sidebar_width(), SIDEBAR_WIDTH_MIN);
        assert_eq!(
            config.effective_sidebar_sessions_percent(),
            SIDEBAR_SESSIONS_PERCENT_MAX
        );
        assert_eq!(
            config.effective_sidebar_queue_percent(),
            SIDEBAR_QUEUE_PERCENT_MAX
        );
        config.sidebar.width = u16::MAX;
        config.sidebar.sessions_percent = 1;
        config.sidebar.queue_percent = 1;
        assert_eq!(config.effective_sidebar_width(), SIDEBAR_WIDTH_MAX);
        assert_eq!(
            config.effective_sidebar_sessions_percent(),
            SIDEBAR_SESSIONS_PERCENT_MIN
        );
        assert_eq!(
            config.effective_sidebar_queue_percent(),
            SIDEBAR_QUEUE_PERCENT_MIN
        );
    }

    #[test]
    fn sidebar_leaf_write_preserves_comments_and_unknown_keys() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "# operator note\n[future] # keep this heading\nkeep   =   true # inline note\n\n[sidebar]\n# dock note\nvisible = false # keep this comment\nfuture_key = \"keep-me\"\n",
        );

        assert!(!persist_sidebar_visible(dir.path(), true).unwrap());
        let after = read(dir.path());
        assert!(after.contains("# operator note"));
        assert!(after.contains("keep   =   true # inline note"));
        assert!(after.contains("# dock note"));
        assert!(after.contains("visible = true # keep this comment"));
        assert!(after.contains("future_key = \"keep-me\""));
    }

    #[test]
    fn sidebar_leaf_write_reports_valid_environment_shadowing() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let _visible = EnvVarGuard::set("ZEROCODE_sidebar__visible", "false");
        let _side = EnvVarGuard::set("ZEROCODE_sidebar__side", "left");
        let _width = EnvVarGuard::set("ZEROCODE_sidebar__width", "30");
        let _split = EnvVarGuard::set("ZEROCODE_sidebar__sessions_percent", "45");
        let _queue_split = EnvVarGuard::set("ZEROCODE_sidebar__queue_percent", "40");

        assert!(persist_sidebar_visible(dir.path(), true).unwrap());
        assert!(persist_sidebar_side(dir.path(), SidebarSide::Right).unwrap());
        assert!(persist_sidebar_width(dir.path(), 24).unwrap());
        assert!(persist_sidebar_sessions_percent(dir.path(), 60).unwrap());
        assert!(persist_sidebar_queue_percent(dir.path(), 50).unwrap());
    }

    #[test]
    fn sidebar_leaf_write_refuses_malformed_or_non_table_data() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let before = "[sidebar]\nwidth = \"bad\"\n";
        seed(dir.path(), before);
        assert!(persist_sidebar_width(dir.path(), 28).is_err());
        assert_eq!(read(dir.path()), before);

        let before = "sidebar = \"not-a-table\"\n";
        seed(dir.path(), before);
        assert!(persist_sidebar_width(dir.path(), 28).is_err());
        assert_eq!(read(dir.path()), before);
    }

    /// Another zerocode can be reading the config while this one saves a
    /// sidebar change. That must not stop the save, and the reader keeps the
    /// contents it opened. Windows refuses a plain replace of an open file, so
    /// this pins the replace itself rather than leaving it to a race.
    #[test]
    fn sidebar_leaf_write_replaces_a_config_a_reader_holds_open() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(dir.path(), "[sidebar]\nwidth = 24\n");
        let mut held = std::fs::File::open(config_path(dir.path())).unwrap();

        persist_sidebar_width(dir.path(), 31).expect("an open reader must not stop the save");

        let held_config = std::io::read_to_string(&mut held).unwrap();
        assert_eq!(held_config, "[sidebar]\nwidth = 24\n");
        assert_eq!(load_persisted(dir.path()).unwrap().sidebar.width, 31);
    }

    #[test]
    fn effective_sidebar_side_migrates_legacy_todo_location_until_switch() {
        let mut config = ZerocodeConfig::default();
        config.todotracker.location = TodoTrackerLocation::Left;
        assert_eq!(config.effective_sidebar_side(), SidebarSide::Left);
        config.sidebar.side = Some(SidebarSide::Right);
        assert_eq!(config.effective_sidebar_side(), SidebarSide::Right);
    }

    #[test]
    fn sidebar_section_visibility_is_independent_and_preserves_document() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "# keep this note\n[sidebar]\nvisible = true # sessions\nwidth = 31\nside = \"left\"\nsessions_percent = 45\nqueue_percent = 65\nfuture_key = \"keep\"\n\n[todotracker]\nenabled = true\nenabled_at_start = true\nlocation = \"bottom\"\nwidth = 34\nmax_height = 7\n\n[future]\nkeep = true\n",
        );
        let initial = load_persisted(dir.path()).unwrap();
        assert!(initial.sidebar.visible);
        assert!(initial.sidebar.queue_visible);
        assert!(initial.sidebar.plan_visible);
        let before: toml::Table = toml::from_str(&read(dir.path())).unwrap();

        let writers: [fn(&Path, bool) -> Result<bool>; 3] = [
            persist_sidebar_visible,
            persist_sidebar_queue_visible,
            persist_sidebar_plan_visible,
        ];
        let keys = ["visible", "queue_visible", "plan_visible"];
        // Hide everything, then reopen each section independently.
        for visible in [false, true] {
            for (index, writer) in writers.iter().enumerate() {
                assert!(!writer(dir.path(), visible).unwrap());
                let cfg = load_persisted(dir.path()).unwrap();
                let states = [
                    cfg.sidebar.visible,
                    cfg.sidebar.queue_visible,
                    cfg.sidebar.plan_visible,
                ];
                for (other, state) in states.into_iter().enumerate() {
                    assert_eq!(state, if other <= index { visible } else { !visible });
                }
                assert_eq!(cfg.todotracker, initial.todotracker);
                let after: toml::Table = toml::from_str(&read(dir.path())).unwrap();
                for key in [
                    "width",
                    "side",
                    "sessions_percent",
                    "queue_percent",
                    "future_key",
                ] {
                    assert_eq!(after["sidebar"][key], before["sidebar"][key]);
                }
                assert_eq!(after["sidebar"][keys[index]].as_bool(), Some(visible));
                assert_eq!(after["future"], before["future"]);
                assert!(read(dir.path()).contains("# keep this note"));
                assert!(read(dir.path()).contains("# sessions"));
            }
        }
    }

    #[test]
    fn sidebar_visibility_overrides_do_not_leak_into_sibling_writes() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let _queue = EnvVarGuard::set("ZEROCODE_sidebar__queue_visible", "false");
        let _plan = EnvVarGuard::set("ZEROCODE_sidebar__plan_visible", "false");
        assert!(persist_sidebar_queue_visible(dir.path(), true).unwrap());
        assert!(persist_sidebar_plan_visible(dir.path(), true).unwrap());
        persist_sidebar_visible(dir.path(), false).unwrap();
        let persisted = load_persisted(dir.path()).unwrap();
        assert!(!persisted.sidebar.visible);
        assert!(persisted.sidebar.queue_visible);
        assert!(persisted.sidebar.plan_visible);
        let effective = ensure_and_load(dir.path()).unwrap();
        assert!(!effective.sidebar.queue_visible);
        assert!(!effective.sidebar.plan_visible);
        assert!(!persist_sidebar_queue_visible(dir.path(), false).unwrap());
        assert!(!persist_sidebar_plan_visible(dir.path(), false).unwrap());
    }

    #[test]
    fn sidebar_environment_side_and_splits_keep_strict_path_validation() {
        let mut config = ZerocodeConfig::default();
        assert!(config.sidebar.visible);
        assert!(config.sidebar.queue_visible);
        assert!(config.sidebar.plan_visible);
        set_prop(&mut config, "sidebar.side", "left").unwrap();
        set_prop(&mut config, "sidebar.width", "31").unwrap();
        set_prop(&mut config, "sidebar.sessions_percent", "45").unwrap();
        set_prop(&mut config, "sidebar.queue_percent", "65").unwrap();
        assert_eq!(config.effective_sidebar_side(), SidebarSide::Left);
        assert_eq!(config.effective_sidebar_width(), 31);
        assert_eq!(config.effective_sidebar_sessions_percent(), 45);
        assert_eq!(config.effective_sidebar_queue_percent(), 65);
        assert!(set_prop(&mut config, "sidebar.side", "middle").is_err());
        assert!(set_prop(&mut config, "sidebar.queue_visible", "invalid").is_err());
        assert!(set_prop(&mut config, "sidebar.plan_visible", "invalid").is_err());
        assert!(set_prop(&mut config, "sidebar.unknown", "true").is_err());
    }

    #[test]
    fn connection_section_round_trips() {
        let mut c = ZerocodeConfig::default();
        c.connection.wss.uri = Some("wss://host:9781".to_string());
        c.connection.wss.tls.skip_verify = true;
        c.connection.wss.tls.skip_verify_routes = vec!["wss://host:9781".to_string()];
        let body = toml::to_string_pretty(&c).unwrap();
        let back: ZerocodeConfig = toml::from_str(&body).unwrap();
        assert_eq!(back.connection.wss.uri.as_deref(), Some("wss://host:9781"));
        assert!(back.connection.wss.tls.skip_verify);
        assert_eq!(
            back.connection.wss.tls.skip_verify_routes,
            vec!["wss://host:9781"]
        );
    }

    #[test]
    fn a_token_file_alone_keeps_the_connection_section() {
        let mut c = ZerocodeConfig::default();
        c.connection.wss.auth_token_file = Some("/etc/zeroclaw/zerocode-bearer".to_string());
        let body = toml::to_string_pretty(&c).unwrap();
        let back: ZerocodeConfig = toml::from_str(&body).unwrap();
        assert_eq!(
            back.connection.wss.auth_token_file.as_deref(),
            Some("/etc/zeroclaw/zerocode-bearer"),
            "got:\n{body}"
        );
    }

    #[test]
    fn empty_connection_defaults_are_clean() {
        let c = ZerocodeConfig::default();
        assert!(c.connection.wss.uri.is_none());
        assert!(!c.connection.wss.tls.skip_verify);
        assert!(c.connection.wss.tls.skip_verify_routes.is_empty());
        let parsed: ZerocodeConfig = toml::from_str("locale = \"en\"\n").unwrap();
        assert!(parsed.connection.wss.uri.is_none());
        assert!(parsed.connection.wss.tls.skip_verify_routes.is_empty());
    }

    #[test]
    fn default_config_writes_no_connection_scaffolding() {
        let body = toml::to_string_pretty(&ZerocodeConfig::default()).unwrap();
        assert!(
            !body.contains("connection"),
            "default config must not emit any [connection] scaffolding; got:\n{body}"
        );
        assert!(!body.contains("skip_verify"), "got:\n{body}");
        assert!(!body.contains("wss"), "got:\n{body}");
    }

    #[test]
    fn first_run_file_has_no_connection_section() {
        // Reads the environment via `ensure_and_load`; serialize against the
        // env-mutating tests so a stray override cannot leak in.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        ensure_and_load(dir.path()).unwrap();
        let on_disk = read(dir.path());
        assert!(
            !on_disk.contains("connection"),
            "first-run file must not scaffold [connection]; got:\n{on_disk}"
        );
    }

    #[test]
    fn setting_one_field_materializes_only_that_path() {
        let dir = tempfile::tempdir().unwrap();
        persist_connection_field(dir.path(), "tls.skip_verify", toml::Value::Boolean(true))
            .unwrap();
        let on_disk = read(dir.path());
        assert!(on_disk.contains("[connection.wss.tls]"));
        assert!(on_disk.contains("skip_verify = true"));
        assert!(
            !on_disk.contains("skip_verify_routes"),
            "untouched fields must not appear; got:\n{on_disk}"
        );
    }

    #[test]
    fn route_acked_membership() {
        let tls = WssTlsSection {
            skip_verify_routes: vec!["wss://a:1".to_string(), "wss://b:2".to_string()],
            ..Default::default()
        };
        assert!(tls.route_acked("wss://a:1"));
        assert!(tls.route_acked("wss://b:2"));
        assert!(!tls.route_acked("wss://c:3"));
    }

    #[test]
    fn persist_wss_route_ack_dedups() {
        // Reads the environment via `ensure_and_load`; serialize against the
        // env-mutating tests so a stray override cannot leak in.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        persist_wss_route_ack(dir.path(), "wss://a:1").unwrap();
        persist_wss_route_ack(dir.path(), "wss://a:1").unwrap();
        persist_wss_route_ack(dir.path(), "wss://b:2").unwrap();
        let cfg = ensure_and_load(dir.path()).unwrap();
        assert_eq!(
            cfg.connection.wss.tls.skip_verify_routes,
            vec!["wss://a:1".to_string(), "wss://b:2".to_string()]
        );
    }

    #[test]
    fn persist_wss_route_ack_preserves_other_sections() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"nord\"\n\n[future]\nkeep = true\n",
        );
        persist_wss_route_ack(dir.path(), "wss://a:1").unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord"));
        assert_eq!(doc["future"]["keep"].as_bool(), Some(true));
        assert_eq!(
            doc["connection"]["wss"]["tls"]["skip_verify_routes"][0].as_str(),
            Some("wss://a:1")
        );
    }

    #[test]
    fn persist_connection_field_preserves_other_sections() {
        let dir = tempfile::tempdir().unwrap();
        seed(dir.path(), "[theme]\nname = \"nord\"\n");
        persist_connection_field(
            dir.path(),
            "uri",
            toml::Value::String("wss://host:9781".to_string()),
        )
        .unwrap();
        persist_connection_field(dir.path(), "tls.skip_verify", toml::Value::Boolean(true))
            .unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord"));
        assert_eq!(
            doc["connection"]["wss"]["uri"].as_str(),
            Some("wss://host:9781")
        );
        assert_eq!(
            doc["connection"]["wss"]["tls"]["skip_verify"].as_bool(),
            Some(true)
        );
    }

    // ── Todo tracker persistence tests ──────────────────────────────────────

    #[test]
    fn persist_todotracker_writes_section_and_preserves_others() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"nord\"\n\n[future]\nkeep = true\n",
        );
        let section = TodoTrackerSection {
            enabled: false,
            enabled_at_start: true,
            location: TodoTrackerLocation::Left,
            width: 40,
            max_height: 8,
        };
        persist_todotracker(dir.path(), &section).unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord"));
        assert_eq!(doc["future"]["keep"].as_bool(), Some(true));
        assert_eq!(doc["todotracker"]["enabled"].as_bool(), Some(false));
        assert_eq!(doc["todotracker"]["enabled_at_start"].as_bool(), Some(true));
        assert_eq!(doc["todotracker"]["location"].as_str(), Some("left"));
        assert_eq!(doc["todotracker"]["width"].as_integer(), Some(40));
        assert_eq!(doc["todotracker"]["max_height"].as_integer(), Some(8));
    }

    #[test]
    fn persist_todotracker_round_trips_through_load() {
        let dir = tempfile::tempdir().unwrap();
        let section = TodoTrackerSection {
            enabled: false,
            enabled_at_start: true,
            location: TodoTrackerLocation::Bottom,
            width: 48,
            max_height: 10,
        };
        persist_todotracker(dir.path(), &section).unwrap();
        let cfg = load_persisted(dir.path()).unwrap();
        assert!(!cfg.todotracker.enabled);
        assert!(cfg.todotracker.enabled_at_start);
        assert_eq!(cfg.todotracker.location, TodoTrackerLocation::Bottom);
        assert_eq!(cfg.todotracker.width, 48);
        assert_eq!(cfg.todotracker.max_height, 10);
    }

    #[test]
    fn persist_todotracker_creates_file_when_absent() {
        let dir = tempfile::tempdir().unwrap();
        let section = TodoTrackerSection {
            enabled: false,
            ..Default::default()
        };
        persist_todotracker(dir.path(), &section).unwrap();
        let doc: toml::Table = toml::from_str(&read(dir.path())).unwrap();
        assert_eq!(doc["todotracker"]["enabled"].as_bool(), Some(false));
    }

    #[test]
    fn bad_todotracker_does_not_blank_theme() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"dracula\"\n\n[todotracker]\nwidth = \"not_a_number\"\n",
        );
        // Asserts on-disk parsing/fallback, so read the persisted view: the
        // effective view would also layer in any ambient `ZEROCODE_*` override.
        let cfg = load_persisted(dir.path()).unwrap();
        assert_eq!(cfg.theme.name, "dracula");
        assert_eq!(cfg.todotracker.width, default_todotracker_width());
    }

    // The tolerant `load_persisted` path substitutes defaults for a malformed
    // `[todotracker]`, but the transition resolver must instead see an error so
    // it can preserve the live tracker rather than silently reset to defaults.
    #[test]
    fn resolve_todo_tracker_checked_errors_on_malformed_section() {
        let dir = tempfile::tempdir().unwrap();
        seed(
            dir.path(),
            "[theme]\nname = \"dracula\"\n\n[todotracker]\nwidth = \"not_a_number\"\n",
        );
        let err = resolve_todo_tracker_checked(dir.path())
            .expect_err("a malformed [todotracker] must surface as an error");
        assert!(
            format!("{err:#}").contains("[todotracker]")
                && format!("{err:#}").contains("malformed"),
            "error should name the malformed section, got: {err:#}"
        );
    }

    // A valid section resolves normally through the checked path.
    #[test]
    fn resolve_todo_tracker_checked_ok_on_valid_section() {
        // Resolves through `ensure_and_load`, which *reads* the environment, so
        // this must serialize against the env-mutating tests below even though
        // it sets nothing itself.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(dir.path(), "[todotracker]\nwidth = 41\nmax_height = 6\n");
        let settings =
            resolve_todo_tracker_checked(dir.path()).expect("a valid [todotracker] must resolve");
        assert_eq!(settings.width, 41);
        assert_eq!(settings.max_height, 6);
    }

    // An absent section resolves to defaults (not an error).
    #[test]
    fn resolve_todo_tracker_checked_ok_when_section_absent() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        seed(dir.path(), "[theme]\nname = \"dracula\"\n");
        let settings = resolve_todo_tracker_checked(dir.path())
            .expect("an absent [todotracker] must resolve to defaults");
        assert_eq!(settings.width, default_todotracker_width());
    }

    // ── Env override tests ──────────────────────────────────────────────────

    #[test]
    fn set_prop_todotracker_enabled() {
        let mut c = ZerocodeConfig::default();
        set_prop(&mut c, "todotracker.enabled", "false").unwrap();
        assert!(!c.todotracker.enabled);
    }

    #[test]
    fn set_prop_todotracker_width() {
        let mut c = ZerocodeConfig::default();
        set_prop(&mut c, "todotracker.width", "50").unwrap();
        assert_eq!(c.todotracker.width, 50);
    }

    #[test]
    fn set_prop_todotracker_location() {
        let mut c = ZerocodeConfig::default();
        set_prop(&mut c, "todotracker.location", "left").unwrap();
        assert_eq!(c.todotracker.location, TodoTrackerLocation::Left);
    }

    #[test]
    fn resolve_todo_tracker_checked_accepts_legacy_zero_width_from_file() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            config_path(dir.path()),
            "[todotracker]\nwidth = 0\nmax_height = 5\n",
        )
        .unwrap();

        assert!(resolve_todo_tracker_checked(dir.path()).is_ok());
        assert_eq!(load_persisted(dir.path()).unwrap().todotracker.width, 0);
    }

    #[test]
    fn resolve_todo_tracker_checked_accepts_legacy_zero_max_height_from_file() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            config_path(dir.path()),
            "[todotracker]\nwidth = 32\nmax_height = 0\n",
        )
        .unwrap();

        assert!(
            resolve_todo_tracker_checked(dir.path()).is_ok(),
            "legacy height must not reject settings for the shell-owned dock"
        );
    }

    #[test]
    fn resolve_todo_tracker_checked_accepts_legacy_zero_width_from_env() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            config_path(dir.path()),
            "[todotracker]\nwidth = 32\nmax_height = 5\n",
        )
        .unwrap();
        let _v = EnvVarGuard::set("ZEROCODE_todotracker__width", "0");

        assert!(
            resolve_todo_tracker_checked(dir.path()).is_ok(),
            "legacy width override must not reject settings for the shell-owned dock"
        );
    }

    #[test]
    fn resolve_todo_tracker_checked_accepts_legacy_zero_max_height_from_env() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let _v = EnvVarGuard::set("ZEROCODE_todotracker__max_height", "0");

        assert!(
            resolve_todo_tracker_checked(dir.path()).is_ok(),
            "legacy height override must not reject settings for the shell-owned dock"
        );
    }

    #[test]
    fn resolve_todo_tracker_checked_accepts_positive_dimensions() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            config_path(dir.path()),
            "[todotracker]\nwidth = 44\nmax_height = 9\n",
        )
        .unwrap();

        let s = resolve_todo_tracker_checked(dir.path())
            .expect("a valid section must still resolve unchanged");
        assert_eq!(s.width, 44);
        assert_eq!(s.max_height, 9);
    }

    // ── Single source of truth ──────────────────────────────────────────────
    //
    // `zerocode-config.toml` is the live source of truth for the tracker's
    // display settings: a value persisted by the Config pane must be visible
    // to the next session that resolves the file, never shadowed by a copy
    // cached at first-session start. Sessions resolve the file at each session
    // boundary, so this exercises that contract at the config layer: load,
    // persist a change (as the Config pane does), load again.
    #[test]
    fn resolved_settings_track_edits_across_sessions() {
        // Resolves the effective view, so serialize against the env-mutating
        // tests below: `std::env` is process-global.
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();

        // "Session 1" resolves the defaults.
        let cfg1 = ensure_and_load(dir.path()).unwrap();
        let t1 = cfg1.resolve_todo_tracker();

        // A Config-pane save persists a changed field to the same file.
        let mut tracker = cfg1.todotracker.clone();
        tracker.width = t1.width + 7;
        persist_todotracker(dir.path(), &tracker).unwrap();

        // "Session 2" must resolve the *edited* value, not a cached copy.
        let cfg2 = ensure_and_load(dir.path()).unwrap();
        let t2 = cfg2.resolve_todo_tracker();
        assert_eq!(
            t2.width,
            t1.width + 7,
            "second session must see the persisted tracker width edit"
        );
    }
    // ── Environment override contract ───────────────────────────────────────
    //
    // Canonical spelling is `ZEROCODE_<lowercase dotted path with __>`, e.g.
    // `ZEROCODE_todotracker__enabled`. These exercise real environment
    // variables through `ensure_and_load` rather than calling `set_prop`
    // directly, so the public spelling stays covered.

    use crate::test_support::{EnvVarGuard, env_test_lock};

    #[test]
    fn canonical_env_spelling_overrides_tracker_field() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let _v = EnvVarGuard::set("ZEROCODE_todotracker__enabled", "false");

        let cfg = ensure_and_load(dir.path()).unwrap();
        assert!(
            !cfg.todotracker.enabled,
            "ZEROCODE_todotracker__enabled must reach the parser and win over the file"
        );
    }

    #[test]
    fn canonical_env_spelling_overrides_tracker_width() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let _v = EnvVarGuard::set("ZEROCODE_todotracker__width", "41");

        let cfg = ensure_and_load(dir.path()).unwrap();
        assert_eq!(cfg.resolve_todo_tracker().width, 41);
    }

    #[test]
    fn canonical_env_spelling_overrides_default_sidebar_field() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let _v = EnvVarGuard::set("ZEROCODE_sidebar__visible", "false");

        let cfg = ensure_and_load(dir.path()).unwrap();
        assert!(
            !cfg.sidebar.visible,
            "a default config must materialize [sidebar] before schema-mirror overrides apply"
        );
    }

    #[test]
    fn unknown_env_path_is_rejected() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let _v = EnvVarGuard::set("ZEROCODE_todotracker__nope", "1");

        let err = ensure_and_load(dir.path()).expect_err("unknown path must hard-error");
        assert!(format!("{err:#}").contains("did not resolve to a config field"));
    }

    // Env overrides are process-transient: `load_persisted` is the on-disk
    // truth and must not see them, otherwise a Config-pane save of one field
    // would bake an env-injected value for another field into the file.
    #[test]
    fn env_overrides_do_not_reach_the_persisted_view() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let on_disk = TodoTrackerSection {
            width: 30,
            ..TodoTrackerSection::default()
        };
        persist_todotracker(dir.path(), &on_disk).unwrap();

        let _v = EnvVarGuard::set("ZEROCODE_todotracker__width", "77");

        // Effective view honors the override...
        assert_eq!(ensure_and_load(dir.path()).unwrap().todotracker.width, 77);
        // ...while the persisted view keeps the real file contents.
        assert_eq!(load_persisted(dir.path()).unwrap().todotracker.width, 30);
    }

    // Saving an unrelated field must rewrite the section from *disk* state, so
    // an env-injected value for a different field is never written through.
    #[test]
    fn saving_unrelated_field_does_not_persist_env_value() {
        let _guard = env_test_lock();
        let dir = tempfile::tempdir().unwrap();
        let on_disk = TodoTrackerSection {
            width: 30,
            max_height: 5,
            ..TodoTrackerSection::default()
        };
        persist_todotracker(dir.path(), &on_disk).unwrap();

        let _v = EnvVarGuard::set("ZEROCODE_todotracker__width", "77");

        // Edit an unrelated field starting from the persisted section.
        let mut candidate = load_persisted(dir.path()).unwrap().todotracker;
        candidate.max_height = 9;
        persist_todotracker(dir.path(), &candidate).unwrap();

        let reloaded = load_persisted(dir.path()).unwrap().todotracker;
        assert_eq!(reloaded.max_height, 9, "the edited field must be saved");
        assert_eq!(
            reloaded.width, 30,
            "the env-injected width must not be written to disk"
        );
    }
}

#[cfg(test)]
mod login_tests {
    use super::*;

    fn login(token: &str) -> OidcLogin {
        OidcLogin {
            auth_provider: "oidc.corp".into(),
            auth_token: token.into(),
            enroll_url: "https://gateway.example/zeroclaw".into(),
            expires_at: Some(2000000000),
            tls: WssTlsSection {
                ca_cert_path: "ca.pem".into(),
                ..Default::default()
            },
            gateway_tls: WssTlsSection::default(),
        }
    }

    #[test]
    fn save_login_is_url_scoped_preserves_other_settings_and_redacts_debug() {
        let dir = tempfile::tempdir().unwrap();
        let a = "wss://host:9781/a";
        let b = "wss://host:9781/b";
        std::fs::write(config_path(dir.path()), "[future]\nkeep = 'unchanged'\n").unwrap();
        persist_oidc_login(dir.path(), a, &login("sentinel-a"), true).unwrap();
        persist_oidc_login(dir.path(), b, &login("sentinel-b"), true).unwrap();
        let cfg = load_persisted(dir.path()).unwrap();
        assert_eq!(cfg.connection.wss.uri.as_deref(), Some(b));
        assert_eq!(cfg.connection.logins.len(), 2);
        assert_eq!(
            cfg.connection.wss_for(Some(a)).auth_token.as_deref(),
            Some("sentinel-a")
        );
        assert_eq!(
            cfg.connection.wss_for(None).auth_token.as_deref(),
            Some("sentinel-b")
        );
        let other = cfg.connection.wss_for(Some("wss://other:9781/"));
        assert!(other.auth_token.is_none());
        assert!(other.auth_provider.is_none());
        assert!(other.tls.ca_cert_path.is_empty());
        assert!(!format!("{:?}", cfg).contains("sentinel"));
        let doc: toml::Table =
            toml::from_str(&std::fs::read_to_string(config_path(dir.path())).unwrap()).unwrap();
        assert_eq!(doc["future"]["keep"].as_str(), Some("unchanged"));
        assert!(doc["connection"]["wss"].get("auth_token").is_none());
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt as _;
            assert_eq!(
                std::fs::metadata(config_path(dir.path()))
                    .unwrap()
                    .permissions()
                    .mode()
                    & 0o777,
                0o600
            );
        }
    }

    #[test]
    fn malformed_connection_refuses_save_without_losing_original() {
        let dir = tempfile::tempdir().unwrap();
        let original = "[connection]\nlogins = 7\n";
        std::fs::write(config_path(dir.path()), original).unwrap();
        assert!(persist_oidc_login(dir.path(), "wss://host/", &login("new-token"), true).is_err());
        assert_eq!(
            std::fs::read_to_string(config_path(dir.path())).unwrap(),
            original
        );
    }

    #[test]
    fn route_ack_updates_login_not_legacy_wss() {
        let dir = tempfile::tempdir().unwrap();
        let uri = "wss://host:9781/";
        persist_oidc_login(dir.path(), uri, &login("test-token"), true).unwrap();
        persist_wss_route_ack(dir.path(), uri).unwrap();
        let cfg = load_persisted(dir.path()).unwrap();
        assert!(cfg.connection.wss_for(Some(uri)).tls.route_acked(uri));
        assert!(cfg.connection.wss.tls.skip_verify_routes.is_empty());
    }
    #[test]
    fn renewing_one_url_does_not_change_the_default_destination() {
        let dir = tempfile::tempdir().unwrap();
        let a = "wss://host:9781/a";
        let b = "wss://host:9781/b";
        persist_oidc_login(dir.path(), a, &login("old-a"), true).unwrap();
        persist_oidc_login(dir.path(), b, &login("b-token"), true).unwrap();
        persist_oidc_login(dir.path(), a, &login("new-a"), false).unwrap();
        let cfg = load_persisted(dir.path()).unwrap();
        assert_eq!(cfg.connection.wss.uri.as_deref(), Some(b));
        assert_eq!(cfg.connection.logins[a].auth_token, "new-a");
        assert_eq!(cfg.connection.logins[b].auth_token, "b-token");
    }

    #[test]
    fn connection_editor_changes_the_selected_logins_tls() {
        let dir = tempfile::tempdir().unwrap();
        let uri = "wss://host:9781/";
        persist_oidc_login(dir.path(), uri, &login("test-token"), true).unwrap();
        persist_connection_field(dir.path(), "tls.skip_verify", toml::Value::Boolean(true))
            .unwrap();
        let cfg = load_persisted(dir.path()).unwrap();
        assert!(cfg.connection.wss_for(None).tls.skip_verify);
        assert!(!cfg.connection.wss.tls.skip_verify);
    }

    #[test]
    fn equivalent_manual_url_keeps_credentials_when_other_logins_exist() {
        let mut cfg = ZerocodeConfig::default();
        cfg.connection.wss.uri = Some("wss://legacy.example:9781".into());
        cfg.connection.wss.auth_token = Some("manual-token".into());
        cfg.connection.wss.auth_token_file = Some("manual-token-file".into());
        cfg.connection.wss.auth_provider = Some("native".into());
        cfg.connection.wss.enroll_url = Some("https://legacy.example:42617".into());
        cfg.connection.wss.tls.ca_cert_path = "legacy-ca.pem".into();
        cfg.connection.wss.tls.client_cert_path = "legacy-client.pem".into();
        cfg.connection.wss.tls.client_key_path = "legacy-key.pem".into();
        cfg.connection
            .logins
            .insert("wss://other.example:9781/".into(), login("other-token"));

        let kept = cfg.connection.wss_for(Some("wss://legacy.example:9781/"));
        assert_eq!(kept.auth_token.as_deref(), Some("manual-token"));
        assert_eq!(kept.auth_token_file.as_deref(), Some("manual-token-file"));
        assert_eq!(kept.auth_provider.as_deref(), Some("native"));
        assert_eq!(
            kept.enroll_url.as_deref(),
            Some("https://legacy.example:42617")
        );
        assert_eq!(kept.tls.ca_cert_path, "legacy-ca.pem");
        assert_eq!(kept.tls.client_cert_path, "legacy-client.pem");
        assert_eq!(kept.tls.client_key_path, "legacy-key.pem");
        assert!(
            !cfg.connection
                .uses_scoped_credentials(Some("wss://legacy.example:9781/")),
            "an equivalent spelling is still the manual connection"
        );

        let other_path = cfg
            .connection
            .wss_for(Some("wss://legacy.example:9781/rpc"));
        assert!(
            other_path.auth_token.is_none(),
            "a different path is a different destination"
        );
        assert!(other_path.tls.ca_cert_path.is_empty());

        let other = cfg
            .connection
            .wss_for(Some("wss://elsewhere.example:9781/"));
        assert!(other.auth_token.is_none());
        assert!(other.auth_provider.is_none());
        assert!(other.tls.ca_cert_path.is_empty());
        assert!(other.tls.client_cert_path.is_empty());
        assert!(
            cfg.connection
                .uses_scoped_credentials(Some("wss://elsewhere.example:9781/")),
            "a different daemon must not reuse the manual credential files"
        );
    }

    #[test]
    fn invalid_saved_login_never_falls_back_to_another_principal() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            config_path(dir.path()),
            "[connection.logins.\"wss://host/\"]\nauth_token = 'token-without-provider'\n",
        )
        .unwrap();
        let error = load_persisted(dir.path()).unwrap_err();
        assert!(error.downcast_ref::<InvalidSavedLogin>().is_some());
        let rendered = error.to_string();
        assert_eq!(rendered, crate::i18n::t("zc-config-invalid-saved-login"));
        assert_ne!(rendered, "{zc-config-invalid-saved-login}");
    }

    fn held_login_document() -> String {
        "\
[future]
keep = \"unchanged\"

[connection.logins.\"wss://held.example/\"]
auth_provider = \"oidc.corp\"
auth_token = \"held-token\"
enroll_url = \"https://gateway.example/zeroclaw\"
"
        .to_string()
    }

    /// Hold the config lock, start `writer`, and publish `during_hold` only
    /// once `writer` is blocked. The writer must re-read after it acquires the
    /// lock; a snapshot taken before the wait would drop `during_hold`.
    fn assert_writer_rereads_under_lock(
        dir: &Path,
        during_hold: &str,
        writer: impl FnOnce(&Path) + Send + 'static,
    ) {
        let held = ConfigWriteLock::acquire(dir).expect("the test lock must be free");
        let dir = dir.to_path_buf();
        let (started_tx, started_rx) = std::sync::mpsc::channel();
        let writer_dir = dir.clone();
        let handle = std::thread::spawn(move || {
            started_tx.send(()).expect("test thread still listening");
            writer(&writer_dir);
        });
        started_rx.recv().expect("writer started");
        // The sleep only lets the writer reach the lock. Finishing while it
        // is held means the writer did not take the lock at all.
        std::thread::sleep(std::time::Duration::from_millis(250));
        assert!(
            !handle.is_finished(),
            "writer published while another holder still had the config lock"
        );
        std::fs::write(config_path(&dir), during_hold).unwrap();
        drop(held);
        handle.join().expect("writer thread");
    }

    #[test]
    fn a_login_saved_while_another_save_waits_is_not_dropped() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(config_path(dir.path()), "[future]\nkeep = \"seed\"\n").unwrap();
        assert_writer_rereads_under_lock(dir.path(), &held_login_document(), |dir| {
            persist_oidc_login(
                dir,
                "wss://incoming.example/",
                &login("incoming-token"),
                false,
            )
            .expect("the waiting login must save once the lock is free");
        });
        let cfg = load_persisted(dir.path()).unwrap();
        assert_eq!(
            cfg.connection
                .logins
                .get("wss://held.example/")
                .map(|saved| saved.auth_token.as_str()),
            Some("held-token"),
            "a snapshot taken before the lock would erase the login published while waiting"
        );
        assert_eq!(
            cfg.connection
                .logins
                .get("wss://incoming.example/")
                .map(|saved| saved.auth_token.as_str()),
            Some("incoming-token")
        );
        let doc: toml::Table =
            toml::from_str(&std::fs::read_to_string(config_path(dir.path())).unwrap()).unwrap();
        assert_eq!(doc["future"]["keep"].as_str(), Some("unchanged"));
    }

    #[test]
    fn theme_and_sidebar_saves_reread_under_the_same_lock() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(config_path(dir.path()), "[future]\nkeep = \"seed\"\n").unwrap();
        assert_writer_rereads_under_lock(dir.path(), &held_login_document(), |dir| {
            persist_theme(dir, "gruvbox").expect("theme save must wait, then publish");
        });
        let cfg = load_persisted(dir.path()).unwrap();
        assert_eq!(cfg.theme.name, "gruvbox");
        assert_eq!(
            cfg.connection
                .logins
                .get("wss://held.example/")
                .map(|saved| saved.auth_token.as_str()),
            Some("held-token"),
            "a theme save must not publish a snapshot taken before the lock"
        );

        std::fs::write(config_path(dir.path()), "[future]\nkeep = \"seed\"\n").unwrap();
        assert_writer_rereads_under_lock(dir.path(), &held_login_document(), |dir| {
            persist_sidebar_width(dir, 31).expect("sidebar save must wait, then publish");
        });
        let cfg = load_persisted(dir.path()).unwrap();
        assert_eq!(cfg.sidebar.width, 31);
        assert_eq!(
            cfg.connection
                .logins
                .get("wss://held.example/")
                .map(|saved| saved.auth_token.as_str()),
            Some("held-token"),
            "a sidebar save must not publish a snapshot taken before the lock"
        );
    }

    #[test]
    fn keybinding_migration_rereads_under_the_config_lock() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            config_path(dir.path()),
            "[keybindings]\n\"input_bar.clear_input\" = \"ctrl+u\"\n",
        )
        .unwrap();
        let during_hold = "\
[keybindings]
\"input_bar.clear_input\" = \"ctrl+u\"

[connection.logins.\"wss://held.example/\"]
auth_provider = \"oidc.corp\"
auth_token = \"held-token\"
enroll_url = \"https://gateway.example/zeroclaw\"
";
        assert_writer_rereads_under_lock(dir.path(), during_hold, |dir| {
            let cfg = load_persisted(dir).expect("migration must finish once the lock is free");
            assert_eq!(
                cfg.connection
                    .logins
                    .get("wss://held.example/")
                    .map(|saved| saved.auth_token.as_str()),
                Some("held-token"),
                "migration must re-read under the lock"
            );
        });
        let body = std::fs::read_to_string(config_path(dir.path())).unwrap();
        assert!(
            body.contains("held-token"),
            "migration must not publish the pre-lock snapshot:\n{body}"
        );
        assert!(
            body.contains("primary+u"),
            "the legacy binding must still be migrated:\n{body}"
        );
        assert!(
            !body.contains("ctrl+u"),
            "the legacy spelling must not remain:\n{body}"
        );
    }

    #[test]
    fn concurrent_login_saves_keep_both_urls() {
        let dir = tempfile::tempdir().unwrap();
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(2));
        let mut handles = Vec::new();
        for (url, token) in [
            ("wss://alpha.example/", "alpha-final"),
            ("wss://beta.example/", "beta-final"),
        ] {
            let dir = dir.path().to_path_buf();
            let barrier = barrier.clone();
            handles.push(std::thread::spawn(move || {
                barrier.wait();
                for i in 0..20 {
                    let value = if i == 19 {
                        token.to_string()
                    } else {
                        format!("{token}-{i}")
                    };
                    persist_oidc_login(&dir, url, &login(&value), false)
                        .expect("concurrent login save");
                }
            }));
        }
        for handle in handles {
            handle.join().expect("concurrent login thread");
        }
        let cfg = load_persisted(dir.path()).unwrap();
        assert_eq!(
            cfg.connection
                .logins
                .get("wss://alpha.example/")
                .map(|saved| saved.auth_token.as_str()),
            Some("alpha-final")
        );
        assert_eq!(
            cfg.connection
                .logins
                .get("wss://beta.example/")
                .map(|saved| saved.auth_token.as_str()),
            Some("beta-final")
        );
    }

    #[test]
    fn concurrent_theme_and_locale_persists_keep_both_updates() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            config_path(dir.path()),
            "[theme]\nname = \"default\"\n\n[future]\nkeep = true\n",
        )
        .unwrap();
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(2));
        let theme_dir = dir.path().to_path_buf();
        let locale_dir = dir.path().to_path_buf();
        let theme_barrier = barrier.clone();
        let locale_barrier = barrier;
        let theme = std::thread::spawn(move || {
            theme_barrier.wait();
            for i in 0..20 {
                let name = if i == 19 {
                    "nord".to_string()
                } else {
                    format!("nord-{i}")
                };
                persist_theme(&theme_dir, &name).expect("concurrent theme save");
            }
        });
        let locale = std::thread::spawn(move || {
            locale_barrier.wait();
            for i in 0..20 {
                let value = if i == 19 { "fr" } else { "en" };
                persist_locale(&locale_dir, value).expect("concurrent locale save");
            }
        });
        theme.join().expect("theme persist thread");
        locale.join().expect("locale persist thread");
        let doc: toml::Table =
            toml::from_str(&std::fs::read_to_string(config_path(dir.path())).unwrap()).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord"));
        assert_eq!(doc["locale"].as_str(), Some("fr"));
        assert_eq!(doc["future"]["keep"].as_bool(), Some(true));
    }

    #[test]
    fn concurrent_theme_and_sidebar_persists_keep_both_updates() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            config_path(dir.path()),
            "[theme]\nname = \"default\"\n\n[sidebar]\nvisible = true\n",
        )
        .unwrap();
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(2));
        let theme_dir = dir.path().to_path_buf();
        let sidebar_dir = dir.path().to_path_buf();
        let theme_barrier = barrier.clone();
        let sidebar_barrier = barrier;
        let theme = std::thread::spawn(move || {
            theme_barrier.wait();
            for i in 0..20 {
                let name = if i == 19 {
                    "nord".to_string()
                } else {
                    format!("nord-{i}")
                };
                persist_theme(&theme_dir, &name).expect("concurrent theme save");
            }
        });
        let sidebar = std::thread::spawn(move || {
            sidebar_barrier.wait();
            for i in 0..20 {
                persist_sidebar_visible(&sidebar_dir, i != 19).expect("concurrent sidebar save");
            }
        });
        theme.join().expect("theme persist thread");
        sidebar.join().expect("sidebar persist thread");
        let doc: toml::Table =
            toml::from_str(&std::fs::read_to_string(config_path(dir.path())).unwrap()).unwrap();
        assert_eq!(doc["theme"]["name"].as_str(), Some("nord"));
        assert_eq!(doc["sidebar"]["visible"].as_bool(), Some(false));
    }

    #[test]
    fn a_config_lock_that_is_never_released_fails_with_an_actionable_error() {
        let dir = tempfile::tempdir().unwrap();
        let _held = ConfigWriteLock::acquire(dir.path()).unwrap();
        let started = std::time::Instant::now();
        let err =
            match ConfigWriteLock::acquire_within(dir.path(), std::time::Duration::from_millis(80))
            {
                Err(error) => format!("{error:#}"),
                Ok(_) => panic!("a lock held by another writer must not block forever"),
            };
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "the wait must be bounded"
        );
        let config = config_path(dir.path()).display().to_string();
        let lock = dir.path().join(CONFIG_LOCK_FILE).display().to_string();
        let expected = crate::i18n::t_args(
            "zc-config-save-lock-timeout",
            &[("config", &config), ("lock", &lock), ("seconds", "0")],
        );
        assert_ne!(
            expected, "{zc-config-save-lock-timeout}",
            "the timeout key must resolve from the English catalogue"
        );
        assert!(
            err.contains(&expected),
            "the timeout must use the catalogue message, got: {err}"
        );
    }

    #[cfg(unix)]
    #[test]
    fn a_symlink_lock_file_is_rejected_without_changing_its_target() {
        use std::os::unix::fs::PermissionsExt as _;
        let dir = tempfile::tempdir().unwrap();
        let config = config_path(dir.path());
        std::fs::write(&config, "[theme]\nname = \"nord\"\n").unwrap();
        std::fs::set_permissions(&config, std::fs::Permissions::from_mode(0o644)).unwrap();
        std::os::unix::fs::symlink(&config, dir.path().join(CONFIG_LOCK_FILE)).unwrap();
        let before = std::fs::read(&config).unwrap();

        let err = persist_theme(dir.path(), "gruvbox").unwrap_err();
        let err = format!("{err:#}");
        assert!(
            err.contains(CONFIG_LOCK_FILE) || err.contains("not a regular file"),
            "got: {err}"
        );
        assert_eq!(std::fs::read(&config).unwrap(), before);
        assert_eq!(
            std::fs::metadata(&config).unwrap().permissions().mode() & 0o777,
            0o644,
            "rejecting the symlink must not chmod the config file"
        );
        assert_ne!(
            crate::i18n::t_args("zc-config-lock-not-regular", &[("path", "lock")]),
            "{zc-config-lock-not-regular}"
        );
    }
}
