//! Action enums for the keymap.

use serde::{Deserialize, Serialize};

use super::chord::Chord;

fn distinct_effective_chords(chords: Vec<Chord>) -> Vec<Chord> {
    let mut distinct = Vec::with_capacity(chords.len());
    for chord in chords {
        if !distinct
            .iter()
            .any(|existing: &Chord| existing.same_key(&chord))
        {
            distinct.push(chord);
        }
    }
    distinct
}

macro_rules! keyactions {
    (
        $vis:vis enum $name:ident ( $tag:literal ) {
            $( $variant:ident [ $($chord:expr),* $(,)? ] => $label:expr ),* $(,)?
        }
    ) => {
        #[derive(Debug, Clone, Copy, Eq, PartialEq, Hash, Serialize, Deserialize)]
        #[serde(rename_all = "snake_case")]
        $vis enum $name {
            $( $variant ),*
        }

        impl $name {
            /// Stable per-enum tag namespacing serialized keys
            /// (`"<tag>.<variant>"`).
            pub const TAG: &'static str = $tag;

            /// Every variant in declaration order — walked by the
            /// keybind surface and override loader.
            pub fn variants() -> &'static [$name] {
                &[ $( $name::$variant ),* ]
            }

            pub fn label(&self) -> &'static str {
                match self {
                    $( $name::$variant => $label ),*
                }
            }

            /// This variant's serialized (snake_case) name, via serde so
            /// it can't drift from the wire form.
            pub fn variant_name(&self) -> String {
                serde_json::to_string(self)
                    .ok()
                    .map(|s| s.trim_matches('"').to_string())
                    .unwrap_or_default()
            }

            /// Fully-qualified action key: `"<tag>.<variant>"`.
            pub fn action_key(&self) -> String {
                format!("{}.{}", Self::TAG, self.variant_name())
            }

            /// Compile-time default chords for this variant.
            pub fn default_chords(&self) -> Vec<Chord> {
                let chords = match self {
                    $( $name::$variant => vec![ $( $chord ),* ] ),*
                };
                distinct_effective_chords(chords)
            }

            pub fn bindings() -> Vec<(Chord, $name)> {
                let mut out: Vec<(Chord, $name)> = Vec::new();
                for action in Self::variants() {
                    for chord in action.default_chords() {
                        out.push((chord, *action));
                    }
                }
                out
            }

            pub fn from_chord(event: &crossterm::event::KeyEvent) -> Option<$name> {
                super::match_chord(&Self::resolved_bindings(), event)
            }

            /// Bindings after applying any runtime override for `TAG`;
            /// falls back to the compile-time table when none is active.
            /// Sparse: an un-overridden variant keeps its default chords.
            ///
            /// An explicitly bound chord outranks a merely retained default,
            /// whichever action declares it first. Without that, shipping a new
            /// default chord would silently take a chord the operator had
            /// already assigned elsewhere, because dispatch takes the first
            /// match in declaration order.
            ///
            /// The claim is tested with `Chord::same_key`, not `==`: dispatch
            /// compares effective event modifiers, so on darwin an explicit
            /// `super+a` and a retained `primary+a` are one chord there and
            /// two here. Raw equality left the shadowed default in the table
            /// and the operator's own binding lost to it.
            pub fn resolved_bindings() -> Vec<(Chord, $name)> {
                let Some(over) = super::overrides::lookup(Self::TAG) else {
                    return Self::bindings();
                };
                let claimed: Vec<Chord> = Self::variants()
                    .iter()
                    .filter_map(|v| over.get(&v.variant_name()))
                    .flatten()
                    .cloned()
                    .collect();
                let mut out: Vec<(Chord, $name)> = Vec::new();
                for v in Self::variants() {
                    let chords = match over.get(&v.variant_name()) {
                        Some(cs) => cs.clone(),
                        None => v
                            .default_chords()
                            .into_iter()
                            .filter(|c| !claimed.iter().any(|k| k.same_key(c)))
                            .collect(),
                    };
                    for c in chords {
                        out.push((c, *v));
                    }
                }
                out
            }
        }

        impl super::RebindableActions for $name {
            fn tag() -> &'static str {
                Self::TAG
            }
            fn all() -> &'static [Self] {
                Self::variants()
            }
            fn key(&self) -> String {
                self.action_key()
            }
            fn human_label(&self) -> &'static str {
                self.label()
            }
            fn defaults(&self) -> Vec<Chord> {
                self.default_chords()
            }
            fn resolved(&self) -> Vec<Chord> {
                Self::resolved_bindings()
                    .into_iter()
                    .filter(|(_, a)| a == self)
                    .map(|(c, _)| c)
                    .collect()
            }
        }
    };
}

use crossterm::event::{KeyCode, KeyModifiers};

keyactions! {
    pub enum GlobalAction ("global") {
        Quit         [Chord::ctrl('c')]                                 => "quit",
        Help         [
            Chord::char('?'),
            Chord::ctrl('g'),
        ]                                                              => "help",
        PaneNavLeft  [Chord::with(KeyCode::Left, KeyModifiers::ALT), Chord::with(KeyCode::Char('b'), KeyModifiers::ALT)]  => "prev pane",
        PaneNavRight [Chord::with(KeyCode::Right, KeyModifiers::ALT), Chord::with(KeyCode::Char('f'), KeyModifiers::ALT)] => "next pane",
        ReloadDaemon [Chord::primary('r'), Chord::ctrl('r')]            => "reload daemon",
        ToggleSidebar [Chord::ctrl('b')]                                => "toggle sidebar",
        FocusSession1 [Chord::with_primary(KeyCode::Char('1'), KeyModifiers::CONTROL)] => "focus session 1",
        FocusSession2 [Chord::with_primary(KeyCode::Char('2'), KeyModifiers::CONTROL)] => "focus session 2",
        FocusSession3 [Chord::with_primary(KeyCode::Char('3'), KeyModifiers::CONTROL)] => "focus session 3",
        FocusSession4 [Chord::with_primary(KeyCode::Char('4'), KeyModifiers::CONTROL)] => "focus session 4",
        FocusSession5 [Chord::with_primary(KeyCode::Char('5'), KeyModifiers::CONTROL)] => "focus session 5",
        FocusSession6 [Chord::with_primary(KeyCode::Char('6'), KeyModifiers::CONTROL)] => "focus session 6",
        FocusSession7 [Chord::with_primary(KeyCode::Char('7'), KeyModifiers::CONTROL)] => "focus session 7",
        FocusSession8 [Chord::with_primary(KeyCode::Char('8'), KeyModifiers::CONTROL)] => "focus session 8",
        ConfirmYes   []                                                 => "confirm",
        ConfirmNo    []                                                 => "cancel",
    }
}

keyactions! {
    pub enum ChatTabAction ("chat") {
        ScrollUp                [] => "scroll up",
        ScrollDown              [] => "scroll down",
        PageUp                  [Chord::key(KeyCode::PageUp)] => "page up",
        PageDown                [Chord::key(KeyCode::PageDown)] => "page down",
        JumpStart               [Chord::char('g'), Chord::with(KeyCode::Home, KeyModifiers::CONTROL)] => "jump to start",
        JumpEnd                 [Chord::char('G'), Chord::with(KeyCode::End, KeyModifiers::CONTROL)] => "jump to end",
        // Use alt+shift+up/down to avoid macOS Mission Control conflict (ctrl+up/down)
        // and queue navigation conflict (alt+up/down).
        BrowseEnter             [
            Chord::with(KeyCode::Up, KeyModifiers::ALT.union(KeyModifiers::SHIFT)),
            Chord::ctrl('k'),
        ] => "enter browse mode",
        BrowseExit              [Chord::with(KeyCode::Down, KeyModifiers::ALT.union(KeyModifiers::SHIFT))] => "exit browse mode",
        BrowseUp                [Chord::key(KeyCode::Up)] => "browse prev",
        BrowseDown              [Chord::key(KeyCode::Down)] => "browse next",
        BrowseUpVim             [Chord::char('k')] => "browse prev (vim)",
        BrowseDownVim           [Chord::char('j')] => "browse next (vim)",
        BrowseSelectExtend      [Chord::shift(KeyCode::Up)] => "extend selection up",
        BrowseSelectExtendDown  [Chord::shift(KeyCode::Down)] => "extend selection down",
        FastScrollUp            [Chord::with_primary(KeyCode::Up, KeyModifiers::SHIFT), Chord::with(KeyCode::Up, KeyModifiers::CONTROL.union(KeyModifiers::SHIFT))] => "fast scroll up",
        FastScrollDown          [Chord::with_primary(KeyCode::Down, KeyModifiers::SHIFT), Chord::with(KeyCode::Down, KeyModifiers::CONTROL.union(KeyModifiers::SHIFT))] => "fast scroll down",
        BrowseExitSelection     [Chord::key(KeyCode::Esc)] => "exit selection",
        CopySelection           [
            Chord::char('y'),
            Chord::with(KeyCode::Char('c'), KeyModifiers::SUPER),
        ] => "copy selection",
        CopyAllVisible          [Chord::with(KeyCode::Char('C'), KeyModifiers::CONTROL.union(KeyModifiers::SHIFT))] => "copy all visible",
        ToggleThoughts          [Chord::char('t')] => "toggle thoughts",
        TodoToggle              [Chord::primary('p'), Chord::ctrl('p')] => "toggle todo tracker",
        NewSession              [Chord::ctrl('n')] => "new session",
        SwitchSession           [Chord::ctrl('s')] => "switch session",
        RefreshSession          [Chord::key(KeyCode::F(5))] => "refresh focused session",
        DeleteSession           [] => "delete session",
        CancelTurn              [Chord::primary('d'), Chord::ctrl('d')] => "cancel turn",
        ApprovalApprove         [Chord::key(KeyCode::Enter)] => "approve",
        ApprovalDeny            [] => "deny",
        ApprovalApproveAll      [Chord::char('a')] => "approve all",
        ApprovalApproveEdit     [Chord::char('e')] => "approve + edit",
        DismissModal            [] => "dismiss",
        PauseResumeQueue        [Chord::with(KeyCode::Char('p'), KeyModifiers::ALT)] => "pause/resume queue",
        QueueNavUp              [Chord::with(KeyCode::Up, KeyModifiers::ALT)] => "queue prev",
        QueueNavDown            [Chord::with(KeyCode::Down, KeyModifiers::ALT)] => "queue next",
        QueueSendNow            [Chord::with(KeyCode::Char('s'), KeyModifiers::ALT)] => "send queued now",
        QueueCopy               [Chord::with(KeyCode::Char('c'), KeyModifiers::ALT)] => "copy queued",
        QueueDelete             [Chord::with(KeyCode::Char('x'), KeyModifiers::ALT)] => "delete queued",
        QueueEdit               [Chord::with(KeyCode::Char('e'), KeyModifiers::ALT)] => "edit queued",
        ErrorDismiss            [Chord::char('q')] => "dismiss error",
    }
}

keyactions! {
    pub enum LogsTabAction ("logs") {
        Up               [Chord::char('k'), Chord::key(KeyCode::Up)] => "prev event",
        Down             [Chord::char('j'), Chord::key(KeyCode::Down)] => "next event",
        PageUp           [Chord::key(KeyCode::PageUp)] => "page up",
        PageDown         [Chord::key(KeyCode::PageDown)] => "page down",
        JumpStart        [Chord::char('g'), Chord::key(KeyCode::Home)] => "jump to start",
        JumpEnd          [Chord::char('G'), Chord::key(KeyCode::End)] => "jump to end",
        OpenDetail       [Chord::key(KeyCode::Enter)] => "open detail",
        CloseDetail      [] => "close detail",
        DetailScrollUp   [Chord::char('K')] => "detail scroll up",
        DetailScrollDown [Chord::char('J')] => "detail scroll down",
        DetailWidenLeft  [Chord::shift(KeyCode::Left)] => "widen detail left",
        DetailWidenRight [Chord::shift(KeyCode::Right)] => "widen detail right",
        DetailWidenUp    [Chord::shift(KeyCode::Up)] => "widen detail up",
        DetailWidenDown  [Chord::shift(KeyCode::Down)] => "widen detail down",
        ToggleFollow     [Chord::char('f')] => "toggle follow",
        BeginSearch      [Chord::char('/')] => "search",
        ClearSearch      [Chord::char('c')] => "clear search",
        BeginRunFilter   [Chord::char('r')] => "filter by SOP run",
        ClearRunFilter   [Chord::char('R')] => "clear SOP run filter",
        CopyDetail       [Chord::char('y')] => "copy detail",
        CopySelection    [
            Chord::with(KeyCode::Char('c'), KeyModifiers::SUPER),
            Chord::with(KeyCode::Char('C'), KeyModifiers::CONTROL.union(KeyModifiers::SHIFT)),
        ] => "copy selection/row",
        IncreaseLevel    [Chord::char('+'), Chord::char('=')] => "verbosity up",
        DecreaseLevel    [Chord::char('-')] => "verbosity down",
    }
}

keyactions! {
    pub enum DashboardTabAction ("dashboard") {
        Up               [Chord::char('k'), Chord::key(KeyCode::Up)] => "prev",
        Down             [Chord::char('j'), Chord::key(KeyCode::Down)] => "next",
        NextTab          [Chord::key(KeyCode::Tab), Chord::char('l'), Chord::key(KeyCode::Right)] => "next tab",
        PrevTab          [Chord::key(KeyCode::BackTab), Chord::char('h'), Chord::key(KeyCode::Left)] => "prev tab",
        Tab1             [Chord::char('1')] => "tab 1",
        Tab2             [Chord::char('2')] => "tab 2",
        Tab3             [Chord::char('3')] => "tab 3",
        Tab4             [Chord::char('4')] => "tab 4",
        Tab5             [Chord::char('5')] => "tab 5",
        Tab6             [Chord::char('6')] => "tab 6",
        Tab7             [Chord::char('7')] => "tab 7",
        OpenDetail       [Chord::key(KeyCode::Enter)] => "open detail",
        CloseDetail      [] => "close detail",
        DetailScrollUp   [Chord::char('K')] => "detail scroll up",
        DetailScrollDown [Chord::char('J')] => "detail scroll down",
        DetailWidenLeft  [Chord::shift(KeyCode::Left)] => "widen detail left",
        DetailWidenRight [Chord::shift(KeyCode::Right)] => "widen detail right",
        DetailWidenUp    [Chord::shift(KeyCode::Up)] => "widen detail up",
        DetailWidenDown  [Chord::shift(KeyCode::Down)] => "widen detail down",
        BeginSearch      [Chord::char('/')] => "search",
        CopyDetail       [Chord::char('c')] => "copy detail",
        RenameAgent      [Chord::char('e')] => "rename agent",
        KillSession      [Chord::char('X')] => "kill session",
        TriggerCron      [Chord::char('R')] => "run cron job now",
        Refresh          [Chord::char('r')] => "refresh",
        JumpStart        [Chord::char('g'), Chord::key(KeyCode::Home)] => "jump to start",
        JumpEnd          [Chord::char('G'), Chord::key(KeyCode::End)] => "jump to end",
    }
}

keyactions! {
    pub enum ConfigTabAction ("config_tab") {
        Up            [Chord::char('k'), Chord::key(KeyCode::Up)] => "prev",
        Down          [Chord::char('j'), Chord::key(KeyCode::Down)] => "next",
        Enter         [Chord::key(KeyCode::Enter)] => "open",
        Back          [Chord::char('q'), Chord::key(KeyCode::Esc)] => "back",
        TabLeft       [Chord::char('h'), Chord::key(KeyCode::Left)] => "prev tab",
        TabRight      [Chord::char('l'), Chord::key(KeyCode::Right)] => "next tab",
        SectionNext   [Chord::key(KeyCode::Tab)] => "next section",
        SectionPrev   [Chord::key(KeyCode::BackTab)] => "prev section",
        BeginSearch   [Chord::char('/')] => "search",
        ToggleSecret  [Chord::char('x')] => "toggle secret",
        DeleteRow     [Chord::char('d')] => "delete row",
        RenameAlias   [Chord::char('e')] => "rename provider alias",
        ApplyTemplate [Chord::char('t')] => "apply template",
        ApplicationStatus [Chord::char('s')] => "application status",
        PageUp [Chord::key(KeyCode::PageUp)] => "page up",
        PageDown [Chord::key(KeyCode::PageDown)] => "page down",
        JumpStart [Chord::key(KeyCode::Home)] => "jump to start",
        JumpEnd [Chord::key(KeyCode::End)] => "jump to end",
    }
}

keyactions! {
    pub enum CaptureAction ("capture") {
        Cancel [Chord::key(KeyCode::Esc)] => "cancel capture",
    }
}

keyactions! {
    pub enum DoctorTabAction ("doctor") {
        Up         [Chord::char('k'), Chord::key(KeyCode::Up)] => "prev",
        Down       [Chord::char('j'), Chord::key(KeyCode::Down)] => "next",
        Refresh    [Chord::char('r')] => "refresh",
        FilterNext [Chord::char('+'), Chord::char('=')] => "next filter",
        FilterPrev [Chord::char('-')] => "prev filter",
        PageUp     [Chord::key(KeyCode::PageUp)] => "page up",
        PageDown   [Chord::key(KeyCode::PageDown)] => "page down",
        JumpStart  [Chord::char('g'), Chord::key(KeyCode::Home)] => "jump to start",
        JumpEnd    [Chord::char('G'), Chord::key(KeyCode::End)] => "jump to end",
    }
}

keyactions! {
    pub enum QuickstartTabAction ("quickstart") {
        Up     [Chord::char('k'), Chord::key(KeyCode::Up)] => "prev",
        Down   [Chord::char('j'), Chord::key(KeyCode::Down)] => "next",
        Enter  [Chord::key(KeyCode::Enter)] => "open",
        Back   [Chord::char('q'), Chord::key(KeyCode::Esc)] => "leave",
        Create [Chord::char('c'), Chord::char('C')] => "create agent",
    }
}

keyactions! {
    pub enum SopTabAction ("sop") {
        Up     [Chord::char('k'), Chord::key(KeyCode::Up)] => "prev",
        Down   [Chord::char('j'), Chord::key(KeyCode::Down)] => "next",
        Enter  [Chord::key(KeyCode::Enter)] => "load graph",
        Run    [Chord::char('r'), Chord::char('R')] => "run manual",
        Watch  [Chord::char('w'), Chord::char('W')] => "watch run",
        New    [Chord::char('n')] => "new sop",
        Edit   [Chord::char('e')] => "edit sop",
        Delete [Chord::char('d')] => "delete sop",
        Approve [Chord::char('a'), Chord::char('A')] => "approve checkpoint",
        Deny    [Chord::char('x'), Chord::char('X')] => "deny checkpoint",
        Toggle [Chord::char('v')] => "toggle layer",
        PanLeft  [Chord::shift(KeyCode::Left)] => "pan left",
        PanRight [Chord::shift(KeyCode::Right)] => "pan right",
        PanUp    [Chord::shift(KeyCode::Up)] => "pan up",
        PanDown  [Chord::shift(KeyCode::Down)] => "pan down",
    }
}

keyactions! {
    pub enum SopEditorAction ("sop_editor") {
        SourcePrev  [Chord::with(KeyCode::Left, KeyModifiers::ALT)]  => "prev trigger source",
        SourceNext  [Chord::with(KeyCode::Right, KeyModifiers::ALT)] => "next trigger source",
        ChannelNext [Chord::with(KeyCode::Char('c'), KeyModifiers::ALT)] => "cycle channel",
        AliasNext   [Chord::with(KeyCode::Char('a'), KeyModifiers::ALT)] => "cycle alias",
        Add         [Chord::with(KeyCode::Char('n'), KeyModifiers::ALT)] => "add trigger",
        Remove      [Chord::with(KeyCode::Char('x'), KeyModifiers::ALT)] => "remove trigger",
    }
}

keyactions! {
    pub enum InputBarAction ("input_bar") {
        Submit             [Chord::key(KeyCode::Enter)] => "send",
        Inject             [Chord::with_primary(KeyCode::Enter, KeyModifiers::NONE), Chord::with(KeyCode::Enter, KeyModifiers::CONTROL)] => "send now",
        NewLine            [Chord::shift(KeyCode::Enter)] => "new line",
        CursorLeft         [Chord::key(KeyCode::Left)] => "cursor left",
        CursorRight        [Chord::key(KeyCode::Right)] => "cursor right",
        CursorWordLeft     [Chord::with(KeyCode::Left, KeyModifiers::ALT), Chord::with(KeyCode::Char('b'), KeyModifiers::ALT)] => "word left",
        CursorWordRight    [Chord::with(KeyCode::Right, KeyModifiers::ALT), Chord::with(KeyCode::Char('f'), KeyModifiers::ALT)] => "word right",
        CursorStart        [Chord::key(KeyCode::Home)] => "line start",
        CursorEnd          [Chord::key(KeyCode::End), Chord::primary('e'), Chord::ctrl('e')] => "line end",
        OpenFileBrowser    [] => "browse files",
        Backspace          [Chord::key(KeyCode::Backspace)] => "backspace",
        DeletePreviousWord [Chord::primary('w'), Chord::ctrl('w'), Chord::with(KeyCode::Backspace, KeyModifiers::ALT)] => "delete previous word",
        DeleteForward      [Chord::key(KeyCode::Delete)] => "delete next character",
        DeleteNextWord     [Chord::with(KeyCode::Delete, KeyModifiers::ALT)] => "delete next word",
        ClearInput         [Chord::primary('u'), Chord::ctrl('u')] => "clear input",
        SelectAll          [Chord::primary('a'), Chord::ctrl('a')] => "select all",
        Undo               [Chord::primary('z'), Chord::ctrl('z')] => "undo",
        Redo               [
            Chord::with_primary(KeyCode::Char('Z'), KeyModifiers::SHIFT),
            Chord::with(KeyCode::Char('Z'), KeyModifiers::CONTROL.union(KeyModifiers::SHIFT)),
            Chord::with_primary(KeyCode::Char('z'), KeyModifiers::SHIFT),
            Chord::with(KeyCode::Char('z'), KeyModifiers::CONTROL.union(KeyModifiers::SHIFT)),
        ] => "redo",
        Cut                [Chord::primary('x'), Chord::ctrl('x')] => "cut selection",
        CopySelection      [Chord::primary('c'), Chord::ctrl('c')] => "copy selection",
        SelectLeft         [Chord::shift(KeyCode::Left)] => "select left",
        SelectRight        [Chord::shift(KeyCode::Right)] => "select right",
        SelectUp           [Chord::shift(KeyCode::Up)] => "select up",
        SelectDown         [Chord::shift(KeyCode::Down)] => "select down",
        SelectStart        [Chord::shift(KeyCode::Home)] => "select to line start",
        SelectEnd          [Chord::shift(KeyCode::End)] => "select to line end",
        SelectWordLeft     [Chord::with(KeyCode::Left, KeyModifiers::ALT.union(KeyModifiers::SHIFT))] => "select previous word",
        SelectWordRight    [Chord::with(KeyCode::Right, KeyModifiers::ALT.union(KeyModifiers::SHIFT))] => "select next word",
        Paste              [Chord::primary('v'), Chord::ctrl('v')] => "paste",
        HistoryPrev        [Chord::key(KeyCode::Up)] => "history prev",
        HistoryNext        [Chord::key(KeyCode::Down)] => "history next",
        AutocompleteNext   [] => "autocomplete next",
        AutocompletePrev   [] => "autocomplete prev",
        AutocompleteAccept [Chord::key(KeyCode::Tab)] => "accept completion",
        AutocompleteCancel [Chord::key(KeyCode::Esc)] => "cancel completion",
        AttachClipboard    [] => "attach clipboard",
    }
}

keyactions! {
    pub enum ModalAction ("modal") {
        Confirm [Chord::key(KeyCode::Enter), Chord::char('y'), Chord::char('Y')] => "confirm",
        Cancel  [Chord::key(KeyCode::Esc), Chord::char('n'), Chord::char('N')] => "cancel",
        Up      [Chord::key(KeyCode::Up)] => "prev",
        Down    [Chord::key(KeyCode::Down)] => "next",
        Toggle  [Chord::char(' ')] => "toggle selection",
    }
}

keyactions! {
    pub enum FileExplorerAction ("file_explorer") {
        Up           [Chord::char('k'), Chord::key(KeyCode::Up)] => "prev",
        Down         [Chord::char('j'), Chord::key(KeyCode::Down)] => "next",
        PageUp       [Chord::key(KeyCode::PageUp)] => "page up",
        PageDown     [Chord::key(KeyCode::PageDown)] => "page down",
        JumpStart    [Chord::char('g'), Chord::key(KeyCode::Home)] => "jump to start",
        JumpEnd      [Chord::char('G'), Chord::key(KeyCode::End)] => "jump to end",
        EnterDir     [Chord::char('l'), Chord::key(KeyCode::Right)] => "enter dir",
        LeaveDir     [Chord::char('h'), Chord::key(KeyCode::Left), Chord::key(KeyCode::Backspace)] => "up dir",
        ToggleSelect [Chord::char(' ')] => "toggle select",
        Activate     [Chord::key(KeyCode::Enter)] => "open / attach",
        ToggleHidden [Chord::char('.')] => "toggle hidden",
        BeginSearch  [Chord::char('/')] => "search",
        ConfirmDir   [Chord::char('c')] => "confirm dir",
        Cancel       [Chord::char('q'), Chord::key(KeyCode::Esc)] => "cancel",
    }
}

keyactions! {
    pub enum FileExplorerSearchAction ("file_explorer_search") {
        Accept    [Chord::key(KeyCode::Enter)] => "accept",
        Cancel    [Chord::key(KeyCode::Esc)] => "cancel",
        Backspace [Chord::key(KeyCode::Backspace)] => "backspace",
        Up        [Chord::key(KeyCode::Up)] => "prev",
        Down      [Chord::key(KeyCode::Down)] => "next",
        PageUp    [Chord::key(KeyCode::PageUp)] => "page up",
        PageDown  [Chord::key(KeyCode::PageDown)] => "page down",
    }
}

keyactions! {
    pub enum SearchBoxAction ("search_box") {
        Accept    [Chord::key(KeyCode::Enter)] => "accept",
        Cancel    [Chord::key(KeyCode::Esc)] => "cancel",
        Backspace [Chord::key(KeyCode::Backspace)] => "backspace",
        Up        [Chord::key(KeyCode::Up)] => "prev",
        Down      [Chord::key(KeyCode::Down)] => "next",
    }
}

keyactions! {
    pub enum ConfigEditorAction ("config_editor") {
        Confirm   [Chord::key(KeyCode::Enter)] => "confirm",
        Cancel    [Chord::key(KeyCode::Esc)] => "cancel",
        Save      [Chord::ctrl('s')] => "save",
        Backspace [Chord::key(KeyCode::Backspace)] => "backspace",
        CursorLeft      [Chord::key(KeyCode::Left)] => "cursor left",
        CursorRight     [Chord::key(KeyCode::Right)] => "cursor right",
        CursorWordLeft  [Chord::with(KeyCode::Left, KeyModifiers::ALT), Chord::with(KeyCode::Char('b'), KeyModifiers::ALT)] => "word left",
        CursorWordRight [Chord::with(KeyCode::Right, KeyModifiers::ALT), Chord::with(KeyCode::Char('f'), KeyModifiers::ALT)] => "word right",
        CursorStart     [Chord::key(KeyCode::Home)] => "input start",
        CursorEnd       [Chord::key(KeyCode::End)] => "input end",
        Up        [Chord::key(KeyCode::Up)] => "prev",
        Down      [Chord::key(KeyCode::Down)] => "next",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crossterm::event::KeyEvent;

    fn assert_distinct_defaults<A: crate::keymap::RebindableActions>() {
        for action in A::all() {
            let defaults = action.defaults();
            for (index, chord) in defaults.iter().enumerate() {
                assert!(
                    defaults[..index]
                        .iter()
                        .all(|existing| !existing.same_key(chord)),
                    "{} advertises the effective chord {} more than once",
                    action.key(),
                    chord.wire()
                );
            }
        }
    }

    #[test]
    fn default_tables_do_not_duplicate_effective_chords() {
        assert_distinct_defaults::<GlobalAction>();
        assert_distinct_defaults::<ChatTabAction>();
        assert_distinct_defaults::<InputBarAction>();
    }

    #[cfg(target_os = "macos")]
    fn assert_macos_primary_and_control<A: std::fmt::Debug + Eq + Copy>(
        code: KeyCode,
        extra: KeyModifiers,
        resolve: impl Fn(&KeyEvent) -> Option<A>,
        expected: A,
    ) {
        assert_eq!(
            resolve(&KeyEvent::new(code, KeyModifiers::SUPER.union(extra))),
            Some(expected),
            "platform-primary event must remain accepted"
        );
        assert_eq!(
            resolve(&KeyEvent::new(code, KeyModifiers::CONTROL.union(extra))),
            Some(expected),
            "literal-Control compatibility event must be restored"
        );
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn primary_defaults_retain_their_pre_10479_control_events_on_macos() {
        let _guard = crate::keymap::overrides::TEST_GUARD
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        crate::keymap::overrides::reset();

        assert_macos_primary_and_control(
            KeyCode::Char('r'),
            KeyModifiers::NONE,
            GlobalAction::from_chord,
            GlobalAction::ReloadDaemon,
        );
        assert_macos_primary_and_control(
            KeyCode::Up,
            KeyModifiers::SHIFT,
            ChatTabAction::from_chord,
            ChatTabAction::FastScrollUp,
        );
        assert_macos_primary_and_control(
            KeyCode::Down,
            KeyModifiers::SHIFT,
            ChatTabAction::from_chord,
            ChatTabAction::FastScrollDown,
        );
        assert_macos_primary_and_control(
            KeyCode::Char('p'),
            KeyModifiers::NONE,
            ChatTabAction::from_chord,
            ChatTabAction::TodoToggle,
        );
        assert_macos_primary_and_control(
            KeyCode::Char('d'),
            KeyModifiers::NONE,
            ChatTabAction::from_chord,
            ChatTabAction::CancelTurn,
        );

        for (code, expected) in [
            (KeyCode::Enter, InputBarAction::Inject),
            (KeyCode::Char('e'), InputBarAction::CursorEnd),
            (KeyCode::Char('a'), InputBarAction::SelectAll),
            (KeyCode::Char('w'), InputBarAction::DeletePreviousWord),
            (KeyCode::Char('u'), InputBarAction::ClearInput),
            (KeyCode::Char('v'), InputBarAction::Paste),
        ] {
            assert_macos_primary_and_control(
                code,
                KeyModifiers::NONE,
                InputBarAction::from_chord,
                expected,
            );
        }
    }

    #[test]
    fn session_shortcut_primary_digits_resolve_to_ordinals() {
        let actions = [
            GlobalAction::FocusSession1,
            GlobalAction::FocusSession2,
            GlobalAction::FocusSession3,
            GlobalAction::FocusSession4,
            GlobalAction::FocusSession5,
            GlobalAction::FocusSession6,
            GlobalAction::FocusSession7,
            GlobalAction::FocusSession8,
        ];
        for (index, action) in actions.into_iter().enumerate() {
            let digit = char::from_digit((index + 1) as u32, 10).unwrap();
            let modifiers = if cfg!(target_os = "macos") {
                KeyModifiers::CONTROL.union(KeyModifiers::SUPER)
            } else {
                KeyModifiers::CONTROL
            };
            assert_eq!(
                GlobalAction::from_chord(&KeyEvent::new(KeyCode::Char(digit), modifiers)),
                Some(action)
            );
            #[cfg(target_os = "macos")]
            assert_eq!(
                GlobalAction::from_chord(
                    &KeyEvent::new(KeyCode::Char(digit), KeyModifiers::SUPER,)
                ),
                None,
                "bare Command+{digit} remains available to the terminal host"
            );
        }
    }

    #[test]
    fn copy_selection_resolves_from_super_c_and_terminal_fallback() {
        let command_c = KeyEvent::new(KeyCode::Char('c'), KeyModifiers::SUPER);
        assert_eq!(
            ChatTabAction::from_chord(&command_c),
            Some(ChatTabAction::CopySelection)
        );

        let terminal_copy = KeyEvent::new(
            KeyCode::Char('C'),
            KeyModifiers::CONTROL.union(KeyModifiers::SHIFT),
        );
        assert_eq!(
            ChatTabAction::from_chord(&terminal_copy),
            Some(ChatTabAction::CopyAllVisible)
        );
        assert_eq!(
            LogsTabAction::from_chord(&command_c),
            Some(LogsTabAction::CopySelection)
        );
        assert_eq!(
            LogsTabAction::from_chord(&terminal_copy),
            Some(LogsTabAction::CopySelection)
        );
    }

    #[test]
    fn long_transcript_navigation_chords_preserve_plain_input_home_and_end() {
        let home = KeyEvent::new(KeyCode::Home, KeyModifiers::NONE);
        let end = KeyEvent::new(KeyCode::End, KeyModifiers::NONE);
        let ctrl_home = KeyEvent::new(KeyCode::Home, KeyModifiers::CONTROL);
        let ctrl_end = KeyEvent::new(KeyCode::End, KeyModifiers::CONTROL);

        assert_eq!(
            InputBarAction::from_chord(&home),
            Some(InputBarAction::CursorStart)
        );
        assert_eq!(
            InputBarAction::from_chord(&end),
            Some(InputBarAction::CursorEnd)
        );
        assert_eq!(InputBarAction::from_chord(&ctrl_home), None);
        assert_eq!(InputBarAction::from_chord(&ctrl_end), None);
        assert_eq!(
            ChatTabAction::from_chord(&ctrl_home),
            Some(ChatTabAction::JumpStart)
        );
        assert_eq!(
            ChatTabAction::from_chord(&ctrl_end),
            Some(ChatTabAction::JumpEnd)
        );
    }
}

keyactions! {
    pub enum QuickstartModalAction ("quickstart_modal") {
        Confirm        [Chord::key(KeyCode::Enter)] => "confirm",
        Cancel         [Chord::key(KeyCode::Esc)] => "cancel",
        Up             [Chord::key(KeyCode::Up)] => "prev",
        Down           [Chord::key(KeyCode::Down)] => "next",
        Left           [Chord::key(KeyCode::Left)] => "left",
        Right          [Chord::key(KeyCode::Right)] => "right",
        NextField      [Chord::key(KeyCode::Tab)] => "next field",
        PrevField      [Chord::key(KeyCode::BackTab)] => "prev field",
        Backspace      [Chord::key(KeyCode::Backspace)] => "backspace",
        DeleteRow      [Chord::char('d'), Chord::char('D')] => "delete row",
        Save           [Chord::ctrl('s')] => "save",
        EditWithEditor [Chord::char('e'), Chord::char('E')] => "edit file",
        EditTemplate   [Chord::char('t'), Chord::char('T')] => "from template",
        ClearFile      [Chord::char('c'), Chord::char('C')] => "clear file",
        Create         [] => "create",
    }
}
