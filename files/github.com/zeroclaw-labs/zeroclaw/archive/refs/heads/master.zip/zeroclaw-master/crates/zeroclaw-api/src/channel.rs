use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::{fmt, str::FromStr};
use tokio_util::sync::CancellationToken;

use crate::media::MediaAttachment;

/// Reserved `ChannelMessage.subject` prefix the git/forge channel uses to
/// label SOP-ingress events. Routing is NOT keyed on this (see
/// `ChannelMessage::internal_sop_event`); it exists so channels that fill
/// `subject` from user-controlled data (email) can keep this reserved
/// namespace out of inbound subjects.
pub const CHANNEL_SOP_SUBJECT_PREFIX: &str = "zeroclaw:sop-event:";

/// The single authority for the channel-SOP event topic grammar
/// `channel.alias:event_type`. The producer that lifts a forge/platform event
/// into SOP ingress builds the topic here; the SOP engine parses it here. The
/// grammar lives in one place so the two sides cannot drift.
///
/// `alias` separates from `channel` with `.`; `event_type` separates from the
/// `channel.alias` head with `:`. A bare `channel` (no alias, no event type)
/// and the `channel/alias` message form are both accepted by `parse` so the
/// same matcher serves agent-loop message triggers and forge event triggers.
pub struct ChannelSopTopic;

impl ChannelSopTopic {
    const ALIAS_SEP: char = '.';
    const EVENT_SEP: char = ':';
    const MESSAGE_ALIAS_SEP: char = '/';

    /// Build a forge/platform event topic `channel.alias:event_type`.
    #[must_use]
    pub fn build(channel: &str, alias: &str, event_type: &str) -> String {
        format!(
            "{channel}{}{alias}{}{event_type}",
            Self::ALIAS_SEP,
            Self::EVENT_SEP
        )
    }

    /// Parse a channel-SOP topic into `(channel, alias, event_type)`. The head
    /// before the event separator yields the channel kind and optional alias;
    /// the tail after it is the optional event type. Accepts both the forge
    /// form (`channel.alias:event_type`) and the message form (`channel` or
    /// `channel/alias`).
    #[must_use]
    pub fn parse(topic: &str) -> (&str, Option<&str>, Option<&str>) {
        let (head, event_type) = match topic.split_once(Self::EVENT_SEP) {
            Some((before, after)) => (before, Some(after)),
            None => (topic, None),
        };
        let (channel, alias) = head
            .split_once(Self::ALIAS_SEP)
            .or_else(|| head.split_once(Self::MESSAGE_ALIAS_SEP))
            .map_or((head, None), |(c, a)| (c, Some(a)));
        (channel, alias, event_type)
    }
}

// ── Channel-supplied room context ───────────────────────────────

/// Context a chat channel supplies about one specific room.
///
/// Rooms in the same channel can serve different purposes — one for package
/// maintenance, another for incident response — and the operator already
/// describes that in the chat product's own metadata (Mattermost's channel
/// purpose, Slack's topic, Matrix's room topic). This carries that description
/// to prompt assembly so a room can specialise the agent without a separate
/// config entry per room.
///
/// **Channel-supplied, not operator-supplied.** The text originates from
/// whoever can edit the room's metadata, which on default permission schemes is
/// usually every member — a wider set than whoever controls the agent's config.
/// It is therefore rendered as context about the room, explicitly labelled as
/// such, and never as operating rules. Adapters must return `None` unless the
/// operator opted the alias in.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ChannelRoomContext {
    /// Free-text description of what this room is for.
    pub purpose: Option<String>,
}

impl ChannelRoomContext {
    /// True when there is nothing to inject, so callers can skip the section
    /// rather than render an empty one.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.purpose.as_ref().is_none_or(|p| p.trim().is_empty())
    }
}

// ── Channel approval types ──────────────────────────────────────

/// Where a tool call sits in the batch the model issued for one turn.
///
/// This is the raw batch position, not an approval count. `index` counts every
/// call the model asked for, including calls that never reach an approval
/// prompt. An `Approval 2 of 2` counter would only be truthful once the
/// approval-required set is known, which is after hooks and policy have run —
/// later than the first card is rendered.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct ApprovalPosition {
    /// 1-based position of this call within the batch.
    pub index: u32,
    /// Number of calls in the batch.
    pub total: u32,
}

/// Compact description of a tool call presented to the user for approval.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChannelApprovalRequest {
    pub tool_name: String,
    pub arguments_summary: String,
    /// Raw tool arguments for channels (e.g. ACP) that can render structured
    /// diffs instead of a plain summary string.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub raw_arguments: Option<serde_json::Value>,
    /// Position of this call in the model's tool-call batch, when the caller
    /// knows it. `None` on paths that approve a single call with no batch to
    /// count.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub position: Option<ApprovalPosition>,
}

impl ChannelApprovalRequest {
    /// Batch position for an approval card, as `(index, total)`.
    ///
    /// Reports the position verbatim. Whether a counter is worth showing is
    /// the renderer's decision, so that a caller handing the renderer a tuple
    /// directly cannot bypass the rule.
    #[must_use]
    pub fn position_counter(&self) -> Option<(u32, u32)> {
        self.position.map(|p| (p.index, p.total))
    }
}

/// The operator's response to a channel-presented approval prompt.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ChannelApprovalResponse {
    /// Execute this one call.
    Approve,
    /// Deny this call.
    Deny,
    /// Execute and add tool to session-scoped allowlist.
    #[serde(rename = "always")]
    AlwaysApprove,
    /// Deny this call and supply an edited replacement for the arguments.
    #[serde(rename = "deny_with_edit")]
    DenyWithEdit { replacement: String },
}

/// An approval response together with the back-channel that produced it.
///
/// When a channel fans one approval request out to several back-channels,
/// `decided_by` names the back-channel that actually answered, so the audit
/// trail attributes the decision to the deciding surface. The attribution
/// travels with the returned decision, so concurrent approvals on the same
/// channel instance cannot cross-wire it. Single channels leave it `None`.
///
/// `#[non_exhaustive]` so a future provenance field is an additive change
/// rather than another source break. Out-of-tree code must construct this
/// value through the dedicated constructors on this type — `#[non_exhaustive]`
/// forbids struct-literal construction from another crate, so the
/// `..Default::default()` wildcard is not a workaround. The constructors
/// (`operator`, `from_runtime`, `with_decider`, `with_decider_opt`) below are
/// the public contract.
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub struct AttributedApprovalResponse {
    pub response: ChannelApprovalResponse,
    pub decided_by: Option<String>,
    /// WHO produced this response — an operator, or the runtime failing closed.
    ///
    /// This cannot be inferred from the other two fields, which is why it is
    /// carried explicitly:
    ///
    /// * `Option::is_none()` on the whole response does not work, because a
    ///   fail-closed route returns `Some(Deny)` with no decider.
    /// * `decided_by.is_none()` does not work either, because a single
    ///   (non-fan-out) channel leaves it `None` for a genuine operator answer.
    ///
    /// Conflating the two produced a tool result that told the model
    /// "Denied by user." on runs where no human was ever asked.
    pub source: ApprovalSource,
}

/// Who decided an approval outcome.
///
/// Everything other than [`ApprovalSource::Operator`] is the runtime denying on
/// its own authority. Callers reporting a denial to a model must distinguish
/// them: an operator's "no" is a decision, while the rest are the absence of
/// one, and telling a model a human refused when none was asked sends it
/// looking for a decision that never happened.
/// `#[non_exhaustive]` so a later provenance category is an additive change:
/// out-of-tree matches must already carry a wildcard arm, and `Operator` is the
/// [`Default`] so an out-of-tree constructor that does not care about
/// provenance keeps the pre-existing "a person answered" meaning.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
#[non_exhaustive]
pub enum ApprovalSource {
    /// A human answered through a channel.
    #[default]
    Operator,
    /// No approval-capable channel was available: none connected, or the
    /// channel does not implement approval prompts.
    Unavailable,
    /// An approver was configured but could not be reached, errored, or
    /// returned no decision.
    Unreachable,
    /// An approver was reachable but did not answer within the route's budget.
    TimedOut,
}

impl ApprovalSource {
    /// True when the runtime produced this outcome itself, so no operator
    /// decision exists to report.
    pub fn is_runtime_fail_closed(self) -> bool {
        !matches!(self, ApprovalSource::Operator)
    }
}

impl AttributedApprovalResponse {
    /// An operator answered through a channel.
    ///
    /// Use this at the boundary that actually observed a person's answer. A
    /// synthesized deny (drop, timeout, unreachable approver) must use
    /// [`AttributedApprovalResponse::from_runtime`] instead — that distinction
    /// is the whole point of carrying [`ApprovalSource`].
    pub fn operator(response: ChannelApprovalResponse) -> Self {
        Self {
            response,
            decided_by: None,
            source: ApprovalSource::Operator,
        }
    }

    /// The runtime produced this outcome itself; no operator decided.
    pub fn from_runtime(response: ChannelApprovalResponse, source: ApprovalSource) -> Self {
        Self {
            response,
            decided_by: None,
            source,
        }
    }

    /// Name the back-channel that produced this decision (fan-out attribution).
    ///
    /// Deliberately not called `decided_by`: that is the field's name, and a
    /// same-named method reads as a getter at the call site.
    #[must_use]
    pub fn with_decider(mut self, decider: impl Into<String>) -> Self {
        self.decided_by = Some(decider.into());
        self
    }

    /// Same as [`with_decider`](Self::with_decider) but accepts the fan-out
    /// shape where the decider is known to be an [`Option<String>`]. `Some`
    /// names the back-channel; `None` leaves `decided_by` unset. Callers that
    /// already carry `Option<String>` from a routed decision reach for this
    /// rather than a `match` that rebuilds the value.
    #[must_use]
    pub fn with_decider_opt(mut self, decider: Option<String>) -> Self {
        self.decided_by = decider;
        self
    }
}

/// A long-lived, channel-agnostic gate prompt (e.g. a parked SOP approval):
/// rendered natively per channel (Discord embed + buttons, Telegram inline
/// keyboard, ...), answered through the channel's normal inbound path — a
/// component click or a `<choice> <reference>` text reply — NOT a blocking wait.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChannelGatePrompt {
    /// Short heading, e.g. "SOP approval needed: gitea-triage-pipeline".
    pub title: String,
    /// Body: what is waiting and how to answer (includes the text-reply form
    /// for humans on channels that render it as plain text).
    pub description: String,
    /// Correlation key the answer must carry (e.g. the SOP run id). Encoded in
    /// component custom_ids and expected in text replies.
    pub reference: String,
    /// The presented choices, in order.
    pub choices: Vec<GateChoice>,
    /// Body a RESOLVED prompt should keep showing (the context, without the
    /// how-to-answer instructions): on finalize the channel appends the outcome
    /// line under it, so the record of WHAT was approved survives in place.
    /// `None` = the outcome replaces the body entirely.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub resolved_description: Option<String>,
}

/// The fixed vocabulary of gate-answer tokens, and the single source of truth
/// for their wire spelling. A gate answer crosses two stringly-typed transports
/// — a Discord `custom_id` and a `<choice> <reference>` text reply — so the
/// token must be a string on the wire; this enum keeps producer (the route
/// adapter that mints [`GateChoice::id`]) and consumer (the orchestrator that
/// maps an answer to an approval decision) matching on ONE definition instead of
/// re-typing the literal at each site, so adding a choice is a compile error at
/// every place that must handle it rather than a silent drift.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GateChoiceKind {
    /// Approve the gate as presented.
    Approve,
    /// Deny the gate (cancels / fails the run per the step's policy).
    Deny,
    /// Approve with an operator amendment to the declared editable field.
    Edit,
    /// Ask for a re-draft with guidance (checkpoint with an llm predecessor).
    Revise,
}

impl GateChoiceKind {
    /// The wire token — the string carried in a `custom_id` and a text reply.
    pub fn id(self) -> &'static str {
        match self {
            GateChoiceKind::Approve => "approve",
            GateChoiceKind::Deny => "deny",
            GateChoiceKind::Edit => "edit",
            GateChoiceKind::Revise => "revise",
        }
    }

    /// Parse a wire token back to its kind (case-insensitive). `None` for any
    /// unknown token, so an unrecognized answer is dropped, never coerced.
    pub fn from_id(token: &str) -> Option<Self> {
        match token.to_ascii_lowercase().as_str() {
            "approve" => Some(GateChoiceKind::Approve),
            "deny" => Some(GateChoiceKind::Deny),
            "edit" => Some(GateChoiceKind::Edit),
            "revise" => Some(GateChoiceKind::Revise),
            _ => None,
        }
    }

    /// True when answering this choice collects free text (the amended draft or
    /// the re-draft guidance) — the channels that can, render a form for it.
    pub fn collects_text(self) -> bool {
        matches!(self, GateChoiceKind::Edit | GateChoiceKind::Revise)
    }
}

/// One selectable choice on a [`ChannelGatePrompt`].
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GateChoice {
    /// Stable machine id carried back in the answer (e.g. "approve"). Mint it
    /// from [`GateChoiceKind::id`] so it stays in lockstep with the parser.
    pub id: String,
    /// Human label for the button / keyboard entry.
    pub label: String,
    /// Visual emphasis hint for channels that support it.
    pub emphasis: GateChoiceEmphasis,
    /// When set, this choice collects free text from the operator before it is
    /// answered (e.g. "Edit" amends a draft, "Revise" sends guidance). Channels
    /// with a native form (Discord modal) render one; channels without simply
    /// omit the choice — plain approve/deny stays universally answerable.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub input: Option<GateChoiceInput>,
}

/// The text-collection spec of an input-bearing [`GateChoice`].
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GateChoiceInput {
    /// Field label shown on the form (e.g. "Edited draft").
    pub label: String,
    /// Pre-filled text (e.g. the current draft an Edit starts from).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub prefill: Option<String>,
}

/// Rendering hint for a [`GateChoice`].
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum GateChoiceEmphasis {
    /// The affirmative action (e.g. a green/primary button).
    Positive,
    /// The destructive/refusing action (e.g. a red button).
    Negative,
    /// No particular emphasis.
    Neutral,
}

/// Conversation history scope for an inbound channel message.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ChannelConversationScope {
    /// Isolate history by channel, room/reply target, thread, and sender.
    #[default]
    Sender,
    /// Share history for everyone in the room/reply target.
    ReplyTarget,
}

/// A message received from or sent to a channel
#[derive(Debug, Clone, Default)]
pub struct ChannelMessage {
    pub id: String,
    pub sender: String,
    /// Immutable sender identifier assigned by the channel platform, when
    /// available. Display names and usernames remain in `sender` so existing
    /// session semantics are unchanged.
    pub platform_sender_id: Option<String>,
    pub reply_target: String,
    pub content: String,
    pub channel: String,
    /// ZeroClaw channel alias (the `<alias>` half of `[channels.<type>.<alias>]`)
    /// when the platform supports multiple bot instances. Session-key
    /// construction uses this so two bots on the same platform compute
    /// distinct session IDs and don't share conversation history. `None`
    /// for channels without an alias concept (cli).
    pub channel_alias: Option<String>,
    pub timestamp: u64,
    /// Platform thread identifier (e.g. Slack `ts`, Discord thread ID).
    /// When set, replies should be posted as threaded responses.
    pub thread_ts: Option<String>,
    /// Thread scope identifier for interruption/cancellation grouping.
    /// Distinct from `thread_ts` (reply anchor): this is `Some` only when the message
    /// is genuinely inside a reply thread and should be isolated from other threads.
    /// `None` means top-level — scope is sender+channel only.
    pub interruption_scope_id: Option<String>,
    /// Media attachments (audio, images, video) for the media pipeline.
    /// Channels populate this when they receive media alongside a text message.
    /// Defaults to empty — existing channels are unaffected.
    pub attachments: Vec<MediaAttachment>,
    /// Email subject for reply threading.
    pub subject: Option<String>,
    /// Internal SOP-ingress marker carrying the event topic, set ONLY by the
    /// git/forge channel producer. The orchestrator routes a message into the
    /// SOP engine when (and only when) this is `Some`, so the decision can
    /// never be driven by user-controlled fields like `subject` or `content`.
    /// Never round-trips through serde.
    pub internal_sop_event: Option<String>,
    /// When true, the orchestrator records this as context only and must not
    /// start an agent turn or emit visible channel side effects.
    pub passive_context: bool,
    /// Channel adapter observed that this inbound message explicitly addressed
    /// the bot through a platform-level signal such as an @mention.
    pub explicitly_addressed: bool,
    /// Controls whether conversation history is sender-scoped or room-scoped.
    pub conversation_scope: ChannelConversationScope,
    /// Inbound email References chain (parent thread); used to build the
    /// reply's References header. Empty for non-email channels.
    pub references: Vec<String>,
    /// Set by the receiving channel when the platform marked the inbound event
    /// itself as a voice message (Matrix: an `m.audio` event carrying
    /// `org.matrix.msc3245.voice`). This field creates that fact for the
    /// runtime — nothing else on the inbound side records it. Never derived
    /// from message text, a reply parent, or room state. `false` means text
    /// or unknown.
    pub voice_origin: bool,
}

/// Message to send through a channel
#[derive(Debug, Clone)]
pub struct SendMessage {
    pub content: String,
    pub recipient: String,
    pub subject: Option<String>,
    /// Platform thread identifier for threaded replies (e.g. Slack `thread_ts`).
    pub thread_ts: Option<String>,
    /// Optional cancellation token for interruptible delivery (e.g. multi-message mode).
    pub cancellation_token: Option<CancellationToken>,
    /// File attachments to send with the message.
    /// Channels that don't support attachments ignore this field.
    pub attachments: Vec<MediaAttachment>,
    /// Message-ID to set as In-Reply-To header (email threading).
    pub in_reply_to: Option<String>,
    /// RFC 5322 References chain for email replies; ignored by non-email channels.
    pub references: Vec<String>,
    /// When `true`, channels that support TTS must not synthesise this
    /// message as a voice note. Use for error notices, system alerts, and
    /// other non-conversational content that should never be voiced.
    pub suppress_voice: bool,
    /// When `true`, channels that support TTS must deliver this message as
    /// a voice note even if the peer's default modality is text.
    /// Ignored when `suppress_voice` is also `true`.
    pub force_voice: bool,
}

/// What happens when someone votes on a poll this channel posted.
///
/// A poll that gathers opinions and one that opens a sale need opposite
/// behaviour in the same chat, so this travels per poll rather than as a
/// channel setting.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PollVoteReply {
    /// Votes are recorded as ordinary context and start no turn. The default,
    /// because a poll in a busy group would otherwise have the agent
    /// answering every voter.
    #[default]
    Ignore,
    /// Each vote starts a turn in the chat the poll was posted in.
    InChat,
    /// Each vote starts a turn addressed to the voter privately, leaving the
    /// rest of the chat out of whatever follows.
    Direct,
}

/// A native poll to post in a chat.
///
/// Channels that cannot post one report [`Channel::supports_native_polls`] as
/// `false`, and callers fall back to whatever they did before.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PollRequest {
    /// Chat or peer to post the poll in, in the channel's own addressing.
    pub recipient: String,
    pub question: String,
    /// Answer options, in the order they should be shown.
    pub options: Vec<String>,
    /// How many options one voter may pick. `1` is a single-choice poll.
    pub selectable_count: u32,
    /// What a vote on this poll should do. See [`PollVoteReply`].
    pub vote_reply: PollVoteReply,
}

impl PollRequest {
    /// Single-choice poll. Use [`PollRequest::with_selectable_count`] for a
    /// poll that accepts more than one answer per voter.
    pub fn new(
        recipient: impl Into<String>,
        question: impl Into<String>,
        options: Vec<String>,
    ) -> Self {
        Self {
            recipient: recipient.into(),
            question: question.into(),
            options,
            selectable_count: 1,
            vote_reply: PollVoteReply::Ignore,
        }
    }

    #[must_use]
    pub fn with_vote_reply(mut self, vote_reply: PollVoteReply) -> Self {
        self.vote_reply = vote_reply;
        self
    }

    #[must_use]
    pub fn with_selectable_count(mut self, selectable_count: u32) -> Self {
        self.selectable_count = selectable_count;
        self
    }
}

/// Cross-channel room visibility used by room-management APIs.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RoomVisibility {
    Private,
    Public,
}

/// Stable, non-sensitive lifecycle states that channels may render while an
/// agent turn is running. Variants carry no display text or internal details.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProgressEvent {
    Received,
    Planning,
    WaitingOnModel,
    RunningTool,
    CompactingContext,
    FinalizingResponse,
}

/// Origin of a rendered draft-progress entry.
///
/// Channels may display both variants identically, but must retain this value
/// while coalescing updates so provider reasoning cannot be mistaken for
/// generated status chrome when their rendered text happens to match.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DraftProgressKind {
    /// Generated lifecycle or tool-status chrome.
    Status,
    /// Raw provider reasoning explicitly enabled for the channel.
    Reasoning,
}

/// Rendered draft-progress text paired with its semantic origin.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DraftProgress {
    /// Semantic source retained independently from the display string.
    pub kind: DraftProgressKind,
    /// Channel-ready display text after redaction.
    pub text: String,
}

impl DraftProgress {
    /// Create a generated status or tool-progress entry.
    pub fn status(text: impl Into<String>) -> Self {
        Self {
            kind: DraftProgressKind::Status,
            text: text.into(),
        }
    }

    /// Create a provider-reasoning entry.
    pub fn reasoning(text: impl Into<String>) -> Self {
        Self {
            kind: DraftProgressKind::Reasoning,
            text: text.into(),
        }
    }
}

impl RoomVisibility {
    pub const SCHEMA_VALUES: &'static [&'static str] = &["private", "public"];

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Private => "private",
            Self::Public => "public",
        }
    }
}

impl fmt::Display for RoomVisibility {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

impl FromStr for RoomVisibility {
    type Err = anyhow::Error;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value.trim().to_ascii_lowercase().as_str() {
            "private" => Ok(Self::Private),
            "public" => Ok(Self::Public),
            other => {
                anyhow::bail!("unsupported room visibility '{other}': expected private or public")
            }
        }
    }
}

/// Room creation options shared by channel implementations that support
/// creating group conversations.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct RoomCreationOptions {
    pub name: Option<String>,
    pub topic: Option<String>,
    pub invites: Vec<String>,
    pub visibility: Option<RoomVisibility>,
    pub encryption: Option<bool>,
}

impl SendMessage {
    /// Create a new message with content and recipient
    pub fn new(content: impl Into<String>, recipient: impl Into<String>) -> Self {
        Self {
            content: content.into(),
            recipient: recipient.into(),
            subject: None,
            thread_ts: None,
            cancellation_token: None,
            attachments: vec![],
            in_reply_to: None,
            references: Vec::new(),
            suppress_voice: false,
            force_voice: false,
        }
    }

    /// Prevent TTS channels from voicing this message.
    pub fn suppress_voice(mut self) -> Self {
        self.suppress_voice = true;
        self
    }

    /// Force TTS channels to deliver this message as a voice note.
    pub fn force_voice(mut self) -> Self {
        self.force_voice = true;
        self
    }

    /// Create a new message with content, recipient, and subject
    pub fn with_subject(
        content: impl Into<String>,
        recipient: impl Into<String>,
        subject: impl Into<String>,
    ) -> Self {
        Self {
            content: content.into(),
            recipient: recipient.into(),
            subject: Some(subject.into()),
            thread_ts: None,
            cancellation_token: None,
            attachments: vec![],
            in_reply_to: None,
            references: Vec::new(),
            suppress_voice: false,
            force_voice: false,
        }
    }

    /// Set the In-Reply-To header for email threading.
    pub fn in_reply_to(mut self, msg_id: Option<String>) -> Self {
        self.in_reply_to = msg_id;
        self
    }

    /// Set the subject on an existing SendMessage (builder style).
    pub fn subject(mut self, subject: impl Into<String>) -> Self {
        self.subject = Some(subject.into());
        self
    }

    /// Set the thread identifier for threaded replies.
    pub fn in_thread(mut self, thread_ts: Option<String>) -> Self {
        self.thread_ts = thread_ts;
        self
    }

    /// Attach a cancellation token for interruptible delivery.
    pub fn with_cancellation(mut self, token: CancellationToken) -> Self {
        self.cancellation_token = Some(token);
        self
    }

    /// Attach files to this message.
    pub fn with_attachments(mut self, attachments: Vec<MediaAttachment>) -> Self {
        self.attachments = attachments;
        self
    }
}

impl ChannelMessage {
    /// Construct a `ChannelMessage` with all required fields set and all optional
    /// fields zeroed. Prefer this over raw struct literals so that new optional
    /// fields added to `ChannelMessage` in the future don't require mechanical
    /// updates at every call site.
    pub fn new(
        id: impl Into<String>,
        sender: impl Into<String>,
        reply_target: impl Into<String>,
        content: impl Into<String>,
        channel: impl Into<String>,
        timestamp: u64,
    ) -> Self {
        Self {
            id: id.into(),
            sender: sender.into(),
            reply_target: reply_target.into(),
            content: content.into(),
            channel: channel.into(),
            timestamp,
            ..Self::default()
        }
    }
}

impl SendMessage {
    pub fn reply_to(msg: &ChannelMessage, content: impl Into<String>) -> Self {
        let mut references = msg.references.clone();
        references.push(msg.id.clone());
        let mut sm = Self::new(content, &msg.reply_target)
            .in_thread(msg.thread_ts.clone())
            .in_reply_to(Some(msg.id.clone()));
        sm.references = references;
        if let Some(ref subj) = msg.subject {
            let reply_subject = if subj.to_ascii_lowercase().starts_with("re:") {
                subj.clone()
            } else {
                format!("Re: {}", subj)
            };
            sm = sm.subject(reply_subject);
        }
        sm
    }
}

/// A low-level, provider-relative forge API request routed through a
/// forge-backed channel. Channel-neutral so the `Channel` trait carries no
/// forge-specific types; the git channel maps this onto its provider's
/// `forge_request`. `method` is an uppercase HTTP verb (`GET`/`POST`/`PATCH`/
/// `PUT`/`DELETE`); `path` is relative to the provider's API base (e.g.
/// `repos/owner/repo/issues/12/labels`); `body` is an optional JSON payload.
#[derive(Debug, Clone)]
pub struct ForgeApiRequest {
    pub method: String,
    pub path: String,
    pub body: Option<serde_json::Value>,
}

/// The outcome of a forge API request: the HTTP status and decoded JSON body
/// (`Null` when the response had no body). Non-2xx statuses are carried here
/// rather than raised, so the caller inspects the forge's own error envelope.
#[derive(Debug, Clone)]
pub struct ForgeApiResponse {
    pub status: u16,
    pub body: serde_json::Value,
}

/// Runtime-owned state needed by a channel to present its native model picker.
///
/// The picker is presentation only: a selected option must re-enter the
/// channel runtime through the existing `/model <ref>` command path so model
/// resolution and session scoping keep a single owner.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChannelModelPickerRequest {
    /// Human-readable display name of the user who sent `/model`, for
    /// rendering only. Never use this for authorization; that is
    /// `requesting_user_id`'s role.
    pub requesting_user: String,
    /// Immutable platform identity of the requesting user, used to authorize
    /// picker interactions (only this user may drive the picker) and to bind
    /// the selection back to the sender. Channels may decline to present a
    /// picker (return `Ok(false)`) when this is empty.
    pub requesting_user_id: String,
    /// Reply scope inherited from the triggering message. The picker must be
    /// delivered to this target so it lands in the same chat the command was
    /// issued in.
    pub reply_target: String,
    /// Thread/topic scope inherited from the triggering message. When `Some`,
    /// the picker and any follow-up selection must stay in the same thread or
    /// topic; when `None`, the channel's default scope applies.
    pub thread_ts: Option<String>,
    /// Alias of the channel instance that received the command. A channel
    /// must decline requests whose alias is not its own (return `Ok(false)`).
    pub channel_alias: String,
    /// Alias of the agent that owns this runtime. Implementations that render
    /// agent-owned picker state must decline (return `Ok(false)`) on mismatch.
    pub owner_agent_alias: String,
    /// Provider ref of the currently selected route, shown as the picker's
    /// starting state.
    pub current_model_provider: String,
    /// Model of the currently selected route, shown as the picker's starting
    /// state.
    pub current_model: String,
    /// Restart-scoped route snapshot used by the channel runtime to resolve
    /// `/model <ref>`. This is an in-memory view of the routes loaded at
    /// startup, not durable configuration; native pickers must not offer
    /// routes outside this set.
    pub model_routes: Vec<ChannelModelPickerRoute>,
}

/// Provider/model route identity exposed to a channel-native model picker.
///
/// API keys stay runtime-owned and are deliberately excluded; route entries
/// carry only display and resolution identity, never credentials.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChannelModelPickerRoute {
    /// Short, user-facing alias accepted by `/model <ref>` (e.g. `fast`).
    pub hint: String,
    /// Provider ref this route resolves to.
    pub model_provider: String,
    /// Model identifier this route resolves to.
    pub model: String,
}

/// What a channel can say about its own listener without performing any I/O.
///
/// See [`Channel::listener_health`]. The three states exist because a listener
/// that has not connected yet and a listener that is working are different
/// claims, and a caller that stamps "healthy" for both reports a channel as
/// `ok` before it has ever reached the service.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ListenerHealth {
    /// No exchange has completed yet, so the channel has nothing to report.
    /// Not a failure — a listener that has only just started is not yet
    /// broken — but not evidence of health either.
    Pending,
    /// The most recent exchange succeeded, recently enough that it is still
    /// evidence the channel works.
    Healthy,
    /// Either the most recent exchange failed, or the last success is old
    /// enough that the channel will no longer vouch for it. Both mean a live
    /// `listen()` is not proof the channel is working.
    Unhealthy,
}

/// Error a [`Channel::finalize_draft`] implementation returns when it posted
/// part of a chunked final answer and could not deliver the remainder. The
/// accepted prefix is already on the wire, so a caller that falls back to
/// resending the whole answer would duplicate the delivered chunks. Callers must
/// treat this as degraded-but-committed delivery: do NOT resend the full answer;
/// the undelivered suffix is lost. `delivered` is the number of physical chunks
/// accepted before the failure, for logging only.
#[derive(Debug)]
pub struct FinalizePartialDelivery {
    pub delivered: usize,
}

impl fmt::Display for FinalizePartialDelivery {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "final answer partially delivered ({} chunk(s) accepted); \
             remainder undelivered and must not be resent",
            self.delivered
        )
    }
}

impl std::error::Error for FinalizePartialDelivery {}

/// Error a [`Channel::finalize_draft`] implementation returns when it could not
/// deliver any part of the final answer and the platform has asked it not to
/// send again yet (for example a Telegram flood limit with `retry_after`).
/// Nothing is on the wire, but a caller that falls back to resending the whole
/// answer would only extend the platform's penalty. Callers must treat this as
/// failed delivery and must NOT resend.
#[derive(Debug)]
pub struct FinalizeUndelivered {
    pub reason: String,
}

impl fmt::Display for FinalizeUndelivered {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "final answer not delivered and must not be resent: {}",
            self.reason
        )
    }
}

impl std::error::Error for FinalizeUndelivered {}

/// Core channel trait — implement for any messaging platform.
///
/// Every `Channel` is `Attributable`: the orchestrator's spawn site opens
/// `attribution_span!(&*ch)` so log emissions from within `listen()` /
/// `send()` inherit `channel = <type>.<alias>`.
#[async_trait]
pub trait Channel: Send + Sync + crate::attribution::Attributable {
    /// Human-readable channel name
    fn name(&self) -> &str;

    /// Send a message through this channel
    async fn send(&self, message: &SendMessage) -> anyhow::Result<()>;

    /// Send the completed assistant response for a turn.
    ///
    /// Most channels use the ordinary send path. Channels with delivery
    /// policy that applies only to final responses can override this without
    /// changing the shared message shape or affecting system and approval
    /// sends.
    async fn send_final(&self, message: &SendMessage) -> anyhow::Result<()> {
        self.send(message).await
    }

    /// Start listening for incoming messages (long-running)
    async fn listen(&self, tx: tokio::sync::mpsc::Sender<ChannelMessage>) -> anyhow::Result<()>;

    /// Receive the supervisor lifecycle token before `listen()` is called.
    /// Channels that internally wait for shutdown can subscribe instead of
    /// independently catching SIGINT.
    fn set_cancel_token(&self, _token: CancellationToken) {}

    /// Whether this channel participates in the cooperative cancellation
    /// contract via `set_cancel_token`. Only participating channels get
    /// a bounded grace period for cleanup after cancellation.
    fn uses_cancel_token(&self) -> bool {
        false
    }

    /// Check if channel is healthy
    async fn health_check(&self) -> bool {
        true
    }

    /// Present a channel-native model picker for a bare `/model` command.
    ///
    /// The picker is presentation only: a confirmed selection must re-enter
    /// the runtime through the existing `/model <ref>` command path so model
    /// resolution and session scoping keep a single owner. `request` carries
    /// the reply scope (`reply_target`/`thread_ts`) the picker must preserve
    /// and a restart-scoped route snapshot it must not exceed; see
    /// [`ChannelModelPickerRequest`] for the per-field contract.
    ///
    /// Returns `Ok(true)` when the channel presented a picker and took over
    /// the interaction, `Ok(false)` when it did not (e.g. a channel without a
    /// native picker, an alias or owner mismatch, or an empty
    /// `requesting_user_id`) — the caller then falls back to the ordinary
    /// text response. Returning `Err` reports a presentation failure; the
    /// caller logs it and falls back to the text response as well. The
    /// default implementation returns `Ok(false)` for every channel, keeping
    /// the existing text behavior.
    async fn present_model_picker(
        &self,
        _request: &ChannelModelPickerRequest,
    ) -> anyhow::Result<bool> {
        Ok(false)
    }

    /// Listener health as the channel itself last observed it.
    ///
    /// `health_check` is an *active* probe: implementations reach the remote
    /// service to answer it, and some of them send a real message or open a
    /// broker connection to do so. That makes it safe to call on demand — from
    /// `channel doctor` — and unsafe to call on a timer, so a recurring caller
    /// must not use it.
    ///
    /// This is the recurring-safe counterpart. It is synchronous and returns
    /// state the channel recorded while it was already talking to the service,
    /// so reading it performs no I/O and cannot block, send, or connect.
    ///
    /// `None` — the default — means the channel offers no signal at all, and
    /// the caller should fall back to whatever it knew before asking. A channel
    /// that *does* implement this reports a [`ListenerHealth`], which is a
    /// three-state answer rather than a boolean: "I have nothing to say yet" is
    /// not the same claim as "I am working", and a caller that collapses them
    /// reports a listener as healthy before it has ever connected.
    ///
    /// An implementation owns its own freshness rule, because only the channel
    /// knows how often a working listener completes an exchange. A success from
    /// long enough ago that it is no longer evidence must be reported as
    /// [`ListenerHealth::Unhealthy`], not as `Healthy` forever.
    fn listener_health(&self) -> Option<ListenerHealth> {
        None
    }

    /// Send a discrete-choice prompt with options.
    ///
    /// Each `(callback_id, label)` pair represents one choice. Whether
    /// the `callback_id` round-trips on inbound is **channel-specific**:
    ///
    /// - **WhatsApp Cloud** preserves the `callback_id` exactly — it
    ///   appears as `interactive.button_reply.id` /
    ///   `interactive.list_reply.id`, surfaced as
    ///   `[choice]<callback_id>` in the inbound `ChannelMessage.content`.
    /// - **Signal** uses native polls. Real signal-cli `pollVote`
    ///   payloads round-trip selected option indexes, surfaced as
    ///   `[choice-index]N` with a 1-based index. Some alternate
    ///   `pollAnswer` payloads may include selected titles and surface
    ///   as `[choice]<label>`, but callers needing stable callback ids
    ///   should maintain a side map keyed by poll option index.
    /// - **Default text fallback** (Matrix, SMS, IRC, mock) renders a
    ///   numbered list with a "reply with name or number" hint and
    ///   relies on the consumer's own matcher to resolve the user's
    ///   text reply against the option list.
    ///
    /// `options.is_empty()` is treated as "send the prompt as plain
    /// text with no choices" rather than rendering an empty selection
    /// hint; if `prompt` is also empty the call is a no-op (returns
    /// `Ok(())`).
    ///
    /// `prompt` is the question / title; rendered ABOVE the options.
    async fn send_choice(
        &self,
        recipient: &str,
        prompt: &str,
        options: &[(String, String)],
    ) -> anyhow::Result<()> {
        let trimmed_prompt = prompt.trim();
        if options.is_empty() {
            // No options to render. Send the prompt as plain text; if
            // there's nothing to say either, this is a no-op so we
            // don't ship an empty message that confuses the client.
            if trimmed_prompt.is_empty() {
                return Ok(());
            }
            return self
                .send(&SendMessage::new(trimmed_prompt, recipient))
                .await;
        }

        let mut text = String::new();
        if !trimmed_prompt.is_empty() {
            text.push_str(trimmed_prompt);
            text.push_str("\n\n");
        }
        text.push_str("(reply with name or number)\n");
        for (idx, (_id, label)) in options.iter().enumerate() {
            text.push_str(&format!("{}. {}\n", idx + 1, label.trim()));
        }
        // Trim trailing newline so the message looks tidy across clients.
        let trimmed = text.trim_end().to_string();
        self.send(&SendMessage::new(trimmed, recipient)).await
    }

    /// Signal that the bot is processing a response (e.g. "typing" indicator).
    async fn start_typing(&self, _recipient: &str) -> anyhow::Result<()> {
        Ok(())
    }

    /// Stop any active typing indicator.
    async fn stop_typing(&self, _recipient: &str) -> anyhow::Result<()> {
        Ok(())
    }

    /// Whether this channel supports progressive message updates via draft edits.
    fn supports_draft_updates(&self) -> bool {
        false
    }

    /// Whether this channel can post a native poll through [`Channel::send_poll`].
    /// Callers check this before offering one, so a channel without native
    /// polls keeps whatever fallback the caller already had.
    fn supports_native_polls(&self) -> bool {
        false
    }

    /// Whether `send` actually delivers a message OUTBOUND on this channel. Default
    /// `true`. An INBOUND-ONLY transport (e.g. an AMQP trigger source whose `send` is a
    /// deliberate no-op that returns `Ok`) overrides this to `false`, so a surface that
    /// must genuinely deliver - such as the SOP approval route adapter - can refuse to
    /// route to it (and report the misconfiguration) instead of silently succeeding
    /// without sending anything.
    fn supports_outbound_send(&self) -> bool {
        true
    }

    /// Self-loop guard for multi-agent runs: the bot's own handle/identity on
    /// this channel, so the orchestrator can drop inbound events whose
    /// `sender` matches. A bot must never respond to its own messages, even
    /// if a misconfigured peer group lists the bot's handle as an external
    /// peer.
    ///
    /// **Channels that handle inbound traffic must override this.** The
    /// default `None` disables both layers of the self-loop guard
    /// (`drop_self_messages` here and the agent-loop fallback), leaving the
    /// channel unprotected from looping on its own outbound. Outbound-only
    /// channels can keep the default.
    fn self_handle(&self) -> Option<String> {
        None
    }

    /// The exact form the bot expects when addressed by users on this channel
    /// (e.g. Discord `<@snowflake>`, Telegram `@bot_username`). Returned
    /// verbatim into the per-channel system prompt. Default `None` for
    /// channels with no inbound mention concept. Channels that override
    /// `self_handle` should usually override this too.
    fn self_addressed_mention(&self) -> Option<String> {
        None
    }

    /// Whether the orchestrator should drop an inbound message as
    /// self-authored (multi-agent self-loop guard). Default compares
    /// `msg.sender` against [`Self::self_handle`] case-insensitively after
    /// stripping a leading `@` from each side. Override only for platforms
    /// whose identity comparison is non-string.
    fn drop_self_messages(&self, msg: &ChannelMessage) -> bool {
        let Some(handle) = self.self_handle() else {
            return false;
        };
        let handle_norm = handle.trim_start_matches('@').to_ascii_lowercase();
        let sender_norm = msg.sender.trim_start_matches('@').to_ascii_lowercase();
        !handle_norm.is_empty() && handle_norm == sender_norm
    }

    async fn forge_request(&self, _request: ForgeApiRequest) -> anyhow::Result<ForgeApiResponse> {
        anyhow::bail!(
            "channel '{}' does not support forge API requests",
            self.name()
        )
    }

    /// Whether an inbound message is a direct one-to-one conversation with
    /// the bot. A DM is definitionally addressed to the bot, so the
    /// orchestrator skips the reply-intent classifier and goes straight to
    /// the tool-capable agent turn. Default `false`: channels that cannot
    /// prove a one-to-one context keep the classifier precheck.
    fn is_direct_message(&self, _msg: &ChannelMessage) -> bool {
        false
    }

    /// Whether this channel supports multi-message streaming delivery.
    fn supports_multi_message_streaming(&self) -> bool {
        false
    }

    /// Whether this channel implements the turn-flush narration contract:
    /// `flush_draft_turn` delivers each completed agent text turn as a permanent
    /// outbound message, and the orchestrator therefore routes that narration
    /// through the outbound hook + leak-detection boundary and orders it ahead of
    /// the approval prompt via a flush barrier.
    ///
    /// Distinct from [`Self::supports_multi_message_streaming`]: a channel can stream
    /// multiple messages another way (e.g. paragraph edits via `update_draft`)
    /// without implementing `flush_draft_turn`. Only channels that override
    /// `flush_draft_turn` may return `true` here, otherwise the orchestrator runs
    /// outbound policy on phantom flushes that deliver nothing. Default `false`.
    fn supports_turn_flush_narration(&self) -> bool {
        false
    }

    /// Minimum delay (ms) between successive messages in multi-message mode.
    /// The message boundary is channel-specific (for example, Telegram uses
    /// completed agent turns).
    fn multi_message_delay_ms(&self) -> u64 {
        800
    }

    /// Confirmed-delivery byte offset for a MultiMessage draft: how many bytes
    /// of the cumulative visible text previously handed to `update_draft` have
    /// already been emitted on the transport as paragraph messages (including
    /// their trailing `\n\n` delimiters).
    ///
    /// The orchestrator reads this before `finalize_draft` so it can reconcile
    /// a sanitized final response against the paragraphs that are already on
    /// the wire without stranding or replaying content. Channels that do not
    /// support multi-message streaming keep the default of `0` (nothing
    /// confirmed).
    async fn multi_message_confirmed_offset(&self, _recipient: &str, _message_id: &str) -> usize {
        0
    }

    /// Send an initial draft message. Returns a platform-specific message ID for later edits.
    async fn send_draft(&self, _message: &SendMessage) -> anyhow::Result<Option<String>> {
        Ok(None)
    }

    /// Update a previously sent draft message with new accumulated content.
    async fn update_draft(
        &self,
        _recipient: &str,
        _message_id: &str,
        _text: &str,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Show a progress/status update (e.g. tool execution status).
    async fn update_draft_progress(
        &self,
        _recipient: &str,
        _message_id: &str,
        _text: &str,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Show a batch of progress/status updates as one coalesced draft update.
    ///
    /// Channels with expensive edit APIs should override this so an upstream
    /// burst does not turn into one awaited network edit per progress item.
    async fn update_draft_progress_batch(
        &self,
        recipient: &str,
        message_id: &str,
        texts: &[String],
    ) -> anyhow::Result<()> {
        for text in texts {
            self.update_draft_progress(recipient, message_id, text)
                .await?;
        }
        Ok(())
    }

    /// Show a batch of progress updates without discarding their source kind.
    ///
    /// The default preserves compatibility for channels that only need text;
    /// channels that coalesce semantically different progress should override
    /// this method and keep the kind through their local draft buffer.
    async fn update_typed_draft_progress_batch(
        &self,
        recipient: &str,
        message_id: &str,
        progress: &[DraftProgress],
    ) -> anyhow::Result<()> {
        let texts = progress
            .iter()
            .map(|entry| entry.text.clone())
            .collect::<Vec<_>>();
        self.update_draft_progress_batch(recipient, message_id, &texts)
            .await
    }

    /// Show localized lifecycle progress produced from a typed runtime event.
    /// Unlike raw tool status text, this input is trusted channel chrome.
    async fn update_draft_lifecycle(
        &self,
        _recipient: &str,
        _message_id: &str,
        _event: ProgressEvent,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Flush the current agent text turn as an outbound message in multi-message
    /// streaming mode. Called when an LLM turn completes (e.g. before tool
    /// execution). Default: no-op.
    async fn flush_draft_turn(
        &self,
        _recipient: &str,
        _message_id: &str,
        _text: &str,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Discard a completed agent text turn WITHOUT sending it, marking that
    /// narration consumed for this draft. Called when the outbound hook cancels a
    /// narration flush: the cancelled turn must never be re-offered (no
    /// resurrection), but narration produced by a *later* turn must still be
    /// deliverable. Advancing the channel's delivered-prefix bookkeeping over the
    /// cancelled text achieves both. Default: no-op.
    async fn discard_draft_turn(
        &self,
        _recipient: &str,
        _message_id: &str,
        _text: &str,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Finalize a draft with the complete response (e.g. apply Markdown formatting).
    /// `suppress_voice` forces text delivery even on voice-only peers.
    ///
    /// If finalization must chunk a long answer and a later chunk fails after an
    /// earlier one was accepted, return [`FinalizePartialDelivery`] rather than a
    /// generic error: it tells the caller the accepted prefix is already posted
    /// so it must not resend the whole answer (which would duplicate the
    /// delivered chunks). A generic `Err` still means nothing was committed and a
    /// full-message fallback is safe.
    async fn finalize_draft(
        &self,
        _recipient: &str,
        _message_id: &str,
        _text: &str,
        _suppress_voice: bool,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Cancel and remove a previously sent draft message if the channel supports it.
    async fn cancel_draft(&self, _recipient: &str, _message_id: &str) -> anyhow::Result<()> {
        Ok(())
    }

    /// Add a reaction (emoji) to a message.
    async fn add_reaction(
        &self,
        _channel_id: &str,
        _message_id: &str,
        _emoji: &str,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Remove a reaction (emoji) from a message previously added by this bot.
    async fn remove_reaction(
        &self,
        _channel_id: &str,
        _message_id: &str,
        _emoji: &str,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Pin a message in the channel.
    async fn pin_message(&self, _channel_id: &str, _message_id: &str) -> anyhow::Result<()> {
        Ok(())
    }

    /// Unpin a previously pinned message.
    async fn unpin_message(&self, _channel_id: &str, _message_id: &str) -> anyhow::Result<()> {
        Ok(())
    }

    /// Redact (delete) a message from the channel.
    async fn redact_message(
        &self,
        _channel_id: &str,
        _message_id: &str,
        _reason: Option<String>,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Create a new platform room/conversation when the channel supports it.
    async fn create_room(&self, _options: &RoomCreationOptions) -> anyhow::Result<String> {
        anyhow::bail!("channel does not support room creation")
    }

    /// Post a native poll when the channel supports it.
    async fn send_poll(&self, _poll: &PollRequest) -> anyhow::Result<()> {
        anyhow::bail!("channel does not support native polls")
    }

    /// Invite a user to an existing platform room/conversation.
    async fn invite_user(&self, _room_id: &str, _user_id: &str) -> anyhow::Result<()> {
        anyhow::bail!("channel does not support room invites")
    }

    /// Context this channel supplies about `room_id`, when the adapter can
    /// provide it and the operator has opted the alias in.
    ///
    /// Returns `None` by default: a channel that does not implement this, or a
    /// room the operator has not opted in, contributes nothing to the prompt.
    /// Absence is the safe state, so the default is the safe one.
    fn room_context(&self, _room_id: &str) -> Option<ChannelRoomContext> {
        None
    }

    /// Request interactive tool-call approval from the channel operator.
    ///
    /// Returns `Ok(Some(response))` when the operator answers within the
    /// channel's configured `approval_timeout_secs`; timeouts surface as
    /// `Deny`. Returns `Ok(None)` only for channels that do not implement
    /// the prompt at all — the caller falls back to its default policy
    /// (typically auto-deny).
    async fn request_approval(
        &self,
        _recipient: &str,
        _request: &ChannelApprovalRequest,
    ) -> anyhow::Result<Option<ChannelApprovalResponse>> {
        Ok(None)
    }

    /// Like [`Channel::request_approval`], but also reports WHO produced the
    /// decision: which back-channel answered (`decided_by`) and whether a person
    /// answered at all ([`ApprovalSource`]).
    ///
    /// **Override this whenever the channel can synthesize a response.** The
    /// [`Channel::request_approval`] contract collapses "the operator denied"
    /// and "nobody answered in time" into the same `Some(Deny)`, so the default
    /// below cannot tell them apart and assumes [`ApprovalSource::Operator`].
    /// Any implementation that manufactures a `Deny` on timeout, on a dropped
    /// responder, or on an unreachable approver MUST implement this method and
    /// report the real source — otherwise the runtime tells the model a human
    /// refused when none was ever asked.
    ///
    /// The convention in-tree is to put the real body here and let
    /// [`Channel::request_approval`] delegate to it, so the logic lives once.
    async fn request_approval_attributed(
        &self,
        recipient: &str,
        request: &ChannelApprovalRequest,
    ) -> anyhow::Result<Option<AttributedApprovalResponse>> {
        Ok(self
            .request_approval(recipient, request)
            .await?
            .map(AttributedApprovalResponse::operator))
    }

    /// Request an attributed approval using a caller-owned response budget.
    ///
    /// The default keeps the existing caller-side timeout semantics. Channels
    /// with a claim-aware deadline handoff may override this so their pending
    /// decision and any bounded resolution grace share one deadline owner.
    async fn request_approval_attributed_with_timeout(
        &self,
        recipient: &str,
        request: &ChannelApprovalRequest,
        timeout: std::time::Duration,
    ) -> anyhow::Result<Option<AttributedApprovalResponse>> {
        match tokio::time::timeout(
            timeout,
            self.request_approval_attributed(recipient, request),
        )
        .await
        {
            Ok(result) => result,
            Err(_) => Ok(Some(AttributedApprovalResponse::from_runtime(
                ChannelApprovalResponse::Deny,
                ApprovalSource::TimedOut,
            ))),
        }
    }

    /// Present a long-lived, out-of-band gate prompt (e.g. a parked SOP
    /// approval) on this channel, rendered natively — an embed with one button
    /// per choice on Discord, an inline keyboard on Telegram, and so on.
    ///
    /// UNLIKE [`Channel::request_approval`] this does NOT wait for the answer:
    /// the prompt outlives the call (and daemon restarts). The choice comes
    /// back through the channel's normal INBOUND path — a component click
    /// (stamped with an internal `sop.gate:` marker by the channel's own
    /// interaction producer, never derivable from message text) or a plain
    /// `<choice> <reference>` text reply — which the orchestrator resolves
    /// against the parked gate.
    ///
    /// Default `Ok(false)` = "no native prompt on this channel"; the caller
    /// then falls back to a plain text notice carrying the reply instructions.
    async fn send_gate_prompt(
        &self,
        _recipient: &str,
        _prompt: &ChannelGatePrompt,
    ) -> anyhow::Result<bool> {
        Ok(false)
    }

    /// Mark a previously sent gate prompt as resolved: strip its interactive
    /// controls and replace the body with `outcome` (e.g. "Approved by @user —
    /// run resumed"), so a decided gate cannot be clicked again and the
    /// decision is visible in place. `reference` is the same correlation key
    /// the prompt was sent with. Best-effort: `Ok(false)` when this channel
    /// has nothing to finalize (no native prompt, or the mapping was lost to a
    /// restart) — the gate state itself is never affected.
    async fn finalize_gate_prompt(&self, _reference: &str, _outcome: &str) -> anyhow::Result<bool> {
        Ok(false)
    }

    /// Ask the user a multiple-choice question and return the chosen option's text.
    ///
    /// Returns `Ok(Some(answer))` if the channel handled the question natively
    /// (e.g. ACP `elicitation/create` with a single-select enum schema, or
    /// the legacy `session/request_permission` fallback for older ACP clients;
    /// Telegram inline keyboard; etc.). Returns `Ok(None)` to signal the
    /// caller should fall back to the generic `send` + `listen` flow.
    /// Default impl returns `None`.
    ///
    /// Free-form (no-choices) questions are not modeled by this method.
    /// Multiple-choice support landed via ACP `elicitation/create` (see
    /// the ACP elicitation RFD: <https://agentclientprotocol.com/rfds/elicitation>);
    /// free-form text is tracked under that spec's Phase 2.
    async fn request_choice(
        &self,
        _question: &str,
        _choices: &[String],
        _timeout: std::time::Duration,
    ) -> anyhow::Result<Option<String>> {
        Ok(None)
    }

    async fn request_multi_choice(
        &self,
        _question: &str,
        _choices: &[String],
        _min_items: usize,
        _max_items: usize,
        _timeout: std::time::Duration,
    ) -> anyhow::Result<Option<Vec<String>>> {
        Ok(None)
    }

    /// Whether this channel can answer free-form (no-choices) `ask_user`
    /// questions via the standard `send` + `listen` flow. Channels that only
    /// handle structured choices return `false` so callers fail fast with a
    /// useful error instead of timing out on `listen`.
    fn supports_free_form_ask(&self) -> bool {
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gate_choice_kind_ids_round_trip_and_reject_unknown() {
        for kind in [
            GateChoiceKind::Approve,
            GateChoiceKind::Deny,
            GateChoiceKind::Edit,
            GateChoiceKind::Revise,
        ] {
            assert_eq!(GateChoiceKind::from_id(kind.id()), Some(kind));
        }
        // Case-insensitive parse; unknown tokens are None (dropped, never coerced).
        assert_eq!(
            GateChoiceKind::from_id("APPROVE"),
            Some(GateChoiceKind::Approve)
        );
        assert_eq!(GateChoiceKind::from_id("escalate"), None);
        assert_eq!(GateChoiceKind::from_id(""), None);
        // Only the text-collecting choices report collects_text.
        assert!(GateChoiceKind::Edit.collects_text());
        assert!(GateChoiceKind::Revise.collects_text());
        assert!(!GateChoiceKind::Approve.collects_text());
        assert!(!GateChoiceKind::Deny.collects_text());
    }

    #[test]
    fn channel_sop_topic_build_parse_roundtrip() {
        let topic = ChannelSopTopic::build("git", "main", "pull_request.opened");
        assert_eq!(topic, "git.main:pull_request.opened");
        let (channel, alias, event_type) = ChannelSopTopic::parse(&topic);
        assert_eq!(channel, "git");
        assert_eq!(alias, Some("main"));
        assert_eq!(event_type, Some("pull_request.opened"));
    }

    #[test]
    fn channel_sop_topic_parses_message_forms() {
        let (channel, alias, event_type) = ChannelSopTopic::parse("telegram");
        assert_eq!(channel, "telegram");
        assert_eq!(alias, None);
        assert_eq!(event_type, None);

        let (channel, alias, event_type) = ChannelSopTopic::parse("telegram/prod");
        assert_eq!(channel, "telegram");
        assert_eq!(alias, Some("prod"));
        assert_eq!(event_type, None);
    }

    /// Stub channel that overrides `self_handle` so the default
    /// `drop_self_messages` implementation can be exercised.
    struct StubChannel {
        handle: Option<String>,
    }

    impl crate::attribution::Attributable for StubChannel {
        fn role(&self) -> crate::attribution::Role {
            crate::attribution::Role::Channel(crate::attribution::ChannelKind::Webhook)
        }
        fn alias(&self) -> &str {
            "stub"
        }
    }

    #[async_trait]
    impl Channel for StubChannel {
        fn name(&self) -> &str {
            "stub"
        }
        async fn send(&self, _message: &SendMessage) -> anyhow::Result<()> {
            Ok(())
        }
        async fn listen(
            &self,
            _tx: tokio::sync::mpsc::Sender<ChannelMessage>,
        ) -> anyhow::Result<()> {
            Ok(())
        }
        fn self_handle(&self) -> Option<String> {
            self.handle.clone()
        }
    }

    fn msg_from(sender: &str) -> ChannelMessage {
        ChannelMessage::new("1", sender, "", "hi", "stub", 0)
    }

    #[test]
    fn channel_message_new_zeros_optional_fields() {
        let msg = ChannelMessage::new("id1", "alice", "room-1", "hello", "slack", 42);
        assert_eq!(msg.id, "id1");
        assert_eq!(msg.sender, "alice");
        assert_eq!(msg.reply_target, "room-1");
        assert_eq!(msg.content, "hello");
        assert_eq!(msg.channel, "slack");
        assert_eq!(msg.timestamp, 42);
        assert!(msg.channel_alias.is_none());
        assert!(msg.thread_ts.is_none());
        assert!(msg.interruption_scope_id.is_none());
        assert!(msg.attachments.is_empty());
        assert!(msg.subject.is_none());
        assert!(!msg.passive_context);
        assert!(!msg.explicitly_addressed);
        assert_eq!(msg.conversation_scope, ChannelConversationScope::Sender);
        assert!(msg.references.is_empty());
    }

    #[test]
    fn send_message_reply_to_sets_threading_fields() {
        let inbound = ChannelMessage {
            id: "msg-001".into(),
            reply_target: "user@example.com".into(),
            thread_ts: Some("thread-1".into()),
            subject: Some("Hello there".into()),
            ..ChannelMessage::new("msg-001", "alice", "user@example.com", "", "email", 0)
        };
        let reply = SendMessage::reply_to(&inbound, "Got it");
        assert_eq!(reply.recipient, "user@example.com");
        assert_eq!(reply.in_reply_to.as_deref(), Some("msg-001"));
        assert_eq!(reply.thread_ts.as_deref(), Some("thread-1"));
        assert_eq!(reply.subject.as_deref(), Some("Re: Hello there"));
        assert_eq!(reply.content, "Got it");
    }

    #[test]
    fn send_message_reply_to_does_not_double_re_prefix() {
        let inbound = ChannelMessage {
            subject: Some("Re: Already prefixed".into()),
            ..ChannelMessage::new("msg-002", "alice", "user@example.com", "", "email", 0)
        };
        let reply = SendMessage::reply_to(&inbound, "");
        assert_eq!(reply.subject.as_deref(), Some("Re: Already prefixed"));
    }

    #[test]
    fn send_message_reply_to_no_subject_omits_subject() {
        let inbound = ChannelMessage::new("msg-003", "alice", "room-1", "ping", "slack", 0);
        let reply = SendMessage::reply_to(&inbound, "pong");
        assert!(reply.subject.is_none());
        assert_eq!(reply.in_reply_to.as_deref(), Some("msg-003"));
    }

    #[test]
    fn send_message_reply_to_appends_parent_to_references_chain() {
        let inbound = ChannelMessage {
            references: vec!["a".to_string(), "b".to_string()],
            ..ChannelMessage::new("c", "alice", "user@example.com", "", "email", 0)
        };
        let reply = SendMessage::reply_to(&inbound, "Got it");
        assert_eq!(
            reply.references,
            vec!["a".to_string(), "b".to_string(), "c".to_string()]
        );
    }

    #[test]
    fn send_message_new_starts_without_attachments() {
        let msg = SendMessage::new("content", "recipient@example.com");
        assert!(msg.attachments.is_empty());
    }

    #[test]
    fn send_message_with_attachments_stores_the_given_files() {
        let msg = SendMessage::new("content", "recipient@example.com").with_attachments(vec![
            MediaAttachment {
                file_name: "test.pdf".to_string(),
                data: vec![1, 2, 3],
                mime_type: Some("application/pdf".to_string()),
                marker: None,
            },
        ]);

        assert_eq!(msg.attachments.len(), 1);
        assert_eq!(msg.attachments[0].file_name, "test.pdf");
        assert_eq!(msg.attachments[0].data, vec![1, 2, 3]);
        assert_eq!(
            msg.attachments[0].mime_type.as_deref(),
            Some("application/pdf")
        );
    }

    #[test]
    fn send_message_reply_to_references_defaults_to_parent_id_only() {
        let inbound = ChannelMessage::new("c", "alice", "user@example.com", "", "email", 0);
        let reply = SendMessage::reply_to(&inbound, "Got it");
        assert_eq!(reply.references, vec!["c".to_string()]);
    }

    #[test]
    fn room_visibility_parses_supported_values() {
        assert_eq!(
            "private".parse::<RoomVisibility>().unwrap(),
            RoomVisibility::Private
        );
        assert_eq!(
            "PUBLIC".parse::<RoomVisibility>().unwrap(),
            RoomVisibility::Public
        );
    }

    #[test]
    fn room_visibility_rejects_unknown_values() {
        let err = "shared".parse::<RoomVisibility>().unwrap_err();
        assert!(err.to_string().contains("expected private or public"));
    }

    #[tokio::test]
    async fn room_management_defaults_report_unsupported() {
        let channel = StubChannel { handle: None };

        let create = channel
            .create_room(&RoomCreationOptions {
                name: Some("ops".into()),
                ..RoomCreationOptions::default()
            })
            .await
            .unwrap_err();
        assert!(
            create
                .to_string()
                .contains("does not support room creation")
        );

        let invite = channel
            .invite_user("!room:example.org", "@alice:example.org")
            .await
            .unwrap_err();
        assert!(invite.to_string().contains("does not support room invites"));
    }

    #[test]
    fn drop_self_messages_default_returns_false_when_handle_unknown() {
        let channel = StubChannel { handle: None };
        assert!(!channel.drop_self_messages(&msg_from("@anyone")));
    }

    #[test]
    fn drop_self_messages_matches_exact_handle() {
        let channel = StubChannel {
            handle: Some("@my_bot".into()),
        };
        assert!(channel.drop_self_messages(&msg_from("@my_bot")));
        assert!(!channel.drop_self_messages(&msg_from("@other_bot")));
    }

    #[test]
    fn drop_self_messages_normalizes_at_prefix_and_case() {
        let channel = StubChannel {
            handle: Some("My_Bot".into()),
        };
        // SDK delivered with @ prefix, handle stored without. Match.
        assert!(channel.drop_self_messages(&msg_from("@my_bot")));
        // Both with @, mixed case. Match.
        let channel = StubChannel {
            handle: Some("@My_Bot".into()),
        };
        assert!(channel.drop_self_messages(&msg_from("@MY_BOT")));
    }

    #[test]
    fn drop_self_messages_does_not_match_empty_handle() {
        // A handle of "@" (effectively empty after normalization) must
        // not match every inbound message; the guard only fires when
        // the bot has a real handle to compare against.
        let channel = StubChannel {
            handle: Some("@".into()),
        };
        assert!(!channel.drop_self_messages(&msg_from("@anyone")));
    }

    #[test]
    fn deny_with_edit_round_trips_through_serde() {
        let r = ChannelApprovalResponse::DenyWithEdit {
            replacement: "new content".to_string(),
        };
        let json = serde_json::to_string(&r).unwrap();
        let back: ChannelApprovalResponse = serde_json::from_str(&json).unwrap();
        assert!(
            matches!(back, ChannelApprovalResponse::DenyWithEdit { replacement } if replacement == "new content")
        );
    }
}
