use std::collections::VecDeque;
use std::sync::Arc;
use std::sync::Mutex;
use std::time::{Duration, Instant};

use anyhow::Result;
use crossterm::event::{
    self, Event, KeyCode, KeyEvent, KeyEventKind, KeyModifiers, MouseButton, MouseEvent,
    MouseEventKind,
};
use ratatui::{
    layout::{Constraint, Direction, Layout, Rect},
    style::{Color, Modifier, Style},
    text::{Line, Span},
    widgets::{Block, Borders, Clear, Paragraph},
};
use tokio::sync::mpsc;

use crate::acp;
use crate::chat;
use crate::client::{ConnectionState, RpcClient, StatusResult};
use crate::config;
use crate::config_manager;
use crate::dashboard;
use crate::doctor;
use crate::keymap::{GlobalAction, ModalAction, SearchBoxAction};
use crate::logs;
use crate::mouse;
use crate::quickstart_pane;
use crate::sop_pane;
use crate::theme;
use crate::widgets::{CtxBar, HelpContext, HelpEntry, HelpNode};

const DOCK_HEADER_ROWS: u16 = 1;
const DOCK_MIN_SECTION_ROWS: u16 = 3;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum DockCapture {
    Width,
    SessionsHeight,
    QueuePlanHeight,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum DockAction {
    ToggleSessions,
    ToggleQueue,
    TogglePlan,
    SwitchSide,
    PersistWidth(u16),
    PersistSessionsPercent(u16),
    PersistQueuePercent(u16),
}

#[derive(Debug, Clone, Copy, Default)]
struct DockLayout {
    content: Rect,
    conversation: Rect,
    dock: Option<Rect>,
    header: Rect,
    sessions: Option<Rect>,
    queue: Option<Rect>,
    plan: Option<Rect>,
    width_edge: Rect,
    divider: Rect,
    plan_divider: Rect,
    side_switch: Rect,
    toggles: [Rect; 3],
    close: [Rect; 3],
}

struct ConversationDock {
    config_dir: std::path::PathBuf,
    sessions_visible: bool,
    queue_visible: bool,
    plan_visible: bool,
    side: config::SidebarSide,
    width: u16,
    sessions_percent: u16,
    queue_percent: u16,
    capture: Option<DockCapture>,
    layout: DockLayout,
}

impl ConversationDock {
    fn from_config_dir(config_dir: &std::path::Path) -> Self {
        let config = config::ensure_and_load(config_dir).unwrap_or_default();
        Self {
            config_dir: config_dir.to_path_buf(),
            sessions_visible: config.sidebar.visible,
            queue_visible: config.sidebar.queue_visible,
            plan_visible: config.sidebar.plan_visible,
            side: config.effective_sidebar_side(),
            width: config.effective_sidebar_width(),
            sessions_percent: config.effective_sidebar_sessions_percent(),
            queue_percent: config.effective_sidebar_queue_percent(),
            capture: None,
            layout: DockLayout::default(),
        }
    }

    fn clear_capture(&mut self) {
        self.capture = None;
    }

    fn layout(&mut self, content: Rect, mode: Mode, plan_visible: bool) -> DockLayout {
        let active_conversation = matches!(mode, Mode::Acp | Mode::Chat);
        let show_sessions = active_conversation && self.sessions_visible;
        let show_queue = active_conversation && self.queue_visible;
        let show_plan = active_conversation && plan_visible && self.plan_visible;
        let mut layout = DockLayout {
            content,
            conversation: content,
            ..DockLayout::default()
        };
        let mut content = content;
        if active_conversation && content.height > 1 {
            let mut x = content.x;
            for (index, label) in Self::section_labels().iter().enumerate() {
                let width = (unicode_width::UnicodeWidthStr::width(label.as_str()) as u16 + 4)
                    .min(content.right().saturating_sub(x) / (3 - index as u16));
                layout.toggles[index] = Rect::new(x, content.y, width, 1);
                x = x.saturating_add(width);
            }
            content.y += 1;
            content.height -= 1;
            layout.content = content;
            layout.conversation = content;
        }
        let width = self
            .width
            .clamp(config::SIDEBAR_WIDTH_MIN, config::SIDEBAR_WIDTH_MAX);
        if !(show_sessions || show_queue || show_plan)
            || content.width < width.saturating_add(crate::agent_sidebar::CONTENT_MIN_COLS)
            || content.height <= DOCK_HEADER_ROWS
        {
            self.clear_capture();
            self.layout = layout;
            return layout;
        }

        let dock = match self.side {
            config::SidebarSide::Left => Rect::new(content.x, content.y, width, content.height),
            config::SidebarSide::Right => Rect::new(
                content.right().saturating_sub(width),
                content.y,
                width,
                content.height,
            ),
        };
        let conversation = match self.side {
            config::SidebarSide::Left => Rect::new(
                dock.right(),
                content.y,
                content.width.saturating_sub(width),
                content.height,
            ),
            config::SidebarSide::Right => Rect::new(
                content.x,
                content.y,
                content.width.saturating_sub(width),
                content.height,
            ),
        };
        let header = Rect::new(dock.x, dock.y, dock.width, DOCK_HEADER_ROWS);
        let body = Rect::new(
            dock.x,
            dock.y.saturating_add(DOCK_HEADER_ROWS),
            dock.width,
            dock.height.saturating_sub(DOCK_HEADER_ROWS),
        );
        layout.conversation = conversation;
        layout.dock = Some(dock);
        layout.header = header;
        layout.side_switch =
            Rect::new(dock.right().saturating_sub(7), dock.y, 6.min(dock.width), 1);
        layout.width_edge = match self.side {
            config::SidebarSide::Left => {
                Rect::new(dock.right().saturating_sub(1), dock.y, 1, dock.height)
            }
            config::SidebarSide::Right => Rect::new(dock.x, dock.y, 1, dock.height),
        };

        let section_count = u16::from(show_sessions) + u16::from(show_queue) + u16::from(show_plan);
        let section_space = body.height.saturating_sub(section_count.saturating_sub(1));
        if section_space < DOCK_MIN_SECTION_ROWS * section_count {
            layout.conversation = content;
            layout.dock = None;
            layout.header = Rect::default();
            layout.side_switch = Rect::default();
            layout.width_edge = Rect::default();
            self.clear_capture();
            self.layout = layout;
            return layout;
        }

        let mut next_y = body.y;
        let mut remaining = section_space;
        if show_sessions {
            let lower_count = u16::from(show_queue) + u16::from(show_plan);
            let height = if lower_count == 0 {
                remaining
            } else {
                ((u32::from(section_space) * u32::from(self.sessions_percent) / 100) as u16).clamp(
                    DOCK_MIN_SECTION_ROWS,
                    remaining - DOCK_MIN_SECTION_ROWS * lower_count,
                )
            };
            layout.sessions = Some(Rect::new(body.x, next_y, body.width, height));
            next_y += height;
            remaining -= height;
            if lower_count > 0 {
                layout.divider = Rect::new(body.x, next_y, body.width, 1);
                next_y += 1;
            }
        }
        if show_queue {
            let height = if show_plan {
                ((u32::from(remaining) * u32::from(self.queue_percent) / 100) as u16)
                    .clamp(DOCK_MIN_SECTION_ROWS, remaining - DOCK_MIN_SECTION_ROWS)
            } else {
                remaining
            };
            layout.queue = Some(Rect::new(body.x, next_y, body.width, height));
            next_y += height;
            remaining -= height;
            if show_plan {
                layout.plan_divider = Rect::new(body.x, next_y, body.width, 1);
                next_y += 1;
            }
        }
        if show_plan {
            layout.plan = Some(Rect::new(body.x, next_y, body.width, remaining));
        }
        for (index, area) in [layout.sessions, layout.queue, layout.plan]
            .into_iter()
            .enumerate()
        {
            if let Some(area) = area {
                // Sessions keeps its existing plus control at the right edge.
                let inset = if index == 0 { 8 } else { 4 };
                layout.close[index] = Rect::new(area.right().saturating_sub(inset), area.y, 3, 1);
            }
        }
        if self.capture.is_some_and(|capture| match capture {
            DockCapture::Width => layout.width_edge.is_empty(),
            DockCapture::SessionsHeight => layout.divider.is_empty(),
            DockCapture::QueuePlanHeight => layout.plan_divider.is_empty(),
        }) {
            self.clear_capture();
        }
        self.layout = layout;
        layout
    }

    fn section_labels() -> [String; 3] {
        [
            "zc-dock-toggle-sessions",
            "zc-dock-toggle-queue",
            "zc-dock-toggle-plan",
        ]
        .map(crate::i18n::t)
    }

    fn toggle_section(&mut self, index: usize) -> DockAction {
        let action = match index {
            0 => {
                self.sessions_visible = !self.sessions_visible;
                DockAction::ToggleSessions
            }
            1 => {
                self.queue_visible = !self.queue_visible;
                DockAction::ToggleQueue
            }
            _ => {
                self.plan_visible = !self.plan_visible;
                DockAction::TogglePlan
            }
        };
        self.clear_capture();
        action
    }

    fn draw_shell(&self, frame: &mut ratatui::Frame) {
        for (index, label) in Self::section_labels().into_iter().enumerate() {
            let visible = [self.sessions_visible, self.queue_visible, self.plan_visible][index];
            let marker = if visible { "−" } else { "+" };
            frame.render_widget(
                Paragraph::new(format!("[{marker} {label}]")).style(if visible {
                    theme::accent_style()
                } else {
                    theme::dim_style()
                }),
                self.layout.toggles[index],
            );
        }
        let Some(dock) = self.layout.dock else {
            return;
        };
        frame.render_widget(
            ratatui::widgets::Block::default().style(theme::fill_style()),
            dock,
        );
        let side = match self.side {
            config::SidebarSide::Left => crate::i18n::t("zc-dock-side-left"),
            config::SidebarSide::Right => crate::i18n::t("zc-dock-side-right"),
        };
        let label = crate::i18n::t_args("zc-dock-header", &[("side", &side)]);
        let label_inset = u16::from(self.side == config::SidebarSide::Right);
        let label_area = Rect::new(
            self.layout.header.x.saturating_add(label_inset),
            self.layout.header.y,
            self.layout
                .side_switch
                .x
                .saturating_sub(self.layout.header.x.saturating_add(label_inset)),
            self.layout.header.height,
        );
        frame.render_widget(
            Paragraph::new(Span::styled(label, theme::title_style())),
            label_area,
        );
        frame.render_widget(
            Paragraph::new(Span::styled(
                crate::i18n::t("zc-dock-switch-side"),
                theme::accent_style(),
            )),
            self.layout.side_switch,
        );
    }

    fn draw_resize_handles(&self, frame: &mut ratatui::Frame) {
        for close in self.layout.close {
            frame.render_widget(Paragraph::new("[×]").style(theme::accent_style()), close);
        }
        if self.layout.width_edge.width > 0 {
            frame.render_widget(
                Paragraph::new(Span::styled("│", theme::dim_style())),
                self.layout.width_edge,
            );
            let handle = Rect::new(
                self.layout.width_edge.x,
                self.layout
                    .width_edge
                    .y
                    .saturating_add(self.layout.width_edge.height / 2),
                1,
                1,
            );
            frame.render_widget(
                Paragraph::new(Span::styled("↔", theme::accent_style())),
                handle,
            );
        }
        if self.layout.divider.height > 0 {
            frame.render_widget(
                Paragraph::new(Span::styled(
                    "─".repeat(self.layout.divider.width as usize),
                    theme::dim_style(),
                )),
                self.layout.divider,
            );
            let handle = Rect::new(
                self.layout
                    .divider
                    .x
                    .saturating_add(self.layout.divider.width / 2),
                self.layout.divider.y,
                1,
                1,
            );
            frame.render_widget(
                Paragraph::new(Span::styled("↕", theme::accent_style())),
                handle,
            );
        }
        if self.layout.plan_divider.height > 0 {
            frame.render_widget(
                Paragraph::new(Span::styled(
                    "─".repeat(self.layout.plan_divider.width as usize),
                    theme::dim_style(),
                )),
                self.layout.plan_divider,
            );
            let handle = Rect::new(
                self.layout
                    .plan_divider
                    .x
                    .saturating_add(self.layout.plan_divider.width / 2),
                self.layout.plan_divider.y,
                1,
                1,
            );
            frame.render_widget(
                Paragraph::new(Span::styled("↕", theme::accent_style())),
                handle,
            );
        }
    }

    fn set_width_from_column(&mut self, column: u16) {
        let content = self.layout.content;
        let max_width = content
            .width
            .saturating_sub(crate::agent_sidebar::CONTENT_MIN_COLS);
        let width = match self.side {
            config::SidebarSide::Left => column.saturating_sub(content.x).saturating_add(1),
            config::SidebarSide::Right => content.right().saturating_sub(column),
        };
        self.width = width.clamp(
            config::SIDEBAR_WIDTH_MIN,
            config::SIDEBAR_WIDTH_MAX.min(max_width.max(config::SIDEBAR_WIDTH_MIN)),
        );
    }

    fn set_sessions_percent_from_row(&mut self, row: u16) {
        let Some(dock) = self.layout.dock else {
            return;
        };
        let body_height = dock.height.saturating_sub(DOCK_HEADER_ROWS);
        let lower_sections =
            u16::from(self.layout.queue.is_some()) + u16::from(self.layout.plan.is_some());
        let separator_count = lower_sections;
        let section_space = body_height.saturating_sub(separator_count);
        if section_space == 0 {
            return;
        }
        let sessions_height = row
            .saturating_sub(dock.y)
            .saturating_sub(DOCK_HEADER_ROWS)
            .clamp(
                DOCK_MIN_SECTION_ROWS,
                section_space.saturating_sub(DOCK_MIN_SECTION_ROWS.saturating_mul(lower_sections)),
            );
        self.sessions_percent =
            ((u32::from(sessions_height) * 100) / u32::from(section_space)) as u16;
        self.sessions_percent = self.sessions_percent.clamp(
            config::SIDEBAR_SESSIONS_PERCENT_MIN,
            config::SIDEBAR_SESSIONS_PERCENT_MAX,
        );
    }

    fn set_queue_percent_from_row(&mut self, row: u16) {
        let (Some(queue), Some(plan)) = (self.layout.queue, self.layout.plan) else {
            return;
        };
        let section_space = queue.height.saturating_add(plan.height);
        if section_space == 0 {
            return;
        }
        let queue_height = row.saturating_sub(queue.y).clamp(
            DOCK_MIN_SECTION_ROWS,
            section_space.saturating_sub(DOCK_MIN_SECTION_ROWS),
        );
        self.queue_percent = ((u32::from(queue_height) * 100) / u32::from(section_space)) as u16;
        self.queue_percent = self.queue_percent.clamp(
            config::SIDEBAR_QUEUE_PERCENT_MIN,
            config::SIDEBAR_QUEUE_PERCENT_MAX,
        );
    }

    fn handle_mouse(&mut self, mouse: &crossterm::event::MouseEvent) -> (bool, Option<DockAction>) {
        if let Some(capture) = self.capture {
            match mouse.kind {
                MouseEventKind::Drag(MouseButton::Left) => {
                    match capture {
                        DockCapture::Width => self.set_width_from_column(mouse.column),
                        DockCapture::SessionsHeight => {
                            self.set_sessions_percent_from_row(mouse.row)
                        }
                        DockCapture::QueuePlanHeight => self.set_queue_percent_from_row(mouse.row),
                    }
                    return (true, None);
                }
                MouseEventKind::Up(MouseButton::Left) => {
                    match capture {
                        DockCapture::Width => self.set_width_from_column(mouse.column),
                        DockCapture::SessionsHeight => {
                            self.set_sessions_percent_from_row(mouse.row)
                        }
                        DockCapture::QueuePlanHeight => self.set_queue_percent_from_row(mouse.row),
                    }
                    let action = match capture {
                        DockCapture::Width => DockAction::PersistWidth(self.width),
                        DockCapture::SessionsHeight => {
                            DockAction::PersistSessionsPercent(self.sessions_percent)
                        }
                        DockCapture::QueuePlanHeight => {
                            DockAction::PersistQueuePercent(self.queue_percent)
                        }
                    };
                    self.capture = None;
                    return (true, Some(action));
                }
                _ => return (true, None),
            }
        }

        if let MouseEventKind::Down(MouseButton::Left) = mouse.kind {
            for index in 0..3 {
                if mouse::in_rect(mouse.column, mouse.row, self.layout.toggles[index])
                    || mouse::in_rect(mouse.column, mouse.row, self.layout.close[index])
                {
                    return (true, Some(self.toggle_section(index)));
                }
            }
            if mouse::in_rect(mouse.column, mouse.row, self.layout.side_switch) {
                self.side = self.side.opposite();
                return (true, Some(DockAction::SwitchSide));
            }
            if mouse::in_rect(mouse.column, mouse.row, self.layout.width_edge) {
                self.capture = Some(DockCapture::Width);
                self.set_width_from_column(mouse.column);
                return (true, None);
            }
            if mouse::in_rect(mouse.column, mouse.row, self.layout.divider) {
                self.capture = Some(DockCapture::SessionsHeight);
                self.set_sessions_percent_from_row(mouse.row);
                return (true, None);
            }
            if mouse::in_rect(mouse.column, mouse.row, self.layout.plan_divider) {
                self.capture = Some(DockCapture::QueuePlanHeight);
                self.set_queue_percent_from_row(mouse.row);
                return (true, None);
            }
        }
        let in_dock = self
            .layout
            .dock
            .is_some_and(|rect| mouse::in_rect(mouse.column, mouse.row, rect));
        let in_sessions = self
            .layout
            .sessions
            .is_some_and(|rect| mouse::in_rect(mouse.column, mouse.row, rect));
        let in_plan = self
            .layout
            .plan
            .is_some_and(|rect| mouse::in_rect(mouse.column, mouse.row, rect));
        let in_queue = self
            .layout
            .queue
            .is_some_and(|rect| mouse::in_rect(mouse.column, mouse.row, rect));
        if in_dock && !in_sessions && !in_queue && !in_plan {
            return (true, None);
        }
        (false, None)
    }
}

fn set_dock_plan_visible(
    dock: &mut ConversationDock,
    mode: Mode,
    chat: &mut chat::Chat,
    acp: &mut acp::Acp,
    visible: bool,
) -> DockAction {
    dock.plan_visible = visible;
    dock.clear_capture();
    match mode {
        Mode::Chat => chat.set_plan_visible(visible),
        Mode::Acp => acp.set_plan_visible(visible),
        _ => {}
    }
    DockAction::TogglePlan
}

fn handle_dock_mouse(
    dock: &mut ConversationDock,
    mode: Mode,
    chat: &mut chat::Chat,
    acp: &mut acp::Acp,
    mouse: &crossterm::event::MouseEvent,
) -> (bool, Option<DockAction>) {
    let pane_visible = match mode {
        Mode::Chat => chat.current_session_id().is_none() || chat.plan_visible(),
        Mode::Acp => acp.current_session_id().is_none() || acp.plan_visible(),
        _ => false,
    };
    // Without an active pane, toggle the saved preference on its own.
    let plan_was_visible = dock.plan_visible && pane_visible;
    let result = dock.handle_mouse(mouse);
    if result.1 == Some(DockAction::TogglePlan) {
        set_dock_plan_visible(dock, mode, chat, acp, !plan_was_visible);
    }
    result
}

fn apply_dock_plan_key_request(
    dock: &mut ConversationDock,
    mode: Mode,
    chat: &mut chat::Chat,
    acp: &mut acp::Acp,
) -> Option<DockAction> {
    let (requested, pane_visible) = match mode {
        Mode::Chat => (
            chat.take_plan_toggle_request(),
            chat.current_session_id().is_none() || chat.plan_visible(),
        ),
        Mode::Acp => (
            acp.take_plan_toggle_request(),
            acp.current_session_id().is_none() || acp.plan_visible(),
        ),
        _ => return None,
    };
    requested.then(|| {
        let visible = !(dock.plan_visible && pane_visible);
        set_dock_plan_visible(dock, mode, chat, acp, visible)
    })
}

fn persist_dock_action(dock: &ConversationDock, action: DockAction) -> anyhow::Result<bool> {
    match action {
        DockAction::ToggleSessions => {
            config::persist_sidebar_visible(&dock.config_dir, dock.sessions_visible)
        }
        DockAction::ToggleQueue => {
            config::persist_sidebar_queue_visible(&dock.config_dir, dock.queue_visible)
        }
        DockAction::TogglePlan => {
            config::persist_sidebar_plan_visible(&dock.config_dir, dock.plan_visible)
        }
        DockAction::SwitchSide => config::persist_sidebar_side(&dock.config_dir, dock.side),
        DockAction::PersistWidth(width) => config::persist_sidebar_width(&dock.config_dir, width),
        DockAction::PersistSessionsPercent(percent) => {
            config::persist_sidebar_sessions_percent(&dock.config_dir, percent)
        }
        DockAction::PersistQueuePercent(percent) => {
            config::persist_sidebar_queue_percent(&dock.config_dir, percent)
        }
    }
}

fn dock_save_message(action: DockAction, result: anyhow::Result<bool>) -> Option<String> {
    let setting = crate::i18n::t(match action {
        DockAction::ToggleSessions => "zc-dock-setting-sessions",
        DockAction::ToggleQueue => "zc-dock-toggle-queue",
        DockAction::TogglePlan => "zc-dock-toggle-plan",
        DockAction::SwitchSide => "zc-dock-setting-side",
        DockAction::PersistWidth(_) => "zc-dock-setting-width",
        DockAction::PersistSessionsPercent(_) | DockAction::PersistQueuePercent(_) => {
            "zc-dock-setting-split"
        }
    });
    match result {
        Ok(false) => None,
        Ok(true) => Some(crate::i18n::t_args(
            "zc-dock-save-env-shadow",
            &[("setting", &setting)],
        )),
        Err(error) => Some(crate::i18n::t_args(
            "zc-dock-save-failed",
            &[("setting", &setting), ("error", &error.to_string())],
        )),
    }
}

/// One connection operation owned by the app loop.
///
/// Connection work must not block input processing. The handle is awaited only
/// after Tokio reports it finished, and dropping an unfinished attempt aborts
/// the transport task.
struct ReconnectAttempt<T> {
    handle: Option<tokio::task::JoinHandle<Result<T>>>,
}

impl<T> ReconnectAttempt<T> {
    fn from_handle(handle: tokio::task::JoinHandle<Result<T>>) -> Self {
        Self {
            handle: Some(handle),
        }
    }

    fn is_finished(&self) -> bool {
        self.handle
            .as_ref()
            .is_some_and(tokio::task::JoinHandle::is_finished)
    }

    async fn try_take(&mut self) -> Option<Result<T>> {
        if !self.is_finished() {
            return None;
        }
        let handle = self.handle.take()?;
        Some(match handle.await {
            Ok(result) => result,
            Err(error) => Err(anyhow::Error::msg(format!(
                "connection task failed: {error}"
            ))),
        })
    }
}

impl ReconnectAttempt<(RpcClient, crate::ActiveLeg)> {
    fn start(
        target: crate::ConnectTarget,
        prev_id: Option<String>,
        prev_sig: Option<String>,
    ) -> Self {
        Self::from_handle(tokio::spawn(async move {
            target
                .connect(prev_id.as_deref(), prev_sig.as_deref())
                .await
        }))
    }
}

impl ReconnectAttempt<RpcClient> {
    fn start_direct(
        route: crate::WssRoute,
        prev_id: Option<String>,
        prev_sig: Option<String>,
    ) -> Self {
        Self::from_handle(tokio::spawn(async move {
            route
                .connect_direct(prev_id.as_deref(), prev_sig.as_deref())
                .await
        }))
    }
}

impl<T> Drop for ReconnectAttempt<T> {
    fn drop(&mut self) {
        if let Some(handle) = self.handle.take()
            && !handle.is_finished()
        {
            handle.abort();
        }
    }
}

/// Pending Quickstart chat transition.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PendingQuickstartChat {
    /// Open the created agent after the daemon reconnects.
    AfterReconnect(String),
    /// Open the created agent on the current live connection.
    Immediate(String),
}

/// State that must survive a reconnect — used by Quickstart's
/// Stage-2 flow to route the user into the freshly-created agent's
/// chat after the daemon comes back up.
#[derive(Debug, Default)]
pub struct CrossReconnectState {
    /// The single pending handoff target for Quickstart-created agents.
    pub pending_quickstart_chat: Option<PendingQuickstartChat>,
}

pub type SharedReconnectState = Arc<Mutex<CrossReconnectState>>;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum QuickstartChatDrain {
    Immediate,
    AfterReconnect,
}

#[derive(Debug, Clone)]
struct PostPollDispatchState(ConnectionState);

impl PostPollDispatchState {
    fn new(connection_state: ConnectionState) -> Self {
        Self(connection_state)
    }

    fn rpc_allowed(&self) -> bool {
        !matches!(self.0, ConnectionState::Disconnected { .. })
    }

    async fn run_rpc_dispatch<F, Fut, T>(&self, dispatch: F) -> Option<T>
    where
        F: FnOnce() -> Fut,
        Fut: std::future::Future<Output = T>,
    {
        if self.rpc_allowed() {
            Some(dispatch().await)
        } else {
            None
        }
    }
}

/// Project cached session state only while the daemon connection is
/// authoritative. A disconnect keeps session state available for reconnection,
/// but externally visible terminal state must become neutral instead of
/// advertising a cached working or blocked turn indefinitely.
fn terminal_status_for_connection<'a>(
    connection: &ConnectionState,
    sessions: impl IntoIterator<Item = (Option<&'a crate::turn_status::TurnStatus>, Option<&'a str>)>,
) -> (Option<&'a crate::turn_status::TurnStatus>, Option<&'a str>) {
    if matches!(connection, ConnectionState::Disconnected { .. }) {
        (None, None)
    } else {
        crate::osc_status::most_urgent(sessions)
    }
}

/// How often the UI redraws when no input arrives (for live panes).
const TICK: Duration = Duration::from_millis(200);
/// Slice of the input wait between checks for pending transport events.
/// Bounds live-update latency and the redraw rate (~60 fps) while sessions
/// stream, without spinning when nothing arrives.
const TRANSPORT_WAKE_SLICE: Duration = Duration::from_millis(16);
const CHROME_STATUS_POLL_INTERVAL: Duration = Duration::from_secs(5);
const MAX_COALESCED_MOUSE_DRAGS: usize = 64;
const ELICITATION_ROUTE_GRACE: Duration = Duration::from_secs(2);

/// The sole subscriber and responder for daemon-initiated JSON-RPC requests.
/// Pane ownership is resolved here before a request is exposed to a chat pane,
/// preventing a non-owner pane from racing the real owner with a cancellation.
struct InboundRequestRouter {
    rpc: Arc<RpcClient>,
    rx: mpsc::UnboundedReceiver<crate::client::RpcInboundRequest>,
    deferred: Vec<DeferredInboundRequest>,
}

struct DeferredInboundRequest {
    request: crate::client::RpcInboundRequest,
    first_seen: Instant,
}

impl InboundRequestRouter {
    fn new(rpc: Arc<RpcClient>) -> Result<Self> {
        Ok(Self {
            rx: rpc.take_inbound_requests()?,
            rpc,
            deferred: Vec::new(),
        })
    }

    fn drain(&mut self, chat_pane: &mut chat::Chat, acp_pane: &mut acp::Acp) {
        while let Ok(request) = self.rx.try_recv() {
            if let Some(request) = self.route(request, chat_pane, acp_pane) {
                self.deferred.push(DeferredInboundRequest {
                    request,
                    first_seen: Instant::now(),
                });
            }
        }

        let pending = std::mem::take(&mut self.deferred);
        for deferred in pending {
            let expired = deferred.first_seen.elapsed() >= ELICITATION_ROUTE_GRACE;
            match self.route(deferred.request, chat_pane, acp_pane) {
                None => {}
                Some(request) if expired => {
                    chat::Chat::answer_cancel(&self.rpc, request.id);
                }
                Some(request) => self.deferred.push(DeferredInboundRequest {
                    request,
                    first_seen: deferred.first_seen,
                }),
            }
        }
    }

    /// Resolve every response-bearing request still owned by this router
    /// before its transport is replaced. Quiescing the reader closes the sole
    /// production sender before the final drain, while the writer remains
    /// available for one terminal response to every accepted request.
    async fn cancel_pending(&mut self) -> bool {
        self.rpc.quiesce_inbound_reader().await;
        let mut pending = self
            .deferred
            .drain(..)
            .map(|deferred| deferred.request)
            .collect::<Vec<_>>();
        while let Some(request) = self.rx.recv().await {
            pending.push(request);
        }
        let responses = pending
            .into_iter()
            .map(crate::client::terminal_inbound_response)
            .collect();
        self.rpc.respond_to_inbound_requests(responses);
        self.rpc.flush_outbound().await
    }

    /// Return the request only when no pane owns its session yet. The caller
    /// keeps that genuinely orphaned request for the bounded grace period.
    fn route(
        &self,
        request: crate::client::RpcInboundRequest,
        chat_pane: &mut chat::Chat,
        acp_pane: &mut acp::Acp,
    ) -> Option<crate::client::RpcInboundRequest> {
        if request.method != "elicitation/create" {
            let method_name = request.method.clone();
            let request_id = request.id;
            self.rpc.respond_to_inbound_request(
                request_id,
                Err(crate::jsonrpc::JsonRpcError {
                    code: crate::jsonrpc::error_codes::METHOD_NOT_FOUND,
                    message: format!("Method not found: {method_name}"),
                    data: None,
                }),
            );
            return None;
        }

        let Some(session_id) =
            serde_json::from_value::<crate::wire::ElicitationRequestParams>(request.params.clone())
                .ok()
                .map(|params| params.session_id)
        else {
            chat::Chat::answer_cancel(&self.rpc, request.id);
            return None;
        };
        let chat_owns = chat_pane.owns_session(&session_id);
        let acp_owns = acp_pane.owns_session(&session_id);

        let routed = match (chat_owns, acp_owns) {
            (true, false) => chat_pane.try_install_elicitation(request),
            (false, true) => acp_pane.try_install_elicitation(request),
            (false, false) => return Some(request),
            (true, true) => {
                // Session ids are globally unique. Ambiguous ownership is a
                // protocol/state invariant violation; answer once and make it
                // visible instead of letting two panes race the request.
                chat_pane.note_elicitation_drop();
                acp_pane.note_elicitation_drop();
                chat::Chat::answer_cancel(&self.rpc, request.id);
                return None;
            }
        };

        match routed {
            chat::ElicitationRouting::Installed => None,
            chat::ElicitationRouting::Unparseable(id) => {
                chat::Chat::answer_cancel(&self.rpc, id);
                None
            }
            chat::ElicitationRouting::Defer(request) => Some(request),
        }
    }
}
const SGR_MOUSE_SEQUENCE_TIMEOUT: Duration = Duration::from_millis(50);
const MAX_SGR_MOUSE_SEQUENCE_EVENTS: usize = 32;

/// Reassembles SGR mouse sequences that crossterm exposed as individual key
/// events after an input read split the sequence at the escape byte.
///
/// A complete sequence is converted back into the same `MouseEvent` that
/// crossterm would have produced. Invalid or incomplete sequences are replayed
/// in order, so ordinary Escape-prefixed keyboard input is not discarded.
#[derive(Debug, Default)]
struct SgrMouseEventDecoder {
    pending: VecDeque<Event>,
    candidate: Vec<Event>,
    candidate_started_at: Option<Instant>,
}

impl SgrMouseEventDecoder {
    fn feed(&mut self, event: Event) {
        let output = if self.candidate.is_empty() {
            if is_sgr_mouse_start(&event) {
                self.candidate.push(event);
                self.candidate_started_at = Some(Instant::now());
                Vec::new()
            } else {
                vec![event]
            }
        } else {
            self.candidate.push(event);
            self.decode_candidate()
        };
        self.pending.extend(output);
    }

    fn next(&mut self) -> Option<Event> {
        self.pending.pop_front()
    }

    fn push_front(&mut self, event: Event) {
        self.pending.push_front(event);
    }

    fn poll_timeout(&self) -> Duration {
        self.candidate_started_at
            .map(|started| SGR_MOUSE_SEQUENCE_TIMEOUT.saturating_sub(started.elapsed()))
            .unwrap_or(TICK)
    }

    fn flush_candidate(&mut self) -> bool {
        if self.candidate.is_empty() {
            return false;
        }
        self.pending.extend(self.candidate.drain(..));
        self.candidate_started_at = None;
        true
    }

    fn flush_timed_out_candidate(&mut self) -> bool {
        let timed_out = self
            .candidate_started_at
            .is_some_and(|started| started.elapsed() >= SGR_MOUSE_SEQUENCE_TIMEOUT);
        timed_out && self.flush_candidate()
    }

    fn read_ready_with<F>(&mut self, mut read_event: F) -> Result<Option<Event>>
    where
        F: FnMut() -> Result<Option<Event>>,
    {
        loop {
            if let Some(event) = self.next() {
                return Ok(Some(event));
            }
            let Some(event) = read_event()? else {
                return Ok(None);
            };
            self.feed(event);
        }
    }

    fn decode_candidate(&mut self) -> Vec<Event> {
        if self.candidate.len() > MAX_SGR_MOUSE_SEQUENCE_EVENTS {
            return self.replay_candidate();
        }

        let Some(chars) = self.candidate[1..]
            .iter()
            .map(key_event_char)
            .collect::<Option<Vec<_>>>()
        else {
            return self.replay_candidate();
        };

        let prefix = ['[', '<'];
        for (index, expected) in prefix.iter().enumerate() {
            let Some(actual) = chars.get(index) else {
                return Vec::new();
            };
            if actual != expected {
                return self.replay_candidate();
            }
        }

        let Some(final_char) = chars.last().copied() else {
            return Vec::new();
        };
        if !matches!(final_char, 'M' | 'm') {
            if chars[2..]
                .iter()
                .all(|character| character.is_ascii_digit() || *character == ';')
            {
                return Vec::new();
            }
            return self.replay_candidate();
        }

        let Some(mouse) = parse_sgr_mouse(&chars) else {
            return self.replay_candidate();
        };
        self.candidate.clear();
        self.candidate_started_at = None;
        vec![Event::Mouse(mouse)]
    }

    fn replay_candidate(&mut self) -> Vec<Event> {
        self.candidate_started_at = None;
        std::mem::take(&mut self.candidate)
    }
}

fn is_sgr_mouse_start(event: &Event) -> bool {
    matches!(
        event,
        Event::Key(key)
            if key.code == KeyCode::Esc // keyguard: recognize terminal protocol escape, not an app chord
                && key.kind == KeyEventKind::Press
                && key.modifiers == KeyModifiers::NONE
    )
}

fn key_event_char(event: &Event) -> Option<char> {
    match event {
        Event::Key(KeyEvent {
            code: KeyCode::Char(character), // keyguard: extract terminal protocol byte
            kind: KeyEventKind::Press,
            ..
        }) => Some(*character),
        _ => None,
    }
}

fn parse_sgr_mouse(chars: &[char]) -> Option<MouseEvent> {
    let final_char = *chars.last()?;
    let payload: String = chars[2..chars.len().checked_sub(1)?].iter().collect();
    let payload = payload.strip_suffix(';').unwrap_or(payload.as_str());
    let fields: Vec<_> = payload.split(';').collect();
    if fields.len() != 3 || fields.iter().any(|field| field.is_empty()) {
        return None;
    }
    let cb = fields[0].parse::<u8>().ok()?;
    let column = fields[1].parse::<u16>().ok()?;
    let row = fields[2].parse::<u16>().ok()?;
    if column == 0 || row == 0 {
        return None;
    }

    let (mut kind, modifiers) = parse_sgr_mouse_button(cb)?;
    if final_char == 'm'
        && let MouseEventKind::Down(button) = kind
    {
        kind = MouseEventKind::Up(button);
    }

    Some(MouseEvent {
        kind,
        column: column - 1,
        row: row - 1,
        modifiers,
    })
}

fn parse_sgr_mouse_button(cb: u8) -> Option<(MouseEventKind, KeyModifiers)> {
    let button_number = (cb & 0b0000_0011) | ((cb & 0b1100_0000) >> 4);
    let dragging = cb & 0b0010_0000 == 0b0010_0000;
    let kind = match (button_number, dragging) {
        (0, false) => MouseEventKind::Down(MouseButton::Left),
        (1, false) => MouseEventKind::Down(MouseButton::Middle),
        (2, false) => MouseEventKind::Down(MouseButton::Right),
        (0, true) => MouseEventKind::Drag(MouseButton::Left),
        (1, true) => MouseEventKind::Drag(MouseButton::Middle),
        (2, true) => MouseEventKind::Drag(MouseButton::Right),
        (3, false) => MouseEventKind::Up(MouseButton::Left),
        (3, true) | (4, true) | (5, true) => MouseEventKind::Moved,
        (4, false) => MouseEventKind::ScrollUp,
        (5, false) => MouseEventKind::ScrollDown,
        (6, false) => MouseEventKind::ScrollLeft,
        (7, false) => MouseEventKind::ScrollRight,
        _ => return None,
    };

    let mut modifiers = KeyModifiers::NONE;
    if cb & 0b0000_0100 != 0 {
        modifiers |= KeyModifiers::SHIFT;
    }
    if cb & 0b0000_1000 != 0 {
        modifiers |= KeyModifiers::ALT;
    }
    if cb & 0b0001_0000 != 0 {
        modifiers |= KeyModifiers::CONTROL;
    }
    Some((kind, modifiers))
}

/// Returns whether an application-level confirmation modal owns an input event.
///
/// Confirmation dialogs sit above every pane and intentionally consume paste
/// events so text or file paths cannot mutate a hidden composer.
fn confirmation_modal_owns_event(event: &Event, reload_confirm: bool, quit_confirm: bool) -> bool {
    matches!(event, Event::Paste(_)) && (reload_confirm || quit_confirm)
}

fn mouse_drag_button(event: &Event) -> Option<crossterm::event::MouseButton> {
    match event {
        Event::Mouse(mouse) => match mouse.kind {
            MouseEventKind::Drag(button) => Some(button),
            _ => None,
        },
        _ => None,
    }
}

fn coalesce_mouse_drag<F>(mut current: Event, mut read_queued: F) -> Result<(Event, Option<Event>)>
where
    F: FnMut() -> Result<Option<Event>>,
{
    let Some(button) = mouse_drag_button(&current) else {
        return Ok((current, None));
    };

    let mut coalesced = 1;
    while coalesced < MAX_COALESCED_MOUSE_DRAGS {
        let Some(next) = read_queued()? else {
            return Ok((current, None));
        };
        if mouse_drag_button(&next) == Some(button) {
            current = next;
            coalesced += 1;
        } else {
            return Ok((current, Some(next)));
        }
    }
    Ok((current, None))
}

fn poll_input_event_and_snapshot<P, R, S>(
    input_decoder: &mut SgrMouseEventDecoder,
    mut poll: P,
    mut read: R,
    connection_state: S,
) -> Result<(Option<Event>, PostPollDispatchState)>
where
    P: FnMut(Duration) -> Result<bool>,
    R: FnMut() -> Result<Event>,
    S: FnOnce() -> ConnectionState,
{
    let input_event = loop {
        if let Some(event) = input_decoder.next() {
            break Some(event);
        }

        if !poll(input_decoder.poll_timeout())? {
            if input_decoder.flush_timed_out_candidate() {
                continue;
            }
            break None;
        }
        input_decoder.feed(read()?);
    };

    let input_event = match input_event {
        Some(input_event) => {
            let (input_event, next_pending) = coalesce_mouse_drag(input_event, || {
                input_decoder.read_ready_with(|| {
                    if poll(Duration::ZERO)? {
                        Ok(Some(read()?))
                    } else {
                        Ok(None)
                    }
                })
            })?;
            if let Some(next_pending) = next_pending {
                input_decoder.push_front(next_pending);
            }
            Some(input_event)
        }
        None => None,
    };

    Ok((input_event, PostPollDispatchState::new(connection_state())))
}

/// Wait up to `timeout` for terminal input, returning early (as a timeout)
/// once transport events are pending so the loop redraws them.
///
/// Input is always polled for at least one slice first: events that arrived
/// during the previous draw must not make the loop redraw back-to-back.
fn poll_input_or_transport<P, T>(
    timeout: Duration,
    slice: Duration,
    mut poll: P,
    mut transport_pending: T,
) -> Result<bool>
where
    P: FnMut(Duration) -> Result<bool>,
    T: FnMut() -> bool,
{
    let deadline = Instant::now() + timeout;
    loop {
        let remaining = deadline.saturating_duration_since(Instant::now());
        if poll(remaining.min(slice))? {
            return Ok(true);
        }
        if remaining <= slice || transport_pending() {
            return Ok(false);
        }
    }
}

/// Ephemeral interaction state for the keybinding overlay. Keybinding
/// metadata itself stays in the action/help registry and is resolved on draw.
#[derive(Debug, Default)]
struct HelpOverlayState {
    query: String,
    scroll: usize,
}

impl HelpOverlayState {
    /// Handle a key while the overlay has focus. Returns `true` when it
    /// should close.
    fn handle_key(&mut self, key: &KeyEvent) -> bool {
        match SearchBoxAction::from_chord(key) {
            Some(SearchBoxAction::Cancel) if self.query.is_empty() => return true,
            Some(SearchBoxAction::Cancel) => {
                self.query.clear();
                self.scroll = 0;
            }
            Some(SearchBoxAction::Backspace) => {
                self.query.pop();
                self.scroll = 0;
            }
            Some(SearchBoxAction::Up) => {
                self.scroll = self.scroll.saturating_sub(1);
            }
            Some(SearchBoxAction::Down) => {
                self.scroll = self.scroll.saturating_add(1);
            }
            Some(SearchBoxAction::Accept) => {}
            None => {
                if let KeyCode::Char(c) = key.code
                    && !key.modifiers.contains(KeyModifiers::CONTROL)
                {
                    self.query.push(c);
                    self.scroll = 0;
                }
            }
        }
        false
    }
}

/// Mode bar entries. Shared between drawing and click detection.
const MODES: &[Mode] = &[
    Mode::Dashboard,
    Mode::Config,
    Mode::Acp,
    Mode::Chat,
    Mode::Logs,
    Mode::Doctor,
    Mode::Quickstart,
    Mode::Sop,
];

// ── Mode enum ────────────────────────────────────────────────────

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub(crate) enum Mode {
    Dashboard,
    Config,
    Doctor,
    Acp, // displayed as "Code" in the UI
    Chat,
    Logs,
    Quickstart,
    Sop,
}

/// Draw the app's frame rows around pane content. Notices remain owned by the
/// focused ChatState; this frame only resolves the active pane's current notice.
pub(crate) fn draw_app_frame(
    frame: &mut ratatui::Frame,
    mode: Mode,
    chat_pane: &mut chat::Chat,
    acp_pane: &mut acp::Acp,
    draw_body: impl FnOnce(&mut ratatui::Frame, [Rect; 3], &mut chat::Chat, &mut acp::Acp),
) {
    if let Some(style) = theme::backdrop_style() {
        frame.render_widget(
            ratatui::widgets::Block::default().style(style),
            frame.area(),
        );
    }
    let info_message = match mode {
        Mode::Chat => chat_pane.info_message().cloned(),
        Mode::Acp => acp_pane.info_message().cloned(),
        _ => None,
    };
    let has_info = info_message.is_some();
    let constraints: Vec<Constraint> = if has_info {
        vec![
            Constraint::Length(1), // mode bar
            Constraint::Min(0),    // content
            Constraint::Length(1), // info bar
            Constraint::Length(1), // status bar
        ]
    } else {
        vec![
            Constraint::Length(1), // mode bar
            Constraint::Min(0),    // content
            Constraint::Length(1), // status bar
        ]
    };
    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints(constraints)
        .split(frame.area());
    let status_idx = if has_info { 3 } else { 2 };
    draw_body(
        frame,
        [chunks[0], chunks[1], chunks[status_idx]],
        chat_pane,
        acp_pane,
    );
    if has_info {
        let info_area = chunks[2];
        let bar = crate::widgets::InfoBar::new(info_message.as_ref());
        if let Some(widget) = bar.widget(info_area.width as usize) {
            frame.render_widget(widget, info_area);
        }
    }
}

#[derive(Debug, Clone)]
struct ModeBarEntry {
    mode: Mode,
    title: String,
    hit_rect: Rect,
}

/// Exact geometry produced for the most recently rendered mode bar.
///
/// Drawing and mouse dispatch both consume this value, so a clipped or hidden
/// tab can never retain a larger synthetic click target.
#[derive(Debug, Clone, Default)]
struct ModeBarLayout {
    tab_area: Rect,
    summary_area: Option<Rect>,
    entries: Vec<ModeBarEntry>,
}

impl ModeBarLayout {
    fn mode_at(&self, column: u16, row: u16) -> Option<Mode> {
        if self
            .summary_area
            .is_some_and(|area| mouse::in_rect(column, row, area))
            || !mouse::in_rect(column, row, self.tab_area)
        {
            return None;
        }
        self.entries
            .iter()
            .find(|entry| mouse::in_rect(column, row, entry.hit_rect))
            .map(|entry| entry.mode)
    }
}

#[derive(Default)]
struct ChromeStatus {
    status: Option<StatusResult>,
    health: Option<serde_json::Value>,
    last_poll: Option<Instant>,
    refresh_in_flight: bool,
    refresh_rx: Option<mpsc::UnboundedReceiver<ChromeStatusSnapshot>>,
}

struct ChromeStatusSnapshot {
    status: Option<StatusResult>,
    health: Option<serde_json::Value>,
}

impl ChromeStatus {
    fn tick(&mut self, rpc: &Arc<RpcClient>) {
        self.drain_completed_refresh();
        let due = self
            .last_poll
            .map(|t| t.elapsed() >= CHROME_STATUS_POLL_INTERVAL)
            .unwrap_or(true);
        if due && !self.refresh_in_flight {
            self.start_poll(rpc);
        }
    }

    fn start_poll(&mut self, rpc: &Arc<RpcClient>) {
        self.last_poll = Some(Instant::now());
        self.refresh_in_flight = true;
        let (tx, rx) = mpsc::unbounded_channel();
        self.refresh_rx = Some(rx);
        let rpc = Arc::clone(rpc);
        tokio::spawn(async move {
            let status = rpc.status().await.ok();
            let health = rpc.health().await.ok();
            let _ = tx.send(ChromeStatusSnapshot { status, health });
        });
    }

    fn drain_completed_refresh(&mut self) {
        let Some(rx) = self.refresh_rx.as_mut() else {
            return;
        };

        match rx.try_recv() {
            Ok(snapshot) => {
                if let Some(status) = snapshot.status {
                    self.status = Some(status);
                }
                // A failed poll must not keep an old healthy result visible.
                self.health = snapshot.health;
                self.refresh_in_flight = false;
                self.refresh_rx = None;
            }
            Err(mpsc::error::TryRecvError::Empty) => {}
            Err(mpsc::error::TryRecvError::Disconnected) => {
                self.refresh_in_flight = false;
                self.refresh_rx = None;
            }
        }
    }

    fn clear(&mut self) {
        self.status = None;
        self.health = None;
        self.last_poll = None;
        self.refresh_in_flight = false;
        self.refresh_rx = None;
    }

    fn summary_line(&self) -> Option<Line<'static>> {
        let status = self.status.as_ref()?;
        let mut text = format!(
            " v{} {}:{}",
            status.server_version,
            crate::i18n::t("zc-chrome-summary-sessions"),
            status.active_sessions
        );
        text.push_str(&process_stats_summary(self.health.as_ref()));
        text.push(' ');
        Some(Line::from(Span::styled(text, theme::dim_style())))
    }
}

impl Mode {
    fn fluent_key(self) -> &'static str {
        match self {
            Mode::Dashboard => "zc-pane-dashboard",
            Mode::Config => "zc-pane-config",
            Mode::Doctor => "zc-pane-doctor",
            Mode::Acp => "zc-pane-code",
            Mode::Chat => "zc-pane-chat",
            Mode::Logs => "zc-pane-logs",
            Mode::Quickstart => "zc-pane-quickstart",
            Mode::Sop => "zc-pane-sop",
        }
    }

    fn cycle(self, offset: isize) -> Mode {
        let len = MODES.len() as isize;
        // Defensive for future modes outside the nav bar.
        let Some(cur) = MODES.iter().position(|m| *m == self) else {
            return if offset >= 0 {
                MODES[0]
            } else {
                MODES[MODES.len() - 1]
            };
        };
        let next = ((cur as isize + offset).rem_euclid(len)) as usize;
        MODES[next]
    }
}

async fn switch_mode(
    mode: &mut Mode,
    next: Mode,
    dispatch_state: &PostPollDispatchState,
    dashboard_pane: &mut dashboard::Dashboard,
    quickstart: &mut quickstart_pane::QuickstartPane,
    acp_pane: &mut acp::Acp,
    chat_pane: &mut chat::Chat,
    sop_pane: &mut sop_pane::SopPane,
) {
    if *mode == Mode::Dashboard && next != Mode::Dashboard {
        dashboard_pane.on_pane_blur();
    }
    if *mode == Mode::Quickstart && next != Mode::Quickstart && dispatch_state.rpc_allowed() {
        quickstart.dismiss_beacon();
    }
    if *mode == Mode::Sop && next != Mode::Sop {
        sop_pane.on_pane_blur();
    }
    if *mode == Mode::Chat && next != Mode::Chat {
        chat_pane.on_pane_blur();
    }
    if dispatch_state.rpc_allowed() {
        match next {
            Mode::Acp => acp_pane.refresh_if_inactive().await,
            Mode::Chat => chat_pane.start_entry_retry(),
            Mode::Sop => sop_pane.refresh(),
            _ => {}
        }
    }
    *mode = next;
}

fn remember_quickstart_return(current: Mode, next: Mode, return_mode: &mut Mode) {
    if next == Mode::Quickstart && current != Mode::Quickstart {
        *return_mode = current;
    }
}

fn take_pending_quickstart_chat(
    reconnect_state: &SharedReconnectState,
    drain: QuickstartChatDrain,
) -> Option<String> {
    let Ok(mut guard) = reconnect_state.lock() else {
        return None;
    };
    let pending = guard.pending_quickstart_chat.take()?;
    match (drain, pending) {
        (QuickstartChatDrain::Immediate, PendingQuickstartChat::Immediate(alias))
        | (QuickstartChatDrain::AfterReconnect, PendingQuickstartChat::AfterReconnect(alias)) => {
            Some(alias)
        }
        (_, other) => {
            guard.pending_quickstart_chat = Some(other);
            None
        }
    }
}

async fn consume_pending_quickstart_chat(
    dispatch_state: &PostPollDispatchState,
    reconnect_state: &SharedReconnectState,
    mode: &mut Mode,
    chat_pane: &mut chat::Chat,
) {
    if !dispatch_state.rpc_allowed() {
        return;
    }
    let Some(alias) = take_pending_quickstart_chat(reconnect_state, QuickstartChatDrain::Immediate)
    else {
        return;
    };
    chat_pane.focus_agent(&alias).await;
    *mode = Mode::Chat;
}

/// Grace period before respawning an owned ephemeral daemon whose
/// process still looks alive. An in-place daemon reload rebinds the
/// socket within a couple of seconds, so a disconnect with a live
/// daemon process usually means a reload is in flight — respawning
/// immediately would race it for the socket endpoint.
const EPHEMERAL_RESPAWN_GRACE: Duration = Duration::from_secs(10);

fn should_respawn_ephemeral(
    owned_pid: Option<u32>,
    already_respawned: bool,
    disconnected_for: Duration,
    pid_alive: impl Fn(u32) -> bool,
) -> bool {
    let Some(pid) = owned_pid else {
        return false;
    };
    if already_respawned {
        return false;
    }
    !pid_alive(pid) || disconnected_for >= EPHEMERAL_RESPAWN_GRACE
}

pub(crate) fn reconnect_matches_owned_daemon(
    owned_pid: Option<u32>,
    pending_respawn_pid: Option<u32>,
    server_pid: Option<u32>,
) -> bool {
    pending_respawn_pid
        .or(owned_pid)
        .is_none_or(|expected_pid| server_pid == Some(expected_pid))
}

fn record_automatic_respawn_failure(
    owned_daemon_pid: &mut Option<u32>,
    needs_intervention: &mut bool,
) {
    // The original owned process is already dead and the one automatic
    // replacement has definitively failed. Release the stale identity gate so
    // a compatible manual restart can be adopted by the polling loop.
    *owned_daemon_pid = None;
    *needs_intervention = true;
}

/// Probe whether the owned daemon process still exists. `kill(pid, 0)`
/// succeeds (or fails with EPERM) while the process is alive.
#[cfg(unix)]
fn ephemeral_daemon_pid_alive(pid: u32) -> bool {
    let result = unsafe { libc::kill(pid as libc::pid_t, 0) };
    result == 0 || std::io::Error::last_os_error().raw_os_error() == Some(libc::EPERM)
}

/// Windows has no cheap liveness probe wired up here; report alive so
/// the grace period governs respawn instead of a spurious kill result.
#[cfg(not(unix))]
fn ephemeral_daemon_pid_alive(_pid: u32) -> bool {
    true
}

// ── Top-level entry point ────────────────────────────────────────

/// Run the TUI event loop. Owns the full session lifecycle: when the
/// daemon disconnects it reconnects in-loop (keeping the cached UI alive
/// and responsive) and rebuilds its panes against the recovered client.
/// Returns when the user quits.
#[allow(clippy::too_many_arguments)]
pub async fn run(
    rpc: Arc<RpcClient>,
    term: &mut config_manager::Term,
    connect_label: &str,
    insecure_tls: bool,
    reconnect_state: SharedReconnectState,
    config_dir: &std::path::Path,
    target: &crate::ConnectTarget,
    mut owned_daemon_pid: Option<u32>,
    initial_leg: crate::ActiveLeg,
) -> Result<()> {
    let mut mode = Mode::Dashboard;
    theme::set_agent_overrides(resolve_agent_overrides(config_dir));
    let mut help_overlay: Option<HelpOverlayState> = None;
    let mut reload_confirm = false;
    let mut quit_confirm = false;
    let mut reload_status: Option<String> = None;
    let mut mode_bar_layout = ModeBarLayout::default();
    let mut content_area = Rect::default();
    let mut sidebar = crate::agent_sidebar::AgentSidebar::new();
    let mut dock = ConversationDock::from_config_dir(config_dir);
    // Where Esc from the (sidebar-launched) Quickstart wizard returns to.
    let mut quickstart_return = Mode::Dashboard;
    let mut reconnect_last_attempt: Option<std::time::Instant> = None;
    let mut reconnect_attempt: Option<ReconnectAttempt<(RpcClient, crate::ActiveLeg)>> = None;
    let mut ephemeral_respawn_done = false;
    let mut needs_intervention = false;
    let mut disconnected_at: Option<Instant> = None;
    let mut pending_respawn: Option<crate::SpawnedDaemon> = None;

    // Which transport leg the live connection sits on, and when the direct path
    // was last re-probed. While on the relay leg of a route that also has a
    // direct address, the loop periodically retries direct and migrates back.
    let mut active_leg = initial_leg;
    let mut reprobe_last_attempt: Option<std::time::Instant> = None;
    let mut direct_reprobe_attempt: Option<ReconnectAttempt<RpcClient>> = None;

    // The live client handle. Reassigned in place on a successful
    // reconnect so every rebuilt pane talks to the recovered daemon.
    let mut rpc = rpc;

    macro_rules! build_panes {
        ($resume_chat:expr, $resume_acp:expr) => {
            async {
                let mut dashboard_pane =
                    dashboard::Dashboard::new(rpc.clone(), connect_label, insecure_tls);
                dashboard_pane.init().await?;
                let mut config_app = config_manager::App::new(rpc.clone(), config_dir);
                config_app.init().await?;
                let doctor_pane = doctor::Doctor::new(rpc.clone());
                let mut acp_pane = acp::Acp::new(rpc.clone());
                // Carry the pre-disconnect sessions across a reconnect rebuild
                // so the rebuilt pane reattaches every daemon-retained session
                // (focused + sidebar backgrounds) instead of minting a fresh
                // one. Empty on first build.
                acp_pane.set_resume_sessions($resume_acp);
                acp_pane.init().await?;
                let mut chat_pane = chat::Chat::new(rpc.clone(), chat::PaneKind::Chat);
                chat_pane.set_resume_sessions($resume_chat);
                chat_pane.init().await?;
                let pending_start_chat = take_pending_quickstart_chat(
                    &reconnect_state,
                    QuickstartChatDrain::AfterReconnect,
                );
                let mut logs_pane = logs::Logs::new(rpc.clone());
                logs_pane.init().await?;
                let mut quickstart =
                    quickstart_pane::QuickstartPane::new(rpc.clone(), Arc::clone(&reconnect_state));
                quickstart.init().await?;
                let sop_pane = sop_pane::SopPane::new(rpc.clone());
                if let Some(alias) = pending_start_chat {
                    chat_pane.focus_agent(&alias).await;
                    mode = Mode::Chat;
                }
                anyhow::Ok((
                    dashboard_pane,
                    config_app,
                    doctor_pane,
                    acp_pane,
                    chat_pane,
                    logs_pane,
                    quickstart,
                    sop_pane,
                ))
            }
            .await
        };
    }

    // Subscribe before pane initialization. A reconnect can resume a live
    // daemon turn, so an elicitation may arrive while the panes are still
    // reattaching and must already have one app-level receiver waiting.
    let mut inbound_router = InboundRequestRouter::new(rpc.clone())?;
    let (
        mut dashboard_pane,
        mut config_app,
        mut doctor_pane,
        mut acp_pane,
        mut chat_pane,
        mut logs_pane,
        mut quickstart,
        mut sop_pane,
    ) = build_panes!(Vec::new(), Vec::new())?;

    // Route one sidebar event: switch to the owning pane's mode and call
    // into it. A macro (like `build_panes!`) because the routing needs the
    // same pile of `&mut` locals. Session-touching events are gated on a
    // live connection; the Quickstart launcher works offline like the mode
    // bar always has.
    macro_rules! apply_sidebar_event {
        ($event:expr, $dispatch_state:expr) => {{
            let connected = $dispatch_state.rpc_allowed();
            match $event {
                crate::agent_sidebar::SidebarEvent::FocusSession { pane, session_id }
                    if connected =>
                {
                    let next = match pane {
                        chat::PaneKind::Chat => Mode::Chat,
                        chat::PaneKind::Acp => Mode::Acp,
                    };
                    switch_mode(
                        &mut mode,
                        next,
                        &$dispatch_state,
                        &mut dashboard_pane,
                        &mut quickstart,
                        &mut acp_pane,
                        &mut chat_pane,
                        &mut sop_pane,
                    )
                    .await;
                    match pane {
                        chat::PaneKind::Chat => {
                            chat_pane.focus_session(&session_id).await;
                        }
                        chat::PaneKind::Acp => {
                            acp_pane.focus_session(&session_id).await;
                        }
                    }
                }
                crate::agent_sidebar::SidebarEvent::CloseSession { pane, session_id }
                    if connected =>
                {
                    // The pane keeps the row until the daemon acknowledges the
                    // close. The daemon cancels and fences an in-flight turn
                    // before removing the live session; durable history stays.
                    match pane {
                        chat::PaneKind::Chat => {
                            chat_pane.close_session(&session_id).await;
                        }
                        chat::PaneKind::Acp => {
                            acp_pane.close_session(&session_id).await;
                        }
                    }
                }
                crate::agent_sidebar::SidebarEvent::OpenPicker if connected => {
                    // The picker adds to the pane you're in; other modes
                    // default to Chat.
                    let target = if mode == Mode::Acp {
                        chat::PaneKind::Acp
                    } else {
                        chat::PaneKind::Chat
                    };
                    let summaries = match target {
                        chat::PaneKind::Chat => chat_pane.session_summaries(),
                        chat::PaneKind::Acp => acp_pane.session_summaries(),
                    };
                    let open_aliases = summaries.into_iter().map(|s| s.agent_alias).collect();
                    sidebar.open_picker(target, open_aliases, &rpc);
                }
                crate::agent_sidebar::SidebarEvent::PickAgent { pane, alias } if connected => {
                    let next = match pane {
                        chat::PaneKind::Chat => Mode::Chat,
                        chat::PaneKind::Acp => Mode::Acp,
                    };
                    switch_mode(
                        &mut mode,
                        next,
                        &$dispatch_state,
                        &mut dashboard_pane,
                        &mut quickstart,
                        &mut acp_pane,
                        &mut chat_pane,
                        &mut sop_pane,
                    )
                    .await;
                    match pane {
                        chat::PaneKind::Chat => {
                            chat_pane.add_agent_session(&alias).await;
                        }
                        chat::PaneKind::Acp => {
                            acp_pane.add_agent_session(&alias).await;
                        }
                    }
                }
                crate::agent_sidebar::SidebarEvent::OpenQuickstart if mode != Mode::Quickstart => {
                    remember_quickstart_return(mode, Mode::Quickstart, &mut quickstart_return);
                    switch_mode(
                        &mut mode,
                        Mode::Quickstart,
                        &$dispatch_state,
                        &mut dashboard_pane,
                        &mut quickstart,
                        &mut acp_pane,
                        &mut chat_pane,
                        &mut sop_pane,
                    )
                    .await;
                }
                _ => {}
            }
        }};
    }
    let mut chrome_status = ChromeStatus::default();
    chrome_status.tick(&rpc);
    let mut input_decoder = SgrMouseEventDecoder::default();

    // Adopt a freshly-connected client: rebuild every pane against it (a kept
    // pane would still hold the dead client's notification receiver) while
    // carrying the live sessions + agent aliases across the rebuild. Evaluates to
    // `true` when the rebuild succeeded, `false` when the daemon flapped mid-init
    // (the caller stays in its current state and retries). Shared by the
    // disconnect-recovery path and the relay->direct re-probe migration.
    macro_rules! adopt_client {
        ($new_client:expr) => {{
            // Transactional: `rpc` and the panes must always describe the SAME
            // connection. The new client has to be installed first because the
            // panes are built against it, so a failed rebuild puts the previous
            // one back rather than leaving a live `rpc` beside panes that still
            // hold the old, possibly dead, connection.
            let previous = Arc::clone(&rpc);
            rpc = Arc::new($new_client);
            match InboundRequestRouter::new(rpc.clone()) {
                Ok(mut next_inbound_router) => {
                    let resume_chat = chat_pane.resume_entries();
                    let resume_acp = acp_pane.resume_entries();
                    match build_panes!(resume_chat, resume_acp) {
                        Ok(mut panes) => {
                            refresh_visible_sop_after_reconnect(mode, &mut panes.7).await;
                            // Resume snapshots are read-only. Commit the old
                            // panes' transport-bound interaction cleanup only
                            // after every replacement pane built, so a mid-build
                            // failure cannot consume queues or retry state.
                            chat_pane.commit_reconnect_handoff();
                            acp_pane.commit_reconnect_handoff();
                            let previous_flushed = inbound_router.cancel_pending().await;
                            // Assigned as one tuple: every pane the builder
                            // produces is adopted, and a later pane addition
                            // cannot stay bound to the old client silently.
                            (
                                dashboard_pane,
                                config_app,
                                doctor_pane,
                                acp_pane,
                                chat_pane,
                                logs_pane,
                                quickstart,
                                sop_pane,
                            ) = panes;
                            inbound_router = next_inbound_router;
                            // No pane holds the replaced connection any more.
                            if previous_flushed {
                                previous.shutdown();
                            } else {
                                previous.retire_after_outbound_flush();
                            }
                            true
                        }
                        Err(_) => {
                            let abandoned_flushed = next_inbound_router.cancel_pending().await;
                            let abandoned = std::mem::replace(&mut rpc, previous);
                            if abandoned_flushed {
                                abandoned.shutdown();
                            } else {
                                abandoned.retire_after_outbound_flush();
                            }
                            false
                        }
                    }
                }
                Err(_) => {
                    let abandoned = std::mem::replace(&mut rpc, previous);
                    abandoned.shutdown();
                    false
                }
            }
        }};
    }

    loop {
        // Synchronous terminal polls and ready RPC futures can keep this loop
        // running without yielding to the outer shutdown-signal selector.
        tokio::task::yield_now().await;

        // Draw
        let conn_state = rpc.connection_state();
        if matches!(conn_state, ConnectionState::Disconnected { .. }) {
            chrome_status.clear();
            // The picker's agent list would be stale by reconnect time.
            sidebar.close_picker();
            dashboard_pane.invalidate_daemon_data();
        } else {
            chrome_status.tick(&rpc);
            sidebar.drain_picker_fetch();
        }
        config_app.tick_application_status(
            mode == Mode::Config && !matches!(conn_state, ConnectionState::Disconnected { .. }),
        );
        inbound_router.drain(&mut chat_pane, &mut acp_pane);
        acp_pane.tick_transport_events();
        chat_pane.tick_transport_events();
        let chrome_summary = chrome_status.summary_line();
        doctor_pane.poll_refresh().await;
        if mode == Mode::Doctor && !matches!(conn_state, ConnectionState::Disconnected { .. }) {
            doctor_pane.refresh_if_inactive();
        }
        let base_theme = theme::active_raw();
        let frame_theme = match mode {
            Mode::Acp => acp_pane.selected_agent().and_then(theme::agent_override),
            Mode::Chat => chat_pane.selected_agent().and_then(theme::agent_override),
            _ => None,
        };
        if let Some(t) = frame_theme {
            theme::set_active(t);
        }

        // Sidebar rows: Code group first, then Chat, matching the mode bar
        // order. Derived fresh each frame — the panes own the state.
        let mut sidebar_rows = acp_pane.session_summaries();
        sidebar_rows.extend(chat_pane.session_summaries());
        let plan_visible = match mode {
            Mode::Acp => acp_pane.plan_visible(),
            Mode::Chat => chat_pane.plan_visible(),
            _ => false,
        };
        let sidebar_ctx = crate::agent_sidebar::SidebarCtx {
            active_pane: match mode {
                Mode::Acp => Some(chat::PaneKind::Acp),
                Mode::Chat => Some(chat::PaneKind::Chat),
                _ => None,
            },
            quickstart_active: mode == Mode::Quickstart,
            connected: !matches!(conn_state, ConnectionState::Disconnected { .. }),
        };

        // Report whichever session most wants the operator, not whichever is
        // visible: the terminal status exists to be read from outside this
        // window, so it has to answer "does anything here need me?". Emitted
        // before `term.draw` so the OSC write never lands inside a frame.
        let mut terminal_candidates = chat_pane.terminal_statuses();
        terminal_candidates.extend(acp_pane.terminal_statuses());
        let (terminal_status, terminal_agent) = terminal_status_for_connection(
            &conn_state,
            terminal_candidates
                .iter()
                .map(|(status, agent)| (Some(status), Some(agent.as_str()))),
        );
        crate::osc_status::sync(terminal_status, terminal_agent);

        term.draw(|frame| {
            draw_app_frame(
                frame,
                mode,
                &mut chat_pane,
                &mut acp_pane,
                |frame, chunks, chat_pane, acp_pane| {
                    mode_bar_layout =
                        draw_mode_bar(frame, chunks[0], mode, chrome_summary.as_ref());
                    // The dock shares the content row; the mode,
                    // info, and status bars stay full-width. Panes render into (and
                    // hit-test against) the remaining `content_area` untouched.
                    let dock_layout = dock.layout(chunks[1], mode, plan_visible);
                    content_area = dock_layout.conversation;
                    dock.draw_shell(frame);
                    if let Some(sidebar_area) = dock_layout.sessions {
                        sidebar.draw(frame, sidebar_area, &sidebar_rows, &sidebar_ctx);
                    } else {
                        sidebar.clear_geometry();
                    }

                    match mode {
                        Mode::Dashboard => dashboard_pane.draw(
                            frame,
                            content_area,
                            chrome_status.status.as_ref(),
                            chrome_status.health.as_ref(),
                            acp_pane.current_cwd(),
                            chat_pane.current_cwd(),
                            acp_pane.focused_runtime_context(),
                            chat_pane.focused_runtime_context(),
                            &terminal_candidates,
                        ),
                        Mode::Config => config_app.draw_into(frame, content_area),
                        Mode::Doctor => doctor_pane.draw(frame, content_area),
                        Mode::Acp => acp_pane.draw_with_dock(
                            frame,
                            content_area,
                            dock_layout.queue,
                            dock_layout.plan,
                        ),
                        Mode::Chat => chat_pane.draw_with_dock(
                            frame,
                            content_area,
                            dock_layout.queue,
                            dock_layout.plan,
                        ),
                        Mode::Logs => logs_pane.draw(frame, content_area),
                        Mode::Quickstart => quickstart.draw(frame, content_area),
                        Mode::Sop => sop_pane.render(frame, content_area),
                    }

                    dock.draw_resize_handles(frame);
                    match mode {
                        Mode::Acp => acp_pane.draw_dock_overlay(frame),
                        Mode::Chat => chat_pane.draw_dock_overlay(frame),
                        _ => {}
                    }
                    let (ctx_input, ctx_input_source, ctx_max, ctx_model_window) = match mode {
                        Mode::Chat => chat_pane.ctx_tokens(),
                        Mode::Acp => acp_pane.ctx_tokens(),
                        _ => (None, None, None, None),
                    };
                    let browse_mode = match mode {
                        Mode::Chat => chat_pane.in_browse_mode(),
                        Mode::Acp => acp_pane.in_browse_mode(),
                        _ => false,
                    };
                    draw_status_bar(
                        frame,
                        chunks[2],
                        &conn_state,
                        rpc.tui_id(),
                        CtxBar::new(ctx_input, ctx_input_source, ctx_max, ctx_model_window),
                        needs_intervention,
                        browse_mode,
                    );
                },
            );

            // Sidebar "+" picker modal: above the panes, below the help and
            // confirm overlays.
            sidebar.draw_picker(frame, frame.area());

            // Help modal overlay (drawn last so it sits on top).
            if let Some(state) = help_overlay.as_mut() {
                let mut node = HelpNode::entries(global_help_entries());
                let pane_node = match mode {
                    Mode::Dashboard => dashboard_pane.help_context(),
                    Mode::Config => config_app.help_context(),
                    Mode::Doctor => doctor_pane.help_context(),
                    Mode::Acp => acp_pane.help_context(),
                    Mode::Chat => chat_pane.help_context(),
                    Mode::Logs => logs_pane.help_context(),
                    Mode::Quickstart => quickstart.help_context(),
                    Mode::Sop => sop_pane.help_context(),
                };
                node.children.push(pane_node);
                draw_help_modal(frame, frame.area(), &node, state);
            }

            if reload_confirm {
                draw_reload_confirm_modal(frame, frame.area());
            }
            if quit_confirm {
                draw_quit_confirm_modal(frame, frame.area());
            }
            if let Some(msg) = &reload_status {
                draw_reload_status_toast(frame, frame.area(), msg);
            }
        })?;

        // Restore the base palette so the override never leaks into the next
        // frame, a different pane, or live theme changes from the Config pane.
        if frame_theme.is_some() {
            theme::set_active(base_theme);
        }

        // Recovery stays inside the responsive event loop. During each disconnected
        // episode an owned ephemeral daemon is respawned at most once — only once the
        // process is confirmed dead or the reload grace period elapses — attached
        // daemons are never spawned, and both modes keep polling for manual recovery.
        if matches!(rpc.connection_state(), ConnectionState::Disconnected { .. }) {
            // A direct-path probe belongs to the relay session that started it.
            // Do not retain a candidate across a disconnect or transport change.
            direct_reprobe_attempt = None;
            if let Some(daemon) = pending_respawn.as_mut() {
                match daemon.has_exited() {
                    Ok(false) => {}
                    Ok(true) | Err(_) => {
                        pending_respawn = None;
                        record_automatic_respawn_failure(
                            &mut owned_daemon_pid,
                            &mut needs_intervention,
                        );
                    }
                }
            }
            let since = *disconnected_at.get_or_insert_with(Instant::now);
            // Transport loss terminates ownership of active-turn clipboard
            // temporaries without touching the composer or queued messages, so
            // the cached pane stays live for reconnect.
            chat_pane.cleanup_active_turn_on_disconnect();
            if should_respawn_ephemeral(
                owned_daemon_pid,
                ephemeral_respawn_done,
                since.elapsed(),
                ephemeral_daemon_pid_alive,
            ) {
                ephemeral_respawn_done = true;
                if let crate::ConnectTarget::LocalSocket(socket) = target {
                    match crate::spawn_owned_ephemeral_daemon(config_dir, socket) {
                        Ok(daemon) => pending_respawn = Some(daemon),
                        Err(_) => record_automatic_respawn_failure(
                            &mut owned_daemon_pid,
                            &mut needs_intervention,
                        ),
                    }
                }
            }

            {
                let now = std::time::Instant::now();
                let due = reconnect_last_attempt
                    .map(|t| now.duration_since(t) >= Duration::from_secs(1))
                    .unwrap_or(true);
                if reconnect_attempt.is_none() && due {
                    reconnect_last_attempt = Some(now);
                    // Reclaim the same TUI identity so the daemon restores
                    // our UID via HMAC signature verification.
                    let prev_id = rpc.tui_id().map(String::from);
                    let prev_sig = rpc.tui_sig().map(String::from);
                    reconnect_attempt =
                        Some(ReconnectAttempt::start(target.clone(), prev_id, prev_sig));
                }

                let reconnect_result = match reconnect_attempt.as_mut() {
                    Some(attempt) => attempt.try_take().await,
                    None => None,
                };
                if let Some(result) = reconnect_result {
                    reconnect_attempt = None;
                    // The connect prefers the direct path and falls back to the
                    // relay, so a reconnect lands on whichever leg is reachable.
                    if let Ok((new_client, leg)) = result {
                        let pending_respawn_pid =
                            pending_respawn.as_ref().map(crate::SpawnedDaemon::id);
                        if !reconnect_matches_owned_daemon(
                            owned_daemon_pid,
                            pending_respawn_pid,
                            new_client.server_pid,
                        ) {
                            new_client.shutdown();
                            if pending_respawn_pid.is_none() {
                                needs_intervention = true;
                            }
                            continue;
                        }
                        // A reconnect may land on a DIFFERENT leg than the one
                        // that dropped: direct can fall back to the relay, and a
                        // relay session can come back direct. The leg is
                        // committed only once the panes run on that client.
                        let adopted = adopt_client!(new_client);
                        active_leg = leg_after_adoption(adopted, active_leg, leg);
                        if adopted {
                            chrome_status.clear();
                            chrome_status.tick(&rpc);
                            reconnect_last_attempt = None;
                            ephemeral_respawn_done = false;
                            needs_intervention = false;
                            disconnected_at = None;
                            if let Some(daemon) = pending_respawn.take() {
                                owned_daemon_pid = Some(daemon.id());
                                daemon.detach();
                            }
                        }
                        // Adopted or not, go round again: a failed rebuild means
                        // the daemon flapped mid-init, and the previous client is
                        // back in place for the next throttle window.
                        continue;
                    } else if owned_daemon_pid.is_some() && ephemeral_respawn_done {
                        // The one permitted respawn did not come back — flag
                        // for the user. We keep polling above, so a manual
                        // daemon restart still recovers.
                        needs_intervention = true;
                    }
                }
            }
        }

        // Migrate back to the direct path once it becomes reachable again. Only
        // runs while live on the relay leg of a route that also has a direct
        // address; a successful probe adopts the direct client and rebuilds the
        // panes against it. The probe is throttled and short-timeout, so the
        // event loop keeps drawing between attempts.
        let direct_reprobe_allowed = matches!(rpc.connection_state(), ConnectionState::Connected)
            && active_leg == crate::ActiveLeg::WssRelay
            && matches!(
                target,
                crate::ConnectTarget::Wss(route)
                    if route.reprobe_secs > 0 && route.direct_url.is_some()
            );
        if !direct_reprobe_allowed {
            direct_reprobe_attempt = None;
        }
        if direct_reprobe_allowed && let crate::ConnectTarget::Wss(route) = target {
            let now = std::time::Instant::now();
            let due = reprobe_last_attempt
                .map(|t| now.duration_since(t) >= Duration::from_secs(route.reprobe_secs))
                .unwrap_or(true);
            if direct_reprobe_attempt.is_none() && due {
                reprobe_last_attempt = Some(now);
                let prev_id = rpc.tui_id().map(String::from);
                let prev_sig = rpc.tui_sig().map(String::from);
                direct_reprobe_attempt = Some(ReconnectAttempt::start_direct(
                    route.as_ref().clone(),
                    prev_id,
                    prev_sig,
                ));
            }
            let direct_result = match direct_reprobe_attempt.as_mut() {
                Some(attempt) => attempt.try_take().await,
                None => None,
            };
            if let Some(result) = direct_result {
                direct_reprobe_attempt = None;
                if let Ok(direct) = result {
                    // Committed after the rebuild, not before: a probe that
                    // connects but cannot be adopted leaves the session on the
                    // relay, and claiming the direct leg there would stop the
                    // re-probe that is still the only way back.
                    let adopted = adopt_client!(direct);
                    active_leg =
                        leg_after_adoption(adopted, active_leg, crate::ActiveLeg::WssDirect);
                    continue;
                }
            }
        }

        // The frame snapshot predates terminal polling and can become stale
        // while the loop waits. Capture one fresh state only after sequence
        // assembly and drag coalescing finish, or after a genuine timeout.
        let (input_event, dispatch_state) = poll_input_event_and_snapshot(
            &mut input_decoder,
            |timeout| {
                poll_input_or_transport(
                    timeout,
                    TRANSPORT_WAKE_SLICE,
                    |slice| Ok(event::poll(slice)?),
                    || {
                        chat_pane.has_pending_transport_events()
                            || acp_pane.has_pending_transport_events()
                    },
                )
            },
            || Ok(event::read()?),
            || rpc.connection_state(),
        )?;

        let Some(input_event) = input_event else {
            dispatch_state
                .run_rpc_dispatch(|| async {
                    if mode == Mode::Dashboard {
                        dashboard_pane.tick().await;
                    }
                    if mode == Mode::Logs {
                        logs_pane.tick().await;
                    }
                    if mode == Mode::Quickstart {
                        quickstart.tick().await;
                    }
                    if mode == Mode::Sop {
                        sop_pane.tick();
                    }
                    consume_pending_quickstart_chat(
                        &dispatch_state,
                        &reconnect_state,
                        &mut mode,
                        &mut chat_pane,
                    )
                    .await;
                })
                .await;
            continue;
        };

        if confirmation_modal_owns_event(&input_event, reload_confirm, quit_confirm) {
            // The visible confirmation modal is the authoritative input
            // owner; discard paste instead of forwarding it underneath.
            continue;
        }

        match input_event {
            Event::Key(key) => {
                dock.clear_capture();
                sidebar.cancel_drag();
                if key.kind == KeyEventKind::Release {
                    continue;
                }

                let in_text_input = match mode {
                    Mode::Dashboard => dashboard_pane.wants_text_input(),
                    Mode::Config => config_app.wants_text_input(),
                    Mode::Doctor => doctor_pane.wants_text_input(),
                    Mode::Acp => acp_pane.wants_text_input(),
                    Mode::Chat => chat_pane.wants_text_input(),
                    Mode::Logs => logs_pane.wants_text_input(),
                    Mode::Quickstart => quickstart.wants_text_input(),
                    Mode::Sop => sop_pane.wants_text_input(),
                };
                let global = GlobalAction::from_chord(&key);

                // Quit-confirm modal. The first exit chord closes any open
                // transient widgets and arms the modal; a second exit chord —
                // or an explicit confirm — actually quits. Cancel dismisses.
                if quit_confirm {
                    match ModalAction::from_chord(&key) {
                        Some(ModalAction::Confirm) => break,
                        Some(ModalAction::Cancel) => {
                            quit_confirm = false;
                        }
                        _ => {
                            if global == Some(GlobalAction::Quit) {
                                break;
                            }
                        }
                    }
                    continue;
                }

                // Retained selected text can still be copied after a network
                // failure. This path cannot issue RPCs or clear the draft.
                if copy_disconnected_composer(
                    &dispatch_state,
                    reload_confirm || help_overlay.is_some() || sidebar.picker_open(),
                    mode,
                    &mut chat_pane,
                    &mut acp_pane,
                    &key,
                ) {
                    continue;
                }

                let pane_wants_quit_chord = global == Some(GlobalAction::Quit)
                    && match mode {
                        Mode::Chat => chat_pane.wants_quit_chord(&key),
                        Mode::Acp => acp_pane.wants_quit_chord(&key),
                        _ => false,
                    };
                if global == Some(GlobalAction::Quit)
                    && should_handle_global_quit(&dispatch_state, pane_wants_quit_chord)
                {
                    // First Ctrl+C: clear input bar text, clear transient
                    // state (browse mode, overlay, …) and arm the confirm modal.
                    match mode {
                        Mode::Chat => {
                            chat_pane.exit_browse_mode();
                            chat_pane.clear_input();
                        }
                        Mode::Acp => {
                            acp_pane.exit_browse_mode();
                            acp_pane.clear_input();
                        }
                        _ => {}
                    }
                    help_overlay = None;
                    reload_confirm = false;
                    reload_status = None;
                    sidebar.close_picker();
                    quit_confirm = true;
                    continue;
                }

                // Reload-daemon confirmation modal — intercepts all keys
                // while open. Mirrors the web dashboard's
                // `ReloadDaemonButton` confirm flow.
                if reload_confirm {
                    match ModalAction::from_chord(&key) {
                        Some(ModalAction::Confirm) => {
                            reload_confirm = false;
                            if let Some(status) = dispatch_state
                                .run_rpc_dispatch(|| async {
                                    match rpc.config_reload().await {
                                        Ok(_) => crate::i18n::t("zc-app-reload-status-signalled"),
                                        Err(e) => format!("Reload requested ({e})"),
                                    }
                                })
                                .await
                            {
                                reload_status = Some(status);
                            }
                        }
                        Some(ModalAction::Cancel) => {
                            reload_confirm = false;
                        }
                        _ => {}
                    }
                    continue;
                }

                // Any pending reload-status toast clears on the next key.
                if reload_status.is_some() {
                    reload_status = None;
                }

                if global == Some(GlobalAction::ReloadDaemon) && !in_text_input {
                    reload_confirm = true;
                    continue;
                }

                // The help overlay owns keyboard focus while open. Its opening
                // chord toggles it closed; Esc clears a filter before closing.
                if let Some(state) = help_overlay.as_mut() {
                    if global == Some(GlobalAction::Help) || state.handle_key(&key) {
                        help_overlay = None;
                    }
                    continue;
                }

                // Sidebar visibility toggle: a modified chord, so it stays
                // live inside text inputs like the pane-nav chords.
                if global == Some(GlobalAction::ToggleSidebar) {
                    let action = dock.toggle_section(0);
                    if !dock.sessions_visible {
                        sidebar.close_picker();
                    }
                    reload_status = dock_save_message(action, persist_dock_action(&dock, action));
                    continue;
                }

                // The "+" picker owns keys while open.
                if sidebar.picker_open() {
                    if let Some(event) = sidebar.handle_picker_key(&key) {
                        apply_sidebar_event!(event, dispatch_state);
                    }
                    continue;
                }

                if let Some(ordinal) = session_shortcut_ordinal(global) {
                    let pane_claims_shortcut = match mode {
                        Mode::Dashboard => {
                            crate::keymap::DashboardTabAction::from_chord(&key).is_some()
                                || SearchBoxAction::from_chord(&key).is_some()
                                || crate::keymap::ConfigEditorAction::from_chord(&key).is_some()
                        }
                        Mode::Config => config_app.claims_session_shortcut(&key),
                        Mode::Doctor => crate::keymap::DoctorTabAction::from_chord(&key).is_some(),
                        Mode::Acp => acp_pane.claims_session_shortcut(&key),
                        Mode::Chat => chat_pane.claims_session_shortcut(&key),
                        Mode::Logs => {
                            crate::keymap::LogsTabAction::from_chord(&key).is_some()
                                || SearchBoxAction::from_chord(&key).is_some()
                        }
                        Mode::Quickstart => {
                            crate::keymap::QuickstartTabAction::from_chord(&key).is_some()
                                || crate::keymap::QuickstartModalAction::from_chord(&key).is_some()
                        }
                        Mode::Sop => {
                            crate::keymap::SopTabAction::from_chord(&key).is_some()
                                || crate::keymap::SopEditorAction::from_chord(&key).is_some()
                        }
                    };
                    if session_shortcut_is_available(mode, in_text_input, pane_claims_shortcut) {
                        let sessions = session_summaries_in_sidebar_order(
                            &sidebar,
                            acp_pane.session_summaries(),
                            chat_pane.session_summaries(),
                        );
                        if let Some(event) = session_shortcut_event(ordinal, &sessions) {
                            apply_sidebar_event!(event, dispatch_state);
                        }
                        continue;
                    }
                }

                let editor_claims_pane_navigation = matches!(
                    global,
                    Some(GlobalAction::PaneNavLeft | GlobalAction::PaneNavRight)
                ) && match mode {
                    Mode::Config => config_app.claims_pane_navigation(&key),
                    Mode::Acp => acp_pane.claims_pane_navigation(&key),
                    Mode::Chat => chat_pane.claims_pane_navigation(&key),
                    Mode::Sop => sop_pane.claims_pane_navigation(&key),
                    _ => false,
                };
                // Disconnected panes are skipped below to avoid dead-socket RPCs,
                // so a retained editor cannot consume its local cursor chord.
                let pane_can_receive_editor_chord = dispatch_state.rpc_allowed();
                let switch_to = pane_switch_delta(
                    global,
                    editor_claims_pane_navigation,
                    pane_can_receive_editor_chord,
                )
                .map(|delta| mode.cycle(delta));
                if let Some(next) = switch_to {
                    remember_quickstart_return(mode, next, &mut quickstart_return);
                    switch_mode(
                        &mut mode,
                        next,
                        &dispatch_state,
                        &mut dashboard_pane,
                        &mut quickstart,
                        &mut acp_pane,
                        &mut chat_pane,
                        &mut sop_pane,
                    )
                    .await;
                    continue;
                }

                if global == Some(GlobalAction::Help)
                    && (!in_text_input || crate::keymap::help_bypasses_text_input(&key))
                {
                    help_overlay = Some(HelpOverlayState::default());
                    continue;
                }

                let Some(quit) = dispatch_state
                    .run_rpc_dispatch(|| async {
                        anyhow::Ok(match mode {
                            Mode::Dashboard => dashboard_pane.handle_key(key).await,
                            Mode::Config => config_app.handle_key(key, term).await?,
                            Mode::Doctor => doctor_pane.handle_key(key).await,
                            Mode::Acp => acp_pane.handle_key(key, term).await,
                            Mode::Chat => chat_pane.handle_key(key, term).await,
                            Mode::Logs => logs_pane.handle_key(key).await,
                            Mode::Quickstart => quickstart.handle_key(key).await,
                            Mode::Sop => sop_pane.handle_key(key).await,
                        })
                    })
                    .await
                else {
                    continue;
                };
                let quit = quit?;
                if quit {
                    break;
                }
                if let Some(action) =
                    apply_dock_plan_key_request(&mut dock, mode, &mut chat_pane, &mut acp_pane)
                {
                    reload_status = dock_save_message(action, persist_dock_action(&dock, action));
                }
                match mode {
                    Mode::Acp if acp_pane.take_help_request() => {
                        help_overlay = Some(HelpOverlayState::default());
                    }
                    Mode::Chat if chat_pane.take_help_request() => {
                        help_overlay = Some(HelpOverlayState::default());
                    }
                    _ => {}
                }
                // Ctrl+N is the keyboard form of the sidebar `[+]`. Routing it
                // through the same event keeps the picker, the session cap, the
                // cancellation/error handling and the remote-Code directory
                // selection on one path instead of two.
                let add_session_requested = match mode {
                    Mode::Acp => acp_pane.take_add_session_request(),
                    Mode::Chat => chat_pane.take_add_session_request(),
                    _ => false,
                };
                if add_session_requested {
                    apply_sidebar_event!(
                        crate::agent_sidebar::SidebarEvent::OpenPicker,
                        dispatch_state
                    );
                }
                if mode == Mode::Quickstart && quickstart.take_leave_request() {
                    // Return to wherever the sidebar launched the wizard from
                    // (sanitized: never back into the wizard itself).
                    let back = if quickstart_return == Mode::Quickstart {
                        Mode::Dashboard
                    } else {
                        quickstart_return
                    };
                    switch_mode(
                        &mut mode,
                        back,
                        &dispatch_state,
                        &mut dashboard_pane,
                        &mut quickstart,
                        &mut acp_pane,
                        &mut chat_pane,
                        &mut sop_pane,
                    )
                    .await;
                }
                consume_pending_quickstart_chat(
                    &dispatch_state,
                    &reconnect_state,
                    &mut mode,
                    &mut chat_pane,
                )
                .await;
            }
            Event::Mouse(mouse) => {
                if let Some(state) = help_overlay.as_mut() {
                    sidebar.cancel_drag();
                    match mouse.kind {
                        MouseEventKind::ScrollUp => {
                            state.scroll = state.scroll.saturating_sub(3);
                        }
                        MouseEventKind::ScrollDown => {
                            state.scroll = state.scroll.saturating_add(3);
                        }
                        MouseEventKind::Down(_) => {
                            help_overlay = None;
                        }
                        _ => {}
                    }
                    continue;
                }
                // The sidebar picker owns all mouse input while open. Handle
                // it before mode-bar/help dispatch so confirming the captured
                // target can never yank the user back from a tab they clicked
                // behind the modal.
                if sidebar.picker_open() {
                    if let Some(event) = sidebar.handle_mouse(&mouse) {
                        apply_sidebar_event!(event, dispatch_state);
                    }
                    continue;
                }
                // Context menus keep their existing modal precedence over dock controls.
                let menu_open = match mode {
                    Mode::Acp => acp_pane.context_menu_open(),
                    Mode::Chat => chat_pane.context_menu_open(),
                    _ => false,
                };
                let menu_consumed = dispatch_state
                    .run_rpc_dispatch(|| async {
                        match mode {
                            Mode::Acp => acp_pane.handle_context_menu_mouse(mouse).await,
                            Mode::Chat => chat_pane.handle_context_menu_mouse(mouse).await,
                            _ => false,
                        }
                    })
                    .await
                    .unwrap_or(menu_open);
                if menu_consumed {
                    dock.clear_capture();
                    sidebar.cancel_drag();
                    continue;
                }
                // A row drag owns its release, including over another dock
                // section or the transcript. Do not start another gesture there.
                if sidebar.captures_mouse(&mouse) {
                    route_agent_sidebar_mouse(
                        mode,
                        &mut chat_pane,
                        &mut acp_pane,
                        &mut sidebar,
                        &mouse,
                    );
                    continue;
                }
                let (dock_consumed, dock_action) =
                    handle_dock_mouse(&mut dock, mode, &mut chat_pane, &mut acp_pane, &mouse);
                if dock_consumed {
                    match mode {
                        Mode::Chat => chat_pane.finish_transcript_drag_if_released(&mouse),
                        Mode::Acp => acp_pane.finish_transcript_drag_if_released(&mouse),
                        _ => {}
                    }
                    if let Some(action) = dock_action {
                        if !dock.sessions_visible {
                            sidebar.close_picker();
                        }
                        reload_status =
                            dock_save_message(action, persist_dock_action(&dock, action));
                    }
                    continue;
                }
                if matches!(mouse.kind, MouseEventKind::Down(_))
                    && let Some(next) = mode_bar_layout.mode_at(mouse.column, mouse.row)
                {
                    remember_quickstart_return(mode, next, &mut quickstart_return);
                    switch_mode(
                        &mut mode,
                        next,
                        &dispatch_state,
                        &mut dashboard_pane,
                        &mut quickstart,
                        &mut acp_pane,
                        &mut chat_pane,
                        &mut sop_pane,
                    )
                    .await;
                    continue;
                }
                // Help-hint click: every pane renders the `?=help` indicator at
                // the bottom-left of the content area; clicking it opens help,
                // mirroring the `?` key.
                if matches!(mouse.kind, MouseEventKind::Down(_))
                    && mouse::help_hint_click(mouse.column, mouse.row, content_area)
                {
                    help_overlay = Some(HelpOverlayState::default());
                    continue;
                }
                // Clicks and wheel inside the sidebar itself.
                let (sidebar_consumed, sidebar_event) = route_agent_sidebar_mouse(
                    mode,
                    &mut chat_pane,
                    &mut acp_pane,
                    &mut sidebar,
                    &mouse,
                );
                if dock.layout.sessions.is_some() && sidebar_consumed {
                    if let Some(event) = sidebar_event {
                        apply_sidebar_event!(event, dispatch_state);
                    }
                    continue;
                }
                if let Some(queue_area) = dock.layout.queue
                    && mouse::in_rect(mouse.column, mouse.row, queue_area)
                {
                    dispatch_state
                        .run_rpc_dispatch(|| async {
                            match mode {
                                Mode::Acp => acp_pane.handle_queue_mouse(mouse, queue_area).await,
                                Mode::Chat => chat_pane.handle_queue_mouse(mouse, queue_area).await,
                                _ => {}
                            }
                        })
                        .await;
                    continue;
                }
                if let Some(result) = dispatch_state
                    .run_rpc_dispatch(|| async {
                        match mode {
                            Mode::Dashboard => {
                                dashboard_pane.handle_mouse(mouse, content_area);
                            }
                            Mode::Config => {
                                config_app.handle_mouse(mouse, content_area, term).await?;
                            }
                            Mode::Doctor => {
                                doctor_pane.handle_mouse(mouse, content_area);
                            }
                            Mode::Logs => {
                                logs_pane.handle_mouse(mouse, content_area);
                            }
                            Mode::Acp => {
                                acp_pane.handle_mouse(mouse, content_area).await;
                            }
                            Mode::Chat => {
                                chat_pane.handle_mouse(mouse, content_area).await;
                            }
                            Mode::Quickstart => {
                                quickstart.handle_mouse(mouse, content_area).await;
                            }
                            Mode::Sop => {
                                sop_pane.handle_mouse(mouse).await;
                            }
                        }
                        consume_pending_quickstart_chat(
                            &dispatch_state,
                            &reconnect_state,
                            &mut mode,
                            &mut chat_pane,
                        )
                        .await;
                        anyhow::Ok(())
                    })
                    .await
                {
                    result?;
                }
            }
            Event::Paste(text) if help_overlay.is_some() => {
                if let Some(state) = help_overlay.as_mut() {
                    state
                        .query
                        .extend(text.chars().filter(|character| !character.is_control()));
                    state.scroll = 0;
                }
            }
            Event::Paste(text) => {
                dispatch_state
                    .run_rpc_dispatch(|| async {
                        match mode {
                            Mode::Chat => chat_pane.handle_paste(&text),
                            Mode::Acp => acp_pane.handle_paste(&text),
                            Mode::Config => config_app.handle_paste(&text).await,
                            Mode::Doctor => doctor_pane.handle_paste(&text),
                            Mode::Quickstart => quickstart.handle_paste(&text),
                            Mode::Dashboard => dashboard_pane.handle_paste(&text),
                            Mode::Logs => logs_pane.handle_paste(&text),
                            Mode::Sop => sop_pane.handle_paste(&text),
                        }
                        consume_pending_quickstart_chat(
                            &dispatch_state,
                            &reconnect_state,
                            &mut mode,
                            &mut chat_pane,
                        )
                        .await;
                    })
                    .await;
            }
            Event::Resize(_, _) => {
                dock.clear_capture();
                sidebar.cancel_drag();
            }
            _ => {}
        }
    }

    // The event loop is ending by an explicit normal-exit path. Reclaim only
    // dispatched clipboard temporaries; drafts and queued messages stay owned
    // by their input state and must never be treated as active turn files.
    chat_pane.cleanup_active_turn_on_shutdown();
    acp_pane.cleanup_active_turn_on_shutdown();
    Ok(())
}

/// A reconnect rebuilds every pane around the new RPC client. The SOP list is
/// loaded on focus rather than at construction, so an already-visible SOP pane
/// must run that same canonical refresh before replacing the disconnected pane.
/// The transport leg to run with after an adoption attempt.
///
/// `connected` is the leg the routing source of truth actually dialled, which is
/// not necessarily the one that dropped: a direct session reconnects onto the
/// relay when the direct address is still down, and a relay session can come
/// back direct. It is committed ONLY when the panes were rebuilt against that
/// client, because `active_leg` names the connection the panes hold and the
/// re-probe and failback loops read it to decide what to try next.
///
/// Discarding it leaves a direct-to-relay reconnect believing it is still
/// direct, so the failback loop that would migrate it back never runs; the
/// mirror case leaves a relay-to-direct reconnect believing it is on the relay,
/// which re-probes a direct path it is already using.
fn leg_after_adoption(
    adopted: bool,
    current: crate::ActiveLeg,
    connected: crate::ActiveLeg,
) -> crate::ActiveLeg {
    if adopted { connected } else { current }
}

async fn refresh_visible_sop_after_reconnect(mode: Mode, pane: &mut sop_pane::SopPane) {
    if mode == Mode::Sop {
        pane.refresh();
    }
}

fn global_help_entries() -> Vec<HelpEntry> {
    use crate::keymap::{GlobalAction, action_key_labels};

    let cycle_keys = action_key_labels(GlobalAction::PaneNavLeft)
        .into_iter()
        .chain(action_key_labels(GlobalAction::PaneNavRight));
    let session_keys = [
        GlobalAction::FocusSession1,
        GlobalAction::FocusSession2,
        GlobalAction::FocusSession3,
        GlobalAction::FocusSession4,
        GlobalAction::FocusSession5,
        GlobalAction::FocusSession6,
        GlobalAction::FocusSession7,
        GlobalAction::FocusSession8,
    ]
    .into_iter()
    .flat_map(action_key_labels);
    vec![
        HelpEntry::new(cycle_keys, crate::i18n::t("zc-app-help-cycle-mode")),
        HelpEntry::new(session_keys, crate::i18n::t("zc-chat-help-switch-session")),
        HelpEntry::new(
            action_key_labels(GlobalAction::Help),
            crate::i18n::t("zc-app-help-help"),
        ),
        HelpEntry::new(
            action_key_labels(GlobalAction::ReloadDaemon),
            crate::i18n::t("zc-app-help-reload"),
        ),
        HelpEntry::new(
            action_key_labels(GlobalAction::ToggleSidebar),
            crate::i18n::t("zc-app-help-toggle-sidebar"),
        ),
        HelpEntry::new(
            action_key_labels(GlobalAction::Quit),
            crate::i18n::t("zc-app-help-quit"),
        ),
        HelpEntry::spacer(),
    ]
}

fn pane_switch_delta(
    global: Option<GlobalAction>,
    editor_claims_chord: bool,
    pane_can_receive_editor_chord: bool,
) -> Option<isize> {
    if editor_claims_chord && pane_can_receive_editor_chord {
        return None;
    }
    match global {
        Some(GlobalAction::PaneNavLeft) => Some(-1),
        Some(GlobalAction::PaneNavRight) => Some(1),
        _ => None,
    }
}

fn session_shortcut_ordinal(action: Option<GlobalAction>) -> Option<usize> {
    match action? {
        GlobalAction::FocusSession1 => Some(0),
        GlobalAction::FocusSession2 => Some(1),
        GlobalAction::FocusSession3 => Some(2),
        GlobalAction::FocusSession4 => Some(3),
        GlobalAction::FocusSession5 => Some(4),
        GlobalAction::FocusSession6 => Some(5),
        GlobalAction::FocusSession7 => Some(6),
        GlobalAction::FocusSession8 => Some(7),
        _ => None,
    }
}

fn session_shortcut_event(
    ordinal: usize,
    sessions: &[chat::SidebarSessionSummary],
) -> Option<crate::agent_sidebar::SidebarEvent> {
    sessions
        .get(ordinal)
        .map(|session| crate::agent_sidebar::SidebarEvent::FocusSession {
            pane: session.pane_kind,
            session_id: session.session_id.clone(),
        })
}

fn session_shortcut_is_available(
    mode: Mode,
    in_text_input: bool,
    pane_claims_shortcut: bool,
) -> bool {
    !pane_claims_shortcut && (!in_text_input || matches!(mode, Mode::Acp | Mode::Chat))
}

/// Direct session shortcuts count sessions in the order the sidebar shows
/// them, so a dragged row keeps the number of the position it was dropped in.
fn session_summaries_in_sidebar_order(
    sidebar: &crate::agent_sidebar::AgentSidebar,
    mut acp_sessions: Vec<chat::SidebarSessionSummary>,
    chat_sessions: Vec<chat::SidebarSessionSummary>,
) -> Vec<chat::SidebarSessionSummary> {
    acp_sessions.extend(chat_sessions);
    sidebar.sort_in_display_order(&mut acp_sessions);
    acp_sessions
}

fn copy_disconnected_composer(
    dispatch_state: &PostPollDispatchState,
    app_modal_owns_keys: bool,
    mode: Mode,
    chat: &mut chat::Chat,
    acp: &mut acp::Acp,
    key: &KeyEvent,
) -> bool {
    !app_modal_owns_keys
        && !dispatch_state.rpc_allowed()
        && match mode {
            Mode::Chat => chat.copy_composer_selection(key),
            Mode::Acp => acp.copy_composer_selection(key),
            _ => false,
        }
}

fn should_handle_global_quit(
    dispatch_state: &PostPollDispatchState,
    pane_wants_quit_chord: bool,
) -> bool {
    !dispatch_state.rpc_allowed() || !pane_wants_quit_chord
}

fn resolve_agent_overrides(
    config_dir: &std::path::Path,
) -> std::collections::HashMap<String, theme::Theme> {
    let mut out = std::collections::HashMap::new();
    let Ok(cfg) = config::ensure_and_load(config_dir) else {
        return out;
    };
    for alias in cfg.agent_override_aliases() {
        if let Ok(Some(t)) = cfg.resolve_agent_theme(alias) {
            out.insert(alias.to_string(), t);
        }
    }
    out
}

fn route_agent_sidebar_mouse(
    mode: Mode,
    chat_pane: &mut chat::Chat,
    acp_pane: &mut acp::Acp,
    sidebar: &mut crate::agent_sidebar::AgentSidebar,
    mouse: &crossterm::event::MouseEvent,
) -> (bool, Option<crate::agent_sidebar::SidebarEvent>) {
    if !sidebar.contains(mouse.column, mouse.row) && !sidebar.captures_mouse(mouse) {
        return (false, None);
    }

    match mode {
        Mode::Chat => chat_pane.finish_transcript_drag_if_released(mouse),
        Mode::Acp => acp_pane.finish_transcript_drag_if_released(mouse),
        _ => {}
    }

    (true, sidebar.handle_mouse(mouse))
}

// ── Mode bar ─────────────────────────────────────────────────────

fn draw_mode_bar(
    frame: &mut ratatui::Frame,
    area: Rect,
    active: Mode,
    chrome_summary: Option<&Line<'static>>,
) -> ModeBarLayout {
    use ratatui::widgets::Tabs;

    // Keep the active navigation target visible even when the terminal is too
    // narrow to show the complete mode list.
    let active_idx = MODES.iter().position(|m| *m == active);
    let window_anchor = active_idx.unwrap_or(0);
    let base_titles: Vec<String> = MODES
        .iter()
        .map(|mode| format!(" {} ", crate::i18n::t(mode.fluent_key())))
        .collect();

    // Chrome is informative; the selected navigation target is interactive.
    // Keep the full summary only when it leaves enough room for the active tab.
    let active_width = crate::display_width::display_width(&base_titles[window_anchor]) as u16;
    let summary_width = chrome_summary
        .map(Line::width)
        .filter(|width| usize::from(area.width) >= width.saturating_add(active_width.into()))
        .map(|width| width.min(usize::from(u16::MAX)) as u16)
        .unwrap_or(0);
    let tab_area = Rect::new(
        area.x,
        area.y,
        area.width.saturating_sub(summary_width),
        area.height,
    );
    let summary_area = (summary_width > 0)
        .then(|| Rect::new(tab_area.right(), area.y, summary_width, area.height));

    let (start, end, show_overflow_markers) =
        visible_mode_window(&base_titles, window_anchor, usize::from(tab_area.width));
    let mut visible: Vec<(Mode, String)> = MODES[start..end]
        .iter()
        .copied()
        .zip(base_titles[start..end].iter().cloned())
        .collect();
    if show_overflow_markers && start > 0 {
        visible[0].1.insert(0, '‹');
    }
    if show_overflow_markers && end < MODES.len() {
        visible
            .last_mut()
            .expect("active mode is visible")
            .1
            .push('›');
    }

    let mut x = tab_area.x;
    let mut entries = Vec::with_capacity(visible.len());
    for (index, (mode, title)) in visible.into_iter().enumerate() {
        let remaining = tab_area.right().saturating_sub(x);
        if remaining == 0 {
            break;
        }
        let title_width = crate::display_width::display_width(&title) as u16;
        let rendered_width = title_width.min(remaining);
        entries.push(ModeBarEntry {
            mode,
            title,
            hit_rect: Rect::new(x, tab_area.y, rendered_width, tab_area.height),
        });
        x = x.saturating_add(rendered_width);
        if rendered_width < title_width {
            break;
        }
        if index + 1 < end - start && x < tab_area.right() {
            // Ratatui renders the one-column divider after each non-final title.
            x = x.saturating_add(1);
        }
    }

    let selected = entries.iter().position(|entry| entry.mode == active);
    let titles: Vec<ratatui::text::Line> = entries
        .iter()
        .map(|entry| {
            ratatui::text::Line::from(ratatui::text::Span::styled(
                entry.title.clone(),
                theme::body_style(),
            ))
        })
        .collect();

    let tabs = Tabs::new(titles)
        .select(selected)
        .style(theme::bar_style())
        .highlight_style(theme::selected_style().add_modifier(Modifier::BOLD))
        .divider("│")
        .padding("", "");

    frame.render_widget(tabs, tab_area);
    if let (Some(summary), Some(summary_area)) = (chrome_summary, summary_area) {
        frame.render_widget(Paragraph::new(summary.clone()), summary_area);
    }

    ModeBarLayout {
        tab_area,
        summary_area,
        entries,
    }
}

/// Select a contiguous localized-title window containing `active_idx`.
/// Hidden neighbors are signaled with edge markers when those markers fit.
fn visible_mode_window(
    titles: &[String],
    active_idx: usize,
    available_width: usize,
) -> (usize, usize, bool) {
    let mut start = active_idx.min(titles.len().saturating_sub(1));
    let mut end = (start + 1).min(titles.len());

    loop {
        let mut expanded = false;
        if start > 0 && mode_window_width(titles, start - 1, end) <= available_width {
            start -= 1;
            expanded = true;
        }
        if end < titles.len() && mode_window_width(titles, start, end + 1) <= available_width {
            end += 1;
            expanded = true;
        }
        if !expanded {
            break;
        }
    }

    let markers_fit = mode_window_width(titles, start, end) <= available_width;
    (start, end, markers_fit)
}

fn mode_window_width(titles: &[String], start: usize, end: usize) -> usize {
    let title_width: usize = titles[start..end]
        .iter()
        .map(|title| crate::display_width::display_width(title))
        .sum();
    let dividers = end.saturating_sub(start + 1);
    let overflow_markers = usize::from(start > 0) + usize::from(end < titles.len());
    title_width + dividers + overflow_markers
}

// ── Status bar ───────────────────────────────────────────────────

const HEALTHY_GREEN: Color = Color::Rgb(80, 220, 120);
const DEAD_RED: Color = Color::Rgb(255, 80, 80);

fn draw_status_bar(
    frame: &mut ratatui::Frame,
    area: Rect,
    state: &ConnectionState,
    tui_id: Option<&str>,
    ctx: CtxBar,
    needs_intervention: bool,
    browse_mode: bool,
) {
    let (dot, label, style) = match state {
        ConnectionState::Connected => (
            "\u{25cf}",
            " Connected".to_string(),
            Style::default().fg(HEALTHY_GREEN),
        ),
        ConnectionState::Disconnected { reason } if needs_intervention => (
            "\u{25cf}",
            format!(" Daemon unavailable — restart required ({reason})"),
            Style::default().fg(DEAD_RED),
        ),
        ConnectionState::Disconnected { reason } => (
            "\u{25cf}",
            format!(" Reconnecting… (reason: {reason})"),
            Style::default().fg(DEAD_RED),
        ),
    };

    // Show TUI ID prefix when connected and assigned.
    let id_span = match (state, tui_id) {
        (ConnectionState::Connected, Some(id)) => Some(Span::styled(
            format!("{id} "),
            Style::default().fg(HEALTHY_GREEN),
        )),
        _ => None,
    };

    let id_len = id_span.as_ref().map(|s| s.width()).unwrap_or(0);
    let conn_text_len = (id_len + 1 + label.len()) as u16; // id + dot + label

    // Split the row: ctx bar on the left, connection status on the right.
    // Right column is sized to exactly fit the conn text; left gets the rest.
    let right_w = conn_text_len.min(area.width);
    let chunks = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Min(0), Constraint::Length(right_w)])
        .split(area);
    let left_area = chunks[0];
    let right_area = chunks[1];

    // Right: connection status, no leading padding (column is exact width).
    let mut spans = Vec::with_capacity(3);
    if let Some(id) = id_span {
        spans.push(id);
    }
    spans.push(Span::styled(dot, style));
    spans.push(Span::styled(label, style));
    frame.render_widget(Paragraph::new(Line::from(spans)), right_area);

    // Left: ctx bar, possibly preceded by a browse-mode badge.
    // The ctx bar is held back until the context-accounting feature is
    // ready to show; there is no user-facing switch — the gate flips
    // when the work lands.
    const SHOW_CTX_BAR: bool = true;
    // If browse mode is active, split off a fixed-width badge first.
    let left_area = if browse_mode {
        let badge_w = "  BROWSE  ".len() as u16 + 1;
        let chunks = Layout::default()
            .direction(Direction::Horizontal)
            .constraints([Constraint::Length(badge_w), Constraint::Min(0)])
            .split(left_area);
        frame.render_widget(
            Paragraph::new(Line::from(vec![Span::styled(
                " BROWSE ",
                Style::default()
                    .fg(HEALTHY_GREEN)
                    .add_modifier(Modifier::REVERSED),
            )])),
            chunks[0],
        );
        chunks[1]
    } else {
        left_area
    };
    if SHOW_CTX_BAR && let Some(w) = ctx.widget() {
        frame.render_widget(w, left_area);
    }
}

fn process_stats_summary(health: Option<&serde_json::Value>) -> String {
    let cpu_label = crate::i18n::t("zc-chrome-summary-cpu");
    let loading_label = crate::i18n::t("zc-chrome-summary-loading");
    let Some(h) = health else {
        return format!(" {cpu_label}:{loading_label}");
    };
    let Some(process) = h.get("process") else {
        return format!(" {cpu_label}:{loading_label}");
    };
    let mut parts = Vec::new();
    if let Some(rss) = process.get("rss_bytes").and_then(|v| v.as_u64())
        && rss > 0
    {
        let total = process
            .get("system_ram_total_bytes")
            .and_then(|v| v.as_u64())
            .unwrap_or(0);
        let rss_str = format_bytes(rss);
        let ram_label = crate::i18n::t("zc-chrome-summary-ram");
        if total > 0 {
            let pct = (rss as f64 / total as f64) * 100.0;
            parts.push(format!(" {ram_label}:{rss_str}({pct:.0}%)"));
        } else {
            parts.push(format!(" {ram_label}:{rss_str}"));
        }
    }
    if let Some(cpu) = process.get("cpu_percent").and_then(|v| v.as_f64()) {
        parts.push(format!(" {cpu_label}:{cpu:.1}%"));
    } else {
        parts.push(format!(" {cpu_label}:{loading_label}"));
    }
    parts.join("")
}

fn format_bytes(bytes: u64) -> String {
    if bytes >= 1_073_741_824 {
        format!("{:.1}G", bytes as f64 / 1_073_741_824.0)
    } else if bytes >= 1_048_576 {
        format!("{:.1}M", bytes as f64 / 1_048_576.0)
    } else if bytes >= 1024 {
        format!("{:.0}K", bytes as f64 / 1024.0)
    } else {
        format!("{bytes}B")
    }
}

// ── Help modal ───────────────────────────────────────────────────

/// Flatten a `HelpNode` tree into renderable lines, depth-first.
/// Returns `(key_string, action)` pairs; both empty = spacer; action empty +
/// key non-empty = section header; key == "\x01" = dim rule separator.
fn flatten_help_node(node: &HelpNode, out: &mut Vec<(String, String)>, inner_width: usize) {
    // Section title → dim header line.
    if let Some(title) = &node.title {
        out.push(("\x01".into(), title.to_string())); // sentinel = separator/header
    }

    // Description prose → soft-wrapped plain lines, no key column.
    if let Some(desc) = &node.description {
        let wrap_at = inner_width.saturating_sub(2).max(20);
        for line in soft_wrap(desc, wrap_at) {
            out.push(("".into(), line));
        }
        out.push(("".into(), "".into())); // blank after prose
    }

    // Keybinding entries.
    for entry in &node.entries {
        let k = entry.key_str();
        out.push((k, entry.action.to_string()));
    }

    // Children with a dim rule before each.
    for child in &node.children {
        out.push(("\x01".into(), "".into())); // dim rule
        flatten_help_node(child, out, inner_width);
    }
}

/// Naive soft-wrap: split `text` into lines no longer than `width`.
/// Breaks on word boundaries where possible.
fn soft_wrap(text: &str, width: usize) -> Vec<String> {
    let mut lines = Vec::new();
    for paragraph in text.split('\n') {
        let mut current = String::new();
        for word in paragraph.split_whitespace() {
            if current.is_empty() {
                current.push_str(word);
            } else if current.len() + 1 + word.len() <= width {
                current.push(' ');
                current.push_str(word);
            } else {
                lines.push(current.clone());
                current = word.to_string();
            }
        }
        if !current.is_empty() {
            lines.push(current);
        }
    }
    lines
}

fn filter_help_node(node: &HelpNode, query: &str) -> Option<HelpNode> {
    let needle = query.trim().to_lowercase();
    if needle.is_empty() {
        return Some(node.clone());
    }

    let node_matches = node
        .title
        .as_deref()
        .is_some_and(|title| title.to_lowercase().contains(&needle))
        || node
            .description
            .as_deref()
            .is_some_and(|description| description.to_lowercase().contains(&needle));
    if node_matches {
        return Some(node.clone());
    }

    let entries: Vec<HelpEntry> = node
        .entries
        .iter()
        .filter(|entry| {
            entry.key_str().to_lowercase().contains(&needle)
                || entry.action.to_lowercase().contains(&needle)
        })
        .cloned()
        .collect();
    let children: Vec<HelpNode> = node
        .children
        .iter()
        .filter_map(|child| filter_help_node(child, &needle))
        .collect();

    if entries.is_empty() && children.is_empty() {
        return None;
    }

    Some(HelpNode {
        title: node.title.clone(),
        description: None,
        entries,
        children,
    })
}

fn help_control_hint() -> String {
    use crate::keymap::action_key_labels;

    let up = action_key_labels(SearchBoxAction::Up).join("/");
    let down = action_key_labels(SearchBoxAction::Down).join("/");
    let cancel = action_key_labels(SearchBoxAction::Cancel).join("/");
    crate::i18n::t_args(
        "zc-app-help-controls",
        &[("up", &up), ("down", &down), ("cancel", &cancel)],
    )
}

fn draw_help_modal(
    frame: &mut ratatui::Frame,
    area: Rect,
    node: &HelpNode,
    state: &mut HelpOverlayState,
) {
    // We need inner_width to soft-wrap descriptions. Use a generous default
    // first pass, then clamp to terminal width.
    let max_inner_w = (area.width as usize).saturating_sub(6).max(30);

    let mut all_flat: Vec<(String, String)> = Vec::new();
    flatten_help_node(node, &mut all_flat, max_inner_w);
    let mut flat: Vec<(String, String)> = Vec::new();
    if let Some(filtered) = filter_help_node(node, &state.query) {
        flatten_help_node(&filtered, &mut flat, max_inner_w);
    }

    // Compute key column width (skip sentinels and prose-only lines).
    let key_width = all_flat
        .iter()
        .filter(|(k, _)| k != "\x01")
        .map(|(k, _)| crate::display_width::display_width(k))
        .max()
        .unwrap_or(0);
    let val_width = all_flat
        .iter()
        .filter(|(k, _)| k != "\x01")
        .map(|(_, v)| crate::display_width::display_width(v))
        .max()
        .unwrap_or(0);

    let title = format!(" {} ", crate::i18n::t("zc-app-keybindings-title"));
    let filter_label = crate::i18n::t("zc-app-help-filter-label");
    let filter_placeholder = crate::i18n::t("zc-app-help-filter-placeholder");
    let filter_display = if state.query.is_empty() {
        filter_placeholder.as_str()
    } else {
        &state.query
    };
    let control_hint = help_control_hint();
    let chrome_width = [
        crate::display_width::display_width(&title),
        crate::display_width::display_width(&filter_label)
            + 2
            + crate::display_width::display_width(filter_display),
        crate::display_width::display_width(&control_hint),
    ]
    .into_iter()
    .max()
    .unwrap_or(0);
    let inner_w = (key_width + 2 + val_width).max(chrome_width);
    let box_w = (inner_w + 4).min(area.width as usize) as u16;
    // +4: 2 border + 1 filter row + 1 footer row.
    let box_h = (all_flat.len() + 4).min(area.height as usize) as u16;

    let x = area.x + area.width.saturating_sub(box_w) / 2;
    let y = area.y + area.height.saturating_sub(box_h) / 2;
    let modal_rect = Rect::new(x, y, box_w, box_h);

    frame.render_widget(Clear, modal_rect);

    let block = Block::default()
        .borders(Borders::ALL)
        .border_style(theme::dim_style())
        .style(theme::fill_style())
        .title(Span::styled(title, theme::heading_style()));

    let inner = block.inner(modal_rect);
    frame.render_widget(block, modal_rect);

    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(1),
            Constraint::Min(0),
            Constraint::Length(1),
        ])
        .split(inner);

    let filter_value = if state.query.is_empty() {
        Span::styled(filter_placeholder, theme::dim_style())
    } else {
        Span::styled(state.query.clone(), theme::accent_style())
    };
    frame.render_widget(
        Paragraph::new(Line::from(vec![
            Span::styled(format!("{filter_label}: "), theme::body_style()),
            filter_value,
        ]))
        .style(theme::fill_style()),
        chunks[0],
    );

    let rule_width = chunks[1].width as usize;
    let mut text_lines: Vec<Line> = Vec::new();

    if flat.is_empty() {
        text_lines.push(Line::from(Span::styled(
            crate::i18n::t("zc-app-help-no-matches"),
            theme::dim_style(),
        )));
    }
    for (key, val) in &flat {
        if key == "\x01" {
            // Dim horizontal rule, optionally with a label.
            if val.is_empty() {
                let rule = "─".repeat(rule_width);
                text_lines.push(Line::from(Span::styled(rule, theme::dim_style())));
            } else {
                // "── Label ──"
                let label = format!(" {} ", val);
                let sides = rule_width.saturating_sub(crate::display_width::display_width(&label));
                let left = "─".repeat(sides / 2);
                let right = "─".repeat(sides - sides / 2);
                text_lines.push(Line::from(vec![
                    Span::styled(left, theme::dim_style()),
                    Span::styled(label, theme::dim_style()),
                    Span::styled(right, theme::dim_style()),
                ]));
            }
        } else if key.is_empty() && val.is_empty() {
            text_lines.push(Line::from(""));
        } else if key.is_empty() {
            // Prose line — no key column, full width.
            text_lines.push(Line::from(Span::styled(val.clone(), theme::body_style())));
        } else {
            let padding =
                " ".repeat(key_width.saturating_sub(crate::display_width::display_width(key)));
            text_lines.push(Line::from(vec![
                Span::styled(format!("{padding}{key}"), theme::accent_style()),
                Span::styled("  ", theme::dim_style()),
                Span::styled(val.clone(), theme::body_style()),
            ]));
        }
    }

    let max_scroll = text_lines.len().saturating_sub(chunks[1].height as usize);
    state.scroll = state.scroll.min(max_scroll);
    let scroll = state.scroll.min(u16::MAX as usize) as u16;
    frame.render_widget(
        Paragraph::new(text_lines)
            .style(theme::fill_style())
            .scroll((scroll, 0)),
        chunks[1],
    );
    frame.render_widget(
        Paragraph::new(Span::styled(control_hint, theme::dim_style())).style(theme::fill_style()),
        chunks[2],
    );
}

fn draw_reload_confirm_modal(frame: &mut ratatui::Frame, area: Rect) {
    let body_lines: Vec<Line> = vec![
        Line::from(Span::styled(
            crate::i18n::t("zc-app-reload-line-1"),
            theme::body_style(),
        )),
        Line::from(Span::styled(
            crate::i18n::t("zc-app-reload-line-2"),
            theme::body_style(),
        )),
        Line::from(Span::styled(
            crate::i18n::t("zc-app-reload-line-3"),
            theme::body_style(),
        )),
        Line::from(""),
        Line::from(Span::styled(
            crate::i18n::t("zc-app-reload-bullet-gateway"),
            theme::body_style(),
        )),
        Line::from(Span::styled(
            crate::i18n::t("zc-app-reload-bullet-channels"),
            theme::body_style(),
        )),
        Line::from(Span::styled(
            crate::i18n::t("zc-app-reload-bullet-mcp"),
            theme::body_style(),
        )),
        Line::from(Span::styled(
            crate::i18n::t("zc-app-reload-bullet-provider"),
            theme::body_style(),
        )),
        Line::from(""),
        Line::from(Span::styled(
            crate::i18n::t("zc-app-reload-socket-note"),
            theme::dim_style(),
        )),
    ];

    let box_w = area.width.saturating_sub(8).min(64);
    let box_h = (body_lines.len() as u16 + 4).min(area.height.saturating_sub(4));
    let x = area.x + area.width.saturating_sub(box_w) / 2;
    let y = area.y + area.height.saturating_sub(box_h) / 2;
    let rect = Rect::new(x, y, box_w, box_h);

    frame.render_widget(Clear, rect);
    let block = Block::default()
        .borders(Borders::ALL)
        .border_style(theme::warn_style())
        .style(theme::fill_style())
        .title(Span::styled(
            " Reload daemon? ",
            theme::warn_style().add_modifier(Modifier::BOLD),
        ));
    let inner = block.inner(rect);
    frame.render_widget(block, rect);

    let body = Paragraph::new(body_lines)
        .style(theme::fill_style())
        .wrap(ratatui::widgets::Wrap { trim: false });
    let body_rect = Rect::new(
        inner.x.saturating_add(1),
        inner.y,
        inner.width.saturating_sub(2),
        inner.height.saturating_sub(1),
    );
    frame.render_widget(body, body_rect);

    let footer_rect = Rect::new(
        inner.x.saturating_add(1),
        inner.y + inner.height.saturating_sub(1),
        inner.width.saturating_sub(2),
        1,
    );
    frame.render_widget(
        Paragraph::new(Span::styled(
            crate::i18n::t_args(
                "zc-app-reload-confirm-row",
                &[("confirm_chord", "Enter / y"), ("cancel_chord", "Esc / n")],
            ),
            theme::dim_style(),
        ))
        .style(theme::fill_style()),
        footer_rect,
    );
}

fn draw_quit_confirm_modal(frame: &mut ratatui::Frame, area: Rect) {
    let body_lines: Vec<Line> = vec![
        Line::from(Span::styled(
            crate::i18n::t("zc-app-quit-prompt"),
            theme::heading_style(),
        )),
        Line::from(""),
        Line::from(Span::styled(
            crate::i18n::t("zc-app-quit-explainer"),
            theme::dim_style(),
        )),
    ];

    let box_w = area.width.saturating_sub(8).min(60);
    let box_h = (body_lines.len() as u16 + 4).min(area.height.saturating_sub(4));
    let x = area.x + area.width.saturating_sub(box_w) / 2;
    let y = area.y + area.height.saturating_sub(box_h) / 2;
    let rect = Rect::new(x, y, box_w, box_h);

    frame.render_widget(Clear, rect);
    let block = theme::modal_block(" Quit? ");
    let inner = block.inner(rect);
    frame.render_widget(block, rect);

    let body = Paragraph::new(body_lines)
        .style(theme::fill_style())
        .wrap(ratatui::widgets::Wrap { trim: false });
    let body_rect = Rect::new(
        inner.x.saturating_add(1),
        inner.y,
        inner.width.saturating_sub(2),
        inner.height.saturating_sub(1),
    );
    frame.render_widget(body, body_rect);

    let footer_rect = Rect::new(
        inner.x.saturating_add(1),
        inner.y + inner.height.saturating_sub(1),
        inner.width.saturating_sub(2),
        1,
    );
    let footer = format!(
        "{} = {confirm}   {} = {quit}   {} = {cancel}",
        chords_for(ModalAction::bindings(), ModalAction::Confirm),
        chords_for(GlobalAction::resolved_bindings(), GlobalAction::Quit),
        chords_for(ModalAction::bindings(), ModalAction::Cancel),
        confirm = ModalAction::Confirm.label(),
        quit = GlobalAction::Quit.label(),
        cancel = ModalAction::Cancel.label(),
    );
    frame.render_widget(
        Paragraph::new(Span::styled(footer, theme::dim_style())).style(theme::fill_style()),
        footer_rect,
    );
}

/// Render every chord bound to `action` from its `bindings()` table as a
/// `a/b` display string. Surfaces read the harness; no key literals.
/// Display strings are deduplicated — chords that render identically
/// (e.g. `'y'` and `'Y'` both render as `Y`) collapse to one slot.
fn chords_for<ActionType: PartialEq>(
    bindings: Vec<(crate::keymap::Chord, ActionType)>,
    action: ActionType,
) -> String {
    let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut out: Vec<String> = Vec::new();
    for (chord, bound_action) in bindings {
        if bound_action != action {
            continue;
        }
        let label = chord.display();
        if seen.insert(label.clone()) {
            out.push(label);
        }
    }
    out.join("/")
}

fn draw_reload_status_toast(frame: &mut ratatui::Frame, area: Rect, msg: &str) {
    let text = format!(" {msg} ");
    let box_w = (text.chars().count() as u16 + 2).min(area.width);
    let box_h = 3u16.min(area.height);
    let x = area.x + area.width.saturating_sub(box_w) / 2;
    let y = area.y + area.height.saturating_sub(box_h).saturating_sub(1);
    let rect = Rect::new(x, y, box_w, box_h);

    frame.render_widget(Clear, rect);
    let block = Block::default()
        .borders(Borders::ALL)
        .border_style(theme::warn_style())
        .style(theme::fill_style());
    let inner = block.inner(rect);
    frame.render_widget(block, rect);
    frame.render_widget(
        Paragraph::new(Span::styled(text, theme::body_style())).style(theme::fill_style()),
        inner,
    );
}
#[cfg(test)]
pub(crate) mod tests {
    use super::*;
    use std::collections::VecDeque;

    fn test_dock() -> ConversationDock {
        ConversationDock {
            config_dir: std::path::PathBuf::new(),
            sessions_visible: true,
            queue_visible: true,
            plan_visible: true,
            side: config::SidebarSide::Right,
            width: 24,
            sessions_percent: 60,
            queue_percent: 50,
            capture: None,
            layout: DockLayout::default(),
        }
    }

    fn dock_mouse(kind: MouseEventKind, column: u16, row: u16) -> crossterm::event::MouseEvent {
        crossterm::event::MouseEvent {
            kind,
            column,
            row,
            modifiers: KeyModifiers::NONE,
        }
    }

    #[test]
    fn dock_layout_visibility_combinations_preserve_order_and_remaining_space() {
        let area = Rect::new(2, 3, 120, 40);
        for mask in 0..8 {
            for active_plan in [false, true] {
                for mode in [Mode::Chat, Mode::Acp] {
                    let mut dock = test_dock();
                    dock.sessions_visible = mask & 1 != 0;
                    dock.queue_visible = mask & 2 != 0;
                    dock.plan_visible = mask & 4 != 0;
                    let layout = dock.layout(area, mode, active_plan);
                    assert_eq!(layout.sessions.is_some(), dock.sessions_visible);
                    assert_eq!(layout.queue.is_some(), dock.queue_visible);
                    assert_eq!(layout.plan.is_some(), dock.plan_visible && active_plan);
                    assert!(layout.toggles.iter().all(|rect| rect.width > 0));
                    let sections: Vec<_> = [layout.sessions, layout.queue, layout.plan]
                        .into_iter()
                        .flatten()
                        .collect();
                    assert_eq!(layout.dock.is_some(), !sections.is_empty());
                    for section in &sections {
                        assert!(section.height >= DOCK_MIN_SECTION_ROWS);
                        assert!(section.intersection(layout.conversation).is_empty());
                    }
                    for pair in sections.windows(2) {
                        assert_eq!(pair[0].bottom() + 1, pair[1].y);
                    }
                    if let Some(last) = sections.last() {
                        assert_eq!(last.bottom(), area.bottom());
                    }
                    if let Some(queue) = layout.queue
                        && layout.plan.is_none()
                    {
                        assert_eq!(
                            queue.bottom(),
                            area.bottom(),
                            "Queue gets the remaining lower space"
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn dock_plan_mouse_and_keyboard_toggle_without_active_session() {
        let _guard = crate::test_support::env_test_lock();
        tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap()
            .block_on(async {
                let dir = tempfile::tempdir().unwrap();
                let (tx, _rx) = tokio::sync::mpsc::channel::<String>(1);
                let client = Arc::new(RpcClient::with_rpc(Arc::new(
                    crate::jsonrpc::RpcOutbound::new(tx),
                )));
                let mut chat = chat::Chat::new(client.clone(), chat::PaneKind::Chat);
                let mut acp = acp::Acp::new(client);
                let mut dock = test_dock();
                dock.config_dir = dir.path().to_path_buf();
                let mut term: crate::config_manager::Term = ratatui::Terminal::with_options(
                    crate::terminal_backend::WideCellCleanupBackend::new(std::io::stdout()),
                    ratatui::TerminalOptions {
                        viewport: ratatui::Viewport::Fixed(Rect::new(0, 0, 120, 40)),
                    },
                )
                .unwrap();
                let key = KeyEvent::new(
                    KeyCode::Char('p'),
                    crate::keymap::Chord::primary('p').effective_modifiers(),
                );
                for mode in [Mode::Chat, Mode::Acp] {
                    for expected in [false, true] {
                        let target = dock.layout(Rect::new(0, 0, 120, 40), mode, false).toggles[2];
                        let (handled, action) = handle_dock_mouse(
                            &mut dock,
                            mode,
                            &mut chat,
                            &mut acp,
                            &dock_mouse(
                                MouseEventKind::Down(MouseButton::Left),
                                target.x,
                                target.y,
                            ),
                        );
                        assert!(handled);
                        assert_eq!(action, Some(DockAction::TogglePlan));
                        assert_eq!(dock.plan_visible, expected);
                        persist_dock_action(&dock, action.unwrap()).unwrap();
                        assert_eq!(
                            config::load_persisted(dir.path())
                                .unwrap()
                                .sidebar
                                .plan_visible,
                            expected
                        );
                        assert!(chat.current_session_id().is_none());
                        assert!(acp.current_session_id().is_none());
                    }
                    for expected in [false, true] {
                        match mode {
                            Mode::Chat => assert!(!chat.handle_key(key, &mut term).await),
                            Mode::Acp => assert!(!acp.handle_key(key, &mut term).await),
                            _ => unreachable!(),
                        }
                        let action =
                            apply_dock_plan_key_request(&mut dock, mode, &mut chat, &mut acp);
                        assert_eq!(action, Some(DockAction::TogglePlan));
                        assert_eq!(dock.plan_visible, expected);
                        persist_dock_action(&dock, action.unwrap()).unwrap();
                        assert_eq!(
                            config::load_persisted(dir.path())
                                .unwrap()
                                .sidebar
                                .plan_visible,
                            expected
                        );
                        assert!(chat.current_session_id().is_none());
                        assert!(acp.current_session_id().is_none());
                        assert!(
                            apply_dock_plan_key_request(&mut dock, mode, &mut chat, &mut acp)
                                .is_none()
                        );
                    }
                }
            });
    }

    #[tokio::test]
    async fn dock_plan_mouse_and_keyboard_share_visibility() {
        let area = Rect::new(0, 0, 120, 40);
        for mode in [Mode::Chat, Mode::Acp] {
            let (tx, _rx) = tokio::sync::mpsc::channel::<String>(1);
            let client = Arc::new(RpcClient::with_rpc(Arc::new(
                crate::jsonrpc::RpcOutbound::new(tx),
            )));
            let mut chat = chat::Chat::new(client.clone(), chat::PaneKind::Chat);
            let mut acp = acp::Acp::new(client);
            chat.activate_session_for_test("chat-session");
            acp.activate_session_for_test("code-session");
            let mut dock = test_dock();
            set_dock_plan_visible(&mut dock, mode, &mut chat, &mut acp, true);
            let mut term: crate::config_manager::Term = ratatui::Terminal::with_options(
                crate::terminal_backend::WideCellCleanupBackend::new(std::io::stdout()),
                ratatui::TerminalOptions {
                    viewport: ratatui::Viewport::Fixed(area),
                },
            )
            .unwrap();
            let key = KeyEvent::new(
                KeyCode::Char('p'),
                crate::keymap::Chord::primary('p').effective_modifiers(),
            );

            // Mouse close, keyboard reopen, keyboard close, mouse reopen.
            for expected in [false, true] {
                let layout = dock.layout(area, mode, true);
                let target = if expected {
                    layout.toggles[2]
                } else {
                    layout.close[2]
                };
                let (_, action) = handle_dock_mouse(
                    &mut dock,
                    mode,
                    &mut chat,
                    &mut acp,
                    &dock_mouse(MouseEventKind::Down(MouseButton::Left), target.x, target.y),
                );
                assert_eq!(action, Some(DockAction::TogglePlan));
                let visible = dock.plan_visible;
                assert_eq!(visible, expected);
                for _ in 0..2 {
                    match mode {
                        Mode::Chat => {
                            chat.handle_key(key, &mut term).await;
                        }
                        Mode::Acp => {
                            acp.handle_key(key, &mut term).await;
                        }
                        _ => unreachable!(),
                    }
                    assert_eq!(
                        apply_dock_plan_key_request(&mut dock, mode, &mut chat, &mut acp),
                        Some(DockAction::TogglePlan)
                    );
                    let pane_visible = match mode {
                        Mode::Chat => chat.plan_visible(),
                        Mode::Acp => acp.plan_visible(),
                        _ => unreachable!(),
                    };
                    assert_eq!(dock.plan_visible, pane_visible);
                    assert_eq!(
                        dock.layout(area, mode, pane_visible).plan.is_some(),
                        pane_visible
                    );
                }
            }
            // A persisted hidden dock can coexist with a newly visible session.
            dock.plan_visible = false;
            match mode {
                Mode::Chat => {
                    chat.handle_key(key, &mut term).await;
                }
                Mode::Acp => {
                    acp.handle_key(key, &mut term).await;
                }
                _ => unreachable!(),
            }
            assert!(apply_dock_plan_key_request(&mut dock, mode, &mut chat, &mut acp).is_some());
            assert!(dock.plan_visible);

            // Hide here, reopen in the other mode, then reopen here in one click.
            let other_mode = if mode == Mode::Chat {
                Mode::Acp
            } else {
                Mode::Chat
            };
            for (active_mode, expected) in [(mode, false), (other_mode, true), (mode, true)] {
                let pane_visible = match active_mode {
                    Mode::Chat => chat.plan_visible(),
                    Mode::Acp => acp.plan_visible(),
                    _ => unreachable!(),
                };
                let target = dock.layout(area, active_mode, pane_visible).toggles[2];
                assert_eq!(
                    handle_dock_mouse(
                        &mut dock,
                        active_mode,
                        &mut chat,
                        &mut acp,
                        &dock_mouse(MouseEventKind::Down(MouseButton::Left), target.x, target.y),
                    ),
                    (true, Some(DockAction::TogglePlan))
                );
                let pane_visible = match active_mode {
                    Mode::Chat => chat.plan_visible(),
                    Mode::Acp => acp.plan_visible(),
                    _ => unreachable!(),
                };
                assert_eq!(dock.plan_visible, expected);
                assert_eq!(pane_visible, expected);
                assert_eq!(
                    dock.layout(area, active_mode, pane_visible).plan.is_some(),
                    expected
                );
            }
        }
    }

    #[test]
    fn dock_close_reopen_only_changes_the_selected_section() {
        let area = Rect::new(0, 0, 120, 40);
        for index in 0..3 {
            let mut dock = test_dock();
            let layout = dock.layout(area, Mode::Chat, true);
            let close = layout.close[index];
            let expected = [
                DockAction::ToggleSessions,
                DockAction::ToggleQueue,
                DockAction::TogglePlan,
            ][index];
            assert_eq!(
                dock.handle_mouse(&dock_mouse(
                    MouseEventKind::Down(MouseButton::Left),
                    close.x,
                    close.y
                )),
                (true, Some(expected))
            );
            let visible = [dock.sessions_visible, dock.queue_visible, dock.plan_visible];
            for (other, value) in visible.into_iter().enumerate() {
                assert_eq!(value, other != index);
            }
            let layout = dock.layout(area, Mode::Chat, true);
            assert!(layout.close[index].is_empty());
            let reopen = layout.toggles[index];
            assert_eq!(
                dock.handle_mouse(&dock_mouse(
                    MouseEventKind::Down(MouseButton::Left),
                    reopen.x,
                    reopen.y
                )),
                (true, Some(expected))
            );
            assert!(dock.sessions_visible && dock.queue_visible && dock.plan_visible);
            assert!(dock.capture.is_none());
        }
        let mut dock = test_dock();
        for index in 0..3 {
            dock.toggle_section(index);
        }
        let layout = dock.layout(area, Mode::Chat, true);
        assert!(layout.dock.is_none());
        assert!(layout.toggles.iter().all(|rect| !rect.is_empty()));
    }

    #[test]
    fn dock_collapses_as_a_unit_and_drops_stale_hit_targets() {
        for area in [Rect::new(0, 0, 24, 40), Rect::new(0, 0, 120, 7)] {
            let mut dock = test_dock();
            dock.layout(Rect::new(0, 0, 120, 40), Mode::Acp, true);
            dock.capture = Some(DockCapture::Width);
            let layout = dock.layout(area, Mode::Acp, true);
            assert!(layout.dock.is_none());
            assert!(layout.sessions.is_none() && layout.queue.is_none() && layout.plan.is_none());
            assert_eq!(layout.conversation.width, area.width);
            assert_eq!(layout.conversation.bottom(), area.bottom());
            assert!(layout.close.iter().all(|rect| rect.is_empty()));
            assert!(
                layout.width_edge.is_empty()
                    && layout.divider.is_empty()
                    && layout.plan_divider.is_empty()
            );
            assert!(layout.toggles.iter().all(|rect| !rect.is_empty()));
            assert!(dock.capture.is_none());
        }
        let mut dock = test_dock();
        let layout = dock.layout(Rect::new(0, 0, 120, 40), Mode::Config, true);
        assert!(layout.dock.is_none());
        assert!(layout.toggles.iter().all(|rect| rect.is_empty()));
        assert_eq!(layout.conversation, Rect::new(0, 0, 120, 40));
    }

    #[test]
    fn dock_rendered_session_close_is_distinct_from_add_session() {
        let mut dock = test_dock();
        let mut sidebar = crate::agent_sidebar::AgentSidebar::new();
        let layout = dock.layout(Rect::new(0, 0, 120, 40), Mode::Chat, true);
        let sessions = layout.sessions.unwrap();
        let mut terminal =
            ratatui::Terminal::new(ratatui::backend::TestBackend::new(120, 40)).unwrap();
        terminal
            .draw(|frame| {
                dock.draw_shell(frame);
                sidebar.draw(
                    frame,
                    sessions,
                    &[],
                    &crate::agent_sidebar::SidebarCtx {
                        active_pane: Some(chat::PaneKind::Chat),
                        quickstart_active: false,
                        connected: true,
                    },
                );
                dock.draw_resize_handles(frame);
            })
            .unwrap();
        let close = layout.close[0];
        let plus = Rect::new(sessions.right() - 4, sessions.y, 3, 1);
        assert!(close.intersection(plus).is_empty());
        assert_eq!(
            terminal.backend().buffer()[(close.x + 1, close.y)].symbol(),
            "×"
        );
        assert_eq!(
            terminal.backend().buffer()[(plus.x + 1, plus.y)].symbol(),
            "+"
        );
        let add = dock_mouse(MouseEventKind::Down(MouseButton::Left), plus.x + 1, plus.y);
        assert_eq!(dock.handle_mouse(&add), (false, None));
        assert_eq!(
            sidebar.handle_mouse(&add),
            Some(crate::agent_sidebar::SidebarEvent::OpenPicker)
        );
        let hide = dock_mouse(
            MouseEventKind::Down(MouseButton::Left),
            close.x + 1,
            close.y,
        );
        assert_eq!(
            dock.handle_mouse(&hide),
            (true, Some(DockAction::ToggleSessions))
        );
    }

    #[test]
    fn dock_drag_persists_on_release_and_invalidates_removed_divider() {
        for side in [config::SidebarSide::Left, config::SidebarSide::Right] {
            let mut dock = test_dock();
            dock.side = side;
            let layout = dock.layout(Rect::new(0, 0, 120, 40), Mode::Chat, true);
            let edge = layout.width_edge;
            assert_eq!(
                dock.handle_mouse(&dock_mouse(
                    MouseEventKind::Down(MouseButton::Left),
                    edge.x,
                    edge.y
                )),
                (true, None)
            );
            let column = if side == config::SidebarSide::Left {
                29
            } else {
                90
            };
            assert_eq!(
                dock.handle_mouse(&dock_mouse(
                    MouseEventKind::Drag(MouseButton::Left),
                    column,
                    edge.y
                )),
                (true, None)
            );
            assert_eq!(dock.width, 30);
            assert_eq!(
                dock.handle_mouse(&dock_mouse(
                    MouseEventKind::Up(MouseButton::Left),
                    column,
                    edge.y
                )),
                (true, Some(DockAction::PersistWidth(30)))
            );
            assert!(dock.capture.is_none());
            let layout = dock.layout(Rect::new(0, 0, 120, 40), Mode::Chat, true);
            let divider = layout.plan_divider;
            dock.handle_mouse(&dock_mouse(
                MouseEventKind::Down(MouseButton::Left),
                divider.x + 2,
                divider.y,
            ));
            assert_eq!(dock.capture, Some(DockCapture::QueuePlanHeight));
            dock.layout(Rect::new(0, 0, 120, 40), Mode::Chat, false);
            assert!(dock.capture.is_none());
        }
    }

    #[test]
    fn disconnected_terminal_projection_is_neutral() {
        let working = crate::turn_status::TurnStatus::Working;
        let blocked = crate::turn_status::TurnStatus::WaitingForApproval;
        let disconnected = ConnectionState::Disconnected {
            reason: "test disconnect".to_string(),
        };

        let (status, agent) = terminal_status_for_connection(
            &disconnected,
            [
                (Some(&working), Some("chat")),
                (Some(&blocked), Some("code")),
            ],
        );

        assert!(status.is_none());
        assert!(agent.is_none());
    }

    #[test]
    fn connected_terminal_projection_keeps_urgent_session() {
        let working = crate::turn_status::TurnStatus::Working;
        let blocked = crate::turn_status::TurnStatus::WaitingForApproval;

        let (status, agent) = terminal_status_for_connection(
            &ConnectionState::Connected,
            [
                (Some(&working), Some("chat")),
                (Some(&blocked), Some("code")),
            ],
        );

        assert!(matches!(
            status,
            Some(crate::turn_status::TurnStatus::WaitingForApproval)
        ));
        assert_eq!(agent, Some("code"));
    }

    #[tokio::test]
    async fn sidebar_session_drag_routes_outside_release_and_keeps_order_after_reconnect() {
        let (tx, _rx) = mpsc::channel::<String>(1);
        let client = Arc::new(RpcClient::with_rpc(Arc::new(
            crate::jsonrpc::RpcOutbound::new(tx),
        )));
        let mut chat_pane = chat::Chat::new(client.clone(), chat::PaneKind::Chat);
        let mut acp_pane = acp::Acp::new(client.clone());
        chat_pane.activate_session_for_test("chat-session");
        acp_pane.activate_session_for_test("code-session");
        let mut sidebar = crate::agent_sidebar::AgentSidebar::new();
        let area = Rect::new(70, 0, 30, 10);
        let ctx = crate::agent_sidebar::SidebarCtx {
            active_pane: Some(chat::PaneKind::Chat),
            quickstart_active: false,
            connected: true,
        };
        let mut rows = acp_pane.session_summaries();
        rows.extend(chat_pane.session_summaries());
        let mut terminal = ratatui::Terminal::new(ratatui::backend::TestBackend::new(100, 20))
            .expect("test terminal");
        terminal
            .draw(|frame| sidebar.draw(frame, area, &rows, &ctx))
            .unwrap();

        let mut mouse = crossterm::event::MouseEvent {
            kind: MouseEventKind::Down(MouseButton::Left),
            column: area.x + 1,
            row: area.y + 1,
            modifiers: KeyModifiers::NONE,
        };
        let (consumed, event) = route_agent_sidebar_mouse(
            Mode::Chat,
            &mut chat_pane,
            &mut acp_pane,
            &mut sidebar,
            &mouse,
        );
        assert!(consumed);
        assert_eq!(
            event,
            Some(crate::agent_sidebar::SidebarEvent::FocusSession {
                pane: chat::PaneKind::Acp,
                session_id: "code-session".into(),
            })
        );
        terminal
            .draw(|frame| sidebar.draw(frame, area, &rows, &ctx))
            .unwrap();
        mouse.kind = MouseEventKind::Drag(MouseButton::Left);
        mouse.row += 1;
        assert!(sidebar.captures_mouse(&mouse));
        let (consumed, event) = route_agent_sidebar_mouse(
            Mode::Chat,
            &mut chat_pane,
            &mut acp_pane,
            &mut sidebar,
            &mouse,
        );
        assert!(consumed);
        assert_eq!(event, None);
        mouse.kind = MouseEventKind::Up(MouseButton::Left);
        mouse.column = 20; // Release over the conversation, outside Sessions.
        let (consumed, event) = route_agent_sidebar_mouse(
            Mode::Chat,
            &mut chat_pane,
            &mut acp_pane,
            &mut sidebar,
            &mouse,
        );
        assert!(consumed);
        assert_eq!(event, None);
        assert!(!sidebar.captures_mouse(&mouse));

        // Use the same constructors and handoff as build_panes on reconnect.
        let mut reconnected_chat = chat::Chat::new(client.clone(), chat::PaneKind::Chat);
        reconnected_chat.set_resume_sessions(chat_pane.resume_entries());
        let mut reconnected_code = acp::Acp::new(client);
        reconnected_code.set_resume_sessions(acp_pane.resume_entries());
        let mut rows = reconnected_code.session_summaries();
        rows.extend(reconnected_chat.session_summaries());
        terminal
            .draw(|frame| sidebar.draw(frame, area, &rows, &ctx))
            .unwrap();
        mouse.kind = MouseEventKind::Down(MouseButton::Left);
        mouse.column = area.x + 1;
        mouse.row = area.y + 1;
        let (_, event) = route_agent_sidebar_mouse(
            Mode::Chat,
            &mut reconnected_chat,
            &mut reconnected_code,
            &mut sidebar,
            &mouse,
        );
        assert_eq!(
            event,
            Some(crate::agent_sidebar::SidebarEvent::FocusSession {
                pane: chat::PaneKind::Chat,
                session_id: "chat-session".into(),
            })
        );
    }

    #[tokio::test]
    async fn sidebar_mouse_up_finishes_chat_and_code_transcript_drags() {
        let (tx, _rx) = mpsc::channel::<String>(1);
        let client = Arc::new(RpcClient::with_rpc(Arc::new(
            crate::jsonrpc::RpcOutbound::new(tx),
        )));
        let mut chat_pane = chat::Chat::new(client.clone(), chat::PaneKind::Chat);
        let mut acp_pane = acp::Acp::new(client);
        chat_pane.activate_session_for_test("chat-session");
        acp_pane.activate_session_for_test("code-session");

        let mut sidebar = crate::agent_sidebar::AgentSidebar::new();
        let sidebar_area = test_dock()
            .layout(Rect::new(0, 0, 100, 20), Mode::Chat, false)
            .sessions
            .expect("default sidebar is visible");
        let backend = ratatui::backend::TestBackend::new(100, 20);
        let mut terminal = ratatui::Terminal::new(backend).expect("test terminal");
        terminal
            .draw(|frame| {
                sidebar.draw(
                    frame,
                    sidebar_area,
                    &[],
                    &crate::agent_sidebar::SidebarCtx {
                        active_pane: Some(chat::PaneKind::Chat),
                        quickstart_active: false,
                        connected: true,
                    },
                )
            })
            .expect("draw sidebar hit geometry");

        let mouse = crossterm::event::MouseEvent {
            kind: MouseEventKind::Up(MouseButton::Left),
            column: sidebar_area.x,
            row: sidebar_area.y,
            modifiers: KeyModifiers::NONE,
        };

        chat_pane.begin_transcript_drag_for_test(false);
        let (consumed, event) = route_agent_sidebar_mouse(
            Mode::Chat,
            &mut chat_pane,
            &mut acp_pane,
            &mut sidebar,
            &mouse,
        );
        assert!(consumed);
        assert_eq!(event, None);
        assert_eq!(chat_pane.transcript_selected_text_for_test(), None);

        chat_pane.begin_transcript_drag_for_test(true);
        let (consumed, event) = route_agent_sidebar_mouse(
            Mode::Chat,
            &mut chat_pane,
            &mut acp_pane,
            &mut sidebar,
            &mouse,
        );
        assert!(consumed);
        assert_eq!(event, None);
        assert_eq!(
            chat_pane.transcript_selected_text_for_test().as_deref(),
            Some("hello")
        );

        acp_pane.begin_transcript_drag_for_test(false);
        let (consumed, event) = route_agent_sidebar_mouse(
            Mode::Acp,
            &mut chat_pane,
            &mut acp_pane,
            &mut sidebar,
            &mouse,
        );
        assert!(consumed);
        assert_eq!(event, None);
        assert_eq!(acp_pane.transcript_selected_text_for_test(), None);

        acp_pane.begin_transcript_drag_for_test(true);
        let (consumed, event) = route_agent_sidebar_mouse(
            Mode::Acp,
            &mut chat_pane,
            &mut acp_pane,
            &mut sidebar,
            &mouse,
        );
        assert!(consumed);
        assert_eq!(event, None);
        assert_eq!(
            acp_pane.transcript_selected_text_for_test().as_deref(),
            Some("hello")
        );
    }

    fn inbound_elicitation(request_id: &str, session_id: &str) -> crate::client::RpcInboundRequest {
        crate::client::RpcInboundRequest {
            id: serde_json::json!(request_id),
            method: "elicitation/create".to_string(),
            params: serde_json::json!({
                "sessionId": session_id,
                "mode": "form",
                "message": "Pick one",
                "requestedSchema": {
                    "type": "object",
                    "properties": {
                        "choice": {
                            "type": "string",
                            "oneOf": [
                                { "const": "choice-0", "title": "Yes" },
                                { "const": "choice-1", "title": "No" }
                            ]
                        }
                    }
                }
            }),
        }
    }

    #[tokio::test]
    async fn inbound_elicitation_is_installed_only_by_owning_pane() {
        let (tx, mut writer_rx) = mpsc::channel::<String>(16);
        let outbound = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let client = Arc::new(RpcClient::with_rpc(outbound));
        let router = InboundRequestRouter::new(client.clone()).unwrap();
        let mut chat_pane = chat::Chat::new(client.clone(), chat::PaneKind::Chat);
        let mut acp_pane = acp::Acp::new(client);
        chat_pane.activate_session_for_test("chat-session");
        acp_pane.activate_session_for_test("code-session");

        let deferred = router.route(
            inbound_elicitation("e1", "chat-session"),
            &mut chat_pane,
            &mut acp_pane,
        );

        assert!(deferred.is_none());
        assert!(chat_pane.has_pending_elicitation_for_test());
        assert!(!acp_pane.has_pending_elicitation_for_test());
        tokio::task::yield_now().await;
        assert!(
            writer_rx.try_recv().is_err(),
            "the non-owner pane must never cancel another pane's request"
        );
    }

    #[tokio::test]
    async fn orphaned_elicitation_is_cancelled_once_after_grace() {
        let (tx, mut writer_rx) = mpsc::channel::<String>(16);
        let outbound = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let client = Arc::new(RpcClient::with_rpc(outbound));
        let mut router = InboundRequestRouter::new(client.clone()).unwrap();
        let mut chat_pane = chat::Chat::new(client.clone(), chat::PaneKind::Chat);
        let mut acp_pane = acp::Acp::new(client);
        router.deferred.push(DeferredInboundRequest {
            request: inbound_elicitation("e-orphan", "missing-session"),
            first_seen: Instant::now() - (ELICITATION_ROUTE_GRACE + Duration::from_millis(1)),
        });

        router.drain(&mut chat_pane, &mut acp_pane);
        let line = tokio::time::timeout(Duration::from_secs(1), writer_rx.recv())
            .await
            .expect("expired orphan should be cancelled")
            .expect("writer channel remains open");
        let response: serde_json::Value = serde_json::from_str(&line).expect("valid JSON-RPC");
        assert_eq!(response["id"], "e-orphan");
        assert_eq!(response["result"]["action"], "cancel");
        assert!(router.deferred.is_empty());

        router.drain(&mut chat_pane, &mut acp_pane);
        tokio::task::yield_now().await;
        assert!(
            writer_rx.try_recv().is_err(),
            "a centrally handled orphan must not be answered twice"
        );
    }

    #[tokio::test]
    async fn router_replacement_resolves_deferred_and_queued_requests_once() {
        let (tx, mut writer_rx) = mpsc::channel::<String>(16);
        let outbound = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let client = Arc::new(RpcClient::with_rpc(outbound));
        let (inbound_tx, inbound_rx) = mpsc::unbounded_channel();
        let mut router = InboundRequestRouter {
            rpc: client,
            rx: inbound_rx,
            deferred: Vec::new(),
        };
        router.deferred.push(DeferredInboundRequest {
            request: inbound_elicitation("e-deferred", "missing-session"),
            first_seen: Instant::now(),
        });
        let release_during_retirement = tokio::spawn(async move {
            tokio::task::yield_now().await;
            inbound_tx
                .send(inbound_elicitation(
                    "e-arrived-during-retirement",
                    "missing-session",
                ))
                .unwrap();
        });

        router.cancel_pending().await;
        release_during_retirement.await.unwrap();
        let mut ids = Vec::new();
        for _ in 0..2 {
            let line = tokio::time::timeout(Duration::from_secs(1), writer_rx.recv())
                .await
                .expect("router handoff must answer every owned request")
                .expect("writer channel remains open");
            let response: serde_json::Value = serde_json::from_str(&line).expect("valid response");
            ids.push(response["id"].as_str().unwrap().to_string());
            assert_eq!(response["result"]["action"], "cancel");
        }
        ids.sort();
        assert_eq!(ids, vec!["e-arrived-during-retirement", "e-deferred"]);
        assert!(router.deferred.is_empty());

        router.cancel_pending().await;
        assert!(
            writer_rx.try_recv().is_err(),
            "a retired router must not answer the same request twice"
        );
    }

    #[test]
    fn quickstart_return_tracks_every_entry_surface() {
        let mut return_mode = Mode::Dashboard;
        remember_quickstart_return(Mode::Chat, Mode::Quickstart, &mut return_mode);
        assert_eq!(
            return_mode,
            Mode::Chat,
            "keyboard cycling records its source"
        );

        remember_quickstart_return(Mode::Acp, Mode::Quickstart, &mut return_mode);
        assert_eq!(
            return_mode,
            Mode::Acp,
            "mode-bar clicks record their source"
        );

        remember_quickstart_return(Mode::Quickstart, Mode::Quickstart, &mut return_mode);
        assert_eq!(
            return_mode,
            Mode::Acp,
            "re-entry never points back to Quickstart"
        );
        remember_quickstart_return(Mode::Logs, Mode::Sop, &mut return_mode);
        assert_eq!(
            return_mode,
            Mode::Acp,
            "ordinary tab changes do not rewrite it"
        );
    }

    fn mouse_event(kind: MouseEventKind, column: u16, row: u16) -> Event {
        mouse_event_with_modifiers(kind, column, row, KeyModifiers::NONE)
    }

    fn mouse_event_with_modifiers(
        kind: MouseEventKind,
        column: u16,
        row: u16,
        modifiers: KeyModifiers,
    ) -> Event {
        Event::Mouse(crossterm::event::MouseEvent {
            kind,
            column,
            row,
            modifiers,
        })
    }

    fn key_event(code: KeyCode) -> Event {
        Event::Key(KeyEvent::new(code, KeyModifiers::NONE))
    }

    fn decode_sgr_sequence(sequence: &str) -> Vec<Event> {
        let mut decoder = SgrMouseEventDecoder::default();
        decoder.feed(key_event(KeyCode::Esc));
        for character in sequence.chars() {
            decoder.feed(key_event(KeyCode::Char(character)));
        }
        std::iter::from_fn(|| decoder.next()).collect()
    }

    fn split_sgr_events(sequence: &str) -> VecDeque<Event> {
        sequence
            .chars()
            .map(|character| key_event(KeyCode::Char(character)))
            .collect()
    }

    #[test]
    fn coalesces_contiguous_mouse_drags_to_latest_position() {
        let first = mouse_event(
            MouseEventKind::Drag(crossterm::event::MouseButton::Left),
            1,
            2,
        );
        let mut queued = VecDeque::from([
            mouse_event(
                MouseEventKind::Drag(crossterm::event::MouseButton::Left),
                4,
                5,
            ),
            mouse_event(
                MouseEventKind::Drag(crossterm::event::MouseButton::Left),
                8,
                9,
            ),
        ]);

        let (current, pending) =
            coalesce_mouse_drag(first, || Ok(queued.pop_front())).expect("coalesce drag events");

        assert_eq!(
            current,
            mouse_event(
                MouseEventKind::Drag(crossterm::event::MouseButton::Left),
                8,
                9
            )
        );
        assert_eq!(pending, None);
    }

    #[test]
    fn coalescing_preserves_first_non_drag_event() {
        let first = mouse_event(
            MouseEventKind::Drag(crossterm::event::MouseButton::Left),
            1,
            2,
        );
        let mouse_up = mouse_event(
            MouseEventKind::Up(crossterm::event::MouseButton::Left),
            8,
            9,
        );
        let mut queued = VecDeque::from([
            mouse_event(
                MouseEventKind::Drag(crossterm::event::MouseButton::Left),
                8,
                9,
            ),
            mouse_up.clone(),
        ]);

        let (current, pending) =
            coalesce_mouse_drag(first, || Ok(queued.pop_front())).expect("coalesce drag events");

        assert_eq!(
            current,
            mouse_event(
                MouseEventKind::Drag(crossterm::event::MouseButton::Left),
                8,
                9
            )
        );
        assert_eq!(pending, Some(mouse_up));
    }

    #[test]
    fn coalescing_bounds_each_drag_batch_and_preserves_following_input() {
        let first = mouse_event(
            MouseEventKind::Drag(crossterm::event::MouseButton::Left),
            0,
            0,
        );
        let mouse_up = mouse_event(
            MouseEventKind::Up(crossterm::event::MouseButton::Left),
            MAX_COALESCED_MOUSE_DRAGS as u16,
            0,
        );
        let key = Event::Key(KeyEvent::new(KeyCode::Char('x'), KeyModifiers::NONE));
        let mut queued: VecDeque<Event> = (1..=MAX_COALESCED_MOUSE_DRAGS)
            .map(|column| {
                mouse_event(
                    MouseEventKind::Drag(crossterm::event::MouseButton::Left),
                    column as u16,
                    0,
                )
            })
            .chain([mouse_up.clone(), key.clone()])
            .collect();

        let (current, pending) =
            coalesce_mouse_drag(first, || Ok(queued.pop_front())).expect("coalesce first batch");

        assert_eq!(
            current,
            mouse_event(
                MouseEventKind::Drag(crossterm::event::MouseButton::Left),
                MAX_COALESCED_MOUSE_DRAGS.saturating_sub(1) as u16,
                0,
            )
        );
        assert_eq!(pending, None);

        let next = queued.pop_front().expect("next drag remains queued");
        let (current, pending) =
            coalesce_mouse_drag(next, || Ok(queued.pop_front())).expect("coalesce next batch");

        assert_eq!(
            current,
            mouse_event(
                MouseEventKind::Drag(crossterm::event::MouseButton::Left),
                MAX_COALESCED_MOUSE_DRAGS as u16,
                0,
            )
        );
        assert_eq!(pending, Some(mouse_up));
        assert_eq!(queued.pop_front(), Some(key));
    }

    #[test]
    fn non_drag_event_passes_through_without_reading_ahead() {
        let first = Event::Key(KeyEvent::new(KeyCode::Char('x'), KeyModifiers::NONE));
        let mut read_ahead = false;

        let (current, pending) = coalesce_mouse_drag(first.clone(), || {
            read_ahead = true;
            Ok(None)
        })
        .expect("leave non-drag event unchanged");

        assert_eq!(current, first);
        assert_eq!(pending, None);
        assert!(!read_ahead);
    }

    #[test]
    fn split_sgr_mouse_decoder_decodes_vertical_wheel_events() {
        for (sequence, kind) in [
            ("[<64;32;17M", MouseEventKind::ScrollUp),
            ("[<65;32;17M", MouseEventKind::ScrollDown),
        ] {
            assert_eq!(
                decode_sgr_sequence(sequence),
                vec![mouse_event(kind, 31, 16)]
            );
        }
    }

    #[test]
    fn split_sgr_mouse_decoder_decodes_click_and_release_events() {
        for (sequence, kind) in [
            ("[<0;3;4M", MouseEventKind::Down(MouseButton::Left)),
            ("[<1;3;4M", MouseEventKind::Down(MouseButton::Middle)),
            ("[<2;3;4M", MouseEventKind::Down(MouseButton::Right)),
            ("[<3;3;4M", MouseEventKind::Up(MouseButton::Left)),
            ("[<0;3;4m", MouseEventKind::Up(MouseButton::Left)),
        ] {
            assert_eq!(decode_sgr_sequence(sequence), vec![mouse_event(kind, 2, 3)]);
        }
    }

    #[test]
    fn split_sgr_mouse_decoder_decodes_drag_and_movement_events() {
        for (sequence, kind) in [
            ("[<32;5;6M", MouseEventKind::Drag(MouseButton::Left)),
            ("[<33;5;6M", MouseEventKind::Drag(MouseButton::Middle)),
            ("[<34;5;6M", MouseEventKind::Drag(MouseButton::Right)),
            ("[<35;5;6M", MouseEventKind::Moved),
        ] {
            assert_eq!(decode_sgr_sequence(sequence), vec![mouse_event(kind, 4, 5)]);
        }
    }

    #[test]
    fn split_sgr_mouse_decoder_decodes_horizontal_wheel_events() {
        for (sequence, kind) in [
            ("[<66;10;11M", MouseEventKind::ScrollLeft),
            ("[<67;10;11M", MouseEventKind::ScrollRight),
        ] {
            assert_eq!(
                decode_sgr_sequence(sequence),
                vec![mouse_event(kind, 9, 10)]
            );
        }
    }

    #[test]
    fn split_sgr_mouse_decoder_preserves_modifiers_and_coordinates() {
        assert_eq!(
            decode_sgr_sequence("[<93;1;2M"),
            vec![mouse_event_with_modifiers(
                MouseEventKind::ScrollDown,
                0,
                1,
                KeyModifiers::SHIFT | KeyModifiers::ALT | KeyModifiers::CONTROL,
            )]
        );
    }

    #[test]
    fn split_sgr_mouse_decoder_accepts_optional_delimiter_and_lowercase_release() {
        assert_eq!(
            decode_sgr_sequence("[<64;32;17;M"),
            vec![mouse_event(MouseEventKind::ScrollUp, 31, 16)]
        );
        assert_eq!(
            decode_sgr_sequence("[<0;32;17;m"),
            vec![mouse_event(MouseEventKind::Up(MouseButton::Left), 31, 16)]
        );
    }

    #[test]
    fn split_sgr_mouse_decoder_rejects_multiple_empty_trailing_fields() {
        let sequence = "[<64;32;17;;M";
        let expected: Vec<Event> = std::iter::once(key_event(KeyCode::Esc))
            .chain(
                sequence
                    .chars()
                    .map(|character| key_event(KeyCode::Char(character))),
            )
            .collect();

        assert_eq!(decode_sgr_sequence(sequence), expected);
    }

    #[test]
    fn drag_read_ahead_reassembles_split_sgr_drag_without_leaking_escape() {
        let first_drag = mouse_event(MouseEventKind::Drag(MouseButton::Left), 4, 5);
        let latest_drag = mouse_event(MouseEventKind::Drag(MouseButton::Left), 7, 8);
        let following_key = key_event(KeyCode::Char('x'));
        let mut queued = VecDeque::from([key_event(KeyCode::Esc)]);
        queued.extend(split_sgr_events("[<32;8;9M"));
        queued.push_back(following_key.clone());
        let mut decoder = SgrMouseEventDecoder::default();

        let (current, pending) = coalesce_mouse_drag(first_drag, || {
            decoder.read_ready_with(|| Ok(queued.pop_front()))
        })
        .expect("reassemble SGR drag during read-ahead");

        assert_eq!(current, latest_drag);
        assert_eq!(pending, Some(following_key.clone()));
        assert!(decoder.candidate.is_empty());
        assert!(queued.is_empty());

        decoder.push_front(pending.expect("preserve following input"));
        assert_eq!(decoder.next(), Some(following_key));
    }

    #[test]
    fn invalid_escape_prefix_is_replayed_in_order() {
        let original = vec![
            Event::Key(KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE)),
            Event::Key(KeyEvent::new(KeyCode::Char('['), KeyModifiers::NONE)),
            Event::Key(KeyEvent::new(KeyCode::Char('x'), KeyModifiers::NONE)),
        ];
        let mut decoder = SgrMouseEventDecoder::default();
        for event in original.iter().cloned() {
            decoder.feed(event);
        }

        let decoded: Vec<Event> = std::iter::from_fn(|| decoder.next()).collect();

        assert_eq!(decoded, original);
    }

    #[test]
    fn incomplete_escape_flush_preserves_the_escape_key() {
        let escape = Event::Key(KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE));
        let mut decoder = SgrMouseEventDecoder::default();
        decoder.feed(escape.clone());

        assert_eq!(decoder.next(), None);
        assert!(decoder.flush_candidate());
        assert_eq!(decoder.next(), Some(escape));
    }

    #[test]
    fn delayed_input_flushes_an_expired_escape_before_the_next_tick() {
        let escape = Event::Key(KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE));
        let mut decoder = SgrMouseEventDecoder::default();
        decoder.feed(escape.clone());
        decoder.candidate_started_at = Some(Instant::now() - SGR_MOUSE_SEQUENCE_TIMEOUT);

        assert_eq!(decoder.poll_timeout(), Duration::ZERO);
        assert!(decoder.flush_timed_out_candidate());
        assert_eq!(decoder.next(), Some(escape));
    }

    #[test]
    fn confirmation_modals_consume_text_and_path_paste_before_pane_dispatch() {
        let paste_payloads = ["hidden composer text", "/tmp/hidden-attachment.txt"];
        let modal_states = [(true, false), (false, true), (true, true)];

        for (reload_confirm, quit_confirm) in modal_states {
            for payload in paste_payloads {
                // Both plain text and path-shaped paste must stop at the
                // application modal boundary before any pane sees the value.
                let event = Event::Paste(payload.to_owned());
                assert!(confirmation_modal_owns_event(
                    &event,
                    reload_confirm,
                    quit_confirm
                ));
            }
        }

        assert!(!confirmation_modal_owns_event(
            &Event::Paste("visible composer text".to_owned()),
            false,
            false
        ));
        assert!(!confirmation_modal_owns_event(
            &Event::Key(KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE)),
            true,
            false
        ));
    }

    #[test]
    fn quit_confirmation_renders_the_resolved_quit_binding() {
        use std::collections::HashMap;

        use crate::keymap::{Chord, overrides};
        use ratatui::{Terminal, backend::TestBackend};

        let _guard = overrides::TEST_GUARD
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        overrides::set_active(HashMap::from([(
            GlobalAction::TAG.to_string(),
            HashMap::from([(
                "quit".to_string(),
                vec![Chord::with(KeyCode::Char('q'), KeyModifiers::ALT)],
            )]),
        )]));

        let backend = TestBackend::new(80, 12);
        let mut terminal = Terminal::new(backend).expect("test terminal");
        terminal
            .draw(|frame| draw_quit_confirm_modal(frame, frame.area()))
            .expect("draw quit confirmation");

        let rendered: String = terminal
            .backend()
            .buffer()
            .content()
            .iter()
            .map(|cell| cell.symbol())
            .collect();
        let configured = Chord::with(KeyCode::Char('q'), KeyModifiers::ALT).display();
        let default = Chord::ctrl('c').display();
        assert!(
            rendered.contains(&format!("{configured} = quit")),
            "rendered modal should advertise configured binding: {rendered:?}"
        );
        assert!(
            !rendered.contains(&format!("{default} = quit")),
            "rendered modal should not advertise default binding: {rendered:?}"
        );
        overrides::reset();
    }

    #[test]
    fn chrome_process_summary_shows_cpu_loading_without_health() {
        let cpu = crate::i18n::t("zc-chrome-summary-cpu");
        let loading = crate::i18n::t("zc-chrome-summary-loading");

        assert_eq!(process_stats_summary(None), format!(" {cpu}:{loading}"));
    }

    #[test]
    fn chrome_process_summary_shows_ram_and_cpu_values() {
        let ram = crate::i18n::t("zc-chrome-summary-ram");
        let cpu = crate::i18n::t("zc-chrome-summary-cpu");
        let health = serde_json::json!({
            "process": {
                "rss_bytes": 1_048_576_u64,
                "system_ram_total_bytes": 4_194_304_u64,
                "cpu_percent": 12.345_f64
            }
        });

        assert_eq!(
            process_stats_summary(Some(&health)),
            format!(" {ram}:1.0M(25%) {cpu}:12.3%")
        );
    }

    #[test]
    fn chrome_process_summary_keeps_cpu_loading_until_sample_exists() {
        let ram = crate::i18n::t("zc-chrome-summary-ram");
        let cpu = crate::i18n::t("zc-chrome-summary-cpu");
        let loading = crate::i18n::t("zc-chrome-summary-loading");
        let health = serde_json::json!({
            "process": {
                "rss_bytes": 1_048_576_u64,
                "system_ram_total_bytes": 4_194_304_u64
            }
        });

        assert_eq!(
            process_stats_summary(Some(&health)),
            format!(" {ram}:1.0M(25%) {cpu}:{loading}")
        );
    }

    #[tokio::test]
    async fn chrome_status_tick_starts_refresh_without_waiting_for_rpc_response() {
        let (tx, mut rx) = mpsc::channel::<String>(1);
        let rpc = Arc::new(RpcClient::with_rpc(Arc::new(
            crate::jsonrpc::RpcOutbound::new(tx),
        )));
        let mut chrome_status = ChromeStatus::default();

        let start = Instant::now();
        chrome_status.tick(&rpc);

        assert!(
            start.elapsed() < Duration::from_millis(50),
            "tick must not wait for the status response"
        );
        assert!(
            chrome_status.refresh_in_flight,
            "tick should record that the background refresh is still pending"
        );

        let raw = tokio::time::timeout(Duration::from_millis(200), rx.recv())
            .await
            .expect("status refresh should send a request")
            .expect("request channel should stay open");
        let request: serde_json::Value = serde_json::from_str(&raw).unwrap();
        assert_eq!(request["method"], crate::client::method::STATUS);
    }

    #[test]
    fn chrome_status_failed_health_refresh_clears_previous_snapshot() {
        let (tx, rx) = mpsc::unbounded_channel();
        let mut chrome_status = ChromeStatus {
            health: Some(serde_json::json!({
                "components": {"daemon": {"status": "ok"}}
            })),
            refresh_in_flight: true,
            refresh_rx: Some(rx),
            ..Default::default()
        };
        assert!(
            tx.send(ChromeStatusSnapshot {
                status: None,
                health: None,
            })
            .is_ok()
        );

        chrome_status.drain_completed_refresh();

        assert!(chrome_status.health.is_none());
        assert!(!chrome_status.refresh_in_flight);
        assert!(chrome_status.refresh_rx.is_none());
    }

    #[tokio::test]
    async fn mode_switch_to_sop_returns_before_a_withheld_list_response() {
        let (tx, mut rx) = mpsc::channel::<String>(1);
        let outbound = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let rpc = Arc::new(RpcClient::with_rpc(Arc::clone(&outbound)));
        let reconnect_state = Arc::new(Mutex::new(CrossReconnectState::default()));
        let mut mode = Mode::Config;
        let conn_state = PostPollDispatchState::new(ConnectionState::Connected);
        let mut dashboard_pane = dashboard::Dashboard::new(Arc::clone(&rpc), "test", false);
        let mut quickstart =
            quickstart_pane::QuickstartPane::new(Arc::clone(&rpc), reconnect_state);
        let mut acp_pane = acp::Acp::new(Arc::clone(&rpc));
        let mut chat_pane = chat::Chat::new(Arc::clone(&rpc), chat::PaneKind::Chat);
        let mut sop_pane = sop_pane::SopPane::new(rpc);

        tokio::time::timeout(
            Duration::from_millis(50),
            switch_mode(
                &mut mode,
                Mode::Sop,
                &conn_state,
                &mut dashboard_pane,
                &mut quickstart,
                &mut acp_pane,
                &mut chat_pane,
                &mut sop_pane,
            ),
        )
        .await
        .expect("entering SOP mode must not await the list response");
        assert_eq!(mode, Mode::Sop);

        let raw = tokio::time::timeout(Duration::from_millis(200), rx.recv())
            .await
            .expect("mode entry should send a list request")
            .expect("RPC writer should remain connected");
        let request: serde_json::Value = serde_json::from_str(&raw).unwrap();
        assert_eq!(request["method"], crate::client::method::SOPS_LIST);
    }

    #[tokio::test]
    async fn sop_reentry_discards_pre_blur_list_and_requests_one_fresh_result() {
        let (tx, mut rx) = mpsc::channel::<String>(4);
        let outbound = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let rpc = Arc::new(RpcClient::with_rpc(Arc::clone(&outbound)));
        let reconnect_state = Arc::new(Mutex::new(CrossReconnectState::default()));
        let mut mode = Mode::Config;
        let conn_state = PostPollDispatchState::new(ConnectionState::Connected);
        let mut dashboard_pane = dashboard::Dashboard::new(Arc::clone(&rpc), "test", false);
        let mut quickstart =
            quickstart_pane::QuickstartPane::new(Arc::clone(&rpc), reconnect_state);
        let mut acp_pane = acp::Acp::new(Arc::clone(&rpc));
        let mut chat_pane = chat::Chat::new(Arc::clone(&rpc), chat::PaneKind::Chat);
        let mut sop_pane = sop_pane::SopPane::new(rpc);

        switch_mode(
            &mut mode,
            Mode::Sop,
            &conn_state,
            &mut dashboard_pane,
            &mut quickstart,
            &mut acp_pane,
            &mut chat_pane,
            &mut sop_pane,
        )
        .await;
        let first_raw = rx.recv().await.expect("first list request");
        let first_request: serde_json::Value = serde_json::from_str(&first_raw).unwrap();
        let first_id = first_request["id"].as_str().unwrap().to_string();

        switch_mode(
            &mut mode,
            Mode::Config,
            &conn_state,
            &mut dashboard_pane,
            &mut quickstart,
            &mut acp_pane,
            &mut chat_pane,
            &mut sop_pane,
        )
        .await;
        switch_mode(
            &mut mode,
            Mode::Sop,
            &conn_state,
            &mut dashboard_pane,
            &mut quickstart,
            &mut acp_pane,
            &mut chat_pane,
            &mut sop_pane,
        )
        .await;
        assert!(
            rx.try_recv().is_err(),
            "single-flight re-entry must wait for the older request to settle"
        );

        outbound.dispatch_response(
            &first_id,
            Some(serde_json::json!([{ "name": "old" }])),
            None,
        );
        let mut fresh_id = None;
        for _ in 0..100 {
            tokio::task::yield_now().await;
            sop_pane.tick();
            while let Ok(raw) = rx.try_recv() {
                let request: serde_json::Value = serde_json::from_str(&raw).unwrap();
                if request["method"] == crate::client::method::SOPS_LIST {
                    fresh_id = request["id"].as_str().map(String::from);
                }
            }
            if fresh_id.is_some() {
                break;
            }
        }
        assert_eq!(
            sop_pane.selected_name(),
            None,
            "the pre-blur response must not become authoritative after re-entry"
        );
        let fresh_id = fresh_id.expect("fresh list request after re-entry");
        assert_ne!(fresh_id, first_id);

        outbound.dispatch_response(
            &fresh_id,
            Some(serde_json::json!([{ "name": "fresh" }])),
            None,
        );
        for _ in 0..100 {
            tokio::task::yield_now().await;
            sop_pane.tick();
            if sop_pane.selected_name() == Some("fresh") {
                break;
            }
        }
        assert_eq!(sop_pane.selected_name(), Some("fresh"));
        while let Ok(raw) = rx.try_recv() {
            let request: serde_json::Value = serde_json::from_str(&raw).unwrap();
            assert_ne!(
                request["method"],
                crate::client::method::SOPS_LIST,
                "only one authoritative follow-up may be sent"
            );
        }
    }

    #[tokio::test]
    async fn mode_switch_leaves_quickstart_for_sop_before_withheld_responses() {
        let (tx, mut rx) = mpsc::channel::<String>(1);
        let outbound = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let rpc = Arc::new(RpcClient::with_rpc(Arc::clone(&outbound)));
        let reconnect_state = Arc::new(Mutex::new(CrossReconnectState::default()));
        let mut mode = Mode::Quickstart;
        let conn_state = PostPollDispatchState::new(ConnectionState::Connected);
        let mut dashboard_pane = dashboard::Dashboard::new(Arc::clone(&rpc), "test", false);
        let mut quickstart =
            quickstart_pane::QuickstartPane::new(Arc::clone(&rpc), reconnect_state);
        let mut acp_pane = acp::Acp::new(Arc::clone(&rpc));
        let mut chat_pane = chat::Chat::new(Arc::clone(&rpc), chat::PaneKind::Chat);
        let mut sop_pane = sop_pane::SopPane::new(rpc);

        tokio::time::timeout(
            Duration::from_millis(50),
            switch_mode(
                &mut mode,
                Mode::Sop,
                &conn_state,
                &mut dashboard_pane,
                &mut quickstart,
                &mut acp_pane,
                &mut chat_pane,
                &mut sop_pane,
            ),
        )
        .await
        .expect("leaving Quickstart must not await dismissal or SOP refresh");
        assert_eq!(mode, Mode::Sop);

        let mut methods = Vec::new();
        for _ in 0..2 {
            let raw = tokio::time::timeout(Duration::from_millis(200), rx.recv())
                .await
                .expect("mode switch should send both background requests")
                .expect("RPC writer should remain connected");
            let request: serde_json::Value = serde_json::from_str(&raw).unwrap();
            let method = request["method"].as_str().unwrap().to_string();
            if method == crate::client::method::QUICKSTART_DISMISS {
                assert_eq!(request["params"]["surface"], "tui");
            }
            methods.push(method);
        }
        assert!(
            methods
                .iter()
                .any(|method| method == crate::client::method::QUICKSTART_DISMISS),
            "mode switch should send dismissal telemetry: {methods:?}"
        );
        assert!(
            methods
                .iter()
                .any(|method| method == crate::client::method::SOPS_LIST),
            "mode switch should refresh SOPs: {methods:?}"
        );
        assert_eq!(outbound.pending_count(), 2, "both responses are withheld");
    }

    #[tokio::test]
    async fn reconnect_refreshes_the_sop_list_when_it_remains_visible() {
        let (tx, mut rx) = mpsc::channel::<String>(1);
        let outbound = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let rpc = Arc::new(RpcClient::with_rpc(Arc::clone(&outbound)));
        let mut pane = sop_pane::SopPane::new(rpc);

        tokio::time::timeout(
            Duration::from_millis(50),
            refresh_visible_sop_after_reconnect(Mode::Sop, &mut pane),
        )
        .await
        .expect("visible reconnect must not await the list response");

        let raw = tokio::time::timeout(Duration::from_millis(200), rx.recv())
            .await
            .expect("visible reconnect should request the SOP list")
            .expect("RPC request channel should stay open");
        let request: serde_json::Value =
            serde_json::from_str(&raw).expect("RPC request should be JSON");
        assert_eq!(request["method"], crate::client::method::SOPS_LIST);
        let id = request["id"]
            .as_str()
            .expect("RPC request should carry an id");
        outbound.dispatch_response(id, Some(serde_json::json!([{ "name": "deploy" }])), None);
        for _ in 0..100 {
            tokio::task::yield_now().await;
            pane.tick();
            if pane.selected_name().is_some() {
                break;
            }
        }

        assert_eq!(pane.selected_name(), Some("deploy"));
    }

    /// Render the real status bar through the production renderer and return
    /// the final terminal cells a user sees. Reaches the outermost TUI
    /// boundary for the context meter, not a component snapshot.
    #[cfg(test)]
    pub(crate) fn render_status_bar_cells(ctx: CtxBar, width: u16) -> String {
        use ratatui::{Terminal, backend::TestBackend};

        let backend = TestBackend::new(width, 1);
        let mut terminal = Terminal::new(backend).expect("test terminal");
        terminal
            .draw(|frame| {
                draw_status_bar(
                    frame,
                    frame.area(),
                    &ConnectionState::Connected,
                    Some("tui-1"),
                    ctx,
                    false,
                    false,
                );
            })
            .expect("draw status bar");
        terminal
            .backend()
            .buffer()
            .content()
            .iter()
            .map(|cell| cell.symbol())
            .collect()
    }

    /// User-boundary proof: an estimated context count reaches the real status
    /// bar marked approximate, and a measured count does not.
    #[test]
    fn status_bar_marks_estimated_context_and_not_measured_context() {
        let estimated = render_status_bar_cells(
            CtxBar::new(
                Some(100_000),
                Some("estimate".to_string()),
                Some(180_000),
                Some(200_000),
            ),
            100,
        );
        let measured = render_status_bar_cells(
            CtxBar::new(
                Some(100_000),
                Some("provider".to_string()),
                Some(180_000),
                Some(200_000),
            ),
            100,
        );

        assert!(
            estimated.contains("~100,000 / 200,000"),
            "estimated count must render approximate in the real status bar: {estimated:?}"
        );
        assert!(
            estimated.contains("~50%"),
            "estimated percentage must render approximate: {estimated:?}"
        );
        assert!(
            measured.contains(" 100,000 / 200,000"),
            "measured count keeps the reserved marker column blank: {measured:?}"
        );
        assert!(
            !measured.contains('~'),
            "measured usage must never render approximate: {measured:?}"
        );
    }

    /// The marker occupies a reserved column, so enabling provenance must not
    /// shift any following content in the status bar.
    #[test]
    fn approximation_marker_does_not_shift_status_bar_layout() {
        for width in [80_u16, 100, 120] {
            let estimated = render_status_bar_cells(
                CtxBar::new(
                    Some(100_000),
                    Some("estimate".to_string()),
                    Some(180_000),
                    Some(200_000),
                ),
                width,
            );
            let measured = render_status_bar_cells(
                CtxBar::new(
                    Some(100_000),
                    Some("provider".to_string()),
                    Some(180_000),
                    Some(200_000),
                ),
                width,
            );
            assert_eq!(
                estimated.len(),
                measured.len(),
                "width {width}: estimated and measured rows must occupy the same cells"
            );
            // The only differing cells are the two reserved marker columns.
            let diffs = estimated
                .chars()
                .zip(measured.chars())
                .filter(|(a, b)| a != b)
                .count();
            assert_eq!(
                diffs, 2,
                "width {width}: only the two marker columns may differ\n  est={estimated:?}\n  mea={measured:?}"
            );
        }
    }

    #[test]
    fn narrow_mode_bar_keeps_selected_sop_visible_and_summary_non_clickable() {
        use ratatui::{Terminal, backend::TestBackend};

        let summary = Line::from(" status");
        let backend = TestBackend::new(24, 1);
        let mut terminal = Terminal::new(backend).expect("test terminal");
        let mut layout = ModeBarLayout::default();

        terminal
            .draw(|frame| {
                layout = draw_mode_bar(frame, frame.area(), Mode::Sop, Some(&summary));
            })
            .expect("draw narrow mode bar");

        let rendered: String = terminal
            .backend()
            .buffer()
            .content()
            .iter()
            .map(|cell| cell.symbol())
            .collect();
        assert!(rendered.contains("SOPs"), "rendered bar: {rendered:?}");
        assert!(
            rendered.contains('‹'),
            "hidden leading modes should be signaled: {rendered:?}"
        );

        let sop = layout
            .entries
            .iter()
            .find(|entry| entry.mode == Mode::Sop)
            .expect("selected SOP tab must have rendered geometry");
        assert_eq!(
            layout.mode_at(sop.hit_rect.x, sop.hit_rect.y),
            Some(Mode::Sop)
        );

        let summary_area = layout.summary_area.expect("full summary should fit");
        assert_eq!(
            layout.mode_at(summary_area.x, summary_area.y),
            None,
            "chrome summary must not share a tab hit target"
        );
        assert!(
            layout
                .entries
                .iter()
                .all(|entry| entry.hit_rect.right() <= layout.tab_area.right()),
            "every click target must stay within the rendered tab chunk"
        );
    }

    #[test]
    fn narrow_mode_bar_renders_keyboard_reachable_quickstart() {
        use ratatui::{Terminal, backend::TestBackend};

        let backend = TestBackend::new(24, 1);
        let mut terminal = Terminal::new(backend).expect("test terminal");
        let mut layout = ModeBarLayout::default();
        terminal
            .draw(|frame| {
                layout = draw_mode_bar(frame, frame.area(), Mode::Quickstart, None);
            })
            .expect("draw narrow mode bar");

        let rendered: String = terminal
            .backend()
            .buffer()
            .content()
            .iter()
            .map(|cell| cell.symbol())
            .collect();
        assert!(
            rendered.contains("Quickstart"),
            "rendered bar: {rendered:?}"
        );
        let quickstart = layout
            .entries
            .iter()
            .find(|entry| entry.mode == Mode::Quickstart)
            .expect("selected Quickstart tab must stay visible at narrow widths");
        assert_eq!(
            layout.mode_at(quickstart.hit_rect.x, quickstart.hit_rect.y),
            Some(Mode::Quickstart)
        );
    }

    #[test]
    fn mode_cycle_includes_quickstart_and_wraps() {
        let quickstart = MODES
            .iter()
            .position(|mode| *mode == Mode::Quickstart)
            .expect("Quickstart stays in keyboard navigation");
        assert_eq!(Mode::Quickstart.cycle(1), MODES[quickstart + 1]);
        assert_eq!(Mode::Quickstart.cycle(-1), MODES[quickstart - 1]);
        assert_eq!(MODES[0].cycle(1), MODES[1]);
        assert_eq!(MODES[0].cycle(-1), MODES[MODES.len() - 1]);
    }

    #[test]
    fn global_help_entries_include_sidebar_toggle() {
        use crate::keymap::{GlobalAction, action_key_labels};

        let entries = global_help_entries();
        let toggle = entries
            .iter()
            .find(|entry| entry.action == crate::i18n::t("zc-app-help-toggle-sidebar"))
            .expect("global help should list the sidebar toggle");
        assert_eq!(toggle.keys, action_key_labels(GlobalAction::ToggleSidebar));
    }

    #[test]
    fn global_help_entries_include_live_help_binding() {
        use crate::keymap::{GlobalAction, action_key_labels};

        let entries = global_help_entries();
        let help = entries
            .iter()
            .find(|entry| entry.action == crate::i18n::t("zc-app-help-help"))
            .expect("global Help section should include its own opening binding");
        let expected = action_key_labels(GlobalAction::Help);

        assert_eq!(help.keys, expected);
    }

    #[test]
    fn session_shortcut_help_groups_all_live_ordinals() {
        use crate::keymap::{GlobalAction, action_key_labels};

        let entries = global_help_entries();
        let switch = entries
            .iter()
            .find(|entry| entry.action == crate::i18n::t("zc-chat-help-switch-session"))
            .expect("global Help should advertise direct session switching");
        let expected = [
            GlobalAction::FocusSession1,
            GlobalAction::FocusSession2,
            GlobalAction::FocusSession3,
            GlobalAction::FocusSession4,
            GlobalAction::FocusSession5,
            GlobalAction::FocusSession6,
            GlobalAction::FocusSession7,
            GlobalAction::FocusSession8,
        ]
        .into_iter()
        .flat_map(action_key_labels)
        .collect::<Vec<_>>();

        assert_eq!(switch.keys, expected);
    }

    #[test]
    fn session_shortcut_targets_follow_visible_code_then_chat_order() {
        let summary = |pane_kind, session_id: &str| chat::SidebarSessionSummary {
            session_id: session_id.to_string(),
            agent_alias: "test".to_string(),
            message_count: 0,
            status: chat::SidebarStatus::Ready,
            pane_kind,
            focused: false,
        };
        let acp = vec![
            summary(chat::PaneKind::Acp, "code-1"),
            summary(chat::PaneKind::Acp, "code-2"),
        ];
        let chat = vec![summary(chat::PaneKind::Chat, "chat-1")];
        let sessions = session_summaries_in_sidebar_order(
            &crate::agent_sidebar::AgentSidebar::new(),
            acp,
            chat,
        );

        assert_eq!(
            session_shortcut_event(
                session_shortcut_ordinal(Some(GlobalAction::FocusSession2)).unwrap(),
                &sessions,
            ),
            Some(crate::agent_sidebar::SidebarEvent::FocusSession {
                pane: chat::PaneKind::Acp,
                session_id: "code-2".to_string(),
            })
        );
        assert_eq!(
            session_shortcut_event(
                session_shortcut_ordinal(Some(GlobalAction::FocusSession3)).unwrap(),
                &sessions,
            ),
            Some(crate::agent_sidebar::SidebarEvent::FocusSession {
                pane: chat::PaneKind::Chat,
                session_id: "chat-1".to_string(),
            })
        );
        assert_eq!(
            session_shortcut_event(
                session_shortcut_ordinal(Some(GlobalAction::FocusSession4)).unwrap(),
                &sessions,
            ),
            None
        );
    }

    #[test]
    fn session_shortcut_targets_follow_dragged_sidebar_order() {
        use crossterm::event::{MouseButton, MouseEvent, MouseEventKind};
        let summary = |pane_kind, session_id: &str| chat::SidebarSessionSummary {
            session_id: session_id.to_string(),
            agent_alias: "test".to_string(),
            message_count: 0,
            status: chat::SidebarStatus::Ready,
            pane_kind,
            focused: false,
        };
        let acp = vec![
            summary(chat::PaneKind::Acp, "code-1"),
            summary(chat::PaneKind::Acp, "code-2"),
        ];
        let chat = vec![summary(chat::PaneKind::Chat, "chat-1")];
        let mut rows = acp.clone();
        rows.extend(chat.clone());
        let mut sidebar = crate::agent_sidebar::AgentSidebar::new();
        let area = Rect::new(0, 0, 30, 10);
        let ctx = crate::agent_sidebar::SidebarCtx {
            active_pane: Some(chat::PaneKind::Acp),
            quickstart_active: false,
            connected: true,
        };
        let mut term = ratatui::Terminal::new(ratatui::backend::TestBackend::new(30, 10)).unwrap();
        term.draw(|frame| sidebar.draw(frame, area, &rows, &ctx))
            .unwrap();
        // Rows start one line inside the panel border: drag the Chat row
        // (third) to the top.
        let mouse = |kind, row| MouseEvent {
            kind,
            column: 2,
            row,
            modifiers: KeyModifiers::NONE,
        };
        sidebar.handle_mouse(&mouse(MouseEventKind::Down(MouseButton::Left), 3));
        sidebar.handle_mouse(&mouse(MouseEventKind::Drag(MouseButton::Left), 1));
        sidebar.handle_mouse(&mouse(MouseEventKind::Up(MouseButton::Left), 1));
        term.draw(|frame| sidebar.draw(frame, area, &rows, &ctx))
            .unwrap();

        let sessions = session_summaries_in_sidebar_order(&sidebar, acp, chat);
        let target = |action| {
            session_shortcut_event(session_shortcut_ordinal(Some(action)).unwrap(), &sessions)
        };
        let focus = |pane, id: &str| {
            Some(crate::agent_sidebar::SidebarEvent::FocusSession {
                pane,
                session_id: id.to_string(),
            })
        };
        assert_eq!(
            target(GlobalAction::FocusSession1),
            focus(chat::PaneKind::Chat, "chat-1")
        );
        assert_eq!(
            target(GlobalAction::FocusSession2),
            focus(chat::PaneKind::Acp, "code-1")
        );
        assert_eq!(
            target(GlobalAction::FocusSession3),
            focus(chat::PaneKind::Acp, "code-2")
        );
    }

    #[test]
    fn session_shortcut_dispatch_respects_composer_and_other_input_owners() {
        assert!(
            session_shortcut_is_available(Mode::Chat, true, false),
            "typed composer text must not disable the modified session shortcut"
        );
        assert!(
            !session_shortcut_is_available(Mode::Chat, true, true),
            "an explicit Chat or input-bar binding must retain the chord"
        );
        assert!(
            !session_shortcut_is_available(Mode::Config, true, false),
            "non-chat text editors retain their existing input ownership"
        );
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn session_shortcut_decoder_preserves_ctrl_command_modifiers() {
        let original = Event::Key(KeyEvent::new(
            KeyCode::Char('1'),
            KeyModifiers::CONTROL | KeyModifiers::SUPER,
        ));
        let mut decoder = SgrMouseEventDecoder::default();
        decoder.feed(original.clone());

        assert_eq!(decoder.next(), Some(original));
        assert_eq!(
            GlobalAction::from_chord(&KeyEvent::new(
                KeyCode::Char('1'),
                KeyModifiers::CONTROL | KeyModifiers::SUPER,
            )),
            Some(GlobalAction::FocusSession1)
        );
    }

    #[test]
    fn active_text_editor_can_claim_global_pane_navigation() {
        assert_eq!(
            pane_switch_delta(Some(GlobalAction::PaneNavLeft), false, true),
            Some(-1)
        );
        assert_eq!(
            pane_switch_delta(Some(GlobalAction::PaneNavRight), true, true),
            None
        );
    }

    #[test]
    fn disconnected_editor_claim_keeps_global_pane_navigation() {
        assert_eq!(
            pane_switch_delta(Some(GlobalAction::PaneNavRight), true, false),
            Some(1)
        );
    }

    #[test]
    fn connected_chat_or_acp_quit_chord_stays_with_the_pane() {
        let dispatch_state = PostPollDispatchState::new(ConnectionState::Connected);
        assert!(!should_handle_global_quit(&dispatch_state, true));
        assert!(should_handle_global_quit(&dispatch_state, false));
    }

    #[allow(clippy::await_holding_lock)]
    #[tokio::test]
    async fn selected_code_composer_copy_bypasses_app_quit_confirmation() {
        let _guard = crate::keymap::overrides::TEST_GUARD
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        crate::keymap::overrides::reset();
        let (tx, mut rx) = tokio::sync::mpsc::channel::<String>(16);
        let outbound = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let client = Arc::new(crate::client::RpcClient::with_rpc(outbound));
        let mut chat = chat::Chat::new(client.clone(), chat::PaneKind::Chat);
        let mut pane = acp::Acp::new(client);
        pane.activate_session_for_test("editor-test");
        pane.handle_paste("selected draft");
        let mut term: crate::config_manager::Term = ratatui::Terminal::with_options(
            crate::terminal_backend::WideCellCleanupBackend::new(std::io::stdout()),
            ratatui::TerminalOptions {
                viewport: ratatui::Viewport::Fixed(Rect::new(0, 0, 100, 30)),
            },
        )
        .unwrap();
        let copy = KeyEvent::new(KeyCode::Char('c'), KeyModifiers::CONTROL);
        let connected = PostPollDispatchState::new(ConnectionState::Connected);
        assert!(should_handle_global_quit(
            &connected,
            pane.wants_quit_chord(&copy)
        ));
        pane.handle_key(
            KeyEvent::new(KeyCode::Char('a'), KeyModifiers::CONTROL),
            &mut term,
        )
        .await;
        assert!(!should_handle_global_quit(
            &connected,
            pane.wants_quit_chord(&copy)
        ));
        assert!(!pane.handle_key(copy, &mut term).await);
        assert!(rx.try_recv().is_err());
        let disconnected = PostPollDispatchState::new(ConnectionState::Disconnected {
            reason: "test".into(),
        });
        assert!(copy_disconnected_composer(
            &disconnected,
            false,
            Mode::Acp,
            &mut chat,
            &mut pane,
            &copy
        ));
        let error = std::io::Error::new(std::io::ErrorKind::BrokenPipe, "writer rejected copy");
        let expected = crate::clipboard::copy_failure_notice(&error);
        crate::clipboard::with_copy_result(Err(error), || {
            assert!(
                copy_disconnected_composer(
                    &disconnected,
                    false,
                    Mode::Acp,
                    &mut chat,
                    &mut pane,
                    &copy,
                ),
                "known copy failure must not fall through to global quit"
            );
        });
        assert_eq!(pane.info_message().unwrap().text, expected);
        assert!(
            pane.wants_quit_chord(&copy),
            "failed copy retains the selected draft"
        );
        let outcome = crate::clipboard::CopyOutcome::TerminalRequested;
        crate::clipboard::with_copy_result(Ok(outcome), || {
            assert!(copy_disconnected_composer(
                &disconnected,
                false,
                Mode::Acp,
                &mut chat,
                &mut pane,
                &copy,
            ));
        });
        assert_eq!(pane.info_message().unwrap().text, outcome.notice());
        assert!(
            !copy_disconnected_composer(
                &disconnected,
                true,
                Mode::Acp,
                &mut chat,
                &mut pane,
                &copy,
            ),
            "an app-level overlay must exclude hidden composer copy"
        );
        assert!(!copy_disconnected_composer(
            &disconnected,
            false,
            Mode::Acp,
            &mut chat,
            &mut pane,
            &KeyEvent::new(KeyCode::Char('x'), KeyModifiers::CONTROL)
        ));
        assert!(
            rx.try_recv().is_err(),
            "disconnected copy must not dispatch RPC"
        );
        pane.handle_key(KeyEvent::new(KeyCode::Right, KeyModifiers::NONE), &mut term)
            .await;
        assert!(should_handle_global_quit(
            &connected,
            pane.wants_quit_chord(&copy)
        ));
        assert!(!copy_disconnected_composer(
            &disconnected,
            false,
            Mode::Acp,
            &mut chat,
            &mut pane,
            &copy
        ));
        assert!(should_handle_global_quit(
            &disconnected,
            pane.wants_quit_chord(&copy)
        ));
    }

    #[test]
    fn disconnected_chat_or_acp_quit_chord_uses_global_quit_confirm() {
        let dispatch_state = PostPollDispatchState::new(ConnectionState::Disconnected {
            reason: "test".into(),
        });
        assert!(should_handle_global_quit(&dispatch_state, true));
        assert!(should_handle_global_quit(&dispatch_state, false));
    }

    #[tokio::test]
    async fn post_poll_snapshot_blocks_dispatch_after_disconnect() {
        fn poll_after_disconnect(event: Option<Event>) -> (Option<Event>, PostPollDispatchState) {
            let live_state = std::cell::RefCell::new(ConnectionState::Connected);
            let event = std::cell::RefCell::new(event);
            let mut input_decoder = SgrMouseEventDecoder::default();
            poll_input_event_and_snapshot(
                &mut input_decoder,
                |_| {
                    *live_state.borrow_mut() = ConnectionState::Disconnected {
                        reason: "disconnected while waiting for input".into(),
                    };
                    Ok(event.borrow().is_some())
                },
                || Ok(event.borrow_mut().take().expect("poll reported an event")),
                || live_state.borrow().clone(),
            )
            .expect("poll input and take the post-poll snapshot")
        }

        let (timeout_event, timeout_state) = poll_after_disconnect(None);
        assert_eq!(timeout_event, None);
        assert!(!timeout_state.rpc_allowed());

        for family in ["tick", "key", "mouse", "paste", "reload"] {
            let invoked = std::cell::Cell::new(false);
            let result = timeout_state
                .run_rpc_dispatch(|| async {
                    invoked.set(true);
                    family
                })
                .await;
            assert_eq!(result, None, "{family} must remain locally suppressed");
            assert!(!invoked.get(), "{family} must not enter RPC dispatch");
        }

        let navigation_key = KeyEvent::new(KeyCode::Right, KeyModifiers::ALT);
        let navigation = Event::Key(navigation_key);
        let (event, state) = poll_after_disconnect(Some(navigation.clone()));
        assert_eq!(event, Some(navigation));
        assert_eq!(
            pane_switch_delta(
                GlobalAction::from_chord(&navigation_key),
                true,
                state.rpc_allowed()
            ),
            Some(1)
        );
    }

    #[test]
    fn input_wait_returns_early_for_pending_transport_events() {
        // Pending transport work ends the wait after one slice, not the tick.
        let polls = std::cell::RefCell::new(Vec::new());
        let woke = poll_input_or_transport(
            TICK,
            TRANSPORT_WAKE_SLICE,
            |slice| {
                polls.borrow_mut().push(slice);
                Ok(false)
            },
            || true,
        )
        .expect("poll");
        assert!(!woke, "a transport wake is reported as an input timeout");
        assert_eq!(polls.borrow().as_slice(), &[TRANSPORT_WAKE_SLICE]);

        // Input wins over pending transport work in the same slice.
        let woke = poll_input_or_transport(TICK, TRANSPORT_WAKE_SLICE, |_| Ok(true), || true)
            .expect("poll");
        assert!(woke);

        // Idle: keep slicing until the full timeout, never polling past it.
        let polls = std::cell::RefCell::new(Vec::new());
        let started = Instant::now();
        let woke = poll_input_or_transport(
            Duration::from_millis(40),
            Duration::from_millis(10),
            |slice| {
                polls.borrow_mut().push(slice);
                std::thread::sleep(slice);
                Ok(false)
            },
            || false,
        )
        .expect("poll");
        assert!(!woke);
        assert!(started.elapsed() >= Duration::from_millis(40));
        let polls = polls.borrow();
        // The time left is read before each poll, so the first poll's exit
        // check still sees 40 ms against a 10 ms slice and a second poll
        // always follows, however long the first one's sleep overruns.
        assert!(polls.len() >= 2, "{polls:?}");
        assert!(
            polls
                .iter()
                .all(|slice| *slice <= Duration::from_millis(10))
        );
    }

    #[test]
    fn app_run_uses_background_connections_and_fresh_dispatch_state() {
        let source = include_str!("app.rs");
        let run = source
            .split_once("pub async fn run(")
            .expect("app::run must remain present")
            .1;

        assert!(run.contains("ReconnectAttempt::start("));
        assert!(run.contains("ReconnectAttempt::start_direct("));
        assert!(run.contains("poll_input_event_and_snapshot("));
        assert!(run.contains("should_handle_global_quit(&dispatch_state"));
        assert!(run.matches(".run_rpc_dispatch(|| async").count() >= 4);
    }

    #[tokio::test]
    async fn reconnect_attempt_does_not_await_unfinished_work() {
        let (_release, wait) = tokio::sync::oneshot::channel::<()>();
        let mut attempt = ReconnectAttempt::<u8>::from_handle(tokio::spawn(async move {
            let _ = wait.await;
            Ok(7)
        }));

        assert!(!attempt.is_finished());
        assert!(attempt.try_take().await.is_none());
    }

    #[tokio::test]
    async fn reconnect_attempt_consumes_completed_result_once() {
        let mut success =
            ReconnectAttempt::<u8>::from_handle(tokio::spawn(async { Ok::<u8, anyhow::Error>(7) }));
        while !success.is_finished() {
            tokio::task::yield_now().await;
        }
        assert_eq!(success.try_take().await.unwrap().unwrap(), 7);
        assert!(success.try_take().await.is_none());

        let mut failure = ReconnectAttempt::<u8>::from_handle(tokio::spawn(async {
            Err::<u8, anyhow::Error>(anyhow::Error::msg("connect failed"))
        }));
        while !failure.is_finished() {
            tokio::task::yield_now().await;
        }
        assert_eq!(
            failure.try_take().await.unwrap().unwrap_err().to_string(),
            "connect failed"
        );
        assert!(failure.try_take().await.is_none());
    }

    #[tokio::test]
    async fn dropping_reconnect_attempt_aborts_unfinished_work() {
        use std::sync::{
            Arc,
            atomic::{AtomicBool, Ordering},
        };

        struct DropProbe(Arc<AtomicBool>);
        impl Drop for DropProbe {
            fn drop(&mut self) {
                self.0.store(true, Ordering::Release);
            }
        }

        let dropped = Arc::new(AtomicBool::new(false));
        let probe = DropProbe(Arc::clone(&dropped));
        let (started_tx, started_rx) = tokio::sync::oneshot::channel();
        let task = tokio::spawn(async move {
            let _probe = probe;
            let _ = started_tx.send(());
            std::future::pending::<()>().await;
            Ok::<(), anyhow::Error>(())
        });
        let attempt = ReconnectAttempt::<()>::from_handle(task);
        started_rx.await.expect("connection task should start");
        drop(attempt);
        tokio::time::timeout(Duration::from_secs(1), async {
            while !dropped.load(Ordering::Acquire) {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("aborted connection task should drop its state");
    }

    #[test]
    fn help_filter_matches_actions_case_insensitively() {
        let node = HelpNode::titled(
            "Chat",
            vec![
                HelpEntry::key("Ctrl+N", "New session"),
                HelpEntry::key("Ctrl+D", "Cancel turn"),
            ],
        );

        let filtered = filter_help_node(&node, "NEW SESSION").expect("action should match");

        assert_eq!(filtered.title.as_deref(), Some("Chat"));
        assert_eq!(filtered.entries.len(), 1);
        assert_eq!(filtered.entries[0].action, "New session");
    }

    #[test]
    fn help_filter_matches_live_registry_key_labels() {
        use crate::keymap::{GlobalAction, action_key_labels};

        let live_key = action_key_labels(GlobalAction::ReloadDaemon)
            .into_iter()
            .next()
            .expect("reload action should have a binding");
        let node = HelpNode::entries(global_help_entries());

        let filtered =
            filter_help_node(&node, &live_key).expect("rendered registry key should match");

        assert_eq!(filtered.entries.len(), 1);
        assert_eq!(
            filtered.entries[0].action,
            crate::i18n::t("zc-app-help-reload")
        );
    }

    #[test]
    fn help_filter_keeps_every_entry_when_section_title_matches() {
        let child = HelpNode::titled(
            "Sessions",
            vec![
                HelpEntry::key("n", "New session"),
                HelpEntry::key("d", "Delete session"),
            ],
        );
        let root = HelpNode::default().with_child(child);

        let filtered = filter_help_node(&root, "sessions").expect("section should match");

        assert_eq!(filtered.children.len(), 1);
        assert_eq!(filtered.children[0].entries.len(), 2);
    }

    #[test]
    fn help_overlay_typing_scroll_and_escape_are_stateful() {
        let mut state = HelpOverlayState::default();

        assert!(!state.handle_key(&KeyEvent::new(KeyCode::Char('r'), KeyModifiers::NONE)));
        assert_eq!(state.query, "r");

        assert!(!state.handle_key(&KeyEvent::new(KeyCode::Down, KeyModifiers::NONE)));
        assert_eq!(state.scroll, 1);

        assert!(!state.handle_key(&KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE)));
        assert!(state.query.is_empty());
        assert_eq!(state.scroll, 0);

        assert!(state.handle_key(&KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE)));
    }

    #[test]
    fn help_control_hint_uses_live_search_box_bindings() {
        use crate::keymap::action_key_labels;

        let hint = help_control_hint();
        for label in action_key_labels(SearchBoxAction::Up)
            .into_iter()
            .chain(action_key_labels(SearchBoxAction::Down))
            .chain(action_key_labels(SearchBoxAction::Cancel))
        {
            assert!(
                hint.contains(&label),
                "control hint should contain live binding {label:?}"
            );
        }
    }

    #[test]
    fn help_modal_renders_filtered_results_and_keeps_controls_visible() {
        use ratatui::{Terminal, backend::TestBackend};

        let node = HelpNode::entries(vec![
            HelpEntry::key("r", "Reload daemon"),
            HelpEntry::key("q", "Quit"),
        ]);
        let mut state = HelpOverlayState {
            query: "reload".into(),
            scroll: 0,
        };
        let backend = TestBackend::new(60, 10);
        let mut terminal = Terminal::new(backend).expect("test terminal");

        terminal
            .draw(|frame| draw_help_modal(frame, frame.area(), &node, &mut state))
            .expect("draw help modal");

        let rendered: String = terminal
            .backend()
            .buffer()
            .content()
            .iter()
            .map(|cell| cell.symbol())
            .collect();
        assert!(rendered.contains("reload"));
        assert!(rendered.contains("Reload daemon"));
        assert!(!rendered.contains("Quit"));
        assert!(rendered.contains(&help_control_hint()));
    }

    #[test]
    fn help_modal_scrolls_results_without_scrolling_filter_row() {
        use ratatui::{Terminal, backend::TestBackend};

        let node = HelpNode::entries(
            (0..10)
                .map(|index| HelpEntry::key(index.to_string(), format!("Action {index}")))
                .collect(),
        );
        let mut state = HelpOverlayState {
            query: String::new(),
            scroll: usize::MAX,
        };
        let backend = TestBackend::new(40, 8);
        let mut terminal = Terminal::new(backend).expect("test terminal");

        terminal
            .draw(|frame| draw_help_modal(frame, frame.area(), &node, &mut state))
            .expect("draw help modal");

        let rendered: String = terminal
            .backend()
            .buffer()
            .content()
            .iter()
            .map(|cell| cell.symbol())
            .collect();
        let cancel = crate::keymap::action_key_labels(SearchBoxAction::Cancel)
            .into_iter()
            .next()
            .expect("cancel action should have a binding");
        assert_eq!(state.scroll, 6);
        assert!(rendered.contains(&crate::i18n::t("zc-app-help-filter-label")));
        assert!(rendered.contains(&cancel));
        assert!(!rendered.contains("Action 0"));
        assert!(rendered.contains("Action 9"));
    }

    #[tokio::test]
    async fn switching_to_chat_returns_before_agent_status_response() {
        let (tx, mut rx) = mpsc::channel::<String>(16);
        let rpc_out = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let rpc = Arc::new(RpcClient::with_rpc(Arc::clone(&rpc_out)));
        let reconnect_state = SharedReconnectState::default();
        let mut dashboard = dashboard::Dashboard::new(Arc::clone(&rpc), "", false);
        let mut quickstart =
            quickstart_pane::QuickstartPane::new(Arc::clone(&rpc), reconnect_state);
        let mut acp = acp::Acp::new(Arc::clone(&rpc));
        let mut chat = chat::Chat::new(Arc::clone(&rpc), chat::PaneKind::Chat);
        let mut sop = sop_pane::SopPane::new(rpc);
        let mut mode = Mode::Logs;
        let dispatch_state = PostPollDispatchState::new(ConnectionState::Connected);

        tokio::time::timeout(
            Duration::from_millis(100),
            switch_mode(
                &mut mode,
                Mode::Chat,
                &dispatch_state,
                &mut dashboard,
                &mut quickstart,
                &mut acp,
                &mut chat,
                &mut sop,
            ),
        )
        .await
        .expect("switching to Chat must not wait for agent status");

        assert_eq!(mode, Mode::Chat);
        let request = tokio::time::timeout(Duration::from_secs(1), rx.recv())
            .await
            .expect("Chat entry should start the background request")
            .expect("RPC request channel should stay open");
        let request: serde_json::Value = serde_json::from_str(&request).unwrap();
        assert_eq!(request["method"], crate::client::method::AGENTS_STATUS);
        assert_eq!(rpc_out.pending_count(), 1);
    }

    #[tokio::test]
    async fn switching_away_from_chat_invalidates_entry_retry() {
        let (tx, mut rx) = mpsc::channel::<String>(16);
        let rpc_out = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let rpc = Arc::new(RpcClient::with_rpc(Arc::clone(&rpc_out)));
        let reconnect_state = SharedReconnectState::default();
        let mut dashboard = dashboard::Dashboard::new(Arc::clone(&rpc), "", false);
        let mut quickstart =
            quickstart_pane::QuickstartPane::new(Arc::clone(&rpc), reconnect_state);
        let mut acp = acp::Acp::new(Arc::clone(&rpc));
        let mut chat = chat::Chat::new(Arc::clone(&rpc), chat::PaneKind::Chat);
        let mut sop = sop_pane::SopPane::new(Arc::clone(&rpc));
        let mut mode = Mode::Chat;
        let dispatch_state = PostPollDispatchState::new(ConnectionState::Connected);

        chat.start_entry_retry();
        let request = tokio::time::timeout(Duration::from_secs(1), rx.recv())
            .await
            .expect("Chat entry should request agents/status")
            .expect("RPC request channel should stay open");
        let request: serde_json::Value = serde_json::from_str(&request).unwrap();

        switch_mode(
            &mut mode,
            Mode::Logs,
            &dispatch_state,
            &mut dashboard,
            &mut quickstart,
            &mut acp,
            &mut chat,
            &mut sop,
        )
        .await;

        assert_eq!(mode, Mode::Logs);
        let id = request["id"].as_str().unwrap();
        rpc_out.dispatch_response(
            id,
            None,
            Some(crate::jsonrpc::JsonRpcError {
                code: -32000,
                message: "cancelled by test".to_string(),
                data: None,
            }),
        );
        for _ in 0..16 {
            if rpc_out.pending_count() == 0 {
                break;
            }
            tokio::task::yield_now().await;
        }
        assert_eq!(rpc_out.pending_count(), 0);
        assert!(
            tokio::time::timeout(Duration::from_millis(50), rx.recv())
                .await
                .is_err(),
            "a blurred Chat pane must not continue into session creation"
        );
    }

    #[tokio::test]
    async fn startup_agent_flags_open_target_chat_once_after_connect() {
        use clap::Parser;

        for flag in ["-a", "--agent"] {
            let cli = crate::Cli::parse_from(["zerocode", flag, "startup-target"]);
            let reconnect_state = cli.initial_reconnect_state();
            let (tx, mut rx) = mpsc::channel::<String>(16);
            let rpc_out = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
            let rpc = Arc::new(RpcClient::with_rpc(Arc::clone(&rpc_out)));
            let mut chat = chat::Chat::new(rpc, chat::PaneKind::Chat);
            let mut mode = Mode::Dashboard;

            consume_pending_quickstart_chat(
                &PostPollDispatchState::new(ConnectionState::Disconnected {
                    reason: "startup fixture disconnect".to_string(),
                }),
                &reconnect_state,
                &mut mode,
                &mut chat,
            )
            .await;
            assert_eq!(mode, Mode::Dashboard);
            assert!(
                rx.try_recv().is_err(),
                "disconnected startup must not send RPC"
            );

            let state_for_start = Arc::clone(&reconnect_state);
            let mut start = tokio::spawn(async move {
                consume_pending_quickstart_chat(
                    &PostPollDispatchState::new(ConnectionState::Connected),
                    &state_for_start,
                    &mut mode,
                    &mut chat,
                )
                .await;
                (mode, chat)
            });
            let request = tokio::time::timeout(Duration::from_secs(2), async {
                tokio::select! {
                    request = rx.recv() => request.expect("startup RPC channel stays open"),
                    finished = &mut start => {
                        let (mode, _) = finished.expect("startup task completes");
                        assert_eq!(mode, Mode::Chat, "parsed agent must reach Chat startup");
                        panic!("startup completed without requesting the target session");
                    }
                }
            })
            .await
            .expect("startup should request its selected session");
            let request: serde_json::Value = serde_json::from_str(&request).unwrap();
            assert_eq!(request["method"], crate::client::method::SESSION_NEW);
            assert_eq!(request["params"]["agent_alias"], "startup-target");
            assert!(request["params"]["session_id"].is_null());
            assert_eq!(request["params"]["keep_siblings"], true);
            rpc_out.dispatch_response(
                request["id"].as_str().unwrap(),
                Some(serde_json::json!({
                    "session_id": "startup-session",
                    "workspace_dir": "/startup-workspace"
                })),
                None,
            );

            let request = tokio::time::timeout(Duration::from_secs(2), rx.recv())
                .await
                .expect("session start resolves model identity")
                .expect("RPC channel stays open");
            let request: serde_json::Value = serde_json::from_str(&request).unwrap();
            assert_eq!(request["method"], crate::client::method::CONFIG_LIST);
            rpc_out.dispatch_response(
                request["id"].as_str().unwrap(),
                Some(serde_json::json!([])),
                None,
            );
            let (mut mode, mut chat) = tokio::time::timeout(Duration::from_secs(2), start)
                .await
                .expect("startup completes after the RPC responses")
                .expect("startup task succeeds");
            assert_eq!(mode, Mode::Chat);
            assert_eq!(chat.current_session_id(), Some("startup-session"));
            let sessions = chat.session_summaries();
            assert_eq!(sessions.len(), 1);
            assert_eq!(sessions[0].agent_alias, "startup-target");
            assert!(sessions[0].focused);
            assert!(
                reconnect_state
                    .lock()
                    .unwrap()
                    .pending_quickstart_chat
                    .is_none()
            );

            consume_pending_quickstart_chat(
                &PostPollDispatchState::new(ConnectionState::Connected),
                &reconnect_state,
                &mut mode,
                &mut chat,
            )
            .await;
            assert!(
                rx.try_recv().is_err(),
                "a consumed startup must not reopen a session"
            );
            assert_eq!(chat.current_session_id(), Some("startup-session"));
        }
    }

    #[tokio::test]
    async fn startup_without_agent_keeps_dashboard_and_sends_no_session_request() {
        use clap::Parser;

        let cli = crate::Cli::parse_from(["zerocode"]);
        let reconnect_state = cli.initial_reconnect_state();
        let (tx, mut rx) = mpsc::channel::<String>(16);
        let rpc_out = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let rpc = Arc::new(RpcClient::with_rpc(rpc_out));
        let mut chat = chat::Chat::new(rpc, chat::PaneKind::Chat);
        let mut mode = Mode::Dashboard;

        consume_pending_quickstart_chat(
            &PostPollDispatchState::new(ConnectionState::Connected),
            &reconnect_state,
            &mut mode,
            &mut chat,
        )
        .await;

        assert_eq!(mode, Mode::Dashboard);
        assert_eq!(chat.current_session_id(), None);
        assert!(chat.session_summaries().is_empty());
        assert!(
            reconnect_state
                .lock()
                .unwrap()
                .pending_quickstart_chat
                .is_none()
        );
        assert!(
            rx.try_recv().is_err(),
            "omitted alias must not initiate an RPC"
        );
    }

    #[tokio::test]
    async fn startup_agent_rpc_rejection_uses_existing_chat_error() {
        use clap::Parser;
        use ratatui::{Terminal, backend::TestBackend};

        let cli = crate::Cli::parse_from(["zerocode", "--agent", "unknown-startup-agent"]);
        let reconnect_state = cli.initial_reconnect_state();
        let (tx, mut rx) = mpsc::channel::<String>(16);
        let rpc_out = Arc::new(crate::jsonrpc::RpcOutbound::new(tx));
        let rpc = Arc::new(RpcClient::with_rpc(Arc::clone(&rpc_out)));
        let mut chat = chat::Chat::new(rpc, chat::PaneKind::Chat);
        let start = tokio::spawn(async move {
            let mut mode = Mode::Dashboard;
            consume_pending_quickstart_chat(
                &PostPollDispatchState::new(ConnectionState::Connected),
                &reconnect_state,
                &mut mode,
                &mut chat,
            )
            .await;
            (mode, chat)
        });
        let request = tokio::time::timeout(Duration::from_secs(2), rx.recv())
            .await
            .expect("startup should request the supplied alias")
            .expect("RPC channel stays open");
        let request: serde_json::Value = serde_json::from_str(&request).unwrap();
        assert_eq!(request["method"], crate::client::method::SESSION_NEW);
        assert_eq!(request["params"]["agent_alias"], "unknown-startup-agent");
        rpc_out.dispatch_response(
            request["id"].as_str().unwrap(),
            None,
            Some(crate::jsonrpc::JsonRpcError {
                code: crate::jsonrpc::error_codes::INTERNAL_ERROR,
                message: "unknown-startup-agent".to_string(),
                data: None,
            }),
        );
        let (mode, mut chat) = tokio::time::timeout(Duration::from_secs(2), start)
            .await
            .expect("rejected startup should return")
            .expect("startup task succeeds");
        assert_eq!(mode, Mode::Chat);
        assert_eq!(chat.current_session_id(), None);
        assert!(
            rx.try_recv().is_err(),
            "rejection must not start another session"
        );

        let mut terminal = Terminal::new(TestBackend::new(100, 12)).unwrap();
        terminal
            .draw(|frame| chat.draw(frame, frame.area()))
            .unwrap();
        let rendered: String = terminal
            .backend()
            .buffer()
            .content()
            .iter()
            .map(|cell| cell.symbol())
            .collect();
        assert!(rendered.contains("unknown-startup-agent"));
    }

    #[test]
    fn quickstart_chat_handoff_consumes_immediate_target() {
        let state = SharedReconnectState::default();
        {
            let mut guard = state.lock().unwrap();
            guard.pending_quickstart_chat = Some(PendingQuickstartChat::Immediate("scout".into()));
        }

        assert_eq!(
            take_pending_quickstart_chat(&state, QuickstartChatDrain::Immediate),
            Some("scout".into())
        );
        assert!(state.lock().unwrap().pending_quickstart_chat.is_none());
    }

    #[test]
    fn quickstart_chat_handoff_immediate_drain_preserves_after_reconnect_target() {
        let state = SharedReconnectState::default();
        {
            let mut guard = state.lock().unwrap();
            guard.pending_quickstart_chat =
                Some(PendingQuickstartChat::AfterReconnect("scout".into()));
        }

        assert_eq!(
            take_pending_quickstart_chat(&state, QuickstartChatDrain::Immediate),
            None
        );
        assert_eq!(
            state.lock().unwrap().pending_quickstart_chat,
            Some(PendingQuickstartChat::AfterReconnect("scout".into()))
        );
    }

    #[test]
    fn quickstart_chat_handoff_consumes_after_reconnect_target() {
        let state = SharedReconnectState::default();
        {
            let mut guard = state.lock().unwrap();
            guard.pending_quickstart_chat =
                Some(PendingQuickstartChat::AfterReconnect("scout".into()));
        }

        assert_eq!(
            take_pending_quickstart_chat(&state, QuickstartChatDrain::AfterReconnect),
            Some("scout".into())
        );
        assert!(state.lock().unwrap().pending_quickstart_chat.is_none());
    }

    #[test]
    fn unowned_session_never_respawns() {
        assert!(!should_respawn_ephemeral(
            None,
            false,
            Duration::from_secs(3600),
            |_| false
        ));
    }

    #[test]
    fn owned_dead_daemon_respawns_immediately() {
        assert!(should_respawn_ephemeral(
            Some(1),
            false,
            Duration::ZERO,
            |_| false
        ));
    }

    #[test]
    fn owned_live_daemon_waits_out_reload_grace() {
        assert!(!should_respawn_ephemeral(
            Some(1),
            false,
            EPHEMERAL_RESPAWN_GRACE - Duration::from_millis(1),
            |_| true
        ));
    }

    #[test]
    fn owned_live_daemon_respawns_after_grace() {
        assert!(should_respawn_ephemeral(
            Some(1),
            false,
            EPHEMERAL_RESPAWN_GRACE,
            |_| true
        ));
    }

    #[test]
    fn respawn_happens_at_most_once_per_episode() {
        assert!(!should_respawn_ephemeral(
            Some(1),
            true,
            Duration::from_secs(3600),
            |_| false
        ));
    }

    #[test]
    fn owned_reconnect_accepts_only_the_expected_daemon_identity() {
        assert!(reconnect_matches_owned_daemon(Some(11), None, Some(11)));
        assert!(!reconnect_matches_owned_daemon(Some(11), None, Some(12)));
        assert!(!reconnect_matches_owned_daemon(Some(11), None, None));
    }

    #[test]
    fn respawned_daemon_identity_takes_precedence_during_readiness() {
        assert!(reconnect_matches_owned_daemon(Some(11), Some(22), Some(22)));
        assert!(!reconnect_matches_owned_daemon(
            Some(11),
            Some(22),
            Some(11)
        ));
        assert!(!reconnect_matches_owned_daemon(
            Some(11),
            Some(22),
            Some(33)
        ));
    }

    #[test]
    fn attached_reconnect_accepts_any_compatible_daemon() {
        assert!(reconnect_matches_owned_daemon(None, None, Some(33)));
        assert!(reconnect_matches_owned_daemon(None, None, None));
    }

    #[test]
    fn failed_automatic_replacement_releases_stale_pid_for_manual_recovery() {
        let mut owned_pid = Some(11);
        let mut pending_pid = Some(22);
        let manual_pid = Some(33);
        let mut needs_intervention = false;

        assert!(
            !reconnect_matches_owned_daemon(owned_pid, pending_pid, manual_pid),
            "exact replacement identity must remain enforced while it is active"
        );

        // The automatic child exits: production drops `pending_respawn`, then
        // records the definitive failure through this transition.
        pending_pid = None;
        record_automatic_respawn_failure(&mut owned_pid, &mut needs_intervention);

        assert!(owned_pid.is_none());
        assert!(needs_intervention);
        assert!(
            reconnect_matches_owned_daemon(owned_pid, pending_pid, manual_pid),
            "a compatible manual restart must be accepted after replacement failure"
        );
    }

    #[test]
    fn ephemeral_respawn_grace_outlasts_daemon_reload_rebind() {
        assert_eq!(EPHEMERAL_RESPAWN_GRACE, Duration::from_secs(10));
    }

    #[cfg(unix)]
    #[test]
    fn live_process_probe_reports_alive() {
        assert!(ephemeral_daemon_pid_alive(std::process::id()));
    }
}

#[cfg(test)]
mod transport_leg_tests {
    //! What the reconnect and failback paths do with the leg the routing source
    //! of truth returns.
    //!
    //! `active_leg` is not decoration: the failback loop runs only while it says
    //! `WssRelay`, so a leg that is dropped or committed early silently disables
    //! the migration back to the direct path.

    use super::leg_after_adoption;
    use crate::ActiveLeg;

    /// A direct session whose address is still down reconnects onto the relay.
    /// Keeping `WssDirect` here is what stops the failback loop from ever
    /// running, stranding the session on the relay for the rest of its life.
    #[test]
    fn a_direct_session_that_reconnects_on_the_relay_commits_the_relay_leg() {
        let leg = leg_after_adoption(true, ActiveLeg::WssDirect, ActiveLeg::WssRelay);

        assert_eq!(leg, ActiveLeg::WssRelay);
        assert!(
            leg == ActiveLeg::WssRelay,
            "the failback loop's precondition must now hold"
        );
    }

    /// The mirror case: a relay session that comes back on the direct path must
    /// stop re-probing a direct address it is already using.
    #[test]
    fn a_relay_session_that_reconnects_direct_commits_the_direct_leg() {
        let leg = leg_after_adoption(true, ActiveLeg::WssRelay, ActiveLeg::WssDirect);

        assert_eq!(leg, ActiveLeg::WssDirect);
        assert!(
            leg != ActiveLeg::WssRelay,
            "a direct session must not keep re-probing the path it is on"
        );
    }

    /// A connection that could not be adopted is not the connection the panes
    /// hold, so its leg must not be committed: the session is still on the old
    /// one and must keep behaving that way.
    #[test]
    fn a_failed_adoption_keeps_the_leg_it_is_still_running_on() {
        assert_eq!(
            leg_after_adoption(false, ActiveLeg::WssRelay, ActiveLeg::WssDirect),
            ActiveLeg::WssRelay,
            "a failed direct migration must leave the session on the relay"
        );
        assert_eq!(
            leg_after_adoption(false, ActiveLeg::WssDirect, ActiveLeg::WssRelay),
            ActiveLeg::WssDirect
        );
    }

    /// The local socket has no legs to migrate between; adoption must not
    /// invent one.
    #[test]
    fn a_local_session_keeps_its_leg() {
        assert_eq!(
            leg_after_adoption(true, ActiveLeg::Local, ActiveLeg::Local),
            ActiveLeg::Local
        );
    }
}
