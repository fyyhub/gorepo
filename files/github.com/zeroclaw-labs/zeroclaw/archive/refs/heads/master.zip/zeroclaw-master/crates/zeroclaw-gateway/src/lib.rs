#![allow(
    clippy::to_string_in_format_args,
    clippy::useless_format,
    clippy::collapsible_if
)]

#[cfg(feature = "a2a")]
pub mod a2a;
pub mod acp;
pub mod agent_owned_state;
pub mod api;
pub mod api_browse;
pub mod api_config;
pub mod api_logs;
pub mod api_oidc;
mod api_oidc_enroll;
pub mod api_pairing;
pub mod api_personality;
pub mod api_plugins;
pub mod api_quickstart;
pub mod api_sections;
pub mod api_skills;
pub mod api_sop;
pub mod api_sop_author;
mod api_sop_webhook;
pub mod api_upload;
#[cfg(feature = "webauthn")]
pub mod api_webauthn;
#[cfg(any(
    feature = "channel-linq",
    feature = "channel-nextcloud",
    feature = "channel-whatsapp-cloud"
))]
pub mod api_webhook;
pub mod auth_rate_limit;
pub mod canvas;
mod chat_core;
pub mod core_rpc;
pub mod dashboard_core;
pub mod dashboard_session;
pub mod node_tool;
pub mod nodes;
pub mod openapi;
#[cfg(feature = "plugins-wasm")]
mod plugin_webhook;
pub mod principal_gate;
mod relay_ingress;
pub mod security_headers;
pub mod session_queue;
pub mod sse;
pub mod static_files;
pub mod tls;
pub mod version;
#[cfg(feature = "gateway-voice-duplex")]
pub mod voice_duplex;
#[cfg(any(
    feature = "channel-linq",
    feature = "channel-nextcloud",
    feature = "channel-whatsapp-cloud"
))]
mod webhook_ingress;
pub mod ws;
pub mod ws_approval;
pub mod ws_sop_runs;

use anyhow::{Context, Result};
#[cfg(any(
    feature = "channel-email",
    feature = "channel-linq",
    feature = "channel-nextcloud",
    feature = "channel-whatsapp-cloud"
))]
use axum::body::Bytes;
#[cfg(any(
    feature = "channel-linq",
    feature = "channel-nextcloud",
    feature = "channel-whatsapp-cloud"
))]
use axum::extract::Path;
use axum::{
    Router,
    extract::{ConnectInfo, Query, State},
    http::{HeaderMap, StatusCode, header},
    response::{
        IntoResponse, Json, Response,
        sse::{Event as SseWireEvent, KeepAlive as SseKeepAlive, Sse as SseBody},
    },
    routing::{delete, get, post, put},
};
use parking_lot::Mutex;
use std::collections::HashMap;
use std::future::Future;
use std::net::{IpAddr, SocketAddr};
use std::sync::Arc;
use std::time::{Duration, Instant};

/// Gateway session key prefix to avoid collisions with channel sessions.
pub(crate) const GW_SESSION_PREFIX: &str = "gw_";

/// Return the canonical persistence key for a gateway session.
///
/// Persistence backends apply the shared filesystem-safe normalization so
/// their in-memory and on-disk keys remain consistent.
pub(crate) fn gateway_session_key(session_id: &str) -> String {
    format!(
        "{GW_SESSION_PREFIX}{}",
        zeroclaw_api::session_keys::sanitize_session_key(session_id)
    )
}

/// Return the process-local cancellation key for a gateway session.
///
/// Unlike persistence keys, cancellation keys must preserve the accepted
/// session id verbatim: filesystem-safe normalization is lossy and would make
/// distinct live sessions such as `team.alpha` and `team_alpha` cancel one
/// another.
pub(crate) fn gateway_cancel_key(session_id: &str) -> String {
    format!("{GW_SESSION_PREFIX}{session_id}")
}

/// Backoff after a transient `accept()` error so the serve loop does not
/// hot-spin while the condition (e.g. fd exhaustion) clears.
const ACCEPT_ERROR_BACKOFF_MS: u64 = 50;

/// File-descriptor exhaustion errno values, stable across the Unix targets
/// we support (Linux, macOS, BSD).
#[cfg(unix)]
const EMFILE: i32 = 24; // too many open files (this process)
#[cfg(unix)]
const ENFILE: i32 = 23; // too many open files (system-wide)

fn is_recoverable_accept_error(e: &std::io::Error) -> bool {
    use std::io::ErrorKind;
    if matches!(
        e.kind(),
        ErrorKind::ConnectionAborted | ErrorKind::Interrupted | ErrorKind::WouldBlock
    ) {
        return true;
    }
    #[cfg(unix)]
    if matches!(e.raw_os_error(), Some(EMFILE) | Some(ENFILE)) {
        return true;
    }
    false
}
use tower_http::limit::RequestBodyLimitLayer;
use tower_http::timeout::TimeoutLayer;
use uuid::Uuid;
#[cfg(any(
    feature = "channel-linq",
    feature = "channel-nextcloud",
    feature = "channel-whatsapp-cloud"
))]
use zeroclaw_api::channel::Channel;
use zeroclaw_api::memory_traits::MemoryStrategy;
use zeroclaw_api::tool::ToolSpec;
#[cfg(feature = "channel-email")]
use zeroclaw_channels::gmail_push::GmailPushChannel;
#[cfg(feature = "channel-linq")]
use zeroclaw_channels::linq::LinqChannel;
#[cfg(feature = "channel-nextcloud")]
use zeroclaw_channels::nextcloud_talk::NextcloudTalkChannel;
#[cfg(feature = "channel-whatsapp-cloud")]
use zeroclaw_channels::whatsapp::WhatsAppChannel;
use zeroclaw_config::policy::SecurityPolicy;
use zeroclaw_config::schema::Config;
use zeroclaw_infra::session_backend::SessionBackend;
use zeroclaw_memory::{self, Memory, MemoryCategory};
use zeroclaw_providers::{self, ModelProvider};
use zeroclaw_runtime::agent::memory_strategy::DefaultMemoryStrategy;
use zeroclaw_runtime::cost::CostTracker;
use zeroclaw_runtime::i18n;
use zeroclaw_runtime::platform;
use zeroclaw_runtime::security::pairing::{
    GATEWAY_ADMIN_TOKEN_HEADER, PairingCodePolicy, PairingGuard, PairingLimits, constant_time_eq,
    gateway_admin_token_path, is_public_bind,
};
use zeroclaw_runtime::tools;
use zeroclaw_runtime::tools::CanvasStore;
use zeroclaw_runtime::tools::scoped;

/// Maximum request body size (64KB) — prevents memory exhaustion
pub const MAX_BODY_SIZE: usize = 65_536;
/// Default request timeout (30s) — prevents slow-loris attacks.
pub const REQUEST_TIMEOUT_SECS: u64 = 30;

pub const LONG_RUNNING_REQUEST_TIMEOUT_SECS: u64 = 600;

/// Gateway request timeout (seconds) for ordinary routes. Reads from typed config.
pub fn gateway_request_timeout_secs(cfg: &zeroclaw_config::schema::GatewayConfig) -> u64 {
    cfg.request_timeout_secs
}

/// Request timeout (seconds) for webhook, manual cron and A2A task routes,
/// exempt from [`gateway_request_timeout_secs`]. Reads from typed config.
pub fn gateway_long_running_request_timeout_secs(
    cfg: &zeroclaw_config::schema::GatewayConfig,
) -> u64 {
    cfg.long_running_request_timeout_secs
}
/// Sliding window used by gateway rate limiting.
pub const RATE_LIMIT_WINDOW_SECS: u64 = 60;

/// Fallback max distinct client keys tracked in gateway rate limiter.
pub const RATE_LIMIT_MAX_KEYS_DEFAULT: usize = 10_000;
/// Fallback max distinct idempotency keys retained in gateway memory.
pub const IDEMPOTENCY_MAX_KEYS_DEFAULT: usize = 10_000;

fn webhook_memory_key() -> String {
    format!("webhook_msg_{}", Uuid::new_v4())
}

#[cfg(feature = "channel-whatsapp-cloud")]
fn whatsapp_memory_key(msg: &zeroclaw_api::channel::ChannelMessage) -> String {
    format!("whatsapp_{}_{}", msg.sender, msg.id)
}

#[cfg(feature = "channel-linq")]
fn linq_memory_key(msg: &zeroclaw_api::channel::ChannelMessage) -> String {
    format!("linq_{}_{}", msg.sender, msg.id)
}

#[cfg(feature = "channel-nextcloud")]
fn nextcloud_talk_memory_key(msg: &zeroclaw_api::channel::ChannelMessage) -> String {
    format!("nextcloud_talk_{}_{}", msg.sender, msg.id)
}

#[cfg(any(
    feature = "channel-linq",
    feature = "channel-nextcloud",
    feature = "channel-whatsapp-cloud"
))]
fn sender_session_id(channel: &str, msg: &zeroclaw_api::channel::ChannelMessage) -> String {
    match &msg.thread_ts {
        Some(thread_id) => format!("{channel}_{thread_id}_{}", msg.sender),
        None => format!("{channel}_{}", msg.sender),
    }
}

#[cfg(feature = "channel-linq")]
fn linq_channel_ref(alias: &str) -> String {
    format!("linq.{alias}")
}

fn webhook_session_id(headers: &HeaderMap) -> Option<String> {
    const MAX_SESSION_ID_LEN: usize = 128;
    headers
        .get("X-Session-Id")
        .and_then(|v| v.to_str().ok())
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .filter(|value| value.len() <= MAX_SESSION_ID_LEN)
        .filter(|value| {
            value
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_' || b == b'.')
        })
        .map(str::to_owned)
}

fn hash_webhook_secret(value: &str) -> String {
    use sha2::{Digest, Sha256};

    let digest = Sha256::digest(value.as_bytes());
    hex::encode(digest)
}

/// How often the rate limiter sweeps stale IP entries from its map.
const RATE_LIMITER_SWEEP_INTERVAL_SECS: u64 = 300; // 5 minutes

#[derive(Debug)]
pub(crate) struct SlidingWindowRateLimiter {
    limit_per_window: u32,
    window: Duration,
    max_keys: usize,
    requests: Mutex<(HashMap<String, Vec<Instant>>, Instant)>,
}

impl SlidingWindowRateLimiter {
    pub(crate) fn new(limit_per_window: u32, window: Duration, max_keys: usize) -> Self {
        Self {
            limit_per_window,
            window,
            max_keys: max_keys.max(1),
            requests: Mutex::new((HashMap::new(), Instant::now())),
        }
    }

    fn prune_stale(requests: &mut HashMap<String, Vec<Instant>>, cutoff: Instant) {
        requests.retain(|_, timestamps| {
            timestamps.retain(|t| *t > cutoff);
            !timestamps.is_empty()
        });
    }

    fn allow(&self, key: &str) -> bool {
        self.allow_or_retry_after(key).is_ok()
    }

    /// Consume one request from `key`'s budget. On refusal, the error is the
    /// whole seconds until the oldest request still inside the window ages
    /// out (rounded up, never below 1), which is what a caller puts in
    /// `Retry-After`.
    pub(crate) fn allow_or_retry_after(&self, key: &str) -> Result<(), u64> {
        if self.limit_per_window == 0 {
            return Ok(());
        }

        let now = Instant::now();
        let cutoff = now.checked_sub(self.window).unwrap_or_else(Instant::now);

        let mut guard = self.requests.lock();
        let (requests, last_sweep) = &mut *guard;

        // Periodic sweep: remove keys with no recent requests
        if last_sweep.elapsed() >= Duration::from_secs(RATE_LIMITER_SWEEP_INTERVAL_SECS) {
            Self::prune_stale(requests, cutoff);
            *last_sweep = now;
        }

        if !requests.contains_key(key) && requests.len() >= self.max_keys {
            // Opportunistic stale cleanup before eviction under cardinality pressure.
            Self::prune_stale(requests, cutoff);
            *last_sweep = now;

            if requests.len() >= self.max_keys {
                let evict_key = requests
                    .iter()
                    .min_by_key(|(_, timestamps)| timestamps.last().copied().unwrap_or(cutoff))
                    .map(|(k, _)| k.clone());
                if let Some(evict_key) = evict_key {
                    requests.remove(&evict_key);
                }
            }
        }

        let entry = requests.entry(key.to_owned()).or_default();
        entry.retain(|instant| *instant > cutoff);

        if entry.len() >= self.limit_per_window as usize {
            // Timestamps are pushed in order, so the first one still inside
            // the window is the one whose expiry frees the next slot.
            let remaining = entry
                .first()
                .map(|oldest| self.window.saturating_sub(now.duration_since(*oldest)))
                .unwrap_or(self.window);
            let secs = remaining.as_secs() + u64::from(remaining.subsec_nanos() > 0);
            return Err(secs.max(1));
        }

        entry.push(now);
        Ok(())
    }
}

#[derive(Debug)]
pub struct GatewayRateLimiter {
    pair: SlidingWindowRateLimiter,
    webhook: SlidingWindowRateLimiter,
}

impl GatewayRateLimiter {
    pub fn new(pair_per_minute: u32, webhook_per_minute: u32, max_keys: usize) -> Self {
        let window = Duration::from_secs(RATE_LIMIT_WINDOW_SECS);
        Self {
            pair: SlidingWindowRateLimiter::new(pair_per_minute, window, max_keys),
            webhook: SlidingWindowRateLimiter::new(webhook_per_minute, window, max_keys),
        }
    }

    fn allow_pair(&self, key: &str) -> bool {
        self.pair.allow(key)
    }

    fn allow_webhook(&self, key: &str) -> bool {
        self.webhook.allow(key)
    }
}

#[derive(Debug)]
pub struct IdempotencyStore {
    ttl: Duration,
    max_keys: usize,
    entries: Mutex<IdempotencyEntries>,
    #[cfg(feature = "plugins-wasm")]
    next_generation: std::sync::atomic::AtomicU64,
}

#[derive(Debug, Default)]
struct IdempotencyEntries {
    committed: HashMap<String, Instant>,
    /// Temporary plugin-delivery owners, bounded independently by `max_keys`.
    /// Keeping this separate prevents one slow plugin request from making the
    /// legacy boolean `record_if_new` path misclassify store pressure as a
    /// committed duplicate.
    #[cfg(feature = "plugins-wasm")]
    pending: HashMap<String, PendingIdempotencyReservation>,
}

#[cfg(feature = "plugins-wasm")]
#[derive(Debug)]
struct PendingIdempotencyReservation {
    generation: u64,
    status: tokio::sync::watch::Sender<zeroclaw_api::webhook::WebhookReservationStatus>,
}

impl IdempotencyStore {
    pub fn new(ttl: Duration, max_keys: usize) -> Self {
        Self {
            ttl,
            max_keys: max_keys.max(1),
            entries: Mutex::new(IdempotencyEntries::default()),
            #[cfg(feature = "plugins-wasm")]
            next_generation: std::sync::atomic::AtomicU64::new(1),
        }
    }

    /// Returns true if this key is new and is now recorded.
    fn record_if_new(&self, key: &str) -> bool {
        let now = Instant::now();
        let mut entries = self.entries.lock();

        entries
            .committed
            .retain(|_, seen_at| now.duration_since(*seen_at) < self.ttl);

        let pending_contains = {
            #[cfg(feature = "plugins-wasm")]
            {
                entries.pending.contains_key(key)
            }
            #[cfg(not(feature = "plugins-wasm"))]
            {
                false
            }
        };
        if entries.committed.contains_key(key) || pending_contains {
            return false;
        }

        if entries.committed.len() >= self.max_keys {
            let evict_key = entries
                .committed
                .iter()
                .min_by_key(|(_, seen_at)| *seen_at)
                .map(|(k, _)| k.clone());
            if let Some(evict_key) = evict_key {
                entries.committed.remove(&evict_key);
            } else {
                return false;
            }
        }

        entries.committed.insert(key.to_owned(), now);
        true
    }

    #[cfg(feature = "plugins-wasm")]
    fn begin_reservation(&self, key: &str) -> zeroclaw_api::webhook::WebhookReservation {
        use zeroclaw_api::webhook::{
            WebhookReservation, WebhookReservationStatus, WebhookReservationToken,
            WebhookReservationWaiter,
        };

        let now = Instant::now();
        let mut entries = self.entries.lock();
        entries
            .committed
            .retain(|_, seen_at| now.duration_since(*seen_at) < self.ttl);
        if entries.committed.contains_key(key) {
            return WebhookReservation::Committed;
        }
        if let Some(pending) = entries.pending.get(key) {
            return WebhookReservation::InFlight(WebhookReservationWaiter::new(
                pending.status.subscribe(),
            ));
        }

        if entries.pending.len() >= self.max_keys {
            return WebhookReservation::Unavailable;
        }

        let generation = self
            .next_generation
            .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let (status, _) = tokio::sync::watch::channel(WebhookReservationStatus::InFlight);
        entries.pending.insert(
            key.to_string(),
            PendingIdempotencyReservation { generation, status },
        );
        WebhookReservation::Owner(WebhookReservationToken::new(key.to_string(), generation))
    }

    #[cfg(feature = "plugins-wasm")]
    fn commit_reservation(&self, token: &zeroclaw_api::webhook::WebhookReservationToken) -> bool {
        let mut entries = self.entries.lock();
        if entries
            .pending
            .get(token.key())
            .is_none_or(|pending| pending.generation != token.generation())
        {
            return false;
        }
        let Some(pending) = entries.pending.remove(token.key()) else {
            return false;
        };
        pending
            .status
            .send_replace(zeroclaw_api::webhook::WebhookReservationStatus::Committed);
        let now = Instant::now();
        entries
            .committed
            .retain(|_, seen_at| now.duration_since(*seen_at) < self.ttl);
        if entries.committed.len() >= self.max_keys {
            let evict_key = entries
                .committed
                .iter()
                .min_by_key(|(_, seen_at)| *seen_at)
                .map(|(key, _)| key.clone());
            if let Some(evict_key) = evict_key {
                entries.committed.remove(&evict_key);
            }
        }
        entries.committed.insert(token.key().to_string(), now);
        true
    }

    #[cfg(feature = "plugins-wasm")]
    fn rollback_reservation(&self, token: &zeroclaw_api::webhook::WebhookReservationToken) -> bool {
        let mut entries = self.entries.lock();
        if entries
            .pending
            .get(token.key())
            .is_none_or(|pending| pending.generation != token.generation())
        {
            return false;
        }
        let Some(pending) = entries.pending.remove(token.key()) else {
            return false;
        };
        pending
            .status
            .send_replace(zeroclaw_api::webhook::WebhookReservationStatus::RolledBack);
        true
    }
}

fn parse_client_ip(value: &str) -> Option<IpAddr> {
    let value = value.trim().trim_matches('"').trim();
    if value.is_empty() {
        return None;
    }

    if let Ok(ip) = value.parse::<IpAddr>() {
        return Some(ip);
    }

    if let Ok(addr) = value.parse::<SocketAddr>() {
        return Some(addr.ip());
    }

    let value = value.trim_matches(['[', ']']);
    value.parse::<IpAddr>().ok()
}

fn dirs_data_local() -> Option<std::path::PathBuf> {
    directories::BaseDirs::new().map(|d| d.data_local_dir().to_path_buf())
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum WebDashboardAvailability {
    Embedded,
    Filesystem(std::path::PathBuf),
}

pub fn resolve_web_dashboard_availability(config: &Config) -> Option<WebDashboardAvailability> {
    #[cfg(feature = "embedded-web")]
    {
        let _ = config;
        Some(WebDashboardAvailability::Embedded)
    }
    #[cfg(not(feature = "embedded-web"))]
    {
        resolve_web_dist_dir(config).map(WebDashboardAvailability::Filesystem)
    }
}

fn has_servable_dashboard_index(dir: &std::path::Path) -> bool {
    let Ok(canonical_root) = std::fs::canonicalize(dir) else {
        return false;
    };
    let Ok(canonical_index) = std::fs::canonicalize(canonical_root.join("index.html")) else {
        return false;
    };

    canonical_index.starts_with(&canonical_root) && canonical_index.is_file()
}

pub fn resolve_web_dist_dir(config: &Config) -> Option<std::path::PathBuf> {
    match config
        .gateway
        .web_dist_dir
        .as_ref()
        .map(std::path::PathBuf::from)
    {
        Some(explicit) if has_servable_dashboard_index(&explicit) => Some(explicit),
        Some(_) | None => auto_detect_web_dist_dir(),
    }
}

fn auto_detect_web_dist_dir() -> Option<std::path::PathBuf> {
    let mut candidates = vec![
        std::path::PathBuf::from("web/dist"),
        std::env::current_exe()
            .ok()
            .and_then(|p| p.parent().map(|d| d.join("web/dist")))
            .unwrap_or_default(),
        std::path::PathBuf::from("/zeroclaw-data/web/dist"),
        std::path::PathBuf::from("/usr/share/zeroclawlabs/web/dist"),
    ];
    if let Some(data_dir) = dirs_data_local() {
        candidates.push(data_dir.join("zeroclaw/web/dist"));
    }
    candidates
        .into_iter()
        .find(|p| !p.as_os_str().is_empty() && has_servable_dashboard_index(p))
}

fn forwarded_client_ip(headers: &HeaderMap) -> Option<IpAddr> {
    // Appending proxies add the connecting peer at the right-hand end. Prefer
    // that hop so a client-supplied leading entry cannot pick the rate-limit key.
    // Skip loopback hops: a real client never arrives as loopback through a
    // proxy, and a same-host proxy chain can append 127.0.0.1 while the real
    // caller sits further left.
    if let Some(xff) = headers.get("X-Forwarded-For") {
        let mut rightmost_loopback = None;
        // A proxy can append a valid address to a caller's opaque header
        // bytes. Decode each hop separately so that prefix cannot hide the
        // proxy's suffix and restore the loopback peer's limiter exemption.
        for candidate in xff.as_bytes().rsplit(|byte| *byte == b',') {
            if let Some(ip) = std::str::from_utf8(candidate)
                .ok()
                .and_then(parse_client_ip)
            {
                if ip.is_loopback() {
                    if rightmost_loopback.is_none() {
                        rightmost_loopback = Some(ip);
                    }
                    continue;
                }
                return Some(ip);
            }
        }
        if rightmost_loopback.is_some() {
            return rightmost_loopback;
        }
    }

    headers
        .get("X-Real-IP")
        .and_then(|v| v.to_str().ok())
        .and_then(parse_client_ip)
}

pub(crate) fn client_key_from_request(
    peer_addr: Option<SocketAddr>,
    headers: &HeaderMap,
    trust_forwarded_headers: bool,
) -> String {
    if trust_forwarded_headers && let Some(ip) = forwarded_client_ip(headers) {
        // A real loopback caller never arrives through a proxy with a
        // forwarded header. Treat a loopback-only forwarded value as spoofed.
        if !ip.is_loopback() {
            return ip.to_string();
        }
        // Do not inherit a loopback peer exemption from a proxied path — that
        // would let a remote caller behind a same-host proxy skip per-client
        // limits. Prefer a non-loopback peer; otherwise a non-exempt sentinel.
        if let Some(addr) = peer_addr {
            if !addr.ip().is_loopback() {
                return addr.ip().to_string();
            }
        }
        return "unknown".to_string();
    }

    peer_addr
        .map(|addr| addr.ip().to_string())
        .unwrap_or_else(|| "unknown".to_string())
}

/// Whether this request counts as a local (loopback) caller for locality guards.
///
/// Defined as the rate-limit key being a loopback address, so
/// [`client_key_from_request`] and SOP-cancel locality cannot drift apart: a
/// forwarded loopback address is never local, and a direct loopback peer with
/// no trusted forwarded header still is.
pub(crate) fn request_is_local(
    peer_addr: Option<SocketAddr>,
    headers: &HeaderMap,
    trust_forwarded_headers: bool,
) -> bool {
    auth_rate_limit::is_loopback_key(&client_key_from_request(
        peer_addr,
        headers,
        trust_forwarded_headers,
    ))
}

fn normalize_max_keys(configured: usize, fallback: usize) -> usize {
    if configured == 0 {
        fallback.max(1)
    } else {
        configured
    }
}

fn default_agent_alias(config: &Config) -> Option<String> {
    config
        .agents
        .iter()
        .filter(|(_, a)| a.enabled)
        .map(|(alias, _)| alias.clone())
        .min()
}

/// Serialization witness for config authorization and retained persistence.
pub(crate) type ConfigWriteGuard = zeroclaw_runtime::live_config_authority::ConfigCommit;

/// Shared state for all axum handlers
#[derive(Clone)]
pub struct AppState {
    /// Read-only live config handle: HTTP readers observe the published
    /// config and its revision as one pair and cannot bypass publication
    /// with a raw write. Mutating handlers admit through
    /// `AppState::begin_config_commit` instead.
    pub config: zeroclaw_config::live::LiveConfigHandle,

    /// The live-config authority owning this gateway run's publication
    /// transaction: the process-wide writer mutex, the config-write
    /// lifecycle lease, and the published pair. Every HTTP config writer
    /// serializes through it before cloning the current config; the
    /// irreversible save-and-publish phase of each commit runs retained,
    /// so request cancellation cannot abandon a dispatched commit. Mirrors
    /// `RpcContext::config_authority` in the RPC path.
    pub config_authority: zeroclaw_runtime::LiveConfigAuthority,
    pub agent_lifecycle: zeroclaw_runtime::live_config_authority::AgentLifecycleCoordinator,
    pub model_provider: Arc<dyn ModelProvider>,
    pub model: String,
    /// `None` means "let the provider decide" — required for models
    /// (e.g. claude-opus-4-7) that reject the field. Always preserve
    /// `Option<f64>` end-to-end; never substitute a hardcoded default.
    pub temperature: Option<f64>,
    pub mem: Arc<dyn Memory>,
    pub memory_strategy: Arc<dyn MemoryStrategy>,
    pub auto_save: bool,
    pub pairing: Arc<PairingGuard>,
    pub trust_forwarded_headers: bool,
    pub rate_limiter: Arc<GatewayRateLimiter>,
    pub auth_limiter: Arc<auth_rate_limit::AuthRateLimiter>,
    pub idempotency_store: Arc<IdempotencyStore>,
    /// `WhatsApp` channel instances keyed by config alias. Webhooks route by
    /// `/whatsapp/{alias}`; the bare `/whatsapp` path falls back to the first
    /// instance (see [`api_webhook`]).
    #[cfg(feature = "channel-whatsapp-cloud")]
    pub whatsapp: HashMap<String, Arc<WhatsAppChannel>>,
    /// `WhatsApp` app secrets keyed by alias for webhook signature verification
    /// (`X-Hub-Signature-256`).
    #[cfg(feature = "channel-whatsapp-cloud")]
    pub whatsapp_app_secret: HashMap<String, Arc<str>>,
    #[cfg(feature = "channel-linq")]
    pub linq: HashMap<String, Arc<LinqChannel>>,
    /// Linq webhook signing secrets per alias
    #[cfg(feature = "channel-linq")]
    pub linq_signing_secrets: HashMap<String, Arc<str>>,
    /// Nextcloud Talk channel instances keyed by config alias.
    #[cfg(feature = "channel-nextcloud")]
    pub nextcloud_talk: HashMap<String, Arc<NextcloudTalkChannel>>,
    /// Nextcloud Talk webhook secrets keyed by alias for signature verification.
    #[cfg(feature = "channel-nextcloud")]
    pub nextcloud_talk_webhook_secret: HashMap<String, Arc<str>>,
    /// Gmail Pub/Sub push notification channel
    #[cfg(feature = "channel-email")]
    pub gmail_push: Option<Arc<GmailPushChannel>>,
    /// Observability backend for metrics scraping
    pub observer: Arc<dyn zeroclaw_runtime::observability::Observer>,
    /// Registered tool specs (for web dashboard tools page). This is the
    /// default (no `?agent=`) listing, seeded from the deterministically
    /// smallest enabled agent alias.
    pub tools_registry: Arc<Vec<ToolSpec>>,
    /// Per-agent tool-spec listings keyed by agent alias, powering the
    /// agent-aware `GET /api/tools?agent=<alias>` view so the WebUI Tools
    /// page can show each agent's scoped tool set. Falls back to
    /// `tools_registry` for an unknown or omitted alias.
    pub tools_registry_by_agent: Arc<HashMap<String, Arc<Vec<ToolSpec>>>>,
    /// Cost tracker (optional, for web dashboard cost page)
    pub cost_tracker: Option<Arc<CostTracker>>,
    /// SSE broadcast channel for real-time events
    pub event_tx: tokio::sync::broadcast::Sender<serde_json::Value>,
    /// Ring buffer of recent events for history replay
    pub event_buffer: Arc<sse::EventBuffer>,
    /// Shutdown signal sender for graceful shutdown
    pub shutdown_tx: tokio::sync::watch::Sender<bool>,
    /// Reload signal sender owned by the daemon. /admin/reload writes `true`
    /// here; the daemon's wait loop reacts and re-instantiates every
    /// subsystem in place. `None` when running standalone (`zeroclaw gateway start`)
    /// — reload then degrades to a 503 with a clear message.
    pub reload_tx: Option<zeroclaw_runtime::daemon::GatewayReloadControls>,
    /// Registry of dynamically connected nodes
    pub node_registry: Arc<nodes::NodeRegistry>,
    /// LAN-local peer hints discovered by multicast. These are informational
    /// only; they never authorize or connect a peer.
    pub mdns_peer_registry: nodes::mdns::MdnsPeerRegistry,
    /// Path prefix for reverse-proxy deployments (empty string = no prefix)
    pub path_prefix: String,
    /// Filesystem path to `web/dist/` for serving the dashboard (None = API-only)
    pub web_dist_dir: Option<std::path::PathBuf>,
    /// Session backend for persisting gateway WS chat sessions
    pub session_backend: Option<Arc<dyn SessionBackend>>,
    /// Per-session actor queue for serializing concurrent turns
    pub session_queue: Arc<session_queue::SessionActorQueue>,
    /// Device registry for paired device management
    pub device_registry: Option<Arc<api_pairing::DeviceRegistry>>,
    /// Shared canvas store for Live Canvas (A2UI) system
    pub canvas_store: CanvasStore,
    /// WebAuthn state for hardware key authentication (optional, requires `webauthn` feature)
    #[cfg(feature = "webauthn")]
    pub webauthn: Option<Arc<api_webauthn::WebAuthnState>>,
    /// Per-session cancellation tokens for aborting in-flight agent responses.
    /// Key is session_key (e.g. `gw_<session_id>`), value is the token for the
    /// current turn. Entries are inserted before each turn and removed after
    /// completion (normal or cancelled). The outer `Arc` provides turn identity
    /// so late cleanup cannot remove a replacement turn's token.
    pub cancel_tokens: Arc<
        std::sync::Mutex<
            std::collections::HashMap<String, Arc<tokio_util::sync::CancellationToken>>,
        >,
    >,
    pub pending_reload: Arc<std::sync::atomic::AtomicBool>,
    /// TUI session registry from the daemon (for /api/tuis endpoint).
    /// `None` when the gateway runs standalone without a daemon.
    pub tui_registry: Option<Arc<zeroclaw_runtime::rpc::tui_identity::TuiRegistry>>,
    /// Shared SOP engine from the daemon (for WS agent sessions).
    /// `None` when the gateway runs standalone — sessions build their own.
    pub sop_engine: Option<Arc<std::sync::Mutex<zeroclaw_runtime::sop::SopEngine>>>,
    /// Shared SOP audit logger from the daemon (for WS agent sessions).
    pub sop_audit: Option<Arc<zeroclaw_runtime::sop::SopAuditLogger>>,
    pub sop_driver_handles: Option<zeroclaw_runtime::sop::SopDriverHandles>,
}

impl AppState {
    pub(crate) fn reserve_agent_turn_at(
        &self,
        alias: impl Into<String>,
        generation: u64,
    ) -> Result<
        zeroclaw_runtime::live_config_authority::AgentTurnLease,
        zeroclaw_runtime::live_config_authority::AgentAdmissionError,
    > {
        self.agent_lifecycle.reserve_turn_at(alias, generation)
    }
    /// Admit one serialized config write on this gateway's authority.
    /// Fails closed once the daemon generation is closing.
    pub(crate) async fn begin_config_commit(
        &self,
    ) -> Result<
        zeroclaw_runtime::live_config_authority::ConfigCommit,
        zeroclaw_runtime::live_config_authority::ConfigCommitError,
    > {
        self.config_authority.begin_config_commit().await
    }
}

/// Daemon-owned services whose lifecycle matches one supervised gateway run.
pub struct GatewaySupervision {
    readiness: Option<zeroclaw_runtime::daemon::GatewayReadinessReporter>,
    plugin_webhooks: Arc<zeroclaw_api::webhook::PluginWebhookRegistry>,
    authority: zeroclaw_runtime::LiveConfigAuthority,
    /// The daemon generation's driver supervisor set. Approval surfaces
    /// register resumed headless drivers here so a reload drains them with the
    /// generation that owns them. `None` standalone, where no generation exists.
    sop_driver_handles: Option<zeroclaw_runtime::sop::SopDriverHandles>,
    /// Where the relay bridge hands over the browser connections of a
    /// relay-served dashboard (`[relay.dashboard]`). `None` serves none.
    dashboard_ingress: Option<zeroclaw_runtime::relay_dashboard::DashboardIngress>,
}

impl GatewaySupervision {
    /// Pair startup readiness with the channel supervisor's route generation.
    #[must_use]
    pub fn new(
        readiness: Option<zeroclaw_runtime::daemon::GatewayReadinessReporter>,
        plugin_webhooks: Arc<zeroclaw_api::webhook::PluginWebhookRegistry>,
        authority: zeroclaw_runtime::LiveConfigAuthority,
        sop_driver_handles: Option<zeroclaw_runtime::sop::SopDriverHandles>,
    ) -> Self {
        Self {
            readiness,
            plugin_webhooks,
            authority,
            sop_driver_handles,
            dashboard_ingress: None,
        }
    }

    /// Serve the dashboard connections the relay bridge delivers to
    /// `ingress` as well as this gateway's own listener.
    #[must_use]
    pub fn with_dashboard_ingress(
        mut self,
        ingress: zeroclaw_runtime::relay_dashboard::DashboardIngress,
    ) -> Self {
        self.dashboard_ingress = Some(ingress);
        self
    }
}

/// The relay-forwarded dashboard connections one gateway generation
/// serves. Waits forever when it has none attached, or once a later
/// generation has taken over and every connection queued here is served.
struct DashboardFeed(Option<zeroclaw_runtime::relay_dashboard::DashboardIngressReceiver>);

impl DashboardFeed {
    async fn next(&mut self) -> zeroclaw_runtime::relay_dashboard::DashboardConn {
        loop {
            match &mut self.0 {
                Some(receiver) => match receiver.recv().await {
                    Some(conn) => return conn,
                    None => self.0 = None,
                },
                None => std::future::pending::<()>().await,
            }
        }
    }
}

/// The config/onboarding route group. Authentication is enforced
/// structurally by the `route_layer` at the tail (see [`principal_gate`]),
/// never per handler: every route whose handler lives in `api_config`,
/// `api_quickstart`, or `api_sections` MUST be registered on THIS router,
/// whatever its URL prefix.
fn config_admin_router(route_auth: principal_gate::ConfigRouteAuth) -> Router<AppState> {
    Router::new()
        .route(
            "/api/config",
            get(api_config::handle_config_get)
                .patch(api_config::handle_patch)
                .options(api_config::handle_options_config),
        )
        .route(
            "/api/config/prop",
            get(api_config::handle_prop_get)
                .put(api_config::handle_prop_put)
                .delete(api_config::handle_prop_delete)
                .options(api_config::handle_options_prop),
        )
        .route("/api/config/list", get(api_config::handle_list))
        .route("/api/config/drift", get(api_config::handle_drift))
        .route(
            "/api/config/reload-status",
            get(api_config::handle_reload_status),
        )
        .route("/api/config/templates", get(api_config::handle_templates))
        .route("/api/config/map-keys", get(api_config::handle_get_map_keys))
        .route(
            "/api/config/resolve-alias-source",
            get(api_config::handle_resolve_alias_source),
        )
        .route(
            "/api/config/map-key",
            post(api_config::handle_map_key).delete(api_config::handle_delete_map_key),
        )
        .route(
            "/api/config/rename-map-key",
            post(api_config::handle_rename_map_key),
        )
        .route(
            "/api/config/model-providers/{type}/{alias}/refresh-context-window",
            post(api_config::handle_refresh_context_window),
        )
        .route(
            "/api/config/delete-plan",
            get(api_config::handle_delete_plan),
        )
        .route("/api/config/catalog", get(api_sections::handle_catalog))
        .route(
            "/api/config/catalog/models",
            get(api_sections::handle_catalog_models),
        )
        .route(
            "/api/config/status",
            get(api_sections::handle_section_status),
        )
        .route(
            "/api/config/agent-options",
            get(api_sections::handle_agent_options),
        )
        .route("/api/config/sections", get(api_sections::handle_sections))
        .route(
            "/api/config/sections/{section}",
            get(api_sections::handle_section_picker),
        )
        .route(
            "/api/config/sections/{section}/items/{key}",
            post(api_sections::handle_section_select),
        )
        .route("/api/quickstart/state", get(api_quickstart::handle_state))
        .route(
            "/api/quickstart/fields",
            post(api_quickstart::handle_fields),
        )
        .route(
            "/api/quickstart/validate",
            post(api_quickstart::handle_validate),
        )
        .route("/api/quickstart/apply", post(api_quickstart::handle_apply))
        .route(
            "/api/quickstart/dismiss",
            post(api_quickstart::handle_dismiss),
        )
        .route("/api/config/init", post(api_config::handle_init))
        .route("/api/config/migrate", post(api_config::handle_migrate))
        .route(
            "/api/channels/bind",
            post(api_config::handle_api_channel_bind),
        )
        .route_layer(axum::middleware::from_fn_with_state(
            route_auth,
            principal_gate::config_route_auth,
        ))
}

/// How long a stopping gateway lets its connections finish the requests in
/// flight. With [`RETIRE_JOIN`] it stays inside the daemon's 500 ms grace for
/// the gateway, so what is left is cancelled before that grace runs out.
const CONNECTION_DRAIN: Duration = Duration::from_millis(300);

#[cfg(test)]
tokio::task_local! {
    static LISTENER_RELEASED: std::cell::RefCell<Option<tokio::sync::oneshot::Sender<()>>>;
}

fn release_listener(listener: tokio::net::TcpListener) {
    drop(listener);
    #[cfg(test)]
    let _ = LISTENER_RELEASED.try_with(|released| {
        if let Some(released) = released.borrow_mut().take() {
            let _ = released.send(());
        }
    });
}

/// How long retirement waits for the tasks it cancelled to end. Cancelling
/// only asks: a task ends, and drops what it owns, when it is next polled.
const RETIRE_JOIN: Duration = Duration::from_millis(100);

/// Every task one gateway's serving runs: one per connection, and the
/// stream tasks hyper's HTTP/2 spawns through its executor. A stop cancels
/// them all at once, and the set counts each task until it has been
/// destroyed.
#[derive(Clone, Default)]
struct ServeTasks(Arc<ServeTasksInner>);

#[derive(Default)]
struct ServeTasksInner {
    live: std::sync::atomic::AtomicUsize,
    idle: tokio::sync::Notify,
    cancelled: tokio_util::sync::CancellationToken,
}

/// A task of the set. Fields drop in declaration order, so the future, and
/// everything it owns, is destroyed before `_done` takes the task off the
/// count, also when the task is dropped before its first poll.
struct ServeTask {
    future: std::pin::Pin<Box<dyn Future<Output = ()> + Send>>,
    _done: ServeTaskDone,
}

/// Takes its task off the count.
struct ServeTaskDone(Arc<ServeTasksInner>);

impl Drop for ServeTaskDone {
    fn drop(&mut self) {
        if self
            .0
            .live
            .fetch_sub(1, std::sync::atomic::Ordering::AcqRel)
            == 1
        {
            self.0.idle.notify_waiters();
        }
    }
}

impl ServeTasks {
    fn spawn<F>(&self, future: F)
    where
        F: Future<Output = ()> + Send + 'static,
    {
        self.0
            .live
            .fetch_add(1, std::sync::atomic::Ordering::AcqRel);
        let task = ServeTask {
            future: Box::pin(future),
            _done: ServeTaskDone(Arc::clone(&self.0)),
        };
        let cancelled = self.0.cancelled.clone();
        // No lock is held here: spawning can drop the task at once (a runtime
        // that has shut down does), and that only updates the count.
        // Every connection and HTTP/2 stream is one of these tasks, so their
        // lifecycle is recorded at DEBUG: at INFO it would fill the runtime
        // trace with routine traffic.
        zeroclaw_spawn::spawn!(level = DEBUG, async move {
            // Moves the whole task in. Naming only `task.future` below would
            // capture just that field, and `_done` would take the task off the
            // count as soon as `spawn` returned.
            let mut task = task;
            // The cancel is checked first, so a task spawned after it never
            // runs.
            tokio::select! {
                biased;
                () = cancelled.cancelled() => {}
                () = task.future.as_mut() => {}
            }
        });
    }

    /// How many tasks are running, or not yet destroyed.
    fn live(&self) -> usize {
        self.0.live.load(std::sync::atomic::Ordering::Acquire)
    }

    /// Resolves once no task is running.
    async fn idle(&self) {
        loop {
            let notified = self.0.idle.notified();
            tokio::pin!(notified);
            notified.as_mut().enable();
            if self.live() == 0 {
                return;
            }
            notified.await;
        }
    }

    /// Cancel every task, and any spawned later: each ends at its next poll.
    fn cancel(&self) {
        self.0.cancelled.cancel();
    }

    fn is_cancelled(&self) -> bool {
        self.0.cancelled.is_cancelled()
    }

    /// Wait up to `within` for every task to finish, then cancel the rest and
    /// wait a little for them to end. Whether all finished in time. A task in
    /// code that never yields can outlast this; it admits no request, and
    /// ends at its next poll.
    async fn retire_within(&self, within: Duration) -> bool {
        if tokio::time::timeout(within, self.idle()).await.is_ok() {
            return true;
        }
        self.cancel();
        if tokio::time::timeout(RETIRE_JOIN, self.idle())
            .await
            .is_err()
        {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({"remaining": self.live()})),
                "gateway tasks were still running after they were cancelled; each ends at its next poll"
            );
        }
        false
    }
}

impl<F> hyper::rt::Executor<F> for ServeTasks
where
    F: Future + Send + 'static,
    F::Output: Send + 'static,
{
    fn execute(&self, future: F) {
        self.spawn(async move {
            let _ = future.await;
        });
    }
}

/// Owned by a gateway's serve loop. If the gateway is dropped before its
/// drain ran (the daemon aborted it), its tasks are cancelled here.
struct ServeTasksGuard(ServeTasks);

impl ServeTasksGuard {
    fn new(tasks: ServeTasks) -> Self {
        Self(tasks)
    }
}

impl Drop for ServeTasksGuard {
    fn drop(&mut self) {
        self.0.cancel();
    }
}

/// Whether the gateway that accepted a connection still admits requests on
/// it: not once it has been told to stop, and not once its tasks were
/// cancelled (it was dropped without a stop).
#[derive(Clone)]
struct Admission {
    stopping: tokio::sync::watch::Receiver<bool>,
    tasks: ServeTasks,
}

impl Admission {
    fn admits(&self) -> bool {
        // The stop is a value, not a change: a receiver made after it still
        // reads it.
        !*self.stopping.borrow() && !self.tasks.is_cancelled()
    }
}

/// Serve one request on a connection the gateway accepted, unless the
/// gateway has stopped since. So nothing reaches a stopped gateway's
/// router, whichever connection or HTTP/2 stream it arrives on, an upgrade
/// request included.
async fn serve_while_current<S, B>(
    mut svc: S,
    admission: &Admission,
    req: axum::http::Request<B>,
) -> Result<Response, std::convert::Infallible>
where
    S: tower::Service<
            axum::http::Request<B>,
            Response = Response,
            Error = std::convert::Infallible,
        >,
{
    if !admission.admits() {
        return Ok(gateway_restarting(req.version()));
    }
    tower::Service::call(&mut svc, req).await
}

/// What a stopped gateway answers: try again on a new connection, which the
/// next gateway serves. Nothing in it comes from the stopped gateway's
/// configuration or state.
pub(crate) fn gateway_restarting(version: axum::http::Version) -> Response {
    let mut response = (
        StatusCode::SERVICE_UNAVAILABLE,
        [(header::RETRY_AFTER, "1")],
        Json(serde_json::json!({
            "error": "The gateway is restarting. Try again.",
            "reason": "gateway_restarting",
        })),
    )
        .into_response();
    // HTTP/1 closes the connection after this response. HTTP/2 has no
    // Connection header: its connection gets GOAWAY from the graceful
    // shutdown.
    if version < axum::http::Version::HTTP_2 {
        response.headers_mut().insert(
            header::CONNECTION,
            axum::http::HeaderValue::from_static("close"),
        );
    }
    response
}

/// What the accept loop does after `accept()` failed.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum AcceptErrorAction {
    /// Accept again at once.
    Retry,
    /// Accept again after this long, unless the gateway is stopped first.
    RetryAfter(Duration),
    /// The listener cannot recover: stop serving.
    Fail,
}

fn accept_error_action(error: &std::io::Error, tls: bool) -> AcceptErrorAction {
    if tls {
        return if is_recoverable_accept_error(error) {
            AcceptErrorAction::RetryAfter(Duration::from_millis(ACCEPT_ERROR_BACKOFF_MS))
        } else {
            AcceptErrorAction::Fail
        };
    }
    // The plain listener's rule from `axum::serve`: a connection that failed
    // before it was accepted is skipped, anything else (running out of file
    // descriptors, say) is waited out for a second, and it never gives up.
    if matches!(
        error.kind(),
        std::io::ErrorKind::ConnectionRefused
            | std::io::ErrorKind::ConnectionAborted
            | std::io::ErrorKind::ConnectionReset
    ) {
        AcceptErrorAction::Retry
    } else {
        AcceptErrorAction::RetryAfter(Duration::from_secs(1))
    }
}

/// Wait `delay` before accepting again. Whether the gateway was told to stop
/// meanwhile.
async fn accept_backoff(
    delay: Duration,
    stopping: &mut tokio::sync::watch::Receiver<bool>,
) -> bool {
    tokio::select! {
        () = tokio::time::sleep(delay) => false,
        () = gateway_stop_requested(stopping) => true,
    }
}

/// Resolves when the gateway is told to stop; never, if it no longer can be.
async fn gateway_stop_requested(stopping: &mut tokio::sync::watch::Receiver<bool>) {
    if stopping.changed().await.is_err() {
        std::future::pending::<()>().await;
    }
}

/// Run the HTTP gateway using axum with proper HTTP/1.1 compliance.
#[allow(clippy::too_many_lines)]
// One parameter per daemon-owned dependency; a bundling struct would only
// move the list. Matches the existing allowance on the runtime spawn paths.
#[allow(clippy::too_many_arguments)]
pub async fn run_gateway(
    host: &str,
    port: u16,
    config: Config,
    // The daemon's event bus. The daemon owns the observer broadcast hook, so a
    // supervised gateway reuses its sender and history and installs nothing;
    // a standalone gateway (`None`) builds and installs its own.
    external_event_bus: Option<zeroclaw_runtime::observability::EventBus>,
    // Reload controls owned by the daemon for supervised runs. RPC reloads
    // write to `shutdown_tx` before signalling daemon reload so the listener
    // releases its socket before the replacement gateway binds. /admin/reload
    // writes to both controls directly. Standalone gateway passes `None`.
    reload_controls: Option<zeroclaw_runtime::daemon::GatewayReloadControls>,
    // TUI session registry from the daemon for the /api/tuis endpoint.
    tui_registry: Option<Arc<zeroclaw_runtime::rpc::tui_identity::TuiRegistry>>,
    canvas_store: Option<CanvasStore>,
    // Shared SOP engine from the daemon. `None` when standalone — sessions build their own.
    sop_engine: Option<Arc<std::sync::Mutex<zeroclaw_runtime::sop::SopEngine>>>,
    sop_audit: Option<Arc<zeroclaw_runtime::sop::SopAuditLogger>>,
    // The daemon generation's one inbound-auth state (pairing guard,
    // accepted policy, live configuration), shared with the RPC context.
    // `None` (standalone gateway) builds all three locally from config.
    daemon_authority: Option<zeroclaw_runtime::daemon::DaemonInboundAuthority>,
    // The daemon generation's driver supervisor set: approval surfaces
    // register resumed headless drivers here so reload drains them.
    sop_driver_handles: Option<zeroclaw_runtime::sop::SopDriverHandles>,
    readiness: Option<zeroclaw_runtime::daemon::GatewayReadinessReporter>,
) -> Result<()> {
    let authority = zeroclaw_runtime::LiveConfigAuthority::new_owned(config.clone())?;
    run_gateway_with_authority(
        host,
        port,
        config,
        external_event_bus,
        reload_controls,
        tui_registry,
        canvas_store,
        sop_engine,
        sop_audit,
        daemon_authority,
        sop_driver_handles,
        readiness,
        authority,
    )
    .await
}

/// Run the gateway with the live config authority owned by its daemon
/// generation.
#[allow(clippy::too_many_arguments, clippy::too_many_lines)]
pub async fn run_gateway_with_authority(
    host: &str,
    port: u16,
    config: Config,
    external_event_bus: Option<zeroclaw_runtime::observability::EventBus>,
    reload_controls: Option<zeroclaw_runtime::daemon::GatewayReloadControls>,
    tui_registry: Option<Arc<zeroclaw_runtime::rpc::tui_identity::TuiRegistry>>,
    canvas_store: Option<CanvasStore>,
    sop_engine: Option<Arc<std::sync::Mutex<zeroclaw_runtime::sop::SopEngine>>>,
    sop_audit: Option<Arc<zeroclaw_runtime::sop::SopAuditLogger>>,
    daemon_authority: Option<zeroclaw_runtime::daemon::DaemonInboundAuthority>,
    sop_driver_handles: Option<zeroclaw_runtime::sop::SopDriverHandles>,
    readiness: Option<zeroclaw_runtime::daemon::GatewayReadinessReporter>,
    authority: zeroclaw_runtime::LiveConfigAuthority,
) -> Result<()> {
    Box::pin(run_gateway_with_plugin_webhooks(
        host,
        port,
        config,
        external_event_bus,
        reload_controls,
        tui_registry,
        canvas_store,
        sop_engine,
        sop_audit,
        daemon_authority,
        GatewaySupervision::new(
            readiness,
            Arc::new(zeroclaw_api::webhook::PluginWebhookRegistry::new()),
            authority,
            sop_driver_handles,
        ),
    ))
    .await
}

/// Run the supervised gateway with the daemon generation's channel-plugin
/// webhook registry and live-config authority.
#[allow(clippy::too_many_lines)]
#[allow(clippy::too_many_arguments)] // supervised-run wiring; params mirror run_gateway plus the plugin webhook registry
pub async fn run_gateway_with_plugin_webhooks(
    host: &str,
    port: u16,
    config: Config,
    external_event_bus: Option<zeroclaw_runtime::observability::EventBus>,
    reload_controls: Option<zeroclaw_runtime::daemon::GatewayReloadControls>,
    tui_registry: Option<Arc<zeroclaw_runtime::rpc::tui_identity::TuiRegistry>>,
    canvas_store: Option<CanvasStore>,
    sop_engine: Option<Arc<std::sync::Mutex<zeroclaw_runtime::sop::SopEngine>>>,
    sop_audit: Option<Arc<zeroclaw_runtime::sop::SopAuditLogger>>,
    // The daemon generation's one inbound-auth state, shared with the RPC
    // context so pairing, revocation and policy changes persisted through
    // either surface bind both. Standalone runs pass `None` and build their
    // own guard, authority and configuration state from config.
    daemon_authority: Option<zeroclaw_runtime::daemon::DaemonInboundAuthority>,
    supervision: GatewaySupervision,
) -> Result<()> {
    let GatewaySupervision {
        readiness,
        plugin_webhooks,
        authority,
        sop_driver_handles,
        dashboard_ingress,
    } = supervision;
    let (shared_pairing, shared_inbound_auth, shared_config, shared_cert_audit) =
        match daemon_authority {
            Some(authority) => (
                Some(authority.pairing),
                Some(authority.inbound_auth),
                Some(authority.config),
                authority.cert_audit,
            ),
            None => (None, None, None, None),
        };

    // The in-process RPC seam: dial the daemon's dispatcher when a
    // supervised run provides its connector, and hand the handle to every
    // request as an extension so routes can migrate onto RPC one at a time.
    // The gateway has no credential of its own yet, so the dial is refused
    // and the seam stays idle until that credential exists; it never rides
    // the daemon's anonymous compatibility path.
    let core_rpc = core_rpc::CoreRpc::default();
    if let Some(connector) = reload_controls
        .as_ref()
        .and_then(|controls| controls.inproc.clone())
    {
        core_rpc.attach_inproc(connector, zeroclaw_rpc_client::ConnectOptions::default());
    }
    // ── Security: warn on public bind without tunnel or explicit opt-in ──
    if is_public_bind(host)
        && config.tunnel.tunnel_provider == "none"
        && !config.gateway.allow_public_bind
    {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                .with_outcome(::zeroclaw_log::EventOutcome::Unknown),
            "⚠️  Binding to {host} — gateway will be exposed to all network interfaces.\n\
             Suggestion: use --host 127.0.0.1 (default), configure a tunnel, or set\n\
             [gateway] allow_public_bind = true in config.toml to silence this warning.\n\n\
             Docker/VM: if you are running inside a container or VM, this is expected."
        );
    }
    // Supervised HTTP and RPC readers share the daemon's published config.
    let config_state = shared_config.unwrap_or_else(|| authority.live_handle());

    let addr: SocketAddr = match zeroclaw_infra::parse_gateway_bind_socket_addr(host, port) {
        Ok(a) => a,
        Err(e) => {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({
                        "host": host,
                        "port": port,
                        "error": format!("{e}"),
                    })),
                "Gateway: host:port did not parse as a SocketAddr; falling back to \
                 127.0.0.1 so the gateway can still boot. Fix [gateway] host and \
                 POST /admin/reload."
            );
            zeroclaw_infra::fallback_gateway_bind_socket_addr(port)
        }
    };
    let listener = tokio::net::TcpListener::bind(addr).await?;
    let actual_addr = listener.local_addr()?;
    let actual_port = actual_addr.port();
    let display_addr = format!("{host}:{actual_port}");

    // Seed the install-wide default provider from the first entry that
    // actually declares a `model`. Entries without one cannot serve as the
    // default (there is no model string to pair with the provider), so
    // skipping them keeps the boot family, credentials, runtime options, and
    // model coherent — the previous "first entry, whatever it is" pick could
    // build the provider from one entry while `resolve_default_model` sourced
    // the model from another.
    let (boot_family, boot_alias, boot_entry) = config
        .providers
        .models
        .first_entry_with_model()
        .map(|(f, a, e)| (f.to_string(), a.to_string(), Some(e)))
        .unwrap_or_else(|| ("openrouter".to_string(), "default".to_string(), None));
    let fallback = boot_entry;
    let model_provider_name = boot_family.as_str();
    let (model_provider, boot_provider_failed): (Arc<dyn ModelProvider>, bool) =
        match zeroclaw_providers::create_resilient_model_provider_from_ref(
            &config,
            model_provider_name,
            fallback.and_then(|e| e.api_key.as_deref()),
            fallback.and_then(|e| e.uri.as_deref()),
            &config.reliability,
            &zeroclaw_providers::provider_runtime_options_for_alias(
                &config,
                &boot_family,
                &boot_alias,
            ),
        ) {
            Ok(p) => (Arc::from(p), false),
            Err(e) => {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note,)
                        .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                        .with_attrs(::serde_json::json!({
                            "model_provider": model_provider_name,
                            "alias": boot_alias,
                            "error": format!("{e}"),
                        })),
                    "Gateway: seed model_provider failed to construct; booting in \
                     needs_quickstart mode so /quickstart and /admin/reload stay \
                     reachable. Fix the [providers.models.<type>.<alias>] entry \
                     and POST /admin/reload."
                );
                (
                    Arc::new(UnconfiguredModelProvider) as Arc<dyn ModelProvider>,
                    true,
                )
            }
        };
    let model = if boot_provider_failed {
        String::new()
    } else {
        // `first_entry_with_model` guarantees a non-empty model for the boot
        // entry, so reaching the empty fallback means no entry declares a
        // model at all — the needs_quickstart onboarding path.
        let model = fallback
            .and_then(|e| e.model.as_deref())
            .map(str::trim)
            .filter(|m| !m.is_empty())
            .map(ToString::to_string);
        if model.is_none() {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({"display_addr": display_addr})),
                &format!(
                    "Gateway booting without a configured model. Visit http://{display_addr}/quickstart to complete browser quickstart. Chat endpoints will return 503 needs_quickstart until at least one [providers.models.<type>.<alias>] model = \"...\" is set."
                )
            );
        }
        model.unwrap_or_default()
    };
    // Preserve `Option<f64>` end-to-end. Substituting a hardcoded default
    // here would clobber the "let the provider decide" intent for models
    // (e.g. claude-opus-4-7) that reject `temperature`.
    let temperature: Option<f64> = fallback.and_then(|e| e.temperature);
    let mem: Arc<dyn Memory> = if config.agents.is_empty() {
        Arc::new(zeroclaw_memory::NoneMemory::new("none"))
    } else {
        match zeroclaw_memory::create_memory_from_config(
            &config,
            fallback.and_then(|e| e.api_key.as_deref()),
        ) {
            Ok(m) => Arc::from(m),
            Err(e) => {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note,)
                        .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                        .with_attrs(::serde_json::json!({"error": format!("{e}")})),
                    "Gateway: memory backend failed to construct; falling back to \
                     NoneMemory so the gateway can still boot. Fix [memory] and \
                     POST /admin/reload."
                );
                Arc::new(zeroclaw_memory::NoneMemory::new("none"))
            }
        }
    };
    let runtime: Arc<dyn platform::RuntimeAdapter> = match platform::create_runtime(&config.runtime)
    {
        Ok(r) => Arc::from(r),
        Err(e) => {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note,)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({
                        "runtime_kind": config.runtime.kind,
                        "error": format!("{e}"),
                    })),
                "Gateway: runtime adapter failed to construct; falling back to \
                     NativeRuntime so the gateway can still boot. Fix [runtime] and \
                     POST /admin/reload."
            );
            Arc::new(platform::NativeRuntime::new())
        }
    };
    let memory_strategy: Arc<dyn MemoryStrategy> = Arc::new(DefaultMemoryStrategy::with_config(
        mem.clone(),
        config.memory.clone(),
        config.data_dir.clone(),
    ));
    let canvas_store = canvas_store.unwrap_or_default();
    let agent_alias_opt = default_agent_alias(&config);

    let (composio_key, composio_entity_id) = if config.composio.enabled {
        (
            config.composio.api_key.as_deref(),
            Some(config.composio.entity_id.as_str()),
        )
    } else {
        (None, None)
    };

    let agent_setup: Option<(
        zeroclaw_config::schema::RiskProfileConfig,
        Arc<SecurityPolicy>,
    )> = agent_alias_opt.as_ref().and_then(|agent_alias| {
        let Some(risk_profile) = config.risk_profile_for_agent(agent_alias) else {
            ::zeroclaw_log::record!(WARN, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_outcome(::zeroclaw_log::EventOutcome::Unknown).with_attrs(::serde_json::json!({"agent": agent_alias, "agent_alias": agent_alias})), "Gateway: agents..risk_profile does not name a configured risk_profiles entry; booting with empty tools registry. Fix via /admin/reload or /quickstart.");
            return None;
        };
        let risk_profile = risk_profile.clone();
        let security = match SecurityPolicy::for_agent(&config, agent_alias) {
            Ok(s) => Arc::new(s),
            Err(e) => {
                ::zeroclaw_log::record!(WARN, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_outcome(::zeroclaw_log::EventOutcome::Unknown).with_attrs(::serde_json::json!({"agent": agent_alias, "error": format!("{}", e), "agent_alias": agent_alias})), "Gateway: agent SecurityPolicy failed to build; booting with empty tools registry. Fix [agents.] via /admin/reload or /quickstart.");
                return None;
            }
        };
        Some((risk_profile, security))
    });

    let (tools_registry_raw, _delegate_handle_gw) = match (&agent_alias_opt, agent_setup) {
        (Some(agent_alias), Some((risk_profile, security))) => {
            match tools::all_tools_with_runtime(
                Arc::new(config.clone()),
                &security,
                &risk_profile,
                agent_alias,
                Arc::clone(&runtime),
                Arc::clone(&mem),
                composio_key,
                composio_entity_id,
                &config.browser,
                &config.http_request,
                &config.web_fetch,
                &config.data_dir,
                &config.agents,
                config
                    .model_provider_for_agent(agent_alias)
                    .and_then(|e| e.api_key.as_deref()),
                &config,
                Some(canvas_store.clone()),
                false,
                None,
                sop_engine.clone(),
                sop_audit.clone(),
                None,
            ) {
                Ok(all_tools_result) => {
                    let assembled = scoped::ScopedToolRegistry::assemble(scoped::ScopedAssembly {
                        config: &config,
                        agent_alias,
                        security: &security,
                        built: all_tools_result,
                        // The gateway registers no skills today; unifying the two
                        // skill loaders through this seam is the Epic F follow-up.
                        skills: &[],
                        runtime: Arc::clone(&runtime),
                        caller_allowed: None,
                        connect_mcp: true,
                        // Gateway tool-listing path: short-lived, no cross-turn reuse
                        // contract, so the per-call connect is correct.
                        mcp_registry: None,
                        // Listing-only registry: loading peripherals physically opens
                        // hardware (exclusive serial holds) that the live turn paths
                        // need. Never connect them for a registry no turn runs against.
                        connect_peripherals: false,
                        emit_assembly_logs: false,
                        exclude_memory: false,
                        acp_delivery: false,
                        list_deferred_mcp_specs: true,
                    })
                    .await;
                    let reaction_handle_gw_opt = Some(assembled.reaction_handle.clone());
                    let channel_names =
                        zeroclaw_channels::orchestrator::register_channels_for_tools(
                            &config,
                            &assembled.ask_user_handle,
                            &assembled.channel_room_handle,
                            &reaction_handle_gw_opt,
                            &assembled.poll_handle,
                            &assembled.escalate_handle,
                        );
                    if !channel_names.is_empty() {
                        ::zeroclaw_log::record!(
                            INFO,
                            ::zeroclaw_log::Event::new(
                                module_path!(),
                                ::zeroclaw_log::Action::Note
                            )
                            .with_attrs(::serde_json::json!({"count": channel_names.len()})),
                            &format!(
                                "Registered {} channel(s) for dashboard agent",
                                channel_names.len()
                            ),
                        );
                    }
                    // Listing-only registry: no turn runs against it, so the
                    // deferred-MCP prompt section and activation handle returned by
                    // `assemble` have no consumer here (live gateway chat resolves
                    // its tools inside process_message).
                    (assembled.registry.into_inner(), assembled.delegate_handle)
                }
                Err(e) => {
                    ::zeroclaw_log::record!(
                        WARN,
                        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                            .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                            .with_attrs(::serde_json::json!({"agent_alias": agent_alias, "error": format!("{e}")})),
                        "Gateway: agent tool registry failed to build; booting with empty tools registry. Fix via /admin/reload or /quickstart."
                    );
                    (Vec::new(), None)
                }
            }
        }
        (Some(_), None) => {
            // Agent existed but its config failed to resolve. Warned
            // above; fall through to the empty-registry shape.
            (Vec::new(), None)
        }
        (None, _) => {
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_attrs(::serde_json::json!({"display_addr": display_addr})),
                &format!(
                    "Gateway: no [agents.<alias>] configured — booting with empty tools registry. Visit http://{display_addr}/quickstart to add an agent."
                )
            );
            (Vec::new(), None)
        }
    };

    let tools_registry: Arc<Vec<ToolSpec>> =
        Arc::new(tools_registry_raw.iter().map(|t| t.spec()).collect());

    let mut tools_registry_by_agent: HashMap<String, Arc<Vec<ToolSpec>>> = HashMap::new();
    if let Some(default_alias) = agent_alias_opt.as_ref() {
        tools_registry_by_agent.insert(default_alias.clone(), Arc::clone(&tools_registry));
    }
    let mut other_aliases: Vec<String> = config
        .agents
        .iter()
        .filter(|(alias, a)| a.enabled && Some(*alias) != agent_alias_opt.as_ref())
        .map(|(alias, _)| alias.clone())
        .collect();
    other_aliases.sort();
    for alias in other_aliases {
        let Some(risk_profile) = config.risk_profile_for_agent(&alias) else {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({"agent_alias": alias})),
                "Gateway: agent risk_profile does not resolve; skipping its /api/tools listing."
            );
            continue;
        };
        let risk_profile = risk_profile.clone();
        let security = match SecurityPolicy::for_agent(&config, &alias) {
            Ok(s) => Arc::new(s),
            Err(e) => {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                        .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                        .with_attrs(
                            ::serde_json::json!({"agent_alias": alias, "error": format!("{e}")})
                        ),
                    "Gateway: agent SecurityPolicy failed to build; skipping its /api/tools listing."
                );
                continue;
            }
        };
        let agent_tools_result = match tools::all_tools_with_runtime(
            Arc::new(config.clone()),
            &security,
            &risk_profile,
            &alias,
            Arc::clone(&runtime),
            Arc::clone(&mem),
            composio_key,
            composio_entity_id,
            &config.browser,
            &config.http_request,
            &config.web_fetch,
            &config.data_dir,
            &config.agents,
            config
                .model_provider_for_agent(&alias)
                .and_then(|e| e.api_key.as_deref()),
            &config,
            Some(canvas_store.clone()),
            false,
            None,
            sop_engine.clone(),
            sop_audit.clone(),
            None,
        ) {
            Ok(result) => result,
            Err(e) => {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                        .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                        .with_attrs(
                            ::serde_json::json!({"agent_alias": alias, "error": format!("{e}")})
                        ),
                    "Gateway: agent tool registry failed to build; exposing an empty /api/tools listing. Fix via /admin/reload or /quickstart."
                );
                // An absent alias falls back to the default agent's tools.
                tools_registry_by_agent.insert(alias, Arc::new(Vec::new()));
                continue;
            }
        };
        // Same gated seam as the dashboard seed above, so this listing shows
        // the agent's policy-filtered set (filter + MCP). The tools are only
        // enumerated for their specs, never invoked, so the returned channel
        // handles, deferred section, and activation handle are unused.
        let assembled = scoped::ScopedToolRegistry::assemble(scoped::ScopedAssembly {
            config: &config,
            agent_alias: &alias,
            security: &security,
            built: agent_tools_result,
            // Same divergence note as the dashboard seed: no skills on the
            // gateway until Epic F unifies the loaders.
            skills: &[],
            runtime: Arc::clone(&runtime),
            caller_allowed: None,
            connect_mcp: true,
            // Gateway tool-listing path: short-lived, no cross-turn reuse
            // contract, so the per-call connect is correct.
            mcp_registry: None,
            // Same as the seed: never open hardware for a listing (and
            // `config.peripherals` is global - N per-agent opens of the same
            // boards would fail against the first holder anyway).
            connect_peripherals: false,
            emit_assembly_logs: false,
            exclude_memory: false,
            acp_delivery: false,
            list_deferred_mcp_specs: true,
        })
        .await;
        let specs: Vec<ToolSpec> = assembled.registry.iter().map(|t| t.spec()).collect();
        tools_registry_by_agent.insert(alias, Arc::new(specs));
    }
    let tools_registry_by_agent: Arc<HashMap<String, Arc<Vec<ToolSpec>>>> =
        Arc::new(tools_registry_by_agent);

    // Cost tracker — process-global singleton so channels share the same instance
    let cost_tracker = CostTracker::get_or_init_global(config.cost.clone(), &config.data_dir);

    // The live-pricing refresher and the gateway-start hook belong to the
    // process that owns this listener (the daemon, or the standalone
    // `zeroclaw gateway` command), not to the listener: the refresher must run
    // with the gateway disabled, and the hook fires from the readiness report.
    // The gateway does own the live config handle its config API writes in
    // place, so it points the refresher at that handle. An operator's change
    // (an opt-out, a new endpoint or model) then reaches the next refresh
    // without a reload.
    zeroclaw_providers::pricing::bind_config(config_state.clone());

    // SSE broadcast channel for real-time events.
    // Use an externally provided sender (e.g. from the daemon) so that other
    // components (cron, heartbeat) can publish events to the same bus.
    // Under the daemon the bus and its observer hook are already live; a
    // standalone gateway builds and installs its own. Either way there is one
    // hook, so each observer event is delivered once and buffered once.
    let (event_bus, broadcast_hook_guard) =
        zeroclaw_runtime::observability::EventBus::shared_or_installed(external_event_bus);
    let event_tx = event_bus.sender().clone();
    let event_buffer = Arc::clone(event_bus.history());
    // WhatsApp channel instances (one per cloud-configured alias), keyed by
    // alias so `/whatsapp/{alias}` webhooks reach the matching instance
    #[cfg(feature = "channel-whatsapp-cloud")]
    let whatsapp_channel: HashMap<String, Arc<WhatsAppChannel>> = config
        .channels
        .whatsapp
        .iter()
        .filter(|(_, wa)| wa.is_cloud_config())
        .map(|(alias, wa)| {
            let peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync> = {
                let cfg_arc = config_state.clone();
                let alias = alias.clone();
                Arc::new(move || cfg_arc.read().channel_external_peers("whatsapp", &alias))
            };
            (
                alias.clone(),
                Arc::new(WhatsAppChannel::new(
                    wa.access_token.clone().unwrap_or_default(),
                    wa.phone_number_id.clone().unwrap_or_default(),
                    wa.verify_token.clone().unwrap_or_default(),
                    alias.clone(),
                    peer_resolver,
                )),
            )
        })
        .collect();

    // WhatsApp app secrets keyed by alias for webhook signature verification.
    #[cfg(feature = "channel-whatsapp-cloud")]
    let whatsapp_app_secret: HashMap<String, Arc<str>> = config
        .channels
        .whatsapp
        .iter()
        .filter_map(|(alias, wa)| {
            let secret = wa
                .app_secret
                .as_deref()
                .map(str::trim)
                .filter(|secret| !secret.is_empty())
                .map(ToOwned::to_owned)?;
            Some((alias.clone(), Arc::from(secret)))
        })
        .collect();

    // Linq channel instances (multi-tenant: one per alias)
    #[cfg(feature = "channel-linq")]
    let linq_channels: HashMap<String, Arc<LinqChannel>> = config
        .channels
        .linq
        .iter()
        .filter(|(_, lq)| lq.enabled)
        .map(|(alias, lq)| {
            let peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync> = {
                let cfg_arc = config_state.clone();
                let alias = alias.clone();
                Arc::new(move || cfg_arc.read().channel_external_peers("linq", &alias))
            };
            (
                alias.clone(),
                Arc::new(LinqChannel::new(
                    lq.api_token.clone(),
                    lq.from_phone.clone(),
                    alias.clone(),
                    peer_resolver,
                )),
            )
        })
        .collect();

    // Linq signing secrets per alias.
    #[cfg(feature = "channel-linq")]
    let linq_signing_secrets: HashMap<String, Arc<str>> = config
        .channels
        .linq
        .iter()
        .filter_map(|(alias, lq)| {
            let secret = lq
                .signing_secret
                .as_deref()
                .map(str::trim)
                .filter(|s| !s.is_empty())
                .map(ToOwned::to_owned)?;
            Some((alias.clone(), Arc::from(secret)))
        })
        .collect();

    // Nextcloud Talk channel instances keyed by alias.
    #[cfg(feature = "channel-nextcloud")]
    let nextcloud_talk_channel: HashMap<String, Arc<NextcloudTalkChannel>> = config
        .channels
        .nextcloud_talk
        .iter()
        .map(|(alias, nc)| {
            let peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync> = {
                let cfg_arc = config_state.clone();
                let alias = alias.clone();
                Arc::new(move || {
                    cfg_arc
                        .read()
                        .channel_external_peers("nextcloud_talk", &alias)
                })
            };
            (
                alias.clone(),
                Arc::new(NextcloudTalkChannel::new(
                    nc.base_url.clone(),
                    // Resolve the same installed-bot secret used by inbound
                    // verification. `webhook_secret` is canonical and
                    // `bot_token` is a deprecated alias for the same value.
                    nc.resolve_bot_secret().unwrap_or_else(|e| {
                        ::zeroclaw_log::record!(
                            WARN,
                            ::zeroclaw_log::Event::new(
                                module_path!(),
                                ::zeroclaw_log::Action::Note
                            )
                            .with_outcome(::zeroclaw_log::EventOutcome::Failure),
                            &e.to_string()
                        );
                        None
                    }),
                    nc.bot_name.clone().unwrap_or_default(),
                    alias.clone(),
                    peer_resolver,
                )),
            )
        })
        .collect();

    // Nextcloud Talk webhook secrets keyed by alias for signature verification.
    #[cfg(feature = "channel-nextcloud")]
    let nextcloud_talk_webhook_secret: HashMap<String, Arc<str>> = config
        .channels
        .nextcloud_talk
        .iter()
        .filter_map(|(alias, nc)| {
            // Same resolver as the outbound signing path: Nextcloud installs one
            // secret per bot, so inbound verification and outbound signing must
            // agree. A conflict or an unresolved secret yields no entry, and the
            // handler rejects rather than skipping verification.
            let secret = match nc.resolve_bot_secret() {
                Ok(Some(secret)) => secret,
                Ok(None) => return None,
                Err(e) => {
                    ::zeroclaw_log::record!(
                        WARN,
                        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                            .with_outcome(::zeroclaw_log::EventOutcome::Failure),
                        &e.to_string()
                    );
                    return None;
                }
            };
            Some((alias.clone(), Arc::from(secret)))
        })
        .collect();

    // Gmail Push channel (if configured and referenced by an enabled agent)
    #[cfg(feature = "channel-email")]
    let gmail_push_channel: Option<Arc<GmailPushChannel>> = {
        let active: std::collections::HashSet<String> = config
            .agents
            .values()
            .filter(|a| a.enabled)
            .flat_map(|a| a.channels.iter().map(|c| c.as_str().to_string()))
            .collect();
        config
            .channels
            .gmail_push
            .iter()
            .find(|(alias, _)| active.contains(&format!("gmail_push.{alias}")))
            .map(|(alias, gp)| {
                let alias = alias.clone();
                let peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync> = {
                    let cfg_arc = config_state.clone();
                    let alias = alias.clone();
                    Arc::new(move || cfg_arc.read().channel_external_peers("gmail_push", &alias))
                };
                Arc::new(GmailPushChannel::new(gp.clone(), alias, peer_resolver))
            })
    };

    let session_backend: Option<Arc<dyn SessionBackend>> = if config.gateway.session_persistence {
        match zeroclaw_infra::make_session_backend(
            &config.data_dir,
            &config.channels.session_backend,
        ) {
            Ok(backend) => {
                ::zeroclaw_log::record!(
                    INFO,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
                    &format!(
                        "Gateway session persistence enabled (backend={})",
                        config.channels.session_backend
                    )
                );
                if config.gateway.session_ttl_hours > 0
                    && let Ok(cleaned) = backend.cleanup_stale(config.gateway.session_ttl_hours)
                    && cleaned > 0
                {
                    ::zeroclaw_log::record!(
                        INFO,
                        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                            .with_attrs(::serde_json::json!({"cleaned": cleaned})),
                        "Cleaned up stale gateway sessions"
                    );
                }
                Some(backend)
            }
            Err(e) => {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                        .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                        .with_attrs(::serde_json::json!({"error": format!("{}", e)})),
                    "Session persistence disabled"
                );
                None
            }
        }
    } else {
        None
    };

    // ── Pairing guard ──────────────────────────────────────
    // Supervised runs share the daemon's live authority so pairing and
    // revocation reach RPC authentication too; standalone constructs its
    // own from config exactly as before. Either way the pairing-code policy
    // is resolved from config in exactly one guard: startup pairing,
    // `gateway get-paircode --new`, the dashboard pairing flow, and
    // rotate-device all issue through it. Its code lifetime and brute-force
    // limits are read from `[gateway.pairing_dashboard]` in live config on
    // every use, in the daemon's guard as in this one.
    let pairing = Arc::new(shared_pairing.unwrap_or_else(|| {
        PairingGuard::new(
            config.gateway.require_pairing,
            &config.gateway.paired_tokens,
            config.gateway.pairing_code,
        )
        .with_live_limits(PairingLimits::live(config_state.clone()))
    }));
    let rate_limit_max_keys = normalize_max_keys(
        config.gateway.rate_limit_max_keys,
        RATE_LIMIT_MAX_KEYS_DEFAULT,
    );
    let rate_limiter = Arc::new(GatewayRateLimiter::new(
        config.gateway.pair_rate_limit_per_minute,
        config.gateway.webhook_rate_limit_per_minute,
        rate_limit_max_keys,
    ));
    let idempotency_max_keys = normalize_max_keys(
        config.gateway.idempotency_max_keys,
        IDEMPOTENCY_MAX_KEYS_DEFAULT,
    );
    let idempotency_store = Arc::new(IdempotencyStore::new(
        Duration::from_secs(config.gateway.idempotency_ttl_secs.max(1)),
        idempotency_max_keys,
    ));

    // Resolve optional path prefix for reverse-proxy deployments.
    let path_prefix: Option<&str> = config
        .gateway
        .path_prefix
        .as_deref()
        .filter(|p| !p.is_empty());

    // ── Tunnel ────────────────────────────────────────────────
    let tunnel = match zeroclaw_runtime::tunnel::create_tunnel(&config.tunnel) {
        Ok(t) => t,
        Err(e) => {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({
                        "tunnel_provider": config.tunnel.tunnel_provider,
                        "error": format!("{e}"),
                    })),
                "Gateway: tunnel adapter failed to construct; booting without a \
                 tunnel. Fix [tunnel] and POST /admin/reload."
            );
            None
        }
    };
    let mut tunnel_url: Option<String> = None;

    if let Some(ref tun) = tunnel {
        println!("🔗 Starting {} tunnel...", tun.name());
        match tun.start(host, actual_port).await {
            Ok(url) => {
                println!("🌐 Tunnel active: {url}");
                tunnel_url = Some(url);
                // The WSS RPC plane and enrollment endpoint terminate their
                // own TLS; publish them as raw TCP passthrough where the
                // provider supports it. Resolved from this run's config, the
                // same source the daemon starts those listeners from.
                let services = zeroclaw_runtime::tunnel::daemon_tcp_services(&config);
                match tun.publish_tcp_services(&services).await {
                    Ok(published) => {
                        for p in &published {
                            println!(
                                "{}",
                                i18n::get_required_cli_string_with_args(
                                    "cli-tunnel-tcp-service-published",
                                    &[("service", p.service.name), ("endpoint", &p.endpoint)],
                                )
                            );
                        }
                    }
                    Err(e) => {
                        ::zeroclaw_log::record!(
                            WARN,
                            ::zeroclaw_log::Event::new(
                                module_path!(),
                                ::zeroclaw_log::Action::Fail
                            )
                            .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                            .with_attrs(::serde_json::json!({
                                "tunnel_provider": tun.name(),
                                "error": format!("{e}"),
                            })),
                            "Gateway: tunnel could not publish WSS/enrollment listeners; \
                             they remain reachable only at their configured bind"
                        );
                    }
                }
            }
            Err(e) => {
                println!("⚠️  Tunnel failed to start: {e}");
                println!("   Falling back to local-only mode.");
            }
        }
    }

    let web_dist_dir = resolve_web_dist_dir(&config);
    if let Some(stale) = config
        .gateway
        .web_dist_dir
        .as_ref()
        .map(std::path::PathBuf::from)
        && !has_servable_dashboard_index(&stale)
    {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                .with_attrs(::serde_json::json!({"configured": stale.display().to_string()})),
            "gateway.web_dist_dir points at a path without a usable index.html on \
             this machine; falling back to auto-detect. Update or remove the setting in \
             config.toml to silence this warning."
        );
    }

    // Embedded assets take serving priority when compiled in. Otherwise, use
    // the single resolved `web_dist_dir` snapshot stored in AppState.
    let availability: Option<WebDashboardAvailability> = {
        #[cfg(feature = "embedded-web")]
        {
            Some(WebDashboardAvailability::Embedded)
        }
        #[cfg(not(feature = "embedded-web"))]
        {
            web_dist_dir
                .clone()
                .map(WebDashboardAvailability::Filesystem)
        }
    };

    match availability {
        Some(WebDashboardAvailability::Embedded) => {
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
                "Web dashboard: serving embedded assets"
            );
        }
        Some(WebDashboardAvailability::Filesystem(ref dir)) => {
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_attrs(::serde_json::json!({"path": dir.display().to_string()})),
                "Web dashboard: serving filesystem assets"
            );
        }
        None if config.gateway.web_dist_dir.is_some() => {
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
                "Web dashboard: not available — configured gateway.web_dist_dir is missing on \
                 this machine and no fallback location was found. Reinstall with the supported \
                 installer (`./install.sh --source` on Linux/macOS, `setup.bat` on Windows) to \
                 build and place the dashboard where the gateway looks for it."
            );
        }
        None => {
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
                "Web dashboard: not available — no web/dist found. Reinstall with the supported \
                 installer (`./install.sh --source` on Linux/macOS, `setup.bat` on Windows) to \
                 build and place the dashboard where the gateway looks for it."
            );
        }
    }

    let pfx = path_prefix.unwrap_or("");
    println!("🦀 ZeroClaw Gateway listening on http://{display_addr}{pfx}");
    if let Some(ref url) = tunnel_url {
        println!("  🌐 Public URL: {url}");
    }
    if availability.is_some() {
        println!("  🌐 Web Dashboard: http://{display_addr}{pfx}/");
    } else {
        println!(
            "  ⚠️  Web Dashboard: not available — reinstall with the supported installer \
             (`./install.sh --source` on Linux/macOS, `setup.bat` on Windows) to build it"
        );
    }
    // Start this run's admin-token generation. The pairing-code admin routes
    // accept only the token the guard holds in memory. If the file cannot be
    // written the guard holds none, so they refuse everyone (fail closed) and
    // no file left by an earlier run is honoured; the banner below stays the
    // way to read the first-run code.
    let admin_token_path = gateway_admin_token_path(&config.data_dir);
    if let Err(e) = pairing.rotate_admin_token(&config.data_dir) {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                .with_attrs(::serde_json::json!({
                    "path": admin_token_path.display().to_string(),
                    "error": e.to_string(),
                })),
            "gateway admin token could not be written; pairing-code admin routes will refuse all callers"
        );
    }
    if let Some(code) = pairing.pairing_code() {
        // The box is sized from the code, not from a literal: since the policy became config-driven,
        // the code length is operator-configurable (6..=128 chars).
        let rule = "─".repeat(code.chars().count() + 4);
        println!();
        println!("  🔐 PAIRING REQUIRED — use this one-time code:");
        println!("     ┌{rule}┐");
        println!("     │  {code}  │");
        println!("     └{rule}┘");
        println!("     Send: POST {pfx}/pair with header X-Pairing-Code: {code}");
    } else if pairing.require_pairing() {
        for line in already_paired_pairing_notice(host, actual_port, pfx, &admin_token_path) {
            println!("{line}");
        }
        println!();
    } else {
        println!("  ⚠️  Pairing: DISABLED (all requests accepted)");
        println!();
    }
    println!("  POST {pfx}/pair      — pair a new client (X-Pairing-Code header)");
    println!("  POST {pfx}/webhook   — {{\"message\": \"your prompt\"}}");
    #[cfg(feature = "channel-whatsapp-cloud")]
    if !whatsapp_channel.is_empty() {
        println!("  GET  {pfx}/whatsapp[/<alias>]  — Meta webhook verification");
        println!("  POST {pfx}/whatsapp[/<alias>]  — WhatsApp message webhook");
    }
    #[cfg(feature = "channel-linq")]
    if !linq_channels.is_empty() {
        println!("  POST {pfx}/linq[/<alias>]      — Linq message webhook (iMessage/RCS/SMS)");
    }
    #[cfg(feature = "channel-nextcloud")]
    if !nextcloud_talk_channel.is_empty() {
        println!("  POST {pfx}/nextcloud-talk[/<alias>] — Nextcloud Talk bot webhook");
    }
    println!("  GET  {pfx}/api/*     — REST API (bearer token required)");
    println!("  GET  {pfx}/ws/chat   — WebSocket agent chat");
    if config.nodes.enabled {
        println!("  GET  {pfx}/ws/nodes  — WebSocket node discovery");
    }
    println!("  GET  {pfx}/health    — health check");
    println!("  GET  {pfx}/metrics   — Prometheus metrics");
    println!("  Press Ctrl+C to stop.\n");

    zeroclaw_runtime::health::mark_component_ok("gateway");

    zeroclaw_log::set_broadcast_hook(event_tx.clone());

    // Bound into AppState. Not a broadcaster — the broadcaster is the event
    // bus's hook (`EventBus::shared_or_installed` above). This is the
    // configured backend (Log/Prometheus/...) wrapped by `TeeObserver`,
    // which tees events into the hook on every record.
    let state_observer: Arc<dyn zeroclaw_runtime::observability::Observer> = Arc::from(
        zeroclaw_runtime::observability::create_observer(&config.observability),
    );

    let (owned_shutdown_tx, _) = tokio::sync::watch::channel(false);
    let (shutdown_tx, reload_tx) = reload_controls
        .map(|controls| (controls.shutdown_tx.clone(), Some(controls)))
        .unwrap_or((owned_shutdown_tx, None));
    let mut shutdown_rx = shutdown_tx.subscribe();

    // Node registry for dynamic node discovery
    let node_registry = Arc::new(nodes::NodeRegistry::new(config.nodes.max_nodes));
    let mdns_config_state = config_state.clone();
    let mdns_peer_registry =
        nodes::mdns::MdnsPeerRegistry::new(move || mdns_config_state.read().nodes.mdns.max_peers);
    let mdns_task = if config.nodes.mdns.enabled
        && nodes::mdns::is_advertisable_gateway_addr(&actual_addr)
    {
        let mdns_config = config.nodes.mdns.clone();
        let advertised_gateway = nodes::mdns::MdnsAdvertisedGateway::new(actual_port, path_prefix);
        let mdns_registry = mdns_peer_registry.clone();
        let mdns_shutdown_rx = shutdown_tx.subscribe();
        Some(zeroclaw_spawn::spawn!(async move {
            if let Err(err) = nodes::mdns::run_peer_discovery(
                mdns_config,
                advertised_gateway,
                mdns_registry,
                mdns_shutdown_rx,
            )
            .await
            {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                        .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                        .with_attrs(::serde_json::json!({"error": format!("{err}")})),
                    "mDNS local peer discovery stopped"
                );
            }
        }))
    } else if config.nodes.mdns.enabled {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Reject)
                .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                .with_attrs(::serde_json::json!({"bind_addr": actual_addr.to_string()})),
            "mDNS local peer discovery skipped because the gateway is bound to a loopback-only host"
        );
        None
    } else {
        None
    };

    // Device registry and pairing store (only when pairing is required)
    let device_registry = if config.gateway.require_pairing {
        let registry = Arc::new(
            api_pairing::DeviceRegistry::new(&config.data_dir)
                .context("Initialize paired-device registry")?,
        );
        // Reconcile the registry against the canonical paired-token set so that
        // tokens paired via the legacy `/pair` route (and any other historical
        // orphans) become visible and revocable in the management UI. The token
        // set itself stays owned by `PairingGuard`/`gateway.paired_tokens`.
        match registry.reconcile_from_token_hashes(&pairing.tokens()) {
            Ok(0) => {}
            Ok(n) => ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_attrs(::serde_json::json!({ "backfilled": n })),
                "backfilled legacy paired token(s) into the device registry"
            ),
            Err(e) => ::zeroclaw_log::record!(
                ERROR,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                    .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                    .with_attrs(::serde_json::json!({ "error": format!("{e}") })),
                "device registry backfill from paired_tokens failed"
            ),
        }
        Some(registry)
    } else {
        None
    };

    // The gateway's inbound-auth authority. Supervised runs share the
    // daemon's accepted policy with the RPC context, so a revocation
    // persisted through either surface binds this one without a reload.
    // Standalone runs build their own from config and the local pairing
    // guard. Either way the policy moves only when a config mutation
    // persists (see `persist_and_swap`).
    let inbound_auth = Arc::new(match shared_inbound_auth {
        Some(shared) => principal_gate::GatewayInboundAuth::from_shared(shared),
        None => principal_gate::GatewayInboundAuth::from_config(&config, Arc::clone(&pairing))?,
    });

    let state = AppState {
        config: config_state,
        config_authority: authority.clone(),
        agent_lifecycle: authority.agent_lifecycle(),
        model_provider,
        model,
        temperature,
        mem,
        memory_strategy,
        auto_save: config.memory.auto_save,
        pairing,
        trust_forwarded_headers: config.gateway.trust_forwarded_headers,
        rate_limiter,
        auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
        idempotency_store,
        #[cfg(feature = "channel-whatsapp-cloud")]
        whatsapp: whatsapp_channel,
        #[cfg(feature = "channel-whatsapp-cloud")]
        whatsapp_app_secret,
        #[cfg(feature = "channel-linq")]
        linq: linq_channels,
        #[cfg(feature = "channel-linq")]
        linq_signing_secrets,
        #[cfg(feature = "channel-nextcloud")]
        nextcloud_talk: nextcloud_talk_channel,
        #[cfg(feature = "channel-nextcloud")]
        nextcloud_talk_webhook_secret,
        #[cfg(feature = "channel-email")]
        gmail_push: gmail_push_channel,
        observer: state_observer,
        tools_registry,
        tools_registry_by_agent,
        cost_tracker,
        event_tx,
        event_buffer,
        shutdown_tx,
        reload_tx,
        node_registry,
        mdns_peer_registry,
        session_backend,
        session_queue: Arc::new(session_queue::SessionActorQueue::new(8, 30, 600)),
        device_registry,
        path_prefix: path_prefix.unwrap_or("").to_string(),
        web_dist_dir,
        canvas_store,
        cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
        pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
        tui_registry,
        sop_engine,
        sop_audit,
        sop_driver_handles,
        #[cfg(feature = "webauthn")]
        webauthn: if config.security.webauthn.enabled {
            let secret_store = Arc::new(zeroclaw_runtime::security::SecretStore::new(
                &config.data_dir,
                true,
            ));
            let wa_config = zeroclaw_runtime::security::webauthn::WebAuthnConfig {
                enabled: true,
                rp_id: config.security.webauthn.rp_id.clone(),
                rp_origin: config.security.webauthn.rp_origin.clone(),
                rp_name: config.security.webauthn.rp_name.clone(),
            };
            Some(Arc::new(api_webauthn::WebAuthnState {
                manager: zeroclaw_runtime::security::webauthn::WebAuthnManager::new(
                    wa_config,
                    secret_store,
                    &config.data_dir,
                ),
                pending_registrations: parking_lot::Mutex::new(std::collections::HashMap::new()),
                pending_authentications: parking_lot::Mutex::new(std::collections::HashMap::new()),
            }))
        } else {
            None
        },
    };

    let dashboard_layer_state = state.clone();
    // On every route that issues or redeems a pairing code: refused through a
    // relay-served dashboard, where the relay would see the code.
    let no_relayed_pairing = axum::middleware::from_fn(relay_ingress::no_pairing_through_a_relay);

    // Build router with middleware
    let inner = Router::new()
        .merge(config_admin_router(principal_gate::ConfigRouteAuth::new(
            &inbound_auth,
            &state.config,
        )))
        .merge(api_oidc::routes())
        .merge(api_oidc_enroll::routes(Arc::clone(&inbound_auth), shared_cert_audit))
        // ── Admin routes (for CLI management) ──
        .route("/admin/shutdown", post(handle_admin_shutdown))
        .route("/admin/reload", post(handle_admin_reload))
        .route("/admin/sop/pending", get(api_sop::handle_sop_pending))
        .route("/admin/sop/logs", get(api_sop::handle_sop_logs))
        .route("/admin/sop/approve", post(api_sop::handle_sop_approve))
        .route("/admin/sop/deny", post(api_sop::handle_sop_deny))
        .route("/admin/paircode", get(handle_admin_paircode))
        .route("/admin/paircode/new", post(handle_admin_paircode_new))
        // ── Existing routes ──
        .route("/health", get(handle_health))
        .route("/metrics", get(handle_metrics))
        .route(
            "/pair",
            post(handle_pair).layer(no_relayed_pairing.clone()),
        )
        .route("/pair/code", get(handle_pair_code))
        .merge(sop_webhook_routes())
        .merge(optional_channel_routes())
        .merge(optional_tool_routes())
        // ── Web Dashboard API routes ──
        .route("/api/status", get(dashboard_core::status))
        .route("/api/version/check", get(version::handle_version_check))
        .route("/api/version/upgrade", post(version::handle_version_upgrade))
        .route(
            "/api/version/upgrade/status",
            get(version::handle_version_upgrade_status),
        )
        .route("/api/logs", get(api_logs::handle_api_logs))
        .route(
            "/api/sops",
            get(api_sop_author::handle_sops_list).post(api_sop_author::handle_sop_create),
        )
        .route(
            "/api/sops/{name}",
            put(api_sop_author::handle_sop_save).delete(api_sop_author::handle_sop_delete),
        )
        .route(
            "/api/sops/{name}/graph",
            get(api_sop_author::handle_sop_graph),
        )
        .route(
            "/api/sops/{name}/run",
            post(api_sop_author::handle_sop_run),
        )
        .route(
            "/api/sops/{name}/rename",
            post(api_sop_author::handle_sop_rename),
        )
        .route("/api/sops/runs", get(api_sop_author::handle_sop_runs))
        .route(
            "/api/sops/{name}/full",
            get(api_sop_author::handle_sop_full),
        )
        .route(
            "/api/sops/wire-draft",
            post(api_sop_author::handle_sop_wire_draft),
        )
        .route(
            "/api/sops/graph-draft",
            post(api_sop_author::handle_sop_graph_draft),
        )
        .route(
            "/api/sops/trigger-sources",
            get(api_sop_author::handle_sop_trigger_sources),
        )
        .route(
            "/api/sops/decision-models",
            get(api_sop_author::handle_sop_decision_models),
        )
        .route(
            "/api/sops/graph-legend",
            get(api_sop_author::handle_sop_graph_legend),
        )
        .route(
            "/api/tools/param-options",
            post(api_sop_author::handle_tools_param_options),
        )
        .route(
            "/api/sops/{name}/runs/{run_id}/overlay",
            get(api_sop_author::handle_sop_run_overlay),
        )
        .route(
            "/api/sops/{name}/runs/{run_id}/decide",
            post(api_sop_author::handle_sop_decide),
        )
        .route(
            "/api/sops/{name}/runs/{run_id}/cancel",
            post(api_sop_author::handle_sop_cancel),
        )
        .route("/api/personality", get(api_personality::handle_index))
        .route(
            "/api/personality/templates",
            get(api_personality::handle_templates),
        )
        .route(
            "/api/personality/{filename}",
            get(api_personality::handle_get).put(api_personality::handle_put),
        )
        .route("/api/browse", get(api_browse::handle_browse))
        .route("/api/browse/mkdir", post(api_browse::handle_browse_mkdir))
        .route("/api/browse/rmdir", delete(api_browse::handle_browse_rmdir))
        .route(
            "/api/agents/{alias}/workspace/list",
            get(api_browse::handle_agent_workspace_list),
        )
        .route(
            "/api/agents/{alias}/workspace/read",
            get(api_browse::handle_agent_workspace_read),
        )
        .route(
            "/api/agents/{alias}/workspace/path",
            delete(api_browse::handle_agent_workspace_delete),
        )
        .route(
            "/api/agents/{alias}/workspace/move",
            post(api_browse::handle_agent_workspace_move),
        )
        .route(
            "/api/agents/{alias}/workspace/mkdir",
            post(api_browse::handle_agent_workspace_mkdir),
        )
        .route(
            "/api/agents/{alias}/skills",
            get(api_skills::handle_agent_skills),
        )
        .route("/api/skills/bundles", get(api_skills::handle_list_bundles))
        .route(
            "/api/skills/slash-option-kinds",
            get(api_skills::handle_slash_option_kinds),
        )
        .route(
            "/api/skills/bundles/{alias}/skills",
            get(api_skills::handle_list_skills).post(api_skills::handle_create_skill),
        )
        .route(
            "/api/skills/bundles/{alias}/skills/{name}",
            get(api_skills::handle_read_skill)
                .put(api_skills::handle_write_skill)
                .delete(api_skills::handle_delete_skill),
        )
        .route("/api/openapi.json", get(openapi::handle_openapi_json))
        .route("/api/docs", get(openapi::handle_docs))
        .route("/api/tools", get(api::handle_api_tools))
        .route("/api/cron", get(api::handle_api_cron_list))
        .route("/api/cron", post(api::handle_api_cron_add))
        .route(
            "/api/cron/settings",
            get(api::handle_api_cron_settings_get).patch(api::handle_api_cron_settings_patch),
        )
        .route(
            "/api/cron/{id}",
            delete(api::handle_api_cron_delete).patch(api::handle_api_cron_patch),
        )
        .route("/api/cron/{id}/runs", get(api::handle_api_cron_runs))
        // Note: `/api/cron/{id}/run` is registered on a separate router below
        // with a longer TimeoutLayer — manual cron triggers run the job
        // synchronously and routinely exceed the 30s gateway-wide default.
        .route("/api/integrations", get(api::handle_api_integrations))
        .route(
            "/api/integrations/settings",
            get(api::handle_api_integrations_settings),
        )
        .route(
            "/api/doctor",
            get(api::handle_api_doctor).post(api::handle_api_doctor),
        )
        .route("/api/memory", get(api::handle_api_memory_list))
        .route("/api/memory", post(api::handle_api_memory_store))
        .route("/api/memory/{key}", delete(api::handle_api_memory_delete))
        .route("/api/cost", get(api::handle_api_cost))
        .route("/api/cli-tools", get(api::handle_api_cli_tools))
        .route("/api/channels", get(api::handle_api_channels))
        .route(
            "/api/channels/{channel}/relink",
            post(api::handle_api_channel_relink),
        )
        .route("/api/health", get(api::handle_api_health))
        .route("/api/tuis", get(api::handle_api_tuis))
        .route("/api/sessions", get(dashboard_core::sessions_list))
        .route("/api/sessions/running", get(api::handle_api_sessions_running))
        .route(
            "/api/sessions/{id}/messages",
            get(dashboard_core::session_messages).post(api::handle_api_session_message_post),
        )
        .route("/api/sessions/{id}", delete(dashboard_core::session_delete).put(dashboard_core::session_rename))
        .route("/api/sessions/{id}/state", get(api::handle_api_session_state))
        .route("/api/sessions/{id}/abort", post(dashboard_core::session_abort))
        .route("/api/agents/available", get(dashboard_core::agents_available))
        // ── Pairing + Device management API ──
        .route(
            "/api/pairing/initiate",
            post(api_pairing::initiate_pairing).layer(no_relayed_pairing.clone()),
        )
        .route(
            "/api/pair",
            post(api_pairing::submit_pairing_enhanced).layer(no_relayed_pairing.clone()),
        )
        .route("/api/devices", get(api_pairing::list_devices))
        .route("/api/devices/{id}/voice", get(api_pairing::get_device_voice_preferences).put(api_pairing::put_device_voice_preferences))
        .route("/api/devices/me/voice", get(api_pairing::get_my_voice_preferences).put(api_pairing::put_my_voice_preferences))
        .route(
            "/api/devices/me/capabilities",
            post(api_pairing::update_my_capabilities),
        )
        .route("/api/devices/{id}", delete(api_pairing::revoke_device))
        .route(
            "/api/devices/{id}/token/rotate",
            post(api_pairing::rotate_token).layer(no_relayed_pairing),
        )
        // ── Live Canvas (A2UI) routes ──
        .route("/api/canvas", get(canvas::handle_canvas_list))
        .route(
            "/api/canvas/{id}",
            get(canvas::handle_canvas_get)
                .post(canvas::handle_canvas_post)
                .delete(canvas::handle_canvas_clear),
        )
        .route(
            "/api/canvas/{id}/history",
            get(canvas::handle_canvas_history),
        );

    #[cfg(feature = "plugins-wasm")]
    let inner = inner.merge(plugin_webhook::routes(plugin_webhooks));
    #[cfg(not(feature = "plugins-wasm"))]
    let _ = plugin_webhooks;

    #[cfg(feature = "a2a")]
    let inner = inner.merge(a2a::a2a_routes_with_endpoint(Some(
        a2a::AdvertisedGatewayEndpoint::new(host, actual_port),
    )));

    // ── WebAuthn hardware key authentication API (requires webauthn feature) ──
    #[cfg(feature = "webauthn")]
    let inner = inner
        .route(
            "/api/webauthn/register/start",
            post(api_webauthn::handle_register_start),
        )
        .route(
            "/api/webauthn/register/finish",
            post(api_webauthn::handle_register_finish),
        )
        .route(
            "/api/webauthn/auth/start",
            post(api_webauthn::handle_auth_start),
        )
        .route(
            "/api/webauthn/auth/finish",
            post(api_webauthn::handle_auth_finish),
        )
        .route(
            "/api/webauthn/credentials",
            get(api_webauthn::handle_list_credentials),
        )
        .route(
            "/api/webauthn/credentials/{id}",
            delete(api_webauthn::handle_delete_credential),
        );

    // The read-only package catalog remains discoverable in every gateway
    // build; WASM-specific sources degrade explicitly when support is absent.
    let inner = inner.route("/api/plugins", get(api_plugins::list_plugins));

    let inner = inner
        // ── SSE event stream ──
        .route("/api/events", get(sse::handle_sse_events))
        .route("/api/events/history", get(sse::handle_events_history))
        // ── ACP client bridge ──
        .route("/acp", get(acp::handle_ws_acp))
        // ── WebSocket agent chat ──
        .route("/ws/chat", get(ws::handle_ws_chat))
        // ── WebSocket SOP runs feed ──
        .route("/ws/sops/runs", get(ws_sop_runs::handle_ws_sop_runs))
        // ── WebSocket canvas updates ──
        .route("/ws/canvas/{id}", get(canvas::handle_ws_canvas))
        // ── WebSocket node discovery ──
        .route("/ws/nodes", get(nodes::handle_ws_nodes))
        // ── Static assets (web dashboard) ──
        .merge(static_file_routes())
        // ── SPA fallback: non-API GET requests serve index.html ──
        .fallback(get(static_files::handle_spa_fallback))
        .with_state(state.clone())
        .layer(RequestBodyLimitLayer::new(MAX_BODY_SIZE))
        .layer(TimeoutLayer::with_status_code(
            StatusCode::REQUEST_TIMEOUT,
            Duration::from_secs(gateway_request_timeout_secs(&config.gateway)),
        ));

    // The dashboard image upload lives on its own sub-router so it can opt out
    // of the 64 KB gateway-wide RequestBodyLimitLayer, which is sized for JSON
    // control-plane bodies and would otherwise reject any real image before the
    // route's own ceiling runs. The route keeps the extractor-level
    // DefaultBodyLimit at the same ceiling; the per-request size check against
    // live `multimodal.max_image_size_mb` happens inside the handler.
    let upload_router: Router = Router::new()
        .route(
            "/api/upload",
            post(api_upload::handle_upload).layer(axum::extract::DefaultBodyLimit::max(
                api_upload::UPLOAD_BODY_CEILING_BYTES,
            )),
        )
        .with_state(state.clone())
        .layer(RequestBodyLimitLayer::new(
            api_upload::UPLOAD_BODY_CEILING_BYTES,
        ))
        .layer(TimeoutLayer::with_status_code(
            StatusCode::REQUEST_TIMEOUT,
            Duration::from_secs(gateway_request_timeout_secs(&config.gateway)),
        ));
    let inner = inner.merge(upload_router);

    // These routes can wait for a complete agent turn. Keep their timeout and
    // body limit on the sub-router so both survive `merge`. For `/webhook`,
    // this also bounds body extraction and SOP/SSE response creation; the SSE
    // body and its cancellation remain owned by the streaming path.
    let long_running_router: Router<AppState> = Router::new()
        .route("/webhook", post(handle_webhook))
        .route("/api/cron/{id}/run", post(api::handle_api_cron_run));
    #[cfg(feature = "a2a")]
    let long_running_router = long_running_router.merge(a2a::a2a_task_route());
    let long_running_router: Router = long_running_router
        .with_state(state)
        .layer(RequestBodyLimitLayer::new(MAX_BODY_SIZE))
        .layer(TimeoutLayer::with_status_code(
            StatusCode::REQUEST_TIMEOUT,
            Duration::from_secs(gateway_long_running_request_timeout_secs(&config.gateway)),
        ));

    let inner = inner
        .merge(long_running_router)
        .layer(axum::Extension(core_rpc));

    // Nest under path prefix when configured (axum strips prefix before routing).
    // nest() at "/prefix" handles both "/prefix" and "/prefix/*" but not "/prefix/"
    // with a trailing slash, so we add a fallback redirect for that case.
    let app = if let Some(prefix) = path_prefix {
        let redirect_target = prefix.to_string();
        Router::new().nest(prefix, inner).route(
            &format!("{prefix}/"),
            get(|| async move { axum::response::Redirect::permanent(&redirect_target) }),
        )
    } else {
        inner
    };

    // Dashboard sign-in sessions: classified once per request for every
    // route, upgrades and the fallback included. A no-op unless
    // `[gateway.dashboard_sign_in]` offers a provider.
    // Bound to this generation before it serves anything, so its stop
    // retires the sessions' sockets and refuses their later requests.
    let dashboard_auth = Arc::new(
        dashboard_session::DashboardAuth::new(
            dashboard_session::DashboardSessions::process_shared(),
            Arc::clone(&inbound_auth),
        )
        .for_generation(&dashboard_layer_state),
    );
    let app = app.layer(axum::middleware::from_fn_with_state(
        dashboard_session::DashboardLayer {
            state: dashboard_layer_state,
            auth: dashboard_auth,
        },
        dashboard_session::layer,
    ));

    let tls_enabled = config
        .gateway
        .tls
        .as_ref()
        .is_some_and(|tls_cfg| tls_cfg.enabled);
    let app = if tls_enabled {
        app.layer(axum::middleware::from_fn(security_headers::apply_with_hsts))
    } else {
        app.layer(axum::middleware::from_fn(security_headers::apply))
    };

    // ── TLS / mTLS setup ───────────────────────────────────────────
    let tls_acceptor = match &config.gateway.tls {
        Some(tls_cfg) if tls_cfg.enabled => {
            let has_mtls = tls_cfg.client_auth.as_ref().is_some_and(|ca| ca.enabled);
            if has_mtls {
                ::zeroclaw_log::record!(
                    INFO,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
                    "TLS enabled with mutual TLS (mTLS) client verification"
                );
            } else {
                ::zeroclaw_log::record!(
                    INFO,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
                    "TLS enabled (no client certificate requirement)"
                );
            }
            Some(tls::build_tls_acceptor(tls_cfg)?)
        }
        _ => None,
    };

    if let Some(readiness) = readiness {
        readiness.report_ready(actual_addr);
    }

    // One accept loop for plain and TLS connections. Every connection
    // watches this gateway's stop and serves through `admission`, so after
    // the stop no request reaches this gateway's router. Its tasks are in
    // `tasks`, so the stop also cancels whatever outlasts the drain.
    let mut app = app.into_make_service_with_connect_info::<SocketAddr>();
    // Attached once this generation is about to serve, and detached when
    // it returns, so the bridge never hands a connection to a gateway that
    // can't serve it.
    let mut dashboard_feed = DashboardFeed(
        dashboard_ingress
            .as_ref()
            .map(zeroclaw_runtime::relay_dashboard::DashboardIngress::attach),
    );
    let tasks = ServeTasks::default();
    let _cancel_on_drop = ServeTasksGuard::new(tasks.clone());
    let admission = Admission {
        stopping: shutdown_rx.clone(),
        tasks: tasks.clone(),
    };
    loop {
        tokio::select! {
            conn = listener.accept() => {
                let (tcp_stream, remote_addr) = match conn {
                    Ok(pair) => pair,
                    Err(e) => match accept_error_action(&e, tls_acceptor.is_some()) {
                        AcceptErrorAction::Retry => continue,
                        AcceptErrorAction::RetryAfter(delay) => {
                            // Transient (e.g. EMFILE under fd pressure):
                            // the listener is still valid. Back off
                            // briefly to avoid hot-spinning, then keep
                            // serving rather than killing the daemon
                            ::zeroclaw_log::record!(WARN, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_outcome(::zeroclaw_log::EventOutcome::Unknown).with_attrs(::serde_json::json!({"error": format!("{}", e)})), "gateway accept() failed with a transient error; backing off and continuing");
                            if accept_backoff(delay, &mut shutdown_rx).await {
                                ::zeroclaw_log::record!(INFO, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note), "ZeroClaw Gateway shutting down");
                                break;
                            }
                            continue;
                        }
                        AcceptErrorAction::Fail => return Err(e.into()),
                    },
                };
                let tls_acceptor = tls_acceptor.clone();
                let svc = tower::MakeService::<
                    SocketAddr,
                    hyper::Request<hyper::body::Incoming>,
                >::make_service(&mut app, remote_addr)
                .await
                .expect("infallible make_service");
                // A clone of this loop's receiver, which was subscribed when
                // the gateway started: it sees a stop that lands while the
                // connection is being handed over too.
                let mut stopping = shutdown_rx.clone();
                let executor = tasks.clone();
                let admission = admission.clone();

                tasks.spawn(async move {
                    let hyper_svc = hyper::service::service_fn(move |req: hyper::Request<hyper::body::Incoming>| {
                        let svc = svc.clone();
                        let admission = admission.clone();
                        async move { serve_while_current(svc, &admission, req).await }
                    });
                    let builder = hyper_util::server::conn::auto::Builder::new(executor);
                    // Serve until the connection ends or the gateway stops; then
                    // finish the request in flight and close (HTTP/1 closes
                    // once its response is done). The drain below bounds it.
                    macro_rules! serve_until_stopped {
                        ($connection:expr) => {{
                            let connection = $connection;
                            tokio::pin!(connection);
                            tokio::select! {
                                served = connection.as_mut() => served,
                                () = gateway_stop_requested(&mut stopping) => {
                                    connection.as_mut().graceful_shutdown();
                                    connection.as_mut().await
                                }
                            }
                        }};
                    }
                    let served = match tls_acceptor {
                        Some(tls_acceptor) => {
                            let accepted = tokio::select! {
                                accepted = tls_acceptor.accept(tcp_stream) => accepted,
                                () = gateway_stop_requested(&mut stopping) => return,
                            };
                            let tls_stream = match accepted {
                                Ok(s) => s,
                                Err(e) => {
                                    ::zeroclaw_log::record!(DEBUG, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_attrs(::serde_json::json!({"error": format!("{}", e), "remote_addr": remote_addr})), "TLS handshake failed from");
                                    return;
                                }
                            };
                            let io = hyper_util::rt::TokioIo::new(tls_stream);
                            // With upgrades, as over plain HTTP: WebSockets work over TLS too.
                            serve_until_stopped!(builder.serve_connection_with_upgrades(io, hyper_svc))
                        }
                        None => {
                            let io = hyper_util::rt::TokioIo::new(tcp_stream);
                            serve_until_stopped!(builder.serve_connection_with_upgrades(io, hyper_svc))
                        }
                    };
                    if let Err(e) = served {
                        ::zeroclaw_log::record!(DEBUG, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_attrs(::serde_json::json!({"error": format!("{}", e), "remote_addr": remote_addr})), "connection error from");
                    }
                });
            }
            conn = dashboard_feed.next() => {
                // A browser connection a relay-served dashboard forwarded.
                // Served like an accepted socket - same router, admission
                // and drain - with the browser's address as the peer (never
                // loopback) and each request admitted for that dashboard's
                // origin alone. No TLS here: the browser's ended at the
                // relay, and the bridge carries the stream inside the
                // daemon's own TLS link to it.
                let (stream, client_addr, origin) = conn.into_parts();
                let relay = relay_ingress::RelayConnection::new(origin);
                let svc = tower::MakeService::<
                    SocketAddr,
                    hyper::Request<hyper::body::Incoming>,
                >::make_service(&mut app, client_addr)
                .await
                .expect("infallible make_service");
                let mut stopping = shutdown_rx.clone();
                let admission = admission.clone();
                tasks.spawn(async move {
                    let hyper_svc = hyper::service::service_fn(move |mut req: hyper::Request<hyper::body::Incoming>| {
                        let svc = svc.clone();
                        let admission = admission.clone();
                        let admitted = relay.admit(&mut req);
                        async move {
                            match admitted {
                                Ok(()) => serve_while_current(svc, &admission, req).await,
                                Err(refusal) => Ok(*refusal),
                            }
                        }
                    });
                    // HTTP/1.1 only, which is all the relay offers browsers:
                    // one connection then carries requests for one host.
                    let connection = hyper::server::conn::http1::Builder::new()
                        .serve_connection(hyper_util::rt::TokioIo::new(stream), hyper_svc)
                        .with_upgrades();
                    tokio::pin!(connection);
                    let served = tokio::select! {
                        served = connection.as_mut() => served,
                        () = gateway_stop_requested(&mut stopping) => {
                            connection.as_mut().graceful_shutdown();
                            connection.as_mut().await
                        }
                    };
                    if let Err(e) = served {
                        ::zeroclaw_log::record!(DEBUG, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note).with_attrs(::serde_json::json!({"error": format!("{}", e), "remote_addr": client_addr})), "relay dashboard connection error from");
                    }
                });
            }
            _ = shutdown_rx.changed() => {
                ::zeroclaw_log::record!(INFO, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note), "ZeroClaw Gateway shutting down");
                break;
            }
        }
    }
    // Let go of the port at once, as `axum::serve` does: a connection made
    // from here on is refused, not accepted into a backlog nothing serves.
    release_listener(listener);
    // And stop taking relay-forwarded dashboard connections: the bridge
    // refuses them until the next generation attaches.
    drop(dashboard_feed);
    // Every connection finishes the request in flight and closes; whatever
    // is still open after the drain (an event stream, a connection that
    // ignored the shutdown) is cancelled. Nothing waits on it beyond that:
    // it admits no request, and the next gateway can serve.
    if !tasks.retire_within(CONNECTION_DRAIN).await {
        ::zeroclaw_log::record!(
            DEBUG,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
            "gateway connections still open after the drain; closing them"
        );
    }

    // Withdraw the tunnel before slower teardown below: the daemon allows a
    // short grace window before aborting the gateway. An early error return
    // above still drops the tunnel, which kills its processes without waiting.
    if let Some(tun) = tunnel {
        if let Err(e) = tun.stop().await {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                    .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                    .with_attrs(::serde_json::json!({
                        "tunnel_provider": tun.name(),
                        "error": format!("{e}"),
                    })),
                "Gateway: tunnel did not stop cleanly"
            );
        } else {
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_attrs(::serde_json::json!({"tunnel_provider": tun.name()})),
                "Gateway: tunnel stopped"
            );
        }
    }

    if let Some(task) = mdns_task {
        let mut task = task;
        tokio::select! {
            result = &mut task => {
                if let Err(err) = result {
                    ::zeroclaw_log::record!(
                        DEBUG,
                        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                            .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                            .with_attrs(::serde_json::json!({"error": format!("{err}")})),
                        "LAN peer discovery task join failed"
                    );
                }
            }
            _ = tokio::time::sleep(Duration::from_secs(2)) => {
                task.abort();
            }
        }
    }

    drop(broadcast_hook_guard);
    Ok(())
}

fn static_file_routes() -> Router<AppState> {
    Router::new()
        .route("/_app/", get(static_files::handle_static))
        .route("/_app/{*path}", get(static_files::handle_static))
}

fn format_paircode_recovery_command(_host: &str, port: u16) -> String {
    format!("zeroclaw gateway get-paircode --new --port {port}")
}

fn already_paired_pairing_notice(
    host: &str,
    port: u16,
    path_prefix: &str,
    admin_token_path: &std::path::Path,
) -> Vec<String> {
    vec![
        "  🔒 Pairing: ACTIVE — this gateway is already paired, so no new \
         one-time code was generated on this start."
            .to_string(),
        format!(
            "     To pair another device, run: {}",
            format_paircode_recovery_command(host, port)
        ),
        format!(
            "     Fallback (on this host, as this user): {}",
            format_paircode_recovery_curl(host, port, path_prefix, admin_token_path)
        ),
    ]
}

fn format_paircode_recovery_curl(
    host: &str,
    port: u16,
    path_prefix: &str,
    admin_token_path: &std::path::Path,
) -> String {
    // Admin paircode routes are localhost-only, so the curl fallback must point
    // at loopback. Bind-only hosts and non-loopback advertised hosts are
    // normalized to `127.0.0.1`; explicit loopback hosts are preserved. They
    // also require this run's admin secret, read from its owner-only file.
    let recovery_host = paircode_recovery_curl_host(host);
    format!(
        "curl -s -X POST -H \"{GATEWAY_ADMIN_TOKEN_HEADER}: $(cat '{}')\" \
         http://{recovery_host}:{port}{path_prefix}/admin/paircode/new",
        admin_token_path
            .display()
            .to_string()
            .replace('\'', "'\\''")
    )
}

fn paircode_recovery_curl_host(host: &str) -> &str {
    match host {
        "127.0.0.1" | "localhost" => host,
        "::1" => "[::1]",
        _ => "127.0.0.1",
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// AXUM HANDLERS
// ══════════════════════════════════════════════════════════════════════════════

fn public_health_snapshot() -> serde_json::Value {
    let snapshot = zeroclaw_runtime::health::snapshot();
    let components = snapshot
        .components
        .into_iter()
        .map(|(name, component)| {
            (
                name,
                serde_json::json!({
                    "status": component.status,
                    "updated_at": component.updated_at,
                    "last_ok": component.last_ok,
                    "restart_count": component.restart_count,
                }),
            )
        })
        .collect::<serde_json::Map<_, _>>();

    serde_json::json!({
        "pid": snapshot.pid,
        "updated_at": snapshot.updated_at,
        "uptime_seconds": snapshot.uptime_seconds,
        "components": components,
    })
}

/// GET /health — always public (no secrets leaked)
async fn handle_health(State(state): State<AppState>) -> impl IntoResponse {
    let body = serde_json::json!({
        "status": "ok",
        "paired": state.pairing.is_paired(),
        "require_pairing": state.pairing.require_pairing(),
        "runtime": public_health_snapshot(),
    });
    Json(body)
}

/// Prometheus content type for text exposition format.
const PROMETHEUS_CONTENT_TYPE: &str = "text/plain; version=0.0.4; charset=utf-8";

fn prometheus_disabled_hint() -> String {
    String::from(
        "# Prometheus backend not enabled. Set [observability] backend = \"prometheus\" in config.\n",
    )
}

#[cfg(feature = "observability-prometheus")]
fn prometheus_observer_from_state(
    observer: &dyn zeroclaw_runtime::observability::Observer,
) -> Option<&zeroclaw_runtime::observability::PrometheusObserver> {
    // `TeeObserver::as_any` returns the primary observer, so a single direct
    // downcast finds the PrometheusObserver whether the state observer is the
    // raw backend or wrapped by the factory tee.
    observer
        .as_any()
        .downcast_ref::<zeroclaw_runtime::observability::PrometheusObserver>()
}

/// GET /metrics — Prometheus text exposition format
async fn handle_metrics(State(state): State<AppState>) -> impl IntoResponse {
    let body = {
        #[cfg(feature = "observability-prometheus")]
        {
            if let Some(prom) = prometheus_observer_from_state(state.observer.as_ref()) {
                prom.encode()
            } else {
                prometheus_disabled_hint()
            }
        }
        #[cfg(not(feature = "observability-prometheus"))]
        {
            let _ = &state;
            prometheus_disabled_hint()
        }
    };

    (
        StatusCode::OK,
        [(header::CONTENT_TYPE, PROMETHEUS_CONTENT_TYPE)],
        body,
    )
}

/// POST /pair — exchange one-time code for bearer token
#[axum::debug_handler]
async fn handle_pair(
    State(state): State<AppState>,
    ConnectInfo(peer_addr): ConnectInfo<SocketAddr>,
    headers: HeaderMap,
) -> impl IntoResponse {
    let rate_key =
        client_key_from_request(Some(peer_addr), &headers, state.trust_forwarded_headers);
    if !state.rate_limiter.allow_pair(&rate_key) {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                .with_outcome(::zeroclaw_log::EventOutcome::Unknown),
            "/pair rate limit exceeded"
        );
        let err = serde_json::json!({
            "error": "Too many pairing requests. Please retry later.",
            "retry_after": RATE_LIMIT_WINDOW_SECS,
        });
        return (StatusCode::TOO_MANY_REQUESTS, Json(err));
    }

    // ── Auth rate limiting (brute-force protection) ──
    if let Err(e) = state.auth_limiter.check_rate_limit(&rate_key) {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                .with_attrs(::serde_json::json!({"rate_key": rate_key})),
            "pairing auth rate limit exceeded"
        );
        let err = serde_json::json!({
            "error": format!("Too many auth attempts. Try again in {}s.", e.retry_after_secs),
            "retry_after": e.retry_after_secs,
        });
        return (StatusCode::TOO_MANY_REQUESTS, Json(err));
    }

    let code = headers
        .get("X-Pairing-Code")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");

    match state.pairing.try_pair(code, &rate_key).await {
        Ok(Some(token)) => {
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
                "new client paired successfully"
            );
            let token_hash = PairingGuard::token_hash(&token);
            if let Some(ref registry) = state.device_registry {
                if let Err(e) = registry.register(
                    token_hash.clone(),
                    api_pairing::DeviceInfo {
                        id: uuid::Uuid::new_v4().to_string(),
                        name: None,
                        device_type: None,
                        paired_at: chrono::Utc::now(),
                        last_seen: chrono::Utc::now(),
                        ip_address: Some(rate_key.clone()),
                        capabilities: None,
                    },
                ) {
                    ::zeroclaw_log::record!(
                        ERROR,
                        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                            .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                            .with_attrs(::serde_json::json!({"error": format!("{e}")})),
                        "device registry insert failed after successful legacy /pair; rolling back in-process token"
                    );
                    state.pairing.revoke_token_hash(&token_hash);
                    let body = serde_json::json!({
                        "paired": false,
                        "persisted": false,
                        "error": format!("Device registry error: {e}"),
                        "message": "Pairing failed; the in-process token was not retained.",
                    });
                    return (StatusCode::INTERNAL_SERVER_ERROR, Json(body));
                }
            }
            if let Err(err) = Box::pin(persist_pairing_tokens(&state)).await {
                ::zeroclaw_log::record!(
                    ERROR,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                        .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                        .with_attrs(::serde_json::json!({"error": format!("{}", err)})),
                    "pairing token persistence failed; rolling back in-process token"
                );
                state.pairing.revoke_token_hash(&token_hash);
                let body = serde_json::json!({
                    "paired": false,
                    "persisted": false,
                    "error": format!("Token persistence error: {err}"),
                    "message": "Pairing failed; the in-process token was not retained.",
                });
                return (StatusCode::INTERNAL_SERVER_ERROR, Json(body));
            }

            let body = serde_json::json!({
                "paired": true,
                "persisted": true,
                "token": token,
                "message": "Save this token — use it as Authorization: Bearer <token>"
            });
            (StatusCode::OK, Json(body))
        }
        Ok(None) => {
            state.auth_limiter.record_attempt(&rate_key);
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown),
                "pairing attempt with invalid code"
            );
            let err = serde_json::json!({"error": "Invalid pairing code"});
            (StatusCode::FORBIDDEN, Json(err))
        }
        Err(lockout_secs) => {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({"lockout_secs": lockout_secs})),
                "pairing locked out; too many failed attempts"
            );
            let err = serde_json::json!({
                "error": format!("Too many failed attempts. Try again in {lockout_secs}s."),
                "retry_after": lockout_secs
            });
            (StatusCode::TOO_MANY_REQUESTS, Json(err))
        }
    }
}

pub(crate) async fn persist_pairing_tokens(state: &AppState) -> Result<()> {
    // Self-contained: no caller pre-reads config for modify, so this
    // admits its own commit rather than taking one as a param.
    let commit = state.begin_config_commit().await?;
    persist_pairing_tokens_under(state, commit).await.map(drop)
}

/// [`persist_pairing_tokens`] for a caller that already holds an admitted
/// commit: a revocation that removed a live token under it, through
/// [`PairingGuard::revoke_under_config_write_lock`], persists under the same
/// commit.
///
/// The commit (writer guard + config-work lease) is held across the whole
/// read-modify-save-publish below and runs the irreversible phase retained,
/// so a cancelled request cannot strand a committed token write without its
/// publication. It is handed back once the publication lands, so a caller
/// that must stay serialized past the persist (a rotation issuing its new
/// pairing code) keeps the writer gate until it is done.
pub(crate) async fn persist_pairing_tokens_under(
    state: &AppState,
    commit: ConfigWriteGuard,
) -> Result<ConfigWriteGuard> {
    let paired_tokens = state.pairing.tokens();
    let mut updated_cfg = commit.current_config();
    updated_cfg.gateway.paired_tokens = paired_tokens;
    updated_cfg.mark_dirty("gateway.paired_tokens");
    // Checked revision before the irreversible save.
    let revision = commit
        .next_revision()
        .context("Failed to allocate a config revision for paired tokens")?;
    let task =
        zeroclaw_runtime::live_config_authority::spawn_agent_lifecycle_job(Box::pin(async move {
            let mut config = updated_cfg;
            config
                .save_dirty()
                .await
                .context("Failed to persist paired tokens to config.toml")?;
            // Keep the published pair in sync with the persisted tokens.
            commit
                .publish(revision, config)
                .context("Failed to publish paired tokens to the live config")?;
            Ok::<ConfigWriteGuard, anyhow::Error>(commit)
        }));
    task.await.context("Paired-token persistence task failed")?
}

/// Result of a gateway chat turn.
struct GatewayChatOutcome {
    response: String,
}

struct UnconfiguredModelProvider;

#[async_trait::async_trait]
impl ModelProvider for UnconfiguredModelProvider {
    async fn chat_with_system(
        &self,
        _system_prompt: Option<&str>,
        _message: &str,
        _model: &str,
        _temperature: Option<f64>,
    ) -> anyhow::Result<String> {
        anyhow::bail!(
            "needs_quickstart: gateway booted without a working model_provider. \
             Complete browser quickstart at /quickstart, or fix \
             [providers.models.<type>.<alias>] and POST /admin/reload."
        )
    }
}

impl ::zeroclaw_api::attribution::Attributable for UnconfiguredModelProvider {
    fn role(&self) -> ::zeroclaw_api::attribution::Role {
        ::zeroclaw_api::attribution::Role::Provider(
            ::zeroclaw_api::attribution::ProviderKind::Model(
                ::zeroclaw_api::attribution::ModelProviderKind::Custom,
            ),
        )
    }
    fn alias(&self) -> &str {
        "unconfigured"
    }
}

fn needs_quickstart_for(model: &str) -> Option<anyhow::Error> {
    if model.trim().is_empty() {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Reject)
                .with_outcome(::zeroclaw_log::EventOutcome::Failure),
            "gateway dispatch refused: no model configured (browser quickstart incomplete)"
        );
        Some(anyhow::Error::msg(
            "needs_quickstart: gateway has no model configured. Complete \
             browser quickstart at /quickstart, or set [providers.models.<type>.<alias>] \
             model = \"...\" before sending messages.",
        ))
    } else {
        None
    }
}

/// True when `e` carries the marker produced by `needs_quickstart_for`.
/// Used by chat-dispatch error paths to map the marker to a 503
/// `needs_quickstart` HTTP response or a more accurate channel-side
/// reply, instead of the generic 500 / "sorry" catch-all.
fn is_needs_quickstart_err(e: &anyhow::Error) -> bool {
    e.to_string().contains("needs_quickstart")
}

fn needs_quickstart_channel_reply() -> String {
    i18n::get_required_cli_string("channel-needs-quickstart-reply")
}

#[cfg(test)]
#[derive(Clone, Debug, Eq, PartialEq)]
struct GatewayChatDispatchCapture {
    message: String,
    session_id: Option<String>,
    agent_override: Option<String>,
}

#[cfg(test)]
static GATEWAY_CHAT_DISPATCH_CAPTURES: std::sync::Mutex<Vec<GatewayChatDispatchCapture>> =
    std::sync::Mutex::new(Vec::new());

/// Events the test-only streamed dispatch delivered into the relay, per
/// session id, so a test can tell a relay that drained everything from one
/// that closed its receiver early.
#[cfg(test)]
static SSE_TEST_EVENTS_DELIVERED: std::sync::Mutex<Vec<(String, usize)>> =
    std::sync::Mutex::new(Vec::new());

#[cfg(test)]
fn sse_test_record_event_delivered(session_id: &str) {
    let mut delivered = SSE_TEST_EVENTS_DELIVERED
        .lock()
        .expect("sse delivery counter mutex poisoned");
    match delivered.iter_mut().find(|(key, _)| key == session_id) {
        Some((_, count)) => *count += 1,
        None => delivered.push((session_id.to_owned(), 1)),
    }
}

#[cfg(test)]
fn sse_test_events_delivered(session_id: &str) -> usize {
    SSE_TEST_EVENTS_DELIVERED
        .lock()
        .expect("sse delivery counter mutex poisoned")
        .iter()
        .find(|(key, _)| key == session_id)
        .map_or(0, |(_, count)| *count)
}

// Tests that read or clear the shared capture buffer hold this lock so
// parallel webhook tests cannot invalidate one another's evidence.
#[cfg(test)]
static GATEWAY_CHAT_DISPATCH_CAPTURE_TEST_LOCK: tokio::sync::Mutex<()> =
    tokio::sync::Mutex::const_new(());

#[cfg(test)]
async fn lock_gateway_chat_dispatch_capture_for_test() -> tokio::sync::MutexGuard<'static, ()> {
    GATEWAY_CHAT_DISPATCH_CAPTURE_TEST_LOCK.lock().await
}

#[cfg(all(
    test,
    any(feature = "channel-linq", feature = "channel-whatsapp-cloud")
))]
fn clear_gateway_chat_dispatch_captures_for_test() {
    GATEWAY_CHAT_DISPATCH_CAPTURES
        .lock()
        .expect("gateway chat dispatch capture mutex poisoned")
        .clear();
}

#[cfg(test)]
fn gateway_chat_dispatch_captures_for_test() -> Vec<GatewayChatDispatchCapture> {
    GATEWAY_CHAT_DISPATCH_CAPTURES
        .lock()
        .expect("gateway chat dispatch capture mutex poisoned")
        .clone()
}

#[cfg(test)]
fn record_gateway_chat_dispatch_for_test(
    message: &str,
    session_id: Option<&str>,
    agent_override: Option<&str>,
) {
    GATEWAY_CHAT_DISPATCH_CAPTURES
        .lock()
        .expect("gateway chat dispatch capture mutex poisoned")
        .push(GatewayChatDispatchCapture {
            message: message.to_string(),
            session_id: session_id.map(ToString::to_string),
            agent_override: agent_override.map(ToString::to_string),
        });
}

pub(crate) async fn run_gateway_chat_with_tools(
    state: &AppState,
    message: &str,
    session_id: Option<&str>,
    agent_override: Option<&str>,
) -> anyhow::Result<GatewayChatOutcome> {
    if let Some(err) = needs_quickstart_for(&state.model) {
        return Err(err);
    }

    // Tests exercise webhook infrastructure (idempotency, auth, autosave)
    // through handle_webhook, so dispatch to the mock model_provider directly
    // instead of bootstrapping the full agent runtime. The mock path
    // doesn't go through the cost-tracking scope.
    #[cfg(test)]
    {
        record_gateway_chat_dispatch_for_test(message, session_id, agent_override);
        let response = state
            .model_provider
            .chat_with_system(None, message, &state.model, state.temperature)
            .await?;
        Ok(GatewayChatOutcome { response })
    }

    #[cfg(not(test))]
    {
        let initial_config = state.config.read().clone();
        let requested_alias = require_gateway_chat_agent_alias(&initial_config, agent_override)?;
        let execution_capability =
            zeroclaw_runtime::live_config_authority::AgentExecutionCapability::from_parts(
                state.config.clone(),
                state.agent_lifecycle.clone(),
            );
        let execution_admission = execution_capability
            .resolve_and_admit(&requested_alias)
            .map_err(|error| anyhow::Error::msg(error.to_string()))?;
        let agent_alias = execution_admission.alias().to_string();
        let config = execution_admission.config().as_ref().clone();
        // The admission snapshot is authoritative for both the alias and the
        // target config, so a delete/recreate cannot run with predecessor data.
        let current_alias = require_gateway_chat_agent_alias(&config, agent_override)?;
        anyhow::ensure!(
            current_alias == agent_alias,
            "gateway chat agent changed during turn admission"
        );

        // Scope the cost tracking context so per-LLM-call usage flows into
        // the gateway's cost tracker and costs.jsonl. A separate
        // `TOOL_LOOP_TURN_USAGE` task-local accumulates this turn's totals so
        // the runtime-owned lifecycle guard can annotate its `AgentEnd`
        // without racing concurrent requests sharing the same tracker.
        // Pricing is built from the
        // unified `build_model_provider_pricing` (alias-keyed, `cost.rates`
        // wins over legacy per-alias pricing).
        let cost_tracking_context = state.cost_tracker.as_ref().map(|tracker| {
            let pricing = zeroclaw_runtime::agent::cost::build_model_provider_pricing(&config);
            zeroclaw_runtime::agent::cost::ToolLoopCostTrackingContext::new(
                tracker.clone(),
                std::sync::Arc::new(pricing),
            )
            .with_agent_alias(&agent_alias)
        });
        let turn_usage = state.cost_tracker.as_ref().map(|_| {
            std::sync::Arc::new(parking_lot::Mutex::new(
                zeroclaw_runtime::agent::cost::TurnUsage::default(),
            ))
        });
        let response = Box::pin(zeroclaw_runtime::agent::cost::TOOL_LOOP_TURN_USAGE.scope(
            turn_usage.clone(),
            zeroclaw_runtime::agent::cost::TOOL_LOOP_COST_TRACKING_CONTEXT.scope(
                cost_tracking_context,
                zeroclaw_runtime::agent::loop_::process_message_with_live_config_and_admission(
                    config,
                    state.config.clone(),
                    &agent_alias,
                    message,
                    session_id,
                    zeroclaw_api::ingress::TurnOrigin::Interactive,
                    Some(execution_admission),
                ),
            ),
        ))
        .await?;
        Ok(GatewayChatOutcome { response })
    }
}

fn resolve_gateway_chat_agent_alias(
    config: &Config,
    agent_override: Option<&str>,
) -> Option<String> {
    agent_override
        .map(ToString::to_string)
        .or_else(|| config.resolved_runtime_agent_alias().map(str::to_owned))
}

fn require_gateway_chat_agent_alias(
    config: &Config,
    agent_override: Option<&str>,
) -> anyhow::Result<String> {
    resolve_gateway_chat_agent_alias(config, agent_override).ok_or_else(|| {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Reject)
                .with_outcome(::zeroclaw_log::EventOutcome::Failure),
            "webhook chat rejected: no configured [agents.<alias>] entry"
        );
        anyhow::Error::msg("webhook chat requires at least one configured [agents.<alias>] entry")
    })
}

/// Routes owned by opt-in tools, present only when the tool is compiled in.
fn optional_tool_routes() -> Router<AppState> {
    let router: Router<AppState> = Router::new();
    // Claude Code runner hooks
    #[cfg(feature = "tool-claude-code-runner")]
    let router = router.route("/hooks/claude-code", post(api::handle_claude_code_hook));
    router
}

fn optional_channel_routes() -> Router<AppState> {
    let router: Router<AppState> = Router::new();
    #[cfg(feature = "channel-whatsapp-cloud")]
    let router = router
        .route("/whatsapp", get(handle_whatsapp_verify))
        .route("/whatsapp", post(handle_whatsapp_message))
        .route("/whatsapp/{alias}", get(handle_whatsapp_verify_alias))
        .route("/whatsapp/{alias}", post(handle_whatsapp_message_alias));
    #[cfg(feature = "channel-linq")]
    let router = router
        .route("/linq", post(handle_linq_webhook))
        .route("/linq/{alias}", post(handle_linq_webhook_alias));
    #[cfg(feature = "channel-nextcloud")]
    let router = router
        .route("/nextcloud-talk", post(handle_nextcloud_talk_webhook))
        .route(
            "/nextcloud-talk/{alias}",
            post(handle_nextcloud_talk_webhook_alias),
        );
    #[cfg(feature = "channel-email")]
    let router = router.route("/webhook/gmail", post(handle_gmail_push_webhook));
    router
}

fn sop_webhook_routes() -> Router<AppState> {
    Router::new().route("/sop/{*rest}", post(api_sop_webhook::handle_sop_webhook))
}

/// Webhook request body
#[derive(serde::Deserialize)]
pub struct WebhookBody {
    pub message: String,
    /// Opt in to Server-Sent Events streaming for this turn. Callers must also
    /// send an `Accept: text/event-stream` header.
    #[serde(default)]
    pub stream: bool,
    /// Keep a streamed turn running after this response body is dropped,
    /// instead of cancelling it. Requires `X-Session-Id`, so the turn stays
    /// addressable through `POST /api/sessions/{id}/abort`. The webhook keeps
    /// no transcript, so a detached turn's text has no reader: what it
    /// leaves behind is its memory writes, tool effects and usage records.
    /// Only meaningful with `stream: true`.
    #[serde(default)]
    pub continue_on_disconnect: bool,
}

/// Webhook query parameters
#[derive(Default, serde::Deserialize)]
pub struct WebhookQuery {
    /// Configured agent alias to dispatch to. Optional — when omitted, the
    /// legacy pick applies (migration-synthesized "default" agent, else the
    /// first enabled one). Aliases mirror `WsQuery` so `/ws/chat` callers
    /// can reuse their query string verbatim.
    #[serde(default, alias = "agentAlias", alias = "agent_alias")]
    pub agent: Option<String>,
}

type WebhookJsonResponse = (StatusCode, Json<serde_json::Value>);

/// Resolve the gateway webhook credential from its canonical live config.
/// Channel webhook aliases own separate HMAC listeners and never participate
/// in authorization for the gateway's `/webhook` or `/sop/*` routes.
fn configured_gateway_webhook_secret_hash(state: &AppState) -> Option<String> {
    state
        .config
        .read()
        .gateway
        .webhook_secret
        .as_deref()
        .map(str::trim)
        .filter(|secret| !secret.is_empty())
        .map(hash_webhook_secret)
}

/// Immutable snapshot of the credential policy applied to ONE request.
///
/// `AppState::config` is a live, published config that the config
/// PUT/PATCH handlers and `POST /admin/reload` legitimately replace while a
/// request is in flight. Reading the policy twice therefore lets a single
/// request straddle two security states: a headerless request can pass an
/// "unconfigured" read and then satisfy a "configured" read after an operator
/// inserts a secret, and a request bearing a revoked secret can pass a read
/// against the old secret and then be admitted merely because a replacement is
/// present.
///
/// This verdict is produced by exactly one policy read inside
/// [`authorize_webhook_request`] and is then threaded through dispatch. No
/// downstream code re-reads `state.config` for an authorization decision, so
/// live rotation takes effect at *next*-request granularity instead of mixing
/// two security states inside one request.
#[derive(Debug, Clone, Copy)]
pub(crate) struct WebhookAuthVerdict {
    /// `gateway.require_pairing` was on in this snapshot AND the bearer token verified.
    pairing_verified: bool,
    /// `gateway.webhook_secret` was set in this snapshot AND `X-Webhook-Secret` matched it.
    secret_verified: bool,
    /// At least one control was configured in this same snapshot.
    any_control_configured: bool,
}

impl WebhookAuthVerdict {
    /// The composition rule the docs state: at least one control must be
    /// configured, and every configured control must have passed. A verdict is
    /// only ever constructed after every configured control passed, so both
    /// facts come from the SAME snapshot and insertion/rotation cannot straddle
    /// them.
    fn may_dispatch_sop(self) -> bool {
        self.any_control_configured && (self.pairing_verified || self.secret_verified)
    }
}

fn authorize_webhook_request(
    state: &AppState,
    peer_addr: SocketAddr,
    headers: &HeaderMap,
) -> Result<WebhookAuthVerdict, WebhookJsonResponse> {
    let rate_key = client_key_from_request(Some(peer_addr), headers, state.trust_forwarded_headers);
    if !state.rate_limiter.allow_webhook(&rate_key) {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                .with_outcome(::zeroclaw_log::EventOutcome::Unknown),
            "/webhook rate limit exceeded"
        );
        let err = serde_json::json!({
            "error": "Too many webhook requests. Please retry later.",
            "retry_after": RATE_LIMIT_WINDOW_SECS,
        });
        return Err((StatusCode::TOO_MANY_REQUESTS, Json(err)));
    }

    // ── The single authorization policy read for this request ──
    // Everything below decides from `snapshot_secret_hash` / `require_pairing`
    // captured here; `state.config` is never consulted again for an
    // authorization decision on this request.
    let snapshot_secret_hash = configured_gateway_webhook_secret_hash(state);
    let require_pairing = state.pairing.require_pairing();
    let any_control_configured = require_pairing || snapshot_secret_hash.is_some();
    let mut pairing_verified = false;
    let mut secret_verified = false;

    if require_pairing {
        if let Err(e) = state.auth_limiter.check_rate_limit(&rate_key) {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({"rate_key": rate_key})),
                "webhook: auth rate limit exceeded for"
            );
            let err = serde_json::json!({
                "error": format!("Too many auth attempts. Try again in {}s.", e.retry_after_secs),
                "retry_after": e.retry_after_secs,
            });
            return Err((StatusCode::TOO_MANY_REQUESTS, Json(err)));
        }
        let auth = headers
            .get(header::AUTHORIZATION)
            .and_then(|v| v.to_str().ok())
            .unwrap_or("");
        let token = auth.strip_prefix("Bearer ").unwrap_or("");
        if !state.pairing.is_authenticated(token) {
            state.auth_limiter.record_attempt(&rate_key);
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown),
                "webhook: rejected — not paired / invalid bearer token"
            );
            let err = serde_json::json!({
                "error": "Unauthorized — pair first via POST /pair, then send Authorization: Bearer <token>"
            });
            return Err((StatusCode::UNAUTHORIZED, Json(err)));
        }
        pairing_verified = true;
    }

    if let Some(secret_hash) = snapshot_secret_hash.as_deref() {
        let header_hash = headers
            .get("X-Webhook-Secret")
            .and_then(|v| v.to_str().ok())
            .map(str::trim)
            .filter(|value| !value.is_empty())
            .map(hash_webhook_secret);
        match header_hash {
            Some(val) if constant_time_eq(&val, secret_hash) => {
                secret_verified = true;
            }
            _ => {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                        .with_outcome(::zeroclaw_log::EventOutcome::Unknown),
                    "webhook: rejected request — invalid or missing X-Webhook-Secret"
                );
                let err = serde_json::json!({"error": "Unauthorized — invalid or missing X-Webhook-Secret header"});
                return Err((StatusCode::UNAUTHORIZED, Json(err)));
            }
        }
    }

    Ok(WebhookAuthVerdict {
        pairing_verified,
        secret_verified,
        any_control_configured,
    })
}

/// Build an injective storage key for the replay/idempotency store.
///
/// Both the namespace (derived from a caller-controlled SOP path) and the
/// caller's `X-Idempotency-Key` are attacker-controlled strings, so a bare
/// `"{namespace}:{key}"` join is ambiguous: `/sop/a` with key `b:c` produced
/// the same string as `/sop/a:b` with key `c`, and a `/webhook` caller could
/// forge the key `sop:/sop/deploy:k` to collide with `/sop/deploy` key `k`.
/// An authenticated caller could therefore suppress a *different* attempt
/// despite the documented per-path and per-endpoint isolation.
///
/// This encoding is injective because every component is length-prefixed:
/// a reader consumes exactly the declared number of bytes, so no component
/// boundary can be forged by embedding the separator inside a component. The
/// endpoint domain tag is carried as its own component, so `/webhook` keys can
/// never alias `/sop/*` keys.
fn idempotency_storage_key(namespace: Option<&str>, idempotency_key: &str) -> String {
    fn push_component(out: &mut String, value: &str) {
        // `<byte-len>:<value>` — the length prefix makes the split point
        // unambiguous regardless of what `value` contains.
        out.push_str(&value.len().to_string());
        out.push(':');
        out.push_str(value);
    }

    let mut key = String::new();
    match namespace {
        Some(namespace) => {
            push_component(&mut key, "ns");
            push_component(&mut key, namespace);
        }
        None => push_component(&mut key, "global"),
    }
    push_component(&mut key, idempotency_key);
    key
}

/// Emit duplicate telemetry without copying caller-controlled key material
/// into the log pipeline. The key remains available to the replay store; only
/// its presence is useful and safe at this observability boundary.
fn record_duplicate_idempotency_log() {
    ::zeroclaw_log::record!(
        INFO,
        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
            .with_attrs(::serde_json::json!({"idempotency_key_present": true})),
        "webhook duplicate ignored"
    );
}

fn check_webhook_idempotency(
    state: &AppState,
    headers: &HeaderMap,
    namespace: Option<&str>,
) -> Option<WebhookJsonResponse> {
    let idempotency_key = headers
        .get("X-Idempotency-Key")
        .and_then(|v| v.to_str().ok())
        .map(str::trim)
        .filter(|value| !value.is_empty())?;
    let storage_key = idempotency_storage_key(namespace, idempotency_key);
    if state.idempotency_store.record_if_new(&storage_key) {
        return None;
    }

    record_duplicate_idempotency_log();
    Some((
        StatusCode::OK,
        Json(serde_json::json!({
            "status": "duplicate",
            "idempotent": true,
            "message": "A prior request already reserved this idempotency key; no new dispatch was started"
        })),
    ))
}

/// Fail closed before a SOP run starts. Starting a SOP run authorizes real
/// side effects, so — unlike the chat-only `/webhook` fallback, which keeps
/// its existing default-open policy — dispatch must not proceed when both
/// `gateway.require_pairing` and the webhook secret are unset (the official
/// container's default configuration). Repo policy is "new external surfaces
/// default closed".
///
/// This is a PURE function over the request-scoped [`WebhookAuthVerdict`]
/// produced by the single policy read in [`authorize_webhook_request`]. It
/// deliberately takes no `&AppState`: re-reading the live config here is what
/// let a request straddle two security states across a concurrent config
/// mutation.
fn require_sop_dispatch_credentials(
    verdict: WebhookAuthVerdict,
) -> Result<(), WebhookJsonResponse> {
    if verdict.may_dispatch_sop() {
        return Ok(());
    }
    ::zeroclaw_log::record!(
        WARN,
        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Reject)
            .with_outcome(::zeroclaw_log::EventOutcome::Failure),
        "sop webhook dispatch rejected — no credential configured"
    );
    let err = serde_json::json!({
        "error": "SOP webhook dispatch requires a configured credential: set \
                  `gateway.require_pairing = true` and authenticate with \
                  `Authorization: Bearer <paired-token>` (pair first via POST /pair), or set \
                  `gateway.webhook_secret` and send X-Webhook-Secret."
    });
    Err((StatusCode::UNAUTHORIZED, Json(err)))
}

/// POST /webhook — main webhook endpoint
async fn handle_webhook(
    State(state): State<AppState>,
    ConnectInfo(peer_addr): ConnectInfo<SocketAddr>,
    Query(query): Query<WebhookQuery>,
    headers: HeaderMap,
    body: Result<Json<WebhookBody>, axum::extract::rejection::JsonRejection>,
) -> Response {
    let auth_verdict = match authorize_webhook_request(&state, peer_addr, &headers) {
        Ok(verdict) => verdict,
        Err(response) => return response.into_response(),
    };
    let Json(webhook_body) = match body {
        Ok(b) => b,
        Err(e) => {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({"error": format!("{}", e)})),
                "webhook JSON parse error"
            );
            let err = serde_json::json!({
                "error": "Invalid JSON body. Expected: {\"message\": \"...\"}"
            });
            return (StatusCode::BAD_REQUEST, Json(err)).into_response();
        }
    };

    // ── SOP dispatch first ──
    // A matching `/webhook` SOP trigger takes the request before any
    // chat-only routing (query params, agent aliases) is even inspected —
    // the advertised contract is SOP dispatch first, chat fallback second,
    // so a chat-only param must never block a matching SOP.
    let sop_payload = serde_json::json!({ "message": &webhook_body.message }).to_string();
    let has_matching_sop = match api_sop_webhook::has_matching_webhook_sop(&state, "/webhook") {
        Ok(matches) => matches,
        Err(response) => return response.into_response(),
    };

    if has_matching_sop {
        if let Err(response) = require_sop_dispatch_credentials(auth_verdict) {
            return response.into_response();
        }
        if let Some(response) = check_webhook_idempotency(&state, &headers, None) {
            return response.into_response();
        }
        if let api_sop_webhook::SopWebhookOutcome::Handled(response) =
            api_sop_webhook::dispatch_webhook_sop(&state, "/webhook", Some(&sop_payload)).await
        {
            return response.into_response();
        }
        // The engine reported no match after all (e.g. a trigger was
        // unloaded between the pre-check above and dispatch); fall through
        // to chat. The idempotency key above is already consumed for this
        // attempt.
    }

    // ── Per-request agent dispatch (optional `?agent=` query param) ──
    // Chat-only routing: only reached when no SOP trigger matched
    // `/webhook`, so a bogus `?agent=` can never block a matching SOP
    // dispatch. Validated before idempotency / autosave so a typo'd alias
    // doesn't consume the caller's idempotency key. Mirrors the `/ws/chat`
    // unknown-agent rejection.
    let agent_override = query
        .agent
        .as_deref()
        .map(str::trim)
        .filter(|s| !s.is_empty());
    if let Some(alias) = agent_override {
        let cfg = state.config.read();
        if cfg.agent(alias).is_none() {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Reject)
                    .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                    .with_attrs(::serde_json::json!({"agent": alias})),
                "webhook: rejected — unknown agent alias"
            );
            let err = serde_json::json!({
                "error": format!(
                    "Unknown agent `{alias}` — no [agents.{alias}] entry configured."
                )
            });
            return (StatusCode::BAD_REQUEST, Json(err)).into_response();
        }
    }

    // A streamed turn may only outlive its body when it stays abortable, so
    // `continue_on_disconnect` needs an `X-Session-Id`. Refused here, before
    // idempotency and autosave, so the rejected attempt neither consumes the
    // caller's idempotency key (a corrected retry must run) nor saves its
    // message.
    if webhook_body.stream
        && webhook_body.continue_on_disconnect
        && accepts_sse(&headers)
        && webhook_session_id(&headers).is_none()
    {
        let err = serde_json::json!({
            "error": "continue_on_disconnect requires an X-Session-Id header"
        });
        return (StatusCode::BAD_REQUEST, Json(err)).into_response();
    }

    if !has_matching_sop && let Some(response) = check_webhook_idempotency(&state, &headers, None) {
        return response.into_response();
    }

    let message = &webhook_body.message;
    let session_id = webhook_session_id(&headers);

    if state.auto_save && !zeroclaw_memory::should_skip_autosave_content(message) {
        let key = webhook_memory_key();
        let _ = state
            .mem
            .store(
                &key,
                message,
                MemoryCategory::Conversation,
                session_id.as_deref(),
            )
            .await;
    }

    let model_label = {
        let cfg = state.config.read();
        let resolved_agent_alias = resolve_gateway_chat_agent_alias(&cfg, agent_override);
        let resolved_provider = resolved_agent_alias
            .as_deref()
            .and_then(|alias| cfg.resolved_model_provider_for_agent(alias));
        resolved_provider
            .and_then(|(_, _, entry)| {
                entry
                    .model
                    .as_deref()
                    .map(str::trim)
                    .filter(|model| !model.is_empty())
                    .map(ToString::to_string)
            })
            .or_else(|| cfg.resolve_default_model())
            .unwrap_or_else(|| "<unresolved>".to_string())
    };
    // HTTP transport owns request latency and response mapping. The production
    // dispatch below enters `process_message`, whose runtime turn guard is the
    // sole owner of lifecycle and LLM events. Emitting another bracket here
    // gives one webhook prompt two unrelated turn IDs.
    let started_at = Instant::now();

    // ── Optional SSE streaming ──
    // Opt in with `stream: true` plus an `Accept: text/event-stream` header:
    // the turn then streams cumulative assistant tokens as `event: token`
    // frames, ends with `event: done` (or `event: error`), and honours
    // client disconnects through the shared cancellation registry. Every
    // other combination keeps the JSON `{ response }` path below untouched.
    if webhook_body.stream && accepts_sse(&headers) {
        return run_gateway_chat_streaming_response(
            &state,
            message,
            session_id.as_deref(),
            agent_override,
            webhook_body.continue_on_disconnect,
            started_at,
        )
        .await;
    }

    match run_gateway_chat_with_tools(&state, message, session_id.as_deref(), agent_override).await
    {
        Ok(GatewayChatOutcome { response, .. }) => {
            let duration = started_at.elapsed();
            state.observer.record_metric(
                &zeroclaw_runtime::observability::traits::ObserverMetric::RequestLatency(duration),
            );

            let body = serde_json::json!({"response": response, "model": model_label});
            (StatusCode::OK, Json(body)).into_response()
        }
        Err(e) => {
            let duration = started_at.elapsed();
            let sanitized = zeroclaw_providers::sanitize_api_error(&e.to_string());
            state.observer.record_metric(
                &zeroclaw_runtime::observability::traits::ObserverMetric::RequestLatency(duration),
            );
            state
                .observer
                .record_event(&zeroclaw_runtime::observability::ObserverEvent::Error {
                    component: "gateway".to_string(),
                    message: sanitized.clone(),
                });
            if is_needs_quickstart_err(&e) {
                ::zeroclaw_log::record!(
                    WARN,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                        .with_outcome(::zeroclaw_log::EventOutcome::Unknown),
                    "Webhook chat refused: gateway has no model configured; \
                     visit /quickstart"
                );
                let body = serde_json::json!({
                    "error": "needs_quickstart",
                    "url": "/quickstart"
                });
                (StatusCode::SERVICE_UNAVAILABLE, Json(body)).into_response()
            } else {
                ::zeroclaw_log::record!(
                    ERROR,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                        .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                        .with_attrs(::serde_json::json!({"error": sanitized})),
                    "webhook model_provider error"
                );
                let err = serde_json::json!({"error": "LLM request failed"});
                (StatusCode::INTERNAL_SERVER_ERROR, Json(err)).into_response()
            }
        }
    }
}

/// True when the request's `Accept` header negotiates Server-Sent Events.
fn accepts_sse(headers: &HeaderMap) -> bool {
    headers
        .get(header::ACCEPT)
        .and_then(|v| v.to_str().ok())
        .map(|v| v.to_ascii_lowercase().contains("text/event-stream"))
        .unwrap_or(false)
}

/// Build one cumulative `event: token` SSE frame.
fn sse_token_frame(cumulative: &str) -> Result<SseWireEvent, std::convert::Infallible> {
    let data = serde_json::json!({ "text": cumulative }).to_string();
    Ok(SseWireEvent::default().event("token").data(data))
}

/// Build the terminating `event: error` SSE frame.
fn sse_error_frame(message: &str) -> Result<SseWireEvent, std::convert::Infallible> {
    let data = serde_json::json!({ "message": message }).to_string();
    Ok(SseWireEvent::default().event("error").data(data))
}

fn send_sse_terminal_error(
    terminal_tx: &mut Option<tokio::sync::oneshot::Sender<SseFrame>>,
    message: &str,
) {
    if let Some(sender) = terminal_tx.take() {
        let _ = sender.send(sse_error_frame(message));
    }
}

/// Reconcile the runtime's authoritative final response with text already
/// emitted from streamed chunks. The runtime may return a cached response with
/// no chunks, or append a receipt/fallback suffix after the last chunk. Prefix
/// reconciliation emits only the missing suffix; a non-prefix conflict uses a
/// replacement cumulative frame so clients never concatenate duplicate text.
/// An empty final response is authoritative too: when earlier chunks exist it
/// emits an empty cumulative replacement instead of leaving stale text visible.
fn reconcile_sse_final_response(cumulative: &mut String, final_response: &str) -> Option<SseFrame> {
    if final_response == cumulative {
        return None;
    }

    if let Some(suffix) = final_response.strip_prefix(cumulative.as_str()) {
        cumulative.push_str(suffix);
    } else {
        cumulative.clear();
        cumulative.push_str(final_response);
    }
    Some(sse_token_frame(cumulative))
}

type SseFrame = Result<SseWireEvent, std::convert::Infallible>;

/// Why a frame did not reach the SSE body.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SseSend {
    Sent,
    /// The turn was cancelled while the frame waited for queue space.
    Cancelled,
    /// The client dropped the response body: there is no viewer any more.
    ViewerGone,
}

async fn send_sse_frame(
    frame_tx: &tokio::sync::mpsc::Sender<SseFrame>,
    frame: SseFrame,
    cancel_token: &tokio_util::sync::CancellationToken,
) -> SseSend {
    tokio::select! {
        result = frame_tx.send(frame) => match result {
            Ok(()) => SseSend::Sent,
            Err(_) => SseSend::ViewerGone,
        },
        _ = cancel_token.cancelled() => SseSend::Cancelled,
    }
}

/// Register the current turn for a gateway session and cancel any replaced
/// turn before returning. Both HTTP/SSE and WebSocket transports share this
/// registry, so replacement ownership must be identical at both edges.
pub(crate) fn register_cancel_token(
    cancel_tokens: &Arc<
        std::sync::Mutex<
            std::collections::HashMap<String, Arc<tokio_util::sync::CancellationToken>>,
        >,
    >,
    session_key: &str,
    cancel_token: Arc<tokio_util::sync::CancellationToken>,
) {
    let previous_token = cancel_tokens
        .lock()
        .expect("cancel_tokens lock poisoned")
        .insert(session_key.to_owned(), cancel_token);
    if let Some(previous_token) = previous_token {
        previous_token.cancel();
    }
}

/// Remove a turn's registry entry only while it still owns the session key.
/// A late completion from a replaced WS/SSE turn must never remove the newer
/// turn's cancellation handle.
pub(crate) fn remove_cancel_token_if_current(
    cancel_tokens: &Arc<
        std::sync::Mutex<
            std::collections::HashMap<String, Arc<tokio_util::sync::CancellationToken>>,
        >,
    >,
    session_key: &str,
    cancel_token: &Arc<tokio_util::sync::CancellationToken>,
) {
    let mut tokens = cancel_tokens.lock().expect("cancel_tokens lock poisoned");
    if tokens
        .get(session_key)
        .is_some_and(|current| Arc::ptr_eq(current, cancel_token))
    {
        tokens.remove(session_key);
    }
}

/// The cancellation a body holds when it owns its turn, which is every
/// streamed turn that did not opt into `continue_on_disconnect`: leaving
/// cancels it at once rather than at the next chunk.
struct OwnedTurnCancel {
    cancel_token: Arc<tokio_util::sync::CancellationToken>,
    cancel_tokens: Arc<
        std::sync::Mutex<
            std::collections::HashMap<String, Arc<tokio_util::sync::CancellationToken>>,
        >,
    >,
    cancel_key: String,
}

/// The streamed response body. By default it owns its turn and cancels it
/// when dropped. A turn that opted into `continue_on_disconnect` (with an
/// `X-Session-Id`) is only viewed by its body: dropping it closes the frame
/// queue, which the relay task reads as the viewer leaving, and the turn
/// runs on until it ends or `POST /api/sessions/{id}/abort` cancels it.
struct SseClientStream {
    receiver: tokio::sync::mpsc::Receiver<SseFrame>,
    terminal_receiver: Option<tokio::sync::oneshot::Receiver<SseFrame>>,
    terminal_delivered: bool,
    owned_turn: Option<OwnedTurnCancel>,
}

impl Drop for SseClientStream {
    fn drop(&mut self) {
        if let Some(owned) = &self.owned_turn {
            owned.cancel_token.cancel();
            remove_cancel_token_if_current(
                &owned.cancel_tokens,
                &owned.cancel_key,
                &owned.cancel_token,
            );
        }
    }
}

impl futures_util::Stream for SseClientStream {
    type Item = SseFrame;

    fn poll_next(
        self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        let this = self.get_mut();
        if this.terminal_delivered {
            return std::task::Poll::Ready(None);
        }

        if let Some(terminal_receiver) = this.terminal_receiver.as_mut() {
            match std::pin::Pin::new(terminal_receiver).poll(cx) {
                std::task::Poll::Ready(Ok(frame)) => {
                    // A terminal error is deliberately independent of the
                    // bounded token queue. Once it is delivered, discard any
                    // queued token frames so the client observes one terminal
                    // error rather than a truncated stream followed by stale
                    // data.
                    this.terminal_receiver = None;
                    this.terminal_delivered = true;
                    this.receiver.close();
                    return std::task::Poll::Ready(Some(frame));
                }
                std::task::Poll::Ready(Err(_)) => {
                    // Normal completion drops the sender after enqueueing the
                    // regular done frame. Continue draining that frame queue.
                    this.terminal_receiver = None;
                }
                std::task::Poll::Pending => {}
            }
        }

        this.receiver.poll_recv(cx)
    }
}

/// Stream one gateway chat turn over Server-Sent Events.
///
/// Drives the turn with the same streamed agent API the `/ws/chat` path uses
/// ([`zeroclaw_runtime::agent::Agent::turn_streamed`]), relaying cumulative
/// `TurnEvent::Chunk` text as `event: token` frames. The turn's cancellation
/// token is registered under the same `gw_{session}` key the abort endpoint
/// uses, so an in-flight streamed turn is cancellable exactly like a
/// WebSocket turn. By default the stream owns its turn and dropping it
/// cancels, the contract streamed webhook callers have always had. A caller
/// that sends `continue_on_disconnect: true` with its `X-Session-Id` makes
/// the stream a viewer instead, like a WebSocket: a disconnect mid-turn
/// detaches, the turn runs to completion unattended and the token stays
/// registered until it ends, so only `POST /api/sessions/{id}/abort`, or a
/// newer turn on the same session, cancels it. The handler refuses the opt-in
/// without a session, since nobody could abort such a turn.
async fn run_gateway_chat_streaming_response(
    state: &AppState,
    message: &str,
    session_id: Option<&str>,
    agent_override: Option<&str>,
    continue_on_disconnect: bool,
    started_at: Instant,
) -> Response {
    if let Some(err) = needs_quickstart_for(&state.model) {
        if is_needs_quickstart_err(&err) {
            let body = serde_json::json!({
                "error": "needs_quickstart",
                "url": "/quickstart"
            });
            return (StatusCode::SERVICE_UNAVAILABLE, Json(body)).into_response();
        }
    }

    let (event_tx, mut event_rx) = tokio::sync::mpsc::channel::<zeroclaw_api::agent::TurnEvent>(64);
    let cancel_token = Arc::new(tokio_util::sync::CancellationToken::new());

    // Register under the process-local cancellation key so the existing abort
    // endpoint (and the shared cancellation registry) can cancel the
    // in-flight turn without collapsing distinct display ids.
    let (session_key, cancel_key) = match session_id {
        Some(session_id) => (
            gateway_session_key(session_id),
            gateway_cancel_key(session_id),
        ),
        None => {
            let generated_session_id = uuid::Uuid::new_v4().to_string();
            (
                gateway_session_key(&generated_session_id),
                gateway_cancel_key(&generated_session_id),
            )
        }
    };
    register_cancel_token(&state.cancel_tokens, &cancel_key, Arc::clone(&cancel_token));

    let (frame_tx, frame_rx) = tokio::sync::mpsc::channel::<SseFrame>(16);
    let (terminal_tx, terminal_rx) = tokio::sync::oneshot::channel::<SseFrame>();
    let (turn_tx, turn_rx) = tokio::sync::oneshot::channel::<anyhow::Result<String>>();

    let state_for_turn = state.clone();
    let message_owned = message.to_string();
    let session_for_turn = session_id.map(str::to_string);
    let alias_for_turn = agent_override.map(str::to_string);
    let session_key_for_turn = session_key.clone();
    let token_for_turn = Arc::clone(&cancel_token);
    zeroclaw_spawn::spawn!(async move {
        let outcome = dispatch_gateway_turn_streaming(
            &state_for_turn,
            &message_owned,
            event_tx,
            token_for_turn.as_ref(),
            session_for_turn.as_deref(),
            alias_for_turn.as_deref(),
            &session_key_for_turn,
        )
        .await;
        let _ = turn_tx.send(outcome);
    });

    let state_for_frames = state.clone();
    let cancel_key_for_frames = cancel_key.clone();
    let session_key_for_frames = session_key.clone();
    // Only an opted-in turn with a session outlives its body: it stays
    // abortable through the registered token. Every other stream owns its
    // turn, so dropping it cancels.
    let viewer_owns_turn = session_id.is_none() || !continue_on_disconnect;
    let token_for_body = Arc::clone(&cancel_token);
    zeroclaw_spawn::spawn!(async move {
        let mut terminal_tx = Some(terminal_tx);
        let mut cumulative = String::new();
        // An opted-in body is a viewer of the turn, not its owner. Once the
        // client is gone (the frame queue's receiver dropped) this task stops
        // sending frames but keeps draining `event_rx`, so the agent runs to
        // completion: its memory writes, tool effects and usage records
        // happen, although the webhook keeps no transcript of its text. Only
        // the explicit abort path (`cancel_token`, reached through
        // `POST /api/sessions/{id}/abort`) or a newer turn on the session
        // cancels it. Any other body owns its turn: its leaving cancels.
        let mut viewer_attached = true;
        let interrupted = || {
            zeroclaw_providers::sanitize_api_error(
                &zeroclaw_runtime::i18n::get_required_cli_string("turn-interrupted-by-user"),
            )
        };
        let detach = |viewer_attached: &mut bool| {
            if *viewer_attached {
                *viewer_attached = false;
                ::zeroclaw_log::record!(
                    INFO,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                        .with_attrs(::serde_json::json!({
                            "session_key": session_key_for_frames,
                            "transport": "sse",
                        })),
                    "SSE client detached mid-turn; turn continues unattended"
                );
            }
        };
        loop {
            tokio::select! {
                maybe = event_rx.recv() => match maybe {
                    Some(zeroclaw_api::agent::TurnEvent::Chunk { delta }) => {
                        cumulative.push_str(&delta);
                        if !viewer_attached {
                            continue;
                        }
                        match send_sse_frame(&frame_tx, sse_token_frame(&cumulative), &cancel_token)
                            .await
                        {
                            SseSend::Sent => {}
                            SseSend::ViewerGone if !viewer_owns_turn => detach(&mut viewer_attached),
                            SseSend::ViewerGone | SseSend::Cancelled => {
                                if viewer_owns_turn {
                                    cancel_token.cancel();
                                }
                                // The bounded token queue may be full, so a
                                // cancellation-aware send can return without
                                // delivering the terminal frame through it.
                                send_sse_terminal_error(&mut terminal_tx, &interrupted());
                                remove_cancel_token_if_current(
                                    &state_for_frames.cancel_tokens,
                                    &cancel_key_for_frames,
                                    &cancel_token,
                                );
                                return;
                            }
                        }
                    }
                    Some(_) => {}
                    None => break,
                },
                _ = cancel_token.cancelled() => {
                    // A server-side abort can leave the HTTP connection open.
                    // Emit one sanitized terminal frame before ending the
                    // stream; a client that is already gone makes this send
                    // fail and is handled by the same path without more work.
                    send_sse_terminal_error(&mut terminal_tx, &interrupted());
                    remove_cancel_token_if_current(
                        &state_for_frames.cancel_tokens,
                        &cancel_key_for_frames,
                        &cancel_token,
                    );
                    return;
                }
            }
        }
        let result = turn_rx
            .await
            .unwrap_or_else(|e| Err(anyhow::Error::msg(e.to_string())));
        remove_cancel_token_if_current(
            &state_for_frames.cancel_tokens,
            &cancel_key_for_frames,
            &cancel_token,
        );
        state_for_frames.observer.record_metric(
            &zeroclaw_runtime::observability::traits::ObserverMetric::RequestLatency(
                started_at.elapsed(),
            ),
        );
        if !viewer_attached {
            // Nobody is listening and there is no body to finish. The turn's
            // memory writes, tool effects and usage records are done; the
            // webhook path keeps no transcript, so its text has no reader.
            return;
        }
        match result {
            Ok(final_response) => {
                if let Some(frame) = reconcile_sse_final_response(&mut cumulative, &final_response)
                    && send_sse_frame(&frame_tx, frame, &cancel_token).await != SseSend::Sent
                {
                    // Cancelled or gone during the final frame: the turn is
                    // over either way, so a terminal frame is all that is
                    // left to offer, and a gone client simply never reads it.
                    send_sse_terminal_error(&mut terminal_tx, &interrupted());
                    return;
                }
                if send_sse_frame(
                    &frame_tx,
                    Ok(SseWireEvent::default().event("done").data("{}")),
                    &cancel_token,
                )
                .await
                    != SseSend::Sent
                {
                    send_sse_terminal_error(&mut terminal_tx, &interrupted());
                }
            }
            Err(e) => {
                if cancel_token.is_cancelled() {
                    send_sse_terminal_error(&mut terminal_tx, &interrupted());
                } else {
                    let sanitized = zeroclaw_providers::sanitize_api_error(&e.to_string());
                    if send_sse_frame(&frame_tx, sse_error_frame(&sanitized), &cancel_token).await
                        != SseSend::Sent
                    {
                        send_sse_terminal_error(&mut terminal_tx, &interrupted());
                    }
                }
            }
        }
    });

    let owned_turn = viewer_owns_turn.then(|| OwnedTurnCancel {
        cancel_token: token_for_body,
        cancel_tokens: Arc::clone(&state.cancel_tokens),
        cancel_key: cancel_key.clone(),
    });
    let body = SseBody::new(SseClientStream {
        receiver: frame_rx,
        terminal_receiver: Some(terminal_rx),
        terminal_delivered: false,
        owned_turn,
    })
    .keep_alive(SseKeepAlive::default());
    (
        StatusCode::OK,
        [
            (header::CACHE_CONTROL, "no-cache"),
            (header::CONTENT_TYPE, "text/event-stream"),
        ],
        body,
    )
        .into_response()
}

/// Dispatch one streamed gateway chat turn, emitting [`TurnEvent`]s on
/// `event_tx`. Test builds dispatch to the mock model provider directly
/// (mirroring `run_gateway_chat_with_tools`); production builds construct
/// the per-request agent and drive it through `turn_streamed`.
async fn dispatch_gateway_turn_streaming(
    state: &AppState,
    message: &str,
    event_tx: tokio::sync::mpsc::Sender<zeroclaw_api::agent::TurnEvent>,
    cancel_token: &tokio_util::sync::CancellationToken,
    session_id: Option<&str>,
    agent_override: Option<&str>,
    session_key: &str,
) -> anyhow::Result<String> {
    #[cfg(test)]
    {
        // Keep the lightweight provider fixture for the existing webhook
        // infrastructure tests, but allow configured-agent fixtures to run
        // through the same Agent construction and cost scope as production.
        let configured_agent = {
            let config = state.config.read();
            resolve_gateway_chat_agent_alias(&config, agent_override)
                .is_some_and(|alias| config.agent(&alias).is_some())
        };
        if configured_agent {
            return dispatch_gateway_turn_streaming_with_agent(
                state,
                message,
                event_tx,
                cancel_token,
                session_id,
                agent_override,
                session_key,
            )
            .await;
        }

        record_gateway_chat_dispatch_for_test(message, session_id, agent_override);
        let call =
            state
                .model_provider
                .chat_with_system(None, message, &state.model, state.temperature);
        tokio::select! {
            result = call => {
                let response = result?;
                // One chunk per line, so a fixture can emit more events than
                // the relay's queue holds and prove the relay keeps reading.
                // Delivered events are counted per session, so a test can
                // tell a relay that closed its receiver early from one that
                // drained everything.
                for delta in response.split_inclusive('\n') {
                    if event_tx
                        .send(zeroclaw_api::agent::TurnEvent::Chunk { delta: delta.to_owned() })
                        .await
                        .is_ok()
                    {
                        sse_test_record_event_delivered(session_id.unwrap_or("anonymous"));
                    }
                }
                Ok(response)
            }
            _ = cancel_token.cancelled() => Err(anyhow::Error::msg(
                "streamed webhook turn cancelled",
            )),
        }
    }

    #[cfg(not(test))]
    {
        dispatch_gateway_turn_streaming_with_agent(
            state,
            message,
            event_tx,
            cancel_token,
            session_id,
            agent_override,
            session_key,
        )
        .await
    }
}

/// Construct and drive the production Agent for a streamed gateway turn.
/// Keeping this helper outside the test-only dispatch branch lets configured
/// test fixtures exercise the exact same construction, budget, and attribution
/// path used by non-test builds.
async fn dispatch_gateway_turn_streaming_with_agent(
    state: &AppState,
    message: &str,
    event_tx: tokio::sync::mpsc::Sender<zeroclaw_api::agent::TurnEvent>,
    cancel_token: &tokio_util::sync::CancellationToken,
    session_id: Option<&str>,
    agent_override: Option<&str>,
    session_key: &str,
) -> anyhow::Result<String> {
    let config = state.config.read().clone();
    let agent_alias = require_gateway_chat_agent_alias(&config, agent_override)?;
    let mut agent =
        zeroclaw_runtime::agent::Agent::from_live_config_with_session_cwd_and_mcp_backchannel(
            state.config.clone(),
            &agent_alias,
            None,
            true,
            false,
            false,
            state.sop_engine.clone(),
            state.sop_audit.clone(),
            Some(state.canvas_store.clone()),
        )
        .await?;
    #[cfg(test)]
    agent.set_turn_datetime_for_test(gateway_fixture_turn_datetime);
    if let Some(session) = session_id {
        agent.set_memory_session_id(Some(zeroclaw_api::session_keys::sanitize_session_key(
            session,
        )));
    }

    let cost_tracking_context = state.cost_tracker.as_ref().map(|tracker| {
        zeroclaw_runtime::agent::cost::tool_loop_cost_tracking_context_from_tracker(
            &config,
            &agent_alias,
            tracker.clone(),
        )
    });
    let turn_usage = state.cost_tracker.as_ref().map(|_| {
        Arc::new(Mutex::new(
            zeroclaw_runtime::agent::cost::TurnUsage::default(),
        ))
    });
    let (response, _) = Box::pin(zeroclaw_runtime::agent::loop_::scope_session_key(
        Some(session_key.to_owned()),
        zeroclaw_runtime::agent::cost::TOOL_LOOP_TURN_USAGE.scope(
            turn_usage,
            zeroclaw_runtime::agent::cost::TOOL_LOOP_COST_TRACKING_CONTEXT.scope(
                cost_tracking_context,
                agent.turn_streamed(message, event_tx, Some(cancel_token.clone())),
            ),
        ),
    ))
    .await?;
    Ok(response)
}

#[cfg(test)]
fn gateway_fixture_turn_datetime() -> chrono::DateTime<chrono::Local> {
    chrono::DateTime::parse_from_rfc3339("2026-06-25T12:00:00+00:00")
        .expect("fixed gateway fixture timestamp")
        .with_timezone(&chrono::Local)
}

/// `WhatsApp` verification query params
#[derive(serde::Deserialize)]
pub struct WhatsAppVerifyQuery {
    #[serde(rename = "hub.mode")]
    pub mode: Option<String>,
    #[serde(rename = "hub.verify_token")]
    pub verify_token: Option<String>,
    #[serde(rename = "hub.challenge")]
    pub challenge: Option<String>,
}

/// GET /whatsapp — Meta webhook verification (bare path, deprecated fallback).
#[cfg(feature = "channel-whatsapp-cloud")]
async fn handle_whatsapp_verify(
    State(state): State<AppState>,
    Query(params): Query<WhatsAppVerifyQuery>,
) -> Response {
    handle_whatsapp_verify_impl(state, None, params).await
}

/// GET /whatsapp/{alias} — Meta webhook verification for a specific instance.
#[cfg(feature = "channel-whatsapp-cloud")]
async fn handle_whatsapp_verify_alias(
    State(state): State<AppState>,
    Path(alias): Path<String>,
    Query(params): Query<WhatsAppVerifyQuery>,
) -> Response {
    handle_whatsapp_verify_impl(state, Some(alias), params).await
}

#[cfg(feature = "channel-whatsapp-cloud")]
async fn handle_whatsapp_verify_impl(
    state: AppState,
    alias: Option<String>,
    params: WhatsAppVerifyQuery,
) -> Response {
    let resolved = api_webhook::resolve(&state.whatsapp, alias.as_deref());
    let Some((_alias, wa)) = resolved.entry() else {
        return api_webhook::not_found("whatsapp");
    };

    // Verify the token matches (constant-time comparison to prevent timing attacks)
    let token_matches = params
        .verify_token
        .as_deref()
        .is_some_and(|t| constant_time_eq(t, wa.verify_token()));
    let resp = if params.mode.as_deref() == Some("subscribe") && token_matches {
        if let Some(ch) = params.challenge {
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_attrs(::serde_json::json!({"channel": "whatsapp"})),
                "webhook verified successfully"
            );
            (StatusCode::OK, ch).into_response()
        } else {
            (StatusCode::BAD_REQUEST, "Missing hub.challenge".to_string()).into_response()
        }
    } else {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                .with_attrs(::serde_json::json!({"channel": "whatsapp"})),
            "webhook verification failed — token mismatch"
        );
        (StatusCode::FORBIDDEN, "Forbidden".to_string()).into_response()
    };
    api_webhook::tag_deprecation(resp, resolved, "whatsapp")
}

/// Verify `WhatsApp` webhook signature (`X-Hub-Signature-256`).
/// Returns true if the signature is valid, false otherwise.
/// See: <https://developers.facebook.com/docs/graph-api/webhooks/getting-started#verification-requests>
pub fn verify_whatsapp_signature(app_secret: &str, body: &[u8], signature_header: &str) -> bool {
    use hmac::{Hmac, Mac};
    use sha2::Sha256;

    // Signature format: "sha256=<hex_signature>"
    let Some(hex_sig) = signature_header.strip_prefix("sha256=") else {
        return false;
    };

    // Decode hex signature
    let Ok(expected) = hex::decode(hex_sig) else {
        return false;
    };

    // Compute HMAC-SHA256
    let Ok(mut mac) = Hmac::<Sha256>::new_from_slice(app_secret.as_bytes()) else {
        return false;
    };
    mac.update(body);

    // Constant-time comparison
    mac.verify_slice(&expected).is_ok()
}

/// POST /whatsapp — incoming message webhook
/// POST /whatsapp — incoming message webhook (bare path, deprecated fallback).
#[cfg(feature = "channel-whatsapp-cloud")]
async fn handle_whatsapp_message(
    State(state): State<AppState>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    handle_whatsapp_message_impl(state, None, headers, body).await
}

/// POST /whatsapp/{alias} — incoming message webhook for a specific instance.
#[cfg(feature = "channel-whatsapp-cloud")]
async fn handle_whatsapp_message_alias(
    State(state): State<AppState>,
    Path(alias): Path<String>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    handle_whatsapp_message_impl(state, Some(alias), headers, body).await
}

#[cfg(feature = "channel-whatsapp-cloud")]
async fn handle_whatsapp_message_impl(
    state: AppState,
    alias: Option<String>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    let resolved = api_webhook::resolve(&state.whatsapp, alias.as_deref());
    let Some((alias_key, wa)) = resolved.entry() else {
        return api_webhook::not_found("whatsapp");
    };
    let app_secret = state.whatsapp_app_secret.get(alias_key).cloned();
    let resp =
        process_whatsapp_message(&state, alias_key, wa, app_secret.as_deref(), headers, body).await;
    api_webhook::tag_deprecation(resp.into_response(), resolved, "whatsapp")
}

/// Verify, parse, and dispatch a WhatsApp webhook payload for one resolved
/// instance. `app_secret` is that instance's `X-Hub-Signature-256` secret.
#[cfg(feature = "channel-whatsapp-cloud")]
async fn process_whatsapp_message(
    state: &AppState,
    alias: &str,
    wa: &Arc<WhatsAppChannel>,
    app_secret: Option<&str>,
    headers: HeaderMap,
    body: Bytes,
) -> (StatusCode, Json<serde_json::Value>) {
    let verified = match webhook_ingress::authenticate(
        &webhook_ingress::WHATSAPP_WEBHOOK,
        alias,
        app_secret,
        &headers,
        body,
        |secret, headers, body| {
            let signature = headers
                .get("X-Hub-Signature-256")
                .and_then(|v| v.to_str().ok())
                .unwrap_or("");
            verify_whatsapp_signature(secret, body, signature)
        },
    ) {
        Ok(verified) => verified,
        Err(refusal) => return refusal.into_response(&webhook_ingress::WHATSAPP_WEBHOOK),
    };

    let mut verified = match verified.parse_messages(|body| {
        let payload = serde_json::from_slice::<serde_json::Value>(body).map_err(|_| {
            (
                StatusCode::BAD_REQUEST,
                Json(serde_json::json!({"error": "Invalid JSON payload"})),
            )
        })?;
        Ok::<_, (StatusCode, Json<serde_json::Value>)>(wa.parse_webhook_payload(&payload))
    }) {
        Ok(verified) => verified,
        Err(response) => return response,
    };

    // Route approval replies to pending approval requests before dispatching
    // to the agent.
    let mut handled_approval_messages = std::collections::HashSet::new();
    for msg in verified.messages() {
        let Some((token, response)) = zeroclaw_channels::util::parse_approval_reply(&msg.content)
        else {
            continue;
        };
        if wa
            .resolve_pending_approval(
                &token,
                response,
                msg.sender.as_str(),
                msg.reply_target.as_str(),
            )
            .await
        {
            handled_approval_messages.insert(msg.id.clone());
        }
    }
    verified.retain(|msg| !handled_approval_messages.contains(&msg.id));

    let channel: Arc<dyn Channel> = wa.clone();
    webhook_ingress::dispatch_verified_webhook(
        state,
        verified,
        webhook_ingress::WebhookDispatchContext {
            channel,
            memory_key: whatsapp_memory_key,
            agent_override: None,
            mode: webhook_ingress::WebhookDispatchMode::Synchronous,
            #[cfg(test)]
            suppress_reply_send: true,
        },
    )
    .await
}

/// POST /linq — incoming message webhook (bare path, deprecated fallback).
#[cfg(feature = "channel-linq")]
async fn handle_linq_webhook(
    State(state): State<AppState>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    handle_linq_webhook_impl(state, None, headers, body).await
}

/// POST /linq/{alias} — incoming message webhook for a specific instance.
#[cfg(feature = "channel-linq")]
async fn handle_linq_webhook_alias(
    State(state): State<AppState>,
    Path(alias): Path<String>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    handle_linq_webhook_impl(state, Some(alias), headers, body).await
}

#[cfg(feature = "channel-linq")]
async fn handle_linq_webhook_impl(
    state: AppState,
    alias: Option<String>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    let resolved = api_webhook::resolve(&state.linq, alias.as_deref());
    let Some((alias_key, linq)) = resolved.entry() else {
        return api_webhook::not_found("linq");
    };
    let signing_secret = state.linq_signing_secrets.get(alias_key).cloned();
    let resp = process_linq_webhook(
        &state,
        alias_key,
        linq,
        signing_secret.as_deref(),
        headers,
        body,
    )
    .await;
    api_webhook::tag_deprecation(resp.into_response(), resolved, "linq")
}

/// Verify, parse, and dispatch a Linq webhook payload for one resolved instance.
/// `signing_secret` is that instance's `X-Webhook-Signature` secret.
#[cfg(feature = "channel-linq")]
async fn process_linq_webhook(
    state: &AppState,
    alias: &str,
    linq: &Arc<LinqChannel>,
    signing_secret: Option<&str>,
    headers: HeaderMap,
    body: Bytes,
) -> (StatusCode, Json<serde_json::Value>) {
    let verified = match webhook_ingress::authenticate(
        &webhook_ingress::LINQ_WEBHOOK,
        alias,
        signing_secret,
        &headers,
        body,
        |secret, headers, body| {
            let body_str = String::from_utf8_lossy(body);
            let timestamp = headers
                .get("X-Webhook-Timestamp")
                .and_then(|v| v.to_str().ok())
                .unwrap_or("");
            let signature = headers
                .get("X-Webhook-Signature")
                .and_then(|v| v.to_str().ok())
                .unwrap_or("");
            zeroclaw_channels::linq::verify_linq_signature(secret, &body_str, timestamp, signature)
        },
    ) {
        Ok(verified) => verified,
        Err(refusal) => return refusal.into_response(&webhook_ingress::LINQ_WEBHOOK),
    };

    let verified = match verified.parse_messages(|body| {
        let payload = serde_json::from_slice::<serde_json::Value>(body).map_err(|_| {
            (
                StatusCode::BAD_REQUEST,
                Json(serde_json::json!({"error": "Invalid JSON payload"})),
            )
        })?;
        Ok::<_, (StatusCode, Json<serde_json::Value>)>(linq.parse_webhook_payload(&payload))
    }) {
        Ok(verified) => verified,
        Err(response) => return response,
    };

    if verified.is_empty() {
        // Acknowledge status/delivery events before ownership resolution.
        return (StatusCode::OK, Json(serde_json::json!({"status": "ok"})));
    }

    let channel_ref = linq_channel_ref(alias);
    let (agent_override, has_channel_bindings) = {
        let config = state.config.read();
        (
            config.agent_for_channel(&channel_ref).map(str::to_owned),
            config
                .agents
                .values()
                .any(|agent| !agent.channels.is_empty()),
        )
    };
    if agent_override.is_none() && has_channel_bindings {
        ::zeroclaw_log::record!(
            WARN,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Reject)
                .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                .with_attrs(::serde_json::json!({"channel": "linq", "alias": alias})),
            "Linq webhook ignored because no enabled agent owns the channel alias"
        );
        return (
            StatusCode::OK,
            Json(serde_json::json!({"status": "ignored", "reason": "no_agent_for_channel"})),
        );
    }

    let channel: Arc<dyn Channel> = linq.clone();
    webhook_ingress::dispatch_verified_webhook(
        state,
        verified,
        webhook_ingress::WebhookDispatchContext {
            channel,
            memory_key: linq_memory_key,
            agent_override,
            mode: webhook_ingress::WebhookDispatchMode::Synchronous,
            #[cfg(test)]
            suppress_reply_send: true,
        },
    )
    .await
}

/// POST /nextcloud-talk — incoming message webhook (bare path, deprecated).
#[cfg(feature = "channel-nextcloud")]
async fn handle_nextcloud_talk_webhook(
    State(state): State<AppState>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    handle_nextcloud_talk_webhook_impl(state, None, headers, body).await
}

/// POST /nextcloud-talk/{alias} — incoming message webhook for one instance.
#[cfg(feature = "channel-nextcloud")]
async fn handle_nextcloud_talk_webhook_alias(
    State(state): State<AppState>,
    Path(alias): Path<String>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    handle_nextcloud_talk_webhook_impl(state, Some(alias), headers, body).await
}

#[cfg(feature = "channel-nextcloud")]
async fn handle_nextcloud_talk_webhook_impl(
    state: AppState,
    alias: Option<String>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    let resolved = api_webhook::resolve(&state.nextcloud_talk, alias.as_deref());
    let Some((alias_key, nextcloud_talk)) = resolved.entry() else {
        return api_webhook::not_found("nextcloud-talk");
    };
    let webhook_secret = state.nextcloud_talk_webhook_secret.get(alias_key).cloned();
    let resp = process_nextcloud_talk_webhook(
        &state,
        alias_key,
        nextcloud_talk,
        webhook_secret.as_deref(),
        headers,
        body,
    )
    .await;
    api_webhook::tag_deprecation(resp.into_response(), resolved, "nextcloud-talk")
}

/// Verify, parse, and dispatch a Nextcloud Talk webhook payload for one resolved
/// instance. `webhook_secret` is that instance's HMAC signing secret.
#[cfg(feature = "channel-nextcloud")]
async fn process_nextcloud_talk_webhook(
    state: &AppState,
    alias: &str,
    nextcloud_talk: &Arc<NextcloudTalkChannel>,
    webhook_secret: Option<&str>,
    headers: HeaderMap,
    body: Bytes,
) -> (StatusCode, Json<serde_json::Value>) {
    let verified = match webhook_ingress::authenticate(
        &webhook_ingress::NEXTCLOUD_TALK_WEBHOOK,
        alias,
        webhook_secret,
        &headers,
        body,
        |secret, headers, body| {
            let body_str = String::from_utf8_lossy(body);
            let random = headers
                .get("X-Nextcloud-Talk-Random")
                .and_then(|v| v.to_str().ok())
                .unwrap_or("");
            let signature = headers
                .get("X-Nextcloud-Talk-Signature")
                .and_then(|v| v.to_str().ok())
                .unwrap_or("");
            zeroclaw_channels::nextcloud_talk::verify_nextcloud_talk_signature(
                secret, random, &body_str, signature,
            )
        },
    ) {
        Ok(verified) => verified,
        Err(refusal) => return refusal.into_response(&webhook_ingress::NEXTCLOUD_TALK_WEBHOOK),
    };

    let verified = match verified.parse_messages(|body| {
        let payload = serde_json::from_slice::<serde_json::Value>(body).map_err(|_| {
            (
                StatusCode::BAD_REQUEST,
                Json(serde_json::json!({"error": "Invalid JSON payload"})),
            )
        })?;
        Ok::<_, (StatusCode, Json<serde_json::Value>)>(
            nextcloud_talk.parse_webhook_payload(&payload),
        )
    }) {
        Ok(verified) => verified,
        Err(response) => return response,
    };

    // Fast-ack: Nextcloud Talk cancels webhook requests that don't complete
    // within ~5s and slow local models routinely exceed that, so processing
    // happens in background tasks and the 200 returns immediately.
    let channel: Arc<dyn Channel> = nextcloud_talk.clone();
    webhook_ingress::dispatch_verified_webhook(
        state,
        verified,
        webhook_ingress::WebhookDispatchContext {
            channel,
            memory_key: nextcloud_talk_memory_key,
            agent_override: None,
            mode: webhook_ingress::WebhookDispatchMode::FastAck,
            #[cfg(test)]
            suppress_reply_send: true,
        },
    )
    .await
}

/// Maximum request body size for the Gmail webhook endpoint (1 MB).
/// Google Pub/Sub messages are typically under 10 KB.
#[cfg(feature = "channel-email")]
const GMAIL_WEBHOOK_MAX_BODY: usize = 1024 * 1024;

/// Compare the presented Gmail push bearer against the configured secret in
/// constant time, so a wrong token's rejection latency does not reveal how
/// many leading bytes matched.
#[cfg(feature = "channel-email")]
fn gmail_bearer_matches(provided: &str, secret: &str) -> bool {
    zeroclaw_config::pairing::constant_time_eq(provided, secret)
}

/// POST /webhook/gmail — incoming Gmail Pub/Sub push notification
#[cfg(feature = "channel-email")]
async fn handle_gmail_push_webhook(
    State(state): State<AppState>,
    headers: HeaderMap,
    body: Bytes,
) -> impl IntoResponse {
    let Some(ref gmail_push) = state.gmail_push else {
        return (
            StatusCode::NOT_FOUND,
            Json(serde_json::json!({"error": "Gmail push not configured"})),
        );
    };

    // Enforce body size limit.
    if body.len() > GMAIL_WEBHOOK_MAX_BODY {
        return (
            StatusCode::PAYLOAD_TOO_LARGE,
            Json(serde_json::json!({"error": "Request body too large"})),
        );
    }

    // Authenticate the webhook request using a shared secret.
    let secret = gmail_push.config.webhook_secret.clone();
    if !secret.is_empty() {
        let provided = headers
            .get(axum::http::header::AUTHORIZATION)
            .and_then(|v| v.to_str().ok())
            .and_then(|auth| auth.strip_prefix("Bearer "))
            .unwrap_or("");

        if !gmail_bearer_matches(provided, &secret) {
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(::serde_json::json!({"channel": "gmail_push"})),
                "webhook: unauthorized request"
            );
            return (
                StatusCode::UNAUTHORIZED,
                Json(serde_json::json!({"error": "Unauthorized"})),
            );
        }
    }

    let body_str = String::from_utf8_lossy(&body);
    let envelope: zeroclaw_channels::gmail_push::PubSubEnvelope =
        match serde_json::from_str(&body_str) {
            Ok(e) => e,
            Err(e) => {
                ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                    .with_attrs(
                        ::serde_json::json!({"error": format!("{}", e), "channel": "gmail_push"})
                    ),
                "webhook: invalid payload"
            );
                return (
                    StatusCode::BAD_REQUEST,
                    Json(serde_json::json!({"error": "Invalid Pub/Sub envelope"})),
                );
            }
        };

    // Process the notification asynchronously (non-blocking for the webhook response)
    let channel = Arc::clone(gmail_push);
    zeroclaw_spawn::spawn!(async move {
        if let Err(e) = channel.handle_notification(&envelope).await {
            ::zeroclaw_log::record!(
                ERROR,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                    .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                    .with_attrs(
                        ::serde_json::json!({"channel": "gmail_push", "error": format!("{}", e)})
                    ),
                "push notification processing failed"
            );
        }
    });

    // Acknowledge immediately — Google Pub/Sub requires a 2xx within ~10s
    (StatusCode::OK, Json(serde_json::json!({"status": "ok"})))
}

// ══════════════════════════════════════════════════════════════════════════════
// ADMIN HANDLERS (for CLI management)
// ══════════════════════════════════════════════════════════════════════════════

/// Response for admin endpoints
#[derive(serde::Serialize)]
struct AdminResponse {
    success: bool,
    message: String,
}

/// Reject requests that do not originate from a loopback address.
fn require_localhost(peer: &SocketAddr) -> Result<(), (StatusCode, Json<serde_json::Value>)> {
    if peer.ip().is_loopback() {
        Ok(())
    } else {
        Err((
            StatusCode::FORBIDDEN,
            Json(serde_json::json!({
                "error": "Admin endpoints are restricted to localhost"
            })),
        ))
    }
}

/// Reject a pairing-code admin request that does not present this run's admin
/// secret. [`require_localhost`] alone is not enough for these routes: a reverse
/// proxy or tunnel on the same host relays remote callers from loopback, and
/// a code read or minted here is exchanged at `/pair` for a shared-operator
/// bearer. The secret reaches local clients through an owner-only file, so
/// presenting it proves the caller runs as the gateway's user on its host.
/// Admission compares against the token the pairing guard holds for this
/// run, never the file, so a stale file or a failed rotation matches nothing.
fn require_gateway_admin_token(
    state: &AppState,
    headers: &HeaderMap,
) -> Result<(), (StatusCode, Json<serde_json::Value>)> {
    let presented = headers
        .get(GATEWAY_ADMIN_TOKEN_HEADER)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");
    if state.pairing.admin_token_matches(presented) {
        Ok(())
    } else {
        Err((
            StatusCode::FORBIDDEN,
            Json(serde_json::json!({
                "error": "Pairing-code admin requests need this gateway's admin token. \
                          Run `zeroclaw gateway get-paircode` on the gateway host, as the \
                          user that runs the gateway."
            })),
        ))
    }
}

/// POST /admin/shutdown — graceful shutdown from CLI (localhost only)
async fn handle_admin_shutdown(
    State(state): State<AppState>,
    ConnectInfo(peer): ConnectInfo<SocketAddr>,
) -> Result<impl IntoResponse, (StatusCode, Json<serde_json::Value>)> {
    require_localhost(&peer)?;
    ::zeroclaw_log::record!(
        INFO,
        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
        "admin shutdown request received; initiating graceful shutdown"
    );

    let body = AdminResponse {
        success: true,
        message: "Gateway shutdown initiated".to_string(),
    };

    let _ = state.shutdown_tx.send(true);

    Ok((StatusCode::OK, Json(body)))
}

/// Authorization decision for `POST /admin/reload`, derived purely from the
/// caller's loopback status, the `gateway.allow_remote_admin` flag, and
/// whether pairing is enabled.
#[derive(Debug, PartialEq, Eq)]
enum AdminReloadGate {
    /// Loopback caller (the CLI) — allow without further checks.
    Allow,
    /// Non-loopback caller, opted in with pairing on — allow only if pairing
    /// auth passes.
    RequireAuth,
    /// Non-loopback caller, not opted in — reject.
    Forbidden,
    /// Non-loopback caller opted in, but pairing is disabled — reject rather
    /// than allow an unauthenticated remote reload. `require_auth` is a no-op
    /// when pairing is off, so without this guard `allow_remote_admin` would
    /// expose reload to anonymous remote callers.
    ForbiddenNoPairing,
}

fn admin_reload_gate(
    is_loopback: bool,
    allow_remote_admin: bool,
    require_pairing: bool,
) -> AdminReloadGate {
    if is_loopback {
        AdminReloadGate::Allow
    } else if !allow_remote_admin {
        AdminReloadGate::Forbidden
    } else if require_pairing {
        AdminReloadGate::RequireAuth
    } else {
        AdminReloadGate::ForbiddenNoPairing
    }
}

async fn handle_admin_reload(
    State(state): State<AppState>,
    ConnectInfo(peer): ConnectInfo<SocketAddr>,
    headers: HeaderMap,
) -> Result<impl IntoResponse, (StatusCode, Json<serde_json::Value>)> {
    // Loopback (the CLI) is always allowed. A non-loopback caller is rejected
    // unless the operator opted in via `gateway.allow_remote_admin`, and even
    // then must pass pairing auth — which requires pairing to be enabled, so
    // opting in without pairing is rejected rather than left unauthenticated.
    let allow_remote = state.config.read().gateway.allow_remote_admin;
    // Source pairing status from the guard `require_auth` consults, not the
    // raw config field, so the gate's `RequireAuth` decision can never
    // diverge from what `require_auth` will actually enforce.
    let require_pairing = state.pairing.require_pairing();
    match admin_reload_gate(peer.ip().is_loopback(), allow_remote, require_pairing) {
        AdminReloadGate::Allow => {}
        AdminReloadGate::RequireAuth => api::require_auth(&state, &headers)?,
        AdminReloadGate::Forbidden => {
            return Err((
                StatusCode::FORBIDDEN,
                Json(serde_json::json!({
                    "error": "Remote admin reload is disabled. Call from localhost, \
                              or set gateway.allow_remote_admin = true (with pairing \
                              enabled, then pair) to allow authenticated remote reloads."
                })),
            ));
        }
        AdminReloadGate::ForbiddenNoPairing => {
            return Err((
                StatusCode::FORBIDDEN,
                Json(serde_json::json!({
                    "error": "Remote admin reload requires pairing. \
                              gateway.allow_remote_admin is enabled but \
                              gateway.require_pairing is off, so remote callers \
                              cannot be authenticated. Enable require_pairing, or \
                              call /admin/reload from localhost."
                })),
            ));
        }
    }

    let Some(reload_tx) = state.reload_tx.clone() else {
        return Err((
            StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({
                "error": "no daemon supervisor — running as standalone gateway. \
                          Restart the process to pick up config changes."
            })),
        ));
    };

    ::zeroclaw_log::record!(
        INFO,
        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
        "admin reload request received"
    );
    // Clear the pending-reload flag before the daemon supervisor brings up
    // the new gateway instance. The fresh instance starts with the flag
    // already false, matching its "subsystems just-loaded, no pending
    // changes" state.
    state
        .pending_reload
        .store(false, std::sync::atomic::Ordering::Relaxed);
    let shutdown_tx = state.shutdown_tx.clone();
    // Brief delay so the HTTP response flushes before tear-down begins.
    zeroclaw_spawn::spawn!(async move {
        tokio::time::sleep(std::time::Duration::from_millis(200)).await;
        // Drain axum first so the listener releases.
        let _ = shutdown_tx.send(true);
        // Then signal the daemon to re-read disk and re-spawn subsystems.
        let _ = reload_tx.send(true);
    });

    Ok((
        StatusCode::OK,
        Json(AdminResponse {
            success: true,
            message: "Daemon reload initiated".to_string(),
        }),
    ))
}

/// GET /admin/paircode — fetch current pairing code (localhost only, and only
/// with this run's admin token)
async fn handle_admin_paircode(
    State(state): State<AppState>,
    ConnectInfo(peer): ConnectInfo<SocketAddr>,
    headers: HeaderMap,
) -> Result<impl IntoResponse, (StatusCode, Json<serde_json::Value>)> {
    require_localhost(&peer)?;
    require_gateway_admin_token(&state, &headers)?;
    let code = state.pairing.pairing_code();

    let body = if let Some(c) = code {
        serde_json::json!({
            "success": true,
            "pairing_required": state.pairing.require_pairing(),
            "pairing_code": c,
            "message": "Use this one-time code to pair"
        })
    } else {
        serde_json::json!({
            "success": true,
            "pairing_required": state.pairing.require_pairing(),
            "pairing_code": null,
            "message": if state.pairing.require_pairing() {
                "Pairing is active but no new code available (already paired or code expired)"
            } else {
                "Pairing is disabled for this gateway"
            }
        })
    };

    Ok((StatusCode::OK, Json(body)))
}

/// The pairing-code policy as configured *right now*.
///
/// `AppState.pairing` outlives every config write (`persist_and_swap` at
/// `api_config.rs` replaces the whole `Config`), so the guard deliberately
/// stores no policy. Resolving it here, per mint, is what makes a
/// strengthened `[gateway.pairing_code]` take effect on the next code
/// instead of at the next restart.
pub(crate) fn live_pairing_code_policy(state: &AppState) -> PairingCodePolicy {
    state.config.read().gateway.pairing_code
}

/// The admin rotate response when its config commit is refused before
/// anything changed: the daemon generation is closing.
fn admin_revocation_not_admitted(
    error: zeroclaw_runtime::live_config_authority::ConfigCommitError,
) -> (StatusCode, Json<serde_json::Value>) {
    let body = serde_json::json!({
        "success": false,
        "pairing_required": true,
        "pairing_code": null,
        "message": format!("Revocation refused without any change: {error}"),
    });
    (StatusCode::SERVICE_UNAVAILABLE, Json(body))
}

#[derive(Debug, serde::Deserialize, Default)]
pub struct AdminPaircodeQuery {
    #[serde(default)]
    pub rotate: Option<String>,
}

async fn handle_admin_paircode_new(
    State(state): State<AppState>,
    ConnectInfo(peer): ConnectInfo<SocketAddr>,
    headers: HeaderMap,
    Query(params): Query<AdminPaircodeQuery>,
) -> Result<impl IntoResponse, (StatusCode, Json<serde_json::Value>)> {
    require_localhost(&peer)?;
    require_gateway_admin_token(&state, &headers)?;

    if !state.pairing.require_pairing() {
        let body = serde_json::json!({
            "success": false,
            "pairing_required": false,
            "pairing_code": null,
            "message": "Pairing is disabled for this gateway"
        });
        return Ok((StatusCode::BAD_REQUEST, Json(body)));
    }

    let rotate = params
        .rotate
        .as_deref()
        .map(str::trim)
        .filter(|s| !s.is_empty());

    let revocation_message = match rotate {
        Some("all") => {
            // Every live token and every device row go in one step under
            // the lock, so a dropped request leaves neither half behind.
            let ((revoked, cleared), config_write_guard) = match state
                .pairing
                .revoke_under_config_write_lock(state.begin_config_commit(), |pairing| {
                    let revoked = pairing.revoke_all_tokens();
                    let cleared = state
                        .device_registry
                        .as_ref()
                        .map(|registry| registry.clear());
                    (revoked, cleared)
                })
                .await
            {
                Ok(revoked) => revoked,
                Err(e) => return Ok(admin_revocation_not_admitted(e)),
            };
            if let Some(Err(e)) = cleared {
                let body = serde_json::json!({
                    "success": false,
                    "pairing_required": true,
                    "pairing_code": null,
                    "message": format!("Tokens revoked in memory but device registry clear failed: {e}"),
                });
                return Ok((StatusCode::INTERNAL_SERVER_ERROR, Json(body)));
            }
            if let Err(e) = persist_pairing_tokens_under(&state, config_write_guard).await {
                let body = serde_json::json!({
                    "success": false,
                    "pairing_required": true,
                    "pairing_code": null,
                    "message": format!("Tokens revoked in memory but config persist failed: {e}"),
                });
                return Ok((StatusCode::INTERNAL_SERVER_ERROR, Json(body)));
            }
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_attrs(::serde_json::json!({"revoked": revoked})),
                "all paired tokens revoked via admin endpoint"
            );
            Some(format!(
                "Revoked all {revoked} paired token(s) and cleared the device registry."
            ))
        }
        Some(device_id) => {
            let Some(registry) = state.device_registry.as_ref() else {
                let body = serde_json::json!({
                    "success": false,
                    "pairing_required": true,
                    "pairing_code": null,
                    "message": "Device registry is disabled; cannot rotate a single device.",
                });
                return Ok((StatusCode::SERVICE_UNAVAILABLE, Json(body)));
            };
            let config_write_guard = match state.begin_config_commit().await {
                Ok(commit) => commit,
                Err(e) => return Ok(admin_revocation_not_admitted(e)),
            };
            let revoked = api_pairing::revoke_device_credential(
                &state,
                registry,
                device_id,
                &config_write_guard,
                || require_gateway_admin_token(&state, &headers),
            )?;
            match revoked {
                Ok(true) => {}
                Ok(false) => {
                    let body = serde_json::json!({
                        "success": false,
                        "pairing_required": true,
                        "pairing_code": null,
                        "message": format!("Device '{device_id}' not found; nothing revoked."),
                    });
                    return Ok((StatusCode::NOT_FOUND, Json(body)));
                }
                Err(e) => {
                    let body = serde_json::json!({
                        "success": false,
                        "pairing_required": true,
                        "pairing_code": null,
                        "message": format!("Device registry error: {e}"),
                    });
                    return Ok((StatusCode::INTERNAL_SERVER_ERROR, Json(body)));
                }
            }
            if let Err(e) = persist_pairing_tokens_under(&state, config_write_guard).await {
                let body = serde_json::json!({
                    "success": false,
                    "pairing_required": true,
                    "pairing_code": null,
                    "message": format!("Token revoked in memory but config persist failed: {e}"),
                });
                return Ok((StatusCode::INTERNAL_SERVER_ERROR, Json(body)));
            }
            ::zeroclaw_log::record!(
                INFO,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
                "single device token revoked via admin endpoint"
            );
            Some(format!(
                "Revoked the bearer token for device '{device_id}'."
            ))
        }
        None => None,
    };

    let code = state
        .pairing
        .generate_new_pairing_code(live_pairing_code_policy(&state))
        .expect("require_pairing checked above");
    if rotate.is_none() {
        ::zeroclaw_log::record!(
            INFO,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
            "new pairing code generated via admin endpoint"
        );
    }

    let message = match revocation_message {
        Some(revoked) => {
            format!("{revoked} Use this one-time code to re-pair.")
        }
        None => "New pairing code generated — use this one-time code to pair".to_string(),
    };

    let body = serde_json::json!({
        "success": true,
        "pairing_required": true,
        "pairing_code": code,
        "message": message,
    });
    Ok((StatusCode::OK, Json(body)))
}

/// GET /pair/code — whether pairing is required. It never returns the code.
///
/// No HTTP caller can prove it is on this host: a reverse proxy or tunnel on
/// the same host relays remote callers from loopback, with or without
/// forwarding headers, and whoever reads a first-run code can pair as the
/// shared operator. The code reaches operators only through the startup
/// banner in the gateway log and `zeroclaw gateway get-paircode`, which
/// presents the owner-only admin token. `pairing_code` stays in the response,
/// always `null`, so existing dashboard clients fall back to manual entry.
async fn handle_pair_code(State(state): State<AppState>) -> impl IntoResponse {
    let body = serde_json::json!({
        "success": true,
        "pairing_required": state.pairing.require_pairing(),
        "pairing_code": serde_json::Value::Null,
    });

    (StatusCode::OK, Json(body))
}

/// Serializes tests that start `run_gateway`, which binds the process-global
/// pricing config handle, so a test that reads that handle sees its own bind.
#[cfg(test)]
pub(crate) static PRICING_BINDING_TEST_LOCK: tokio::sync::Mutex<()> =
    tokio::sync::Mutex::const_new(());

#[cfg(test)]
mod tests {
    impl AppState {
        /// Install a mutated config as the next publication — the test
        /// stand-in for the raw handle write this state type no longer
        /// exposes. Unsynchronized on purpose: tests that exercise writer
        /// serialization hold real admitted commits instead.
        pub(super) fn publish_test_config(&self, mutate: impl FnOnce(&mut Config)) {
            let mut next = self.config.snapshot();
            mutate(&mut next);
            self.config_authority.publish_for_test(next);
        }
    }

    use super::*;
    use async_trait::async_trait;
    use axum::body::Body;
    use axum::http::{HeaderValue, Request, Uri};
    use axum::response::IntoResponse;
    use http_body_util::BodyExt;
    use parking_lot::Mutex;
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
    use tower::ServiceExt;
    #[cfg(feature = "channel-whatsapp-cloud")]
    use zeroclaw_api::channel::ChannelMessage;
    use zeroclaw_memory::{Memory, MemoryCategory, MemoryEntry};
    use zeroclaw_providers::ModelProvider;
    use zeroclaw_runtime::agent::loop_::{
        mcp_tool_access_policy, register_eager_mcp_tool_if_allowed,
    };

    #[test]
    fn default_agent_alias_picks_smallest_enabled_and_is_deterministic() {
        use zeroclaw_config::schema::AliasedAgentConfig;

        let enabled = || AliasedAgentConfig {
            enabled: true,
            ..AliasedAgentConfig::default()
        };

        // No agents -> no default.
        let mut config = Config::default();
        assert_eq!(default_agent_alias(&config), None);

        // Insertion order is deliberately not alphabetical; `config.agents` is
        // a HashMap whose iteration order is randomized per process. The pick
        // must still be the lexicographically smallest ENABLED alias so the
        // Tools page seeds the same agent on every restart.
        config.agents.insert("zeta".to_string(), enabled());
        config.agents.insert("alpha".to_string(), enabled());
        config.agents.insert("mid".to_string(), enabled());
        assert_eq!(default_agent_alias(&config).as_deref(), Some("alpha"));

        // A smaller-but-disabled alias is skipped (omission is not a grant).
        config.agents.insert(
            "aaa_disabled".to_string(),
            AliasedAgentConfig {
                enabled: false,
                ..AliasedAgentConfig::default()
            },
        );
        assert_eq!(default_agent_alias(&config).as_deref(), Some("alpha"));
    }

    #[test]
    fn gateway_cancel_key_preserves_distinct_session_ids() {
        let dotted = gateway_cancel_key("team.alpha");
        let underscored = gateway_cancel_key("team_alpha");

        assert_eq!(dotted, "gw_team.alpha");
        assert_eq!(underscored, "gw_team_alpha");
        assert_ne!(dotted, underscored);
    }

    /// Generate a random hex secret at runtime to avoid hard-coded cryptographic values.
    fn generate_test_secret() -> String {
        let bytes: [u8; 32] = rand::random();
        hex::encode(bytes)
    }

    struct NamedMcpMockTool(&'static str);
    zeroclaw_api::mock_tool_attribution!(NamedMcpMockTool);
    #[async_trait]
    impl tools::Tool for NamedMcpMockTool {
        fn name(&self) -> &str {
            self.0
        }
        fn description(&self) -> &str {
            "mcp mock"
        }
        fn parameters_schema(&self) -> serde_json::Value {
            serde_json::json!({ "type": "object", "properties": {} })
        }
        async fn execute(&self, _args: serde_json::Value) -> anyhow::Result<tools::ToolResult> {
            Ok(tools::ToolResult {
                success: true,
                output: tools::ToolOutput::default(),
                error: None,
            })
        }
    }

    #[test]
    fn gateway_excluded_tools_drops_denied_mcp_tool() {
        let policy = SecurityPolicy {
            excluded_tools: Some(vec!["aa_mcp__find_items".to_string()]),
            workspace_dir: std::env::temp_dir(),
            ..SecurityPolicy::default()
        };
        let mcp_policy = mcp_tool_access_policy(&policy, None);
        let mut gw_tools: Vec<Box<dyn tools::Tool>> = Vec::new();
        let denied: std::sync::Arc<dyn tools::Tool> =
            std::sync::Arc::new(NamedMcpMockTool("aa_mcp__find_items"));
        let allowed: std::sync::Arc<dyn tools::Tool> =
            std::sync::Arc::new(NamedMcpMockTool("aa_mcp__find_npcs"));
        let registered_denied =
            register_eager_mcp_tool_if_allowed(denied, &mut gw_tools, None, mcp_policy.as_ref());
        let registered_allowed =
            register_eager_mcp_tool_if_allowed(allowed, &mut gw_tools, None, mcp_policy.as_ref());
        assert!(
            !registered_denied,
            "gateway must not register an `excluded_tools`-denied MCP tool"
        );
        assert!(
            registered_allowed,
            "gateway must register a non-denied MCP tool (allowlist auto-admit)"
        );
        let names: Vec<&str> = gw_tools.iter().map(|t| t.name()).collect();
        assert!(
            !names.contains(&"aa_mcp__find_items"),
            "denied MCP tool leaked into the gateway registry; got {names:?}"
        );
        assert!(
            names.contains(&"aa_mcp__find_npcs"),
            "allowed MCP tool missing from the gateway registry; got {names:?}"
        );
    }

    #[test]
    fn security_body_limit_is_64kb() {
        assert_eq!(MAX_BODY_SIZE, 65_536);
    }

    #[test]
    fn security_timeout_default_is_30_seconds() {
        assert_eq!(REQUEST_TIMEOUT_SECS, 30);
    }

    #[test]
    fn gateway_timeout_uses_typed_config_default() {
        let cfg = zeroclaw_config::schema::GatewayConfig::default();
        assert_eq!(gateway_request_timeout_secs(&cfg), 30);
    }

    #[test]
    fn paircode_recovery_command_includes_alternate_port() {
        assert_eq!(
            format_paircode_recovery_command("127.0.0.1", 42617),
            "zeroclaw gateway get-paircode --new --port 42617"
        );
    }

    #[test]
    fn paircode_recovery_command_includes_specific_host_when_needed() {
        // Admin paircode routes are localhost-only, so the recovery hint must
        // not advertise a non-loopback `--host` (the admin guard would 403 it).
        // The CLI is left to fall back to its loopback default.
        assert_eq!(
            format_paircode_recovery_command("192.168.1.20", 42617),
            "zeroclaw gateway get-paircode --new --port 42617"
        );
    }

    #[test]
    fn paircode_recovery_command_uses_loopback_for_nonloopback_host() {
        // a gateway bound to a non-loopback interface must
        // not surface a recovery hint that the localhost-only admin guard rejects.
        let cmd = format_paircode_recovery_command("192.168.1.20", 42617);
        assert!(
            !cmd.contains("192.168.1.20"),
            "recovery command must not advertise the non-loopback bound host: {cmd}"
        );
        assert!(
            !cmd.contains("--host"),
            "recovery command should omit --host so the CLI uses its loopback default: {cmd}"
        );

        let curl = format_paircode_recovery_curl(
            "192.168.1.20",
            42617,
            "",
            std::path::Path::new("/zc/data/gateway-admin.token"),
        );
        assert_eq!(
            curl,
            "curl -s -X POST -H \"x-zeroclaw-admin-token: $(cat '/zc/data/gateway-admin.token')\" http://127.0.0.1:42617/admin/paircode/new",
            "curl fallback must target loopback, not the non-loopback bound host"
        );
        assert!(
            !curl.contains("192.168.1.20"),
            "curl fallback must not advertise the non-loopback bound host: {curl}"
        );

        // Path prefix is still preserved while the host is normalized.
        assert_eq!(
            format_paircode_recovery_curl(
                "192.168.1.20",
                42617,
                "/gw",
                std::path::Path::new("/zc/data/gateway-admin.token")
            ),
            "curl -s -X POST -H \"x-zeroclaw-admin-token: $(cat '/zc/data/gateway-admin.token')\" http://127.0.0.1:42617/gw/admin/paircode/new"
        );
    }

    #[test]
    fn paircode_recovery_curl_targets_running_instance() {
        assert_eq!(
            format_paircode_recovery_curl(
                "127.0.0.1",
                42617,
                "",
                std::path::Path::new("/zc/data/gateway-admin.token")
            ),
            "curl -s -X POST -H \"x-zeroclaw-admin-token: $(cat '/zc/data/gateway-admin.token')\" http://127.0.0.1:42617/admin/paircode/new"
        );
    }

    #[test]
    fn already_paired_notice_states_no_code_was_generated() {
        // the banner must say plainly that NO code exists
        // (already paired), not just "Pairing: ACTIVE" — otherwise the operator
        // hits the dashboard's pairing-code prompt with no code printed
        // anywhere.
        let lines = already_paired_pairing_notice(
            "127.0.0.1",
            3001,
            "",
            std::path::Path::new("/zc/data/gateway-admin.token"),
        );
        let joined = lines.join("\n");
        assert!(
            joined.contains("already paired"),
            "notice must say the gateway is already paired: {joined}"
        );
        assert!(
            joined.contains("no new") && joined.contains("code"),
            "notice must state that no new code was generated: {joined}"
        );
    }

    #[test]
    fn already_paired_notice_includes_recovery_command_and_curl() {
        // The notice is the single source of truth for the on-demand recovery
        // commands; it must reuse the loopback-safe builders so the banner and
        // any future surface never drift from's no-`--host` rule.
        let lines = already_paired_pairing_notice(
            "192.168.1.20",
            3001,
            "/gw",
            std::path::Path::new("/zc/data/gateway-admin.token"),
        );
        let joined = lines.join("\n");
        assert!(
            joined.contains(&format_paircode_recovery_command("192.168.1.20", 3001)),
            "notice must surface the get-paircode recovery command: {joined}"
        );
        assert!(
            joined.contains(&format_paircode_recovery_curl(
                "192.168.1.20",
                3001,
                "/gw",
                std::path::Path::new("/zc/data/gateway-admin.token")
            )),
            "notice must surface the curl fallback (honoring the path prefix): {joined}"
        );
        // never advertise the non-loopback bound host in the hint.
        assert!(
            !joined.contains("192.168.1.20"),
            "notice must not advertise the non-loopback bound host: {joined}"
        );
    }

    #[test]
    fn paircode_recovery_curl_normalizes_unspecified_bind_hosts() {
        assert_eq!(
            format_paircode_recovery_curl(
                "0.0.0.0",
                42617,
                "",
                std::path::Path::new("/zc/data/gateway-admin.token")
            ),
            "curl -s -X POST -H \"x-zeroclaw-admin-token: $(cat '/zc/data/gateway-admin.token')\" http://127.0.0.1:42617/admin/paircode/new"
        );
        assert_eq!(
            format_paircode_recovery_curl(
                "::",
                42617,
                "",
                std::path::Path::new("/zc/data/gateway-admin.token")
            ),
            "curl -s -X POST -H \"x-zeroclaw-admin-token: $(cat '/zc/data/gateway-admin.token')\" http://127.0.0.1:42617/admin/paircode/new"
        );
    }

    #[test]
    fn paircode_recovery_curl_preserves_actual_loopback_hosts() {
        assert_eq!(
            format_paircode_recovery_curl(
                "localhost",
                42617,
                "",
                std::path::Path::new("/zc/data/gateway-admin.token")
            ),
            "curl -s -X POST -H \"x-zeroclaw-admin-token: $(cat '/zc/data/gateway-admin.token')\" http://localhost:42617/admin/paircode/new"
        );
        assert_eq!(
            format_paircode_recovery_curl(
                "::1",
                42617,
                "",
                std::path::Path::new("/zc/data/gateway-admin.token")
            ),
            "curl -s -X POST -H \"x-zeroclaw-admin-token: $(cat '/zc/data/gateway-admin.token')\" http://[::1]:42617/admin/paircode/new"
        );
    }

    #[cfg(unix)]
    #[test]
    fn paircode_recovery_curl_quotes_admin_token_path() {
        let tmp = tempfile::tempdir().unwrap();
        let token_path = tmp.path().join("owner's $(touch escaped).token");
        std::fs::write(&token_path, "synthetic-admin-token").unwrap();
        let command = format_paircode_recovery_curl("127.0.0.1", 42617, "", &token_path);
        // Intercept curl: exercise actual shell parsing and cat without a
        // network call, and verify path contents cannot become shell syntax.
        let output = std::process::Command::new("/bin/sh")
            .arg("-c")
            .arg(format!("curl() {{ printf '%s\\n' \"$@\"; }}; {command}"))
            .current_dir(tmp.path())
            .output()
            .unwrap();
        assert!(output.status.success(), "{:?}", output.stderr);
        let args = String::from_utf8(output.stdout).unwrap();
        assert!(
            args.lines()
                .any(|arg| arg == "x-zeroclaw-admin-token: synthetic-admin-token"),
            "{args}"
        );
        assert!(!tmp.path().join("escaped").exists());
    }

    #[test]
    fn paircode_recovery_curl_preserves_path_prefix() {
        assert_eq!(
            format_paircode_recovery_curl(
                "127.0.0.1",
                42617,
                "/gw",
                std::path::Path::new("/zc/data/gateway-admin.token")
            ),
            "curl -s -X POST -H \"x-zeroclaw-admin-token: $(cat '/zc/data/gateway-admin.token')\" http://127.0.0.1:42617/gw/admin/paircode/new"
        );
    }

    #[tokio::test]
    async fn public_health_omits_component_error_details() {
        let component = format!("health-public-{}", uuid::Uuid::new_v4());
        let sensitive_error = "provider failed: token=not-for-public-health";
        zeroclaw_runtime::health::mark_component_ok(&component);
        zeroclaw_runtime::health::mark_component_error(&component, sensitive_error);

        let tmp = tempfile::TempDir::new().unwrap();
        let response = handle_health(State(admin_paircode_state(&tmp, false, false)))
            .await
            .into_response();
        assert_eq!(response.status(), StatusCode::OK);

        let body = response.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        let public_component = &json["runtime"]["components"][&component];

        assert_eq!(public_component["status"], "error");
        assert!(public_component["updated_at"].is_string());
        assert!(public_component["last_ok"].is_string());
        assert_eq!(public_component["restart_count"], 0);
        assert!(public_component.get("last_error").is_none());
        assert!(!json.to_string().contains(sensitive_error));
        assert_eq!(
            zeroclaw_runtime::health::snapshot().components[&component]
                .last_error
                .as_deref(),
            Some(sensitive_error)
        );
    }

    #[test]
    fn resolve_web_dist_dir_accepts_configured_dist() {
        let temp = tempfile::tempdir().expect("create temp dir");
        let dist_dir = temp.path().join("dist");
        std::fs::create_dir_all(&dist_dir).expect("create dist dir");
        std::fs::write(dist_dir.join("index.html"), "").expect("write index.html");
        let mut config = Config::default();
        config.gateway.web_dist_dir = Some(dist_dir.display().to_string());

        assert_eq!(resolve_web_dist_dir(&config), Some(dist_dir));
    }

    #[test]
    fn resolve_web_dist_dir_rejects_configured_path_without_index() {
        let temp = tempfile::tempdir().expect("create temp dir");
        let mut config = Config::default();
        config.gateway.web_dist_dir = Some(temp.path().display().to_string());

        assert_ne!(
            resolve_web_dist_dir(&config),
            Some(temp.path().to_path_buf())
        );
    }

    #[cfg(unix)]
    #[test]
    fn dashboard_index_rejects_symlink_that_escapes_dashboard_root() {
        use std::os::unix::fs::symlink;

        let root = tempfile::tempdir().expect("create dashboard root");
        let outside = tempfile::tempdir().expect("create outside directory");
        std::fs::write(outside.path().join("index.html"), "outside dashboard")
            .expect("write outside index");
        symlink(
            outside.path().join("index.html"),
            root.path().join("index.html"),
        )
        .expect("link escaping index");

        let mut config = Config::default();
        config.gateway.web_dist_dir = Some(root.path().display().to_string());

        assert!(!has_servable_dashboard_index(root.path()));
        assert_ne!(
            resolve_web_dist_dir(&config),
            Some(root.path().to_path_buf()),
            "the resolver must not report an index the serving layer rejects"
        );
    }

    #[test]
    #[cfg(not(feature = "embedded-web"))]
    fn web_dashboard_availability_uses_filesystem_dist() {
        let temp = tempfile::tempdir().expect("create temp dir");
        let dist_dir = temp.path().join("dist");
        std::fs::create_dir_all(&dist_dir).expect("create dist dir");
        std::fs::write(dist_dir.join("index.html"), "").expect("write index.html");
        let mut config = Config::default();
        config.gateway.web_dist_dir = Some(dist_dir.display().to_string());

        assert_eq!(
            resolve_web_dashboard_availability(&config),
            Some(WebDashboardAvailability::Filesystem(dist_dir))
        );
    }

    #[test]
    #[cfg(feature = "embedded-web")]
    fn web_dashboard_availability_reports_embedded_assets() {
        let config = Config::default();

        assert_eq!(
            resolve_web_dashboard_availability(&config),
            Some(WebDashboardAvailability::Embedded)
        );
    }

    /// Build an AppState wired with a real pairing guard, on-disk config path,
    /// and an optional device registry so the admin paircode handler's
    /// revoke + persist paths can be exercised end to end.
    pub(super) fn admin_paircode_state(
        tmp: &tempfile::TempDir,
        require_pairing: bool,
        with_registry: bool,
    ) -> AppState {
        let data_dir = tmp.path().join("workspace");
        std::fs::create_dir_all(&data_dir).unwrap();
        let config = Config {
            data_dir: data_dir.clone(),
            config_path: tmp.path().join("config.toml"),
            ..Config::default()
        };
        let registry =
            with_registry.then(|| Arc::new(api_pairing::DeviceRegistry::new(&data_dir).unwrap()));
        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(config);
        AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider: Arc::new(MockModelProvider::default()),
            model: "test-model".into(),
            temperature: None,
            mem: Arc::new(MockMemory),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::new(MockMemory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(
                require_pairing,
                &[],
                PairingCodePolicy::default(),
            )),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: registry,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        }
    }

    #[test]
    fn gateway_and_ws_turn_admission_blocks_destructive_alias_work() {
        let temp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&temp, false, false);
        let generation = state.agent_lifecycle.alias_generation("alpha");
        let turn = state
            .reserve_agent_turn_at("alpha", generation)
            .expect("gateway turn is admitted");

        assert!(matches!(
            state.agent_lifecycle.begin_delete("alpha"),
            Err(
                zeroclaw_runtime::live_config_authority::AgentDeleteBlocker::ActiveTurns {
                    count: 1,
                    ..
                }
            )
        ));
        drop(turn);
        assert!(state.agent_lifecycle.begin_delete("alpha").is_ok());
    }

    fn webhook_sop_state(
        tmp: &tempfile::TempDir,
        trigger_path: &str,
    ) -> (AppState, Arc<MockModelProvider>) {
        let mut state = admin_paircode_state(tmp, false, false);
        let provider = Arc::new(MockModelProvider::default());
        state.model_provider = provider.clone();

        let sops_dir = tmp.path().join("sops");
        let sop_dir = sops_dir.join("webhook-test");
        std::fs::create_dir_all(&sop_dir).unwrap();
        std::fs::write(
            sop_dir.join("SOP.toml"),
            format!(
                r#"[sop]
name = "webhook-test"
description = "Gateway webhook fan-in test"
execution_mode = "auto"

[[triggers]]
type = "webhook"
path = "{trigger_path}"
"#,
            ),
        )
        .unwrap();
        std::fs::write(
            sop_dir.join("SOP.md"),
            "## Steps\n\n1. **Handle webhook** — Process the webhook payload.\n",
        )
        .unwrap();

        let mut sop_config = state.config.read().sop.clone();
        sop_config.sops_dir = Some(sops_dir.to_string_lossy().into_owned());
        sop_config.persist_runs = false;
        state.publish_test_config(|c| c.sop = sop_config.clone());
        let data_dir = state.config.read().data_dir.clone();
        let install_root = state.config.read().install_root_dir();
        let (engine, audit) = zeroclaw_runtime::sop::build_sop_engine(
            sop_config,
            &std::collections::HashMap::new(),
            &data_dir,
            &install_root,
            Arc::clone(&state.mem),
            Default::default(),
        );
        state.sop_engine = Some(engine);
        state.sop_audit = Some(audit);
        (state, provider)
    }

    /// Same as [`webhook_sop_state`] but loads two SOPs, each with its own
    /// distinct webhook trigger path — used to prove idempotency keys are
    /// namespaced per SOP path rather than shared across all of `/sop/*`.
    fn webhook_two_sop_state(
        tmp: &tempfile::TempDir,
        path_a: &str,
        path_b: &str,
    ) -> (AppState, Arc<MockModelProvider>) {
        let mut state = admin_paircode_state(tmp, false, false);
        let provider = Arc::new(MockModelProvider::default());
        state.model_provider = provider.clone();

        let sops_dir = tmp.path().join("sops");
        for (name, trigger_path) in [("sop-a", path_a), ("sop-b", path_b)] {
            let sop_dir = sops_dir.join(name);
            std::fs::create_dir_all(&sop_dir).unwrap();
            std::fs::write(
                sop_dir.join("SOP.toml"),
                format!(
                    r#"[sop]
name = "{name}"
description = "Gateway webhook fan-in test"
execution_mode = "auto"

[[triggers]]
type = "webhook"
path = "{trigger_path}"
"#,
                ),
            )
            .unwrap();
            std::fs::write(
                sop_dir.join("SOP.md"),
                "## Steps\n\n1. **Handle webhook** — Process the webhook payload.\n",
            )
            .unwrap();
        }

        let mut sop_config = state.config.read().sop.clone();
        sop_config.sops_dir = Some(sops_dir.to_string_lossy().into_owned());
        sop_config.persist_runs = false;
        state.publish_test_config(|c| c.sop = sop_config.clone());
        let data_dir = state.config.read().data_dir.clone();
        let install_root = state.config.read().install_root_dir();
        let (engine, audit) = zeroclaw_runtime::sop::build_sop_engine(
            sop_config,
            &std::collections::HashMap::new(),
            &data_dir,
            &install_root,
            Arc::clone(&state.mem),
            Default::default(),
        );
        state.sop_engine = Some(engine);
        state.sop_audit = Some(audit);
        (state, provider)
    }

    /// Attach a webhook-secret credential to `state`; returns the plaintext
    /// secret to send back as `X-Webhook-Secret`. Item 2's fail-closed SOP
    /// dispatch policy requires a configured-and-verified credential before
    /// a SOP run can start.
    fn with_webhook_secret(state: AppState) -> (AppState, String) {
        let secret = generate_test_secret();
        state.publish_test_config(|c| c.gateway.webhook_secret = Some(secret.clone()));
        (state, secret)
    }

    fn webhook_secret_header(secret: &str) -> HeaderMap {
        let mut headers = HeaderMap::new();
        headers.insert("X-Webhook-Secret", HeaderValue::from_str(secret).unwrap());
        headers
    }

    fn spa_fallback_state(tmp: &tempfile::TempDir) -> AppState {
        let dist_dir = tmp.path().join("web").join("dist");
        std::fs::create_dir_all(&dist_dir).unwrap();
        std::fs::write(
            dist_dir.join("index.html"),
            r#"<!DOCTYPE html><html><head></head><body>dashboard shell</body></html>"#,
        )
        .unwrap();

        let mut state = admin_paircode_state(tmp, false, false);
        state.web_dist_dir = Some(dist_dir);
        state
    }

    async fn spa_fallback_response(
        path: &'static str,
        state: AppState,
    ) -> axum::response::Response {
        static_files::handle_spa_fallback(State(state), Uri::from_static(path)).await
    }

    async fn static_route_response(
        path: &'static str,
        prefix: Option<&str>,
        state: AppState,
    ) -> axum::response::Response {
        let routes = static_file_routes();
        let app = match prefix {
            Some(prefix) => Router::new().nest(prefix, routes),
            None => routes,
        }
        .with_state(state);

        app.oneshot(Request::builder().uri(path).body(Body::empty()).unwrap())
            .await
            .unwrap()
    }

    /// Pair a device into both the pairing guard and the device registry,
    /// returning the plaintext token so the test can assert it is revoked.
    async fn pair_device(state: &AppState, device_id: &str) -> String {
        let code = state
            .pairing
            .generate_new_pairing_code(live_pairing_code_policy(state))
            .expect("pairing enabled");
        let token = state
            .pairing
            .try_pair(&code, device_id)
            .await
            .unwrap()
            .unwrap();
        state
            .device_registry
            .as_ref()
            .unwrap()
            .register(
                PairingGuard::token_hash(&token),
                api_pairing::DeviceInfo {
                    id: device_id.to_string(),
                    name: None,
                    device_type: None,
                    paired_at: chrono::Utc::now(),
                    last_seen: chrono::Utc::now(),
                    ip_address: None,
                    capabilities: None,
                },
            )
            .expect("test device registry insert");
        token
    }

    #[tokio::test]
    async fn plugin_catalog_rejects_missing_and_invalid_bearer_tokens() {
        let tmp = tempfile::tempdir().unwrap();
        let state = admin_paircode_state(&tmp, true, false);

        let response = api_plugins::list_plugins(State(state.clone()), HeaderMap::new()).await;
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);

        let mut headers = HeaderMap::new();
        headers.insert(
            header::AUTHORIZATION,
            HeaderValue::from_static("Bearer invalid-token"),
        );
        let response = api_plugins::list_plugins(State(state), headers).await;
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    }

    #[tokio::test]
    async fn plugin_catalog_accepts_a_paired_bearer_in_every_gateway_build() {
        let tmp = tempfile::tempdir().unwrap();
        let state = admin_paircode_state(&tmp, true, true);
        let token = pair_device(&state, "plugin-catalog-browser").await;
        let mut headers = HeaderMap::new();
        headers.insert(
            header::AUTHORIZATION,
            HeaderValue::from_str(&format!("Bearer {token}")).unwrap(),
        );

        let response = api_plugins::list_plugins(State(state), headers).await;
        assert_eq!(response.status(), StatusCode::OK);
        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(
            json["wasm_plugins_available"],
            cfg!(feature = "plugins-wasm")
        );
        assert!(json["plugins"].is_array());
        assert!(json["issues"].is_array());
    }

    async fn admin_paircode_response_json(
        result: Result<impl IntoResponse, (StatusCode, Json<serde_json::Value>)>,
    ) -> (StatusCode, serde_json::Value) {
        let response = result.into_response();
        let status = response.status();
        let bytes = response.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        (status, json)
    }

    #[tokio::test]
    async fn admin_paircode_new_without_rotate_keeps_existing_tokens() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, true);
        let token = pair_device(&state, "dev-a").await;

        let (status, json) = admin_paircode_response_json(
            handle_admin_paircode_new(
                State(state.clone()),
                test_connect_info(),
                admin_headers(&state),
                Query(AdminPaircodeQuery::default()),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert!(json["pairing_code"].is_string());
        assert!(
            state.pairing.is_authenticated(&token),
            "add-another-client path must not revoke existing tokens"
        );
    }

    /// Review MAJOR-1: `AppState.pairing` outlives every config write, so it
    /// must not carry a snapshotted pairing-code policy. Strengthening
    /// `[gateway.pairing_code]` through the live config — exactly what
    /// `persist_and_swap` does — must change the *next* code the same guard
    /// instance mints, with no restart and no reconstruction.
    #[tokio::test]
    async fn admin_paircode_new_mints_under_live_policy_after_a_config_swap() {
        use zeroclaw_config::pairing::{PairingCodeCharset, PairingCodePolicy};

        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, true);

        // Boot weak: six numeric digits, the legacy shape.
        let weak = PairingCodePolicy::numeric_compat();
        state.publish_test_config(|c| c.gateway.pairing_code = weak);
        let guard_before = Arc::as_ptr(&state.pairing);

        let (status, json) = admin_paircode_response_json(
            handle_admin_paircode_new(
                State(state.clone()),
                test_connect_info(),
                admin_headers(&state),
                Query(AdminPaircodeQuery::default()),
            )
            .await,
        )
        .await;
        assert_eq!(status, StatusCode::OK);
        let weak_code = json["pairing_code"]
            .as_str()
            .expect("code issued")
            .to_string();
        assert_eq!(weak_code.len(), 6, "weak policy in force at first mint");
        assert!(weak_code.chars().all(|c| c.is_ascii_digit()));

        // Operator strengthens the policy. No restart, no new guard.
        let strong = PairingCodePolicy::new(28, PairingCodeCharset::Unambiguous).unwrap();
        state.publish_test_config(|c| c.gateway.pairing_code = strong);

        let (status, json) = admin_paircode_response_json(
            handle_admin_paircode_new(
                State(state.clone()),
                test_connect_info(),
                admin_headers(&state),
                Query(AdminPaircodeQuery::default()),
            )
            .await,
        )
        .await;
        assert_eq!(status, StatusCode::OK);
        let strong_code = json["pairing_code"].as_str().expect("code issued");

        assert_eq!(
            strong_code.len(),
            28,
            "the strengthened policy must apply to the very next code, got {strong_code}"
        );
        let alphabet = PairingCodeCharset::Unambiguous.alphabet();
        assert!(
            strong_code.bytes().all(|b| alphabet.contains(&b)),
            "code {strong_code} must use the newly configured charset"
        );
        assert_eq!(
            Arc::as_ptr(&state.pairing),
            guard_before,
            "the guard must not have been rebuilt — the policy is resolved per mint"
        );
    }

    #[tokio::test]
    async fn admin_paircode_new_rotate_all_revokes_everything() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, true);
        let token_a = pair_device(&state, "dev-a").await;
        let token_b = pair_device(&state, "dev-b").await;

        let (status, json) = admin_paircode_response_json(
            handle_admin_paircode_new(
                State(state.clone()),
                test_connect_info(),
                admin_headers(&state),
                Query(AdminPaircodeQuery {
                    rotate: Some("all".into()),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert!(json["pairing_code"].is_string());
        assert!(!state.pairing.is_authenticated(&token_a));
        assert!(!state.pairing.is_authenticated(&token_b));
        assert!(
            state.config.read().gateway.paired_tokens.is_empty(),
            "rotate=all must persist an empty token set"
        );
        assert!(
            state
                .device_registry
                .as_ref()
                .unwrap()
                .list()
                .expect("test device registry list")
                .is_empty(),
            "rotate=all must clear the device registry"
        );
    }

    /// The admin rotate paths dropped while they wait for the config write
    /// lock, as the gateway's request timeout drops them, must leave every
    /// device row and token in place, and the retried request revokes them.
    #[tokio::test]
    async fn admin_paircode_rotate_dropped_while_waiting_can_be_retried() {
        for target in ["dev-a", "all"] {
            let tmp = tempfile::TempDir::new().unwrap();
            let state = admin_paircode_state(&tmp, true, true);
            let token_a = pair_device(&state, "dev-a").await;
            let token_b = pair_device(&state, "dev-b").await;
            let listed = |state: &AppState| -> Vec<String> {
                let mut ids: Vec<String> = state
                    .device_registry
                    .as_ref()
                    .unwrap()
                    .list()
                    .expect("test device registry list")
                    .into_iter()
                    .map(|device| device.id)
                    .collect();
                ids.sort();
                ids
            };
            let call = |state: AppState| {
                handle_admin_paircode_new(
                    State(state.clone()),
                    test_connect_info(),
                    admin_headers(&state),
                    Query(AdminPaircodeQuery {
                        rotate: Some(target.into()),
                    }),
                )
            };

            let in_flight = state.config_authority.lock_config_writer().await;
            let mut waiting = Box::pin(call(state.clone()));
            let mut cx = std::task::Context::from_waker(std::task::Waker::noop());
            assert!(
                std::future::Future::poll(waiting.as_mut(), &mut cx).is_pending(),
                "{target}: the rotation must wait for the config write lock"
            );
            drop(waiting);
            drop(in_flight);

            assert_eq!(listed(&state), vec!["dev-a", "dev-b"], "{target}");
            assert!(state.pairing.is_authenticated(&token_a), "{target}");
            assert!(state.pairing.is_authenticated(&token_b), "{target}");

            let (status, _) = admin_paircode_response_json(call(state.clone()).await).await;
            assert_eq!(status, StatusCode::OK, "{target}: the retry");
            assert!(!state.pairing.is_authenticated(&token_a), "{target}");
            if target == "all" {
                assert!(listed(&state).is_empty());
                assert!(!state.pairing.is_authenticated(&token_b));
            } else {
                assert_eq!(listed(&state), vec!["dev-b"]);
                assert!(state.pairing.is_authenticated(&token_b));
            }
        }
    }

    #[tokio::test]
    async fn admin_paircode_new_rotate_device_revokes_one() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, true);
        let token_a = pair_device(&state, "dev-a").await;
        let token_b = pair_device(&state, "dev-b").await;

        let (status, json) = admin_paircode_response_json(
            handle_admin_paircode_new(
                State(state.clone()),
                test_connect_info(),
                admin_headers(&state),
                Query(AdminPaircodeQuery {
                    rotate: Some("dev-a".into()),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert!(json["pairing_code"].is_string());
        assert!(!state.pairing.is_authenticated(&token_a));
        assert!(
            state.pairing.is_authenticated(&token_b),
            "targeted rotate must not touch other devices"
        );
        let old_hash = PairingGuard::token_hash(&token_a);
        assert!(
            !state
                .config
                .read()
                .gateway
                .paired_tokens
                .contains(&old_hash)
        );
    }

    #[tokio::test]
    async fn admin_paircode_new_rotate_unknown_device_is_not_found() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, true);
        let token = pair_device(&state, "dev-a").await;

        let (status, _json) = admin_paircode_response_json(
            handle_admin_paircode_new(
                State(state.clone()),
                test_connect_info(),
                admin_headers(&state),
                Query(AdminPaircodeQuery {
                    rotate: Some("ghost".into()),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::NOT_FOUND);
        assert!(
            state.pairing.is_authenticated(&token),
            "a not-found rotate must not revoke any token"
        );
    }

    #[tokio::test]
    async fn admin_paircode_new_pairing_disabled_is_bad_request() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, false, false);

        let (status, json) = admin_paircode_response_json(
            handle_admin_paircode_new(
                State(state.clone()),
                test_connect_info(),
                admin_headers(&state),
                Query(AdminPaircodeQuery {
                    rotate: Some("all".into()),
                }),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(json["success"], false);
    }

    #[tokio::test]
    async fn admin_paircode_new_rejects_remote_peer() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, true);

        let remote = ConnectInfo(SocketAddr::from(([203, 0, 113, 7], 40_000)));
        let (status, _json) = admin_paircode_response_json(
            handle_admin_paircode_new(
                State(state.clone()),
                remote,
                admin_headers(&state),
                Query(AdminPaircodeQuery::default()),
            )
            .await,
        )
        .await;

        assert_eq!(
            status,
            StatusCode::FORBIDDEN,
            "minting a pairing code must be rejected for non-loopback peers"
        );
    }

    /// Headers carrying this test gateway's admin secret, minted the way a
    /// gateway start mints it.
    fn admin_headers(state: &AppState) -> HeaderMap {
        let data_dir = state.config.read().data_dir.clone();
        let secret = state
            .pairing
            .rotate_admin_token(&data_dir)
            .expect("rotate admin token");
        let mut headers = HeaderMap::new();
        headers.insert(
            GATEWAY_ADMIN_TOKEN_HEADER,
            HeaderValue::from_str(&secret).expect("admin token is a valid header value"),
        );
        headers
    }

    /// Headers a same-host reverse proxy or tunnel produces for a remote
    /// caller. Some proxies add a forwarding header and some add none; the
    /// admin gates must not depend on either.
    fn proxied_headers(with_forwarding_header: bool) -> HeaderMap {
        let mut headers = HeaderMap::new();
        if with_forwarding_header {
            headers.insert("X-Forwarded-For", HeaderValue::from_static("203.0.113.7"));
        }
        headers
    }

    async fn json_of(response: Response) -> (StatusCode, serde_json::Value) {
        let status = response.status();
        let bytes = response.into_body().collect().await.unwrap().to_bytes();
        (status, serde_json::from_slice(&bytes).unwrap())
    }

    async fn pair_with(state: &AppState, code: &str) -> (StatusCode, serde_json::Value) {
        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Pairing-Code",
            HeaderValue::from_str(code).expect("code is a valid header value"),
        );
        json_of(
            handle_pair(State(state.clone()), test_connect_info(), headers)
                .await
                .into_response(),
        )
        .await
    }

    #[tokio::test]
    async fn pair_code_never_returns_the_code_even_to_a_loopback_caller() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, false);
        assert!(
            state.pairing.pairing_code().is_some(),
            "a fresh guard holds a first-run code"
        );

        let (status, json) = json_of(handle_pair_code(State(state)).await.into_response()).await;

        assert_eq!(status, StatusCode::OK);
        assert_eq!(json["pairing_required"], true);
        assert!(
            json["pairing_code"].is_null(),
            "no HTTP caller can prove it is local, so the code is never served: {json}"
        );
    }

    #[tokio::test]
    async fn admin_paircode_refuses_loopback_callers_without_the_admin_token() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, false);
        let _current = admin_headers(&state);

        let mut wrong = HeaderMap::new();
        wrong.insert(
            GATEWAY_ADMIN_TOKEN_HEADER,
            HeaderValue::from_static("zc_wrong"),
        );
        for headers in [proxied_headers(true), proxied_headers(false), wrong] {
            let (status, json) = admin_paircode_response_json(
                handle_admin_paircode(State(state.clone()), test_connect_info(), headers).await,
            )
            .await;
            assert_eq!(status, StatusCode::FORBIDDEN, "{json}");
            assert!(json.get("pairing_code").is_none(), "{json}");
        }
    }

    #[tokio::test]
    async fn admin_paircode_serves_the_code_with_the_admin_token() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, false);
        let expected = state.pairing.pairing_code();

        let (status, json) = admin_paircode_response_json(
            handle_admin_paircode(
                State(state.clone()),
                test_connect_info(),
                admin_headers(&state),
            )
            .await,
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        assert_eq!(json["pairing_code"].as_str(), expected.as_deref());
    }

    #[tokio::test]
    async fn admin_paircode_new_refuses_loopback_callers_without_the_admin_token() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, true);
        let _current = admin_headers(&state);
        let before = state.pairing.pairing_code();

        for headers in [proxied_headers(true), proxied_headers(false)] {
            let (status, _json) = admin_paircode_response_json(
                handle_admin_paircode_new(
                    State(state.clone()),
                    test_connect_info(),
                    headers,
                    Query(AdminPaircodeQuery::default()),
                )
                .await,
            )
            .await;
            assert_eq!(status, StatusCode::FORBIDDEN);
        }
        assert_eq!(
            state.pairing.pairing_code(),
            before,
            "a refused mint must not issue or replace a code"
        );
    }

    #[tokio::test]
    async fn admin_token_from_an_earlier_gateway_start_is_refused() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, false);
        let stale = admin_headers(&state);
        let _restart = admin_headers(&state);

        let (status, _json) = admin_paircode_response_json(
            handle_admin_paircode(State(state), test_connect_info(), stale).await,
        )
        .await;

        assert_eq!(status, StatusCode::FORBIDDEN);
    }

    /// A rotation that cannot write its file must fail closed: the token that
    /// worked before, still sitting in the file, is refused afterwards.
    #[tokio::test]
    async fn failed_admin_token_rotation_refuses_the_token_left_on_disk() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, false);
        let working = admin_headers(&state);
        let data_dir = state.config.read().data_dir.clone();
        let on_disk = std::fs::read_to_string(gateway_admin_token_path(&data_dir)).unwrap();

        let unwritable = tmp.path().join("not-a-dir");
        std::fs::write(&unwritable, b"x").unwrap();
        assert!(state.pairing.rotate_admin_token(&unwritable).is_err());
        assert_eq!(
            std::fs::read_to_string(gateway_admin_token_path(&data_dir)).unwrap(),
            on_disk,
            "the previous token file is still in place"
        );

        let (status, json) = admin_paircode_response_json(
            handle_admin_paircode(State(state), test_connect_info(), working).await,
        )
        .await;
        assert_eq!(status, StatusCode::FORBIDDEN, "{json}");
        assert!(json.get("pairing_code").is_none(), "{json}");
    }

    /// The composed attack from review A1: a remote caller relayed from
    /// loopback by a same-host proxy tries every route that reads or mints a
    /// code, then tries to pair. It must end with no code, no paired token and
    /// no authenticated access. A caller holding the admin token completes the
    /// same sequence, so the admin token is the only thing standing between.
    #[tokio::test]
    async fn proxied_loopback_caller_cannot_reach_operator_access_through_any_code_route() {
        for with_forwarding_header in [true, false] {
            let tmp = tempfile::TempDir::new().unwrap();
            let state = admin_paircode_state(&tmp, true, true);
            let _current = admin_headers(&state);

            let (_, public) =
                json_of(handle_pair_code(State(state.clone())).await.into_response()).await;
            assert!(public["pairing_code"].is_null());

            let (read_status, _) = admin_paircode_response_json(
                handle_admin_paircode(
                    State(state.clone()),
                    test_connect_info(),
                    proxied_headers(with_forwarding_header),
                )
                .await,
            )
            .await;
            assert_eq!(read_status, StatusCode::FORBIDDEN);

            let (mint_status, _) = admin_paircode_response_json(
                handle_admin_paircode_new(
                    State(state.clone()),
                    test_connect_info(),
                    proxied_headers(with_forwarding_header),
                    Query(AdminPaircodeQuery::default()),
                )
                .await,
            )
            .await;
            assert_eq!(mint_status, StatusCode::FORBIDDEN);

            // With no code in hand, a guess cannot pair.
            let (pair_status, _) = pair_with(&state, "000000").await;
            assert_ne!(pair_status, StatusCode::OK);
            assert!(!state.pairing.is_paired(), "no token may have been minted");
            assert!(
                api::require_auth(&state, &HeaderMap::new()).is_err(),
                "the caller must end with no authenticated access"
            );
        }

        // Control: the same sequence with the admin token reaches a bearer.
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, true);
        let (_, minted) = admin_paircode_response_json(
            handle_admin_paircode_new(
                State(state.clone()),
                test_connect_info(),
                admin_headers(&state),
                Query(AdminPaircodeQuery::default()),
            )
            .await,
        )
        .await;
        let code = minted["pairing_code"]
            .as_str()
            .expect("admin mint issues a code");
        let (pair_status, paired) = pair_with(&state, code).await;
        assert_eq!(pair_status, StatusCode::OK, "{paired}");
        let bearer = paired["token"].as_str().expect("pairing returns a bearer");
        let mut auth = HeaderMap::new();
        auth.insert(
            header::AUTHORIZATION,
            HeaderValue::from_str(&format!("Bearer {bearer}")).unwrap(),
        );
        assert!(api::require_auth(&state, &auth).is_ok());
    }

    #[test]
    fn long_running_request_timeout_default_is_ten_minutes() {
        assert_eq!(LONG_RUNNING_REQUEST_TIMEOUT_SECS, 600);
    }

    #[test]
    fn long_running_request_timeout_uses_typed_config_default() {
        let cfg = zeroclaw_config::schema::GatewayConfig::default();
        assert_eq!(gateway_long_running_request_timeout_secs(&cfg), 600);
    }

    #[test]
    fn webhook_body_requires_message_field() {
        let valid = r#"{"message": "hello"}"#;
        let parsed: Result<WebhookBody, _> = serde_json::from_str(valid);
        assert!(parsed.is_ok());
        assert_eq!(parsed.unwrap().message, "hello");

        let missing = r#"{"other": "field"}"#;
        let parsed: Result<WebhookBody, _> = serde_json::from_str(missing);
        assert!(parsed.is_err());
    }

    #[test]
    fn whatsapp_query_fields_are_optional() {
        let q = WhatsAppVerifyQuery {
            mode: None,
            verify_token: None,
            challenge: None,
        };
        assert!(q.mode.is_none());
    }

    #[test]
    fn app_state_is_clone() {
        fn assert_clone<T: Clone>() {}
        assert_clone::<AppState>();
    }

    #[tokio::test]
    async fn static_routes_reject_malformed_paths_before_spa_fallback() {
        let tmp = tempfile::TempDir::new().unwrap();
        let mut prefixed_state = spa_fallback_state(&tmp);
        prefixed_state.path_prefix = "/gw".to_string();

        for (path, prefix, state) in [
            ("/_app/", None, spa_fallback_state(&tmp)),
            ("/_app//index.html", None, spa_fallback_state(&tmp)),
            ("/_app/assets/./app.js", None, spa_fallback_state(&tmp)),
            ("/_app/assets/../secret", None, spa_fallback_state(&tmp)),
            ("/_app/assets/app.js/", None, spa_fallback_state(&tmp)),
            ("/gw/_app/", Some("/gw"), prefixed_state),
        ] {
            let response = static_route_response(path, prefix, state).await;
            assert_eq!(
                response.status(),
                StatusCode::BAD_REQUEST,
                "route path should be rejected: {path}"
            );
        }
    }

    #[tokio::test]
    async fn static_routes_serve_valid_assets_with_and_without_prefix() {
        let tmp = tempfile::TempDir::new().unwrap();
        let dist_dir = tmp.path().join("web").join("dist");
        let assets = dist_dir.join("assets");
        std::fs::create_dir_all(&assets).unwrap();
        std::fs::write(assets.join("route-test.js"), b"route-ok").unwrap();

        let mut state = spa_fallback_state(&tmp);
        let unprefixed =
            static_route_response("/_app/assets/route-test.js", None, state.clone()).await;
        assert_eq!(unprefixed.status(), StatusCode::OK);
        assert_eq!(
            unprefixed.into_body().collect().await.unwrap().to_bytes(),
            &b"route-ok"[..]
        );

        state.path_prefix = "/gw".to_string();
        let prefixed =
            static_route_response("/gw/_app/assets/route-test.js", Some("/gw"), state).await;
        assert_eq!(prefixed.status(), StatusCode::OK);
        assert_eq!(
            prefixed.into_body().collect().await.unwrap().to_bytes(),
            &b"route-ok"[..]
        );
    }

    #[tokio::test]
    async fn spa_fallback_returns_json_not_html_for_unknown_api_path() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = spa_fallback_state(&tmp);

        let response = spa_fallback_response("/api/agents", state).await;

        assert_eq!(response.status(), StatusCode::NOT_FOUND);
        assert!(
            response
                .headers()
                .get(header::CONTENT_TYPE)
                .and_then(|value| value.to_str().ok())
                .is_some_and(|value| value.starts_with("application/json")),
            "unknown API paths must not be served as HTML"
        );

        let body = response.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["error"], "not_found");
        assert_eq!(json["path"], "/api/agents");
    }

    #[tokio::test]
    async fn spa_fallback_returns_json_for_api_root_path() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = spa_fallback_state(&tmp);

        let response = spa_fallback_response("/api", state).await;

        assert_eq!(response.status(), StatusCode::NOT_FOUND);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["path"], "/api");
    }

    #[tokio::test]
    async fn spa_fallback_returns_json_for_path_prefixed_api_miss() {
        let tmp = tempfile::TempDir::new().unwrap();
        let mut state = spa_fallback_state(&tmp);
        state.path_prefix = "/gw".to_string();

        let response = spa_fallback_response("/gw/api/agents", state).await;

        assert_eq!(response.status(), StatusCode::NOT_FOUND);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["path"], "/api/agents");
    }

    #[tokio::test]
    async fn spa_fallback_still_serves_dashboard_routes() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = spa_fallback_state(&tmp);

        let response = spa_fallback_response("/config", state).await;

        assert_eq!(response.status(), StatusCode::OK);
        assert!(
            response
                .headers()
                .get(header::CONTENT_TYPE)
                .and_then(|value| value.to_str().ok())
                .is_some_and(|value| value.starts_with("text/html")),
            "dashboard routes should still receive the SPA shell"
        );

        let body = response.into_body().collect().await.unwrap().to_bytes();
        let text = String::from_utf8(body.to_vec()).unwrap();
        assert!(text.contains("dashboard shell"));
    }

    #[cfg(not(feature = "embedded-web"))]
    #[tokio::test]
    async fn spa_fallback_reports_unavailable_without_dashboard_assets() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, false, false);

        let response = spa_fallback_response("/", state).await;

        assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    }

    #[tokio::test]
    async fn spa_fallback_does_not_treat_api_like_spa_paths_as_api() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = spa_fallback_state(&tmp);

        let response = spa_fallback_response("/apiary", state).await;

        assert_eq!(response.status(), StatusCode::OK);
        assert!(
            response
                .headers()
                .get(header::CONTENT_TYPE)
                .and_then(|value| value.to_str().ok())
                .is_some_and(|value| value.starts_with("text/html")),
            "similarly named SPA routes should not be reserved as API paths"
        );
    }

    #[tokio::test]
    async fn run_gateway_starts_with_zero_agents() {
        // `run_gateway` binds the process-global pricing config handle.
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        // Isolate data_dir so parallel nextest runs don't race on the
        // real ~/.zeroclaw/data
        let tmp = tempfile::TempDir::new().unwrap();
        let config = zeroclaw_config::schema::Config {
            data_dir: tmp.path().join("workspace"),
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();

        // Default Config has no [agents.*] entries — the exact shape
        // a fresh install presents on first daemon boot.
        assert!(
            config.agents.is_empty(),
            "regression assumes default Config has no agents",
        );

        let handle = zeroclaw_spawn::spawn!(async move {
            run_gateway(
                "127.0.0.1",
                0,
                config,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
            )
            .await
        });

        match tokio::time::timeout(
            std::time::Duration::from_millis(750),
            &mut Box::pin(async {
                // We cannot await `handle` directly because the gateway
                // never returns under normal operation; instead, peek at
                // whether it has finished by polling join with a tiny
                // budget.
                let _ = tokio::time::sleep(std::time::Duration::from_millis(500)).await;
            }),
        )
        .await
        {
            Ok(()) => {}
            Err(_) => panic!("test setup timed out before checking gateway state"),
        }

        // If the boot path errored, the task is finished and join
        // returns the error. If it's still running, abort and accept
        // boot reached the serving stage.
        if handle.is_finished() {
            let result = handle.await.expect("task did not panic");
            panic!(
                "gateway exited during boot with zero agents — must stay up for reload/quickstart: {:?}",
                result
            );
        }
        handle.abort();
    }

    #[tokio::test]
    async fn run_gateway_starts_with_unresolved_agent_risk_profile() {
        // `run_gateway` binds the process-global pricing config handle.
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        use zeroclaw_config::schema::AliasedAgentConfig;

        // Isolate data_dir so parallel nextest runs don't race on the
        // real ~/.zeroclaw/data
        let tmp = tempfile::TempDir::new().unwrap();
        let mut config = zeroclaw_config::schema::Config {
            data_dir: tmp.path().join("workspace"),
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();

        // Enabled agent whose `risk_profile` does not resolve. No
        // matching [risk_profiles.<key>] entry exists.
        let agent = AliasedAgentConfig {
            enabled: true,
            risk_profile: "definitely_not_configured".into(),
            ..AliasedAgentConfig::default()
        };
        config.agents.insert("fake123".to_string(), agent);

        let handle = zeroclaw_spawn::spawn!(async move {
            run_gateway(
                "127.0.0.1",
                0,
                config,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
            )
            .await
        });

        match tokio::time::timeout(
            std::time::Duration::from_millis(750),
            &mut Box::pin(async {
                let _ = tokio::time::sleep(std::time::Duration::from_millis(500)).await;
            }),
        )
        .await
        {
            Ok(()) => {}
            Err(_) => panic!("test setup timed out before checking gateway state"),
        }

        if handle.is_finished() {
            let result = handle.await.expect("task did not panic");
            panic!(
                "gateway exited during boot when agent.risk_profile was unresolved \
                 — must stay up so operator can fix via /admin/reload or /quickstart: {:?}",
                result
            );
        }
        handle.abort();
    }

    #[cfg(target_os = "macos")]
    #[tokio::test]
    async fn run_gateway_isolates_failed_seatbelt_tool_listings() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        use zeroclaw_config::schema::{AliasedAgentConfig, RiskProfileConfig};

        if !std::path::Path::new("/usr/bin/sandbox-exec").is_file() {
            return;
        }
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        for failed_default in [true, false] {
            let tmp = tempfile::TempDir::new().unwrap();
            let cycle = tmp.path().join("cycle");
            std::os::unix::fs::symlink("cycle", &cycle).unwrap();
            let mut config = Config {
                data_dir: tmp.path().join("data"),
                config_path: tmp.path().join("config.toml"),
                ..Config::default()
            };
            std::fs::create_dir_all(&config.data_dir).unwrap();
            config.gateway.require_pairing = false;
            config.memory.backend = "none".into();
            config.risk_profiles.insert(
                "healthy".into(),
                RiskProfileConfig {
                    sandbox_enabled: Some(true),
                    sandbox_backend: Some("sandbox-exec".into()),
                    ..RiskProfileConfig::default()
                },
            );
            let mut failed_profile = config.risk_profiles["healthy"].clone();
            failed_profile.allowed_roots = vec![cycle.display().to_string()];
            config.risk_profiles.insert("failed".into(), failed_profile);
            let (failed_alias, healthy_alias) = if failed_default {
                ("a-failed", "z-healthy")
            } else {
                ("z-failed", "a-healthy")
            };
            for (alias, profile) in [(failed_alias, "failed"), (healthy_alias, "healthy")] {
                config.agents.insert(
                    alias.into(),
                    AliasedAgentConfig {
                        enabled: true,
                        risk_profile: profile.into(),
                        ..AliasedAgentConfig::default()
                    },
                );
            }
            assert_eq!(
                default_agent_alias(&config).as_deref(),
                Some(if failed_default {
                    failed_alias
                } else {
                    healthy_alias
                })
            );

            let (ready_tx, mut ready_rx) = tokio::sync::watch::channel(None);
            let readiness = zeroclaw_runtime::daemon::GatewayReadinessReporter::new(move |addr| {
                let _ = ready_tx.send(Some(addr));
            });
            let (shutdown_tx, _) = tokio::sync::watch::channel(false);
            let (reload_tx, _) = tokio::sync::watch::channel(false);
            let controls = zeroclaw_runtime::daemon::GatewayReloadControls::standalone(
                shutdown_tx.clone(),
                reload_tx,
            );
            let server = zeroclaw_spawn::spawn!(async move {
                run_gateway(
                    "127.0.0.1",
                    0,
                    config,
                    None,
                    Some(controls),
                    None,
                    None,
                    None,
                    None,
                    None,
                    None,
                    Some(readiness),
                )
                .await
            });
            tokio::time::timeout(std::time::Duration::from_secs(10), async {
                ready_rx.wait_for(Option::is_some).await.unwrap();
            })
            .await
            .expect("failed listing must not prevent gateway readiness");
            let addr = ready_rx.borrow().unwrap();
            let get = |path: String| async move {
                tokio::time::timeout(std::time::Duration::from_secs(5), async {
                    let mut stream = tokio::net::TcpStream::connect(addr).await.unwrap();
                    let request =
                        format!("GET {path} HTTP/1.1\r\nHost: {addr}\r\nConnection: close\r\n\r\n");
                    stream.write_all(request.as_bytes()).await.unwrap();
                    let mut response = String::new();
                    stream.read_to_string(&mut response).await.unwrap();
                    assert!(response.starts_with("HTTP/1.1 200"), "{path}: {response}");
                    let (_, body) = response.split_once("\r\n\r\n").unwrap();
                    serde_json::from_str::<serde_json::Value>(body).unwrap()
                })
                .await
                .expect("gateway must serve the HTTP response")
            };
            get("/health".into()).await;
            get("/api/config".into()).await;
            let failed = get(format!("/api/tools?agent={failed_alias}")).await;
            assert_eq!(failed["tools"], serde_json::json!([]));
            let healthy = get(format!("/api/tools?agent={healthy_alias}")).await;
            assert!(
                healthy["tools"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .any(|tool| tool["name"] == "shell")
            );
            let default = get("/api/tools".into()).await;
            assert_eq!(
                default["tools"],
                if failed_default {
                    failed["tools"].clone()
                } else {
                    healthy["tools"].clone()
                }
            );

            shutdown_tx.send(true).unwrap();
            tokio::time::timeout(std::time::Duration::from_secs(5), server)
                .await
                .expect("gateway should shut down")
                .expect("gateway task should not panic")
                .expect("gateway shutdown should succeed");
        }
    }

    /// A gateway generation for the connection-drain tests: pairing off, on
    /// `port` (0 for any), over TLS when `tls` names a certificate and key.
    async fn start_drain_test_gateway(
        data: &std::path::Path,
        port: u16,
        tls: Option<(&std::path::Path, &std::path::Path)>,
    ) -> (
        SocketAddr,
        tokio::sync::watch::Sender<bool>,
        tokio::task::JoinHandle<Result<()>>,
    ) {
        start_drain_test_gateway_with(data, port, tls, None).await
    }

    async fn start_drain_test_gateway_with(
        data: &std::path::Path,
        port: u16,
        tls: Option<(&std::path::Path, &std::path::Path)>,
        event_bus: Option<zeroclaw_runtime::observability::EventBus>,
    ) -> (
        std::net::SocketAddr,
        tokio::sync::watch::Sender<bool>,
        tokio::task::JoinHandle<Result<()>>,
    ) {
        start_drain_test_gateway_with_release(data, port, tls, event_bus, None).await
    }

    async fn start_drain_test_gateway_with_release(
        data: &std::path::Path,
        port: u16,
        tls: Option<(&std::path::Path, &std::path::Path)>,
        event_bus: Option<zeroclaw_runtime::observability::EventBus>,
        released: Option<tokio::sync::oneshot::Sender<()>>,
    ) -> (
        SocketAddr,
        tokio::sync::watch::Sender<bool>,
        tokio::task::JoinHandle<Result<()>>,
    ) {
        let mut config = Config {
            data_dir: data.join("data"),
            config_path: data.join("config.toml"),
            ..Config::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        config.gateway.require_pairing = false;
        config.memory.backend = "none".into();
        if let Some((cert_path, key_path)) = tls {
            // The process's rustls provider, as `main.rs` installs it: with both
            // ring and aws-lc-rs compiled in (a workspace build), rustls picks none.
            let _ = rustls::crypto::ring::default_provider().install_default();
            config.gateway.tls = Some(zeroclaw_config::schema::GatewayTlsConfig {
                enabled: true,
                cert_path: cert_path.display().to_string(),
                key_path: key_path.display().to_string(),
                ..Default::default()
            });
        }
        let (ready_tx, mut ready_rx) = tokio::sync::watch::channel(None);
        let readiness = zeroclaw_runtime::daemon::GatewayReadinessReporter::new(move |addr| {
            let _ = ready_tx.send(Some(addr));
        });
        let (shutdown_tx, _) = tokio::sync::watch::channel(false);
        let (reload_tx, _) = tokio::sync::watch::channel(false);
        let controls = zeroclaw_runtime::daemon::GatewayReloadControls::standalone(
            shutdown_tx.clone(),
            reload_tx,
        );
        let server = zeroclaw_spawn::spawn!(async move {
            LISTENER_RELEASED
                .scope(std::cell::RefCell::new(released), async move {
                    run_gateway(
                        "127.0.0.1",
                        port,
                        config,
                        event_bus,
                        Some(controls),
                        None,
                        None,
                        None,
                        None,
                        None,
                        None,
                        Some(readiness),
                    )
                    .await
                })
                .await
        });
        tokio::time::timeout(std::time::Duration::from_secs(10), async {
            ready_rx.wait_for(Option::is_some).await.unwrap();
        })
        .await
        .expect("the gateway becomes ready");
        let addr = ready_rx.borrow().unwrap();
        (addr, shutdown_tx, server)
    }

    /// Send one HTTP/1.1 request on `stream`, which stays open, and return
    /// what the first read brings back (enough for a status line).
    async fn drain_test_request<S>(stream: &mut S, path: &str) -> String
    where
        S: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin,
    {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        stream
            .write_all(format!("GET {path} HTTP/1.1\r\nHost: localhost\r\n\r\n").as_bytes())
            .await
            .unwrap();
        let mut buf = vec![0u8; 64 * 1024];
        let n = tokio::time::timeout(std::time::Duration::from_secs(5), stream.read(&mut buf))
            .await
            .expect("response deadline")
            .unwrap();
        String::from_utf8_lossy(&buf[..n]).to_string()
    }

    /// Read `stream` until it ends. `Some(true)`: closed cleanly (TLS
    /// close_notify or a plain FIN), `Some(false)`: torn down, `None`: still
    /// open at the deadline.
    async fn drain_test_closed<S>(stream: &mut S) -> Option<bool>
    where
        S: tokio::io::AsyncRead + Unpin,
    {
        use tokio::io::AsyncReadExt;
        let mut buf = vec![0u8; 64 * 1024];
        tokio::time::timeout(std::time::Duration::from_secs(2), async {
            loop {
                match stream.read(&mut buf).await {
                    Ok(0) => break true,
                    Ok(_) => continue,
                    Err(_) => break false,
                }
            }
        })
        .await
        .ok()
    }

    async fn drain_test_tls_connect(
        connector: &tokio_rustls::TlsConnector,
        addr: SocketAddr,
    ) -> tokio_rustls::client::TlsStream<tokio::net::TcpStream> {
        let tcp = tokio::net::TcpStream::connect(addr).await.unwrap();
        let name = rustls::pki_types::ServerName::try_from("localhost").unwrap();
        connector.connect(name, tcp).await.expect("TLS handshake")
    }

    /// A TLS gateway told to stop closes the connections it accepted rather
    /// than leaving them to serve its router: an idle kept-alive connection
    /// closes cleanly at once, one with an event stream in flight is cut off
    /// within the drain, the gateway returns promptly, and a new connection
    /// reaches the gateway that replaces it.
    #[tokio::test]
    async fn a_stopped_tls_gateway_closes_its_connections_and_the_next_one_serves() {
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let key = rcgen::KeyPair::generate().unwrap();
        let cert = rcgen::CertificateParams::new(vec!["localhost".into()])
            .unwrap()
            .self_signed(&key)
            .unwrap();
        let cert_path = tmp.path().join("gateway.crt");
        let key_path = tmp.path().join("gateway.key");
        std::fs::write(&cert_path, cert.pem()).unwrap();
        std::fs::write(&key_path, key.serialize_pem()).unwrap();
        let mut roots = rustls::RootCertStore::empty();
        roots.add(cert.der().clone()).unwrap();
        let client = rustls::ClientConfig::builder_with_provider(Arc::new(
            rustls::crypto::ring::default_provider(),
        ))
        .with_safe_default_protocol_versions()
        .unwrap()
        .with_root_certificates(roots)
        .with_no_client_auth();
        let connector = tokio_rustls::TlsConnector::from(Arc::new(client));

        let (addr, shutdown_tx, server) =
            start_drain_test_gateway(&tmp.path().join("first"), 0, Some((&cert_path, &key_path)))
                .await;
        let mut idle = drain_test_tls_connect(&connector, addr).await;
        let head = drain_test_request(&mut idle, "/health").await;
        assert!(head.starts_with("HTTP/1.1 200"), "{head}");
        let mut streaming = drain_test_tls_connect(&connector, addr).await;
        let head = drain_test_request(&mut streaming, "/api/events").await;
        assert!(head.starts_with("HTTP/1.1 200"), "{head}");
        // A connection whose TLS handshake never starts.
        let mut handshaking = tokio::net::TcpStream::connect(addr).await.unwrap();

        shutdown_tx.send(true).unwrap();
        tokio::time::timeout(std::time::Duration::from_secs(2), server)
            .await
            .expect("an open connection held up the gateway's stop")
            .expect("the gateway task does not panic")
            .expect("the gateway stops cleanly");
        assert_eq!(
            drain_test_closed(&mut idle).await,
            Some(true),
            "the idle kept-alive connection is closed cleanly"
        );
        assert!(
            drain_test_closed(&mut streaming).await.is_some(),
            "the connection with an event stream in flight is closed"
        );
        assert!(
            drain_test_closed(&mut handshaking).await.is_some(),
            "the connection still waiting for its TLS handshake is closed"
        );

        let (_, next_shutdown, next) = start_drain_test_gateway(
            &tmp.path().join("next"),
            addr.port(),
            Some((&cert_path, &key_path)),
        )
        .await;
        let mut fresh = drain_test_tls_connect(&connector, addr).await;
        let head = drain_test_request(&mut fresh, "/health").await;
        assert!(
            head.starts_with("HTTP/1.1 200"),
            "the next gateway serves: {head}"
        );
        next_shutdown.send(true).unwrap();
        let _ = tokio::time::timeout(std::time::Duration::from_secs(2), next).await;
    }

    /// An HTTP/2 event stream (h2c on the plain listener) is retired with its
    /// gateway: by the time the gateway returns, the stream's task has ended,
    /// and its subscription to the event bus with it.
    #[tokio::test]
    async fn a_stopped_gateway_has_retired_its_http2_streams_when_it_returns() {
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let bus = zeroclaw_runtime::observability::EventBus::new();
        let events = bus.sender().clone();
        let (addr, shutdown_tx, server) =
            start_drain_test_gateway_with(&tmp.path().join("h2"), 0, None, Some(bus)).await;
        let before = events.receiver_count();
        let tcp = tokio::net::TcpStream::connect(addr).await.unwrap();
        let (client, connection) = h2::client::handshake(tcp).await.expect("h2c handshake");
        let driver = zeroclaw_spawn::spawn!(async move {
            let _ = connection.await;
        });
        let mut client = client.ready().await.expect("the h2 connection is ready");
        let request = axum::http::Request::get(format!("http://{addr}/api/events"))
            .body(())
            .unwrap();
        let (response, _) = client
            .send_request(request, true)
            .expect("send the request");
        let response = tokio::time::timeout(std::time::Duration::from_secs(5), response)
            .await
            .expect("response deadline")
            .expect("response");
        assert_eq!(response.status(), 200);
        let _body = response.into_body();
        tokio::time::timeout(std::time::Duration::from_secs(2), async {
            while events.receiver_count() <= before {
                tokio::time::sleep(std::time::Duration::from_millis(10)).await;
            }
        })
        .await
        .expect("the event stream subscribes to the bus");

        shutdown_tx.send(true).unwrap();
        tokio::time::timeout(std::time::Duration::from_secs(2), server)
            .await
            .expect("an HTTP/2 stream held up the gateway's stop")
            .expect("the gateway task does not panic")
            .expect("the gateway stops cleanly");
        assert!(
            events.receiver_count() <= before,
            "an HTTP/2 stream outlived its gateway's retirement"
        );
        driver.abort();
    }

    /// Retiring waits until the tasks it cancelled have actually ended, so
    /// nothing they owned outlives it.
    #[tokio::test]
    async fn retiring_waits_until_the_aborted_tasks_have_ended() {
        let tasks = ServeTasks::default();
        let owned = Arc::new(());
        let held = Arc::clone(&owned);
        tasks.spawn(async move {
            let _held = held;
            std::future::pending::<()>().await;
        });
        assert!(
            !tasks.retire_within(Duration::from_millis(10)).await,
            "the task outlasts the drain"
        );
        assert_eq!(
            Arc::strong_count(&owned),
            1,
            "an aborted task still held what it owned when retiring returned"
        );
    }

    /// The tasks hyper's HTTP/2 spawns for its streams belong to the gateway
    /// too, and are retired with its connections.
    #[tokio::test]
    async fn stream_tasks_hyper_spawns_are_retired_with_the_connections() {
        let tasks = ServeTasks::default();
        let owned = Arc::new(());
        let held = Arc::clone(&owned);
        hyper::rt::Executor::execute(&tasks, async move {
            let _held = held;
            std::future::pending::<()>().await;
        });
        tasks.retire_within(Duration::from_millis(10)).await;
        assert_eq!(
            Arc::strong_count(&owned),
            1,
            "a stream task outlived its gateway's retirement"
        );
    }

    /// Each connection, and each stream hyper hands to the executor, is a task
    /// of the set. Their spawn and completion are recorded at DEBUG, so the
    /// runtime trace, recorded at INFO by default, does not get a pair of
    /// records for every connection.
    #[test]
    fn serve_tasks_record_their_lifecycle_below_info() {
        let _hook_guard = zeroclaw_log::__private_test_hook_lock();
        zeroclaw_log::try_install_capture_subscriber();
        let mut receiver = zeroclaw_log::subscribe_or_install();
        let test_case = "serve-tasks-lifecycle-level";

        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        runtime.block_on(::zeroclaw_log::scope!(test_case: test_case, => async {
            let tasks = ServeTasks::default();
            tasks.spawn(async {});
            hyper::rt::Executor::execute(&tasks, async {});
            tasks.idle().await;
        }));
        drop(runtime);

        let mut records = Vec::new();
        loop {
            let event = match receiver.try_recv() {
                Ok(event) => event,
                // Other tests log into the same capture; a lagged receiver
                // has only dropped older events, so keep reading.
                Err(tokio::sync::broadcast::error::TryRecvError::Lagged(_)) => continue,
                Err(_) => break,
            };
            if event
                .pointer("/attributes/test_case")
                .and_then(|v| v.as_str())
                == Some(test_case)
                && event.pointer("/attributes/task_site").is_some()
            {
                records.push(format!(
                    "{} {}",
                    event["severity_text"].as_str().unwrap_or_default(),
                    event["message"].as_str().unwrap_or_default()
                ));
            }
        }
        zeroclaw_log::clear_broadcast_hook();

        records.sort();
        assert_eq!(
            records,
            [
                "DEBUG task complete",
                "DEBUG task complete",
                "DEBUG task spawned",
                "DEBUG task spawned",
            ],
            "a connection's or stream's task lifecycle must stay out of the INFO trace"
        );
    }

    /// Retiring takes at most the drain plus the join of what it cancelled,
    /// which together fit inside the daemon's 500 ms grace.
    #[tokio::test]
    async fn retiring_ends_within_the_daemons_grace() {
        tokio::time::pause();
        let tasks = ServeTasks::default();
        tasks.spawn(std::future::pending());
        let started = tokio::time::Instant::now();
        tasks.retire_within(CONNECTION_DRAIN).await;
        assert!(
            started.elapsed() < Duration::from_millis(500),
            "retiring took {:?}",
            started.elapsed()
        );
    }

    /// A gateway dropped before its drain ran (the daemon aborted it)
    /// cancels its tasks, so they end at their next poll.
    #[tokio::test]
    async fn dropping_the_serve_loop_cancels_its_tasks() {
        let tasks = ServeTasks::default();
        let owned = Arc::new(());
        let held = Arc::clone(&owned);
        tasks.spawn(async move {
            let _held = held;
            std::future::pending::<()>().await;
        });
        drop(ServeTasksGuard::new(tasks.clone()));
        tokio::time::timeout(std::time::Duration::from_secs(1), tasks.idle())
            .await
            .expect("a task of the dropped serve loop kept running");
        assert_eq!(
            Arc::strong_count(&owned),
            1,
            "a cancelled task still holds what it owned"
        );
    }

    /// Records how many tasks its set counts at the moment it is dropped.
    struct CountAtDrop(ServeTasks, Arc<std::sync::atomic::AtomicUsize>);

    impl Drop for CountAtDrop {
        fn drop(&mut self) {
            self.1
                .store(self.0.live(), std::sync::atomic::Ordering::SeqCst);
        }
    }

    /// A gateway that has stopped admits no request on a connection it
    /// accepted earlier. HTTP/1.1 (an upgrade request too) and HTTP/2 get a
    /// 503 `gateway_restarting` with `Retry-After`, and the router never sees
    /// them. HTTP/1.1 is told to close; HTTP/2 gets no `Connection` header,
    /// since its connection gets GOAWAY. The same once the gateway's tasks
    /// were cancelled without a stop.
    #[tokio::test]
    async fn a_stopped_generation_admits_no_request() {
        use axum::http::Version;
        use std::sync::atomic::{AtomicUsize, Ordering};
        let routed = Arc::new(AtomicUsize::new(0));
        let counted = Arc::clone(&routed);
        let router = axum::Router::new().route(
            "/",
            axum::routing::get(move || {
                counted.fetch_add(1, Ordering::SeqCst);
                async { StatusCode::OK }
            }),
        );
        let request = |version: Version, upgrade: bool| {
            let mut request = axum::http::Request::get("/").version(version);
            if upgrade {
                request = request
                    .header(header::CONNECTION, "upgrade")
                    .header(header::UPGRADE, "websocket");
            }
            request.body(axum::body::Body::empty()).unwrap()
        };
        async fn assert_gateway_restarting(response: Response, version: Version) {
            assert_eq!(
                response.status(),
                StatusCode::SERVICE_UNAVAILABLE,
                "a stopped generation served {version:?}"
            );
            let headers = response.headers();
            assert_eq!(
                headers
                    .get(header::RETRY_AFTER)
                    .and_then(|v| v.to_str().ok()),
                Some("1"),
                "{version:?}"
            );
            let connection = headers
                .get(header::CONNECTION)
                .and_then(|v| v.to_str().ok());
            if version == Version::HTTP_2 {
                assert_eq!(connection, None, "HTTP/2 has no Connection header");
            } else {
                assert_eq!(connection, Some("close"), "{version:?}");
            }
            let mut names: Vec<_> = headers.keys().map(|name| name.as_str()).collect();
            names.sort_unstable();
            names.retain(|name| *name != "connection");
            assert_eq!(names, ["content-type", "retry-after"], "{version:?}");
            let body = axum::body::to_bytes(response.into_body(), 4096)
                .await
                .unwrap();
            let body: serde_json::Value = serde_json::from_slice(&body).unwrap();
            assert_eq!(
                body,
                serde_json::json!({
                    "error": "The gateway is restarting. Try again.",
                    "reason": "gateway_restarting",
                }),
                "{version:?}"
            );
        }

        let (stop, stopping) = tokio::sync::watch::channel(false);
        let admission = Admission {
            stopping,
            tasks: ServeTasks::default(),
        };
        let response =
            serve_while_current(router.clone(), &admission, request(Version::HTTP_11, false))
                .await
                .unwrap();
        assert_eq!(response.status(), StatusCode::OK, "admitted while current");
        assert_eq!(routed.load(Ordering::SeqCst), 1);

        stop.send_replace(true);
        for (version, upgrade) in [
            (Version::HTTP_11, false),
            (Version::HTTP_11, true),
            (Version::HTTP_2, false),
        ] {
            let response =
                serve_while_current(router.clone(), &admission, request(version, upgrade))
                    .await
                    .unwrap();
            assert_gateway_restarting(response, version).await;
        }
        assert_eq!(
            routed.load(Ordering::SeqCst),
            1,
            "a request reached a stopped generation's router"
        );

        let (_stop, stopping) = tokio::sync::watch::channel(false);
        let tasks = ServeTasks::default();
        let admission = Admission {
            stopping,
            tasks: tasks.clone(),
        };
        tasks.cancel();
        let response =
            serve_while_current(router.clone(), &admission, request(Version::HTTP_11, false))
                .await
                .unwrap();
        assert_gateway_restarting(response, Version::HTTP_11).await;
        assert_eq!(
            routed.load(Ordering::SeqCst),
            1,
            "a request reached a cancelled generation's router"
        );
    }

    /// A request whose service call was made before the stop, but that is
    /// first polled after it, is refused like any other: admission is
    /// decided when the request is first served, not when it was read.
    #[tokio::test]
    async fn a_request_taken_before_the_stop_and_served_after_it_is_refused() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        let routed = Arc::new(AtomicUsize::new(0));
        let counted = Arc::clone(&routed);
        let router = axum::Router::new().route(
            "/",
            axum::routing::get(move || {
                counted.fetch_add(1, Ordering::SeqCst);
                async { StatusCode::OK }
            }),
        );
        let (stop, stopping) = tokio::sync::watch::channel(false);
        let admission = Admission {
            stopping,
            tasks: ServeTasks::default(),
        };
        let request = axum::http::Request::get("/")
            .body(axum::body::Body::empty())
            .unwrap();
        let served = serve_while_current(router, &admission, request);
        stop.send_replace(true);
        let response = served.await.unwrap();
        assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
        assert_eq!(
            routed.load(Ordering::SeqCst),
            0,
            "a request taken before the stop reached the router after it"
        );
    }

    /// A WebSocket upgrade request that races the stop on a kept HTTP/1.1
    /// connection never upgrades. Written, then the stop sent, with no
    /// yield between, the connection's task sees both at once: either the
    /// connection closes before the request is read, or the request gets
    /// the generic 503 and the connection closes.
    #[tokio::test]
    async fn an_upgrade_racing_the_stop_never_upgrades() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let (addr, shutdown_tx, server) =
            start_drain_test_gateway(&tmp.path().join("upgrade"), 0, None).await;
        let mut kept = tokio::net::TcpStream::connect(addr).await.unwrap();
        let head = drain_test_request(&mut kept, "/health").await;
        assert!(head.starts_with("HTTP/1.1 200"), "{head}");

        kept.write_all(
            b"GET /ws/chat HTTP/1.1\r\nHost: localhost\r\nConnection: Upgrade\r\n\
              Upgrade: websocket\r\nSec-WebSocket-Version: 13\r\n\
              Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n\r\n",
        )
        .await
        .unwrap();
        shutdown_tx.send(true).unwrap();
        let mut answer = Vec::new();
        let _ = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            kept.read_to_end(&mut answer),
        )
        .await
        .expect("the kept connection closes");
        let answer = String::from_utf8_lossy(&answer).to_ascii_lowercase();
        assert!(
            !answer.contains(" 101 "),
            "an upgrade was admitted after the stop: {answer}"
        );
        if !answer.is_empty() {
            assert!(answer.starts_with("http/1.1 503"), "{answer}");
            assert!(answer.contains("connection: close"), "{answer}");
            assert!(
                answer.contains(r#""reason":"gateway_restarting""#),
                "{answer}"
            );
        }
        tokio::time::timeout(std::time::Duration::from_secs(2), server)
            .await
            .expect("the gateway returns")
            .expect("the gateway task does not panic")
            .expect("the gateway stops cleanly");
    }

    /// A task submitted after the set was cancelled (an HTTP/2 stream
    /// racing the stop) never runs: it is dropped, without another cancel.
    /// Sixteen of them, so a cancel checked in random order would let one
    /// run.
    #[tokio::test]
    async fn a_task_spawned_after_the_cancel_never_runs() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        let tasks = ServeTasks::default();
        tasks.cancel();
        let polled = Arc::new(AtomicUsize::new(0));
        let owned = Arc::new(());
        for _ in 0..16 {
            let (count, held) = (Arc::clone(&polled), Arc::clone(&owned));
            hyper::rt::Executor::execute(&tasks, async move {
                let _held = held;
                count.fetch_add(1, Ordering::SeqCst);
                std::future::pending::<()>().await;
            });
        }
        tokio::time::timeout(std::time::Duration::from_secs(1), tasks.idle())
            .await
            .expect("a task spawned after the cancel was left running");
        assert_eq!(
            polled.load(Ordering::SeqCst),
            0,
            "a task spawned after the cancel ran"
        );
        assert_eq!(
            Arc::strong_count(&owned),
            1,
            "a task spawned after the cancel still holds what it owned"
        );
    }

    /// The set counts a task until everything the task owns has been
    /// destroyed: one cancelled before its first poll, and one that panics.
    #[tokio::test]
    async fn a_task_is_counted_until_it_has_been_destroyed() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        let tasks = ServeTasks::default();
        let seen = Arc::new(AtomicUsize::new(usize::MAX));
        let sentinel = CountAtDrop(tasks.clone(), Arc::clone(&seen));
        tasks.spawn(async move {
            let _sentinel = sentinel;
            std::future::pending::<()>().await;
        });
        tasks.cancel();
        tokio::time::timeout(std::time::Duration::from_secs(1), tasks.idle())
            .await
            .expect("the cancelled task ends");
        assert_eq!(
            seen.load(Ordering::SeqCst),
            1,
            "a task cancelled before its first poll was counted as gone before it was destroyed"
        );

        let tasks = ServeTasks::default();
        let seen = Arc::new(AtomicUsize::new(usize::MAX));
        let sentinel = CountAtDrop(tasks.clone(), Arc::clone(&seen));
        tasks.spawn(async move {
            let _sentinel = sentinel;
            tokio::task::yield_now().await;
            panic!("a serve task panics");
        });
        tokio::time::timeout(std::time::Duration::from_secs(1), tasks.idle())
            .await
            .expect("the panicked task ends");
        assert_eq!(
            seen.load(Ordering::SeqCst),
            1,
            "a task that panicked was counted as gone before it was destroyed"
        );
    }

    /// Spawning on a runtime that has shut down drops the task inside the
    /// spawn. That must not deadlock, and the count must stay right.
    #[test]
    fn spawning_on_a_shut_down_runtime_drops_the_task_without_a_deadlock() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        let runtime = tokio::runtime::Builder::new_current_thread()
            .build()
            .unwrap();
        let handle = runtime.handle().clone();
        drop(runtime);
        let tasks = ServeTasks::default();
        let seen = Arc::new(AtomicUsize::new(usize::MAX));
        let sentinel = CountAtDrop(tasks.clone(), Arc::clone(&seen));
        let spawner = tasks.clone();
        let (spawned, returned) = std::sync::mpsc::channel();
        std::thread::spawn(move || {
            let _entered = handle.enter();
            hyper::rt::Executor::execute(&spawner, async move {
                let _sentinel = sentinel;
                std::future::pending::<()>().await;
            });
            let _ = spawned.send(());
        });
        returned
            .recv_timeout(std::time::Duration::from_secs(5))
            .expect("spawning on a shut-down runtime deadlocked");
        assert_eq!(
            seen.load(Ordering::SeqCst),
            1,
            "the dropped task was counted as gone before it was destroyed"
        );
        assert_eq!(tasks.live(), 0, "the dropped task is still counted");
    }

    /// A task stuck in code that never yields outlasts retirement, which
    /// returns within its bound anyway and leaves the task counted. The task
    /// ends at its next poll.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn a_task_in_non_yielding_code_ends_at_its_next_poll() {
        let tasks = ServeTasks::default();
        let (release, stuck) = std::sync::mpsc::channel::<()>();
        let (entered, entering) = tokio::sync::oneshot::channel();
        tasks.spawn(async move {
            let _ = entered.send(());
            let _ = stuck.recv();
            std::future::pending::<()>().await;
        });
        entering.await.unwrap();
        let started = std::time::Instant::now();
        assert!(!tasks.retire_within(Duration::from_millis(50)).await);
        assert!(
            started.elapsed() < Duration::from_secs(1),
            "retiring waited on a stuck task: {:?}",
            started.elapsed()
        );
        assert_eq!(tasks.live(), 1, "the stuck task is still counted");
        release.send(()).unwrap();
        tokio::time::timeout(std::time::Duration::from_secs(1), tasks.idle())
            .await
            .expect("the released task ends at its next poll");
    }

    /// A certificate and key for `localhost` written under `dir`, and a
    /// client that trusts them.
    fn drain_test_tls(
        dir: &std::path::Path,
    ) -> (
        std::path::PathBuf,
        std::path::PathBuf,
        tokio_rustls::TlsConnector,
    ) {
        let key = rcgen::KeyPair::generate().unwrap();
        let cert = rcgen::CertificateParams::new(vec!["localhost".into()])
            .unwrap()
            .self_signed(&key)
            .unwrap();
        let cert_path = dir.join("gateway.crt");
        let key_path = dir.join("gateway.key");
        std::fs::write(&cert_path, cert.pem()).unwrap();
        std::fs::write(&key_path, key.serialize_pem()).unwrap();
        let mut roots = rustls::RootCertStore::empty();
        roots.add(cert.der().clone()).unwrap();
        let client = rustls::ClientConfig::builder_with_provider(Arc::new(
            rustls::crypto::ring::default_provider(),
        ))
        .with_safe_default_protocol_versions()
        .unwrap()
        .with_root_certificates(roots)
        .with_no_client_auth();
        (
            cert_path,
            key_path,
            tokio_rustls::TlsConnector::from(Arc::new(client)),
        )
    }

    trait DrainTestIo: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send {}

    impl<T: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send> DrainTestIo for T {}

    /// A new connection to `addr`, over TLS when `tls` is given.
    async fn drain_test_connect(
        addr: SocketAddr,
        tls: Option<&tokio_rustls::TlsConnector>,
    ) -> Box<dyn DrainTestIo> {
        match tls {
            Some(connector) => Box::new(drain_test_tls_connect(connector, addr).await),
            None => Box::new(tokio::net::TcpStream::connect(addr).await.unwrap()),
        }
    }

    fn h2_frame(kind: u8, flags: u8, stream: u32, payload: &[u8]) -> Vec<u8> {
        let len = u32::try_from(payload.len()).unwrap().to_be_bytes();
        let mut frame = vec![len[1], len[2], len[3], kind, flags];
        frame.extend_from_slice(&stream.to_be_bytes());
        frame.extend_from_slice(payload);
        frame
    }

    /// An HTTP/2 client written frame by frame. It never acknowledges a
    /// PING, so a server's graceful shutdown stays in its first phase:
    /// GOAWAY sent, and streams the client sends meanwhile still accepted.
    /// Its settings turn the server's header table off, so each response
    /// header block decodes on its own.
    struct RawH2(Box<dyn DrainTestIo>);

    /// One frame read: its type, flags and payload.
    struct H2Frame {
        kind: u8,
        flags: u8,
        payload: Vec<u8>,
    }

    const H2_DATA: u8 = 0x0;
    const H2_HEADERS: u8 = 0x1;
    const H2_RST_STREAM: u8 = 0x3;
    const H2_SETTINGS: u8 = 0x4;
    const H2_GOAWAY: u8 = 0x7;

    impl RawH2 {
        async fn open(mut io: Box<dyn DrainTestIo>) -> Self {
            use tokio::io::AsyncWriteExt;
            io.write_all(b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n")
                .await
                .unwrap();
            // SETTINGS_HEADER_TABLE_SIZE = 0.
            let settings = [0x00, 0x01, 0, 0, 0, 0];
            io.write_all(&h2_frame(H2_SETTINGS, 0, 0, &settings))
                .await
                .unwrap();
            let mut raw = Self(io);
            raw.next_frame_of(|kind, flags, _| kind == H2_SETTINGS && flags & 0x1 == 0)
                .await
                .expect("the server's settings");
            raw.0
                .write_all(&h2_frame(H2_SETTINGS, 0x1, 0, &[]))
                .await
                .unwrap();
            raw
        }

        /// Send `GET path` on `stream`, header block and end of stream in
        /// one frame. Literal fields without indexing, so no table state.
        async fn get(&mut self, stream: u32, path: &str) {
            use tokio::io::AsyncWriteExt;
            // :method GET and :scheme http, from the static table.
            let mut block = vec![0x82, 0x86];
            for (name_index, value) in [(4u8, path), (1, "localhost")] {
                block.push(name_index);
                block.push(u8::try_from(value.len()).unwrap());
                block.extend_from_slice(value.as_bytes());
            }
            self.0
                .write_all(&h2_frame(H2_HEADERS, 0x5, stream, &block))
                .await
                .unwrap();
        }

        /// Read frames until one matches `(type, flags, stream)`; `None` if
        /// the connection ends first.
        async fn next_frame_of(
            &mut self,
            matches: impl Fn(u8, u8, u32) -> bool,
        ) -> Option<H2Frame> {
            use tokio::io::AsyncReadExt;
            tokio::time::timeout(std::time::Duration::from_secs(2), async {
                loop {
                    let mut head = [0u8; 9];
                    self.0.read_exact(&mut head).await.ok()?;
                    let len = u32::from_be_bytes([0, head[0], head[1], head[2]]);
                    let mut payload = vec![0u8; usize::try_from(len).unwrap()];
                    self.0.read_exact(&mut payload).await.ok()?;
                    let stream =
                        u32::from_be_bytes([head[5], head[6], head[7], head[8]]) & 0x7fff_ffff;
                    if matches(head[3], head[4], stream) {
                        return Some(H2Frame {
                            kind: head[3],
                            flags: head[4],
                            payload,
                        });
                    }
                }
            })
            .await
            .expect("frame deadline")
        }
    }

    /// Decode an HPACK Huffman string made only of digits (RFC 7541,
    /// appendix B: `0` to `2` take five bits, `3` to `9` six); `None` for
    /// anything else.
    fn huffman_digits(bytes: &[u8]) -> Option<String> {
        let bits: Vec<u8> = bytes
            .iter()
            .flat_map(|byte| (0..8).rev().map(move |i| (byte >> i) & 1))
            .collect();
        let take = |at: usize, n: usize| bits[at..at + n].iter().fold(0u8, |v, b| (v << 1) | b);
        let mut digits = String::new();
        let mut at = 0;
        while at < bits.len() {
            let rest = bits.len() - at;
            if rest < 8 && bits[at..].iter().all(|bit| *bit == 1) {
                break;
            }
            if rest >= 5 && take(at, 5) <= 2 {
                digits.push(char::from(b'0' + take(at, 5)));
                at += 5;
            } else if rest >= 6 && (0x19..=0x1f).contains(&take(at, 6)) {
                digits.push(char::from(b'0' + 3 + take(at, 6) - 0x19));
                at += 6;
            } else {
                return None;
            }
        }
        Some(digits)
    }

    /// The fields of a header block from a server keeping no header table.
    /// Names beyond the few a gateway response uses read as `#<index>`, or
    /// as their literal; a Huffman-coded string decodes only when it is all
    /// digits (as a status or `Retry-After` is), and reads `<huffman>`
    /// otherwise.
    fn h2_header_fields(block: &[u8]) -> Vec<(String, String)> {
        fn integer(block: &[u8], at: &mut usize, prefix: u32) -> usize {
            let max = (1usize << prefix) - 1;
            let mut value = usize::from(block[*at]) & max;
            *at += 1;
            if value == max {
                let mut shift = 0;
                loop {
                    let byte = block[*at];
                    *at += 1;
                    value += usize::from(byte & 0x7f) << shift;
                    shift += 7;
                    if byte & 0x80 == 0 {
                        break;
                    }
                }
            }
            value
        }
        fn string(block: &[u8], at: &mut usize) -> String {
            let huffman = block[*at] & 0x80 != 0;
            let len = integer(block, at, 7);
            let bytes = &block[*at..*at + len];
            *at += len;
            if huffman {
                huffman_digits(bytes).unwrap_or_else(|| "<huffman>".into())
            } else {
                String::from_utf8_lossy(bytes).into_owned()
            }
        }
        fn name(index: usize) -> String {
            match index {
                8..=14 => ":status".into(),
                28 => "content-length".into(),
                31 => "content-type".into(),
                33 => "date".into(),
                53 => "retry-after".into(),
                _ => format!("#{index}"),
            }
        }
        let mut fields = Vec::new();
        let mut at = 0;
        while at < block.len() {
            let first = block[at];
            if first & 0x80 != 0 {
                let index = integer(block, &mut at, 7);
                let statuses = ["200", "204", "206", "304", "400", "404", "500"];
                let value = index
                    .checked_sub(8)
                    .and_then(|i| statuses.get(i))
                    .map_or("<indexed>", |status| *status);
                fields.push((name(index), value.to_string()));
            } else if first & 0xe0 == 0x20 {
                integer(block, &mut at, 5);
            } else {
                let prefix = if first & 0xc0 == 0x40 { 6 } else { 4 };
                let index = integer(block, &mut at, prefix);
                let field = if index == 0 {
                    string(block, &mut at)
                } else {
                    name(index)
                };
                fields.push((field, string(block, &mut at)));
            }
        }
        fields
    }

    /// Once stopped, a gateway admits no new HTTP/2 stream, though HTTP/2's
    /// graceful shutdown still accepts the streams a client sent before it
    /// saw GOAWAY: such a stream gets the generic 503 on the wire, with no
    /// `Connection` header, and never reaches the router. Over plain HTTP
    /// (h2c) and TLS.
    #[tokio::test]
    async fn a_stopped_gateway_admits_no_http2_stream_after_its_goaway() {
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let (cert_path, key_path, connector) = drain_test_tls(tmp.path());
        for over_tls in [false, true] {
            let bus = zeroclaw_runtime::observability::EventBus::new();
            let events = bus.sender().clone();
            let (addr, shutdown_tx, server) = start_drain_test_gateway_with(
                &tmp.path().join(if over_tls { "tls" } else { "plain" }),
                0,
                over_tls.then_some((cert_path.as_path(), key_path.as_path())),
                Some(bus),
            )
            .await;
            let before = events.receiver_count();
            let mut h2 =
                RawH2::open(drain_test_connect(addr, over_tls.then_some(&connector)).await).await;
            h2.get(1, "/health").await;
            h2.next_frame_of(|kind, _, stream| kind == H2_HEADERS && stream == 1)
                .await
                .expect("a response on the kept connection");

            shutdown_tx.send(true).unwrap();
            h2.next_frame_of(|kind, _, _| kind == H2_GOAWAY)
                .await
                .expect("the kept HTTP/2 connection gets GOAWAY");
            h2.get(3, "/api/events").await;
            let answer = h2
                .next_frame_of(|kind, _, stream| {
                    stream == 3 && (kind == H2_HEADERS || kind == H2_RST_STREAM)
                })
                .await;
            assert!(
                events.receiver_count() <= before,
                "a stream sent after GOAWAY reached the stopped gateway's router (TLS: {over_tls})"
            );
            let answer = answer.expect("the stream sent after GOAWAY is answered");
            assert_eq!(
                answer.kind, H2_HEADERS,
                "the stream sent after GOAWAY is answered, not reset (TLS: {over_tls})"
            );
            assert_eq!(answer.flags & 0x4, 0x4, "one header frame");
            let fields = h2_header_fields(&answer.payload);
            assert!(
                fields.contains(&(":status".into(), "503".into())),
                "TLS: {over_tls}: {fields:?}"
            );
            assert!(
                fields.contains(&("retry-after".into(), "1".into())),
                "TLS: {over_tls}: {fields:?}"
            );
            let allowed = [
                ":status",
                "content-length",
                "content-type",
                "date",
                "retry-after",
            ];
            assert!(
                fields
                    .iter()
                    .all(|(name, _)| allowed.contains(&name.as_str())),
                "no other header, and no Connection (TLS: {over_tls}): {fields:?}"
            );
            let mut body = Vec::new();
            if answer.flags & 0x1 == 0 {
                loop {
                    let data = h2
                        .next_frame_of(|kind, _, stream| stream == 3 && kind == H2_DATA)
                        .await
                        .expect("the response body");
                    body.extend_from_slice(&data.payload);
                    if data.flags & 0x1 != 0 {
                        break;
                    }
                }
            }
            let body: serde_json::Value = serde_json::from_slice(&body).unwrap();
            assert_eq!(
                body,
                serde_json::json!({
                    "error": "The gateway is restarting. Try again.",
                    "reason": "gateway_restarting",
                }),
                "TLS: {over_tls}"
            );

            drop(h2);
            tokio::time::timeout(std::time::Duration::from_secs(2), server)
                .await
                .expect("the gateway returns")
                .expect("the gateway task does not panic")
                .expect("the gateway stops cleanly");
        }
    }

    /// Kept clients of a stopped gateway end up on a fresh connection that
    /// reaches the next gateway. A kept HTTP/1.1 connection is closed; a
    /// kept HTTP/2 client's connection ends after GOAWAY and it can open no
    /// stream on it. The request each sends next, on a new connection, is
    /// served by the next gateway's router: its event stream subscribes to
    /// the next gateway's bus. Over plain HTTP and TLS.
    #[tokio::test]
    async fn kept_clients_reach_the_next_generation_on_a_fresh_connection() {
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let (cert_path, key_path, connector) = drain_test_tls(tmp.path());
        for over_tls in [false, true] {
            let certs = over_tls.then_some((cert_path.as_path(), key_path.as_path()));
            let tls = over_tls.then_some(&connector);
            let label = if over_tls { "tls" } else { "plain" };
            let (addr, shutdown_tx, server) = start_drain_test_gateway_with(
                &tmp.path().join(format!("{label}-first")),
                0,
                certs,
                None,
            )
            .await;
            let mut kept_h1 = drain_test_connect(addr, tls).await;
            let head = drain_test_request(&mut kept_h1, "/health").await;
            assert!(head.starts_with("HTTP/1.1 200"), "{label}: {head}");
            let (kept_h2, connection) = h2::client::handshake(drain_test_connect(addr, tls).await)
                .await
                .expect("HTTP/2 handshake");
            let kept_h2_driver = zeroclaw_spawn::spawn!(async move {
                let _ = connection.await;
            });
            let mut kept_h2 = kept_h2.ready().await.expect("the h2 connection is ready");
            let (response, _) = kept_h2
                .send_request(
                    axum::http::Request::get(format!("http://{addr}/health"))
                        .body(())
                        .unwrap(),
                    true,
                )
                .expect("send the request");
            let response = tokio::time::timeout(std::time::Duration::from_secs(5), response)
                .await
                .expect("response deadline")
                .expect("response");
            assert_eq!(response.status(), 200, "{label}");

            shutdown_tx.send(true).unwrap();
            tokio::time::timeout(std::time::Duration::from_secs(2), server)
                .await
                .expect("the gateway returns")
                .expect("the gateway task does not panic")
                .expect("the gateway stops cleanly");
            assert!(
                drain_test_closed(&mut kept_h1).await.is_some(),
                "{label}: the kept HTTP/1.1 connection is closed"
            );
            tokio::time::timeout(std::time::Duration::from_secs(2), kept_h2_driver)
                .await
                .expect("the kept HTTP/2 connection ends")
                .expect("the connection driver does not panic");
            assert!(
                kept_h2.ready().await.is_err(),
                "{label}: the kept HTTP/2 client can still open a stream"
            );

            let bus = zeroclaw_runtime::observability::EventBus::new();
            let events = bus.sender().clone();
            let (_, next_shutdown, next) = start_drain_test_gateway_with(
                &tmp.path().join(format!("{label}-next")),
                addr.port(),
                certs,
                Some(bus),
            )
            .await;
            let before = events.receiver_count();
            let mut fresh_h1 = drain_test_connect(addr, tls).await;
            let head = drain_test_request(&mut fresh_h1, "/api/events").await;
            assert!(head.starts_with("HTTP/1.1 200"), "{label}: {head}");
            let (fresh_h2, connection) = h2::client::handshake(drain_test_connect(addr, tls).await)
                .await
                .expect("HTTP/2 handshake with the next gateway");
            let fresh_h2_driver = zeroclaw_spawn::spawn!(async move {
                let _ = connection.await;
            });
            let mut fresh_h2 = fresh_h2.ready().await.expect("the h2 connection is ready");
            let (response, _) = fresh_h2
                .send_request(
                    axum::http::Request::get(format!("http://{addr}/api/events"))
                        .body(())
                        .unwrap(),
                    true,
                )
                .expect("send the request");
            let response = tokio::time::timeout(std::time::Duration::from_secs(5), response)
                .await
                .expect("response deadline")
                .expect("response");
            assert_eq!(response.status(), 200, "{label}");
            let _body = response.into_body();
            tokio::time::timeout(std::time::Duration::from_secs(2), async {
                while events.receiver_count() < before + 2 {
                    tokio::time::sleep(std::time::Duration::from_millis(10)).await;
                }
            })
            .await
            .unwrap_or_else(|_| {
                panic!("{label}: the fresh connections reach the next gateway's router")
            });

            next_shutdown.send(true).unwrap();
            let _ = tokio::time::timeout(std::time::Duration::from_secs(2), next).await;
            fresh_h2_driver.abort();
        }
    }

    /// The plain listener keeps the rule it had: a failed connection is
    /// skipped at once, anything else retried after a second, never fatal.
    /// The TLS listener keeps its own.
    #[test]
    fn each_listener_keeps_its_accept_error_rule() {
        use std::io::{Error, ErrorKind};
        for kind in [
            ErrorKind::ConnectionRefused,
            ErrorKind::ConnectionAborted,
            ErrorKind::ConnectionReset,
        ] {
            assert_eq!(
                accept_error_action(&Error::from(kind), false),
                AcceptErrorAction::Retry,
                "plain, {kind:?}"
            );
        }
        for kind in [ErrorKind::Other, ErrorKind::PermissionDenied] {
            assert_eq!(
                accept_error_action(&Error::from(kind), false),
                AcceptErrorAction::RetryAfter(Duration::from_secs(1)),
                "plain, {kind:?}"
            );
        }
        assert_eq!(
            accept_error_action(&Error::from(ErrorKind::ConnectionAborted), true),
            AcceptErrorAction::RetryAfter(Duration::from_millis(ACCEPT_ERROR_BACKOFF_MS)),
            "TLS, a transient error"
        );
        assert_eq!(
            accept_error_action(&Error::from(ErrorKind::PermissionDenied), true),
            AcceptErrorAction::Fail,
            "TLS, a broken listener"
        );
    }

    /// A stop does not wait for an accept-error backoff to run out.
    #[tokio::test]
    async fn a_stop_cuts_an_accept_backoff_short() {
        let (stop, mut stopping) = tokio::sync::watch::channel(false);
        let (stopped, ()) = tokio::time::timeout(std::time::Duration::from_secs(5), async {
            tokio::join!(
                accept_backoff(Duration::from_secs(60), &mut stopping),
                async {
                    tokio::time::sleep(std::time::Duration::from_millis(50)).await;
                    stop.send_replace(true);
                }
            )
        })
        .await
        .expect("the backoff waited out its delay despite the stop");
        assert!(stopped, "the stop is reported");
    }

    /// The same over plain HTTP: a gateway told to stop returns promptly
    /// even with an event stream in flight, every connection it served is
    /// closed, and the next gateway serves.
    #[tokio::test]
    async fn a_stopped_plain_gateway_closes_its_connections_and_the_next_one_serves() {
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let (addr, shutdown_tx, server) =
            start_drain_test_gateway(&tmp.path().join("first"), 0, None).await;
        let mut idle = tokio::net::TcpStream::connect(addr).await.unwrap();
        let head = drain_test_request(&mut idle, "/health").await;
        assert!(head.starts_with("HTTP/1.1 200"), "{head}");
        let mut streaming = tokio::net::TcpStream::connect(addr).await.unwrap();
        let head = drain_test_request(&mut streaming, "/api/events").await;
        assert!(head.starts_with("HTTP/1.1 200"), "{head}");

        shutdown_tx.send(true).unwrap();
        tokio::time::timeout(std::time::Duration::from_secs(2), server)
            .await
            .expect("an event stream in flight held up the gateway's stop")
            .expect("the gateway task does not panic")
            .expect("the gateway stops cleanly");
        assert!(
            drain_test_closed(&mut idle).await.is_some(),
            "the idle kept-alive connection is closed"
        );
        assert!(
            drain_test_closed(&mut streaming).await.is_some(),
            "the connection with an event stream in flight is closed"
        );

        let (_, next_shutdown, next) =
            start_drain_test_gateway(&tmp.path().join("next"), addr.port(), None).await;
        let mut fresh = tokio::net::TcpStream::connect(addr).await.unwrap();
        let head = drain_test_request(&mut fresh, "/health").await;
        assert!(
            head.starts_with("HTTP/1.1 200"),
            "the next gateway serves: {head}"
        );
        next_shutdown.send(true).unwrap();
        let _ = tokio::time::timeout(std::time::Duration::from_secs(2), next).await;
    }

    /// A stopped gateway lets go of its port as soon as it stops accepting,
    /// as `axum::serve` does, even while the drain still holds a response in
    /// flight: the listener is dropped within the drain, and the next
    /// gateway then takes the port. Off Windows, a fresh connection made
    /// during the drain is also seen to be refused rather than left in a
    /// backlog nothing serves. Over plain HTTP and TLS.
    #[tokio::test]
    async fn a_stopped_gateway_releases_its_port_before_its_drain_ends() {
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let (cert_path, key_path, connector) = drain_test_tls(tmp.path());
        for over_tls in [false, true] {
            let certs = over_tls.then_some((cert_path.as_path(), key_path.as_path()));
            let tls = over_tls.then_some(&connector);
            let label = if over_tls { "tls" } else { "plain" };
            let (released_tx, released_rx) = tokio::sync::oneshot::channel();
            let (addr, shutdown_tx, server) = start_drain_test_gateway_with_release(
                &tmp.path().join(format!("{label}-first")),
                0,
                certs,
                None,
                Some(released_tx),
            )
            .await;
            let mut streaming = drain_test_connect(addr, tls).await;
            let head = drain_test_request(&mut streaming, "/api/events").await;
            assert!(head.starts_with("HTTP/1.1 200"), "{label}: {head}");

            shutdown_tx.send(true).unwrap();
            // Observe the owned listener's release, not the peer's retry
            // timer: Windows may defer a refused TCP connect beyond the whole
            // drain. The signal is in-process, so the drain bounds it.
            tokio::time::timeout(CONNECTION_DRAIN, released_rx)
                .await
                .expect("the listener is released before the drain ends")
                .expect("the listener release is reported");
            // Where a refused connect is reported promptly, also see the
            // release from the client side.
            #[cfg(not(windows))]
            {
                let refused = tokio::time::timeout(std::time::Duration::from_millis(150), async {
                    loop {
                        match tokio::net::TcpStream::connect(addr).await {
                            Err(e) if e.kind() == std::io::ErrorKind::ConnectionRefused => break,
                            _ => tokio::time::sleep(std::time::Duration::from_millis(5)).await,
                        }
                    }
                })
                .await;
                assert!(
                    refused.is_ok(),
                    "{label}: the stopped gateway still held its port while it drained"
                );
            }
            assert!(
                !server.is_finished(),
                "{label}: the drain still holds the event stream"
            );
            tokio::time::timeout(std::time::Duration::from_secs(2), server)
                .await
                .expect("the gateway returns")
                .expect("the gateway task does not panic")
                .expect("the gateway stops cleanly");

            let (_, next_shutdown, next) = start_drain_test_gateway_with(
                &tmp.path().join(format!("{label}-next")),
                addr.port(),
                certs,
                None,
            )
            .await;
            let mut fresh = drain_test_connect(addr, tls).await;
            let head = drain_test_request(&mut fresh, "/health").await;
            assert!(
                head.starts_with("HTTP/1.1 200"),
                "{label}: the next gateway serves: {head}"
            );
            next_shutdown.send(true).unwrap();
            let _ = tokio::time::timeout(std::time::Duration::from_secs(2), next).await;
        }
    }

    /// The native TLS listener serves WebSocket upgrades, as plain HTTP
    /// does: a socket opened over TLS completes its upgrade, gets its
    /// route's first frame, and stays open.
    #[tokio::test]
    async fn a_websocket_over_native_tls_stays_open() {
        use futures_util::StreamExt;
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let (cert_path, key_path, connector) = drain_test_tls(tmp.path());
        let (addr, shutdown_tx, server) = start_drain_test_gateway_with(
            &tmp.path().join("tls-ws"),
            0,
            Some((cert_path.as_path(), key_path.as_path())),
            None,
        )
        .await;
        let tls = drain_test_tls_connect(&connector, addr).await;
        let url = format!("ws://localhost:{}/ws/canvas/tls-upgrade", addr.port());
        let (mut socket, response) = tokio_tungstenite::client_async(url, tls)
            .await
            .expect("the upgrade completes");
        assert_eq!(response.status(), 101);
        let first = tokio::time::timeout(std::time::Duration::from_secs(5), socket.next())
            .await
            .expect("a first frame in time")
            .expect("the upgraded TLS socket is still open")
            .expect("a frame, not an error");
        let text = first.into_text().expect("a text frame").to_string();
        assert!(text.contains(r#""type":"connected""#), "{text}");
        assert!(
            tokio::time::timeout(std::time::Duration::from_millis(500), socket.next())
                .await
                .is_err(),
            "the upgraded TLS socket closed on its own"
        );
        drop(socket);
        shutdown_tx.send(true).unwrap();
        let _ = tokio::time::timeout(std::time::Duration::from_secs(2), server).await;
    }

    /// A TLS gateway generation with dashboard sign-in on, at the root path,
    /// verified by the mock provider at `issuer`.
    async fn start_signed_in_tls_gateway(
        data: &std::path::Path,
        cert_path: &std::path::Path,
        key_path: &std::path::Path,
        issuer: &str,
    ) -> (
        SocketAddr,
        Config,
        tokio::sync::watch::Sender<bool>,
        tokio::task::JoinHandle<Result<()>>,
    ) {
        let mut config = Config {
            data_dir: data.join("data"),
            config_path: data.join("config.toml"),
            ..Config::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        config.memory.backend = "none".into();
        crate::dashboard_session::test_support::add_sign_in(&mut config, issuer);
        // The process's rustls provider, as `main.rs` installs it: with both
        // ring and aws-lc-rs compiled in (a workspace build), rustls picks none.
        let _ = rustls::crypto::ring::default_provider().install_default();
        config.gateway.tls = Some(zeroclaw_config::schema::GatewayTlsConfig {
            enabled: true,
            cert_path: cert_path.display().to_string(),
            key_path: key_path.display().to_string(),
            ..Default::default()
        });
        let (ready_tx, mut ready_rx) = tokio::sync::watch::channel(None);
        let readiness = zeroclaw_runtime::daemon::GatewayReadinessReporter::new(move |addr| {
            let _ = ready_tx.send(Some(addr));
        });
        let (shutdown_tx, _) = tokio::sync::watch::channel(false);
        let (reload_tx, _) = tokio::sync::watch::channel(false);
        let controls = zeroclaw_runtime::daemon::GatewayReloadControls::standalone(
            shutdown_tx.clone(),
            reload_tx,
        );
        let served = config.clone();
        let server = zeroclaw_spawn::spawn!(async move {
            run_gateway(
                "127.0.0.1",
                0,
                served,
                None,
                Some(controls),
                None,
                None,
                None,
                None,
                None,
                None,
                Some(readiness),
            )
            .await
        });
        tokio::time::timeout(std::time::Duration::from_secs(10), async {
            ready_rx.wait_for(Option::is_some).await.unwrap();
        })
        .await
        .expect("the gateway becomes ready");
        let addr = ready_rx.borrow().unwrap();
        (addr, config, shutdown_tx, server)
    }

    /// A signed-in dashboard socket over native TLS is closed with 1001
    /// (going away) when its gateway stops, as over plain HTTP: the upgrade
    /// hands the socket to its route, and the session's watch ends it.
    #[tokio::test]
    async fn a_signed_in_socket_over_native_tls_closes_when_its_gateway_stops() {
        use futures_util::StreamExt;
        use tokio_tungstenite::tungstenite::{
            Message, client::IntoClientRequest, protocol::frame::coding::CloseCode,
        };
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let (cert_path, key_path, connector) = drain_test_tls(tmp.path());
        let idp = crate::dashboard_session::test_support::idp(&["admins"], "gw").await;
        let (addr, config, shutdown_tx, server) = start_signed_in_tls_gateway(
            &tmp.path().join("signed-in"),
            &cert_path,
            &key_path,
            &idp.uri(),
        )
        .await;
        // Signed in on the process's shared store, which every generation reads.
        let pairing = Arc::new(PairingGuard::new(
            config.gateway.require_pairing,
            &config.gateway.paired_tokens,
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        let auth = crate::dashboard_session::DashboardAuth::new(
            crate::dashboard_session::DashboardSessions::process_shared(),
            Arc::new(
                crate::principal_gate::GatewayInboundAuth::from_config(&config, pairing).unwrap(),
            ),
        );
        let (cookie, _) = auth
            .sign_in(
                "corp",
                crate::dashboard_session::ProviderPin::of(&config.oidc["corp"]),
                "at-alice".into(),
                3600,
            )
            .await
            .expect("alice signs in");

        let tls = drain_test_tls_connect(&connector, addr).await;
        let origin = format!("https://localhost:{}", addr.port());
        let mut request = format!("{origin}/ws/canvas/signed-in")
            .replacen("https", "ws", 1)
            .into_client_request()
            .unwrap();
        let headers = request.headers_mut();
        headers.insert(
            "cookie",
            format!("{}={cookie}", crate::dashboard_session::HOST_SESSION_COOKIE)
                .parse()
                .unwrap(),
        );
        headers.insert("origin", origin.parse().unwrap());
        let (mut socket, response) = tokio_tungstenite::client_async(request, tls)
            .await
            .expect("the signed-in upgrade completes");
        assert_eq!(response.status(), 101);
        let first = tokio::time::timeout(std::time::Duration::from_secs(5), socket.next())
            .await
            .expect("a first frame in time")
            .expect("the socket is open")
            .expect("a frame");
        assert!(
            first.to_string().contains(r#""type":"connected""#),
            "{first}"
        );

        shutdown_tx.send(true).unwrap();
        let closed = tokio::time::timeout(std::time::Duration::from_secs(5), async {
            while let Some(frame) = socket.next().await {
                if let Ok(Message::Close(close)) = frame {
                    return close.map(|close| close.code);
                }
            }
            None
        })
        .await
        .expect("the socket is closed when its gateway stops");
        assert_eq!(
            closed,
            Some(CloseCode::Away),
            "closed with 1001 (going away)"
        );
        tokio::time::timeout(std::time::Duration::from_secs(2), server)
            .await
            .expect("the gateway returns")
            .expect("the gateway task does not panic")
            .expect("the gateway stops cleanly");
    }

    /// The same race as `an_upgrade_racing_the_stop_never_upgrades`, over
    /// native TLS, which now serves upgrades: the upgrade request never
    /// upgrades once the stop is sent.
    #[tokio::test]
    async fn an_upgrade_racing_the_stop_over_tls_never_upgrades() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let (cert_path, key_path, connector) = drain_test_tls(tmp.path());
        let (addr, shutdown_tx, server) = start_drain_test_gateway_with(
            &tmp.path().join("tls-upgrade"),
            0,
            Some((cert_path.as_path(), key_path.as_path())),
            None,
        )
        .await;
        let mut kept = drain_test_tls_connect(&connector, addr).await;
        let head = drain_test_request(&mut kept, "/health").await;
        assert!(head.starts_with("HTTP/1.1 200"), "{head}");

        kept.write_all(
            b"GET /ws/canvas/race HTTP/1.1\r\nHost: localhost\r\nConnection: Upgrade\r\n\
              Upgrade: websocket\r\nSec-WebSocket-Version: 13\r\n\
              Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n\r\n",
        )
        .await
        .unwrap();
        kept.flush().await.unwrap();
        shutdown_tx.send(true).unwrap();
        let mut answer = Vec::new();
        let _ = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            kept.read_to_end(&mut answer),
        )
        .await
        .expect("the kept connection closes");
        let answer = String::from_utf8_lossy(&answer).to_ascii_lowercase();
        assert!(
            !answer.contains(" 101 "),
            "an upgrade was admitted after the stop: {answer}"
        );
        if !answer.is_empty() {
            assert!(answer.starts_with("http/1.1 503"), "{answer}");
            assert!(answer.contains("connection: close"), "{answer}");
            assert!(
                answer.contains(r#""reason":"gateway_restarting""#),
                "{answer}"
            );
        }
        tokio::time::timeout(std::time::Duration::from_secs(2), server)
            .await
            .expect("the gateway returns")
            .expect("the gateway task does not panic")
            .expect("the gateway stops cleanly");
    }

    #[tokio::test]
    async fn run_gateway_starts_with_mismatched_provider_api_key() {
        // `run_gateway` binds the process-global pricing config handle.
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let mut config = Config::default();
        config.providers.models.anthropic.insert(
            "default".to_string(),
            zeroclaw_config::schema::AnthropicModelProviderConfig {
                base: zeroclaw_config::schema::ModelProviderConfig {
                    model: Some("anthropic/claude-sonnet-4-6".to_string()),
                    api_key: Some("sk-test-openai-shaped-key".to_string()),
                    ..Default::default()
                },
                ..Default::default()
            },
        );

        let handle = zeroclaw_spawn::spawn!(async move {
            run_gateway(
                "127.0.0.1",
                0,
                config,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
            )
            .await
        });

        match tokio::time::timeout(
            std::time::Duration::from_millis(750),
            &mut Box::pin(async {
                let _ = tokio::time::sleep(std::time::Duration::from_millis(500)).await;
            }),
        )
        .await
        {
            Ok(()) => {}
            Err(_) => panic!("test setup timed out before checking gateway state"),
        }

        if handle.is_finished() {
            let result = handle.await.expect("task did not panic");
            panic!(
                "gateway exited during boot when seed provider API key was \
                 mismatched — must stay up so operator can fix via /admin/reload \
                 or /quickstart: {:?}",
                result
            );
        }
        handle.abort();
    }

    #[tokio::test]
    async fn daemon_startup_gateway_reports_ready_and_uses_external_shutdown_sender() {
        // `run_gateway` binds the process-global pricing config handle.
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let port_probe = std::net::TcpListener::bind(("127.0.0.1", 0)).unwrap();
        let port = port_probe.local_addr().unwrap().port();
        drop(port_probe);

        let tmp = tempfile::TempDir::new().unwrap();
        let config = zeroclaw_config::schema::Config {
            data_dir: tmp.path().join("workspace"),
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();

        let (shutdown_tx, _) = tokio::sync::watch::channel(false);
        let (reload_tx, _) = tokio::sync::watch::channel(false);
        let reload_controls = zeroclaw_runtime::daemon::GatewayReloadControls::standalone(
            shutdown_tx.clone(),
            reload_tx,
        );
        let (ready_tx, mut ready_rx) = tokio::sync::watch::channel(None);
        let readiness = zeroclaw_runtime::daemon::GatewayReadinessReporter::new(move |addr| {
            let _ = ready_tx.send(Some(addr));
        });

        let handle = zeroclaw_spawn::spawn!(async move {
            run_gateway(
                "127.0.0.1",
                port,
                config,
                None,
                Some(reload_controls),
                None,
                None,
                None,
                None,
                None,
                None,
                Some(readiness),
            )
            .await
        });

        tokio::time::timeout(std::time::Duration::from_secs(2), async {
            ready_rx.wait_for(Option::is_some).await.unwrap();
        })
        .await
        .expect("gateway should report its successful bind");
        let ready_addr = *ready_rx.borrow();
        assert_eq!(ready_addr.unwrap().port(), port);

        let addr = format!("127.0.0.1:{port}");
        tokio::time::timeout(std::time::Duration::from_secs(2), async {
            loop {
                if tokio::net::TcpStream::connect(&addr).await.is_ok() {
                    break;
                }
                tokio::time::sleep(std::time::Duration::from_millis(25)).await;
            }
        })
        .await
        .expect("gateway should accept connections before shutdown");

        shutdown_tx
            .send(true)
            .expect("external daemon-owned shutdown sender should stay connected");

        tokio::time::timeout(std::time::Duration::from_secs(2), handle)
            .await
            .expect("gateway should return after external shutdown")
            .expect("gateway task should not panic")
            .expect("gateway shutdown should be graceful");

        std::net::TcpListener::bind(("127.0.0.1", port))
            .expect("gateway should release the listener after external shutdown");
    }

    #[tokio::test]
    async fn daemon_startup_gateway_does_not_report_ready_when_tls_setup_fails() {
        // `run_gateway` binds the process-global pricing config handle.
        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let mut config = zeroclaw_config::schema::Config {
            data_dir: tmp.path().join("workspace"),
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        config.gateway.tls = Some(zeroclaw_config::schema::GatewayTlsConfig {
            enabled: true,
            cert_path: tmp.path().join("missing-cert.pem").display().to_string(),
            key_path: tmp.path().join("missing-key.pem").display().to_string(),
            client_auth: None,
        });
        std::fs::create_dir_all(&config.data_dir).unwrap();

        let (ready_tx, ready_rx) = tokio::sync::watch::channel(None);
        let readiness = zeroclaw_runtime::daemon::GatewayReadinessReporter::new(move |addr| {
            let _ = ready_tx.send(Some(addr));
        });
        let result = run_gateway(
            "127.0.0.1",
            0,
            config,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            Some(readiness),
        )
        .await;

        assert!(
            result.is_err(),
            "invalid TLS files should fail gateway setup"
        );
        assert!(
            ready_rx.borrow().is_none(),
            "failed post-bind setup must not report gateway readiness"
        );
    }

    #[tokio::test]
    async fn metrics_endpoint_returns_hint_when_prometheus_is_disabled() {
        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider: Arc::new(MockModelProvider::default()),
            model: "test-model".into(),
            temperature: None,
            mem: Arc::new(MockMemory),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::new(MockMemory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let response = handle_metrics(State(state)).await.into_response();
        assert_eq!(response.status(), StatusCode::OK);
        assert_eq!(
            response
                .headers()
                .get(header::CONTENT_TYPE)
                .and_then(|value| value.to_str().ok()),
            Some(PROMETHEUS_CONTENT_TYPE)
        );

        let body = response.into_body().collect().await.unwrap().to_bytes();
        let text = String::from_utf8(body.to_vec()).unwrap();
        assert!(text.contains("Prometheus backend not enabled"));
    }

    #[cfg(feature = "observability-prometheus")]
    #[tokio::test]
    async fn metrics_endpoint_renders_prometheus_output() {
        let event_tx = tokio::sync::broadcast::channel(16).0;
        let prom = zeroclaw_runtime::observability::PrometheusObserver::new();
        zeroclaw_runtime::observability::Observer::record_event(
            &prom,
            &zeroclaw_runtime::observability::ObserverEvent::HeartbeatTick,
        );

        let observer: Arc<dyn zeroclaw_runtime::observability::Observer> = Arc::new(prom);
        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider: Arc::new(MockModelProvider::default()),
            model: "test-model".into(),
            temperature: None,
            mem: Arc::new(MockMemory),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::new(MockMemory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer,
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let response = handle_metrics(State(state)).await.into_response();
        assert_eq!(response.status(), StatusCode::OK);

        let body = response.into_body().collect().await.unwrap().to_bytes();
        let text = String::from_utf8(body.to_vec()).unwrap();
        assert!(text.contains("zeroclaw_heartbeat_ticks_total 1"));
    }

    #[test]
    fn gateway_rate_limiter_blocks_after_limit() {
        let limiter = GatewayRateLimiter::new(2, 2, 100);
        assert!(limiter.allow_pair("127.0.0.1"));
        assert!(limiter.allow_pair("127.0.0.1"));
        assert!(!limiter.allow_pair("127.0.0.1"));
    }

    #[test]
    fn rate_limiter_sweep_removes_stale_entries() {
        let limiter = SlidingWindowRateLimiter::new(10, Duration::from_secs(60), 100);
        // Add entries for multiple IPs
        assert!(limiter.allow("ip-1"));
        assert!(limiter.allow("ip-2"));
        assert!(limiter.allow("ip-3"));

        {
            let guard = limiter.requests.lock();
            assert_eq!(guard.0.len(), 3);
        }

        // Force a sweep by backdating last_sweep
        {
            let mut guard = limiter.requests.lock();
            guard.1 = Instant::now()
                .checked_sub(Duration::from_secs(RATE_LIMITER_SWEEP_INTERVAL_SECS + 1))
                .unwrap();
            // Clear timestamps for ip-2 and ip-3 to simulate stale entries
            guard.0.get_mut("ip-2").unwrap().clear();
            guard.0.get_mut("ip-3").unwrap().clear();
        }

        // Next allow() call should trigger sweep and remove stale entries
        assert!(limiter.allow("ip-1"));

        {
            let guard = limiter.requests.lock();
            assert_eq!(guard.0.len(), 1, "Stale entries should have been swept");
            assert!(guard.0.contains_key("ip-1"));
        }
    }

    #[test]
    fn rate_limiter_zero_limit_always_allows() {
        let limiter = SlidingWindowRateLimiter::new(0, Duration::from_secs(60), 10);
        for _ in 0..100 {
            assert!(limiter.allow("any-key"));
        }
    }

    #[test]
    fn idempotency_store_rejects_duplicate_key() {
        let store = IdempotencyStore::new(Duration::from_secs(30), 10);
        assert!(store.record_if_new("req-1"));
        assert!(!store.record_if_new("req-1"));
        assert!(store.record_if_new("req-2"));
    }

    #[test]
    fn rate_limiter_bounded_cardinality_evicts_oldest_key() {
        let limiter = SlidingWindowRateLimiter::new(5, Duration::from_secs(60), 2);
        assert!(limiter.allow("ip-1"));
        assert!(limiter.allow("ip-2"));
        assert!(limiter.allow("ip-3"));

        let guard = limiter.requests.lock();
        assert_eq!(guard.0.len(), 2);
        assert!(guard.0.contains_key("ip-2"));
        assert!(guard.0.contains_key("ip-3"));
    }

    #[test]
    fn idempotency_store_bounded_cardinality_evicts_oldest_key() {
        let store = IdempotencyStore::new(Duration::from_secs(300), 2);
        assert!(store.record_if_new("k1"));
        std::thread::sleep(Duration::from_millis(2));
        assert!(store.record_if_new("k2"));
        std::thread::sleep(Duration::from_millis(2));
        assert!(store.record_if_new("k3"));

        let entries = store.entries.lock();
        assert_eq!(entries.committed.len(), 2);
        assert!(!entries.committed.contains_key("k1"));
        assert!(entries.committed.contains_key("k2"));
        assert!(entries.committed.contains_key("k3"));
    }

    #[test]
    fn client_key_defaults_to_peer_addr_when_untrusted_proxy_mode() {
        let peer = SocketAddr::from(([10, 0, 0, 5], 42617));
        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Forwarded-For",
            HeaderValue::from_static("198.51.100.10, 203.0.113.11"),
        );

        let key = client_key_from_request(Some(peer), &headers, false);
        assert_eq!(key, "10.0.0.5");
    }

    #[test]
    fn client_key_uses_forwarded_ip_only_in_trusted_proxy_mode() {
        let peer = SocketAddr::from(([10, 0, 0, 5], 42617));
        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Forwarded-For",
            // Client-supplied leftmost entry, then the address the immediate
            // proxy appended (rightmost).
            HeaderValue::from_static("198.51.100.10, 203.0.113.11"),
        );

        let key = client_key_from_request(Some(peer), &headers, true);
        assert_eq!(key, "203.0.113.11");
    }

    #[test]
    fn client_key_preserves_proxy_suffix_after_opaque_xff_prefix() {
        let peer = SocketAddr::from(([127, 0, 0, 1], 42617));
        for value in [
            &b"\x80, 198.51.100.10"[..],
            &b"\x80, 198.51.100.10, 127.0.0.1"[..],
        ] {
            let mut headers = HeaderMap::new();
            headers.insert("X-Forwarded-For", HeaderValue::from_bytes(value).unwrap());
            assert_eq!(
                client_key_from_request(Some(peer), &headers, true),
                "198.51.100.10"
            );
            assert_eq!(
                client_key_from_request(Some(peer), &headers, false),
                "127.0.0.1"
            );
        }
    }

    #[test]
    fn client_key_ignores_spoofed_loopback_forwarded_header() {
        let peer = SocketAddr::from(([203, 0, 113, 50], 42617));
        let mut headers = HeaderMap::new();
        headers.insert("X-Forwarded-For", HeaderValue::from_static("127.0.0.1"));

        let key = client_key_from_request(Some(peer), &headers, true);
        assert_eq!(key, "203.0.113.50");
    }

    #[test]
    fn client_key_skips_rightmost_loopback_for_earlier_xff_hop() {
        // Same-host proxy chain: immediate hop appended loopback; the real
        // caller remains further left. Must not fall back to a loopback peer
        // (that would grant the local-only limiter exemption).
        let peer = SocketAddr::from(([127, 0, 0, 1], 42617));
        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Forwarded-For",
            HeaderValue::from_static("198.51.100.10, 127.0.0.1"),
        );

        let key = client_key_from_request(Some(peer), &headers, true);
        assert_eq!(key, "198.51.100.10");
    }

    #[test]
    fn client_key_loopback_only_xff_with_loopback_peer_is_non_exempt() {
        let peer = SocketAddr::from(([127, 0, 0, 1], 42617));
        let mut headers = HeaderMap::new();
        headers.insert("X-Forwarded-For", HeaderValue::from_static("127.0.0.1"));

        let key = client_key_from_request(Some(peer), &headers, true);
        assert_eq!(key, "unknown");
    }

    #[test]
    fn request_is_local_matches_rate_limit_loopback_exemption() {
        let loopback = SocketAddr::from(([127, 0, 0, 1], 42617));
        let remote = SocketAddr::from(([203, 0, 113, 50], 42617));
        let mut forwarded_loopback = HeaderMap::new();
        forwarded_loopback.insert("X-Forwarded-For", HeaderValue::from_static("127.0.0.1"));

        assert!(request_is_local(Some(loopback), &HeaderMap::new(), true));
        assert!(request_is_local(Some(loopback), &HeaderMap::new(), false));
        assert!(!request_is_local(Some(loopback), &forwarded_loopback, true));
        assert!(!request_is_local(Some(remote), &forwarded_loopback, true));
        assert!(!request_is_local(Some(remote), &HeaderMap::new(), true));
    }

    #[test]
    fn client_key_falls_back_to_peer_when_forwarded_header_invalid() {
        let peer = SocketAddr::from(([10, 0, 0, 5], 42617));
        let mut headers = HeaderMap::new();
        headers.insert("X-Forwarded-For", HeaderValue::from_static("garbage-value"));

        let key = client_key_from_request(Some(peer), &headers, true);
        assert_eq!(key, "10.0.0.5");
    }

    #[test]
    fn normalize_max_keys_uses_fallback_for_zero() {
        assert_eq!(normalize_max_keys(0, 10_000), 10_000);
        assert_eq!(normalize_max_keys(0, 0), 1);
    }

    #[test]
    fn normalize_max_keys_preserves_nonzero_values() {
        assert_eq!(normalize_max_keys(2_048, 10_000), 2_048);
        assert_eq!(normalize_max_keys(1, 10_000), 1);
    }

    #[tokio::test]
    async fn persist_pairing_tokens_writes_config_tokens() {
        let temp = tempfile::tempdir().unwrap();
        let config_path = temp.path().join("config.toml");
        let workspace_path = temp.path().join("workspace");

        let config = Config {
            config_path: config_path.clone(),
            data_dir: workspace_path,
            ..Default::default()
        };
        config.save().await.unwrap();

        let guard = PairingGuard::new(true, &[], PairingCodePolicy::default());
        let code = guard.pairing_code().unwrap();
        let token = guard.try_pair(&code, "test_client").await.unwrap().unwrap();
        assert!(guard.is_authenticated(&token));

        let state = pairing_persistence_state(config, guard);
        Box::pin(persist_pairing_tokens(&state)).await.unwrap();

        // The published pair keeps tokens as plaintext 64-char hex hashes.
        let plaintext = {
            let in_memory = state.config.read();
            assert_eq!(in_memory.gateway.paired_tokens.len(), 1);
            in_memory.gateway.paired_tokens[0].clone()
        };
        assert_eq!(plaintext.len(), 64);
        assert!(plaintext.chars().all(|c: char| c.is_ascii_hexdigit()));

        // On disk, the token should be encrypted (secrets.encrypt defaults to true).
        let saved = tokio::fs::read_to_string(config_path).await.unwrap();
        let raw_parsed: Config = toml::from_str(&saved).unwrap();
        assert_eq!(raw_parsed.gateway.paired_tokens.len(), 1);
        let on_disk = &raw_parsed.gateway.paired_tokens[0];
        assert!(
            zeroclaw_runtime::security::SecretStore::is_encrypted(on_disk),
            "paired_token should be encrypted on disk"
        );
    }

    /// `persist_pairing_tokens` admits its own config commit since it is
    /// self-contained. This proves that internal admission still
    /// serializes it against a second, concurrent config writer: while an
    /// admitted commit holds the writer guard, the pairing persistence
    /// stays parked on commit admission; once the in-flight commit
    /// publishes and releases, both publications land — neither clobbers
    /// the other. A single Pending poll wouldn't distinguish "blocked on
    /// commit admission" from "transiently Pending on unrelated I/O", so
    /// this polls repeatedly with a no-op waker while the commit stays
    /// held.
    #[tokio::test]
    async fn persist_pairing_tokens_serializes_against_concurrent_config_write() {
        let temp = tempfile::tempdir().unwrap();
        let config = Config {
            config_path: temp.path().join("config.toml"),
            data_dir: temp.path().join("workspace"),
            ..Default::default()
        };
        config.save().await.unwrap();

        let guard = PairingGuard::new(true, &[], PairingCodePolicy::default());
        let code = guard.pairing_code().unwrap();
        let token = guard.try_pair(&code, "test_client").await.unwrap().unwrap();
        assert!(guard.is_authenticated(&token));

        let state = pairing_persistence_state(config, guard);

        // Simulate another in-flight config commit already holding the
        // writer serialization for its own read-mutate-save-publish
        // section.
        let held_commit = state.begin_config_commit().await.unwrap();

        let mut persist_fut = Box::pin(persist_pairing_tokens(&state));

        // Bounded, sleep-free: `persist_pairing_tokens` admits its commit
        // as its very first action, so poll with a no-op waker 50 times
        // while `held_commit` stays live and assert Pending every time,
        // rather than resolving synchronously or racing ahead after a
        // single yield.
        let waker = std::task::Waker::noop();
        let mut cx = std::task::Context::from_waker(waker);
        for _ in 0..50 {
            assert!(
                std::future::Future::poll(persist_fut.as_mut(), &mut cx).is_pending(),
                "persist_pairing_tokens must stay parked on commit admission \
                 for as long as another writer holds the serialization"
            );
        }

        // The concurrent writer's own publication: it holds the same
        // serialization, so it lands before the pairing persistence.
        let mut concurrent = held_commit.current_config();
        concurrent.gateway.port = 55555;
        let revision = held_commit.next_revision().unwrap();
        held_commit.publish(revision, concurrent).unwrap();
        drop(held_commit);

        persist_fut
            .await
            .expect("persist_pairing_tokens must still succeed once unblocked");

        let live = state.config.read();
        assert_eq!(
            live.gateway.port, 55555,
            "the concurrent writer's change must survive — no lost update"
        );
        assert_eq!(
            live.gateway.paired_tokens.len(),
            1,
            "persist_pairing_tokens' own token write must also land"
        );
    }

    /// Minimal AppState carrying one pairing guard, for the pairing
    /// persistence serialization test. The pairing guard cannot be
    /// cloned with its tokens; the test re-pairs inside the fresh guard
    /// before calling this.
    fn pairing_persistence_state(config: Config, guard: PairingGuard) -> AppState {
        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(config);
        AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            pairing: Arc::new(guard),
            ..crate::api::tests::test_state(Config::default())
        }
    }

    #[test]
    fn webhook_memory_key_is_unique() {
        let key1 = webhook_memory_key();
        let key2 = webhook_memory_key();

        assert!(key1.starts_with("webhook_msg_"));
        assert!(key2.starts_with("webhook_msg_"));
        assert_ne!(key1, key2);
    }

    #[test]
    fn webhook_session_id_accepts_valid() {
        let mut headers = HeaderMap::new();
        headers.insert("X-Session-Id", HeaderValue::from_static("abc-DEF_123.foo"));
        assert_eq!(webhook_session_id(&headers), Some("abc-DEF_123.foo".into()));
    }

    #[test]
    fn webhook_session_id_trims_whitespace() {
        let mut headers = HeaderMap::new();
        headers.insert("X-Session-Id", HeaderValue::from_static("  my-session  "));
        assert_eq!(webhook_session_id(&headers), Some("my-session".into()));
    }

    #[test]
    fn webhook_session_id_rejects_empty() {
        let mut headers = HeaderMap::new();
        headers.insert("X-Session-Id", HeaderValue::from_static(""));
        assert_eq!(webhook_session_id(&headers), None);

        headers.insert("X-Session-Id", HeaderValue::from_static("   "));
        assert_eq!(webhook_session_id(&headers), None);
    }

    #[test]
    fn webhook_session_id_rejects_missing() {
        let headers = HeaderMap::new();
        assert_eq!(webhook_session_id(&headers), None);
    }

    #[test]
    fn webhook_session_id_rejects_oversized() {
        let mut headers = HeaderMap::new();
        let long = "a".repeat(129);
        headers.insert("X-Session-Id", HeaderValue::from_str(&long).unwrap());
        assert_eq!(webhook_session_id(&headers), None);

        let at_limit = "b".repeat(128);
        headers.insert("X-Session-Id", HeaderValue::from_str(&at_limit).unwrap());
        assert!(webhook_session_id(&headers).is_some());
    }

    #[test]
    fn webhook_session_id_rejects_invalid_chars() {
        let mut headers = HeaderMap::new();
        for bad in &[
            "has/slash",
            "has:colon",
            "has space",
            "has@at",
            "emoji\u{1f600}",
        ] {
            if let Ok(val) = HeaderValue::from_str(bad) {
                headers.insert("X-Session-Id", val);
                assert_eq!(webhook_session_id(&headers), None, "should reject: {bad}");
            }
        }
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_memory_key_includes_sender_and_message_id() {
        let msg = ChannelMessage {
            id: "wamid-123".into(),
            sender: "+1234567890".into(),
            reply_target: "+1234567890".into(),
            content: "hello".into(),
            channel: "whatsapp".into(),
            channel_alias: None,
            timestamp: 1,
            thread_ts: None,
            interruption_scope_id: None,
            attachments: vec![],
            subject: None,

            ..Default::default()
        };

        let key = whatsapp_memory_key(&msg);
        assert_eq!(key, "whatsapp_+1234567890_wamid-123");
    }

    #[derive(Default)]
    struct MockMemory;

    #[async_trait]
    impl Memory for MockMemory {
        fn name(&self) -> &str {
            "mock"
        }

        async fn store(
            &self,
            _key: &str,
            _content: &str,
            _category: MemoryCategory,
            _session_id: Option<&str>,
        ) -> anyhow::Result<()> {
            Ok(())
        }

        async fn recall(
            &self,
            _query: &str,
            _limit: usize,
            _session_id: Option<&str>,
            _since: Option<&str>,
            _until: Option<&str>,
        ) -> anyhow::Result<Vec<MemoryEntry>> {
            Ok(Vec::new())
        }

        async fn get(&self, _key: &str) -> anyhow::Result<Option<MemoryEntry>> {
            Ok(None)
        }

        async fn list(
            &self,
            _category: Option<&MemoryCategory>,
            _session_id: Option<&str>,
        ) -> anyhow::Result<Vec<MemoryEntry>> {
            Ok(Vec::new())
        }

        async fn forget(&self, _key: &str) -> anyhow::Result<bool> {
            Ok(false)
        }

        async fn forget_for_agent(&self, _key: &str, _agent_id: &str) -> anyhow::Result<bool> {
            Ok(false)
        }

        async fn count(&self) -> anyhow::Result<usize> {
            Ok(0)
        }

        async fn health_check(&self) -> bool {
            true
        }

        async fn store_with_agent(
            &self,
            _key: &str,
            _content: &str,
            _category: MemoryCategory,
            _session_id: Option<&str>,
            _namespace: Option<&str>,
            _importance: Option<f64>,
            _agent_id: Option<&str>,
        ) -> anyhow::Result<()> {
            Ok(())
        }

        async fn recall_for_agents(
            &self,
            _allowed_agent_ids: &[&str],
            _query: &str,
            _limit: usize,
            _session_id: Option<&str>,
            _since: Option<&str>,
            _until: Option<&str>,
        ) -> anyhow::Result<Vec<MemoryEntry>> {
            Ok(Vec::new())
        }
    }
    impl ::zeroclaw_api::attribution::Attributable for MockMemory {
        fn role(&self) -> ::zeroclaw_api::attribution::Role {
            ::zeroclaw_api::attribution::Role::Memory(
                ::zeroclaw_api::attribution::MemoryKind::InMemory,
            )
        }
        fn alias(&self) -> &str {
            "MockMemory"
        }
    }

    #[derive(Default)]
    struct MockModelProvider {
        calls: AtomicUsize,
    }

    #[async_trait]
    impl ModelProvider for MockModelProvider {
        async fn chat_with_system(
            &self,
            _system_prompt: Option<&str>,
            _message: &str,
            _model: &str,
            _temperature: Option<f64>,
        ) -> anyhow::Result<String> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            Ok("ok".into())
        }
    }
    impl ::zeroclaw_api::attribution::Attributable for MockModelProvider {
        fn role(&self) -> ::zeroclaw_api::attribution::Role {
            ::zeroclaw_api::attribution::Role::Provider(
                ::zeroclaw_api::attribution::ProviderKind::Model(
                    ::zeroclaw_api::attribution::ModelProviderKind::Custom,
                ),
            )
        }
        fn alias(&self) -> &str {
            "MockModelProvider"
        }
    }

    #[derive(Default)]
    struct CapturingObserver {
        events: Mutex<Vec<zeroclaw_runtime::observability::ObserverEvent>>,
    }

    impl zeroclaw_runtime::observability::Observer for CapturingObserver {
        fn record_event(&self, event: &zeroclaw_runtime::observability::ObserverEvent) {
            self.events.lock().push(event.clone());
        }

        fn record_metric(&self, _metric: &zeroclaw_runtime::observability::traits::ObserverMetric) {
        }

        fn name(&self) -> &str {
            "capturing"
        }

        fn as_any(&self) -> &dyn std::any::Any {
            self
        }
    }

    #[derive(Default)]
    struct TrackingMemory {
        keys: Mutex<Vec<String>>,
    }

    #[async_trait]
    impl Memory for TrackingMemory {
        fn name(&self) -> &str {
            "tracking"
        }

        async fn store(
            &self,
            key: &str,
            _content: &str,
            _category: MemoryCategory,
            _session_id: Option<&str>,
        ) -> anyhow::Result<()> {
            self.keys.lock().push(key.to_string());
            Ok(())
        }

        async fn recall(
            &self,
            _query: &str,
            _limit: usize,
            _session_id: Option<&str>,
            _since: Option<&str>,
            _until: Option<&str>,
        ) -> anyhow::Result<Vec<MemoryEntry>> {
            Ok(Vec::new())
        }

        async fn get(&self, _key: &str) -> anyhow::Result<Option<MemoryEntry>> {
            Ok(None)
        }

        async fn list(
            &self,
            _category: Option<&MemoryCategory>,
            _session_id: Option<&str>,
        ) -> anyhow::Result<Vec<MemoryEntry>> {
            Ok(Vec::new())
        }

        async fn forget(&self, _key: &str) -> anyhow::Result<bool> {
            Ok(false)
        }

        async fn forget_for_agent(&self, _key: &str, _agent_id: &str) -> anyhow::Result<bool> {
            Ok(false)
        }

        async fn count(&self) -> anyhow::Result<usize> {
            let size = self.keys.lock().len();
            Ok(size)
        }

        async fn health_check(&self) -> bool {
            true
        }

        async fn store_with_agent(
            &self,
            key: &str,
            content: &str,
            category: MemoryCategory,
            session_id: Option<&str>,
            _namespace: Option<&str>,
            _importance: Option<f64>,
            _agent_id: Option<&str>,
        ) -> anyhow::Result<()> {
            self.store(key, content, category, session_id).await
        }

        async fn recall_for_agents(
            &self,
            _allowed_agent_ids: &[&str],
            _query: &str,
            _limit: usize,
            _session_id: Option<&str>,
            _since: Option<&str>,
            _until: Option<&str>,
        ) -> anyhow::Result<Vec<MemoryEntry>> {
            Ok(Vec::new())
        }
    }
    impl ::zeroclaw_api::attribution::Attributable for TrackingMemory {
        fn role(&self) -> ::zeroclaw_api::attribution::Role {
            ::zeroclaw_api::attribution::Role::Memory(
                ::zeroclaw_api::attribution::MemoryKind::InMemory,
            )
        }
        fn alias(&self) -> &str {
            "TrackingMemory"
        }
    }

    fn test_connect_info() -> ConnectInfo<SocketAddr> {
        ConnectInfo(SocketAddr::from(([127, 0, 0, 1], 30_300)))
    }

    /// Minimal AppState for webhook-SSE regressions.
    fn sse_test_state(model_provider: Arc<dyn ModelProvider>) -> AppState {
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
            sop_driver_handles: None,
        }
    }

    /// A local OpenAI-compatible HTTP fixture used by the production-shaped
    /// gateway tests below. Keeping the listener in the test process proves
    /// that the configured Agent/provider path is exercised without relying on
    /// a network credential or a mock `ModelProvider` injected into AppState.
    struct ChatCompletionFixture {
        address: SocketAddr,
        requests: Arc<AtomicUsize>,
        stream_chunks: Arc<AtomicUsize>,
        stream_closed: Arc<AtomicBool>,
        server: tokio::task::JoinHandle<()>,
    }

    impl ChatCompletionFixture {
        fn base_url(&self) -> String {
            format!("http://{}/v1", self.address)
        }
    }

    impl Drop for ChatCompletionFixture {
        fn drop(&mut self) {
            self.server.abort();
        }
    }

    async fn spawn_chat_completion_fixture(
        response_body: impl Into<String>,
    ) -> ChatCompletionFixture {
        spawn_chat_completion_fixture_sequence(vec![response_body.into()]).await
    }

    async fn spawn_chat_completion_fixture_sequence(
        response_bodies: Vec<String>,
    ) -> ChatCompletionFixture {
        let response_bodies = Arc::new(response_bodies);
        let requests = Arc::new(AtomicUsize::new(0));
        let requests_for_handler = Arc::clone(&requests);
        let bodies_for_handler = Arc::clone(&response_bodies);
        let app = Router::new().route(
            "/v1/chat/completions",
            post(move |_: HeaderMap, axum::extract::Json(_request): axum::extract::Json<serde_json::Value>| {
                let bodies = Arc::clone(&bodies_for_handler);
                let requests = Arc::clone(&requests_for_handler);
                async move {
                    let request_index = requests.fetch_add(1, Ordering::SeqCst);
                    let body = bodies
                        .get(request_index)
                        .or_else(|| bodies.last())
                        .cloned()
                        .unwrap_or_default();
                    (
                        [(header::CONTENT_TYPE, HeaderValue::from_static("text/event-stream"))],
                        Body::from(body),
                    )
                        .into_response()
                }
            }),
        );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind local chat-completions fixture");
        let address = listener
            .local_addr()
            .expect("local chat-completions fixture address");
        let server = zeroclaw_spawn::spawn!(async move {
            axum::serve(listener, app)
                .await
                .expect("serve local chat-completions fixture");
        });
        ChatCompletionFixture {
            address,
            requests,
            stream_chunks: Arc::new(AtomicUsize::new(0)),
            stream_closed: Arc::new(AtomicBool::new(false)),
            server,
        }
    }

    struct BurstChatStream {
        bodies: Arc<Vec<String>>,
        next: usize,
        emitted: Arc<AtomicUsize>,
        closed: Arc<AtomicBool>,
    }

    impl futures_util::Stream for BurstChatStream {
        type Item = Result<String, std::convert::Infallible>;

        fn poll_next(
            mut self: std::pin::Pin<&mut Self>,
            _cx: &mut std::task::Context<'_>,
        ) -> std::task::Poll<Option<Self::Item>> {
            if let Some(body) = self.bodies.get(self.next).cloned() {
                self.next += 1;
                self.emitted.fetch_add(1, Ordering::SeqCst);
                std::task::Poll::Ready(Some(Ok(body)))
            } else {
                std::task::Poll::Pending
            }
        }
    }

    impl Drop for BurstChatStream {
        fn drop(&mut self) {
            self.closed.store(true, Ordering::SeqCst);
        }
    }

    async fn spawn_burst_hanging_chat_completion_fixture() -> ChatCompletionFixture {
        let requests = Arc::new(AtomicUsize::new(0));
        let stream_chunks = Arc::new(AtomicUsize::new(0));
        let stream_closed = Arc::new(AtomicBool::new(false));
        let requests_for_handler = Arc::clone(&requests);
        let bodies: Arc<Vec<String>> = Arc::new(
            (0..17)
                .map(|index| {
                    format!(
                        "data: {{\"choices\":[{{\"delta\":{{\"content\":\"chunk-{index}\"}}}}]}}\n\n"
                    )
                })
                .collect(),
        );
        let bodies_for_handler = Arc::clone(&bodies);
        let chunks_for_handler = Arc::clone(&stream_chunks);
        let closed_for_handler = Arc::clone(&stream_closed);
        let app = Router::new().route(
            "/v1/chat/completions",
            post(
                move |_: HeaderMap,
                      axum::extract::Json(_request): axum::extract::Json<serde_json::Value>| {
                    let requests = Arc::clone(&requests_for_handler);
                    let bodies = Arc::clone(&bodies_for_handler);
                    let emitted = Arc::clone(&chunks_for_handler);
                    let closed = Arc::clone(&closed_for_handler);
                    async move {
                        requests.fetch_add(1, Ordering::SeqCst);
                        let stream = BurstChatStream {
                            bodies,
                            next: 0,
                            emitted,
                            closed,
                        };
                        (
                            [(
                                header::CONTENT_TYPE,
                                HeaderValue::from_static("text/event-stream"),
                            )],
                            Body::from_stream(stream),
                        )
                            .into_response()
                    }
                },
            ),
        );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind burst chat-completions fixture");
        let address = listener
            .local_addr()
            .expect("burst chat-completions fixture address");
        let server = zeroclaw_spawn::spawn!(async move {
            axum::serve(listener, app)
                .await
                .expect("serve burst chat-completions fixture");
        });
        ChatCompletionFixture {
            address,
            requests,
            stream_chunks,
            stream_closed,
            server,
        }
    }

    /// A provider fixture that sends response headers and then keeps the
    /// streaming body open. This gives two real gateway transports time to
    /// replace one another under the same session key before either provider
    /// turn can complete.
    async fn spawn_hanging_chat_completion_fixture() -> ChatCompletionFixture {
        let requests = Arc::new(AtomicUsize::new(0));
        let requests_for_handler = Arc::clone(&requests);
        let app = Router::new().route(
            "/v1/chat/completions",
            post(
                move |_: HeaderMap,
                      axum::extract::Json(_request): axum::extract::Json<serde_json::Value>| {
                    let requests = Arc::clone(&requests_for_handler);
                    async move {
                        requests.fetch_add(1, Ordering::SeqCst);
                        let stream = futures_util::stream::pending::<
                            Result<String, std::convert::Infallible>,
                        >();
                        (
                            [(
                                header::CONTENT_TYPE,
                                HeaderValue::from_static("text/event-stream"),
                            )],
                            Body::from_stream(stream),
                        )
                            .into_response()
                    }
                },
            ),
        );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind hanging chat-completions fixture");
        let address = listener
            .local_addr()
            .expect("hanging chat-completions fixture address");
        let server = zeroclaw_spawn::spawn!(async move {
            axum::serve(listener, app)
                .await
                .expect("serve hanging chat-completions fixture");
        });
        ChatCompletionFixture {
            address,
            requests,
            stream_chunks: Arc::new(AtomicUsize::new(0)),
            stream_closed: Arc::new(AtomicBool::new(false)),
            server,
        }
    }

    async fn spawn_test_ws_gateway(state: AppState) -> (SocketAddr, tokio::task::JoinHandle<()>) {
        let app = Router::new()
            .route("/ws/chat", get(ws::handle_ws_chat))
            .with_state(state);
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind gateway WebSocket listener");
        let address = listener
            .local_addr()
            .expect("gateway WebSocket listener address");
        let server = zeroclaw_spawn::spawn!(async move {
            axum::serve(listener, app)
                .await
                .expect("serve gateway WebSocket listener");
        });
        (address, server)
    }

    async fn wait_for_fixture_requests(fixture: &ChatCompletionFixture, expected: usize) {
        tokio::time::timeout(Duration::from_secs(3), async {
            loop {
                if fixture.requests.load(Ordering::SeqCst) >= expected {
                    return;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("provider fixture request");
    }

    async fn wait_for_fixture_chunks(fixture: &ChatCompletionFixture, expected: usize) {
        tokio::time::timeout(Duration::from_secs(3), async {
            loop {
                if fixture.stream_chunks.load(Ordering::SeqCst) >= expected {
                    return;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("provider fixture stream chunks");
    }

    async fn wait_for_registry_token(
        state: &AppState,
        session_key: &str,
    ) -> Arc<tokio_util::sync::CancellationToken> {
        tokio::time::timeout(Duration::from_secs(3), async {
            loop {
                if let Some(token) = state
                    .cancel_tokens
                    .lock()
                    .expect("cancel_tokens lock poisoned")
                    .get(session_key)
                    .cloned()
                {
                    return token;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("registered transport cancellation token")
    }

    async fn wait_for_registry_replacement(
        state: &AppState,
        session_key: &str,
        previous: &Arc<tokio_util::sync::CancellationToken>,
    ) -> Arc<tokio_util::sync::CancellationToken> {
        tokio::time::timeout(Duration::from_secs(3), async {
            loop {
                if let Some(token) = state
                    .cancel_tokens
                    .lock()
                    .expect("cancel_tokens lock poisoned")
                    .get(session_key)
                    .cloned()
                    && !Arc::ptr_eq(&token, previous)
                {
                    return token;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("replacement transport cancellation token")
    }

    async fn wait_for_registry_owner(
        state: &AppState,
        session_key: &str,
        expected: &Arc<tokio_util::sync::CancellationToken>,
    ) {
        tokio::time::timeout(Duration::from_secs(3), async {
            loop {
                let matches = state
                    .cancel_tokens
                    .lock()
                    .expect("cancel_tokens lock poisoned")
                    .get(session_key)
                    .is_some_and(|current| Arc::ptr_eq(current, expected));
                if matches {
                    return;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("replacement transport retains registry ownership");
    }

    async fn wait_for_registry_empty(state: &AppState, session_key: &str) {
        tokio::time::timeout(Duration::from_secs(3), async {
            loop {
                let empty = !state
                    .cancel_tokens
                    .lock()
                    .expect("cancel_tokens lock poisoned")
                    .contains_key(session_key);
                if empty {
                    return;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("transport cancellation registry cleanup");
    }

    async fn collect_cancelled_sse(response: Response) -> String {
        let payload = tokio::time::timeout(Duration::from_secs(3), response.into_body().collect())
            .await
            .expect("cancelled SSE response body")
            .expect("cancelled SSE response body stream")
            .to_bytes();
        String::from_utf8(payload.to_vec()).expect("cancelled SSE response is UTF-8")
    }

    async fn start_test_sse(state: &AppState, session_id: &str) -> Response {
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        headers.insert(
            "X-Session-Id",
            HeaderValue::from_str(session_id).expect("transport test session id header"),
        );
        handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery {
                agent: Some("web".to_string()),
            }),
            headers,
            Ok(Json(WebhookBody {
                message: "transport overlap".to_string(),
                stream: true,
                continue_on_disconnect: false,
            })),
        )
        .await
    }

    /// Build an AppState whose `/webhook?agent=web` path constructs a real
    /// runtime Agent and a configured custom OpenAI-compatible provider. The
    /// synthetic allowlist deliberately leaves the Agent with no executable
    /// tools so a text-only fixture cannot accidentally enter a tool loop.
    fn production_sse_state(
        tmp: &tempfile::TempDir,
        provider_url: &str,
        daily_limit_usd: f64,
        response_cache_enabled: bool,
    ) -> (AppState, Arc<CostTracker>) {
        use zeroclaw_config::multi_agent::{
            AgentMemoryConfig, AgentWorkspaceConfig, MemoryBackendKind,
        };
        use zeroclaw_config::schema::{
            AliasedAgentConfig, CustomModelProviderConfig, ModelProviderConfig, RiskProfileConfig,
            RuntimeProfileConfig,
        };

        let workspace = tmp.path().join("workspace");
        std::fs::create_dir_all(&workspace).expect("production fixture workspace");
        let mut config = Config {
            data_dir: workspace.clone(),
            config_path: tmp.path().join("config.toml"),
            ..Config::default()
        };
        config.memory.backend = "none".to_string();
        config.memory.auto_save = false;
        config.memory.response_cache_enabled = response_cache_enabled;
        config.memory.response_cache_ttl_minutes = 60;
        config.cost.enabled = true;
        config.cost.track_per_agent = true;
        config.cost.daily_limit_usd = daily_limit_usd;
        config.cost.monthly_limit_usd = daily_limit_usd;
        config.cost.warn_at_percent = 100;
        config.reliability.provider_retries = 0;
        config.reliability.provider_backoff_ms = 0;
        config.providers.models.custom.insert(
            "fixture".to_string(),
            CustomModelProviderConfig {
                base: ModelProviderConfig {
                    api_key: Some("test-key".to_string()),
                    uri: Some(provider_url.to_string()),
                    model: Some("fixture-model".to_string()),
                    temperature: Some(0.0),
                    pricing: HashMap::from([
                        ("fixture-model.input".to_string(), 2.0),
                        ("fixture-model.output".to_string(), 4.0),
                    ]),
                    ..ModelProviderConfig::default()
                },
            },
        );
        let risk = RiskProfileConfig {
            allowed_tools: vec!["__gateway_fixture_no_tools__".to_string()],
            ..RiskProfileConfig::default()
        };
        config.risk_profiles.insert("fixture".to_string(), risk);
        config.runtime_profiles.insert(
            "fixture".to_string(),
            RuntimeProfileConfig {
                max_tool_iterations: 1,
                ..RuntimeProfileConfig::default()
            },
        );
        config.agents.insert(
            "web".to_string(),
            AliasedAgentConfig {
                model_provider: "custom.fixture".into(),
                risk_profile: "fixture".into(),
                runtime_profile: "fixture".into(),
                memory: AgentMemoryConfig {
                    backend: MemoryBackendKind::None,
                },
                workspace: AgentWorkspaceConfig {
                    path: Some(workspace),
                    ..AgentWorkspaceConfig::default()
                },
                ..AliasedAgentConfig::default()
            },
        );

        let tracker = Arc::new(
            CostTracker::new(config.cost.clone(), &config.data_dir)
                .expect("production fixture cost tracker"),
        );
        let mut state = crate::api::tests::test_state(config);
        state.cost_tracker = Some(Arc::clone(&tracker));
        (state, tracker)
    }

    async fn collect_production_sse(state: &AppState, message: &str, session_id: &str) -> String {
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        headers.insert(
            "X-Session-Id",
            HeaderValue::from_str(session_id).expect("fixture session id header"),
        );
        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery {
                agent: Some("web".to_string()),
            }),
            headers,
            Ok(Json(WebhookBody {
                message: message.to_string(),
                stream: true,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();
        assert_eq!(response.status(), StatusCode::OK);
        let payload = response
            .into_body()
            .collect()
            .await
            .expect("production SSE response body")
            .to_bytes();
        String::from_utf8(payload.to_vec()).expect("production SSE response is UTF-8")
    }

    const PRODUCTION_FIXTURE_STREAM: &str = "data: {\"choices\":[{\"delta\":{\"content\":\"fixture answer\"}}]}\n\n\
data: {\"choices\":[{\"delta\":{},\"finish_reason\":\"stop\"}],\"usage\":{\"prompt_tokens\":10,\"completion_tokens\":5}}\n\n\
data: [DONE]\n\n";

    const PRODUCTION_FIXTURE_TOOL_STREAM: &str = "data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"id\":\"call_fixture\",\"type\":\"function\",\"function\":{\"name\":\"calculator\",\"arguments\":\"{\\\"function\\\":\\\"add\\\",\\\"values\\\":[1,2]}\"}}]}}]}\n\n\
data: {\"choices\":[{\"delta\":{},\"finish_reason\":\"tool_calls\"}]}\n\n\
data: [DONE]\n\n";

    const PRODUCTION_FIXTURE_FINAL_STREAM: &str = "data: {\"choices\":[{\"delta\":{\"content\":\"final answer\"}}]}\n\n\
data: {\"choices\":[{\"delta\":{},\"finish_reason\":\"stop\"}]}\n\n\
data: [DONE]\n\n";

    /// Answers once the test releases it, and records that it did: a turn
    /// that outlives its viewer can be shown to run to completion.
    struct GatedProvider {
        release: Arc<tokio::sync::Notify>,
        completed: Arc<std::sync::atomic::AtomicUsize>,
        reply: String,
    }

    #[async_trait]
    impl ModelProvider for GatedProvider {
        async fn chat_with_system(
            &self,
            _system_prompt: Option<&str>,
            _message: &str,
            _model: &str,
            _temperature: Option<f64>,
        ) -> anyhow::Result<String> {
            self.release.notified().await;
            self.completed
                .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            Ok(self.reply.clone())
        }
    }

    impl ::zeroclaw_api::attribution::Attributable for GatedProvider {
        fn role(&self) -> ::zeroclaw_api::attribution::Role {
            ::zeroclaw_api::attribution::Role::Provider(
                ::zeroclaw_api::attribution::ProviderKind::Model(
                    ::zeroclaw_api::attribution::ModelProviderKind::Custom,
                ),
            )
        }

        fn alias(&self) -> &str {
            "GatedProvider"
        }
    }

    struct HangingProvider;

    #[async_trait]
    impl ModelProvider for HangingProvider {
        async fn chat_with_system(
            &self,
            _system_prompt: Option<&str>,
            _message: &str,
            _model: &str,
            _temperature: Option<f64>,
        ) -> anyhow::Result<String> {
            std::future::pending::<()>().await;
            unreachable!("pending future never resolves")
        }
    }

    impl ::zeroclaw_api::attribution::Attributable for HangingProvider {
        fn role(&self) -> ::zeroclaw_api::attribution::Role {
            ::zeroclaw_api::attribution::Role::Provider(
                ::zeroclaw_api::attribution::ProviderKind::Model(
                    ::zeroclaw_api::attribution::ModelProviderKind::Custom,
                ),
            )
        }

        fn alias(&self) -> &str {
            "HangingProvider"
        }
    }

    #[tokio::test]
    async fn webhook_sse_production_agent_persists_usage_with_agent_alias() {
        let fixture = spawn_chat_completion_fixture(PRODUCTION_FIXTURE_STREAM).await;
        let tmp = tempfile::tempdir().expect("production gateway temp dir");
        let (state, tracker) = production_sse_state(&tmp, &fixture.base_url(), 1.0, false);

        let text = collect_production_sse(&state, "production stream", "production-cost").await;

        assert!(
            text.contains("event: token") && text.contains(r#"data: {"text":"fixture answer"}"#),
            "configured Agent/provider path must forward streamed text: {text}"
        );
        assert!(
            text.contains("event: done") && !text.contains("event: error"),
            "successful production-shaped turn must finish without an error frame: {text}"
        );
        assert_eq!(
            fixture.requests.load(Ordering::SeqCst),
            1,
            "one successful turn should make exactly one provider request"
        );

        let summary = tracker
            .get_summary_for_agent("web")
            .expect("agent-scoped cost summary");
        assert_eq!(summary.request_count, 1);
        assert_eq!(summary.total_tokens, 15);
        assert!(
            summary.session_cost_usd > 0.0,
            "configured pricing must persist a non-zero streamed-turn cost"
        );
        let by_agent = tracker.get_summary().expect("global cost summary").by_agent;
        let stats = by_agent.get("web").expect("agent alias attribution");
        assert_eq!(stats.total_tokens, 15);
        assert!(stats.cost_usd > 0.0);
    }

    #[tokio::test]
    async fn webhook_sse_production_budget_exhaustion_skips_provider_request() {
        let fixture = spawn_chat_completion_fixture(PRODUCTION_FIXTURE_STREAM).await;
        let tmp = tempfile::tempdir().expect("production gateway temp dir");
        let (state, tracker) = production_sse_state(&tmp, &fixture.base_url(), 0.01, false);
        tracker
            .record_usage_with_agent(
                zeroclaw_config::cost::types::TokenUsage::new(
                    "fixture-model",
                    1_000_000,
                    0,
                    0,
                    2.0,
                    4.0,
                    0.0,
                ),
                Some("web"),
            )
            .expect("seed exhausted budget record");

        let text = collect_production_sse(&state, "blocked stream", "production-budget").await;

        assert_eq!(
            fixture.requests.load(Ordering::SeqCst),
            0,
            "an exhausted budget must reject before the provider request"
        );
        assert!(
            text.contains("event: error"),
            "budget rejection must be an SSE error: {text}"
        );
        assert!(
            text.contains("Budget exceeded"),
            "SSE error should preserve the budget explanation: {text}"
        );
        assert!(
            !text.contains("event: done"),
            "budget rejection must not emit done: {text}"
        );
    }

    #[tokio::test]
    async fn webhook_sse_production_cache_hit_reconciles_no_chunk_final_response() {
        let fixture = spawn_chat_completion_fixture(PRODUCTION_FIXTURE_STREAM).await;
        let tmp = tempfile::tempdir().expect("production gateway temp dir");
        let (state, tracker) = production_sse_state(&tmp, &fixture.base_url(), 1.0, true);

        let first = collect_production_sse(&state, "cache me", "production-cache-first").await;
        assert!(
            first.contains("event: token"),
            "cache seed must stream a token: {first}"
        );
        assert!(
            first.contains("event: done"),
            "cache seed must complete: {first}"
        );
        assert_eq!(fixture.requests.load(Ordering::SeqCst), 1);

        let second = collect_production_sse(&state, "cache me", "production-cache-second").await;
        assert!(
            second.contains("event: token")
                && second.contains(r#"data: {"text":"fixture answer"}"#),
            "a production cache hit has no runtime chunks, so reconciliation must emit the final response: {second}"
        );
        assert!(
            second.contains("event: done"),
            "cache hit must still terminate with done: {second}"
        );
        assert!(
            !second.contains("event: error"),
            "cache hit must not emit an error: {second}"
        );
        assert_eq!(
            fixture.requests.load(Ordering::SeqCst),
            1,
            "cache hit must not make another provider request"
        );
        assert_eq!(
            tracker
                .get_summary_for_agent("web")
                .expect("cache cost summary")
                .request_count,
            1,
            "cache hit must not record a second usage event"
        );
    }

    #[tokio::test]
    async fn webhook_sse_production_receipt_suffix_reconciles_before_done() {
        use zeroclaw_config::schema::ToolReceiptsConfig;

        let fixture = spawn_chat_completion_fixture_sequence(vec![
            PRODUCTION_FIXTURE_TOOL_STREAM.to_string(),
            PRODUCTION_FIXTURE_FINAL_STREAM.to_string(),
        ])
        .await;
        let tmp = tempfile::tempdir().expect("production receipt fixture temp dir");
        let (state, _) = production_sse_state(&tmp, &fixture.base_url(), 1.0, false);
        state.publish_test_config(|config| {
            // Selection admits the tool; the existing allowlist still controls execution.
            config.tools.optional = vec!["calculator".into()];
            config
                .risk_profiles
                .get_mut("fixture")
                .expect("production fixture risk profile")
                .allowed_tools = vec!["calculator".to_string()];
            config
                .runtime_profiles
                .get_mut("fixture")
                .expect("production fixture runtime profile")
                .max_tool_iterations = 2;
            config
                .runtime_profiles
                .get_mut("fixture")
                .expect("production fixture runtime profile")
                .tool_receipts = ToolReceiptsConfig {
                enabled: true,
                show_in_response: true,
                ..ToolReceiptsConfig::default()
            };
        });

        let text = collect_production_sse(&state, "receipt stream", "production-receipt").await;

        assert_eq!(fixture.requests.load(Ordering::SeqCst), 2);
        let final_text = text
            .find(r#"data: {"text":"final answer"}"#)
            .unwrap_or_else(|| panic!("streamed final answer frame: {text}"));
        let receipt_text = text
            .find("Tool receipts:")
            .expect("runtime receipt block in final response");
        let done = text.find("event: done").expect("terminal done frame");
        assert!(
            final_text < receipt_text && receipt_text < done,
            "receipt suffix must be reconciled before done: {text}"
        );
    }

    #[tokio::test]
    async fn webhook_sse_streams_cumulative_token_then_done() {
        let _capture_guard = lock_gateway_chat_dispatch_capture_for_test().await;
        let state = sse_test_state(Arc::new(MockModelProvider::default()));
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        let body = Ok(Json(WebhookBody {
            message: "sse cumulative hello".into(),
            stream: true,
            continue_on_disconnect: false,
        }));

        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            body,
        )
        .await;

        assert_eq!(response.status(), StatusCode::OK);
        assert_eq!(
            response
                .headers()
                .get(header::CONTENT_TYPE)
                .and_then(|v| v.to_str().ok()),
            Some("text/event-stream")
        );

        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let text = std::str::from_utf8(&payload).unwrap();
        assert!(
            text.contains("event: token") && text.contains(r#"data: {"text":"ok"}"#),
            "expected a cumulative token frame, got: {text}"
        );
        assert!(
            text.contains("event: done") && text.contains("data: {}"),
            "expected a terminating done frame, got: {text}"
        );
        assert!(
            !text.contains("event: error"),
            "unexpected error frame: {text}"
        );
        let captures = gateway_chat_dispatch_captures_for_test();
        assert!(
            captures
                .iter()
                .any(|capture| capture.message == "sse cumulative hello"),
            "streamed dispatch must record the same capture as the JSON path"
        );
    }

    #[tokio::test]
    async fn webhook_stream_true_without_sse_accept_keeps_json() {
        let state = sse_test_state(Arc::new(MockModelProvider::default()));
        let body = Ok(Json(WebhookBody {
            message: "hello".into(),
            stream: true,
            continue_on_disconnect: false,
        }));

        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            HeaderMap::new(),
            body,
        )
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::OK);
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        assert_eq!(parsed["response"], "ok");
    }

    #[tokio::test]
    async fn webhook_sse_abort_cancels_turn_via_shared_registry() {
        let state = sse_test_state(Arc::new(HangingProvider));
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        headers.insert("X-Session-Id", HeaderValue::from_static("sse-abort"));
        let body = Ok(Json(WebhookBody {
            message: "hello".into(),
            stream: true,
            continue_on_disconnect: false,
        }));

        let state_for_task = state.clone();
        let task = zeroclaw_spawn::spawn!(async move {
            handle_webhook(
                State(state_for_task.clone()),
                test_connect_info(),
                Query(WebhookQuery::default()),
                headers,
                body,
            )
            .await
            .into_response()
        });
        let response = task.await.unwrap();

        // The streamed turn registered its cancellation token under the
        // gateway session key derived from X-Session-Id.
        let token = state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .get("gw_sse-abort")
            .cloned();
        assert!(
            token.is_some(),
            "streamed webhook turn must register its cancellation token"
        );

        // Cancel through the same registry the abort endpoint uses; the
        // stream must then terminate without a done frame.
        if let Some(token) = token {
            token.cancel();
        }
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let text = std::str::from_utf8(&payload).unwrap();
        assert!(
            !text.contains("event: done"),
            "unexpected done frame: {text}"
        );
        assert!(
            text.contains("event: error"),
            "server-side cancellation must terminate an open SSE stream with an error frame: {text}"
        );
    }

    #[tokio::test]
    async fn webhook_sse_abort_cancels_backpressured_unread_client() {
        let fixture = spawn_burst_hanging_chat_completion_fixture().await;
        let tmp = tempfile::tempdir().expect("backpressure temp dir");
        let (state, _) = production_sse_state(&tmp, &fixture.base_url(), 1.0, false);
        let session_id = "sse-backpressure";
        let response = start_test_sse(&state, session_id).await;
        assert_eq!(response.status(), StatusCode::OK);

        let cancel_key = gateway_cancel_key(session_id);
        let token = wait_for_registry_token(&state, &cancel_key).await;
        wait_for_fixture_requests(&fixture, 1).await;
        wait_for_fixture_chunks(&fixture, 17).await;

        token.cancel();
        tokio::time::timeout(Duration::from_secs(3), async {
            loop {
                let registry_empty = !state
                    .cancel_tokens
                    .lock()
                    .expect("cancel_tokens lock poisoned")
                    .contains_key(&cancel_key);
                let provider_closed = fixture.stream_closed.load(Ordering::SeqCst);
                if registry_empty && provider_closed {
                    return;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("server-side abort must wake a backpressured SSE turn");

        assert!(token.is_cancelled());
        assert!(fixture.stream_closed.load(Ordering::SeqCst));

        // The response body was intentionally left unread while the bounded
        // token queue filled. Resuming the read must still deliver the
        // cancellation terminal frame through its priority channel.
        let text = collect_cancelled_sse(response).await;
        assert!(
            text.contains("event: error"),
            "backpressured cancellation must retain its terminal error: {text}"
        );
        assert!(
            !text.contains("event: done"),
            "a cancelled backpressured stream must not complete: {text}"
        );
    }

    #[tokio::test]
    async fn webhook_sse_anonymous_body_drop_cancels_turn() {
        // Without `X-Session-Id` the turn runs under a key the client never
        // learns and sets no memory session, so nobody could abort it or read
        // its result: the body owns it, and dropping the body cancels at once.
        let state = sse_test_state(Arc::new(HangingProvider));
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: true,
                continue_on_disconnect: false,
            })),
        )
        .await;
        let token = {
            let tokens = state
                .cancel_tokens
                .lock()
                .expect("cancel_tokens lock poisoned");
            assert_eq!(tokens.len(), 1, "one generated key: {:?}", tokens.keys());
            tokens.values().next().cloned().expect("registered token")
        };

        drop(response);

        tokio::time::timeout(Duration::from_secs(1), token.cancelled())
            .await
            .expect("dropping an anonymous SSE body must cancel its turn");
        let deadline = Instant::now() + Duration::from_secs(1);
        while !state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .is_empty()
        {
            assert!(
                Instant::now() < deadline,
                "the cancelled anonymous turn must release its token"
            );
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    }

    #[tokio::test]
    async fn webhook_sse_body_drop_cancels_turn() {
        // The contract streamed webhook callers have always had: a named
        // session alone does not opt into unattended execution, so dropping
        // the body cancels the turn and releases its token.
        let state = sse_test_state(Arc::new(HangingProvider));
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        headers.insert("X-Session-Id", HeaderValue::from_static("sse-drop-default"));

        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: true,
                continue_on_disconnect: false,
            })),
        )
        .await;
        let token = state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .get("gw_sse-drop-default")
            .cloned()
            .expect("streamed turn must register its cancellation token");

        drop(response);

        tokio::time::timeout(Duration::from_secs(1), token.cancelled())
            .await
            .expect("dropping the SSE body must cancel the in-flight turn");
        assert!(
            !state
                .cancel_tokens
                .lock()
                .expect("cancel_tokens lock poisoned")
                .contains_key("gw_sse-drop-default"),
            "dropping the SSE body must remove its cancellation token"
        );
    }

    #[tokio::test]
    async fn webhook_sse_continue_on_disconnect_requires_session_id() {
        // Nobody could abort a detached turn without a session, so the opt-in
        // is refused up front instead of being silently ignored.
        let state = sse_test_state(Arc::new(HangingProvider));
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        headers.insert("X-Idempotency-Key", HeaderValue::from_static("retry-key"));

        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: true,
                continue_on_disconnect: true,
            })),
        )
        .await;

        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
        assert!(
            state
                .cancel_tokens
                .lock()
                .expect("cancel_tokens lock poisoned")
                .is_empty(),
            "a refused request must not start a turn"
        );

        // The refusal happens before the idempotency key is reserved, so a
        // corrected retry under the same key runs instead of being answered
        // as a duplicate.
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        headers.insert("X-Idempotency-Key", HeaderValue::from_static("retry-key"));
        headers.insert("X-Session-Id", HeaderValue::from_static("sse-retry"));
        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: true,
                continue_on_disconnect: true,
            })),
        )
        .await;
        assert_eq!(response.status(), StatusCode::OK);
        assert!(
            state
                .cancel_tokens
                .lock()
                .expect("cancel_tokens lock poisoned")
                .contains_key("gw_sse-retry"),
            "the corrected retry must start a streamed turn"
        );
    }

    #[tokio::test]
    async fn webhook_sse_body_drop_detaches_turn_which_runs_to_completion() {
        // The body is a viewer of the turn, not its owner: dropping it must
        // not cancel the turn, and the token must stay registered so the
        // abort endpoint still reaches the detached turn until it ends.
        let release = Arc::new(tokio::sync::Notify::new());
        let completed = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let state = sse_test_state(Arc::new(GatedProvider {
            release: Arc::clone(&release),
            completed: Arc::clone(&completed),
            reply: "gated ok".into(),
        }));
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        headers.insert("X-Session-Id", HeaderValue::from_static("sse-drop"));

        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: true,
                continue_on_disconnect: true,
            })),
        )
        .await;
        let token = state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .get("gw_sse-drop")
            .cloned()
            .expect("streamed turn must register its cancellation token");

        drop(response);

        assert!(
            tokio::time::timeout(Duration::from_millis(300), token.cancelled())
                .await
                .is_err(),
            "dropping the SSE body must not cancel the in-flight turn"
        );
        assert!(
            state
                .cancel_tokens
                .lock()
                .expect("cancel_tokens lock poisoned")
                .contains_key("gw_sse-drop"),
            "the detached turn stays abortable while it runs"
        );
        assert_eq!(completed.load(std::sync::atomic::Ordering::SeqCst), 0);

        release.notify_one();
        let deadline = Instant::now() + Duration::from_secs(2);
        while state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .contains_key("gw_sse-drop")
        {
            assert!(
                Instant::now() < deadline,
                "the detached turn must finish and release its token"
            );
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
        assert_eq!(
            completed.load(std::sync::atomic::Ordering::SeqCst),
            1,
            "the turn ran to completion with nobody listening"
        );
        assert!(!token.is_cancelled());
    }

    #[tokio::test]
    async fn webhook_sse_detached_turn_drains_events_past_the_queue() {
        // Once the viewer is gone the relay must keep reading the turn's
        // events: the event queue holds 64, so a turn that emits more than
        // that would block on a relay that stopped after the first failed
        // frame, and never finish.
        let release = Arc::new(tokio::sync::Notify::new());
        let completed = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let state = sse_test_state(Arc::new(GatedProvider {
            release: Arc::clone(&release),
            completed: Arc::clone(&completed),
            reply: "line\n".repeat(200),
        }));
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        headers.insert("X-Session-Id", HeaderValue::from_static("sse-flood"));

        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: true,
                continue_on_disconnect: true,
            })),
        )
        .await;
        let token = state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .get("gw_sse-flood")
            .cloned()
            .expect("streamed turn must register its cancellation token");

        drop(response);
        release.notify_one();

        let deadline = Instant::now() + Duration::from_secs(2);
        while state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .contains_key("gw_sse-flood")
        {
            assert!(
                Instant::now() < deadline,
                "a detached turn emitting more events than the queue holds must still finish"
            );
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
        assert_eq!(completed.load(std::sync::atomic::Ordering::SeqCst), 1);
        assert!(!token.is_cancelled());
        assert_eq!(
            sse_test_events_delivered("sse-flood"),
            200,
            "every event must reach the relay: a receiver closed early fails sends"
        );
    }

    #[tokio::test]
    async fn webhook_sse_detached_turn_still_stops_on_abort() {
        // After the viewer is gone, the explicit abort path is the one way
        // to end the turn, exactly as for a detached WebSocket.
        let state = sse_test_state(Arc::new(HangingProvider));
        let mut headers = HeaderMap::new();
        headers.insert(
            header::ACCEPT,
            HeaderValue::from_static("text/event-stream"),
        );
        headers.insert("X-Session-Id", HeaderValue::from_static("sse-abort"));

        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: true,
                continue_on_disconnect: true,
            })),
        )
        .await;
        let token = state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .get("gw_sse-abort")
            .cloned()
            .expect("streamed turn must register its cancellation token");
        drop(response);
        tokio::time::sleep(Duration::from_millis(100)).await;
        assert!(!token.is_cancelled(), "a dropped body does not cancel");

        token.cancel();
        let deadline = Instant::now() + Duration::from_secs(1);
        while state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .contains_key("gw_sse-abort")
        {
            assert!(
                Instant::now() < deadline,
                "an aborted detached turn must release its token"
            );
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    }

    #[tokio::test]
    async fn webhook_sse_replacement_cancels_old_turn_without_removing_new_token() {
        let state = sse_test_state(Arc::new(HangingProvider));
        let request = || {
            let mut headers = HeaderMap::new();
            headers.insert(
                header::ACCEPT,
                HeaderValue::from_static("text/event-stream"),
            );
            headers.insert("X-Session-Id", HeaderValue::from_static("sse-replace"));
            (
                headers,
                Ok(Json(WebhookBody {
                    message: "hello".into(),
                    stream: true,
                    continue_on_disconnect: false,
                })),
            )
        };

        let (headers, body) = request();
        let first = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            body,
        )
        .await;
        let first_token = state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .get("gw_sse-replace")
            .cloned()
            .expect("first streamed turn must register its cancellation token");

        let (headers, body) = request();
        let second = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            body,
        )
        .await;
        let second_token = state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .get("gw_sse-replace")
            .cloned()
            .expect("replacement streamed turn must register its cancellation token");

        tokio::time::timeout(Duration::from_secs(1), first_token.cancelled())
            .await
            .expect("registering a replacement must cancel the previous turn");
        tokio::task::yield_now().await;
        let current = state
            .cancel_tokens
            .lock()
            .expect("cancel_tokens lock poisoned")
            .get("gw_sse-replace")
            .cloned()
            .expect("old-turn cleanup must preserve the replacement token");
        assert!(Arc::ptr_eq(&current, &second_token));

        drop(first);
        drop(second);
    }

    #[test]
    fn cancellation_transport_ws_to_sse_preserves_new_owner() {
        // Real WebSocket/Agent setup is stack-heavy on the test platform; keep
        // this transport-level race isolated without changing the global test
        // stack or weakening the production boundary.
        std::thread::Builder::new()
            .name("gateway-ws-to-sse-cancellation".to_string())
            .stack_size(8 * 1024 * 1024)
            .spawn(|| {
                tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                    .expect("test runtime")
                    .block_on(cancellation_transport_ws_to_sse_preserves_new_owner_inner());
            })
            .expect("spawn WS-to-SSE transport test thread")
            .join()
            .expect("WS-to-SSE transport test thread must not panic");
    }

    async fn cancellation_transport_ws_to_sse_preserves_new_owner_inner() {
        use futures_util::{SinkExt, StreamExt};
        use tokio_tungstenite::{connect_async, tungstenite::Message as ClientMessage};

        let fixture = spawn_hanging_chat_completion_fixture().await;
        let tmp = tempfile::tempdir().expect("transport test temp dir");
        let (state, _) = production_sse_state(&tmp, &fixture.base_url(), 1.0, false);
        let (gateway_addr, gateway_server) = spawn_test_ws_gateway(state.clone()).await;
        let session_id = "transport.ws-to.sse";
        let session_key = gateway_cancel_key(session_id);

        // This URL connects only to the test's loopback listener. Keep the
        // scheme split so the static insecure-transport rule does not flag a
        // non-production fixture.
        let websocket_url = format!(
            "{}//{gateway_addr}/ws/chat?agent=web&session_id={session_id}",
            "ws:"
        );
        let (mut websocket, _) = connect_async(websocket_url)
            .await
            .expect("WS transport upgrade");
        let session_start = websocket
            .next()
            .await
            .expect("WS session_start frame")
            .expect("WS session_start transport");
        assert!(session_start.into_text().unwrap().contains("session_start"));
        websocket
            .send(ClientMessage::Text(r#"{"type":"connect"}"#.into()))
            .await
            .expect("WS connect frame");
        let connected = websocket
            .next()
            .await
            .expect("WS connected frame")
            .expect("WS connected transport");
        assert!(connected.into_text().unwrap().contains("connected"));
        websocket
            .send(ClientMessage::Text(
                r#"{"type":"message","content":"first transport"}"#.into(),
            ))
            .await
            .expect("WS chat frame");

        let ws_token = wait_for_registry_token(&state, &session_key).await;
        wait_for_fixture_requests(&fixture, 1).await;

        let sse_response = start_test_sse(&state, session_id).await;
        assert_eq!(sse_response.status(), StatusCode::OK);
        let sse_token = wait_for_registry_replacement(&state, &session_key, &ws_token).await;
        wait_for_fixture_requests(&fixture, 2).await;
        tokio::time::timeout(Duration::from_secs(3), ws_token.cancelled())
            .await
            .expect("SSE registration cancels the replaced WS turn");
        wait_for_registry_owner(&state, &session_key, &sse_token).await;

        // The dotted display id must resolve to the canonical key and cancel
        // the replacement SSE turn, not the original WebSocket turn.
        let abort_response = api::handle_api_session_abort(
            State(state.clone()),
            HeaderMap::new(),
            axum::extract::Path(session_id.to_string()),
        )
        .await
        .into_response();
        assert_eq!(abort_response.status(), StatusCode::OK);
        tokio::time::timeout(Duration::from_secs(3), sse_token.cancelled())
            .await
            .expect("abort endpoint cancels the replacement SSE turn");

        // Consume the body so its terminal error and owner-qualified cleanup run.
        let sse_text = collect_cancelled_sse(sse_response).await;
        assert!(
            sse_text.contains("event: error"),
            "SSE cancellation frame: {sse_text}"
        );
        assert!(
            !sse_text.contains("event: done"),
            "cancelled SSE must not complete: {sse_text}"
        );
        wait_for_registry_empty(&state, &session_key).await;

        drop(websocket);
        gateway_server.abort();
    }

    #[test]
    fn cancellation_transport_sse_to_ws_preserves_new_owner() {
        std::thread::Builder::new()
            .name("gateway-sse-to-ws-cancellation".to_string())
            .stack_size(8 * 1024 * 1024)
            .spawn(|| {
                tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                    .expect("test runtime")
                    .block_on(cancellation_transport_sse_to_ws_preserves_new_owner_inner());
            })
            .expect("spawn SSE-to-WS transport test thread")
            .join()
            .expect("SSE-to-WS transport test thread must not panic");
    }

    async fn cancellation_transport_sse_to_ws_preserves_new_owner_inner() {
        use futures_util::{SinkExt, StreamExt};
        use tokio_tungstenite::{connect_async, tungstenite::Message as ClientMessage};

        let fixture = spawn_hanging_chat_completion_fixture().await;
        let tmp = tempfile::tempdir().expect("transport test temp dir");
        let (state, _) = production_sse_state(&tmp, &fixture.base_url(), 1.0, false);
        let session_id = "transport-sse-to-ws";
        let session_key = format!("{GW_SESSION_PREFIX}{session_id}");

        let sse_response = start_test_sse(&state, session_id).await;
        assert_eq!(sse_response.status(), StatusCode::OK);
        let sse_token = wait_for_registry_token(&state, &session_key).await;
        wait_for_fixture_requests(&fixture, 1).await;

        let (gateway_addr, gateway_server) = spawn_test_ws_gateway(state.clone()).await;
        // This URL connects only to the test's loopback listener. Keep the
        // scheme split so the static insecure-transport rule does not flag a
        // non-production fixture.
        let websocket_url = format!(
            "{}//{gateway_addr}/ws/chat?agent=web&session_id={session_id}",
            "ws:"
        );
        let (mut websocket, _) = connect_async(websocket_url)
            .await
            .expect("WS transport upgrade");
        let session_start = websocket
            .next()
            .await
            .expect("WS session_start frame")
            .expect("WS session_start transport");
        assert!(session_start.into_text().unwrap().contains("session_start"));
        websocket
            .send(ClientMessage::Text(r#"{"type":"connect"}"#.into()))
            .await
            .expect("WS connect frame");
        let connected = websocket
            .next()
            .await
            .expect("WS connected frame")
            .expect("WS connected transport");
        assert!(connected.into_text().unwrap().contains("connected"));
        websocket
            .send(ClientMessage::Text(
                r#"{"type":"message","content":"replacement transport"}"#.into(),
            ))
            .await
            .expect("WS chat frame");

        let ws_token = wait_for_registry_replacement(&state, &session_key, &sse_token).await;
        wait_for_fixture_requests(&fixture, 2).await;
        tokio::time::timeout(Duration::from_secs(3), sse_token.cancelled())
            .await
            .expect("WS registration cancels the replaced SSE turn");
        wait_for_registry_owner(&state, &session_key, &ws_token).await;

        let sse_text = collect_cancelled_sse(sse_response).await;
        assert!(
            sse_text.contains("event: error"),
            "SSE cancellation frame: {sse_text}"
        );
        assert!(
            !sse_text.contains("event: done"),
            "cancelled SSE must not complete: {sse_text}"
        );

        // Cancel the replacement WS turn and verify that its cleanup removes
        // only its own registry entry after the old SSE cleanup has completed.
        ws_token.cancel();
        wait_for_registry_empty(&state, &session_key).await;

        drop(websocket);
        gateway_server.abort();
    }

    #[test]
    fn websocket_resumes_seeded_legacy_dotted_session_transcript() {
        std::thread::Builder::new()
            .name("gateway-ws-legacy-resume".to_string())
            .stack_size(8 * 1024 * 1024)
            .spawn(|| {
                tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                    .expect("test runtime")
                    .block_on(websocket_resumes_seeded_legacy_dotted_session_inner());
            })
            .expect("spawn WS legacy-resume test thread")
            .join()
            .expect("WS legacy-resume test thread must not panic");
    }

    async fn websocket_resumes_seeded_legacy_dotted_session_inner() {
        use futures_util::StreamExt;
        use tokio_tungstenite::connect_async;

        let tmp = tempfile::tempdir().expect("legacy-resume temp dir");
        let (mut state, _) =
            production_sse_state(&tmp, "http://127.0.0.1:9/v1/chat/completions", 1.0, false);
        let session_db = tempfile::tempdir().expect("legacy-resume session db");
        let backend: std::sync::Arc<dyn zeroclaw_infra::session_backend::SessionBackend> =
            std::sync::Arc::new(
                zeroclaw_infra::session_sqlite::SqliteSessionBackend::new(session_db.path())
                    .expect("sqlite session backend"),
            );
        // Seed the transcript under the legacy raw gateway key: dot-bearing
        // display ids persisted this exact key before cancellation keys were
        // normalized, so a reconnect must resume it unchanged.
        let legacy_key = format!("{GW_SESSION_PREFIX}{}", "transport.legacy-resume");
        backend
            .append(
                &legacy_key,
                &zeroclaw_providers::ChatMessage::user("seeded legacy turn"),
            )
            .expect("seed legacy transcript");
        state.session_backend = Some(backend);

        let (gateway_addr, gateway_server) = spawn_test_ws_gateway(state.clone()).await;
        let session_id = "transport.legacy-resume";
        // This URL connects only to the test's loopback listener. Keep the
        // scheme split so the static insecure-transport rule does not flag a
        // non-production fixture.
        let websocket_url = format!(
            "{}//{gateway_addr}/ws/chat?agent=web&session_id={session_id}",
            "ws:"
        );
        let (mut websocket, _) = connect_async(websocket_url)
            .await
            .expect("WS transport upgrade");
        let session_start = websocket
            .next()
            .await
            .expect("WS session_start frame")
            .expect("WS session_start transport")
            .into_text()
            .expect("session_start text");
        let session_start: serde_json::Value =
            serde_json::from_str(&session_start).expect("session_start json");
        assert_eq!(session_start["type"], "session_start");
        assert_eq!(
            session_start["resumed"], true,
            "legacy raw-key transcript must resume for a dotted display id"
        );
        assert_eq!(session_start["message_count"], 1);

        drop(websocket);
        gateway_server.abort();
    }

    #[test]
    fn websocket_delivers_api_injected_message_for_dotted_session() {
        std::thread::Builder::new()
            .name("gateway-ws-api-delivery".to_string())
            .stack_size(8 * 1024 * 1024)
            .spawn(|| {
                tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                    .expect("test runtime")
                    .block_on(websocket_delivers_api_injected_message_inner());
            })
            .expect("spawn WS api-delivery test thread")
            .join()
            .expect("WS api-delivery test thread must not panic");
    }

    async fn websocket_delivers_api_injected_message_inner() {
        use futures_util::{SinkExt, StreamExt};
        use tokio_tungstenite::{connect_async, tungstenite::Message as ClientMessage};

        let tmp = tempfile::tempdir().expect("api-delivery temp dir");
        let (mut state, _) =
            production_sse_state(&tmp, "http://127.0.0.1:9/v1/chat/completions", 1.0, false);
        let session_db = tempfile::tempdir().expect("api-delivery session db");
        state.session_backend = Some(std::sync::Arc::new(
            zeroclaw_infra::session_sqlite::SqliteSessionBackend::new(session_db.path())
                .expect("sqlite session backend"),
        )
            as std::sync::Arc<dyn zeroclaw_infra::session_backend::SessionBackend>);

        let (gateway_addr, gateway_server) = spawn_test_ws_gateway(state.clone()).await;
        let session_id = "transport.api-delivery";
        // This URL connects only to the test's loopback listener. Keep the
        // scheme split so the static insecure-transport rule does not flag a
        // non-production fixture.
        let websocket_url = format!(
            "{}//{gateway_addr}/ws/chat?agent=web&session_id={session_id}",
            "ws:"
        );
        let (mut websocket, _) = connect_async(websocket_url)
            .await
            .expect("WS transport upgrade");
        let _session_start = websocket
            .next()
            .await
            .expect("WS session_start frame")
            .expect("WS session_start transport");
        websocket
            .send(ClientMessage::Text(r#"{"type":"connect"}"#.into()))
            .await
            .expect("WS connect frame");
        let connected = websocket
            .next()
            .await
            .expect("WS connected frame")
            .expect("WS connected transport");
        assert!(connected.into_text().unwrap().contains("connected"));

        // The `connected` acknowledgement is sent before the WebSocket has
        // finished Agent setup and subscribed to the shared event channel.
        // Wait for that authoritative readiness signal before injecting an
        // API event; a fixed sleep would make this transport regression flaky.
        tokio::time::timeout(Duration::from_secs(3), async {
            while state.event_tx.receiver_count() == 0 {
                tokio::time::sleep(Duration::from_millis(10)).await;
            }
        })
        .await
        .expect("WS subscribes to shared event channel");

        // An API-injected message must broadcast with the display id the
        // connected socket filters on, so it reaches the live transport.
        let response = api::handle_api_session_message_post(
            State(state.clone()),
            HeaderMap::new(),
            axum::extract::Path(session_id.to_string()),
            axum::Json(
                serde_json::from_value::<api::SessionMessagePostBody>(serde_json::json!({
                    "content": "injected for dotted session"
                }))
                .expect("body should deserialize"),
            ),
        )
        .await
        .into_response();
        assert_eq!(response.status(), StatusCode::OK);

        let frame = tokio::time::timeout(Duration::from_secs(3), websocket.next())
            .await
            .expect("WS receives API-injected message event")
            .expect("WS message transport")
            .expect("WS message frame")
            .into_text()
            .expect("message text");
        let event: serde_json::Value = serde_json::from_str(&frame).expect("event json");
        assert_eq!(event["type"], "message");
        assert_eq!(
            event["session_id"], session_id,
            "API broadcasts must carry the display id the socket filters on"
        );
        assert_eq!(event["content"], "injected for dotted session");

        drop(websocket);
        gateway_server.abort();
    }

    #[test]
    fn sse_final_response_reconciliation_handles_empty_and_receipt_suffix() {
        let mut cumulative = String::new();
        let frame = reconcile_sse_final_response(&mut cumulative, "cached response")
            .expect("a no-chunk response must produce one token frame")
            .unwrap();
        let _ = frame;
        assert_eq!(cumulative, "cached response");

        let mut cumulative = "answer".to_string();
        let frame = reconcile_sse_final_response(&mut cumulative, "answer\n\n[receipt]")
            .expect("a final receipt suffix must be emitted")
            .unwrap();
        let _ = frame;
        assert_eq!(cumulative, "answer\n\n[receipt]");

        let mut cumulative = "already complete".to_string();
        assert!(reconcile_sse_final_response(&mut cumulative, "already complete").is_none());
        assert_eq!(cumulative, "already complete");

        let mut cumulative = "speculative streamed text".to_string();
        let frame = reconcile_sse_final_response(&mut cumulative, "authoritative final")
            .expect("a conflicting final response must replace streamed text")
            .unwrap();
        let _ = frame;
        assert_eq!(cumulative, "authoritative final");

        let mut cumulative = "authoritative final with stale suffix".to_string();
        let frame = reconcile_sse_final_response(&mut cumulative, "authoritative final")
            .expect("a shorter authoritative final must remove stale streamed text")
            .unwrap();
        let _ = frame;
        assert_eq!(cumulative, "authoritative final");

        let mut cumulative = "stale streamed text".to_string();
        let frame = reconcile_sse_final_response(&mut cumulative, "")
            .expect("an empty authoritative final must clear stale streamed text")
            .unwrap();
        let _ = frame;
        assert!(cumulative.is_empty());
    }

    #[test]
    fn cancellation_registry_preserves_sse_owner_when_ws_finishes() {
        let registry = Arc::new(std::sync::Mutex::new(HashMap::new()));
        let ws_token = Arc::new(tokio_util::sync::CancellationToken::new());
        let sse_token = Arc::new(tokio_util::sync::CancellationToken::new());

        register_cancel_token(&registry, "gw_cross_direction", Arc::clone(&ws_token));
        register_cancel_token(&registry, "gw_cross_direction", Arc::clone(&sse_token));
        remove_cancel_token_if_current(&registry, "gw_cross_direction", &ws_token);

        assert!(ws_token.is_cancelled());
        let current = registry
            .lock()
            .expect("cancel registry lock")
            .get("gw_cross_direction")
            .cloned()
            .expect("replacement SSE token remains registered");
        assert!(Arc::ptr_eq(&current, &sse_token));
        assert!(!sse_token.is_cancelled());
    }

    #[test]
    fn cancellation_registry_preserves_ws_owner_when_sse_finishes() {
        let registry = Arc::new(std::sync::Mutex::new(HashMap::new()));
        let sse_token = Arc::new(tokio_util::sync::CancellationToken::new());
        let ws_token = Arc::new(tokio_util::sync::CancellationToken::new());

        register_cancel_token(&registry, "gw_cross_direction", Arc::clone(&sse_token));
        register_cancel_token(&registry, "gw_cross_direction", Arc::clone(&ws_token));
        remove_cancel_token_if_current(&registry, "gw_cross_direction", &sse_token);

        assert!(sse_token.is_cancelled());
        let current = registry
            .lock()
            .expect("cancel registry lock")
            .get("gw_cross_direction")
            .cloned()
            .expect("replacement WS token remains registered");
        assert!(Arc::ptr_eq(&current, &ws_token));
        assert!(!ws_token.is_cancelled());
    }

    #[test]
    fn cancellation_registry_keeps_lossy_session_ids_separate() {
        let registry = Arc::new(std::sync::Mutex::new(HashMap::new()));
        let dotted_token = Arc::new(tokio_util::sync::CancellationToken::new());
        let underscored_token = Arc::new(tokio_util::sync::CancellationToken::new());

        register_cancel_token(
            &registry,
            &gateway_cancel_key("team.alpha"),
            Arc::clone(&dotted_token),
        );
        register_cancel_token(
            &registry,
            &gateway_cancel_key("team_alpha"),
            Arc::clone(&underscored_token),
        );

        assert!(!dotted_token.is_cancelled());
        assert!(!underscored_token.is_cancelled());
        assert_eq!(
            registry.lock().expect("cancel registry lock").len(),
            2,
            "distinct session ids must not share a cancellation entry"
        );
    }

    #[tokio::test]
    async fn webhook_idempotency_skips_duplicate_provider_calls() {
        let provider_impl = Arc::new(MockModelProvider::default());
        let model_provider: Arc<dyn ModelProvider> = provider_impl.clone();
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let mut headers = HeaderMap::new();
        headers.insert("X-Idempotency-Key", HeaderValue::from_static("abc-123"));

        let body = Ok(Json(WebhookBody {
            message: "hello".into(),
            stream: false,
            continue_on_disconnect: false,
        }));
        let first = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers.clone(),
            body,
        )
        .await
        .into_response();
        assert_eq!(first.status(), StatusCode::OK);

        let body = Ok(Json(WebhookBody {
            message: "hello".into(),
            stream: false,
            continue_on_disconnect: false,
        }));
        let second = handle_webhook(
            State(state),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            body,
        )
        .await
        .into_response();
        assert_eq!(second.status(), StatusCode::OK);

        let payload = second.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        assert_eq!(parsed["status"], "duplicate");
        assert_eq!(parsed["idempotent"], true);
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn sop_webhook_dispatches_matching_path_without_provider_call() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/sop/deploy");
        let (state, secret) = with_webhook_secret(state);
        let response = api_sop_webhook::handle_sop_webhook(
            State(state.clone()),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            webhook_secret_header(&secret),
            axum::body::Bytes::from_static(br#"{"revision":"abc123"}"#),
        )
        .await;

        assert_eq!(response.status(), StatusCode::OK);
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        assert_eq!(parsed["status"], "accepted");
        assert_eq!(parsed["path"], "/sop/deploy");
        assert_eq!(parsed["results"][0]["sop"], "webhook-test");
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);

        let run_id = parsed["results"][0]["run_id"].as_str().unwrap();
        let engine = state.sop_engine.as_ref().unwrap().lock().unwrap();
        let run = engine.get_run(run_id).unwrap();
        assert_eq!(
            run.trigger_event.source,
            zeroclaw_runtime::sop::SopTriggerSource::Webhook
        );
        assert_eq!(run.trigger_event.topic.as_deref(), Some("/sop/deploy"));
        assert_eq!(
            run.trigger_event.payload.as_deref(),
            Some(r#"{"revision":"abc123"}"#)
        );
    }

    #[tokio::test]
    async fn sop_webhook_route_reaches_the_shared_dispatch_handler() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/sop/deploy");
        let (state, secret) = with_webhook_secret(state);
        let app = sop_webhook_routes().with_state(state);
        let mut request = axum::http::Request::post("/sop/deploy")
            .header(axum::http::header::CONTENT_TYPE, "application/json")
            .header("X-Webhook-Secret", secret)
            .body(axum::body::Body::from(r#"{"revision":"abc123"}"#))
            .unwrap();
        request.extensions_mut().insert(test_connect_info());

        let response = app.oneshot(request).await.unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    async fn post_sop_route_without_credentials(
        state: AppState,
        path: &'static str,
        body: &'static [u8],
    ) -> (StatusCode, serde_json::Value) {
        let app = sop_webhook_routes().with_state(state);
        let mut request = axum::http::Request::post(path)
            .header(axum::http::header::CONTENT_TYPE, "application/json")
            .body(axum::body::Body::from(body))
            .unwrap();
        request.extensions_mut().insert(test_connect_info());
        let response = app.oneshot(request).await.unwrap();
        let status = response.status();
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        (status, serde_json::from_slice(&payload).unwrap())
    }

    #[tokio::test]
    async fn sop_route_without_credentials_hides_body_and_engine_state() {
        let tmp = tempfile::tempdir().unwrap();
        let (matching, provider) = webhook_sop_state(&tmp, "/sop/deploy");
        let unavailable_tmp = tempfile::tempdir().unwrap();
        let unavailable = admin_paircode_state(&unavailable_tmp, false, false);

        let cases = [
            post_sop_route_without_credentials(
                matching.clone(),
                "/sop/deploy",
                br#"{"revision":"abc123"}"#,
            )
            .await,
            post_sop_route_without_credentials(
                matching.clone(),
                "/sop/missing",
                br#"{"revision":"abc123"}"#,
            )
            .await,
            post_sop_route_without_credentials(matching, "/sop/deploy", b"not-json").await,
            post_sop_route_without_credentials(unavailable, "/sop/deploy", br#"{}"#).await,
        ];

        let expected_error = cases[0].1["error"].clone();
        for (status, payload) in cases {
            assert_eq!(status, StatusCode::UNAUTHORIZED);
            assert_eq!(
                payload["error"], expected_error,
                "credential failure must not reveal JSON validity, trigger matches, or engine availability"
            );
        }
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn sop_webhook_rejects_unmatched_and_invalid_requests_without_chat_fallback() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/sop/deploy");
        let (state, secret) = with_webhook_secret(state);

        let unmatched = api_sop_webhook::handle_sop_webhook(
            State(state.clone()),
            test_connect_info(),
            axum::extract::Path("missing".to_string()),
            webhook_secret_header(&secret),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(unmatched.status(), StatusCode::NOT_FOUND);

        let invalid = api_sop_webhook::handle_sop_webhook(
            State(state),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            webhook_secret_header(&secret),
            axum::body::Bytes::from_static(b"not-json"),
        )
        .await;
        assert_eq!(invalid.status(), StatusCode::BAD_REQUEST);
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn sop_webhook_requires_shared_engine_and_webhook_auth() {
        let disabled_tmp = tempfile::tempdir().unwrap();
        let disabled = admin_paircode_state(&disabled_tmp, false, false);
        let (disabled, secret) = with_webhook_secret(disabled);
        let unavailable = api_sop_webhook::handle_sop_webhook(
            State(disabled),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            webhook_secret_header(&secret),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(unavailable.status(), StatusCode::SERVICE_UNAVAILABLE);

        let protected_tmp = tempfile::tempdir().unwrap();
        let (protected, provider) = webhook_sop_state(&protected_tmp, "/sop/deploy");
        let secret = generate_test_secret();
        protected.publish_test_config(|c| c.gateway.webhook_secret = Some(secret));
        let unauthorized = api_sop_webhook::handle_sop_webhook(
            State(protected),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            HeaderMap::new(),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(unauthorized.status(), StatusCode::UNAUTHORIZED);
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn webhook_dispatches_sop_first_then_falls_back_to_chat_on_no_match() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/webhook");
        let (state, secret) = with_webhook_secret(state);
        let sop_response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            webhook_secret_header(&secret),
            Ok(Json(WebhookBody {
                message: "deploy".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();
        assert_eq!(sop_response.status(), StatusCode::OK);
        let payload = sop_response.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        assert_eq!(parsed["status"], "accepted");
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);

        let no_match_tmp = tempfile::tempdir().unwrap();
        let (no_match_state, fallback_provider) = webhook_sop_state(&no_match_tmp, "/sop/only");
        let fallback_response = handle_webhook(
            State(no_match_state),
            test_connect_info(),
            Query(WebhookQuery::default()),
            HeaderMap::new(),
            Ok(Json(WebhookBody {
                message: "chat instead".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();
        assert_eq!(fallback_response.status(), StatusCode::OK);
        assert_eq!(fallback_provider.calls.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn sop_and_chat_webhook_idempotency_namespaces_do_not_collide() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/sop/deploy");
        let (state, secret) = with_webhook_secret(state);
        let mut headers = webhook_secret_header(&secret);
        headers.insert("X-Idempotency-Key", HeaderValue::from_static("same-key"));

        let sop_response = api_sop_webhook::handle_sop_webhook(
            State(state.clone()),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            headers.clone(),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(sop_response.status(), StatusCode::OK);

        let chat_response = handle_webhook(
            State(state),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "chat".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();
        assert_eq!(chat_response.status(), StatusCode::OK);
        assert_eq!(provider.calls.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn sop_idempotency_namespaced_per_path() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_two_sop_state(&tmp, "/sop/deploy", "/sop/rollback");
        let (state, secret) = with_webhook_secret(state);
        let mut headers = webhook_secret_header(&secret);
        headers.insert("X-Idempotency-Key", HeaderValue::from_static("same-key"));

        // Same key, two different SOP paths: both execute.
        let deploy_response = api_sop_webhook::handle_sop_webhook(
            State(state.clone()),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            headers.clone(),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(deploy_response.status(), StatusCode::OK);
        let deploy_payload = deploy_response
            .into_body()
            .collect()
            .await
            .unwrap()
            .to_bytes();
        let deploy_parsed: serde_json::Value = serde_json::from_slice(&deploy_payload).unwrap();
        assert_eq!(deploy_parsed["status"], "accepted");

        let rollback_response = api_sop_webhook::handle_sop_webhook(
            State(state.clone()),
            test_connect_info(),
            axum::extract::Path("rollback".to_string()),
            headers.clone(),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(rollback_response.status(), StatusCode::OK);
        let rollback_payload = rollback_response
            .into_body()
            .collect()
            .await
            .unwrap()
            .to_bytes();
        let rollback_parsed: serde_json::Value = serde_json::from_slice(&rollback_payload).unwrap();
        assert_eq!(rollback_parsed["status"], "accepted");

        // Same key, same path again: the second call is suppressed as a duplicate.
        let repeat_response = api_sop_webhook::handle_sop_webhook(
            State(state),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            headers,
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(repeat_response.status(), StatusCode::OK);
        let repeat_payload = repeat_response
            .into_body()
            .collect()
            .await
            .unwrap()
            .to_bytes();
        let repeat_parsed: serde_json::Value = serde_json::from_slice(&repeat_payload).unwrap();
        assert_eq!(repeat_parsed["status"], "duplicate");
        assert_eq!(repeat_parsed["idempotent"], true);
        assert!(
            repeat_parsed["message"]
                .as_str()
                .unwrap_or_default()
                .contains("no new dispatch was started"),
            "duplicate response must describe reservation, not claim successful processing"
        );

        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    /// Count SOP runs the engine has ever started (active + finished), so a
    /// race test can prove *no run was started*, not merely that the HTTP
    /// status was 401.
    fn started_run_count(state: &AppState) -> usize {
        let engine = state.sop_engine.as_ref().expect("engine").lock().unwrap();
        engine.active_runs().len() + engine.run_summaries(None).len()
    }

    /// B1 insertion race: pairing disabled and no secret configured, so a
    /// headerless request is authorized against an "unconfigured" snapshot.
    /// An operator then writes `gateway.webhook_secret` into the live config
    /// *after* authorization but before dispatch. The old two-read design would
    /// see a configured control on the second read and admit a request that
    /// presented nothing; the request-scoped verdict must reject it.
    #[tokio::test]
    async fn sop_dispatch_uses_authorization_snapshot_when_secret_added_midrequest() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/sop/deploy");

        // Read #1: no control configured at all.
        let verdict = authorize_webhook_request(&state, test_connect_info().0, &HeaderMap::new())
            .expect("no configured control -> authorization itself passes");

        // Concurrent operator action lands between authorization and dispatch.
        state.publish_test_config(|c| c.gateway.webhook_secret = Some(generate_test_secret()));

        // The dispatch decision must come from the snapshot, not the new config.
        let rejection = require_sop_dispatch_credentials(verdict)
            .expect_err("a request that presented no credential must not dispatch a SOP");
        assert_eq!(rejection.0, StatusCode::UNAUTHORIZED);

        // And end-to-end through the route: the headerless caller now fails the
        // (newly configured) secret check outright and still starts no run.
        let response = api_sop_webhook::handle_sop_webhook(
            State(state.clone()),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            HeaderMap::new(),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        assert_eq!(
            started_run_count(&state),
            0,
            "no SOP run may start for a request that presented no credential"
        );
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    /// B1 rotation race: secret A is configured and the caller presents A, so
    /// read #1 verifies genuinely. The live config then rotates to secret B
    /// before dispatch. The in-flight request is judged on its own snapshot
    /// (accepted), while rotation takes effect at *next*-request granularity:
    /// a subsequent A request is rejected and a B request is accepted.
    #[tokio::test]
    async fn sop_dispatch_uses_authorization_snapshot_during_secret_rotation() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, _provider) = webhook_sop_state(&tmp, "/sop/deploy");
        let secret_a = generate_test_secret();
        state.publish_test_config(|c| c.gateway.webhook_secret = Some(secret_a.clone()));

        let verdict = authorize_webhook_request(
            &state,
            test_connect_info().0,
            &webhook_secret_header(&secret_a),
        )
        .expect("the presented secret matches the live policy at read #1");

        // Rotation lands between authorization and dispatch.
        let secret_b = generate_test_secret();
        state.publish_test_config(|c| c.gateway.webhook_secret = Some(secret_b.clone()));

        assert!(
            require_sop_dispatch_credentials(verdict).is_ok(),
            "a request that genuinely verified its snapshot's secret keeps that verdict"
        );

        // Next-request granularity: the retired secret is now rejected...
        assert!(
            authorize_webhook_request(
                &state,
                test_connect_info().0,
                &webhook_secret_header(&secret_a),
            )
            .is_err(),
            "a subsequent request bearing the retired secret must be rejected"
        );
        // ...and the replacement is accepted and may dispatch.
        let rotated = authorize_webhook_request(
            &state,
            test_connect_info().0,
            &webhook_secret_header(&secret_b),
        )
        .expect("the rotated secret authorizes the next request");
        assert!(require_sop_dispatch_credentials(rotated).is_ok());
    }

    /// B1 on `/webhook`, where body parsing and trigger matching sit between
    /// authorization and the dispatch credential check — the widest window.
    /// A headerless request must not become dispatchable because a secret was
    /// inserted while the body was being parsed.
    #[tokio::test]
    async fn webhook_path_snapshot_survives_body_parse_and_trigger_match() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/webhook");

        let verdict = authorize_webhook_request(&state, test_connect_info().0, &HeaderMap::new())
            .expect("no configured control -> authorization itself passes");

        // Simulate the parse/match window: config mutates before dispatch.
        assert!(
            api_sop_webhook::has_matching_webhook_sop(&state, "/webhook").unwrap(),
            "fixture must load a matching /webhook trigger"
        );
        state.publish_test_config(|c| c.gateway.webhook_secret = Some(generate_test_secret()));

        assert!(
            require_sop_dispatch_credentials(verdict).is_err(),
            "the /webhook SOP branch must judge the snapshot, not the mutated config"
        );

        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            HeaderMap::new(),
            Ok(Json(WebhookBody {
                message: "deploy".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        assert_eq!(
            started_run_count(&state),
            0,
            "no SOP run may start on the /webhook path either"
        );
        assert_eq!(
            provider.calls.load(Ordering::SeqCst),
            0,
            "and it must not silently fall back to the chat/model path"
        );
    }

    /// B1 purity: the dispatch gate decides only from the request-scoped
    /// verdict. Two verdict values with identical contents must produce
    /// identical decisions regardless of what the live config says, which is
    /// only possible because the function never touches `AppState`.
    #[tokio::test]
    async fn require_sop_dispatch_credentials_is_pure_over_verdict() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, _provider) = webhook_sop_state(&tmp, "/sop/deploy");

        let unconfigured =
            authorize_webhook_request(&state, test_connect_info().0, &HeaderMap::new())
                .expect("no control configured");
        let before = require_sop_dispatch_credentials(unconfigured).is_ok();

        // Flip the live config to the opposite policy in every way we can.
        state.publish_test_config(|c| c.gateway.webhook_secret = Some(generate_test_secret()));
        let after = require_sop_dispatch_credentials(unconfigured).is_ok();

        assert_eq!(
            before, after,
            "the decision must depend only on the verdict, never on live state"
        );
        assert!(!before, "an unconfigured snapshot must fail closed");
    }

    /// B2: the replay-domain encoding must be injective. Every one of these
    /// pairs collides under the old `format!("{namespace}:{key}")` join, which
    /// let an authenticated caller suppress a *different* attempt.
    #[test]
    fn idempotency_storage_key_encoding_is_injective() {
        // Adversarial cross-path: `/sop/a` + `b:c` vs `/sop/a:b` + `c`.
        assert_ne!(
            idempotency_storage_key(Some("sop:/sop/a"), "b:c"),
            idempotency_storage_key(Some("sop:/sop/a:b"), "c"),
            "a caller must not shift bytes across the namespace/key boundary"
        );
        // `/webhook` (global domain) vs `/sop/*`: a forged caller key must not
        // alias a namespaced SOP key.
        assert_ne!(
            idempotency_storage_key(None, "sop:/sop/deploy:k"),
            idempotency_storage_key(Some("sop:/sop/deploy"), "k"),
            "/webhook keys must never collide with /sop/* keys"
        );
        // Empty-component edge cases stay distinct too.
        assert_ne!(
            idempotency_storage_key(Some(""), "x"),
            idempotency_storage_key(Some("x"), ""),
        );
        // The encoding is still deterministic and path-discriminating.
        assert_eq!(
            idempotency_storage_key(Some("sop:/sop/deploy"), "k"),
            idempotency_storage_key(Some("sop:/sop/deploy"), "k"),
        );
        assert_ne!(
            idempotency_storage_key(Some("sop:/sop/deploy"), "k"),
            idempotency_storage_key(Some("sop:/sop/rollback"), "k"),
            "distinct SOP paths must remain distinct",
        );
    }

    /// B2 end-to-end: two different SOP paths whose `(path, key)` pairs collide
    /// under the old join must both dispatch. `/sop/a` with `X-Idempotency-Key:
    /// b:c` and `/sop/a:b` with key `c` are genuinely different requests.
    #[tokio::test]
    async fn sop_idempotency_resists_adversarial_cross_path_collision() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, _provider) = webhook_two_sop_state(&tmp, "/sop/a", "/sop/a:b");
        let (state, secret) = with_webhook_secret(state);
        let mut headers = webhook_secret_header(&secret);
        headers.insert("X-Idempotency-Key", HeaderValue::from_static("b:c"));
        let mut second_headers = webhook_secret_header(&secret);
        second_headers.insert("X-Idempotency-Key", HeaderValue::from_static("c"));

        let first = api_sop_webhook::handle_sop_webhook(
            State(state.clone()),
            test_connect_info(),
            axum::extract::Path("a".to_string()),
            headers,
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(first.status(), StatusCode::OK);
        let first_parsed: serde_json::Value =
            serde_json::from_slice(&first.into_body().collect().await.unwrap().to_bytes()).unwrap();
        assert_eq!(first_parsed["status"], "accepted");

        let second = api_sop_webhook::handle_sop_webhook(
            State(state),
            test_connect_info(),
            axum::extract::Path("a:b".to_string()),
            second_headers,
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(second.status(), StatusCode::OK);
        let second_parsed: serde_json::Value =
            serde_json::from_slice(&second.into_body().collect().await.unwrap().to_bytes())
                .unwrap();
        assert_eq!(
            second_parsed["status"], "accepted",
            "a colliding-by-concatenation key must not suppress a different SOP path"
        );
    }

    /// B2 end-to-end across endpoints: a `/webhook` caller who forges the SOP
    /// namespace prefix into their own key must not reserve the `/sop/deploy`
    /// replay slot and suppress the real SOP request.
    #[tokio::test]
    async fn webhook_forged_namespace_key_cannot_suppress_sop_dispatch() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, _provider) = webhook_two_sop_state(&tmp, "/webhook", "/sop/deploy");
        let (state, secret) = with_webhook_secret(state);

        // `/webhook` caller forges the `/sop/deploy` storage key.
        let mut forged = webhook_secret_header(&secret);
        forged.insert(
            "X-Idempotency-Key",
            HeaderValue::from_static("sop:/sop/deploy:k"),
        );
        let chat = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            forged,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();
        assert_eq!(chat.status(), StatusCode::OK);

        // The genuine `/sop/deploy` request with key `k` must still dispatch.
        let mut sop_headers = webhook_secret_header(&secret);
        sop_headers.insert("X-Idempotency-Key", HeaderValue::from_static("k"));
        let sop = api_sop_webhook::handle_sop_webhook(
            State(state),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            sop_headers,
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(sop.status(), StatusCode::OK);
        let parsed: serde_json::Value =
            serde_json::from_slice(&sop.into_body().collect().await.unwrap().to_bytes()).unwrap();
        assert_eq!(
            parsed["status"], "accepted",
            "a forged /webhook key must not reserve a /sop/* replay slot"
        );
    }

    /// B2 property test: `idempotency_storage_key` must be injective over the
    /// whole `(namespace, caller_key)` space, not just the two collisions the
    /// reviewers happened to name. Exhaustively cross-products adversarial
    /// components that are rich in the separator character and asserts distinct
    /// inputs never share an encoding.
    #[test]
    fn idempotency_storage_key_is_injective_over_adversarial_inputs() {
        let namespaces = [
            None,
            Some(""),
            Some(":"),
            Some("sop:/sop/a"),
            Some("sop:/sop/a:b"),
            Some("sop:/sop/a:b:c"),
            Some("sop:/sop/deploy"),
            Some("1:x"),
            Some("global"),
            Some("ns"),
        ];
        let caller_keys = ["", ":", "b:c", "c", "k", "sop:/sop/deploy:k", "1:x", "ns"];

        let mut seen: std::collections::HashMap<String, (Option<&str>, &str)> =
            std::collections::HashMap::new();
        for namespace in namespaces {
            for caller_key in caller_keys {
                let encoded = idempotency_storage_key(namespace, caller_key);
                if let Some(previous) = seen.insert(encoded.clone(), (namespace, caller_key)) {
                    assert_eq!(
                        previous,
                        (namespace, caller_key),
                        "encoding collision: {previous:?} and {:?} both map to {encoded}",
                        (namespace, caller_key),
                    );
                }
            }
        }
        assert_eq!(
            seen.len(),
            namespaces.len() * caller_keys.len(),
            "every distinct (namespace, caller_key) pair must have a distinct encoding"
        );
    }

    /// B2 counterpart: injectivity must not have broken the *intended*
    /// duplicate suppression — the same path with the same key is still a replay.
    #[tokio::test]
    async fn sop_idempotency_same_path_same_key_still_suppresses() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, _provider) = webhook_sop_state(&tmp, "/sop/deploy");
        let (state, secret) = with_webhook_secret(state);
        let mut headers = webhook_secret_header(&secret);
        headers.insert("X-Idempotency-Key", HeaderValue::from_static("dup-key"));

        let first = api_sop_webhook::handle_sop_webhook(
            State(state.clone()),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            headers.clone(),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(first.status(), StatusCode::OK);
        let first_parsed: serde_json::Value =
            serde_json::from_slice(&first.into_body().collect().await.unwrap().to_bytes()).unwrap();
        assert_eq!(first_parsed["status"], "accepted");

        let second = api_sop_webhook::handle_sop_webhook(
            State(state),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            headers,
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;
        assert_eq!(second.status(), StatusCode::OK);
        let second_parsed: serde_json::Value =
            serde_json::from_slice(&second.into_body().collect().await.unwrap().to_bytes())
                .unwrap();
        assert_eq!(
            second_parsed["status"], "duplicate",
            "the intended same-path same-key replay suppression must survive the new encoding"
        );
    }

    #[tokio::test]
    async fn sop_dispatch_rejected_when_no_credentials_configured() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/sop/deploy");

        let response = api_sop_webhook::handle_sop_webhook(
            State(state),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            HeaderMap::new(),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;

        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        let error = parsed["error"].as_str().unwrap_or_default();
        assert!(error.contains("require_pairing"), "error was: {error}");
        assert!(error.contains("X-Webhook-Secret"), "error was: {error}");
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn webhook_sop_dispatch_rejected_when_no_credentials_configured() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/webhook");

        let response = handle_webhook(
            State(state),
            test_connect_info(),
            Query(WebhookQuery::default()),
            HeaderMap::new(),
            Ok(Json(WebhookBody {
                message: "deploy".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        let error = parsed["error"].as_str().unwrap_or_default();
        assert!(error.contains("require_pairing"), "error was: {error}");
        assert!(error.contains("X-Webhook-Secret"), "error was: {error}");
        // Rejected outright — a matching SOP with no configured credential
        // must never silently fall back to the chat/model path.
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn sop_dispatch_succeeds_with_paired_bearer_token() {
        let tmp = tempfile::tempdir().unwrap();
        let (mut state, provider) = webhook_sop_state(&tmp, "/sop/deploy");
        // A plaintext (not pre-hashed) token: `PairingGuard::new` treats a
        // bare 64-hex-char value as an already-hashed token, so a "zc_"
        // prefix keeps this one unambiguously plaintext.
        let token = format!("zc_{}", generate_test_secret());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            std::slice::from_ref(&token),
            PairingCodePolicy::default(),
        ));

        let response = api_sop_webhook::handle_sop_webhook(
            State(state),
            test_connect_info(),
            axum::extract::Path("deploy".to_string()),
            bearer_headers(&token),
            axum::body::Bytes::from_static(br#"{}"#),
        )
        .await;

        assert_eq!(response.status(), StatusCode::OK);
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        assert_eq!(parsed["status"], "accepted");
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn webhook_sop_first_ignores_bogus_chat_agent_query_param() {
        let tmp = tempfile::tempdir().unwrap();
        let (state, provider) = webhook_sop_state(&tmp, "/webhook");
        let (state, secret) = with_webhook_secret(state);

        let response = handle_webhook(
            State(state),
            test_connect_info(),
            Query(WebhookQuery {
                agent: Some("missing".into()),
            }),
            webhook_secret_header(&secret),
            Ok(Json(WebhookBody {
                message: "deploy".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();

        // A matching SOP dispatches even though `?agent=missing` has no
        // `[agents.missing]` entry — the chat-only param is never inspected.
        assert_eq!(response.status(), StatusCode::OK);
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        assert_eq!(parsed["status"], "accepted");
        assert_eq!(parsed["source"], "webhook");
        // The model provider is never touched.
        assert_eq!(provider.calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn webhook_unknown_agent_rejected_before_dispatch() {
        let provider_impl = Arc::new(MockModelProvider::default());
        let model_provider: Arc<dyn ModelProvider> = provider_impl.clone();
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        // An idempotency key on a rejected request must NOT be consumed.
        let mut headers = HeaderMap::new();
        headers.insert("X-Idempotency-Key", HeaderValue::from_static("ghost-key"));

        let response = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery {
                agent: Some("ghost".into()),
            }),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();
        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        assert!(
            parsed["error"]
                .as_str()
                .unwrap_or_default()
                .contains("Unknown agent `ghost`")
        );
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 0);
        // Key still fresh — a corrected retry with the same key proceeds.
        assert!(state.idempotency_store.record_if_new("ghost-key"));
    }

    #[tokio::test]
    async fn webhook_explicit_agent_reports_model_without_owning_lifecycle() {
        let provider_impl = Arc::new(MockModelProvider::default());
        let model_provider: Arc<dyn ModelProvider> = provider_impl.clone();
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);
        let observer_impl = Arc::new(CapturingObserver::default());
        let observer: Arc<dyn zeroclaw_runtime::observability::Observer> = observer_impl.clone();

        let mut config = Config::default();
        config.providers.models.anthropic.insert(
            "default".into(),
            zeroclaw_config::schema::AnthropicModelProviderConfig {
                base: zeroclaw_config::schema::ModelProviderConfig {
                    model: Some("agent-model".into()),
                    ..Default::default()
                },
                ..Default::default()
            },
        );
        let expected_provider = "anthropic.default".to_string();
        config.agents.insert(
            "nova".to_string(),
            zeroclaw_config::schema::AliasedAgentConfig {
                enabled: true,
                model_provider: expected_provider.clone().into(),
                ..Default::default()
            },
        );

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(config);
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "startup-model".into(),
            temperature: None,
            mem: memory,
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::new(MockMemory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer,
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let response = handle_webhook(
            State(state),
            test_connect_info(),
            Query(WebhookQuery {
                agent: Some("nova".into()),
            }),
            HeaderMap::new(),
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();
        assert_eq!(response.status(), StatusCode::OK);
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 1);
        let payload = response.into_body().collect().await.unwrap().to_bytes();
        let parsed: serde_json::Value = serde_json::from_slice(&payload).unwrap();
        assert_eq!(parsed["model"], "agent-model");
        let events = observer_impl.events.lock();
        assert!(
            !events.iter().any(|event| matches!(
                event,
                zeroclaw_runtime::observability::ObserverEvent::AgentStart { .. }
                    | zeroclaw_runtime::observability::ObserverEvent::AgentEnd { .. }
                    | zeroclaw_runtime::observability::ObserverEvent::LlmRequest { .. }
                    | zeroclaw_runtime::observability::ObserverEvent::LlmResponse { .. }
            )),
            "the HTTP handler must not create a second agent lifecycle; events were: {events:?}"
        );
    }

    #[tokio::test]
    async fn webhook_autosave_stores_distinct_keys_per_request() {
        let provider_impl = Arc::new(MockModelProvider::default());
        let model_provider: Arc<dyn ModelProvider> = provider_impl.clone();

        let tracking_impl = Arc::new(TrackingMemory::default());
        let memory: Arc<dyn Memory> = tracking_impl.clone();

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory,
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::new(MockMemory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: true,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let headers = HeaderMap::new();

        let body1 = Ok(Json(WebhookBody {
            message: "hello one".into(),
            stream: false,
            continue_on_disconnect: false,
        }));
        let first = handle_webhook(
            State(state.clone()),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers.clone(),
            body1,
        )
        .await
        .into_response();
        assert_eq!(first.status(), StatusCode::OK);

        let body2 = Ok(Json(WebhookBody {
            message: "hello two".into(),
            stream: false,
            continue_on_disconnect: false,
        }));
        let second = handle_webhook(
            State(state),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            body2,
        )
        .await
        .into_response();
        assert_eq!(second.status(), StatusCode::OK);

        let keys = tracking_impl.keys.lock().clone();
        assert_eq!(keys.len(), 2);
        assert_ne!(keys[0], keys[1]);
        assert!(keys[0].starts_with("webhook_msg_"));
        assert!(keys[1].starts_with("webhook_msg_"));
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 2);
    }

    #[test]
    fn webhook_secret_hash_is_deterministic_and_nonempty() {
        let secret_a = generate_test_secret();
        let secret_b = generate_test_secret();
        let one = hash_webhook_secret(&secret_a);
        let two = hash_webhook_secret(&secret_a);
        let other = hash_webhook_secret(&secret_b);

        assert_eq!(one, two);
        assert_ne!(one, other);
        assert_eq!(one.len(), 64);
    }

    #[test]
    fn gateway_webhook_secret_uses_one_live_config_owner() {
        let tmp = tempfile::tempdir().unwrap();
        let state = admin_paircode_state(&tmp, false, false);
        state.publish_test_config(|config| {
            config.channels.webhook.insert(
                "enabled-a".into(),
                zeroclaw_config::schema::WebhookConfig {
                    enabled: true,
                    secret: Some("channel-secret-a".into()),
                    ..Default::default()
                },
            );
            config.channels.webhook.insert(
                "enabled-b".into(),
                zeroclaw_config::schema::WebhookConfig {
                    enabled: true,
                    secret: Some("channel-secret-b".into()),
                    ..Default::default()
                },
            );
            config.channels.webhook.insert(
                "disabled".into(),
                zeroclaw_config::schema::WebhookConfig {
                    enabled: false,
                    secret: Some("disabled-channel-secret".into()),
                    ..Default::default()
                },
            );
        });
        assert_eq!(
            configured_gateway_webhook_secret_hash(&state),
            None,
            "channel listener aliases must never become gateway credentials"
        );
        assert!(
            authorize_webhook_request(&state, test_connect_info().0, &HeaderMap::new())
                .map(require_sop_dispatch_credentials)
                .is_ok_and(|dispatch| dispatch.is_err()),
            "multiple channel aliases without a gateway credential must fail closed"
        );

        let startup_secret = "synthetic-startup-gateway-secret".to_string();
        state.publish_test_config(|c| c.gateway.webhook_secret = Some(startup_secret.clone()));
        assert!(
            authorize_webhook_request(
                &state,
                test_connect_info().0,
                &webhook_secret_header("channel-secret-a"),
            )
            .is_err(),
            "an enabled channel alias secret must not authorize the gateway"
        );
        assert!(
            authorize_webhook_request(
                &state,
                test_connect_info().0,
                &webhook_secret_header(&startup_secret),
            )
            .is_ok()
        );

        let rotated_secret = "synthetic-rotated-gateway-secret".to_string();
        state.publish_test_config(|c| c.gateway.webhook_secret = Some(rotated_secret.clone()));
        assert!(
            authorize_webhook_request(
                &state,
                test_connect_info().0,
                &webhook_secret_header(&startup_secret),
            )
            .is_err(),
            "authorization must not retain a startup snapshot after config replacement"
        );
        assert!(
            authorize_webhook_request(
                &state,
                test_connect_info().0,
                &webhook_secret_header(&rotated_secret),
            )
            .is_ok(),
            "the live canonical gateway credential must take effect"
        );
    }

    #[tokio::test]
    async fn webhook_secret_hash_rejects_missing_header() {
        let provider_impl = Arc::new(MockModelProvider::default());
        let model_provider: Arc<dyn ModelProvider> = provider_impl.clone();
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);
        let secret = generate_test_secret();
        let mut config = Config::default();
        config.gateway.webhook_secret = Some(secret.clone());

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(config);
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let response = handle_webhook(
            State(state),
            test_connect_info(),
            Query(WebhookQuery::default()),
            HeaderMap::new(),
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn webhook_secret_hash_rejects_invalid_header() {
        let provider_impl = Arc::new(MockModelProvider::default());
        let model_provider: Arc<dyn ModelProvider> = provider_impl.clone();
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);
        let valid_secret = generate_test_secret();
        let wrong_secret = generate_test_secret();
        let mut config = Config::default();
        config.gateway.webhook_secret = Some(valid_secret.clone());

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(config);
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Webhook-Secret",
            HeaderValue::from_str(&wrong_secret).unwrap(),
        );

        let response = handle_webhook(
            State(state),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn webhook_secret_hash_accepts_valid_header() {
        let provider_impl = Arc::new(MockModelProvider::default());
        let model_provider: Arc<dyn ModelProvider> = provider_impl.clone();
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);
        let secret = generate_test_secret();
        let mut config = Config::default();
        config.gateway.webhook_secret = Some(secret.clone());

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(config);
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let mut headers = HeaderMap::new();
        headers.insert("X-Webhook-Secret", HeaderValue::from_str(&secret).unwrap());

        let response = handle_webhook(
            State(state),
            test_connect_info(),
            Query(WebhookQuery::default()),
            headers,
            Ok(Json(WebhookBody {
                message: "hello".into(),
                stream: false,
                continue_on_disconnect: false,
            })),
        )
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::OK);
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 1);
    }

    #[cfg(feature = "channel-nextcloud")]
    fn compute_nextcloud_signature_hex(secret: &str, random: &str, body: &str) -> String {
        use hmac::{Hmac, Mac};
        use sha2::Sha256;

        let payload = format!("{random}{body}");
        let mut mac = Hmac::<Sha256>::new_from_slice(secret.as_bytes()).unwrap();
        mac.update(payload.as_bytes());
        hex::encode(mac.finalize().into_bytes())
    }

    #[cfg(feature = "channel-nextcloud")]
    #[tokio::test]
    async fn nextcloud_talk_webhook_returns_not_found_when_not_configured() {
        let model_provider: Arc<dyn ModelProvider> = Arc::new(MockModelProvider::default());
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let response = Box::pin(handle_nextcloud_talk_webhook(
            State(state),
            HeaderMap::new(),
            Bytes::from_static(br#"{"type":"message"}"#),
        ))
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::NOT_FOUND);
    }

    #[cfg(feature = "channel-nextcloud")]
    #[tokio::test]
    async fn nextcloud_talk_webhook_rejects_invalid_signature() {
        let provider_impl = Arc::new(MockModelProvider::default());
        let model_provider: Arc<dyn ModelProvider> = provider_impl.clone();
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);

        let alias = "nextcloud_talk_test_alias";
        let peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync> = Arc::new(Vec::new);
        let channel = Arc::new(NextcloudTalkChannel::new(
            "https://cloud.example.com".into(),
            None,
            String::new(),
            alias,
            peer_resolver,
        ));

        let secret = "nextcloud-test-secret";
        let random = "seed-value";
        let body = r#"{"type":"message","object":{"token":"room-token"},"message":{"actorType":"users","actorId":"user_a","message":"hello"}}"#;
        let _valid_signature = compute_nextcloud_signature_hex(secret, random, body);
        let invalid_signature = "deadbeef";

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            nextcloud_talk: HashMap::from([(alias.to_string(), channel)]),
            nextcloud_talk_webhook_secret: HashMap::from([(alias.to_string(), Arc::from(secret))]),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Nextcloud-Talk-Random",
            HeaderValue::from_str(random).unwrap(),
        );
        headers.insert(
            "X-Nextcloud-Talk-Signature",
            HeaderValue::from_str(invalid_signature).unwrap(),
        );

        let response = Box::pin(handle_nextcloud_talk_webhook(
            State(state),
            headers,
            Bytes::from(body),
        ))
        .await
        .into_response();
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 0);
    }

    /// Fail closed. An alias with no resolved bot secret cannot verify
    /// anything, so the webhook is refused before parsing or dispatch.
    #[cfg(feature = "channel-nextcloud")]
    #[tokio::test]
    async fn nextcloud_talk_webhook_rejects_when_no_secret_is_configured() {
        let provider_impl = Arc::new(MockModelProvider::default());
        let model_provider: Arc<dyn ModelProvider> = provider_impl.clone();
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);

        let alias = "nextcloud_talk_test_alias";
        let peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync> = Arc::new(Vec::new);
        let channel = Arc::new(NextcloudTalkChannel::new(
            "https://cloud.example.com".into(),
            None,
            String::new(),
            alias,
            peer_resolver,
        ));

        let body = r#"{"type":"message","object":{"token":"room-token"},"message":{"actorType":"users","actorId":"user_a","message":"hello"}}"#;

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            nextcloud_talk: HashMap::from([(alias.to_string(), channel)]),
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_driver_handles: None,
            sop_audit: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let response = Box::pin(handle_nextcloud_talk_webhook(
            State(state),
            HeaderMap::new(),
            Bytes::from(body),
        ))
        .await
        .into_response();
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 0);
    }

    // handler must return 200 OK before the (potentially
    // slow) LLM call completes, so Nextcloud Talk doesn't cancel the webhook
    // request at its ~5s timeout.
    #[cfg(feature = "channel-nextcloud")]
    #[derive(Default)]
    struct SlowProvider {
        calls: AtomicUsize,
        started_tx: Mutex<Option<tokio::sync::oneshot::Sender<()>>>,
    }

    #[cfg(feature = "channel-nextcloud")]
    #[async_trait]
    impl ModelProvider for SlowProvider {
        async fn chat_with_system(
            &self,
            _system_prompt: Option<&str>,
            _message: &str,
            _model: &str,
            _temperature: Option<f64>,
        ) -> anyhow::Result<String> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            if let Some(tx) = self.started_tx.lock().take() {
                let _ = tx.send(());
            }
            tokio::time::sleep(Duration::from_secs(30)).await;
            Ok("slow ok".into())
        }
    }
    #[cfg(feature = "channel-nextcloud")]
    impl ::zeroclaw_api::attribution::Attributable for SlowProvider {
        fn role(&self) -> ::zeroclaw_api::attribution::Role {
            ::zeroclaw_api::attribution::Role::Provider(
                ::zeroclaw_api::attribution::ProviderKind::Model(
                    ::zeroclaw_api::attribution::ModelProviderKind::Custom,
                ),
            )
        }
        fn alias(&self) -> &str {
            "SlowProvider"
        }
    }

    #[cfg(feature = "channel-nextcloud")]
    #[tokio::test]
    async fn nextcloud_talk_webhook_returns_before_llm_call_completes() {
        let (started_tx, started_rx) = tokio::sync::oneshot::channel();
        let provider_impl = Arc::new(SlowProvider {
            calls: AtomicUsize::new(0),
            started_tx: Mutex::new(Some(started_tx)),
        });
        let provider: Arc<dyn ModelProvider> = provider_impl.clone();
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);

        // Obviously-fake placeholder, never a real credential.
        let secret = "fake-nextcloud-webhook-secret-not-real";
        let random = "0123456789abcdef0123456789abcdef";

        // The same secret governs both directions now, so the channel is built
        // with that resolved secret as its bot token rather than the `None` this
        // test used to pass.
        let channel = Arc::new(NextcloudTalkChannel::new(
            "https://cloud.example.com".into(),
            Some(secret.to_string()),
            String::new(),
            "default",
            Arc::new(|| vec!["*".to_string()]),
        ));

        let body = r#"{"type":"message","object":{"token":"room-token"},"actor":{"id":"user_a","name":"User A"},"message":{"actorType":"users","actorId":"user_a","message":"hello"}}"#;
        let signature = compute_nextcloud_signature_hex(secret, random, body);

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider: provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory.clone(),
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::clone(&memory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            nextcloud_talk: HashMap::from([("default".to_string(), channel)]),
            // A resolved secret, not an empty map. Inbound verification is now
            // mandatory and fail-closed, so an unsigned request is rejected with
            // 401 before the handler ever spawns the LLM task — which would make
            // this test pass for the wrong reason (no provider call because the
            // request was refused, not because the ack raced ahead of a slow
            // provider). Signing the request keeps it on the fast-ack path.
            nextcloud_talk_webhook_secret: HashMap::from([(
                "default".to_string(),
                std::sync::Arc::<str>::from(secret),
            )]),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Nextcloud-Talk-Random",
            HeaderValue::from_str(random).unwrap(),
        );
        headers.insert(
            "X-Nextcloud-Talk-Signature",
            HeaderValue::from_str(&signature).unwrap(),
        );

        let start = std::time::Instant::now();
        let response = tokio::time::timeout(
            Duration::from_secs(2),
            Box::pin(handle_nextcloud_talk_webhook(
                State(state),
                headers,
                Bytes::from(body),
            )),
        )
        .await
        .expect("webhook must return before 2s deadline (regression #6156)")
        .into_response();

        let elapsed = start.elapsed();
        assert_eq!(response.status(), StatusCode::OK);
        assert!(
            elapsed < Duration::from_secs(2),
            "handler returned after {elapsed:?}; expected fast return for #6156"
        );

        // Confirm the spawned task actually started the LLM call (i.e., the
        // ack didn't just skip processing). The 30s sleep is still in flight.
        tokio::time::timeout(Duration::from_secs(2), started_rx)
            .await
            .expect("spawned LLM call did not start within 2s")
            .expect("started_tx sender was dropped");
        assert_eq!(provider_impl.calls.load(Ordering::SeqCst), 1);
    }

    // ══════════════════════════════════════════════════════════
    // WhatsApp Signature Verification Tests (CWE-345 Prevention)
    // ══════════════════════════════════════════════════════════

    #[cfg(feature = "channel-whatsapp-cloud")]
    fn compute_whatsapp_signature_hex(secret: &str, body: &[u8]) -> String {
        use hmac::{Hmac, Mac};
        use sha2::Sha256;

        let mut mac = Hmac::<Sha256>::new_from_slice(secret.as_bytes()).unwrap();
        mac.update(body);
        hex::encode(mac.finalize().into_bytes())
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    fn compute_whatsapp_signature_header(secret: &str, body: &[u8]) -> String {
        format!("sha256={}", compute_whatsapp_signature_hex(secret, body))
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_valid() {
        let app_secret = generate_test_secret();
        let body = b"test body content";

        let signature_header = compute_whatsapp_signature_header(&app_secret, body);

        assert!(verify_whatsapp_signature(
            &app_secret,
            body,
            &signature_header
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_invalid_wrong_secret() {
        let app_secret = generate_test_secret();
        let wrong_secret = generate_test_secret();
        let body = b"test body content";

        let signature_header = compute_whatsapp_signature_header(&wrong_secret, body);

        assert!(!verify_whatsapp_signature(
            &app_secret,
            body,
            &signature_header
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_invalid_wrong_body() {
        let app_secret = generate_test_secret();
        let original_body = b"original body";
        let tampered_body = b"tampered body";

        let signature_header = compute_whatsapp_signature_header(&app_secret, original_body);

        // Verify with tampered body should fail
        assert!(!verify_whatsapp_signature(
            &app_secret,
            tampered_body,
            &signature_header
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_missing_prefix() {
        let app_secret = generate_test_secret();
        let body = b"test body";

        // Signature without "sha256=" prefix
        let signature_header = "abc123def456";

        assert!(!verify_whatsapp_signature(
            &app_secret,
            body,
            signature_header
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_empty_header() {
        let app_secret = generate_test_secret();
        let body = b"test body";

        assert!(!verify_whatsapp_signature(&app_secret, body, ""));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_invalid_hex() {
        let app_secret = generate_test_secret();
        let body = b"test body";

        // Invalid hex characters
        let signature_header = "sha256=not_valid_hex_zzz";

        assert!(!verify_whatsapp_signature(
            &app_secret,
            body,
            signature_header
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_empty_body() {
        let app_secret = generate_test_secret();
        let body = b"";

        let signature_header = compute_whatsapp_signature_header(&app_secret, body);

        assert!(verify_whatsapp_signature(
            &app_secret,
            body,
            &signature_header
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_unicode_body() {
        let app_secret = generate_test_secret();
        let body = "Hello 🦀 World".as_bytes();

        let signature_header = compute_whatsapp_signature_header(&app_secret, body);

        assert!(verify_whatsapp_signature(
            &app_secret,
            body,
            &signature_header
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_json_payload() {
        let app_secret = generate_test_secret();
        let body = br#"{"entry":[{"changes":[{"value":{"messages":[{"from":"1234567890","text":{"body":"Hello"}}]}}]}]}"#;

        let signature_header = compute_whatsapp_signature_header(&app_secret, body);

        assert!(verify_whatsapp_signature(
            &app_secret,
            body,
            &signature_header
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_case_sensitive_prefix() {
        let app_secret = generate_test_secret();
        let body = b"test body";

        let hex_sig = compute_whatsapp_signature_hex(&app_secret, body);

        // Wrong case prefix should fail
        let wrong_prefix = format!("SHA256={hex_sig}");
        assert!(!verify_whatsapp_signature(&app_secret, body, &wrong_prefix));

        // Correct prefix should pass
        let correct_prefix = format!("sha256={hex_sig}");
        assert!(verify_whatsapp_signature(
            &app_secret,
            body,
            &correct_prefix
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_truncated_hex() {
        let app_secret = generate_test_secret();
        let body = b"test body";

        let hex_sig = compute_whatsapp_signature_hex(&app_secret, body);
        let truncated = &hex_sig[..32]; // Only half the signature
        let signature_header = format!("sha256={truncated}");

        assert!(!verify_whatsapp_signature(
            &app_secret,
            body,
            &signature_header
        ));
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[test]
    fn whatsapp_signature_extra_bytes() {
        let app_secret = generate_test_secret();
        let body = b"test body";

        let hex_sig = compute_whatsapp_signature_hex(&app_secret, body);
        let extended = format!("{hex_sig}deadbeef");
        let signature_header = format!("sha256={extended}");

        assert!(!verify_whatsapp_signature(
            &app_secret,
            body,
            &signature_header
        ));
    }

    // ══════════════════════════════════════════════════════════
    // IdempotencyStore Edge-Case Tests
    // ══════════════════════════════════════════════════════════

    #[test]
    fn idempotency_store_allows_different_keys() {
        let store = IdempotencyStore::new(Duration::from_secs(60), 100);
        assert!(store.record_if_new("key-a"));
        assert!(store.record_if_new("key-b"));
        assert!(store.record_if_new("key-c"));
        assert!(store.record_if_new("key-d"));
    }

    #[test]
    fn idempotency_store_max_keys_clamped_to_one() {
        let store = IdempotencyStore::new(Duration::from_secs(60), 0);
        assert!(store.record_if_new("only-key"));
        assert!(!store.record_if_new("only-key"));
    }

    #[test]
    fn idempotency_store_rapid_duplicate_rejected() {
        let store = IdempotencyStore::new(Duration::from_secs(300), 100);
        assert!(store.record_if_new("rapid"));
        assert!(!store.record_if_new("rapid"));
    }

    #[test]
    fn duplicate_idempotency_log_omits_caller_key() {
        let _hook_guard = zeroclaw_log::__private_test_hook_lock();
        zeroclaw_log::try_install_capture_subscriber();
        let mut receiver = zeroclaw_log::subscribe_or_install();
        while receiver.try_recv().is_ok() {}

        let raw_key = "caller-sensitive-id";
        record_duplicate_idempotency_log();

        let event = loop {
            match receiver.try_recv() {
                Ok(value)
                    if value.get("message").and_then(|message| message.as_str())
                        == Some("webhook duplicate ignored") =>
                {
                    break value;
                }
                Ok(_) => continue,
                Err(error) => panic!("duplicate log event was not broadcast: {error}"),
            }
        };
        zeroclaw_log::clear_broadcast_hook();

        assert_eq!(
            event["attributes"]["idempotency_key_present"],
            serde_json::Value::Bool(true)
        );
        assert!(event["attributes"].get("idempotency_key").is_none());
        assert!(
            !event.to_string().contains(raw_key),
            "caller-controlled idempotency key must not enter structured logs"
        );
    }

    #[test]
    fn idempotency_store_accepts_after_ttl_expires() {
        let store = IdempotencyStore::new(Duration::from_millis(1), 100);
        assert!(store.record_if_new("ttl-key"));
        std::thread::sleep(Duration::from_millis(10));
        assert!(store.record_if_new("ttl-key"));
    }

    #[test]
    fn idempotency_store_eviction_preserves_newest() {
        let store = IdempotencyStore::new(Duration::from_secs(300), 1);
        assert!(store.record_if_new("old-key"));
        std::thread::sleep(Duration::from_millis(2));
        assert!(store.record_if_new("new-key"));

        let entries = store.entries.lock();
        assert_eq!(entries.committed.len(), 1);
        assert!(!entries.committed.contains_key("old-key"));
        assert!(entries.committed.contains_key("new-key"));
    }

    #[test]
    fn rate_limiter_allows_after_window_expires() {
        let window = Duration::from_millis(50);
        let limiter = SlidingWindowRateLimiter::new(2, window, 100);
        assert!(limiter.allow("ip-1"));
        assert!(limiter.allow("ip-1"));
        assert!(!limiter.allow("ip-1")); // blocked

        // Wait for window to expire
        std::thread::sleep(Duration::from_millis(60));

        // Should be allowed again
        assert!(limiter.allow("ip-1"));
    }

    #[test]
    fn rate_limiter_independent_keys_tracked_separately() {
        let limiter = SlidingWindowRateLimiter::new(2, Duration::from_secs(60), 100);
        assert!(limiter.allow("ip-1"));
        assert!(limiter.allow("ip-1"));
        assert!(!limiter.allow("ip-1")); // ip-1 blocked

        // ip-2 should still work
        assert!(limiter.allow("ip-2"));
        assert!(limiter.allow("ip-2"));
        assert!(!limiter.allow("ip-2")); // ip-2 now blocked
    }

    #[test]
    fn rate_limiter_exact_boundary_at_max_keys() {
        let limiter = SlidingWindowRateLimiter::new(10, Duration::from_secs(60), 3);
        assert!(limiter.allow("ip-1"));
        assert!(limiter.allow("ip-2"));
        assert!(limiter.allow("ip-3"));
        // At capacity now
        assert!(limiter.allow("ip-4")); // should evict ip-1

        let guard = limiter.requests.lock();
        assert_eq!(guard.0.len(), 3);
        assert!(
            !guard.0.contains_key("ip-1"),
            "ip-1 should have been evicted"
        );
        assert!(guard.0.contains_key("ip-2"));
        assert!(guard.0.contains_key("ip-3"));
        assert!(guard.0.contains_key("ip-4"));
    }

    #[test]
    fn gateway_rate_limiter_pair_and_webhook_are_independent() {
        let limiter = GatewayRateLimiter::new(2, 3, 100);

        // Exhaust pair limit
        assert!(limiter.allow_pair("ip-1"));
        assert!(limiter.allow_pair("ip-1"));
        assert!(!limiter.allow_pair("ip-1")); // pair blocked

        // Webhook should still work
        assert!(limiter.allow_webhook("ip-1"));
        assert!(limiter.allow_webhook("ip-1"));
        assert!(limiter.allow_webhook("ip-1"));
        assert!(!limiter.allow_webhook("ip-1")); // webhook now blocked
    }

    #[test]
    fn rate_limiter_single_key_max_allows_one_request() {
        let limiter = SlidingWindowRateLimiter::new(5, Duration::from_secs(60), 1);
        assert!(limiter.allow("ip-1"));
        assert!(limiter.allow("ip-2")); // evicts ip-1

        let guard = limiter.requests.lock();
        assert_eq!(guard.0.len(), 1);
        assert!(guard.0.contains_key("ip-2"));
        assert!(!guard.0.contains_key("ip-1"));
    }

    #[test]
    fn rate_limiter_concurrent_access_safe() {
        use std::sync::Arc;

        let limiter = Arc::new(SlidingWindowRateLimiter::new(
            1000,
            Duration::from_secs(60),
            1000,
        ));
        let mut handles = Vec::new();

        for i in 0..10 {
            let limiter = limiter.clone();
            handles.push(std::thread::spawn(move || {
                for j in 0..100 {
                    limiter.allow(&format!("thread-{i}-req-{j}"));
                }
            }));
        }

        for handle in handles {
            handle.join().unwrap();
        }

        // Should not panic or deadlock
        let guard = limiter.requests.lock();
        assert!(guard.0.len() <= 1000, "should respect max_keys");
    }

    #[test]
    fn idempotency_store_concurrent_access_safe() {
        use std::sync::Arc;

        let store = Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000));
        let mut handles = Vec::new();

        for i in 0..10 {
            let store = store.clone();
            handles.push(std::thread::spawn(move || {
                for j in 0..100 {
                    store.record_if_new(&format!("thread-{i}-key-{j}"));
                }
            }));
        }

        for handle in handles {
            handle.join().unwrap();
        }

        let entries = store.entries.lock();
        assert!(entries.committed.len() <= 1000, "should respect max_keys");
    }

    #[test]
    fn rate_limiter_rapid_burst_then_cooldown() {
        let limiter = SlidingWindowRateLimiter::new(5, Duration::from_millis(50), 100);

        // Burst: use all 5 requests
        for _ in 0..5 {
            assert!(limiter.allow("burst-ip"));
        }
        assert!(!limiter.allow("burst-ip")); // 6th should fail

        // Cooldown
        std::thread::sleep(Duration::from_millis(60));

        // Should be allowed again
        assert!(limiter.allow("burst-ip"));
    }

    #[test]
    fn require_localhost_accepts_ipv4_loopback() {
        let peer = SocketAddr::from(([127, 0, 0, 1], 12345));
        assert!(require_localhost(&peer).is_ok());
    }

    #[test]
    fn require_localhost_accepts_ipv6_loopback() {
        let peer = SocketAddr::from((std::net::Ipv6Addr::LOCALHOST, 12345));
        assert!(require_localhost(&peer).is_ok());
    }

    #[test]
    fn require_localhost_rejects_non_loopback_ipv4() {
        let peer = SocketAddr::from(([192, 168, 1, 100], 12345));
        let err = require_localhost(&peer).unwrap_err();
        assert_eq!(err.0, StatusCode::FORBIDDEN);
    }

    #[test]
    fn require_localhost_rejects_non_loopback_ipv6() {
        let peer = SocketAddr::from((
            std::net::Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1),
            12345,
        ));
        let err = require_localhost(&peer).unwrap_err();
        assert_eq!(err.0, StatusCode::FORBIDDEN);
    }

    #[test]
    fn admin_reload_gate_loopback_always_allowed() {
        // Loopback is allowed regardless of the opt-in or pairing flags.
        assert_eq!(
            admin_reload_gate(true, false, false),
            AdminReloadGate::Allow
        );
        assert_eq!(admin_reload_gate(true, true, true), AdminReloadGate::Allow);
        assert_eq!(admin_reload_gate(true, false, true), AdminReloadGate::Allow);
        assert_eq!(admin_reload_gate(true, true, false), AdminReloadGate::Allow);
    }

    #[test]
    fn admin_reload_gate_remote_blocked_by_default() {
        // Non-loopback caller with the flag off is rejected outright,
        // regardless of pairing.
        assert_eq!(
            admin_reload_gate(false, false, true),
            AdminReloadGate::Forbidden
        );
        assert_eq!(
            admin_reload_gate(false, false, false),
            AdminReloadGate::Forbidden
        );
    }

    #[test]
    fn admin_reload_gate_remote_opt_in_requires_auth() {
        // Non-loopback caller with the flag on and pairing on must authenticate.
        assert_eq!(
            admin_reload_gate(false, true, true),
            AdminReloadGate::RequireAuth
        );
    }

    #[test]
    fn admin_reload_gate_remote_opt_in_without_pairing_is_rejected() {
        // Opting in with pairing off cannot authenticate the caller, so the
        // request is rejected rather than allowed anonymously.
        assert_eq!(
            admin_reload_gate(false, true, false),
            AdminReloadGate::ForbiddenNoPairing
        );
    }

    #[test]
    fn allow_remote_admin_defaults_off() {
        // Security default: remote admin reload is disabled until opted in.
        assert!(!zeroclaw_config::schema::GatewayConfig::default().allow_remote_admin);
    }

    /// Build an `AppState` for `handle_admin_reload`: controls
    /// `gateway.allow_remote_admin`, pairing (and its tokens), and wires a
    /// live reload channel so the allowed path reaches `200` rather than the
    /// `503` standalone-gateway branch.
    fn admin_reload_state(
        tmp: &tempfile::TempDir,
        allow_remote_admin: bool,
        require_pairing: bool,
        tokens: &[String],
    ) -> AppState {
        let mut state = admin_paircode_state(tmp, require_pairing, false);
        state.publish_test_config(|c| c.gateway.allow_remote_admin = allow_remote_admin);
        state.pairing = Arc::new(PairingGuard::new(
            require_pairing,
            tokens,
            PairingCodePolicy::default(),
        ));
        state.reload_tx = Some(zeroclaw_runtime::daemon::GatewayReloadControls::standalone(
            tokio::sync::watch::channel(false).0,
            tokio::sync::watch::channel(false).0,
        ));
        state
    }

    fn loopback_peer() -> SocketAddr {
        SocketAddr::from(([127, 0, 0, 1], 40000))
    }

    fn remote_peer() -> SocketAddr {
        // RFC 5737 TEST-NET-3 documentation address — a stable non-loopback
        // peer that is never a real host on anyone's network.
        SocketAddr::from(([203, 0, 113, 50], 40000))
    }

    fn bearer_headers(token: &str) -> HeaderMap {
        let mut headers = HeaderMap::new();
        headers.insert(
            header::AUTHORIZATION,
            HeaderValue::from_str(&format!("Bearer {token}")).unwrap(),
        );
        headers
    }

    #[tokio::test]
    async fn admin_reload_loopback_no_token_reloads() {
        let tmp = tempfile::tempdir().unwrap();
        let state = admin_reload_state(&tmp, false, true, &[]);
        let resp =
            handle_admin_reload(State(state), ConnectInfo(loopback_peer()), HeaderMap::new())
                .await
                .unwrap()
                .into_response();
        assert_eq!(resp.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn admin_reload_remote_default_off_is_forbidden() {
        let tmp = tempfile::tempdir().unwrap();
        let state = admin_reload_state(&tmp, false, true, &[]);
        let err = handle_admin_reload(State(state), ConnectInfo(remote_peer()), HeaderMap::new())
            .await
            .err()
            .unwrap();
        assert_eq!(err.0, StatusCode::FORBIDDEN);
    }

    #[tokio::test]
    async fn admin_reload_remote_opt_in_without_pairing_does_not_reload() {
        // The fixed hole: allow_remote_admin = true + require_pairing = false
        // must NOT permit an anonymous remote reload.
        let tmp = tempfile::tempdir().unwrap();
        let state = admin_reload_state(&tmp, true, false, &[]);
        let err = handle_admin_reload(State(state), ConnectInfo(remote_peer()), HeaderMap::new())
            .await
            .err()
            .unwrap();
        assert_eq!(err.0, StatusCode::FORBIDDEN);
    }

    #[tokio::test]
    async fn admin_reload_remote_opt_in_missing_token_is_rejected() {
        let tmp = tempfile::tempdir().unwrap();
        let state = admin_reload_state(&tmp, true, true, &["zc_test_token".to_string()]);
        let err = handle_admin_reload(State(state), ConnectInfo(remote_peer()), HeaderMap::new())
            .await
            .err()
            .unwrap();
        assert_eq!(err.0, StatusCode::UNAUTHORIZED);
    }

    #[tokio::test]
    async fn admin_reload_remote_opt_in_invalid_token_is_rejected() {
        let tmp = tempfile::tempdir().unwrap();
        let state = admin_reload_state(&tmp, true, true, &["zc_test_token".to_string()]);
        let err = handle_admin_reload(
            State(state),
            ConnectInfo(remote_peer()),
            bearer_headers("not-the-token"),
        )
        .await
        .err()
        .unwrap();
        assert_eq!(err.0, StatusCode::UNAUTHORIZED);
    }

    #[tokio::test]
    async fn admin_reload_remote_opt_in_valid_token_reloads() {
        let tmp = tempfile::tempdir().unwrap();
        let state = admin_reload_state(&tmp, true, true, &["zc_test_token".to_string()]);
        let resp = handle_admin_reload(
            State(state),
            ConnectInfo(remote_peer()),
            bearer_headers("zc_test_token"),
        )
        .await
        .unwrap()
        .into_response();
        assert_eq!(resp.status(), StatusCode::OK);
    }

    #[test]
    fn needs_quickstart_for_flags_empty_model() {
        let err =
            needs_quickstart_for("").expect("empty model must produce a needs_quickstart error");
        let msg = err.to_string();
        assert!(
            msg.contains("needs_quickstart"),
            "error must carry the needs_quickstart marker for callers to map to 503; got: {msg}"
        );
        assert!(
            msg.contains("/quickstart"),
            "error must point the user at /quickstart; got: {msg}"
        );
    }

    #[test]
    fn needs_quickstart_for_flags_whitespace_only_model() {
        assert!(
            needs_quickstart_for("   ").is_some(),
            "whitespace-only model must be treated as empty"
        );
        assert!(
            needs_quickstart_for("\n\t ").is_some(),
            "tabs and newlines count as empty too"
        );
    }

    #[test]
    fn needs_quickstart_for_passes_real_model() {
        assert!(
            needs_quickstart_for("anthropic/claude-sonnet-4").is_none(),
            "a real model id must not be flagged"
        );
        assert!(
            needs_quickstart_for("  gpt-4  ").is_none(),
            "leading/trailing whitespace around a real model id must not be flagged"
        );
    }

    #[test]
    fn is_needs_quickstart_err_detects_marker_from_helper() {
        let err = needs_quickstart_for("").expect("empty model produces marker");
        assert!(
            is_needs_quickstart_err(&err),
            "the marker emitted by needs_quickstart_for must be detected"
        );
    }

    #[test]
    fn is_needs_quickstart_err_ignores_unrelated_errors() {
        let err = anyhow::Error::msg("upstream timeout: provider returned 504");
        assert!(
            !is_needs_quickstart_err(&err),
            "unrelated errors must not be misclassified as needs_quickstart"
        );
        let err = anyhow::Error::msg("invalid api key");
        assert!(!is_needs_quickstart_err(&err));
    }

    #[test]
    fn is_needs_quickstart_err_detects_via_substring() {
        // Defends the contract that the substring marker is the
        // detection key — not the exact string. Wrappers (e.g.
        // anyhow::Error::context) must not break the check.
        let err =
            anyhow::Error::msg("provider call failed").context("needs_quickstart: empty model");
        assert!(is_needs_quickstart_err(&err));
    }

    #[test]
    fn needs_quickstart_channel_reply_resolves_via_fluent() {
        let reply = needs_quickstart_channel_reply();
        assert!(
            !reply.starts_with('{') && !reply.ends_with('}'),
            "fluent missing-key fallback leaked into channel reply: {reply:?}"
        );
        assert!(
            reply.to_lowercase().contains("quickstart"),
            "channel reply must mention Quickstart so users know what's missing: {reply:?}"
        );
    }

    // ══════════════════════════════════════════════════════════
    // Linq Multi-Tenant Webhook Routing Tests
    // ══════════════════════════════════════════════════════════

    /// Helper: compute a valid Linq HMAC-SHA256 signature for the given
    /// secret, timestamp, and body.  Mirrors the verification logic in
    /// `zeroclaw_channels::linq::verify_linq_signature`.
    #[cfg(feature = "channel-linq")]
    fn compute_linq_signature_hex(secret: &str, timestamp: &str, body: &str) -> String {
        use hmac::{Hmac, Mac};
        use sha2::Sha256;

        let message = format!("{timestamp}.{body}");
        let mut mac = Hmac::<Sha256>::new_from_slice(secret.as_bytes()).unwrap();
        mac.update(message.as_bytes());
        hex::encode(mac.finalize().into_bytes())
    }

    /// Helper: build a minimal Linq webhook payload that `parse_webhook_payload`
    /// recognises as a `message.received` event with one text part.
    #[cfg(feature = "channel-linq")]
    fn linq_webhook_body(sender: &str, text: &str) -> String {
        serde_json::json!({
            "event_type": "message.received",
            "data": {
                "chat_id": "chat-789",
                "from": sender,
                "is_from_me": false,
                "message": {
                    "parts": [{ "type": "text", "value": text }]
                }
            }
        })
        .to_string()
    }

    /// Helper: build an `AppState` with one Linq channel registered under the
    /// given alias, with an allow-any peer resolver and an optional signing
    /// secret.
    #[cfg(feature = "channel-linq")]
    fn linq_test_state(alias: &str, signing_secret: Option<&str>) -> AppState {
        linq_test_state_with_config(alias, signing_secret, Config::default())
    }

    #[cfg(feature = "channel-linq")]
    fn linq_test_state_with_config(
        alias: &str,
        signing_secret: Option<&str>,
        config: Config,
    ) -> AppState {
        let model_provider: Arc<dyn ModelProvider> = Arc::new(MockModelProvider::default());
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);

        let peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync> =
            Arc::new(|| vec!["*".to_string()]);
        let channel = Arc::new(LinqChannel::new(
            "test-token".into(),
            "+15550000000".into(),
            alias,
            peer_resolver,
        ));
        let mut linq = HashMap::new();
        linq.insert(alias.to_string(), channel);

        let mut linq_signing_secrets: HashMap<String, Arc<str>> = HashMap::new();
        if let Some(secret) = signing_secret {
            linq_signing_secrets.insert(alias.to_string(), Arc::from(secret));
        }

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(config);
        AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory,
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::new(MockMemory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq,
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets,
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        }
    }

    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn linq_webhook_returns_not_found_for_unknown_alias() {
        // No Linq channels configured at all.
        let state = linq_test_state("production", None);

        let response = Box::pin(handle_linq_webhook_alias(
            State(state),
            Path("staging".to_string()),
            HeaderMap::new(),
            Bytes::from_static(br#"{"event_type":"message.received"}"#),
        ))
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::NOT_FOUND);
    }

    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn linq_webhook_returns_not_found_when_no_channels_configured() {
        let model_provider: Arc<dyn ModelProvider> = Arc::new(MockModelProvider::default());
        let memory: Arc<dyn Memory> = Arc::new(MockMemory);

        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        let state = AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem: memory,
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::new(MockMemory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        };

        let response = Box::pin(handle_linq_webhook_alias(
            State(state),
            Path("default".to_string()),
            HeaderMap::new(),
            Bytes::from_static(br#"{"event_type":"message.received"}"#),
        ))
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::NOT_FOUND);
    }

    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn linq_webhook_accepts_valid_message_for_known_alias() {
        // This test proves alias routing, not signature handling, but inbound
        // verification is mandatory, so it has to carry a real secret and a
        // valid signature to reach the routing it is asserting on.
        let secret = generate_test_secret();
        let state = linq_test_state("default", Some(&secret));
        let body = linq_webhook_body("+15551234567", "hello from test");
        let timestamp = chrono::Utc::now().timestamp().to_string();
        let sig = compute_linq_signature_hex(&secret, &timestamp, &body);

        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Webhook-Signature",
            HeaderValue::from_str(&format!("sha256={sig}")).unwrap(),
        );
        headers.insert(
            "X-Webhook-Timestamp",
            HeaderValue::from_str(&timestamp).unwrap(),
        );

        let response = Box::pin(handle_linq_webhook_alias(
            State(state),
            Path("default".to_string()),
            headers,
            Bytes::from(body),
        ))
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn linq_webhook_rejects_when_no_signing_secret_is_configured() {
        // Fail closed. An alias with no resolved signing secret cannot verify
        // anything, so the webhook is refused rather than processed
        // unverified.
        let state = linq_test_state("default", None);
        let body = linq_webhook_body("+15551234567", "hello from test");

        let response = Box::pin(handle_linq_webhook_alias(
            State(state),
            Path("default".to_string()),
            HeaderMap::new(),
            Bytes::from(body),
        ))
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    }

    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn linq_webhook_rejects_invalid_signature_for_alias() {
        let secret = generate_test_secret();
        let state = linq_test_state("secure-alias", Some(&secret));

        let body = linq_webhook_body("+15551234567", "hello from test");
        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Webhook-Signature",
            HeaderValue::from_static("sha256=deadbeef"),
        );
        headers.insert(
            "X-Webhook-Timestamp",
            HeaderValue::from_static("9999999999"),
        );

        let response = Box::pin(handle_linq_webhook_alias(
            State(state),
            Path("secure-alias".to_string()),
            headers,
            Bytes::from(body),
        ))
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    }

    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn linq_webhook_accepts_valid_signature_for_alias() {
        let secret = generate_test_secret();
        let state = linq_test_state("secure-alias", Some(&secret));

        let body = linq_webhook_body("+15551234567", "hello from test");
        let timestamp = chrono::Utc::now().timestamp().to_string();
        let sig = compute_linq_signature_hex(&secret, &timestamp, &body);

        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Webhook-Signature",
            HeaderValue::from_str(&format!("sha256={sig}")).unwrap(),
        );
        headers.insert(
            "X-Webhook-Timestamp",
            HeaderValue::from_str(&timestamp).unwrap(),
        );

        let response = Box::pin(handle_linq_webhook_alias(
            State(state),
            Path("secure-alias".to_string()),
            headers,
            Bytes::from(body),
        ))
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::OK);
    }

    // ── Authenticated webhook ingress: shared dispatch lifecycle ────────

    /// Memory double that records every autosave call so lifecycle tests
    /// can assert on keys and session ids.
    #[cfg(feature = "channel-linq")]
    #[derive(Default)]
    struct CapturingMemory {
        stores: Mutex<Vec<(String, String, Option<String>)>>,
    }

    #[cfg(feature = "channel-linq")]
    #[async_trait]
    impl Memory for CapturingMemory {
        fn name(&self) -> &str {
            "capturing"
        }

        async fn store(
            &self,
            key: &str,
            content: &str,
            _category: MemoryCategory,
            session_id: Option<&str>,
        ) -> anyhow::Result<()> {
            self.stores.lock().push((
                key.to_string(),
                content.to_string(),
                session_id.map(ToString::to_string),
            ));
            Ok(())
        }

        async fn recall(
            &self,
            _query: &str,
            _limit: usize,
            _session_id: Option<&str>,
            _since: Option<&str>,
            _until: Option<&str>,
        ) -> anyhow::Result<Vec<MemoryEntry>> {
            Ok(Vec::new())
        }

        async fn get(&self, _key: &str) -> anyhow::Result<Option<MemoryEntry>> {
            Ok(None)
        }

        async fn list(
            &self,
            _category: Option<&MemoryCategory>,
            _session_id: Option<&str>,
        ) -> anyhow::Result<Vec<MemoryEntry>> {
            Ok(Vec::new())
        }

        async fn forget(&self, _key: &str) -> anyhow::Result<bool> {
            Ok(false)
        }

        async fn forget_for_agent(&self, _key: &str, _agent_id: &str) -> anyhow::Result<bool> {
            Ok(false)
        }

        async fn count(&self) -> anyhow::Result<usize> {
            Ok(0)
        }

        async fn health_check(&self) -> bool {
            true
        }

        async fn store_with_agent(
            &self,
            key: &str,
            content: &str,
            category: MemoryCategory,
            session_id: Option<&str>,
            _namespace: Option<&str>,
            _importance: Option<f64>,
            _agent_id: Option<&str>,
        ) -> anyhow::Result<()> {
            self.store(key, content, category, session_id).await
        }

        async fn recall_for_agents(
            &self,
            _allowed_agent_ids: &[&str],
            _query: &str,
            _limit: usize,
            _session_id: Option<&str>,
            _since: Option<&str>,
            _until: Option<&str>,
        ) -> anyhow::Result<Vec<MemoryEntry>> {
            Ok(Vec::new())
        }
    }

    #[cfg(feature = "channel-linq")]
    impl ::zeroclaw_api::attribution::Attributable for CapturingMemory {
        fn role(&self) -> ::zeroclaw_api::attribution::Role {
            ::zeroclaw_api::attribution::Role::Memory(
                ::zeroclaw_api::attribution::MemoryKind::InMemory,
            )
        }
        fn alias(&self) -> &str {
            "CapturingMemory"
        }
    }

    /// Channel double that records every outbound send so lifecycle tests
    /// can assert on reply delivery without network I/O.
    #[cfg(feature = "channel-linq")]
    #[derive(Default)]
    struct CapturingChannel {
        sends: Mutex<Vec<(String, String)>>,
    }

    #[cfg(feature = "channel-linq")]
    #[async_trait]
    impl Channel for CapturingChannel {
        fn name(&self) -> &str {
            "capturing"
        }

        async fn send(&self, message: &zeroclaw_api::channel::SendMessage) -> anyhow::Result<()> {
            self.sends
                .lock()
                .push((message.content.clone(), message.recipient.clone()));
            Ok(())
        }

        async fn listen(
            &self,
            _tx: tokio::sync::mpsc::Sender<zeroclaw_api::channel::ChannelMessage>,
        ) -> anyhow::Result<()> {
            Ok(())
        }
    }

    #[cfg(feature = "channel-linq")]
    impl ::zeroclaw_api::attribution::Attributable for CapturingChannel {
        fn role(&self) -> ::zeroclaw_api::attribution::Role {
            ::zeroclaw_api::attribution::Role::Channel(
                ::zeroclaw_api::attribution::ChannelKind::Webhook,
            )
        }
        fn alias(&self) -> &str {
            "CapturingChannel"
        }
    }

    #[cfg(feature = "channel-linq")]
    fn test_channel_message(sender: &str, content: &str) -> zeroclaw_api::channel::ChannelMessage {
        zeroclaw_api::channel::ChannelMessage {
            id: "msg-1".into(),
            sender: sender.into(),
            platform_sender_id: None,
            reply_target: sender.into(),
            content: content.into(),
            channel: "linq".into(),
            channel_alias: Some("default".into()),
            timestamp: 0,
            thread_ts: None,
            interruption_scope_id: None,
            attachments: Vec::new(),
            subject: None,
            internal_sop_event: None,
            passive_context: false,
            explicitly_addressed: false,
            conversation_scope: Default::default(),
            references: Vec::new(),
            voice_origin: false,
        }
    }

    /// A verified request still flows through the full shared lifecycle:
    /// autosave with the channel session key, agent dispatch, and reply
    /// delivery through the channel implementation.
    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn verified_webhook_dispatch_runs_the_full_lifecycle() {
        let mut state = linq_test_state("default", Some("secret"));
        let memory_impl = Arc::new(CapturingMemory::default());
        let mem: Arc<dyn Memory> = memory_impl.clone();
        state.mem = mem;
        state.auto_save = true;

        let verified = match webhook_ingress::authenticate(
            &webhook_ingress::LINQ_WEBHOOK,
            "default",
            Some("secret"),
            &HeaderMap::new(),
            Bytes::from_static(b"{}"),
            |_, _, _| true,
        ) {
            Ok(verified) => verified,
            Err(refusal) => panic!("stub verification must succeed, got {refusal:?}"),
        };
        let verified = verified
            .parse_messages(|body| {
                assert_eq!(body, b"{}", "the parser receives the verified request body");
                Ok::<_, ()>(vec![test_channel_message(
                    "+15551234567",
                    "hello lifecycle",
                )])
            })
            .expect("verified request should parse");

        let channel_impl = Arc::new(CapturingChannel::default());
        let channel: Arc<dyn Channel> = channel_impl.clone();

        let (status, _body) = webhook_ingress::dispatch_verified_webhook(
            &state,
            verified,
            webhook_ingress::WebhookDispatchContext {
                channel,
                memory_key: linq_memory_key,
                agent_override: None,
                mode: webhook_ingress::WebhookDispatchMode::Synchronous,
                suppress_reply_send: false,
            },
        )
        .await;

        assert_eq!(status, StatusCode::OK);

        let stores = memory_impl.stores.lock().clone();
        assert_eq!(stores.len(), 1, "one autosave per inbound message");
        assert_eq!(stores[0].0, "linq_+15551234567_msg-1");
        assert_eq!(stores[0].1, "hello lifecycle");
        assert_eq!(stores[0].2.as_deref(), Some("linq_default__15551234567"));

        let sends = channel_impl.sends.lock().clone();
        assert_eq!(sends.len(), 1, "one reply per inbound message");
        assert_eq!(sends[0].0, "ok", "the model reply is what gets delivered");
        assert_eq!(sends[0].1, "+15551234567");
    }

    /// When the gateway has no model configured, a verified request still
    /// gets the quickstart fallback reply through the channel instead of
    /// silence.
    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn verified_webhook_dispatch_sends_quickstart_fallback_when_unconfigured() {
        let mut state = linq_test_state("default", Some("secret"));
        state.model = String::new();

        let verified = match webhook_ingress::authenticate(
            &webhook_ingress::LINQ_WEBHOOK,
            "default",
            Some("secret"),
            &HeaderMap::new(),
            Bytes::from_static(b"{}"),
            |_, _, _| true,
        ) {
            Ok(verified) => verified,
            Err(refusal) => panic!("stub verification must succeed, got {refusal:?}"),
        };
        let verified = verified
            .parse_messages(|body| {
                assert_eq!(body, b"{}", "the parser receives the verified request body");
                Ok::<_, ()>(vec![test_channel_message("+15551234567", "anyone home?")])
            })
            .expect("verified request should parse");

        let channel_impl = Arc::new(CapturingChannel::default());
        let channel: Arc<dyn Channel> = channel_impl.clone();

        let (status, _body) = webhook_ingress::dispatch_verified_webhook(
            &state,
            verified,
            webhook_ingress::WebhookDispatchContext {
                channel,
                memory_key: linq_memory_key,
                agent_override: None,
                mode: webhook_ingress::WebhookDispatchMode::Synchronous,
                suppress_reply_send: false,
            },
        )
        .await;

        assert_eq!(status, StatusCode::OK);
        let sends = channel_impl.sends.lock().clone();
        assert_eq!(sends.len(), 1);
        assert_eq!(
            sends[0].0,
            needs_quickstart_channel_reply(),
            "unconfigured gateway sends the quickstart reply, not silence"
        );
    }

    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn linq_webhook_alias_dispatches_to_configured_channel_agent() {
        use zeroclaw_config::providers::ChannelRef;
        use zeroclaw_config::schema::AliasedAgentConfig;

        let _capture_guard = lock_gateway_chat_dispatch_capture_for_test().await;
        clear_gateway_chat_dispatch_captures_for_test();

        let mut config = Config::default();
        config.agents.insert(
            "alpha".to_string(),
            AliasedAgentConfig {
                enabled: true,
                ..AliasedAgentConfig::default()
            },
        );
        config.agents.insert(
            "beta".to_string(),
            AliasedAgentConfig {
                enabled: true,
                channels: vec![ChannelRef::new("linq.work")],
                ..AliasedAgentConfig::default()
            },
        );
        let secret = generate_test_secret();
        let state = linq_test_state_with_config("work", Some(&secret), config);

        let message = "hello from linq work alias";
        let body = linq_webhook_body("+15551234567", message);
        let timestamp = chrono::Utc::now().timestamp().to_string();
        let sig = compute_linq_signature_hex(&secret, &timestamp, &body);
        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Webhook-Signature",
            HeaderValue::from_str(&format!("sha256={sig}")).unwrap(),
        );
        headers.insert(
            "X-Webhook-Timestamp",
            HeaderValue::from_str(&timestamp).unwrap(),
        );

        let response = Box::pin(handle_linq_webhook_alias(
            State(state),
            Path("work".to_string()),
            headers,
            Bytes::from(body),
        ))
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::OK);

        let captures = gateway_chat_dispatch_captures_for_test();
        let capture = captures
            .iter()
            .find(|capture| capture.message == message)
            .expect("Linq webhook should dispatch the inbound message");
        assert_eq!(capture.agent_override.as_deref(), Some("beta"));
        let session_id = capture
            .session_id
            .as_deref()
            .expect("Linq dispatch should pass a session id");
        assert_eq!(session_id, "linq_work__15551234567");
    }

    #[cfg(feature = "channel-linq")]
    #[tokio::test]
    async fn linq_webhook_alias_without_enabled_owner_does_not_use_default_agent() {
        use zeroclaw_config::providers::ChannelRef;
        use zeroclaw_config::schema::AliasedAgentConfig;

        let _capture_guard = lock_gateway_chat_dispatch_capture_for_test().await;
        clear_gateway_chat_dispatch_captures_for_test();

        let mut config = Config::default();
        config.agents.insert(
            "alpha".to_string(),
            AliasedAgentConfig {
                enabled: true,
                ..AliasedAgentConfig::default()
            },
        );
        config.agents.insert(
            "beta".to_string(),
            AliasedAgentConfig {
                enabled: false,
                channels: vec![ChannelRef::new("linq.work")],
                ..AliasedAgentConfig::default()
            },
        );
        let secret = generate_test_secret();
        let state = linq_test_state_with_config("work", Some(&secret), config);

        let message = "do not route me to alpha";
        let body = linq_webhook_body("+15551234567", message);
        let timestamp = chrono::Utc::now().timestamp().to_string();
        let sig = compute_linq_signature_hex(&secret, &timestamp, &body);
        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Webhook-Signature",
            HeaderValue::from_str(&format!("sha256={sig}")).unwrap(),
        );
        headers.insert(
            "X-Webhook-Timestamp",
            HeaderValue::from_str(&timestamp).unwrap(),
        );

        let response = Box::pin(handle_linq_webhook_alias(
            State(state),
            Path("work".to_string()),
            headers,
            Bytes::from(body),
        ))
        .await
        .into_response();

        assert_eq!(response.status(), StatusCode::OK);
        let captures = gateway_chat_dispatch_captures_for_test();
        assert!(
            captures.iter().all(|capture| capture.message != message),
            "unowned Linq alias must not dispatch through the default agent: {captures:?}"
        );
    }

    // ── Per-alias webhook routing───────────────────────────────────

    /// Baseline `AppState` with no channels configured, for the per-alias
    /// routing tests. Tests insert the WhatsApp instances they exercise.
    #[cfg(feature = "channel-whatsapp-cloud")]
    fn webhook_baseline_state() -> AppState {
        let model_provider: Arc<dyn ModelProvider> = Arc::new(MockModelProvider::default());
        let mem: Arc<dyn Memory> = Arc::new(MockMemory);
        let state_authority = zeroclaw_runtime::LiveConfigAuthority::new(Config::default());
        AppState {
            config: state_authority.live_handle(),
            config_authority: state_authority.clone(),
            agent_lifecycle: state_authority.agent_lifecycle(),
            model_provider,
            model: "test-model".into(),
            temperature: None,
            mem,
            memory_strategy: Arc::new(DefaultMemoryStrategy::with_config(
                Arc::new(MockMemory),
                zeroclaw_config::schema::MemoryConfig::default(),
                std::path::PathBuf::new(),
            )),
            auto_save: false,
            pairing: Arc::new(PairingGuard::new(false, &[], PairingCodePolicy::default())),
            trust_forwarded_headers: false,
            rate_limiter: Arc::new(GatewayRateLimiter::new(100, 100, 100)),
            auth_limiter: Arc::new(auth_rate_limit::AuthRateLimiter::new()),
            idempotency_store: Arc::new(IdempotencyStore::new(Duration::from_secs(300), 1000)),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp: HashMap::new(),
            #[cfg(feature = "channel-whatsapp-cloud")]
            whatsapp_app_secret: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq: HashMap::new(),
            #[cfg(feature = "channel-linq")]
            linq_signing_secrets: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk: HashMap::new(),
            #[cfg(feature = "channel-nextcloud")]
            nextcloud_talk_webhook_secret: HashMap::new(),
            #[cfg(feature = "channel-email")]
            gmail_push: None,
            observer: Arc::new(zeroclaw_runtime::observability::NoopObserver),
            tools_registry: Arc::new(Vec::new()),
            tools_registry_by_agent: Arc::new(std::collections::HashMap::new()),
            cost_tracker: None,
            event_tx: tokio::sync::broadcast::channel(16).0,
            event_buffer: Arc::new(sse::EventBuffer::new(16)),
            shutdown_tx: tokio::sync::watch::channel(false).0,
            reload_tx: None,
            node_registry: Arc::new(nodes::NodeRegistry::new(16)),
            mdns_peer_registry: nodes::mdns::MdnsPeerRegistry::default(),
            path_prefix: String::new(),
            web_dist_dir: None,
            session_backend: None,
            session_queue: std::sync::Arc::new(crate::session_queue::SessionActorQueue::new(
                8, 30, 600,
            )),
            device_registry: None,
            canvas_store: CanvasStore::new(),
            cancel_tokens: Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            pending_reload: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            tui_registry: None,
            sop_engine: None,
            sop_audit: None,
            sop_driver_handles: None,
            #[cfg(feature = "webauthn")]
            webauthn: None,
        }
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    fn whatsapp_instance(alias: &str, verify_token: &str) -> Arc<WhatsAppChannel> {
        let peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync> = Arc::new(Vec::new);
        Arc::new(WhatsAppChannel::new(
            "access-token".into(),
            "phone-number-id".into(),
            verify_token.into(),
            alias,
            peer_resolver,
        ))
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    fn whatsapp_instance_allowing_all(alias: &str, verify_token: &str) -> Arc<WhatsAppChannel> {
        let peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync> =
            Arc::new(|| vec!["*".to_string()]);
        Arc::new(WhatsAppChannel::new(
            "access-token".into(),
            "phone-number-id".into(),
            verify_token.into(),
            alias.to_string(),
            peer_resolver,
        ))
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    fn whatsapp_signature(secret: &str, body: &[u8]) -> String {
        use hmac::{Hmac, Mac};
        use sha2::Sha256;
        let mut mac = Hmac::<Sha256>::new_from_slice(secret.as_bytes()).unwrap();
        mac.update(body);
        format!("sha256={}", hex::encode(mac.finalize().into_bytes()))
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    fn whatsapp_webhook_body(sender: &str, text: &str) -> Vec<u8> {
        serde_json::to_vec(&serde_json::json!({
            "object": "whatsapp_business_account",
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": sender,
                            "timestamp": "1700000000",
                            "type": "text",
                            "text": { "body": text }
                        }]
                    }
                }]
            }]
        }))
        .expect("WhatsApp test payload must serialize")
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    fn whatsapp_signed_headers(secret: &str, body: &[u8]) -> HeaderMap {
        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Hub-Signature-256",
            HeaderValue::from_str(&whatsapp_signature(secret, body)).unwrap(),
        );
        headers
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    fn verify_query(token: &str, challenge: &str) -> WhatsAppVerifyQuery {
        WhatsAppVerifyQuery {
            mode: Some("subscribe".to_string()),
            verify_token: Some(token.to_string()),
            challenge: Some(challenge.to_string()),
        }
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[tokio::test]
    async fn webhook_alias_routes_to_the_matching_instance() {
        let mut state = webhook_baseline_state();
        state.whatsapp = HashMap::from([
            ("work".to_string(), whatsapp_instance("work", "tok-work")),
            (
                "personal".to_string(),
                whatsapp_instance("personal", "tok-personal"),
            ),
        ]);

        let resp = handle_whatsapp_verify_alias(
            State(state.clone()),
            Path("work".to_string()),
            Query(verify_query("tok-work", "challenge-work")),
        )
        .await;
        assert_eq!(resp.status(), StatusCode::OK);
        // Explicit alias path carries no deprecation header.
        assert!(
            resp.headers()
                .get(api_webhook::DEPRECATION_HEADER)
                .is_none()
        );

        // The other instance's token must NOT verify against `work`.
        let resp = handle_whatsapp_verify_alias(
            State(state.clone()),
            Path("work".to_string()),
            Query(verify_query("tok-personal", "challenge")),
        )
        .await;
        assert_eq!(resp.status(), StatusCode::FORBIDDEN);

        let resp = handle_whatsapp_verify_alias(
            State(state),
            Path("personal".to_string()),
            Query(verify_query("tok-personal", "challenge-personal")),
        )
        .await;
        assert_eq!(resp.status(), StatusCode::OK);
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[tokio::test]
    async fn webhook_unknown_alias_is_404_not_500() {
        let mut state = webhook_baseline_state();
        state.whatsapp = HashMap::from([("work".to_string(), whatsapp_instance("work", "tok"))]);

        let resp = handle_whatsapp_verify_alias(
            State(state),
            Path("nope".to_string()),
            Query(verify_query("tok", "challenge")),
        )
        .await;
        assert_eq!(resp.status(), StatusCode::NOT_FOUND);
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[tokio::test]
    async fn webhook_bare_path_is_back_compat_and_flags_deprecation() {
        let mut state = webhook_baseline_state();
        state.whatsapp =
            HashMap::from([("default".to_string(), whatsapp_instance("default", "tok"))]);

        let resp = handle_whatsapp_verify(
            State(state),
            Query(verify_query("tok", "challenge-default")),
        )
        .await;
        assert_eq!(resp.status(), StatusCode::OK);
        assert!(
            resp.headers()
                .get(api_webhook::DEPRECATION_HEADER)
                .is_some()
        );
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[tokio::test]
    async fn webhook_alias_path_preserves_signature_auth() {
        let mut state = webhook_baseline_state();
        state.whatsapp = HashMap::from([("work".to_string(), whatsapp_instance("work", "tok"))]);
        state.whatsapp_app_secret =
            HashMap::from([("work".to_string(), Arc::<str>::from("app-secret"))]);

        // Unknown alias → 404 before any processing.
        let resp = Box::pin(handle_whatsapp_message_alias(
            State(state.clone()),
            Path("nope".to_string()),
            HeaderMap::new(),
            Bytes::from_static(b"{}"),
        ))
        .await;
        assert_eq!(resp.status(), StatusCode::NOT_FOUND);

        // Configured alias, missing/invalid signature → 401.
        let resp = Box::pin(handle_whatsapp_message_alias(
            State(state.clone()),
            Path("work".to_string()),
            HeaderMap::new(),
            Bytes::from_static(b"{}"),
        ))
        .await;
        assert_eq!(resp.status(), StatusCode::UNAUTHORIZED);

        // Configured alias, valid signature over an empty payload → 200 ack.
        let body = br#"{"object":"whatsapp_business_account","entry":[]}"#;
        let mut headers = HeaderMap::new();
        headers.insert(
            "X-Hub-Signature-256",
            HeaderValue::from_str(&whatsapp_signature("app-secret", body)).unwrap(),
        );
        let resp = Box::pin(handle_whatsapp_message_alias(
            State(state),
            Path("work".to_string()),
            headers,
            Bytes::from_static(body),
        ))
        .await;
        assert_eq!(resp.status(), StatusCode::OK);
    }

    #[cfg(feature = "channel-whatsapp-cloud")]
    #[tokio::test]
    async fn authenticated_webhook_binds_approval_to_alias_responder_and_destination() {
        use tokio::sync::oneshot::error::TryRecvError;
        use zeroclaw_api::channel::ChannelApprovalResponse;

        let _capture_guard = lock_gateway_chat_dispatch_capture_for_test().await;
        clear_gateway_chat_dispatch_captures_for_test();

        const SECRET: &str = "app-secret";
        const TOKEN: &str = "gw1024";
        const APPROVER: &str = "+15551234567";
        const APPROVER_WEBHOOK: &str = "15551234567";

        let mut state = webhook_baseline_state();
        state.whatsapp = HashMap::from([
            (
                "work".to_string(),
                whatsapp_instance_allowing_all("work", "tok-work"),
            ),
            (
                "personal".to_string(),
                whatsapp_instance_allowing_all("personal", "tok-personal"),
            ),
        ]);
        state.whatsapp_app_secret = HashMap::from([
            ("work".to_string(), Arc::<str>::from(SECRET)),
            ("personal".to_string(), Arc::<str>::from(SECRET)),
        ]);

        let mut decision = zeroclaw_channels::whatsapp::register_pending_approval_for_test(
            TOKEN, "work", APPROVER,
        )
        .await;

        let wrong_alias = whatsapp_webhook_body(APPROVER_WEBHOOK, &format!("{TOKEN} approve"));
        let response = Box::pin(handle_whatsapp_message_alias(
            State(state.clone()),
            Path("personal".to_string()),
            whatsapp_signed_headers(SECRET, &wrong_alias),
            Bytes::from(wrong_alias),
        ))
        .await;
        assert_eq!(response.status(), StatusCode::OK);
        assert!(matches!(decision.try_recv(), Err(TryRecvError::Empty)));
        assert!(
            gateway_chat_dispatch_captures_for_test()
                .iter()
                .all(|capture| !capture.message.contains(TOKEN))
        );

        let wrong_responder = whatsapp_webhook_body("15557654321", &format!("{TOKEN} approve"));
        let response = Box::pin(handle_whatsapp_message_alias(
            State(state.clone()),
            Path("work".to_string()),
            whatsapp_signed_headers(SECRET, &wrong_responder),
            Bytes::from(wrong_responder),
        ))
        .await;
        assert_eq!(response.status(), StatusCode::OK);
        assert!(matches!(decision.try_recv(), Err(TryRecvError::Empty)));
        assert!(
            gateway_chat_dispatch_captures_for_test()
                .iter()
                .all(|capture| !capture.message.contains(TOKEN))
        );

        let correct = whatsapp_webhook_body(APPROVER_WEBHOOK, &format!("{TOKEN} approve"));
        let response = Box::pin(handle_whatsapp_message_alias(
            State(state.clone()),
            Path("work".to_string()),
            whatsapp_signed_headers(SECRET, &correct),
            Bytes::from(correct),
        ))
        .await;
        assert_eq!(response.status(), StatusCode::OK);
        assert_eq!(decision.await.unwrap(), ChannelApprovalResponse::Approve);
        assert!(
            gateway_chat_dispatch_captures_for_test()
                .iter()
                .all(|capture| !capture.message.contains(TOKEN))
        );

        let ordinary_text = "continue with the ordinary request";
        let ordinary = whatsapp_webhook_body(APPROVER_WEBHOOK, ordinary_text);
        let response = Box::pin(handle_whatsapp_message_alias(
            State(state),
            Path("work".to_string()),
            whatsapp_signed_headers(SECRET, &ordinary),
            Bytes::from(ordinary),
        ))
        .await;
        assert_eq!(response.status(), StatusCode::OK);
        assert_eq!(
            gateway_chat_dispatch_captures_for_test()
                .iter()
                .filter(|capture| capture.message == ordinary_text)
                .count(),
            1,
            "a non-approval message must still dispatch through the gateway"
        );
    }

    /// Fail closed. A configured alias with no app secret cannot verify
    /// `X-Hub-Signature-256`, so the webhook is refused rather than
    /// dispatched to the agent unverified.
    #[cfg(feature = "channel-whatsapp-cloud")]
    #[tokio::test]
    async fn whatsapp_webhook_rejects_when_no_app_secret_is_configured() {
        let mut state = webhook_baseline_state();
        state.whatsapp = HashMap::from([("work".to_string(), whatsapp_instance("work", "tok"))]);
        state.whatsapp_app_secret = HashMap::new();

        let body = br#"{"object":"whatsapp_business_account","entry":[]}"#;
        let resp = Box::pin(handle_whatsapp_message_alias(
            State(state),
            Path("work".to_string()),
            HeaderMap::new(),
            Bytes::from_static(body),
        ))
        .await;
        assert_eq!(resp.status(), StatusCode::UNAUTHORIZED);
    }

    /// Build an `AppState` whose device registry points at a non-existent
    /// path so every SQLite write fails. Mirrors `unwriteable_registry_state`
    /// in `api_pairing::tests` so the regression set stays side-by-side.
    fn unwriteable_registry_pair_state(tmp: &tempfile::TempDir) -> AppState {
        let mut state = admin_paircode_state(tmp, true, false);
        // No registry from `admin_paircode_state`; inject the broken one.
        state.device_registry = Some(Arc::new(api_pairing::DeviceRegistry::with_db_path(
            std::path::PathBuf::from("/this/path/does/not/exist/devices.db"),
        )));
        state
    }

    async fn legacy_pair_response_json(
        result: impl IntoResponse,
    ) -> (StatusCode, serde_json::Value) {
        let response = result.into_response();
        let status = response.status();
        let bytes = response
            .into_body()
            .collect()
            .await
            .expect("legacy /pair response body")
            .to_bytes();
        let body: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        (status, body)
    }

    #[tokio::test]
    async fn legacy_pair_rolls_back_in_process_token_when_registry_register_fails() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = unwriteable_registry_pair_state(&tmp);

        let code = state
            .pairing
            .generate_new_pairing_code(live_pairing_code_policy(&state))
            .expect("pairing code must be issuable when require_pairing=true");

        let mut headers = HeaderMap::new();
        headers.insert("X-Pairing-Code", HeaderValue::from_str(&code).unwrap());

        let (status, body) = legacy_pair_response_json(
            handle_pair(State(state.clone()), test_connect_info(), headers).await,
        )
        .await;

        assert_eq!(
            status,
            StatusCode::INTERNAL_SERVER_ERROR,
            "legacy /pair registry.register failure must surface as 500"
        );
        assert_eq!(body["paired"], serde_json::Value::Bool(false));
        assert!(
            body.get("token").is_none(),
            "legacy /pair 5xx body MUST NOT contain the plaintext bearer token; got: {body}"
        );
        assert!(
            state.pairing.tokens().is_empty(),
            "PairingGuard::paired_tokens must be empty after a failed /pair \
             registry.register (compensating `revoke_token_hash`); instead have {:?}",
            state.pairing.tokens()
        );
    }

    #[tokio::test]
    async fn legacy_pair_rolls_back_in_process_token_when_persist_fails() {
        let tmp = tempfile::TempDir::new().unwrap();
        let state = admin_paircode_state(&tmp, true, false);
        let blocker = tmp.path().join("legacy-pair-blocker");
        std::fs::write(&blocker, b"").expect("seed blocker file");
        state.publish_test_config(|c| c.config_path = blocker.join("config.toml"));

        let code = state
            .pairing
            .generate_new_pairing_code(live_pairing_code_policy(&state))
            .expect("pairing code must be issuable when require_pairing=true");

        let mut headers = HeaderMap::new();
        headers.insert("X-Pairing-Code", HeaderValue::from_str(&code).unwrap());

        let (status, body) = legacy_pair_response_json(
            handle_pair(State(state.clone()), test_connect_info(), headers).await,
        )
        .await;

        assert_eq!(
            status,
            StatusCode::INTERNAL_SERVER_ERROR,
            "legacy /pair persistence failure MUST surface as 500 (legacy leaked 200 + token)"
        );
        assert_eq!(body["paired"], serde_json::Value::Bool(false));
        assert!(
            body.get("token").is_none(),
            "legacy /pair 5xx body MUST NOT contain the plaintext bearer token; got: {body}"
        );
        assert!(
            state.pairing.tokens().is_empty(),
            "PairingGuard::paired_tokens must be empty after a failed /pair \
             persist; have {:?}",
            state.pairing.tokens()
        );
    }
}

#[cfg(test)]
mod accept_error_tests {
    use super::is_recoverable_accept_error;
    use std::io::{Error, ErrorKind};

    #[cfg(unix)]
    #[test]
    fn fd_exhaustion_accept_errors_are_recoverable() {
        // EMFILE/ENFILE must not terminate the daemon.
        assert!(is_recoverable_accept_error(&Error::from_raw_os_error(24))); // EMFILE
        assert!(is_recoverable_accept_error(&Error::from_raw_os_error(23))); // ENFILE
    }

    #[test]
    fn transient_kinds_recover_but_fatal_propagates() {
        assert!(is_recoverable_accept_error(&Error::from(
            ErrorKind::ConnectionAborted
        )));
        assert!(is_recoverable_accept_error(&Error::from(
            ErrorKind::Interrupted
        )));
        // A non-transient error is not swallowed (loop will propagate it).
        assert!(!is_recoverable_accept_error(&Error::from(
            ErrorKind::InvalidInput
        )));
    }

    /// The gateway points the pricing refresher at the live config handle its
    /// config API writes. An operator opt-out made through `PUT
    /// /api/config/prop` on a running standalone gateway must therefore reach
    /// the refresher without a restart, instead of being lost on a private
    /// copy of the startup config.
    #[tokio::test]
    async fn a_config_api_opt_out_reaches_the_pricing_refresher_without_a_restart() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let _pricing_binding = crate::PRICING_BINDING_TEST_LOCK.lock().await;
        let tmp = tempfile::TempDir::new().unwrap();
        let mut config = zeroclaw_config::schema::Config {
            data_dir: tmp.path().join("workspace"),
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        std::fs::create_dir_all(&config.data_dir).unwrap();
        config.gateway.require_pairing = false;
        config.providers.models.ollama.insert(
            "priced".to_string(),
            zeroclaw_config::schema::OllamaModelProviderConfig {
                base: zeroclaw_config::schema::ModelProviderConfig {
                    uri: Some("http://127.0.0.1:9".to_string()),
                    model: Some("priced-model".to_string()),
                    live_pricing: true,
                    ..Default::default()
                },
                ..Default::default()
            },
        );

        // The exact property path the config API accepts for this flag, taken
        // from the schema rather than spelled by hand.
        let live_pricing_path = config
            .prop_fields()
            .into_iter()
            .map(|field| field.name)
            .find(|name| name.contains(".priced.") && name.contains("live"))
            .expect("the schema exposes the provider's live-pricing flag");

        let (addr_tx, addr_rx) = tokio::sync::oneshot::channel();
        let addr_tx = std::sync::Mutex::new(Some(addr_tx));
        let readiness = zeroclaw_runtime::daemon::GatewayReadinessReporter::new(move |addr| {
            if let Some(tx) = addr_tx.lock().unwrap().take() {
                let _ = tx.send(addr);
            }
        });
        let server = zeroclaw_spawn::spawn!(async move {
            crate::run_gateway(
                "127.0.0.1",
                0,
                config,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                Some(readiness),
            )
            .await
        });
        let addr = tokio::time::timeout(std::time::Duration::from_secs(10), addr_rx)
            .await
            .expect("the gateway reports readiness")
            .expect("the readiness sender is kept until it fires");
        assert!(
            zeroclaw_providers::pricing::live_pricing_enabled(),
            "the refresher is bound to the gateway's config, which opts in"
        );

        let body = serde_json::json!({
            "path": live_pricing_path,
            "value": false,
        })
        .to_string();
        let request = format!(
            "PUT /api/config/prop HTTP/1.1\r\nHost: {addr}\r\nContent-Type: application/json\r\n\
             Content-Length: {}\r\nConnection: close\r\n\r\n{body}",
            body.len()
        );
        let mut stream = tokio::net::TcpStream::connect(addr).await.unwrap();
        stream.write_all(request.as_bytes()).await.unwrap();
        let mut response = String::new();
        stream.read_to_string(&mut response).await.unwrap();
        assert!(
            response.starts_with("HTTP/1.1 200"),
            "the config API accepts the opt-out: {response}"
        );

        assert!(
            !zeroclaw_providers::pricing::live_pricing_enabled(),
            "the opt-out written through the config API must reach the refresher \
             without a restart"
        );
        server.abort();
    }
}

#[cfg(all(test, feature = "channel-email"))]
mod gmail_bearer_tests {
    use super::gmail_bearer_matches;

    #[test]
    fn matching_bearer_is_accepted() {
        assert!(gmail_bearer_matches("s3cret-token", "s3cret-token"));
    }

    #[test]
    fn prefix_and_same_length_mismatches_are_rejected() {
        // A correct prefix must fail exactly like an equal-length mismatch:
        // the compare runs over the longer input regardless of where the
        // first differing byte is, so neither shape leaks progress.
        assert!(!gmail_bearer_matches("s3cret", "s3cret-token"));
        assert!(!gmail_bearer_matches("s3cret-tokeN", "s3cret-token"));
        assert!(!gmail_bearer_matches("s3cret-token-longer", "s3cret-token"));
    }

    #[test]
    fn missing_bearer_never_matches_a_configured_secret() {
        assert!(!gmail_bearer_matches("", "s3cret-token"));
    }
}
