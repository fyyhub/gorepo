//! JSON-RPC 2.0 client over a local IPC stream (Unix socket / Windows
//! named pipe, NDJSON) or WebSocket (WSS).
//!
//! Uses local JSON-RPC transport types so `zerocode` stays an RPC-only surface.

use std::fmt;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use anyhow::{Context, Result};
use serde::de::DeserializeOwned;
use serde_json::Value;
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::sync::{Notify, broadcast, mpsc, oneshot};

use crate::jsonrpc::{self, JsonRpcError, RpcOutbound, field};
use crate::wire::{ConfigFieldEntry, DoctorRunResult, FsListDirResponse, SectionShape};

const CONFIG_RENAME_TIMEOUT: Duration = Duration::from_secs(120);
const CRON_TRIGGER_TIMEOUT: Duration = Duration::from_secs(600);
const INITIALIZE_TIMEOUT: Duration = Duration::from_secs(10);
const OUTBOUND_FLUSH_TIMEOUT: Duration = Duration::from_secs(1);
const OUTBOUND_RETIRE_TIMEOUT: Duration = Duration::from_secs(30);

/// ONE absolute budget for the entire client-side relay setup: the TCP connect,
/// the outer TLS and WebSocket upgrade, the route request, the relay's `Opened`
/// answer, and - on the RPC route - the inner WSS and mTLS handshake that runs
/// over the finished tunnel.
///
/// Absolute rather than per phase: a fresh timeout per step lets an
/// unresponsive relay spend one full budget on each of them, which is how a
/// "bounded" setup still hangs for minutes. The daemon's own relay bridge bounds
/// its outbound setup the same way and with the same figure, so a client and a
/// daemon facing the same dead relay give up together instead of one waiting on
/// the other.
const RELAY_SETUP_DEADLINE: Duration = Duration::from_secs(30);

/// A single outbound write to the relay may not stall longer than this. Mirrors
/// the daemon bridge's write-stall bound, which is its dead-link interval: once
/// the link is up the peer is expected to keep reading, and one that stops must
/// not pin this pump - and the inner TLS stream behind it - forever.
///
/// Reads are deliberately NOT bounded this way. An idle session is legitimate:
/// the operator may be reading rather than typing, and silence alone is not
/// evidence of a dead link. Liveness of an established link is the keepalive
/// layer's job, not the pump's.
const RELAY_WRITE_STALL: Duration = Duration::from_secs(60);

// ── Platform local-stream shim ──────────────────────────────────

#[cfg(unix)]
type LocalStream = tokio::net::UnixStream;
#[cfg(windows)]
type LocalStream = tokio::net::windows::named_pipe::NamedPipeClient;

/// Open a connection to the daemon's local IPC endpoint.
#[cfg(unix)]
async fn open_local_stream(path: &Path) -> Result<LocalStream> {
    tokio::net::UnixStream::connect(path)
        .await
        .map_err(anyhow::Error::from)
}

#[cfg(windows)]
async fn open_local_stream(path: &Path) -> Result<LocalStream> {
    use tokio::net::windows::named_pipe::ClientOptions;
    use tokio::time::{Duration, sleep};
    // The daemon may not yet have a pending pipe instance; retry briefly.
    let name = path.to_string_lossy().into_owned();
    for _ in 0..50 {
        match ClientOptions::new().open(&name) {
            Ok(c) => return Ok(c),
            Err(e) if e.raw_os_error() == Some(231) => {
                // ERROR_PIPE_BUSY — server hasn't recreated a pending instance yet.
                sleep(Duration::from_millis(20)).await;
            }
            Err(e) => return Err(anyhow::Error::from(e)),
        }
    }
    anyhow::bail!("named pipe {name} never became available")
}

// ── Wire method names used by the TUI ────────────────────────────

pub mod method {
    pub const INITIALIZE: &str = "initialize";
    pub const CONFIG_LIST: &str = "config/list";
    pub const CONFIG_SET: &str = "config/set";
    pub const CONFIG_STATUS: &str = "config/status";
    pub const CONFIG_DELETE: &str = "config/delete";
    pub const CONFIG_RELOAD: &str = "config/reload";
    pub const CONFIG_MAP_KEYS: &str = "config/map-keys";
    pub const CONFIG_RESOLVE_ALIAS_SOURCE: &str = "config/resolve-alias-source";
    pub const CONFIG_MAP_KEY_CREATE: &str = "config/map-key-create";
    pub const CONFIG_MAP_KEY_DELETE: &str = "config/map-key-delete";
    pub const CONFIG_RENAME_MAP_KEY: &str = "config/map-key-rename";
    pub const CONFIG_TEMPLATES: &str = "config/templates";
    pub const CONFIG_SECTIONS: &str = "config/sections";
    pub const CONFIG_CATALOG_MODELS: &str = "config/catalog-models";
    // Locales
    pub const LOCALES_LIST: &str = "locales/list";
    pub const LOCALES_FETCH: &str = "locales/fetch";
    // Personality
    pub const PERSONALITY_LIST: &str = "personality/list";
    pub const PERSONALITY_GET: &str = "personality/get";
    pub const PERSONALITY_PUT: &str = "personality/put";
    pub const PERSONALITY_TEMPLATES: &str = "personality/templates";
    // Skills
    pub const SKILLS_LIST: &str = "skills/list";
    pub const SKILLS_READ: &str = "skills/read";
    pub const SKILLS_WRITE: &str = "skills/write";
    pub const SKILLS_DELETE: &str = "skills/delete";
    // Session
    pub const SESSION_NEW: &str = "session/new";
    pub const SESSION_PROMPT: &str = "session/prompt";
    pub const SESSION_CONFIGURE: &str = "session/configure";
    pub const SESSION_CANCEL: &str = "session/cancel";
    pub const SESSION_STATE: &str = "session/state";
    pub const SESSION_GIT_BRANCH: &str = "session/git_branch";
    pub const SESSION_APPROVE: &str = "session/approve";
    pub const SESSION_CLOSE: &str = "session/close";
    pub const SESSION_KILL: &str = "session/kill";
    // Dashboard
    pub const STATUS: &str = "status";
    pub const HEALTH: &str = "health";
    pub const DOCTOR_RUN: &str = "doctor/run";
    pub const COST_QUERY: &str = "cost/query";
    pub const COST_ORG: &str = "cost/org";
    pub const SESSION_LIST: &str = "session/list";
    pub const SESSION_LIST_ACP: &str = "session/list-acp";
    pub const AGENTS_STATUS: &str = "agents/status";
    pub const CRON_LIST: &str = "cron/list";
    pub const CRON_RUNS: &str = "cron/runs";
    pub const CRON_TRIGGER: &str = "cron/trigger";
    pub const MEMORY_LIST: &str = "memory/list";
    pub const MEMORY_SEARCH: &str = "memory/search";
    pub const SESSION_MESSAGES: &str = "session/messages";
    // TUI identity
    pub const TUI_LIST: &str = "tui/list";
    pub const FS_LIST_DIR: &str = "fs/list_dir";
    // Quickstart
    pub const QUICKSTART_STATE: &str = "quickstart/state";
    pub const QUICKSTART_FIELDS: &str = "quickstart/fields";
    pub const QUICKSTART_VALIDATE: &str = "quickstart/validate";
    pub const QUICKSTART_APPLY: &str = "quickstart/apply";
    pub const QUICKSTART_DISMISS: &str = "quickstart/dismiss";
    pub const SOPS_LIST: &str = "sops/list";
    pub const SOPS_GET: &str = "sops/get";
    pub const SOPS_GRAPH: &str = "sops/graph";
    pub const SOPS_RUN: &str = "sops/run";
    pub const SOPS_RUNS: &str = "sops/runs";
    pub const SOPS_RUN_OVERLAY: &str = "sops/run-overlay";
    pub const SOPS_SAVE: &str = "sops/save";
    pub const SOPS_CREATE: &str = "sops/create";
    pub const SOPS_DELETE: &str = "sops/delete";
    pub const SOPS_RENAME: &str = "sops/rename";
    pub const SOPS_DECIDE: &str = "sops/decide";
    pub const SOPS_WIRE_DRAFT: &str = "sops/wire-draft";
    pub const SOPS_GRAPH_DRAFT: &str = "sops/graph-draft";
    pub const SOPS_TRIGGER_SOURCES: &str = "sops/trigger-sources";
}

// ── Socket path resolution ───────────────────────────────────────

/// Resolve the daemon's local IPC endpoint path.
/// CLI flag > `$ZEROCLAW_SOCKET` > `<config_dir>/data/daemon.sock` on Unix
/// or a `\\.\pipe\zeroclaw-<hash>` derived name on Windows.
pub fn resolve_socket_path(config_dir: &Path) -> Result<PathBuf> {
    if let Ok(p) = std::env::var("ZEROCLAW_SOCKET") {
        let p = p.trim();
        if !p.is_empty() {
            return Ok(PathBuf::from(p));
        }
    }
    #[cfg(unix)]
    {
        Ok(config_dir.join("data").join("daemon.sock"))
    }
    #[cfg(windows)]
    {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};
        let data_dir = config_dir.join("data");
        let mut hasher = DefaultHasher::new();
        data_dir.hash(&mut hasher);
        Ok(PathBuf::from(format!(
            r"\\.\pipe\zeroclaw-{:x}",
            hasher.finish()
        )))
    }
}

/// Resolve config dir: CLI flag > `$ZEROCLAW_CONFIG_DIR` > home directory.
pub fn resolve_config_dir(cli_override: Option<&Path>) -> Result<PathBuf> {
    if let Some(dir) = cli_override {
        return Ok(dir.to_path_buf());
    }
    if let Ok(d) = std::env::var("ZEROCLAW_CONFIG_DIR") {
        let d = d.trim();
        if !d.is_empty() {
            return Ok(PathBuf::from(d));
        }
    }
    #[cfg(unix)]
    {
        let home = std::env::var("HOME").context("HOME not set")?;
        Ok(PathBuf::from(home).join(".zeroclaw"))
    }
    #[cfg(windows)]
    {
        let profile = std::env::var("USERPROFILE").context("USERPROFILE not set")?;
        Ok(PathBuf::from(profile).join(".zeroclaw"))
    }
}

// ── Notifications ────────────────────────────────────────────────

/// A server-initiated notification (no `id` field).
#[derive(Debug, Clone)]
pub struct RpcNotification {
    pub method: String,
    pub params: Value,
}

/// A server-initiated JSON-RPC request (has both `id` and `method`)
/// that expects a response back on the same id.
///
/// The daemon issues these for ACP `elicitation/create` calls when
/// the TUI advertised `clientCapabilities.elicitation.form` during
/// `initialize`. The recipient of an `RpcInboundRequest` is the
/// `Chat` widget for the targeted session — it surfaces a modal,
/// waits for the user's choice, and writes a JSON-RPC response back
/// via `RpcClient::respond_to_inbound_request`.
#[derive(Debug, Clone)]
pub struct RpcInboundRequest {
    /// The JSON-RPC `id`. Echoed back verbatim in the response.
    pub id: Value,
    pub method: String,
    pub params: Value,
}

/// Buffer size for the `session/update` notification broadcast.
///
/// Sized for N concurrent sessions streaming at once (the agent sidebar keeps
/// background sessions live): chunk volume multiplies between draw-loop
/// drains, and a `Lagged` receiver forces a durable transcript reload of
/// every tracked session, during which their live stream is gated. The draw
/// loop wakes early to drain pending notifications; this capacity is the
/// headroom for draw stalls (resize storms, full transcript rebuilds, the
/// process being descheduled) on top of that.
pub const NOTIFICATION_CHANNEL_CAPACITY: usize = 4096;

// ── Typed session updates ────────────────────────────────────────

#[derive(Debug, Clone)]
pub enum SessionUpdate {
    AgentMessageChunk {
        session_id: String,
        text: String,
    },
    AgentThoughtChunk {
        session_id: String,
        text: String,
    },
    ToolCall {
        session_id: String,
        tool_call_id: String,
        name: String,
        raw_input: serde_json::Value,
    },
    ToolResult {
        session_id: String,
        tool_call_id: String,
        raw_output: String,
    },
    ApprovalRequest {
        session_id: String,
        request_id: String,
        tool_name: String,
        arguments_summary: String,
        timeout_secs: u64,
    },
    /// Emitted once per LLM call with current context size and configured limit.
    /// `max_context_tokens` is the preemptive-trim budget the bar fills toward;
    /// `model_context_window` is the model's full capacity, used as the bar
    /// denominator when present so the trim budget can be drawn as a marker.
    /// `input_tokens_source` is the provenance of `input_tokens` ("provider" or
    /// "estimate"); an estimated count must be rendered as approximate.
    ContextUsage {
        session_id: String,
        input_tokens: Option<u64>,
        input_tokens_source: Option<String>,
        max_context_tokens: Option<u64>,
        model_context_window: Option<u64>,
    },
    /// Older complete turns were removed from structured session history.
    HistoryTrimmed {
        session_id: String,
        dropped_messages: u64,
        dropped_turns: Option<u64>,
        kept_turns: u64,
        reason: String,
        /// Configured context token budget, when the trim was token-budget
        /// driven. `None` for message-limit trims.
        token_budget: Option<u64>,
        /// Token count before trimming.
        tokens_before: Option<u64>,
        /// Token count after trimming.
        tokens_after: Option<u64>,
        /// Provenance of `tokens_before` ("provider", "estimate", "calibrated").
        tokens_before_source: Option<String>,
        /// Provenance of `tokens_after` ("provider", "estimate", "calibrated").
        tokens_after_source: Option<String>,
        /// The retained request cannot fit the configured budget (protected
        /// newest turn plus schemas) even after trimming. Absent for ordinary
        /// trims; authoritative floor signal — not `dropped_messages == 0`.
        unsatisfiable_floor: Option<bool>,
    },
    /// Terminal event for a turn. Replaces the JSON-RPC response of
    /// `session/prompt`. `outcome` distinguishes a clean finish from a cancel
    /// or a failure; the daemon-composed `content` carries the attributed
    /// reason for non-completed outcomes.
    TurnComplete {
        session_id: String,
        outcome: TurnEndOutcome,
        content: String,
        client_turn_generation: Option<u64>,
        message_count: Option<usize>,
    },
    /// Recorded spend reached `cost.warn_at_percent` of the daily or monthly
    /// limit. The turn continues; this is a heads-up only.
    BudgetWarning {
        session_id: String,
        current_usd: f64,
        limit_usd: f64,
        /// `"day"` or `"month"`.
        period: String,
    },
    /// The agent published or updated its execution plan (TodoWrite).
    /// Whole-list replacement; `entries` is the complete authoritative
    /// list. An empty vec clears the tracker.
    Plan {
        session_id: String,
        entries: Vec<crate::wire::PlanEntry>,
    },
}

impl SessionUpdate {
    /// The session this update belongs to. Every variant carries the id;
    /// multi-session panes route on it before applying the update.
    pub fn session_id(&self) -> &str {
        match self {
            SessionUpdate::AgentMessageChunk { session_id, .. }
            | SessionUpdate::AgentThoughtChunk { session_id, .. }
            | SessionUpdate::ToolCall { session_id, .. }
            | SessionUpdate::ToolResult { session_id, .. }
            | SessionUpdate::ApprovalRequest { session_id, .. }
            | SessionUpdate::ContextUsage { session_id, .. }
            | SessionUpdate::HistoryTrimmed { session_id, .. }
            | SessionUpdate::TurnComplete { session_id, .. }
            | SessionUpdate::Plan { session_id, .. }
            | SessionUpdate::BudgetWarning { session_id, .. } => session_id,
        }
    }
}

/// Wire mirror of the daemon's `TurnCompletionOutcome`. Decoded straight from
/// the `outcome` field; an unrecognised or absent value maps to `Completed` so
/// a turn never appears stuck.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TurnEndOutcome {
    Completed,
    Cancelled,
    Failed,
}

impl TurnEndOutcome {
    fn from_wire(value: Option<&serde_json::Value>) -> Self {
        value
            .and_then(|v| serde_json::from_value::<Self>(v.clone()).ok())
            .unwrap_or(Self::Completed)
    }
}

pub fn parse_session_update(params: &serde_json::Value) -> Option<SessionUpdate> {
    let kind = params.get("type")?.as_str()?;
    let sid = params.get("session_id")?.as_str()?.to_string();
    match kind {
        "agent_message_chunk" => Some(SessionUpdate::AgentMessageChunk {
            session_id: sid,
            text: params.get("text")?.as_str()?.to_string(),
        }),
        "agent_thought_chunk" => Some(SessionUpdate::AgentThoughtChunk {
            session_id: sid,
            text: params.get("text")?.as_str()?.to_string(),
        }),
        "tool_call" => Some(SessionUpdate::ToolCall {
            session_id: sid,
            tool_call_id: params.get("tool_call_id")?.as_str()?.to_string(),
            name: params.get("name")?.as_str()?.to_string(),
            raw_input: params.get("raw_input")?.clone(),
        }),
        "tool_result" => Some(SessionUpdate::ToolResult {
            session_id: sid,
            tool_call_id: params.get("tool_call_id")?.as_str()?.to_string(),
            raw_output: params.get("raw_output")?.as_str()?.to_string(),
        }),
        "approval_request" => Some(SessionUpdate::ApprovalRequest {
            session_id: sid,
            request_id: params.get("request_id")?.as_str()?.to_string(),
            tool_name: params.get("tool_name")?.as_str()?.to_string(),
            arguments_summary: params.get("arguments_summary")?.as_str()?.to_string(),
            timeout_secs: params.get("timeout_secs")?.as_u64().unwrap_or(30),
        }),
        "context_usage" => Some(SessionUpdate::ContextUsage {
            session_id: sid,
            input_tokens: params.get("input_tokens").and_then(|v| v.as_u64()),
            input_tokens_source: params
                .get("input_tokens_source")
                .and_then(|v| v.as_str())
                .map(str::to_string),
            max_context_tokens: params.get("max_context_tokens").and_then(|v| v.as_u64()),
            model_context_window: params.get("model_context_window").and_then(|v| v.as_u64()),
        }),
        "history_trimmed" => Some(SessionUpdate::HistoryTrimmed {
            session_id: sid,
            dropped_messages: params.get("dropped_messages")?.as_u64()?,
            dropped_turns: params.get("dropped_turns").and_then(|v| v.as_u64()),
            kept_turns: params.get("kept_turns")?.as_u64()?,
            reason: params.get("reason")?.as_str()?.to_string(),
            token_budget: params.get("token_budget").and_then(|v| v.as_u64()),
            tokens_before: params.get("tokens_before").and_then(|v| v.as_u64()),
            tokens_after: params.get("tokens_after").and_then(|v| v.as_u64()),
            tokens_before_source: params
                .get("tokens_before_source")
                .and_then(|v| v.as_str())
                .map(str::to_string),
            tokens_after_source: params
                .get("tokens_after_source")
                .and_then(|v| v.as_str())
                .map(str::to_string),
            unsatisfiable_floor: params.get("unsatisfiable_floor").and_then(|v| v.as_bool()),
        }),
        "budget_warning" => Some(SessionUpdate::BudgetWarning {
            session_id: sid,
            current_usd: params.get("current_usd")?.as_f64()?,
            limit_usd: params.get("limit_usd")?.as_f64()?,
            period: params.get("period")?.as_str()?.to_string(),
        }),
        "turn_complete" => Some(SessionUpdate::TurnComplete {
            session_id: sid,
            outcome: TurnEndOutcome::from_wire(params.get("outcome")),
            content: params
                .get("content")
                .and_then(|v| v.as_str())
                .unwrap_or_default()
                .to_string(),
            client_turn_generation: params
                .get("client_turn_generation")
                .and_then(|v| v.as_u64()),
            message_count: params
                .get("message_count")
                .and_then(|v| v.as_u64())
                .map(|n| n as usize),
        }),
        "plan" => {
            let entries = params.get("entries")?.clone();
            let entries: Vec<crate::wire::PlanEntry> = serde_json::from_value(entries).ok()?;
            Some(SessionUpdate::Plan {
                session_id: sid,
                entries,
            })
        }
        _ => None,
    }
}

pub fn spawn_notification_router(
    mut bcast_rx: broadcast::Receiver<RpcNotification>,
    update_tx: mpsc::Sender<SessionUpdate>,
) -> tokio::task::JoinHandle<()> {
    tokio::spawn(async move {
        loop {
            match bcast_rx.recv().await {
                Ok(notif) => {
                    if notif.method != "session/update" {
                        continue;
                    }
                    if let Some(update) = parse_session_update(&notif.params)
                        && update_tx.send(update).await.is_err()
                    {
                        break;
                    }
                }
                Err(broadcast::error::RecvError::Lagged(_)) => continue,
                Err(broadcast::error::RecvError::Closed) => break,
            }
        }
    })
}

// ── Transport ────────────────────────────────────────────────────

/// Transport protocol of the established RPC connection.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Transport {
    /// Local IPC stream — Unix socket on Unix, named pipe on Windows.
    Local,
    Wss,
}

// ── Connection state ──────────────────────────────────────────────

/// Observable connection state, written by the socket read task.
/// This is the single source of truth for daemon connectivity.
#[derive(Clone, Debug)]
pub enum ConnectionState {
    Connected,
    Disconnected { reason: String },
}

fn replace_connection_state(state: &Mutex<ConnectionState>, next: ConnectionState) {
    match state.lock() {
        Ok(mut state) => *state = next,
        Err(poisoned) => *poisoned.into_inner() = next,
    }
}

fn disconnect_rpc(rpc: &RpcOutbound, state: &Mutex<ConnectionState>, reason: String) {
    replace_connection_state(
        state,
        ConnectionState::Disconnected {
            reason: reason.clone(),
        },
    );
    rpc.fail_pending(&format!("Connection closed: {reason}"));
}

fn clone_connection_state(state: &Mutex<ConnectionState>) -> ConnectionState {
    match state.lock() {
        Ok(state) => state.clone(),
        Err(poisoned) => poisoned.into_inner().clone(),
    }
}

/// The TUI and daemon are built from the same package version and do not
/// promise cross-version wire compatibility.
#[derive(Debug)]
pub struct DaemonVersionMismatch {
    client_version: &'static str,
    server_version: String,
}

impl DaemonVersionMismatch {
    fn new(server_version: impl Into<String>) -> Self {
        Self {
            client_version: env!("CARGO_PKG_VERSION"),
            server_version: server_version.into(),
        }
    }

    pub fn client_version(&self) -> &'static str {
        self.client_version
    }

    pub fn server_version(&self) -> &str {
        &self.server_version
    }
}

impl fmt::Display for DaemonVersionMismatch {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "Version mismatch: zerocode is {} but the daemon is {}. \
             Rebuild and restart the daemon from the same checkout as zerocode.",
            self.client_version, self.server_version
        )
    }
}

impl std::error::Error for DaemonVersionMismatch {}

/// The transport connected, but the daemon did not finish the ACP handshake.
#[derive(Debug)]
pub struct DaemonInitializeTimeout {
    timeout: Duration,
}

impl DaemonInitializeTimeout {
    pub(crate) fn new(timeout: Duration) -> Self {
        Self { timeout }
    }

    pub fn timeout_seconds(&self) -> u64 {
        self.timeout.as_secs()
    }
}

impl fmt::Display for DaemonInitializeTimeout {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "daemon did not complete initialization within {}s",
            self.timeout_seconds()
        )
    }
}

impl std::error::Error for DaemonInitializeTimeout {}

/// A single RPC did not get a reply within its client-side deadline. The
/// connection is still up; the daemon is busy or wedged on this method.
/// Callers that own a UI surface should report this and stay alive — a
/// stalled `config/list` is not a reason to exit the TUI.
#[derive(Debug)]
pub struct DaemonRpcTimeout {
    pub method: String,
    pub timeout: Duration,
}

impl DaemonRpcTimeout {
    pub fn from_anyhow(error: &anyhow::Error) -> Option<&Self> {
        error.downcast_ref::<Self>()
    }
}

impl fmt::Display for DaemonRpcTimeout {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "RPC {}: timed out after {}s",
            self.method,
            self.timeout.as_secs()
        )
    }
}

/// The daemon's reason when it refused an RPC for the caller's permissions
/// (`FORBIDDEN`): the principal lacks the method's grant, or the method is
/// limited to administrators. Read from the structured error, never from its
/// text. Like a stalled call, one pane's refusal is not a reason to exit the
/// TUI: a pane that only reads shows the reason and stays open.
pub(crate) fn forbidden_reason(error: &anyhow::Error) -> Option<&str> {
    error
        .downcast_ref::<crate::jsonrpc::JsonRpcError>()
        .filter(|error| error.code == crate::jsonrpc::error_codes::FORBIDDEN)
        .map(|error| error.message.as_str())
}

impl std::error::Error for DaemonRpcTimeout {}

#[derive(Debug)]
pub(crate) struct InitializeResponse {
    server_version: String,
    server_pid: Option<u32>,
    tui_id: Option<String>,
    tui_sig: Option<String>,
    pub(crate) commands: Vec<crate::wire::CommandDescriptor>,
}

/// One-release fallback for daemons from the pre-catalogue 0.8.x line, which
/// share the current package and protocol versions but omit `commands`.
///
/// These descriptors preserve the shared tokens ZeroCode accepted before the
/// RPC catalogue existed. New daemons remain authoritative, including when
/// they explicitly advertise an empty catalogue.
fn legacy_tui_command_descriptors() -> Vec<crate::wire::CommandDescriptor> {
    vec![
        crate::wire::CommandDescriptor {
            id: "help".into(),
            name: "help".into(),
            aliases: Vec::new(),
        },
        crate::wire::CommandDescriptor {
            id: "new".into(),
            name: "new".into(),
            aliases: vec!["new-session".into()],
        },
        crate::wire::CommandDescriptor {
            id: "model".into(),
            name: "model".into(),
            aliases: Vec::new(),
        },
    ]
}

fn parse_initialize_commands(resp: &Value) -> Result<Vec<crate::wire::CommandDescriptor>> {
    match resp.get("commands") {
        Some(commands) => serde_json::from_value(commands.clone())
            .context("invalid command descriptors in initialize response"),
        None => Ok(legacy_tui_command_descriptors()),
    }
}

pub(crate) fn parse_initialize_response(resp: &Value) -> Result<InitializeResponse> {
    let server_version = resp
        .get("server_version")
        .and_then(Value::as_str)
        .unwrap_or("unknown")
        .to_string();
    if server_version != env!("CARGO_PKG_VERSION") {
        return Err(DaemonVersionMismatch::new(server_version).into());
    }

    Ok(InitializeResponse {
        server_version,
        server_pid: resp
            .get("server_pid")
            .and_then(Value::as_u64)
            .and_then(|pid| u32::try_from(pid).ok()),
        tui_id: resp.get("tui_id").and_then(Value::as_str).map(String::from),
        tui_sig: resp
            .get("tui_sig")
            .and_then(Value::as_str)
            .map(String::from),
        commands: parse_initialize_commands(resp)?,
    })
}

/// Retain the handshake's structured authentication verdict so startup can
/// re-enroll a saved login once. Never infer this from error message text.
#[derive(Debug)]
pub(crate) struct AuthenticationRequired;

impl fmt::Display for AuthenticationRequired {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("initialize: authentication required (-32010)")
    }
}
impl std::error::Error for AuthenticationRequired {}

async fn request_initialize(
    rpc: &RpcOutbound,
    init_params: Value,
    timeout: Duration,
) -> Result<Value> {
    match tokio::time::timeout(timeout, rpc.request(method::INITIALIZE, init_params)).await {
        Ok(Ok(resp)) => Ok(resp),
        Ok(Err(e)) if e.code == zeroclaw_api::jsonrpc::error_codes::AUTH_REQUIRED => {
            Err(AuthenticationRequired.into())
        }
        Ok(Err(e)) => Err(anyhow::Error::msg(format!(
            "initialize: {} ({})",
            e.message, e.code
        ))),
        Err(_) => Err(DaemonInitializeTimeout::new(timeout).into()),
    }
}

// ── Client ───────────────────────────────────────────────────────

/// Classify an incoming JSON-RPC frame and route it to the right
/// sink.
///
/// Frames are one of three shapes (per JSON-RPC 2.0):
/// 1. **Response** — has `id` plus `result` or `error`, but no
///    `method`. Routed to `RpcOutbound::dispatch_response` to wake
///    the pending outbound call on the same id.
/// 2. **Server-initiated request** — has both `id` and `method`.
///    Routed to `inbound_tx` for an in-TUI handler to answer (today:
///    `elicitation/create`). The id is preserved verbatim so the
///    response correlates correctly.
/// 3. **Notification** — has `method` but no `id`. Routed to
///    `notif_tx` for the existing notification router.
fn route_inbound_frame(
    rpc: &Arc<RpcOutbound>,
    notif_tx: &broadcast::Sender<RpcNotification>,
    inbound_tx: Option<&mpsc::UnboundedSender<RpcInboundRequest>>,
    frame: Value,
) -> Option<RpcInboundRequest> {
    let id = frame.get(field::ID).cloned();
    let method = frame
        .get(field::METHOD)
        .and_then(Value::as_str)
        .map(str::to_string);

    match (id, method) {
        // Server-initiated request: both id and method present.
        (Some(id), Some(method)) if !id.is_null() => {
            let params = frame.get("params").cloned().unwrap_or(Value::Null);
            let request = RpcInboundRequest { id, method, params };
            if let Some(inbound_tx) = inbound_tx {
                return inbound_tx.send(request).err().map(|error| error.0);
            }
            return Some(request);
        }
        // Response: id present (typically a string), result or error,
        // no method.
        (Some(id), None) => {
            // The outbound id format is always a string; defensively
            // only dispatch when we can stringify it.
            if let Some(id_str) = id.as_str() {
                let result = frame.get(field::RESULT).cloned();
                let error: Option<JsonRpcError> = frame
                    .get(field::ERROR)
                    .and_then(|e| serde_json::from_value(e.clone()).ok());
                rpc.dispatch_response(id_str, result, error);
            }
        }
        // Notification: method present, no id (or null id).
        (None, Some(method)) => {
            let params = frame.get("params").cloned().unwrap_or(Value::Null);
            let _ = notif_tx.send(RpcNotification { method, params });
        }
        _ => {}
    }
    None
}

#[derive(Debug)]
enum ReaderControl {
    Quiesce(oneshot::Sender<()>),
}

#[derive(Debug, Default)]
struct WssFlushAck {
    pending: Mutex<Option<(Vec<u8>, oneshot::Sender<()>)>>,
}

impl WssFlushAck {
    fn register(&self, payload: Vec<u8>) -> Option<oneshot::Receiver<()>> {
        let mut pending = self.pending.lock().ok()?;
        let (ack_tx, ack_rx) = oneshot::channel();
        *pending = Some((payload, ack_tx));
        Some(ack_rx)
    }

    fn acknowledge(&self, payload: &[u8]) {
        let Ok(mut pending) = self.pending.lock() else {
            return;
        };
        if pending
            .as_ref()
            .is_some_and(|(expected, _)| expected == payload)
            && let Some((_, ack)) = pending.take()
        {
            let _ = ack.send(());
        }
    }
}

fn handle_wss_reader_message(
    message: Option<
        std::result::Result<
            tokio_tungstenite::tungstenite::Message,
            tokio_tungstenite::tungstenite::Error,
        >,
    >,
    rpc: &Arc<RpcOutbound>,
    notif_tx: &broadcast::Sender<RpcNotification>,
    inbound_tx: Option<&mpsc::UnboundedSender<RpcInboundRequest>>,
    inbound_responses: &Arc<InboundResponseTracker>,
    conn_state: &Arc<Mutex<ConnectionState>>,
    flush_ack: &WssFlushAck,
) -> bool {
    use tokio_tungstenite::tungstenite::Message;

    match message {
        Some(Ok(Message::Text(text))) => {
            let frame: Value = match serde_json::from_str(&text) {
                Ok(value) => value,
                Err(_) => return true,
            };
            if let Some(request) = route_inbound_frame(rpc, notif_tx, inbound_tx, frame) {
                respond_to_retired_inbound_request(rpc, inbound_responses, request);
            }
        }
        Some(Ok(Message::Close(frame))) => {
            let reason = frame
                .map(|frame| frame.reason.to_string())
                .unwrap_or_else(|| "server closed connection".to_string());
            disconnect_rpc(rpc, conn_state, reason);
            return false;
        }
        Some(Ok(Message::Pong(payload))) => {
            flush_ack.acknowledge(payload.as_ref());
        }
        Some(Ok(Message::Ping(_) | Message::Frame(_))) => {}
        Some(Ok(Message::Binary(_))) => {}
        Some(Err(error)) => {
            disconnect_rpc(rpc, conn_state, error.to_string());
            return false;
        }
        None => {
            disconnect_rpc(rpc, conn_state, "EOF (WSS connection closed)".to_string());
            return false;
        }
    }
    true
}

#[derive(Debug)]
pub struct RpcClient {
    pub(crate) rpc: Arc<RpcOutbound>,
    read_task: tokio::task::JoinHandle<()>,
    /// Retirement closes the app-facing request queue while keeping the
    /// transport reader alive to answer requests that cross the cutover.
    reader_control: Option<mpsc::UnboundedSender<ReaderControl>>,
    router_task: tokio::task::JoinHandle<()>,
    /// Drains the outbound queue into the transport. `None` on the local socket
    /// path, whose writer is owned by its own reader loop.
    writer_task: Option<tokio::task::JoinHandle<()>>,
    /// The relay tunnel pump, when this client runs over a relay. Held so
    /// replacing the client also reclaims the relay route instead of leaving a
    /// pump reading a link nobody consumes.
    relay_pump: Option<tokio::task::JoinHandle<()>>,
    pub server_version: String,
    /// OS process ID reported by the daemon during initialize.
    pub server_pid: Option<u32>,
    notifications_bcast: broadcast::Sender<RpcNotification>,
    /// Single-consumer queue for server-initiated requests that expect a
    /// response (today: `elicitation/create`). Keeping the receiver here until
    /// the app claims it preserves requests that arrive during pane startup.
    inbound_requests_rx: Mutex<Option<mpsc::UnboundedReceiver<RpcInboundRequest>>>,
    /// Responses accepted by the app but not yet enqueued to the bounded
    /// writer. Registration is synchronous so an ordered retirement flush
    /// cannot overtake a responder that Tokio has not polled yet.
    inbound_responses: Arc<InboundResponseTracker>,
    connection_state: Arc<Mutex<ConnectionState>>,
    /// TUI session UID assigned by the daemon during initialize.
    pub tui_id: Option<String>,
    /// HMAC signature for reconnection. Pass back in next initialize.
    pub tui_sig: Option<String>,
    /// Transport protocol of this connection.
    transport: Transport,
    /// Shared TUI command metadata received from the daemon's canonical
    /// command catalogue during initialization.
    commands: Vec<crate::wire::CommandDescriptor>,
}

#[derive(Debug, Default)]
struct InboundResponseTracker {
    pending: AtomicUsize,
    idle: Notify,
}

impl InboundResponseTracker {
    fn register(self: &Arc<Self>) -> InboundResponseGuard {
        self.pending.fetch_add(1, Ordering::AcqRel);
        InboundResponseGuard {
            tracker: Arc::clone(self),
        }
    }

    async fn wait_until_idle(&self) {
        loop {
            let idle = self.idle.notified();
            tokio::pin!(idle);
            idle.as_mut().enable();
            if self.pending.load(Ordering::Acquire) == 0 {
                return;
            }
            idle.await;
        }
    }
}

struct InboundResponseGuard {
    tracker: Arc<InboundResponseTracker>,
}

impl Drop for InboundResponseGuard {
    fn drop(&mut self) {
        if self.tracker.pending.fetch_sub(1, Ordering::AcqRel) == 1 {
            self.tracker.idle.notify_waiters();
        }
    }
}

/// Build the one terminal response used when an app router is retired.
pub(crate) fn terminal_inbound_response(
    request: RpcInboundRequest,
) -> (Value, std::result::Result<Value, JsonRpcError>) {
    let response = if request.method == "elicitation/create" {
        Ok(serde_json::json!({ "action": "cancel" }))
    } else {
        Err(JsonRpcError {
            code: crate::jsonrpc::error_codes::METHOD_NOT_FOUND,
            message: format!("Method not found: {}", request.method),
            data: None,
        })
    };
    (request.id, response)
}

fn enqueue_inbound_responses(
    rpc: Arc<RpcOutbound>,
    tracker: Arc<InboundResponseTracker>,
    responses: Vec<(Value, std::result::Result<Value, JsonRpcError>)>,
) {
    if responses.is_empty() {
        return;
    }
    let guard = tracker.register();
    tokio::spawn(async move {
        let _guard = guard;
        for (id, result) in responses {
            let _ = rpc.respond(id, result).await;
        }
    });
}

fn respond_to_retired_inbound_request(
    rpc: &Arc<RpcOutbound>,
    tracker: &Arc<InboundResponseTracker>,
    request: RpcInboundRequest,
) {
    enqueue_inbound_responses(
        Arc::clone(rpc),
        Arc::clone(tracker),
        vec![terminal_inbound_response(request)],
    );
}

/// Dial the daemon through a nominated relay instead of connecting directly.
#[derive(Debug, Clone)]
pub struct RelayDial {
    /// Relay address (`host:port`) to connect to.
    pub relay_addr: String,
    /// Server name presented for the relay's outer TLS certificate (its SAN).
    /// Defaults to the host portion of `relay_addr` when unset.
    pub relay_host: String,
    /// Node-id of the target daemon to request from the relay.
    pub node_id: String,
    /// PEM CA to trust for the relay's outer certificate. When set, this wins
    /// over remembered pins and TOFU; when unset (and not insecure) the built-in
    /// public webpki roots are used.
    pub relay_ca_path: Option<String>,
    /// Skip verification of the relay's outer certificate (self-signed dev only).
    pub relay_insecure: bool,
    /// Expected relay OUTER-leaf SHA-256 pin (`--relay-pin` or the enrollment-
    /// delivered `relay_cert_pin`). Used only when no `relay_ca_path` is set.
    pub relay_pin: Option<String>,
    /// Opt-in trust-on-first-use for the relay's outer leaf: accept the first cert
    /// and persist its pin to `pin_store` so later runs pin it. Ignored when a
    /// relay CA or pin is configured.
    pub relay_tofu: bool,
    /// Where to persist a TOFU-observed pin (`<config_dir>/relay/relay_pin`).
    pub pin_store: Option<std::path::PathBuf>,
    /// Outer-mTLS variant: PEM cert/key presented to the relay on the OUTER layer
    /// (when the relay sets `outer_client_auth`). Separate from the inner mTLS.
    pub outer_client_cert: Option<String>,
    pub outer_client_key: Option<String>,
}

/// TLS verification + mutual-TLS client identity for a WSS connection.
#[derive(Debug, Clone, Default)]
pub struct ClientTls {
    /// Disable server certificate verification (self-signed dev only).
    pub skip_verify: bool,
    /// PEM CA certificate to verify the daemon against (mutual TLS). When unset
    /// and not skipping, the system / webpki roots are used.
    pub ca_cert_path: Option<String>,
    /// PEM client certificate to present to the daemon (mutual TLS).
    pub client_cert_path: Option<String>,
    /// PEM private key for `client_cert_path`.
    pub client_key_path: Option<String>,
}

impl ClientTls {
    /// True when no custom TLS material is configured (plain default path). Any
    /// lone field (including a stray `client_key_path`) forces the custom path so
    /// the cert+key must-come-together validation in `wss_tls_config` runs.
    pub fn is_default(&self) -> bool {
        !self.skip_verify
            && self.ca_cert_path.is_none()
            && self.client_cert_path.is_none()
            && self.client_key_path.is_none()
    }
}

/// Verifier that accepts every server certificate without checking. Used only on
/// the explicit `skip_verify` path (insecure; self-signed dev only).
#[derive(Debug)]
struct NoVerify;

impl rustls::client::danger::ServerCertVerifier for NoVerify {
    fn verify_server_cert(
        &self,
        _end_entity: &rustls::pki_types::CertificateDer<'_>,
        _intermediates: &[rustls::pki_types::CertificateDer<'_>],
        _server_name: &rustls::pki_types::ServerName<'_>,
        _ocsp_response: &[u8],
        _now: rustls::pki_types::UnixTime,
    ) -> Result<rustls::client::danger::ServerCertVerified, rustls::Error> {
        Ok(rustls::client::danger::ServerCertVerified::assertion())
    }

    fn verify_tls12_signature(
        &self,
        _message: &[u8],
        _cert: &rustls::pki_types::CertificateDer<'_>,
        _dss: &rustls::DigitallySignedStruct,
    ) -> Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error> {
        Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
    }

    fn verify_tls13_signature(
        &self,
        _message: &[u8],
        _cert: &rustls::pki_types::CertificateDer<'_>,
        _dss: &rustls::DigitallySignedStruct,
    ) -> Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error> {
        Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
    }

    fn supported_verify_schemes(&self) -> Vec<rustls::SignatureScheme> {
        rustls::crypto::ring::default_provider()
            .signature_verification_algorithms
            .supported_schemes()
    }
}

/// Persist a TOFU-observed relay outer-leaf pin (sha256 hex) to `path` at `0600`,
/// creating parent dirs. Best-effort: a write failure just means we TOFU again
/// next run (the connection already succeeded).
pub(crate) fn persist_relay_pin(path: &std::path::Path, pin: &str) {
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    #[cfg(unix)]
    {
        use std::io::Write as _;
        use std::os::unix::fs::OpenOptionsExt as _;
        if let Ok(mut f) = std::fs::OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(true)
            .mode(0o600)
            .open(path)
        {
            let _ = f.write_all(pin.as_bytes());
        }
    }
    #[cfg(not(unix))]
    {
        let _ = std::fs::write(path, pin.as_bytes());
    }
}

/// Outer TLS to the relay with a trust-on-first-use verifier purely to OBSERVE
/// its leaf certificate fingerprint (it is not yet trusted/pinned), so the
/// operator can confirm it interactively before it is remembered. Returns the
/// SHA-256 pin the relay would be pinned to. The outer TLS is a metadata boundary;
/// the inner mutual TLS to the daemon is unaffected (A2).
///
/// The probe runs under the same absolute setup budget as a real dial: it is
/// the FIRST thing an interactive relay session does, and an unreachable or
/// silent relay would otherwise hold the operator at a prompt that never
/// resolves.
pub async fn probe_relay_cert_pin(relay_addr: &str, relay_host: &str) -> Result<String> {
    let deadline = tokio::time::Instant::now() + RELAY_SETUP_DEADLINE;
    within_relay_setup(deadline, "the relay trust probe", async {
        probe_relay_cert_pin_unbounded(relay_addr, relay_host).await
    })
    .await
}

async fn probe_relay_cert_pin_unbounded(relay_addr: &str, relay_host: &str) -> Result<String> {
    let tcp = tokio::net::TcpStream::connect(relay_addr)
        .await
        .with_context(|| format!("connecting to relay {relay_addr}"))?;
    let verifier = Arc::new(crate::client_crypto::RelayPinVerifier::tofu());
    let cfg = rustls::ClientConfig::builder_with_provider(Arc::new(
        rustls::crypto::ring::default_provider(),
    ))
    .with_safe_default_protocol_versions()
    .expect("ring provider supports default protocol versions")
    .dangerous()
    .with_custom_certificate_verifier(verifier.clone())
    .with_no_client_auth();
    let connector = tokio_rustls::TlsConnector::from(Arc::new(cfg));
    let server_name = rustls::pki_types::ServerName::try_from(relay_host.to_string())
        .with_context(|| format!("relay host '{relay_host}' as a TLS server name"))?;
    let _tls = connector
        .connect(server_name, tcp)
        .await
        .with_context(|| format!("relay outer TLS handshake to {relay_addr}"))?;
    verifier
        .observed_pin()
        .context("the relay presented no certificate to pin")
}

/// Load PEM certificates from a file into DER.
fn load_pem_certs(path: &str) -> Result<Vec<rustls::pki_types::CertificateDer<'static>>> {
    let pem = std::fs::read(path).with_context(|| format!("reading certificate file {path}"))?;
    rustls_pemfile::certs(&mut &pem[..])
        .collect::<std::result::Result<Vec<_>, _>>()
        .with_context(|| format!("parsing PEM certificates from {path}"))
}

/// Load the daemon CA cached by enrollment. The enrollment SAS binds exactly one
/// daemon trust anchor, so the connect path must not later broaden trust by
/// accepting every PEM block in the cached file.
fn load_single_daemon_ca_cert(path: &str) -> Result<rustls::pki_types::CertificateDer<'static>> {
    let certs = load_pem_certs(path)?;
    match certs.len() {
        0 => anyhow::bail!("no daemon CA certificate found in {path}"),
        1 => Ok(certs.into_iter().next().expect("checked exactly one cert")),
        n => anyhow::bail!(
            "cached daemon CA file {path} must contain exactly one daemon CA certificate, got {n}"
        ),
    }
}

/// Load a PEM private key from a file into DER.
fn load_pem_key(path: &str) -> Result<rustls::pki_types::PrivateKeyDer<'static>> {
    let pem = std::fs::read(path).with_context(|| format!("reading key file {path}"))?;
    rustls_pemfile::private_key(&mut &pem[..])
        .with_context(|| format!("parsing private key from {path}"))?
        .ok_or_else(|| anyhow::Error::msg(format!("no private key found in {path}")))
}

/// Open a tunnel to the daemon through a nominated relay.
///
/// Establishes the OUTER TLS + WebSocket session to the relay, requests the
/// target `node_id`, and on `Opened` returns an in-memory byte stream over which
/// the caller runs the INNER WSS + mTLS. A pump task bridges that byte stream
/// to/from the relay's binary `DATA` frames; the relay only ever forwards the
/// (still-encrypted) inner bytes and never sees plaintext.
#[derive(Debug, Clone, Copy)]
enum RelayRoute {
    Wss,
    Enrollment,
}

impl RelayRoute {
    fn open_control(self, node_id: String) -> crate::relay_proto::Control {
        match self {
            Self::Wss => crate::relay_proto::Control::Connect { node_id },
            Self::Enrollment => crate::relay_proto::Control::Enroll { node_id },
        }
    }

    fn send_context(self) -> &'static str {
        match self {
            Self::Wss => "sending relay Connect",
            Self::Enrollment => "sending relay Enroll",
        }
    }
}

fn relay_outer_connector(
    relay: &RelayDial,
) -> Result<(
    Option<tokio_tungstenite::Connector>,
    Option<Arc<crate::client_crypto::RelayPinVerifier>>,
)> {
    // Outer TLS connector verifying the relay's OWN certificate (distinct from the
    // inner mTLS to the daemon). Precedence: insecure (dev) > configured CA > a
    // leaf pin (explicit, enrollment-delivered, or remembered) > opt-in TOFU >
    // the public roots (`None`). The outer TLS is a metadata boundary, not the
    // RPC boundary (A2).
    let builder = || {
        rustls::ClientConfig::builder_with_provider(Arc::new(
            rustls::crypto::ring::default_provider(),
        ))
        .with_safe_default_protocol_versions()
        .expect("ring provider supports default protocol versions")
    };
    // Apply the outer-mTLS client cert (when configured) to a server-verified
    // builder and wrap it as a connector. The inner mTLS is separate.
    let finish = |verified: rustls::ConfigBuilder<
        rustls::ClientConfig,
        rustls::client::WantsClientCert,
    >|
     -> Result<tokio_tungstenite::Connector> {
        let cfg = match (&relay.outer_client_cert, &relay.outer_client_key) {
            (Some(c), Some(k)) => {
                let chain = load_pem_certs(c)?;
                let key = load_pem_key(k)?;
                verified
                    .with_client_auth_cert(chain, key)
                    .context("loading the relay outer client cert/key")?
            }
            _ => verified.with_no_client_auth(),
        };
        Ok(tokio_tungstenite::Connector::Rustls(Arc::new(cfg)))
    };
    let mut tofu_verifier: Option<Arc<crate::client_crypto::RelayPinVerifier>> = None;
    let outer = if relay.relay_insecure {
        Some(finish(
            builder()
                .dangerous()
                .with_custom_certificate_verifier(Arc::new(NoVerify)),
        )?)
    } else if let Some(ca) = &relay.relay_ca_path {
        let mut roots = rustls::RootCertStore::empty();
        for cert in load_pem_certs(ca)? {
            roots.add(cert).context("adding relay CA to root store")?;
        }
        Some(finish(builder().with_root_certificates(roots))?)
    } else if let Some(pin) = relay.relay_pin.as_deref().filter(|p| !p.is_empty()) {
        let v = Arc::new(crate::client_crypto::RelayPinVerifier::pinned(
            pin.to_string(),
        ));
        Some(finish(
            builder().dangerous().with_custom_certificate_verifier(v),
        )?)
    } else if relay.relay_tofu {
        let v = Arc::new(crate::client_crypto::RelayPinVerifier::tofu());
        tofu_verifier = Some(v.clone());
        Some(finish(
            builder().dangerous().with_custom_certificate_verifier(v),
        )?)
    } else if relay.outer_client_cert.is_some() {
        // Public-CA relay that also requires an outer client cert: build an
        // explicit public-roots connector (the plain default below cannot carry a
        // client cert).
        let mut roots = rustls::RootCertStore::empty();
        roots.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
        Some(finish(builder().with_root_certificates(roots))?)
    } else {
        None
    };
    Ok((outer, tofu_verifier))
}

/// A relay tunnel: the byte stream the inner TLS runs over, plus the pump task
/// that moves DATA frames between that stream and the relay link.
///
/// The two travel together because dropping the stream is not what stops the
/// pump - the pump owns the relay link and only notices a closed stream on its
/// next read. An owner that replaces or abandons a tunnel aborts the pump.
pub(crate) struct RelayTunnel {
    io: tokio::io::DuplexStream,
    pump: tokio::task::JoinHandle<()>,
}

/// Owns a relay pump and aborts it when dropped.
///
/// Dropping a `JoinHandle` detaches the task; it does not stop it. A pump left
/// that way keeps its relay route allocated and can stay parked in a DATA write,
/// in its write-stall budget, or in the closing handshake, and nothing on the
/// client can reach it again. This guard makes the cleanup structural: every way
/// out of a scope holding one - success, `?`, a timeout dropping the whole
/// future, a panic - runs the abort, so a caller cannot forget the path it did
/// not think about.
///
/// Releasing the guard hands the task on to an owner that will keep it running,
/// which is what the RPC path does when a session adopts its tunnel.
pub struct RelayPumpGuard(Option<tokio::task::JoinHandle<()>>);

impl RelayPumpGuard {
    /// Give up ownership without aborting, for a caller that takes over the
    /// task's lifetime.
    fn release(mut self) -> Option<tokio::task::JoinHandle<()>> {
        self.0.take()
    }

    /// Watch the guarded task without owning it. Test-only: the guard's whole
    /// purpose is that nothing else needs to reach the pump.
    #[cfg(test)]
    fn abort_handle(&self) -> Option<tokio::task::AbortHandle> {
        self.0.as_ref().map(|h| h.abort_handle())
    }
}

impl Drop for RelayPumpGuard {
    fn drop(&mut self) {
        if let Some(pump) = self.0.take() {
            pump.abort();
        }
    }
}

/// An enrollment tunnel: the plaintext byte stream the enrollment TLS runs over,
/// and the guard that retires its pump.
///
/// Enrollment is the path with no session to hand the pump to - the exchange
/// finishes, fails, or times out, and the tunnel is done either way - so the
/// pump's lifetime is bound to this value rather than to a caller's discipline.
///
/// It has no `Drop` of its own so that [`Self::split`] can hand the stream and
/// the guard out separately; the guard keeps its own destructor.
pub struct EnrollmentTunnel {
    io: tokio::io::DuplexStream,
    pump: RelayPumpGuard,
}

impl EnrollmentTunnel {
    /// Split into the stream to run TLS over and the guard to keep alive for as
    /// long as that stream is in use. Hold the guard in the same scope as the
    /// exchange: dropping it retires the pump.
    pub fn split(self) -> (tokio::io::DuplexStream, RelayPumpGuard) {
        (self.io, self.pump)
    }
}

/// Run one step of relay setup against the shared absolute deadline.
///
/// Every step of a setup passes through here with the SAME `deadline`, so the
/// budget is spent once across the whole sequence rather than renewed per phase.
async fn within_relay_setup<T>(
    deadline: tokio::time::Instant,
    what: &str,
    step: impl std::future::Future<Output = Result<T>>,
) -> Result<T> {
    match tokio::time::timeout_at(deadline, step).await {
        Ok(result) => result,
        Err(_) => anyhow::bail!(
            "{what} did not complete within the {}s relay setup budget; the relay is \
             unreachable, or it accepted the connection and then stopped responding",
            RELAY_SETUP_DEADLINE.as_secs()
        ),
    }
}

/// Send one frame to the relay under [`RELAY_WRITE_STALL`].
///
/// `false` means the link is unusable - errored, closed, or making no progress -
/// and the caller must tear the tunnel down rather than keep waiting on it.
async fn relay_send<S>(sink: &mut S, msg: tokio_tungstenite::tungstenite::Message) -> bool
where
    S: futures_util::SinkExt<tokio_tungstenite::tungstenite::Message> + Unpin,
{
    matches!(
        tokio::time::timeout(RELAY_WRITE_STALL, sink.send(msg)).await,
        Ok(Ok(()))
    )
}

async fn dial_through_relay(
    relay: &RelayDial,
    route: RelayRoute,
    deadline: tokio::time::Instant,
) -> Result<RelayTunnel> {
    within_relay_setup(
        deadline,
        "the relay tunnel setup",
        dial_through_relay_unbounded(relay, route),
    )
    .await
}

/// The setup itself. Every caller reaches it through [`dial_through_relay`], so
/// it always runs inside the shared deadline and needs no timeout of its own.
async fn dial_through_relay_unbounded(relay: &RelayDial, route: RelayRoute) -> Result<RelayTunnel> {
    use crate::relay_proto::{
        ConnWindow, Control, INITIAL_WINDOW, MAX_DATA_PAYLOAD, SUBPROTOCOL, decode_data,
        encode_data,
    };
    use futures_util::StreamExt;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio_tungstenite::tungstenite::Message;

    let tcp = tokio::net::TcpStream::connect(&relay.relay_addr)
        .await
        .with_context(|| format!("connecting to relay {}", relay.relay_addr))?;

    let (outer, tofu_verifier) = relay_outer_connector(relay)?;

    let relay_uri: tokio_tungstenite::tungstenite::http::Uri =
        format!("wss://{}/", relay.relay_host)
            .parse()
            .context("building relay ws uri")?;
    let request = tokio_tungstenite::tungstenite::ClientRequestBuilder::new(relay_uri)
        .with_sub_protocol(SUBPROTOCOL);
    let (relay_ws, _resp) = tokio_tungstenite::client_async_tls_with_config(
        request,
        tcp,
        Some(relay_ws_config()),
        outer,
    )
    .await
    .with_context(|| format!("relay outer WSS to {}", relay.relay_addr))?;

    // Persist a TOFU-observed relay pin so later runs pin this leaf instead of
    // re-trusting (opt-in path only).
    if let Some(v) = &tofu_verifier
        && let (Some(observed), Some(store)) = (v.observed_pin(), &relay.pin_store)
    {
        persist_relay_pin(store, &observed);
    }

    let (mut sink, mut stream) = relay_ws.split();

    if !relay_send(
        &mut sink,
        Message::text(route.open_control(relay.node_id.clone()).to_json()),
    )
    .await
    {
        anyhow::bail!("{}", route.send_context());
    }

    // Wait for the relay to pair us with the daemon (answer pings while waiting).
    let conn_id = loop {
        match stream.next().await {
            Some(Ok(Message::Text(t))) => match Control::from_json(t.as_str()) {
                Ok(Control::Opened { conn_id }) => break conn_id,
                Ok(Control::Error { code, msg }) => {
                    anyhow::bail!("relay refused the route: {code}: {msg}")
                }
                _ => {}
            },
            Some(Ok(Message::Ping(p))) => {
                if !relay_send(&mut sink, Message::Pong(p)).await {
                    anyhow::bail!("the relay stopped accepting writes while opening the route");
                }
            }
            Some(Ok(_)) => {}
            Some(Err(e)) => return Err(anyhow::Error::new(e).context("relay reply")),
            None => anyhow::bail!("relay closed before opening the route"),
        }
    };

    // Bridge the relay's DATA frames <-> an in-memory byte stream the inner mTLS
    // runs over. What the inner TLS writes to `client_io` is read here and shipped
    // as DATA; inbound DATA payloads are written back for the inner TLS to read.
    let (client_io, mut relay_io) = tokio::io::duplex(128 * 1024);
    let pump = tokio::spawn(async move {
        // Counts this pump as live for as long as the task's future exists. Its
        // destructor runs on a normal exit AND when the future is dropped by an
        // abort, which is what lets a test observe that a tunnel was retired
        // rather than merely asked to stop.
        #[cfg(test)]
        let _alive = live_pumps::Token::new();
        // Per-conn credit flow control. `send_window` gates how much we ship to
        // the relay before the daemon acks (so we never pin more than one window
        // of unsent inner bytes); `recv_drained` counts daemon->client bytes we
        // have handed to the inner stream so we can replenish the daemon's window.
        let mut send_window = ConnWindow::new(INITIAL_WINDOW);
        let mut recv_drained: u32 = 0;
        // Grant the daemon our receive window up front.
        if !relay_send(
            &mut sink,
            Message::text(
                Control::Window {
                    conn_id,
                    credit: INITIAL_WINDOW,
                }
                .to_json(),
            ),
        )
        .await
        {
            return;
        }

        let mut buf = vec![0u8; MAX_DATA_PAYLOAD];
        loop {
            tokio::select! {
                // When the send window is exhausted, stop reading the inner stream
                // (back-pressure to the inner TLS) until a DataAck replenishes it.
                n = relay_io.read(&mut buf), if !send_window.is_blocked() => match n {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        // `n <= MAX_DATA_PAYLOAD` (buffer size) so this is already a
                        // single bounded chunk; the relay rejects anything larger.
                        send_window.debit(n);
                        if !relay_send(
                            &mut sink,
                            Message::binary(encode_data(conn_id, &buf[..n])),
                        )
                        .await
                        {
                            break;
                        }
                    }
                },
                msg = stream.next() => match msg {
                    Some(Ok(Message::Binary(b))) => match decode_data(&b) {
                        // This link carries exactly ONE route, chosen above. A
                        // frame naming a different conn is another connection's
                        // ciphertext or a forgery, so the relay is mis-routing or
                        // compromised: tear the tunnel down rather than feed the
                        // inner TLS bytes from an unknown source. Discarding
                        // would keep a broken relay in service silently.
                        Some((frame_conn, _)) if frame_conn != conn_id => break,
                        Some((_, payload)) => {
                            if relay_io.write_all(payload).await.is_err() {
                                break;
                            }
                            recv_drained = recv_drained.saturating_add(payload.len() as u32);
                            // Replenish the daemon's window once we have drained
                            // about half of it, amortizing the ack frames.
                            if recv_drained >= INITIAL_WINDOW / 2 {
                                if !relay_send(
                                    &mut sink,
                                    Message::text(
                                        Control::DataAck {
                                            conn_id,
                                            consumed: recv_drained,
                                        }
                                        .to_json(),
                                    ),
                                )
                                .await
                                {
                                    break;
                                }
                                recv_drained = 0;
                            }
                        }
                        // Too short to carry a conn id: not attributable to any
                        // route, so it is dropped without ending the tunnel.
                        None => {}
                    },
                    Some(Ok(Message::Text(t))) => match Control::from_json(t.as_str()) {
                        // Credit and close control for another conn is the same
                        // routing fault as a mis-addressed DATA frame: acting on
                        // it would let one route's peer resize or close this one.
                        Ok(Control::Close { conn_id: c, .. })
                        | Ok(Control::Window { conn_id: c, .. })
                        | Ok(Control::DataAck { conn_id: c, .. })
                            if c != conn_id =>
                        {
                            break;
                        }
                        Ok(Control::Close { .. }) => break,
                        Ok(Control::Window { credit, .. }) => send_window.set(credit),
                        Ok(Control::DataAck { consumed, .. }) => send_window.ack(consumed),
                        _ => {}
                    },
                    Some(Ok(Message::Ping(p))) => {
                        if !relay_send(&mut sink, Message::Pong(p)).await {
                            break;
                        }
                    }
                    Some(Ok(_)) => {}
                    Some(Err(_)) | None => break,
                }
            }
        }
        let _ = relay_io.shutdown().await;
        // The closing handshake is a write to the same peer that may already
        // have stopped reading, so it gets the same budget as a DATA frame. An
        // unbounded close is how a pump that has finished its work still fails
        // to finish its task.
        let _ =
            tokio::time::timeout(RELAY_WRITE_STALL, futures_util::SinkExt::close(&mut sink)).await;
        #[cfg(test)]
        live_pumps::mark_completed();
    });

    Ok(RelayTunnel {
        io: client_io,
        pump,
    })
}

/// Tracks how many relay pumps are alive, so a test can prove a tunnel was
/// retired rather than merely abandoned.
#[cfg(test)]
pub(crate) mod live_pumps {
    use std::sync::atomic::{AtomicUsize, Ordering};

    static LIVE: AtomicUsize = AtomicUsize::new(0);

    pub(crate) struct Token;

    impl Token {
        pub(crate) fn new() -> Self {
            LIVE.fetch_add(1, Ordering::SeqCst);
            Self
        }
    }

    impl Drop for Token {
        fn drop(&mut self) {
            LIVE.fetch_sub(1, Ordering::SeqCst);
        }
    }

    /// Relay pumps whose task future still exists.
    pub(crate) fn count() -> usize {
        LIVE.load(Ordering::SeqCst)
    }

    static COMPLETED: AtomicUsize = AtomicUsize::new(0);

    /// Recorded at the end of the pump body, which an abort never reaches.
    pub(crate) fn mark_completed() {
        COMPLETED.fetch_add(1, Ordering::SeqCst);
    }

    /// Pumps that ran to the end of their body.
    ///
    /// This is what separates a pump that was RETIRED from one that merely
    /// noticed its stream had gone: dropping the local stream unparks a pump
    /// sitting in its read arm, so "the task ended" alone proves nothing about
    /// the guard. A pump parked in a relay write or its closing handshake has no
    /// such escape, and only an abort ends it - leaving this count unchanged.
    pub(crate) fn completed() -> usize {
        COMPLETED.load(Ordering::SeqCst)
    }

    static SERIAL: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

    /// Held by every test that creates or counts a relay pump, so the shared
    /// count is never perturbed by a tunnel another test opened in parallel.
    ///
    /// An async lock because the tests hold it across awaits, which is exactly
    /// what a blocking guard must not be held across.
    pub(crate) async fn exclusive() -> tokio::sync::MutexGuard<'static, ()> {
        SERIAL.lock().await
    }
}

/// Open the daemon's narrow enrollment endpoint through the nominated relay.
///
/// The returned tunnel's stream is still plaintext only to the caller; the
/// caller must run the enrollment TLS client over it before sending pairing
/// material.
///
/// The pump is returned under a guard rather than detached. An enrollment
/// exchange has no session to hand the pump to, and it can end in more ways than
/// it can succeed: the response times out, the endpoint refuses the pairing
/// code, the TLS handshake fails, or the whole future is dropped when its budget
/// expires. Only some of those run code the caller wrote, so the cleanup belongs
/// to a value that every one of them drops.
pub async fn dial_enrollment_through_relay(relay: &RelayDial) -> Result<EnrollmentTunnel> {
    let deadline = tokio::time::Instant::now() + RELAY_SETUP_DEADLINE;
    let tunnel = dial_through_relay(relay, RelayRoute::Enrollment, deadline).await?;
    Ok(EnrollmentTunnel {
        io: tunnel.io,
        pump: RelayPumpGuard(Some(tunnel.pump)),
    })
}

impl RpcClient {
    /// Connect to the daemon's local IPC endpoint and complete the
    /// `initialize` handshake.
    ///
    /// Pass previous `tui_id` and `tui_sig` on reconnect to reclaim
    /// the same identity. Pass `None` for both on first connect.
    pub async fn connect(
        socket: &Path,
        prev_tui_id: Option<&str>,
        prev_tui_sig: Option<&str>,
    ) -> Result<Self> {
        let stream = open_local_stream(socket)
            .await
            .with_context(|| format!("connecting to {}", socket.display()))?;
        let (read_half, write_half) = tokio::io::split(stream);

        let (writer_tx, mut writer_rx) = mpsc::channel::<jsonrpc::OutboundMessage>(64);
        let rpc = Arc::new(RpcOutbound::new_transport(writer_tx));
        let (notif_tx, _) = broadcast::channel::<RpcNotification>(NOTIFICATION_CHANNEL_CAPACITY);
        let notif_tx_for_reader = notif_tx.clone();
        let (inbound_tx, inbound_rx) = mpsc::unbounded_channel::<RpcInboundRequest>();
        let mut inbound_tx_for_reader = Some(inbound_tx);
        let inbound_responses = Arc::new(InboundResponseTracker::default());
        let inbound_responses_for_reader = Arc::clone(&inbound_responses);

        let conn_state = Arc::new(Mutex::new(ConnectionState::Connected));
        let conn_state_for_reader = conn_state.clone();
        let rpc_for_writer = Arc::downgrade(&rpc);
        let conn_state_for_writer = conn_state.clone();
        let writer_task = tokio::spawn(async move {
            let mut writer = write_half;
            while let Some(message) = writer_rx.recv().await {
                match message {
                    jsonrpc::OutboundMessage::Frame(mut line) => {
                        if !line.ends_with('\n') {
                            line.push('\n');
                        }
                        if let Err(error) = writer.write_all(line.as_bytes()).await {
                            if let Some(rpc) = rpc_for_writer.upgrade() {
                                disconnect_rpc(&rpc, &conn_state_for_writer, error.to_string());
                            }
                            break;
                        }
                    }
                    jsonrpc::OutboundMessage::Flush(ack) => {
                        let _ = ack.send(());
                    }
                }
            }
        });

        let rpc_for_reader = rpc.clone();
        let (reader_control_tx, mut reader_control_rx) = mpsc::unbounded_channel::<ReaderControl>();
        let read_task = tokio::spawn(async move {
            let mut lines = BufReader::new(read_half).lines();
            loop {
                let line = tokio::select! {
                    biased;
                    control = reader_control_rx.recv() => {
                        let Some(ReaderControl::Quiesce(ack)) = control else {
                            break;
                        };
                        inbound_tx_for_reader.take();
                        let _ = ack.send(());
                        continue;
                    }
                    line = lines.next_line() => line,
                };
                let line = match line {
                    Ok(None) => {
                        disconnect_rpc(
                            &rpc_for_reader,
                            &conn_state_for_reader,
                            "EOF (daemon closed connection)".to_string(),
                        );
                        break;
                    }
                    Err(e) => {
                        disconnect_rpc(&rpc_for_reader, &conn_state_for_reader, e.to_string());
                        break;
                    }
                    Ok(Some(line)) => line,
                };
                let frame: Value = match serde_json::from_str(line.trim()) {
                    Ok(v) => v,
                    Err(_) => continue,
                };
                if let Some(request) = route_inbound_frame(
                    &rpc_for_reader,
                    &notif_tx_for_reader,
                    inbound_tx_for_reader.as_ref(),
                    frame,
                ) {
                    respond_to_retired_inbound_request(
                        &rpc_for_reader,
                        &inbound_responses_for_reader,
                        request,
                    );
                }
            }
        });

        let mut init_params = serde_json::json!({
            "protocol_version": jsonrpc::ACP_PROTOCOL_VERSION,
            // Advertise the ACP `elicitation` capability (form mode) so the
            // daemon's per-session `RpcApprovalChannel` routes `request_choice`
            // / `request_multi_choice` over `elicitation/create` instead of
            // silently returning `Ok(None)`. The Code tab handles inbound
            // `elicitation/create` requests via `route_inbound_frame` →
            // the chat widget's pending-elicitation modal.
            "clientCapabilities": {
                "elicitation": { "form": {} }
            }
        });
        if let Some(id) = prev_tui_id {
            init_params["tui_id"] = serde_json::Value::String(id.to_string());
        }
        if let Some(sig) = prev_tui_sig {
            init_params["tui_sig"] = serde_json::Value::String(sig.to_string());
        }
        // Forward the TUI's full shell environment to the daemon so that
        // subprocesses spawned by agents inherit the user's real env
        // (PATH, SSH_AUTH_SOCK, credential helpers, etc.).  This is safe
        // on a local Unix-socket connection because the daemon is on the
        // same machine and the socket paths / env values are meaningful.
        let env_map: std::collections::HashMap<String, String> = std::env::vars().collect();
        init_params["env"] = serde_json::to_value(env_map).unwrap_or_default();
        let resp = match request_initialize(&rpc, init_params, INITIALIZE_TIMEOUT).await {
            Ok(resp) => resp,
            Err(e) => {
                read_task.abort();
                writer_task.abort();
                return Err(e);
            }
        };

        let init = match parse_initialize_response(&resp) {
            Ok(init) => init,
            Err(e) => {
                read_task.abort();
                writer_task.abort();
                return Err(e);
            }
        };
        let bcast_rx = notif_tx.subscribe();
        let (update_tx, _update_rx) = mpsc::channel::<SessionUpdate>(64);
        let router_task = spawn_notification_router(bcast_rx, update_tx);

        Ok(Self {
            rpc,
            read_task,
            reader_control: Some(reader_control_tx),
            router_task,
            writer_task: Some(writer_task),
            relay_pump: None,
            server_version: init.server_version,
            server_pid: init.server_pid,
            notifications_bcast: notif_tx,
            inbound_requests_rx: Mutex::new(Some(inbound_rx)),
            inbound_responses,
            connection_state: conn_state,
            tui_id: init.tui_id,
            tui_sig: init.tui_sig,
            transport: Transport::Local,
            commands: init.commands,
        })
    }

    /// Connect to the daemon via WebSocket Secure (WSS).
    ///
    /// Same handshake and reconnect semantics as [`Self::connect`] — pass
    /// previous `tui_id`/`tui_sig` to reclaim identity on reconnect.
    ///
    /// `tls` controls TLS verification and mutual-TLS client identity. When the
    /// daemon's remote WSS plane requires mutual TLS, set `ca_cert_path` (the
    /// daemon CA to trust) and `client_cert_path` / `client_key_path` (the client
    /// certificate to present). `skip_verify` disables server verification
    /// (self-signed dev only).
    ///
    /// `auth_token` (with an optional `auth_provider` selection, default
    /// `native`) is presented in the initialize handshake; remote daemons
    /// require it since the RFC 7141 enforcement boundary. The mTLS cert is
    /// transport/device admission; the token is principal authentication.
    pub async fn connect_wss_direct(
        url: &str,
        prev_tui_id: Option<&str>,
        prev_tui_sig: Option<&str>,
        tls: &ClientTls,
        auth_token: Option<&str>,
        auth_provider: Option<&str>,
    ) -> Result<Self> {
        // The built-in (webpki-roots) connector only for the plain default (no
        // client cert, no custom CA, no skip-verify); any custom TLS material
        // requires our own rustls ClientConfig.
        let connector = if tls.is_default() {
            None
        } else {
            Some(tokio_tungstenite::Connector::Rustls(Self::wss_tls_config(
                tls,
            )?))
        };
        let (ws_stream, _response) = tokio_tungstenite::connect_async_tls_with_config(
            url,
            Some(rpc_ws_config()),
            false,
            connector,
        )
        .await
        .with_context(|| format!("WSS connect to {url}"))?;
        // No relay pump on the direct path: the socket IS the transport.
        Self::spawn_ws_session(
            ws_stream,
            prev_tui_id,
            prev_tui_sig,
            auth_token,
            auth_provider,
            None,
        )
        .await
    }

    /// Connect to the daemon through a nominated relay.
    ///
    /// Establishes the OUTER TLS + WS to the relay, requests the target node-id,
    /// then runs the SAME inner WSS + mTLS (against `inner_url`) over the tunnelled
    /// byte stream. The relay only ever forwards ciphertext DATA frames and never
    /// sees plaintext. `inner_url`'s server name is the daemon's loopback SAN.
    pub async fn connect_wss_via_relay(
        inner_url: &str,
        prev_tui_id: Option<&str>,
        prev_tui_sig: Option<&str>,
        tls: &ClientTls,
        relay: &RelayDial,
        auth_token: Option<&str>,
        auth_provider: Option<&str>,
    ) -> Result<Self> {
        // ONE deadline for the whole client-side setup. It is created here, before
        // the first packet, and every step below shares what is left of it: the
        // tunnel dial AND the inner handshake that runs over the finished tunnel.
        let deadline = tokio::time::Instant::now() + RELAY_SETUP_DEADLINE;
        let RelayTunnel { io, pump } = dial_through_relay(relay, RelayRoute::Wss, deadline).await?;
        // A tunnel that outlives a failed handshake keeps a relay route open that
        // nothing will ever read. The guard makes that structural: every exit
        // from here retires the pump unless it is explicitly released to a
        // session that will keep it running.
        let pump = RelayPumpGuard(Some(pump));
        let connector = tokio_tungstenite::Connector::Rustls(Self::wss_tls_config(tls)?);

        let handshake = within_relay_setup(
            deadline,
            "the inner WSS handshake through the relay",
            async {
                tokio_tungstenite::client_async_tls_with_config(
                    inner_url,
                    io,
                    Some(rpc_ws_config()),
                    Some(connector),
                )
                .await
                .with_context(|| format!("WSS-over-relay to {inner_url} via {}", relay.relay_addr))
            },
        )
        .await;
        // `?` here would drop the guard and retire the pump, which is exactly
        // what a failed handshake wants.
        let (ws_stream, _response) = handshake?;
        Self::spawn_ws_session(
            ws_stream,
            prev_tui_id,
            prev_tui_sig,
            auth_token,
            auth_provider,
            pump.release(),
        )
        .await
    }

    /// Drive a connected WSS stream: spawn the writer/reader tasks and complete
    /// the `initialize` handshake. Generic over the underlying transport so it
    /// serves both the direct (`TcpStream`) and relayed (`DuplexStream`) paths.
    /// `relay_pump`, when present, is the tunnel pump this session runs over. The
    /// session owns it from here: every error path below aborts it, and a
    /// successful session hands it to the returned client so
    /// [`RpcClient::shutdown`] can reclaim the relay route.
    async fn spawn_ws_session<S>(
        ws_stream: tokio_tungstenite::WebSocketStream<tokio_tungstenite::MaybeTlsStream<S>>,
        prev_tui_id: Option<&str>,
        prev_tui_sig: Option<&str>,
        auth_token: Option<&str>,
        auth_provider: Option<&str>,
        relay_pump: Option<tokio::task::JoinHandle<()>>,
    ) -> Result<Self>
    where
        S: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send + 'static,
    {
        use futures_util::{SinkExt, StreamExt};
        use tokio_tungstenite::tungstenite::Message;

        let (mut sink, mut stream) = ws_stream.split();

        let (writer_tx, mut writer_rx) = mpsc::channel::<jsonrpc::OutboundMessage>(64);
        let rpc = Arc::new(jsonrpc::RpcOutbound::new_transport(writer_tx));
        let (notif_tx, _) = broadcast::channel::<RpcNotification>(NOTIFICATION_CHANNEL_CAPACITY);
        let notif_tx_for_reader = notif_tx.clone();
        let (inbound_tx, inbound_rx) = mpsc::unbounded_channel::<RpcInboundRequest>();
        let mut inbound_tx_for_reader = Some(inbound_tx.clone());
        let inbound_responses = Arc::new(InboundResponseTracker::default());
        let inbound_responses_for_reader = Arc::clone(&inbound_responses);

        let conn_state = Arc::new(Mutex::new(ConnectionState::Connected));
        let conn_state_for_reader = conn_state.clone();
        let rpc_for_writer = Arc::downgrade(&rpc);
        let conn_state_for_writer = conn_state.clone();
        let flush_ack = Arc::new(WssFlushAck::default());
        let flush_ack_for_writer = Arc::clone(&flush_ack);
        let writer_task = tokio::spawn(async move {
            let mut next_flush_id = 0_u64;
            while let Some(message) = writer_rx.recv().await {
                match message {
                    jsonrpc::OutboundMessage::Frame(line) => {
                        if let Err(error) = sink.send(Message::Text(line.into())).await {
                            if let Some(rpc) = rpc_for_writer.upgrade() {
                                disconnect_rpc(&rpc, &conn_state_for_writer, error.to_string());
                            }
                            break;
                        }
                    }
                    jsonrpc::OutboundMessage::Flush(ack) => {
                        // A successful write to a relayed WSS sink only proves
                        // that bytes reached the inner duplex stream. The relay
                        // pump can still be aborted before it forwards them to
                        // the daemon. A matching ping/pong round trip crosses
                        // that outer boundary and orders every earlier frame
                        // ahead of the acknowledgement.
                        let mut payload = b"zerocode-flush:".to_vec();
                        payload.extend_from_slice(&next_flush_id.to_be_bytes());
                        next_flush_id = next_flush_id.wrapping_add(1);
                        let Some(pong_ack) = flush_ack_for_writer.register(payload.clone()) else {
                            break;
                        };
                        if let Err(error) = sink.send(Message::Ping(payload.clone().into())).await {
                            if let Some(rpc) = rpc_for_writer.upgrade() {
                                disconnect_rpc(&rpc, &conn_state_for_writer, error.to_string());
                            }
                            break;
                        }
                        if pong_ack.await.is_err() {
                            break;
                        }
                        let _ = ack.send(());
                    }
                }
            }
        });

        let rpc_for_reader = rpc.clone();
        let (reader_control_tx, mut reader_control_rx) = mpsc::unbounded_channel::<ReaderControl>();
        let read_task = tokio::spawn(async move {
            loop {
                let message = tokio::select! {
                    biased;
                    control = reader_control_rx.recv() => {
                        let Some(ReaderControl::Quiesce(ack)) = control else {
                            break;
                        };
                        inbound_tx_for_reader.take();
                        let _ = ack.send(());
                        continue;
                    }
                    message = stream.next() => message,
                };
                if !handle_wss_reader_message(
                    message,
                    &rpc_for_reader,
                    &notif_tx_for_reader,
                    inbound_tx_for_reader.as_ref(),
                    &inbound_responses_for_reader,
                    &conn_state_for_reader,
                    &flush_ack,
                ) {
                    break;
                }
            }
        });

        // Initialize handshake — identical to Unix socket path.
        let mut init_params = serde_json::json!({
            "protocol_version": jsonrpc::ACP_PROTOCOL_VERSION,
            // Advertise ACP elicitation form-mode support. See
            // `connect` above for the rationale.
            "clientCapabilities": {
                "elicitation": { "form": {} }
            }
        });
        if let Some(id) = prev_tui_id {
            init_params["tui_id"] = serde_json::Value::String(id.to_string());
        }
        if let Some(sig) = prev_tui_sig {
            init_params["tui_sig"] = serde_json::Value::String(sig.to_string());
        }
        if let Some(token) = auth_token {
            init_params["auth_token"] = serde_json::Value::String(token.to_string());
        }
        if let Some(provider) = auth_provider {
            init_params["auth_provider"] = serde_json::Value::String(provider.to_string());
        }
        // NOTE: We intentionally do NOT forward the TUI's environment here.
        // In a WSS connection the daemon is on a remote machine, so env values
        // like SSH_AUTH_SOCK, VIRTUAL_ENV, or any path-based socket/credential
        // would refer to paths that don't exist on the remote host.  Forwarding
        // them would be misleading at best and silently broken at worst.
        // Env pass-through is only meaningful on a local Unix-socket connection
        // (see `connect` above), where the TUI and daemon share the same filesystem.
        // A failed initialize must not leave the transport running: the reader,
        // the writer, and (on the relayed path) the tunnel pump all belong to a
        // session that will never exist.
        let abandon = |pump: &Option<tokio::task::JoinHandle<()>>| {
            read_task.abort();
            writer_task.abort();
            if let Some(pump) = pump {
                pump.abort();
            }
        };
        let resp = match request_initialize(&rpc, init_params, INITIALIZE_TIMEOUT).await {
            Ok(resp) => resp,
            Err(e) => {
                abandon(&relay_pump);
                return Err(e);
            }
        };

        let init = match parse_initialize_response(&resp) {
            Ok(init) => init,
            Err(e) => {
                abandon(&relay_pump);
                return Err(e);
            }
        };
        let bcast_rx = notif_tx.subscribe();
        let (update_tx, _update_rx) = mpsc::channel::<SessionUpdate>(64);
        let router_task = spawn_notification_router(bcast_rx, update_tx);

        Ok(Self {
            rpc,
            read_task,
            reader_control: Some(reader_control_tx),
            router_task,
            writer_task: Some(writer_task),
            relay_pump,
            server_version: init.server_version,
            server_pid: init.server_pid,
            notifications_bcast: notif_tx,
            inbound_requests_rx: Mutex::new(Some(inbound_rx)),
            inbound_responses,
            connection_state: conn_state,
            tui_id: init.tui_id,
            tui_sig: init.tui_sig,
            transport: Transport::Wss,
            commands: init.commands,
        })
    }

    /// Build a rustls `ClientConfig` from a [`ClientTls`]: server verification via
    /// the configured CA (or `NoVerify` when `skip_verify`), presenting the client
    /// certificate for mutual TLS when one is configured.
    ///
    /// Crate-visible because the gateway enrollment leg that precedes the WSS
    /// connection must be given exactly the same trust material.
    pub(crate) fn wss_tls_config(tls: &ClientTls) -> Result<std::sync::Arc<rustls::ClientConfig>> {
        use std::sync::Arc;

        let builder = rustls::ClientConfig::builder_with_provider(Arc::new(
            rustls::crypto::ring::default_provider(),
        ))
        .with_safe_default_protocol_versions()
        .expect("ring provider supports the default protocol versions");

        // Server verification.
        let verified = if tls.skip_verify {
            builder
                .dangerous()
                .with_custom_certificate_verifier(Arc::new(NoVerify))
        } else if let Some(ca_path) = &tls.ca_cert_path {
            let daemon_ca = load_single_daemon_ca_cert(ca_path)?;
            let mut roots = rustls::RootCertStore::empty();
            roots
                .add(daemon_ca)
                .context("adding daemon CA to the client root store")?;
            builder.with_root_certificates(roots)
        } else {
            let mut roots = rustls::RootCertStore::empty();
            roots.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
            builder.with_root_certificates(roots)
        };

        // Mutual-TLS client identity.
        let config = match (&tls.client_cert_path, &tls.client_key_path) {
            (Some(cert_path), Some(key_path)) => {
                let chain = load_pem_certs(cert_path)?;
                let key = load_pem_key(key_path)?;
                verified
                    .with_client_auth_cert(chain, key)
                    .context("loading client certificate / key for mutual TLS")?
            }
            (Some(_), None) | (None, Some(_)) => {
                anyhow::bail!(
                    "WSS mutual TLS requires both tls.client_cert_path and tls.client_key_path"
                );
            }
            (None, None) => verified.with_no_client_auth(),
        };

        Ok(Arc::new(config))
    }

    pub async fn call<T: DeserializeOwned>(&self, method: &str, params: Value) -> Result<T> {
        self.call_with_timeout(method, params, std::time::Duration::from_secs(5))
            .await
    }

    pub async fn call_with_timeout<T: DeserializeOwned>(
        &self,
        method: &str,
        params: Value,
        timeout: std::time::Duration,
    ) -> Result<T> {
        // Timeout prevents indefinite hangs when the daemon dies between
        // the connection-state check and the actual RPC send/recv.
        let result = tokio::time::timeout(timeout, self.rpc.request(method, params))
            .await
            .map_err(|_| {
                anyhow::Error::new(DaemonRpcTimeout {
                    method: method.to_string(),
                    timeout,
                })
            })?
            .map_err(|e| {
                let message = format!("RPC {method}: {} ({})", e.message, e.code);
                anyhow::Error::new(e).context(message)
            })?;
        serde_json::from_value(result).with_context(|| format!("deserializing {method} result"))
    }

    // ── Connection state ─────────────────────────────────────────

    /// Current connection state. Cheap mutex read, safe to call on every frame.
    pub fn connection_state(&self) -> ConnectionState {
        clone_connection_state(&self.connection_state)
    }

    pub async fn flush_outbound(&self) -> bool {
        self.flush_outbound_with_timeout(OUTBOUND_FLUSH_TIMEOUT)
            .await
    }

    /// Keep a replaced transport alive long enough to drain terminal replies
    /// that missed the fast handoff deadline, then reclaim all of its tasks.
    pub fn retire_after_outbound_flush(self: Arc<Self>) {
        self.retire_after_outbound_flush_with_timeout(OUTBOUND_RETIRE_TIMEOUT);
    }

    fn retire_after_outbound_flush_with_timeout(self: Arc<Self>, timeout: Duration) {
        tokio::spawn(async move {
            let _ = self.flush_outbound_with_timeout(timeout).await;
            self.shutdown();
        });
    }

    async fn flush_outbound_with_timeout(&self, timeout: Duration) -> bool {
        tokio::time::timeout(timeout, async {
            self.inbound_responses.wait_until_idle().await;
            self.rpc.flush_outbound().await
        })
        .await
        .is_ok_and(|flushed| flushed)
    }

    #[cfg(test)]
    #[allow(dead_code)]
    pub(crate) fn disconnect_for_test(&self, reason: &str) {
        disconnect_rpc(&self.rpc, &self.connection_state, reason.to_string());
    }

    // ── Notifications ─────────────────────────────────────────────

    /// Get a receiver for server-initiated notifications.
    pub fn subscribe_notifications(&self) -> broadcast::Receiver<RpcNotification> {
        self.notifications_bcast.subscribe()
    }

    /// Claim the sole receiver for server-initiated JSON-RPC requests that
    /// expect a response (today: `elicitation/create`). The app resolves
    /// `params.sessionId` to the owning pane and answers via
    /// [`Self::respond_to_inbound_request`].
    pub fn take_inbound_requests(&self) -> Result<mpsc::UnboundedReceiver<RpcInboundRequest>> {
        self.inbound_requests_rx
            .lock()
            .map_err(|_| anyhow::Error::msg("inbound request receiver mutex poisoned"))?
            .take()
            .context("inbound request receiver already claimed")
    }

    /// Schedule a JSON-RPC response to a previously received server request.
    /// The registration happens before the task is spawned, so reconnect
    /// retirement cannot flush and stop this writer ahead of an unpolled task.
    pub fn respond_to_inbound_request(
        &self,
        id: Value,
        result: std::result::Result<Value, JsonRpcError>,
    ) {
        self.respond_to_inbound_requests(vec![(id, result)]);
    }

    /// Register one retirement-owned batch before spawning its serial enqueue
    /// loop. A large drained inbound backlog therefore parks at most one task
    /// on writer capacity while remaining visible to the flush barrier.
    pub(crate) fn respond_to_inbound_requests(
        &self,
        responses: Vec<(Value, std::result::Result<Value, JsonRpcError>)>,
    ) {
        enqueue_inbound_responses(
            Arc::clone(&self.rpc),
            Arc::clone(&self.inbound_responses),
            responses,
        );
    }

    /// Stop accepting server-initiated requests without retiring the writer.
    /// Router replacement uses this before its final receiver drain so every
    /// request accepted by the old reader remains answerable on the old
    /// transport. Full [`Self::shutdown`] follows after those responses have
    /// been queued.
    pub async fn quiesce_inbound_reader(&self) {
        if let Some(control) = &self.reader_control {
            let (ack_tx, ack_rx) = oneshot::channel();
            if control.send(ReaderControl::Quiesce(ack_tx)).is_ok() {
                let _ = ack_rx.await;
            }
        } else {
            self.read_task.abort();
            while !self.read_task.is_finished() {
                tokio::task::yield_now().await;
            }
        }
    }

    /// Ask the daemon to start streaming log events as notifications.
    pub async fn logs_subscribe(&self) -> Result<()> {
        let _: Value = self.call("logs/subscribe", serde_json::json!({})).await?;
        Ok(())
    }

    /// Query persisted log events from the daemon.
    pub async fn logs_query(&self, params: LogsQueryParams) -> Result<LogsQueryResult> {
        self.call("logs/query", serde_json::to_value(params)?).await
    }

    /// `logs/get { id }` — fetch one event's full payload. The Logs
    /// pane keeps only preview data in memory and lazy-fetches the
    /// full event when the detail pane opens; on close the detail is
    /// dropped back to `None`.
    pub async fn logs_get(&self, id: &str) -> Result<LogsGetResult> {
        self.call("logs/get", serde_json::json!({ "id": id })).await
    }

    // ── Typed config helpers ─────────────────────────────────────

    pub async fn config_list(&self, prefix: Option<&str>) -> Result<Vec<ConfigFieldEntry>> {
        let result: ConfigListResult = self
            .call(method::CONFIG_LIST, serde_json::json!({ "prefix": prefix }))
            .await?;
        Ok(result.entries)
    }

    pub async fn config_set(
        &self,
        prop: &str,
        value: Value,
    ) -> Result<Option<crate::wire::PublishedConfigRevision>> {
        let result: ConfigSetResult = self
            .call(
                method::CONFIG_SET,
                serde_json::json!({ "prop": prop, "value": value }),
            )
            .await?;
        Ok(result.revision)
    }

    pub async fn config_delete(
        &self,
        prop: &str,
    ) -> Result<Option<crate::wire::PublishedConfigRevision>> {
        let result: ConfigDeleteResult = self
            .call(method::CONFIG_DELETE, serde_json::json!({ "prop": prop }))
            .await?;
        Ok(result.revision)
    }

    pub async fn config_status(&self) -> Result<crate::wire::ConfigStatusResult> {
        self.call_with_timeout(
            method::CONFIG_STATUS,
            serde_json::json!({}),
            std::time::Duration::from_secs(3),
        )
        .await
    }

    /// Signal the daemon to reload in place. Mirrors `POST /admin/reload`.
    pub async fn config_reload(&self) -> Result<ConfigReloadResult> {
        self.call(method::CONFIG_RELOAD, serde_json::json!({}))
            .await
    }

    /// List the build's available locales (embedded `locales.toml` registry).
    pub async fn locales_list(&self) -> Result<Vec<LocaleOption>> {
        let r: LocalesListResult = self
            .call(method::LOCALES_LIST, serde_json::json!({}))
            .await?;
        Ok(r.locales)
    }

    /// Fetch translated FTL catalogue bytes for `locale` from upstream. The
    /// daemon validates the locale/catalog and returns file contents; the
    /// caller writes them locally.
    pub async fn locales_fetch(
        &self,
        locale: &str,
        catalog: &[String],
    ) -> Result<LocalesFetchResult> {
        self.call(
            method::LOCALES_FETCH,
            serde_json::json!({ "locale": locale, "catalog": catalog }),
        )
        .await
    }

    pub async fn config_sections(&self) -> Result<Vec<ConfigSectionEntry>> {
        let result: ConfigSectionsResult = self
            .call(method::CONFIG_SECTIONS, serde_json::json!({}))
            .await?;
        Ok(result.sections)
    }

    pub async fn config_map_keys(&self, path: &str) -> Result<Vec<String>> {
        let result: ConfigMapKeysResult = self
            .call(method::CONFIG_MAP_KEYS, serde_json::json!({ "path": path }))
            .await?;
        Ok(result.keys)
    }

    pub async fn config_resolve_alias_source(
        &self,
        source: crate::wire::AliasSource,
    ) -> Result<Vec<String>> {
        let result: ConfigResolveAliasSourceResult = self
            .call(
                method::CONFIG_RESOLVE_ALIAS_SOURCE,
                serde_json::json!({ "source": source }),
            )
            .await?;
        Ok(result.values)
    }

    pub async fn config_map_key_create(
        &self,
        path: &str,
        key: &str,
    ) -> Result<ConfigMapKeyMutationResult> {
        let result: ConfigMapKeyMutationResult = self
            .call(
                method::CONFIG_MAP_KEY_CREATE,
                serde_json::json!({ "path": path, "key": key }),
            )
            .await?;
        Ok(result)
    }

    pub async fn config_map_key_delete(
        &self,
        path: &str,
        key: &str,
    ) -> Result<ConfigMapKeyMutationResult> {
        let result: ConfigMapKeyMutationResult = self
            .call(
                method::CONFIG_MAP_KEY_DELETE,
                serde_json::json!({ "path": path, "key": key }),
            )
            .await?;
        Ok(result)
    }

    pub async fn config_map_key_rename(
        &self,
        path: &str,
        from: &str,
        to: &str,
    ) -> Result<ConfigRenameMapKeyResult> {
        self.call_with_timeout(
            method::CONFIG_RENAME_MAP_KEY,
            serde_json::json!({ "path": path, "from": from, "to": to }),
            CONFIG_RENAME_TIMEOUT,
        )
        .await
    }

    pub async fn config_templates(&self) -> Result<Vec<ConfigTemplateEntry>> {
        let result: ConfigTemplatesResult = self
            .call(method::CONFIG_TEMPLATES, serde_json::json!({}))
            .await?;
        Ok(result.templates)
    }

    pub async fn catalog_models(&self, provider: &str) -> Result<CatalogModelsResult> {
        self.call_with_timeout(
            method::CONFIG_CATALOG_MODELS,
            serde_json::json!({ "model_provider": provider }),
            std::time::Duration::from_secs(20),
        )
        .await
    }

    // ── Personality helpers ──────────────────────────────────────

    pub async fn personality_list(&self, agent: Option<&str>) -> Result<PersonalityListResult> {
        self.call(
            method::PERSONALITY_LIST,
            serde_json::json!({ "agent": agent }),
        )
        .await
    }

    pub async fn personality_get(
        &self,
        agent: &str,
        filename: &str,
    ) -> Result<PersonalityGetResult> {
        self.call(
            method::PERSONALITY_GET,
            serde_json::json!({ "agent": agent, "filename": filename }),
        )
        .await
    }

    pub async fn personality_put(
        &self,
        agent: &str,
        filename: &str,
        content: &str,
    ) -> Result<PersonalityPutResult> {
        self.call(
            method::PERSONALITY_PUT,
            serde_json::json!({ "agent": agent, "filename": filename, "content": content }),
        )
        .await
    }

    pub async fn personality_templates(
        &self,
        agent: Option<&str>,
    ) -> Result<PersonalityTemplatesResult> {
        self.call(
            method::PERSONALITY_TEMPLATES,
            serde_json::json!({ "agent": agent }),
        )
        .await
    }

    // ── Skills helpers ───────────────────────────────────────────

    pub async fn skills_list(&self, bundle: Option<&str>) -> Result<SkillsListResult> {
        self.call(method::SKILLS_LIST, serde_json::json!({ "bundle": bundle }))
            .await
    }

    pub async fn skills_read(&self, bundle: &str, name: &str) -> Result<SkillsReadResult> {
        self.call(
            method::SKILLS_READ,
            serde_json::json!({ "bundle": bundle, "name": name }),
        )
        .await
    }

    pub async fn skills_write(
        &self,
        bundle: &str,
        name: &str,
        frontmatter: &SkillFrontmatter,
        body: &str,
    ) -> Result<SkillsWriteResult> {
        self.call(
            method::SKILLS_WRITE,
            serde_json::json!({
                "bundle": bundle,
                "name": name,
                "frontmatter": frontmatter,
                "body": body,
            }),
        )
        .await
    }

    pub async fn skills_delete(&self, bundle: &str, name: &str) -> Result<SkillsDeleteResult> {
        self.call(
            method::SKILLS_DELETE,
            serde_json::json!({ "bundle": bundle, "name": name }),
        )
        .await
    }

    // ── Quickstart methods ───────────────────────────────────────
    //
    // Thin RPC mirror of the gateway's `/api/quickstart/*` HTTP routes.
    // Same shapes both ways; the daemon-side handlers live in
    // `zeroclaw_runtime::rpc::dispatch` and call into
    // `zeroclaw_runtime::quickstart::{validate_only,apply}_with_surface`.

    pub async fn quickstart_state(&self) -> Result<QuickstartStateResult> {
        self.call(method::QUICKSTART_STATE, serde_json::json!({}))
            .await
    }

    pub async fn quickstart_fields(
        &self,
        section: QuickstartFieldSection,
        type_key: &str,
    ) -> Result<QuickstartFieldsResult> {
        self.call(
            method::QUICKSTART_FIELDS,
            serde_json::json!({ "section": section, "type_key": type_key }),
        )
        .await
    }

    pub async fn quickstart_validate(
        &self,
        submission: &crate::wire::BuilderSubmission,
    ) -> Result<QuickstartValidateResult> {
        self.call(
            method::QUICKSTART_VALIDATE,
            serde_json::json!({ "submission": submission }),
        )
        .await
    }

    pub async fn quickstart_apply(
        &self,
        submission: &crate::wire::BuilderSubmission,
    ) -> Result<QuickstartApplyResult> {
        // Apply persists config to disk, may enrich the provider entry over
        // the network, and can queue behind an in-flight catalog fetch on
        // the daemon's dispatcher, so it gets the same budget as
        // `catalog_models` rather than the default call timeout.
        self.call_with_timeout(
            method::QUICKSTART_APPLY,
            serde_json::json!({ "submission": submission }),
            std::time::Duration::from_secs(20),
        )
        .await
    }

    pub async fn quickstart_dismiss(
        &self,
        run_id: &str,
        surface: QuickstartSurface,
        last_step: Option<QuickstartStep>,
    ) -> Result<QuickstartDismissResult> {
        self.call(
            method::QUICKSTART_DISMISS,
            serde_json::json!({
                "run_id": run_id,
                "surface": surface,
                "last_step": last_step,
            }),
        )
        .await
    }

    pub async fn sops_list(&self) -> Result<Value> {
        self.call(method::SOPS_LIST, serde_json::json!({})).await
    }

    pub async fn sops_get(&self, name: &str) -> Result<Value> {
        self.call(method::SOPS_GET, serde_json::json!({ "name": name }))
            .await
    }

    pub async fn sops_graph(&self, name: &str) -> Result<Value> {
        self.call(method::SOPS_GRAPH, serde_json::json!({ "name": name }))
            .await
    }

    pub async fn sops_graph_view(&self, name: &str) -> Result<SopGraphView> {
        let value = self.sops_graph(name).await?;
        serde_json::from_value(value).map_err(Into::into)
    }

    pub async fn sops_run_overlay(&self, name: &str, run_id: &str) -> Result<Value> {
        self.call(
            method::SOPS_RUN_OVERLAY,
            serde_json::json!({ "name": name, "run_id": run_id }),
        )
        .await
    }

    /// Fire a Manual run for `name` with an optional JSON-string payload and
    /// return its run id. Mirrors the web `runSop` path; the daemon builds the
    /// Manual `SopEvent` and requires a matching manual trigger.
    pub async fn sops_run(&self, name: &str, payload: Option<&str>) -> Result<String> {
        let value: Value = self
            .call(
                method::SOPS_RUN,
                serde_json::json!({ "name": name, "payload": payload }),
            )
            .await?;
        value
            .get("run_id")
            .and_then(Value::as_str)
            .map(str::to_string)
            .ok_or_else(|| anyhow::Error::msg("sops/run: response missing run_id"))
    }

    /// List run summaries, optionally filtered to one SOP by name. The
    /// daemon returns `{ "runs": [SopRunSummary...] }`.
    ///
    /// Forward compatibility is bounded, not total. `#[serde(default)]` on
    /// [`SopRunSummaryView`] tolerates fields a newer daemon omits, and
    /// `#[serde(other)]` on [`SopRunStatusView`] folds an unrecognized status
    /// string to `Unknown` instead of failing the row. Anything else — a
    /// field whose JSON type changed, a `runs` value that is not an array, or
    /// a missing `runs` key — still fails closed with an error, which the
    /// pane surfaces as a stale-poll indication rather than silently
    /// rendering an empty list.
    pub async fn sops_runs(&self, sop: Option<&str>) -> Result<Vec<SopRunSummaryView>> {
        let value: Value = self
            .call(method::SOPS_RUNS, serde_json::json!({ "sop": sop }))
            .await?;
        let runs = value
            .get("runs")
            .cloned()
            .ok_or_else(|| anyhow::Error::msg("sops/runs: response missing runs"))?;
        serde_json::from_value(runs).map_err(Into::into)
    }

    pub async fn sops_save(&self, sop: Value) -> Result<Value> {
        self.call(method::SOPS_SAVE, serde_json::json!({ "sop": sop }))
            .await
    }

    pub async fn sops_create(&self, sop: Value) -> Result<Value> {
        self.call(method::SOPS_CREATE, serde_json::json!({ "sop": sop }))
            .await
    }

    /// Move a SOP to a new name. Separate from `sops_save`, which persists
    /// under the submitted SOP's own name and so can only overwrite the SOP it
    /// was loaded from; the daemon collision-checks the target and moves the
    /// definition rather than copying it.
    pub async fn sops_rename(&self, from: &str, to: &str) -> Result<Value> {
        self.call(
            method::SOPS_RENAME,
            serde_json::json!({ "from": from, "to": to }),
        )
        .await
    }

    pub async fn sops_delete(&self, name: &str) -> Result<Value> {
        self.call(method::SOPS_DELETE, serde_json::json!({ "name": name }))
            .await
    }

    /// Resolve a paused checkpoint on a live run. `decision` is the raw
    /// `ApprovalDecision` wire value (`"approve"` or `{"deny": {"reason": ..}}`);
    /// the daemon deserializes it into the canonical enum. Returns the refreshed
    /// run overlay so the surface re-renders the post-decision state.
    pub async fn sops_decide(&self, name: &str, run_id: &str, decision: Value) -> Result<Value> {
        self.call(
            method::SOPS_DECIDE,
            serde_json::json!({ "name": name, "run_id": run_id, "decision": decision }),
        )
        .await
    }

    pub async fn sops_wire_draft(&self, sop: Value, edit: Value) -> Result<Value> {
        self.call(
            method::SOPS_WIRE_DRAFT,
            serde_json::json!({ "sop": sop, "edit": edit }),
        )
        .await
    }

    pub async fn sops_graph_draft(&self, sop: Value) -> Result<SopGraphView> {
        let value = self
            .call(method::SOPS_GRAPH_DRAFT, serde_json::json!({ "sop": sop }))
            .await?;
        serde_json::from_value(value).map_err(Into::into)
    }

    pub async fn sops_trigger_sources(&self) -> Result<TriggerSourceRegistryView> {
        let value = self
            .call(method::SOPS_TRIGGER_SOURCES, serde_json::json!({}))
            .await?;
        serde_json::from_value(value).map_err(Into::into)
    }

    // ── Session methods ──────────────────────────────────────────

    pub async fn session_new(
        &self,
        agent_alias: &str,
        cwd: Option<&str>,
    ) -> Result<SessionNewResult> {
        self.session_new_with_id(agent_alias, cwd, None).await
    }

    /// Like [`Self::session_new_with_id`] but sets `exclude_memory: true` so the
    /// daemon strips memory tools and uses a NoneMemory backend. Used by the
    /// ACP pane, which should never have access to persistent memory.
    pub async fn session_new_acp(
        &self,
        agent_alias: &str,
        cwd: Option<&str>,
        session_id: Option<&str>,
    ) -> Result<SessionNewResult> {
        let tui_id = self.tui_id.as_deref();
        self.call(
            method::SESSION_NEW,
            serde_json::json!({
                "agent_alias": agent_alias,
                "cwd": cwd,
                "session_id": session_id,
                "tui_id": tui_id,
                "exclude_memory": true,
                "chat_mode": "acp",
                "keep_siblings": true,
                "interaction_surface": "zerocode_code",
            }),
        )
        .await
    }

    /// Create or rehydrate a session. When `session_id` is `Some`, the daemon
    /// creates the session with that ID, restoring persisted history if it
    /// exists — effectively "attaching" to a prior session.
    ///
    /// Always sends `keep_siblings: true`: zerocode tracks every session it
    /// opens (agent sidebar) and closes them explicitly, so the daemon's
    /// idle-sibling eviction sweep must not reap the tracked backgrounds.
    pub async fn session_new_with_id(
        &self,
        agent_alias: &str,
        cwd: Option<&str>,
        session_id: Option<&str>,
    ) -> Result<SessionNewResult> {
        let tui_id = self.tui_id.as_deref();
        self.call(
            method::SESSION_NEW,
            serde_json::json!({
                "agent_alias": agent_alias,
                "cwd": cwd,
                "session_id": session_id,
                "tui_id": tui_id,
                "keep_siblings": true,
            }),
        )
        .await
    }

    pub async fn session_cancel(&self, session_id: &str) -> Result<SessionCancelResult> {
        self.call(
            method::SESSION_CANCEL,
            serde_json::json!({ "session_id": session_id }),
        )
        .await
    }

    pub async fn session_state(&self, session_id: &str) -> Result<SessionStateResult> {
        self.call(
            method::SESSION_STATE,
            serde_json::json!({ "session_id": session_id }),
        )
        .await
    }

    /// Apply session-scoped overrides (model, model_provider, temperature) to a
    /// live session. The daemon applies them immediately and returns the merged
    /// set. A `model_provider` override triggers a live provider-box rebuild
    /// daemon-side.
    pub async fn session_configure(
        &self,
        session_id: &str,
        overrides: SessionOverrides,
    ) -> Result<SessionConfigureResult> {
        self.call(
            method::SESSION_CONFIGURE,
            serde_json::json!({ "session_id": session_id, "overrides": overrides }),
        )
        .await
    }

    pub async fn session_git_branch(&self, session_id: &str) -> Result<SessionGitBranchResult> {
        self.call(
            method::SESSION_GIT_BRANCH,
            serde_json::json!({ "session_id": session_id }),
        )
        .await
    }

    pub async fn session_approve(
        &self,
        session_id: &str,
        request_id: &str,
        decision: ApprovalDecision,
    ) -> Result<SessionApproveResult> {
        let mut params = serde_json::json!({
            "session_id": session_id,
            "request_id": request_id,
            "decision": decision.kind(),
        });
        if let ApprovalDecision::RejectWithEdit { ref replacement } = decision {
            params["replacement"] = serde_json::Value::String(replacement.clone());
        }
        self.call(method::SESSION_APPROVE, params).await
    }

    pub async fn session_close(&self, session_id: &str) -> Result<()> {
        let request = self.rpc.request(
            method::SESSION_CLOSE,
            serde_json::json!({ "session_id": session_id }),
        );
        match tokio::time::timeout(Duration::from_secs(5), request).await {
            Ok(Ok(_)) => Ok(()),
            Ok(Err(error)) if error.code == jsonrpc::error_codes::SESSION_NOT_FOUND => Ok(()),
            Ok(Err(error)) => anyhow::bail!(
                "RPC {}: {} ({})",
                method::SESSION_CLOSE,
                error.message,
                error.code
            ),
            Err(_) => anyhow::bail!("RPC {}: timed out after 5s", method::SESSION_CLOSE),
        }
    }

    pub async fn session_kill(&self, session_id: &str) -> Result<()> {
        let _: serde_json::Value = self
            .call(
                method::SESSION_KILL,
                serde_json::json!({ "session_id": session_id }),
            )
            .await?;
        Ok(())
    }

    // ── Dashboard helpers ────────────────────────────────────────

    pub async fn status(&self) -> Result<StatusResult> {
        self.call(method::STATUS, serde_json::json!({})).await
    }

    pub async fn health(&self) -> Result<Value> {
        self.call(method::HEALTH, serde_json::json!({})).await
    }

    pub async fn doctor_run(&self) -> Result<DoctorRunResult> {
        self.call_with_timeout(
            method::DOCTOR_RUN,
            serde_json::json!({}),
            std::time::Duration::from_secs(30),
        )
        .await
    }

    pub async fn cost_query(&self, agent: Option<&str>) -> Result<CostSummaryResult> {
        self.call(method::COST_QUERY, serde_json::json!({ "agent": agent }))
            .await
    }

    /// Optional organization-level billed-cost snapshot from the daemon's
    /// `<data_dir>/org_cost.json`. Returns `None` when the file is absent (a
    /// vanilla build never writes it), so the dashboard simply omits the
    /// organization row. An integrator can populate it via an external sync.
    pub async fn cost_org(&self) -> Result<Option<OrgCost>> {
        let v: serde_json::Value = self.call(method::COST_ORG, serde_json::json!({})).await?;
        if v.is_null() {
            return Ok(None);
        }
        Ok(Some(serde_json::from_value(v)?))
    }

    /// Cost summary scoped to a `[from, to)` window (RFC3339). The daemon rolls
    /// up only records in the window, so `session_cost_usd` / `total_tokens` /
    /// `by_model` reflect that period — used by the Cost tab's day/month/
    /// quarter/YTD breakdown.
    pub async fn cost_query_window(
        &self,
        from: &str,
        to: &str,
        agent: Option<&str>,
    ) -> Result<CostSummaryResult> {
        self.call(
            method::COST_QUERY,
            serde_json::json!({ "from": from, "to": to, "agent": agent }),
        )
        .await
    }

    pub async fn session_list(&self, query: Option<&str>) -> Result<SessionListResult> {
        self.call(method::SESSION_LIST, serde_json::json!({ "query": query }))
            .await
    }

    /// List ACP sessions from the dedicated ACP session store. The Code (ACP)
    /// pane's picker uses this so its list only contains ACP-origin sessions
    /// — chat sessions live in a separate backend and must not show up here.
    pub async fn acp_session_list(&self) -> Result<SessionListResult> {
        self.call(method::SESSION_LIST_ACP, serde_json::json!({}))
            .await
    }

    pub async fn agents_status(&self) -> Result<AgentsStatusResult> {
        self.call(method::AGENTS_STATUS, serde_json::json!({}))
            .await
    }

    pub async fn cron_list(&self) -> Result<CronListResult> {
        self.call(method::CRON_LIST, serde_json::json!({})).await
    }

    pub async fn cron_runs(&self, id: &str, limit: Option<u32>) -> Result<CronRunsResult> {
        self.call(
            method::CRON_RUNS,
            serde_json::json!({ "id": id, "limit": limit }),
        )
        .await
    }

    pub async fn cron_trigger(&self, id: &str) -> Result<CronTriggerResult> {
        self.call_with_timeout(
            method::CRON_TRIGGER,
            serde_json::json!({ "id": id }),
            CRON_TRIGGER_TIMEOUT,
        )
        .await
    }

    pub async fn memory_list(&self, category: Option<&str>) -> Result<MemoryListResult> {
        self.call(
            method::MEMORY_LIST,
            serde_json::json!({ "category": category }),
        )
        .await
    }

    pub async fn memory_search(&self, query: &str, limit: usize) -> Result<MemorySearchResult> {
        self.call(
            method::MEMORY_SEARCH,
            serde_json::json!({ "query": query, "limit": limit }),
        )
        .await
    }

    /// `memory/get { key }` — fetch one memory entry's full content.
    /// The Memory pane keeps only preview rows in memory and
    /// lazy-fetches the full entry when the detail pane opens.
    pub async fn memory_get(&self, key: &str) -> Result<MemoryGetResult> {
        self.call("memory/get", serde_json::json!({ "key": key }))
            .await
    }

    pub async fn session_messages(&self, session_id: &str) -> Result<SessionMessagesResult> {
        self.call(
            method::SESSION_MESSAGES,
            serde_json::json!({ "session_id": session_id }),
        )
        .await
    }

    /// Paginated variant of `session_messages`. `limit` caps the page
    /// size, `before_index` paginates older slices. Returns
    /// `(messages, total, start)` so the Sessions pane can size
    /// scroll affordances and render "X of Y" without holding the
    /// full history in memory.
    pub async fn session_messages_page(
        &self,
        session_id: &str,
        limit: Option<usize>,
        before_index: Option<usize>,
    ) -> Result<SessionMessagesResult> {
        let mut params = serde_json::json!({ "session_id": session_id });
        if let Some(l) = limit {
            params["limit"] = serde_json::json!(l);
        }
        if let Some(b) = before_index {
            params["before_index"] = serde_json::json!(b);
        }
        self.call(method::SESSION_MESSAGES, params).await
    }

    // ── TUI identity helpers ─────────────────────────────────────

    /// The TUI session UID assigned by the daemon, if connected.
    pub fn tui_id(&self) -> Option<&str> {
        self.tui_id.as_deref()
    }

    /// The HMAC signature for the TUI session UID.
    pub fn tui_sig(&self) -> Option<&str> {
        self.tui_sig.as_deref()
    }

    pub fn commands(&self) -> &[crate::wire::CommandDescriptor] {
        &self.commands
    }

    /// List all connected TUI sessions from the daemon registry.
    pub async fn tui_list(&self) -> Result<TuiListResult> {
        self.call(method::TUI_LIST, serde_json::json!({})).await
    }

    /// List directory contents on the remote daemon (WSS only).
    /// Returns the structured response from `fs/list_dir`.
    pub async fn fs_list_dir(
        &self,
        path: &std::path::Path,
        show_hidden: bool,
    ) -> Result<FsListDirResponse> {
        self.call(
            method::FS_LIST_DIR,
            serde_json::json!({
                "path": path.to_string_lossy(),
                "show_hidden": show_hidden,
            }),
        )
        .await
    }

    // ── Test-only constructors ────────────────────────────────────

    /// Test-only constructor that skips the Unix socket connect + initialize handshake.
    /// Broadcast buffers are large enough for scripted notification-routing
    /// tests to enqueue a burst before the pane drains it.
    #[cfg(test)]
    pub fn with_rpc(outbound: Arc<RpcOutbound>) -> Self {
        Self::with_rpc_parts(outbound, Transport::Local, None)
    }

    /// Test-only constructor that also attaches a relay pump handle, so a test
    /// can observe that [`Self::shutdown`] reclaims the tunnel.
    #[cfg(test)]
    pub fn with_rpc_and_pump(
        outbound: Arc<RpcOutbound>,
        relay_pump: Option<tokio::task::JoinHandle<()>>,
    ) -> Self {
        Self::with_rpc_parts(outbound, Transport::Local, relay_pump)
    }

    /// Test-only constructor that also controls the transport-specific payload
    /// encoding used by callers such as attachment dispatch.
    #[cfg(test)]
    pub fn with_rpc_transport(outbound: Arc<RpcOutbound>, transport: Transport) -> Self {
        Self::with_rpc_parts(outbound, transport, None)
    }

    /// The union constructor the named test constructors delegate to.
    #[cfg(test)]
    fn with_rpc_parts(
        outbound: Arc<RpcOutbound>,
        transport: Transport,
        relay_pump: Option<tokio::task::JoinHandle<()>>,
    ) -> Self {
        let (notif_tx, _) = tokio::sync::broadcast::channel(64);
        let (_inbound_tx, inbound_rx) = tokio::sync::mpsc::unbounded_channel();
        Self {
            rpc: outbound,
            read_task: tokio::spawn(async {}),
            reader_control: None,
            router_task: tokio::spawn(async {}),
            writer_task: None,
            relay_pump,
            server_version: "test".to_string(),
            server_pid: None,
            notifications_bcast: notif_tx,
            inbound_requests_rx: Mutex::new(Some(inbound_rx)),
            inbound_responses: Arc::new(InboundResponseTracker::default()),
            connection_state: Arc::new(Mutex::new(ConnectionState::Connected)),
            tui_id: None,
            tui_sig: None,
            transport,
            commands: Vec::new(),
        }
    }

    /// Test-only: inject a notification as if the daemon had sent it.
    /// Subscribers created before this call (e.g. a pane's drain receiver)
    /// observe it on their next `try_recv`.
    #[cfg(test)]
    pub fn push_notification_for_test(&self, method: &str, params: Value) {
        let _ = self.notifications_bcast.send(RpcNotification {
            method: method.to_string(),
            params,
        });
    }

    /// Stop this client's transport and release everything it holds open.
    ///
    /// A replaced client is not idle: its reader still owns the socket, its
    /// writer still drains a queue, and on the relayed path its pump still holds
    /// a route open on the relay. Nothing drops those - the tasks are detached,
    /// and `RpcClient` has no destructor that could reach them - so a migration
    /// that simply overwrote the `Arc` left the old connection running and the
    /// old relay route allocated until the daemon or relay timed it out.
    ///
    /// Call this on the client being REPLACED, after the new one has been
    /// adopted, and on a new client whose adoption failed. It is idempotent:
    /// aborting a finished task is a no-op.
    pub fn shutdown(&self) {
        self.read_task.abort();
        self.router_task.abort();
        if let Some(writer) = &self.writer_task {
            writer.abort();
        }
        if let Some(pump) = &self.relay_pump {
            pump.abort();
        }
    }

    /// Whether this client still holds a relay tunnel pump.
    #[cfg(test)]
    pub fn relay_pump_finished(&self) -> Option<bool> {
        self.relay_pump.as_ref().map(|p| p.is_finished())
    }

    /// Transport protocol of this connection.
    pub fn transport(&self) -> Transport {
        self.transport
    }
}

// ── Response types (client-side, minimal) ────────────────────────

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigListResult {
    pub entries: Vec<ConfigFieldEntry>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigSetResult {
    #[serde(default)]
    pub revision: Option<crate::wire::PublishedConfigRevision>,
}

#[derive(Debug, serde::Deserialize)]
pub struct ConfigMapKeyMutationResult {
    #[serde(default, alias = "created", alias = "deleted")]
    pub changed: bool,
    #[serde(default)]
    pub revision: Option<crate::wire::PublishedConfigRevision>,
}

#[cfg(test)]
mod initialize_version_tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn initialize_response_accepts_matching_server_version() {
        let parsed = parse_initialize_response(&json!({
            "server_version": env!("CARGO_PKG_VERSION"),
            "server_pid": 42,
            "tui_id": "tui_1",
            "tui_sig": "sig_1"
        }))
        .unwrap();

        assert_eq!(parsed.server_version, env!("CARGO_PKG_VERSION"));
        assert_eq!(parsed.server_pid, Some(42));
        assert_eq!(parsed.tui_id.as_deref(), Some("tui_1"));
        assert_eq!(parsed.tui_sig.as_deref(), Some("sig_1"));
        assert_eq!(parsed.commands, legacy_tui_command_descriptors());
    }

    #[test]
    fn initialize_response_parses_command_descriptors() {
        let parsed = parse_initialize_response(&json!({
            "server_version": env!("CARGO_PKG_VERSION"),
            "commands": [{
                "id": "new",
                "name": "new",
                "aliases": ["new-session"]
            }]
        }))
        .unwrap();

        assert_eq!(
            parsed.commands,
            vec![crate::wire::CommandDescriptor {
                id: "new".into(),
                name: "new".into(),
                aliases: vec!["new-session".into()],
            }]
        );
    }

    #[test]
    fn initialize_response_preserves_present_empty_command_catalogue() {
        let parsed = parse_initialize_response(&json!({
            "server_version": env!("CARGO_PKG_VERSION"),
            "commands": []
        }))
        .unwrap();

        assert!(parsed.commands.is_empty());
    }

    #[test]
    fn initialize_response_allows_missing_server_pid_for_compatibility() {
        let parsed = parse_initialize_response(&json!({
            "server_version": env!("CARGO_PKG_VERSION")
        }))
        .unwrap();

        assert_eq!(parsed.server_pid, None);
    }

    #[test]
    fn initialize_response_rejects_mismatched_server_version() {
        let err = parse_initialize_response(&json!({
            "server_version": "0.0.0-test"
        }))
        .unwrap_err();
        let mismatch = err
            .downcast_ref::<DaemonVersionMismatch>()
            .expect("mismatched daemon version should be typed");

        assert_eq!(mismatch.client_version(), env!("CARGO_PKG_VERSION"));
        assert_eq!(mismatch.server_version(), "0.0.0-test");
        assert!(err.to_string().contains("Version mismatch"));
    }

    #[test]
    fn initialize_response_rejects_missing_server_version_as_unknown() {
        let err = parse_initialize_response(&json!({})).unwrap_err();
        let mismatch = err
            .downcast_ref::<DaemonVersionMismatch>()
            .expect("missing daemon version should be typed");

        assert_eq!(mismatch.client_version(), env!("CARGO_PKG_VERSION"));
        assert_eq!(mismatch.server_version(), "unknown");
    }
}

#[cfg(test)]
mod initialize_timeout_tests {
    use super::*;

    #[tokio::test]
    async fn initialize_request_times_out_when_transport_never_responds() {
        let (writer_tx, mut writer_rx) = mpsc::channel::<String>(1);
        let rpc = RpcOutbound::new(writer_tx);
        let receiver = tokio::spawn(async move {
            writer_rx.recv().await.expect("initialize request");
            std::future::pending::<()>().await;
        });

        let err = request_initialize(&rpc, serde_json::json!({}), Duration::from_millis(20))
            .await
            .unwrap_err();

        assert!(err.downcast_ref::<DaemonInitializeTimeout>().is_some());
        receiver.abort();
    }
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigDeleteResult {
    #[serde(default)]
    pub revision: Option<crate::wire::PublishedConfigRevision>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigReloadResult {}

/// One selectable locale (`locales/list`).
#[derive(Debug, Clone, serde::Deserialize)]
pub struct LocaleOption {
    pub code: String,
    pub label: String,
}

#[derive(Debug, serde::Deserialize)]
pub struct LocalesListResult {
    pub locales: Vec<LocaleOption>,
}

/// One fetched catalogue's bytes (`locales/fetch`).
#[derive(Debug, Clone, serde::Deserialize)]
pub struct FetchedCatalog {
    pub name: String,
    pub filename: String,
    pub content: String,
}

#[derive(Debug, serde::Deserialize)]
pub struct LocalesFetchResult {
    pub catalogs: Vec<FetchedCatalog>,
    pub skipped: Vec<String>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigMapKeysResult {
    pub keys: Vec<String>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigRenameMapKeyResult {
    pub renamed: bool,
    #[serde(default)]
    pub warnings: Vec<String>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigResolveAliasSourceResult {
    pub values: Vec<String>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigSectionsResult {
    pub sections: Vec<ConfigSectionEntry>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigSectionEntry {
    pub key: String,
    pub label: String,
    pub help: String,
    pub completed: bool,
    /// Display group label (`"Foundation"`, `"Tools"`, …) from
    /// `zeroclaw_config::sections::SectionGroup::label()`. Empty when
    /// the daemon predates group plumbing — the sections pane falls
    /// back to the flat ungrouped list.
    #[serde(default)]
    pub group: String,
    /// Stable locale-independent group key. Empty when connected to an older
    /// daemon; the Config pane then derives it from the legacy English label.
    #[serde(default)]
    pub group_key: String,
    #[serde(default)]
    pub shape: Option<SectionShape>,
    #[serde(default)]
    pub cost_category: String,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigTemplatesResult {
    pub templates: Vec<ConfigTemplateEntry>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct CatalogModelsResult {
    pub models: Vec<String>,
    /// Pricing keyed by upstream model id, when the provider's catalog
    /// returns it. Mirrors the gateway `/api/config/catalog/models` payload
    /// (same RPC) so the Costs tab can pre-fill rate sheets.
    #[serde(default)]
    pub pricing: Option<std::collections::HashMap<String, CatalogModelPricing>>,
    #[serde(default)]
    pub live: bool,
}

/// Per-token USD pricing strings as emitted by the catalog RPC. Field names
/// match `zeroclaw_api::model_provider::ModelPricing`; only the rates the
/// cost-rate sheet consumes are kept.
#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct CatalogModelPricing {
    #[serde(default)]
    pub prompt: Option<String>,
    #[serde(default)]
    pub completion: Option<String>,
    #[serde(default)]
    pub input_cache_read: Option<String>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ConfigTemplateEntry {
    pub path: String,
}

// ── Personality types ────────────────────────────────────────────

#[derive(Debug, Clone, serde::Deserialize)]
pub struct PersonalityFileEntry {
    pub filename: String,
    pub exists: bool,
    #[serde(default)]
    pub size: u64,
}

#[derive(Debug, serde::Deserialize)]
pub struct PersonalityListResult {
    pub files: Vec<PersonalityFileEntry>,
    pub max_chars: usize,
}

#[derive(Debug, serde::Deserialize)]
pub struct PersonalityGetResult {
    #[serde(default)]
    pub content: Option<String>,
}

#[derive(Debug, serde::Deserialize)]
pub struct PersonalityPutResult {}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct TemplateFileEntry {
    pub filename: String,
    pub content: String,
}

#[derive(Debug, serde::Deserialize)]
pub struct PersonalityTemplatesResult {
    pub files: Vec<TemplateFileEntry>,
}

// ── Skills types ─────────────────────────────────────────────────

#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct SkillFrontmatter {
    pub name: String,
    pub description: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub license: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub author: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub version: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub category: Option<String>,
    /// Keeps this skill's instructions inlined in the system prompt even in
    /// compact skill-prompt mode. Not editable from this TUI mirror, but must
    /// be carried through the load→edit→save round-trip so editing a skill
    /// here doesn't silently reset it to `false`.
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub always: bool,
}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct SkillListEntry {
    pub name: String,
}

#[derive(Debug, serde::Deserialize)]
pub struct SkillsListResult {
    pub skills: Vec<SkillListEntry>,
}

#[derive(Debug, serde::Deserialize)]
pub struct SkillsReadResult {
    pub frontmatter: SkillFrontmatter,
    pub body: String,
}

#[derive(Debug, serde::Deserialize)]
pub struct SkillsWriteResult {}

#[derive(Debug, serde::Deserialize)]
pub struct SkillsDeleteResult {}

#[cfg(test)]
mod skill_frontmatter_tests {
    use super::*;

    #[test]
    fn always_true_survives_deserialize_then_serialize_round_trip() {
        let value = serde_json::json!({
            "name": "security-policy",
            "description": "Critical safety rules",
            "always": true,
        });

        let frontmatter: SkillFrontmatter = serde_json::from_value(value).unwrap();
        assert!(
            frontmatter.always,
            "always: true in the wire payload must deserialize into the mirror struct"
        );

        let reserialized = serde_json::to_value(&frontmatter).unwrap();
        assert_eq!(
            reserialized.get("always"),
            Some(&serde_json::Value::Bool(true)),
            "always must round-trip through re-serialization, not be silently dropped \
             on the TUI's load -> edit -> save path"
        );
    }
}

// ── Quickstart types ─────────────────────────────────────────────
//
// **Mirror** of the wire shapes defined in
// `zeroclaw_runtime::rpc::types` (the daemon-side single source of
// truth, which itself mirrors the gateway's HTTP route shapes). The
// types live in `zeroclaw-runtime`, but that crate is not on the
// `apps/zerocode` dependency tree — pulling it in would compile the
// entire runtime into the TUI binary. Instead we duplicate the wire
// shape here; the integration drift test enforces equality across
// surfaces, so divergence is a CI failure rather than a silent bug.

/// Mirror of `zeroclaw_runtime::quickstart::Surface` (`snake_case` on the wire).
#[derive(Debug, Clone, Copy, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum QuickstartSurface {
    Web,
    Tui,
    Cli,
    Test,
}

/// Mirror of `zeroclaw_runtime::quickstart::QuickstartStep`.
#[derive(Debug, Clone, Copy, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum QuickstartStep {
    ModelProvider,
    RiskProfile,
    RuntimeProfile,
    Memory,
    Channels,
    PeerGroups,
    Agent,
}

/// Mirror of `zeroclaw_runtime::quickstart::QuickstartError`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub struct QuickstartError {
    pub step: QuickstartStep,
    pub field: String,
    pub message: String,
}

/// Mirror of `zeroclaw_runtime::quickstart::AppliedAgent`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub struct AppliedAgent {
    pub alias: String,
    pub model_provider: String,
    pub risk_profile: String,
    pub runtime_profile: String,
    pub channels: Vec<String>,
    pub memory_backend: String,
}

/// Mirror of `zeroclaw_runtime::quickstart::FieldSection`.
#[derive(Debug, Clone, Copy, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum QuickstartFieldSection {
    ModelProvider,
    Channel,
}

/// Mirror of `zeroclaw_config::traits::PropKind` (wire form).
#[derive(Debug, Clone, Copy, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum QuickstartFieldKind {
    String,
    Bool,
    Integer,
    Float,
    Enum,
    StringArray,
    ObjectArray,
    Object,
}

/// Mirror of `zeroclaw_runtime::quickstart::FieldDescriptor`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct QuickstartFieldDescriptor {
    pub key: String,
    pub label: String,
    pub help: String,
    pub kind: QuickstartFieldKind,
    pub is_secret: bool,
    pub enum_variants: Option<Vec<String>>,
    pub required: bool,
    pub default: Option<String>,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct QuickstartFieldsResult {
    pub fields: Vec<QuickstartFieldDescriptor>,
}

/// Mirror of `zeroclaw_runtime::quickstart::QuickstartState`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct QuickstartStateResult {
    pub quickstart_completed: bool,
    pub agents: Vec<String>,
    pub risk_profiles: Vec<String>,
    pub runtime_profiles: Vec<String>,
    #[serde(default)]
    pub default_runtime_profile: Option<String>,
    pub model_providers: Vec<String>,
    pub channels: Vec<String>,
    /// Subset of `channels` not yet bound to any agent — safe to
    /// reuse without violating the one-channel-one-agent invariant.
    #[serde(default)]
    pub unassigned_channels: Vec<String>,
    pub storage: Vec<String>,
    /// Picker rows for "Create new model provider" — supplied by the
    /// daemon so the TUI never hardcodes the option list.
    #[serde(default)]
    pub model_provider_types: Vec<QuickstartTypeOption>,
    /// Picker rows for "Create new channel" — supplied by the
    /// daemon so the TUI never hardcodes the option list.
    #[serde(default)]
    pub channel_types: Vec<QuickstartTypeOption>,
    #[serde(default)]
    pub risk_presets: Vec<QuickstartPresetMirror>,
    #[serde(default)]
    pub runtime_presets: Vec<QuickstartPresetMirror>,
    #[serde(default)]
    pub memory_kinds: Vec<String>,
    #[serde(default)]
    pub personality_files: Vec<String>,
}

/// Mirror of `zeroclaw_config::presets::RiskPreset` / `RuntimePreset`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct QuickstartPresetMirror {
    pub preset_name: String,
    pub label: String,
    pub help: String,
}

/// Mirror of `zeroclaw_runtime::rpc::types::QuickstartTypeOption`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct QuickstartTypeOption {
    pub kind: String,
    pub display_name: String,
    #[serde(default)]
    pub local: bool,
    #[serde(default)]
    pub default_runtime_profile: Option<String>,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum QuickstartValidateResult {
    Ok,
    Errors { errors: Vec<QuickstartError> },
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum QuickstartApplyResult {
    Applied {
        agent: AppliedAgent,
        daemon_restarted: bool,
    },
    Errors {
        errors: Vec<QuickstartError>,
    },
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct QuickstartDismissResult {
    pub recorded: bool,
}

//

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SopStepKind {
    #[default]
    Execute,
    Checkpoint,
    Capability,
}

impl SopStepKind {
    pub const ALL: [SopStepKind; 3] = [
        SopStepKind::Execute,
        SopStepKind::Checkpoint,
        SopStepKind::Capability,
    ];

    pub fn as_str(&self) -> &'static str {
        match self {
            SopStepKind::Execute => "execute",
            SopStepKind::Checkpoint => "checkpoint",
            SopStepKind::Capability => "capability",
        }
    }
}

// SOP graph wire types. zerocode is an RPC-only surface: it deserializes these
// off `sops/graph` rather than linking the backend crate that produces them.
// The shape here MUST match `zeroclaw-sop-graph`'s serde projection byte for
// byte (field names, snake_case renames, defaults) or RPC decoding drifts.

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PinClass {
    Flow,
    Data,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FlowRole {
    Sequence,
    Dependency,
    Failure,
    Switch,
    Trigger,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NodeKind {
    #[default]
    Step,
    Trigger,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct GraphPin {
    pub class: PinClass,
    pub name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub data_type: Option<String>,
    pub required: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct GraphNode {
    pub step: u32,
    pub title: String,
    #[serde(default)]
    pub kind: NodeKind,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub subtitle: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub trigger_index: Option<u32>,
    pub inputs: Vec<GraphPin>,
    pub outputs: Vec<GraphPin>,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct GraphWire {
    pub class: PinClass,
    pub from_step: u32,
    pub to_step: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub flow_role: Option<FlowRole>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub from_pin: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub to_pin: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum GraphSeverity {
    Warning,
    Error,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct GraphDiagnostic {
    pub severity: GraphSeverity,
    pub step: u32,
    pub message: String,
}

#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct NodePosition {
    pub step: u32,
    pub col: u32,
    pub row: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub x: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub y: Option<f64>,
}

pub const LAYOUT_NODE_W: f64 = 210.0;
pub const LAYOUT_NODE_H: f64 = 84.0;
pub const LAYOUT_COL_GAP: f64 = 130.0;
pub const LAYOUT_ROW_GAP: f64 = 46.0;
pub const LAYOUT_ORIGIN: f64 = 24.0;

#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct LayoutGeometry {
    pub node_w: f64,
    pub node_h: f64,
    pub col_gap: f64,
    pub row_gap: f64,
    pub origin: f64,
}

impl LayoutGeometry {
    pub const CANONICAL: Self = Self {
        node_w: LAYOUT_NODE_W,
        node_h: LAYOUT_NODE_H,
        col_gap: LAYOUT_COL_GAP,
        row_gap: LAYOUT_ROW_GAP,
        origin: LAYOUT_ORIGIN,
    };

    pub const fn col_pitch(&self) -> f64 {
        self.node_w + self.col_gap
    }

    pub const fn row_pitch(&self) -> f64 {
        self.node_h + self.row_gap
    }
}

impl Default for LayoutGeometry {
    fn default() -> Self {
        Self::CANONICAL
    }
}

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct GraphLayout {
    #[serde(default)]
    pub positions: Vec<NodePosition>,
    #[serde(default)]
    pub columns: u32,
    #[serde(default)]
    pub rows: u32,
    #[serde(default)]
    pub geometry: LayoutGeometry,
}

impl Default for GraphLayout {
    fn default() -> Self {
        Self {
            positions: Vec::new(),
            columns: 0,
            rows: 0,
            geometry: LayoutGeometry::CANONICAL,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct SopGraphView {
    #[serde(default)]
    pub nodes: Vec<GraphNode>,
    #[serde(default)]
    pub wires: Vec<GraphWire>,
    #[serde(default)]
    pub diagnostics: Vec<GraphDiagnostic>,
    #[serde(default)]
    pub layout: GraphLayout,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NodeRunState {
    #[default]
    Pending,
    Active,
    Completed,
    Failed,
    Skipped,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct ChannelAliasView {
    pub alias: String,
    pub enabled: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub owning_agent: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct ChannelTriggerKindView {
    pub channel: String,
    #[serde(default)]
    pub aliases: Vec<ChannelAliasView>,
    pub configured: bool,
    pub setup_path: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub condition: Option<PayloadContractView>,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TriggerFieldKindView {
    #[default]
    Text,
    List,
    Expression,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct TriggerFieldView {
    pub name: String,
    #[serde(default)]
    pub options: Vec<String>,
    #[serde(default)]
    pub multi: bool,
    #[serde(default)]
    pub kind: TriggerFieldKindView,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ConditionValueTypeView {
    #[default]
    String,
    Number,
    Bool,
    Enum,
    DateTime,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct ConditionFieldView {
    pub path: String,
    #[serde(default)]
    pub label: String,
    #[serde(default)]
    pub value_type: ConditionValueTypeView,
    #[serde(default)]
    pub options: Vec<String>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct PayloadContractView {
    #[serde(default)]
    pub open: bool,
    #[serde(default)]
    pub direct: bool,
    #[serde(default)]
    pub fields: Vec<ConditionFieldView>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct ConditionOpSpecView {
    pub token: String,
    #[serde(default)]
    pub label: String,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct BoundTriggerSourceView {
    pub source: String,
    #[serde(default)]
    pub fields: Vec<TriggerFieldView>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub condition: Option<PayloadContractView>,
}

/// Result shape of `sops/trigger-sources`.
#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct TriggerSourceRegistryView {
    #[serde(default)]
    pub sources: Vec<String>,
    #[serde(default)]
    pub bound: Vec<BoundTriggerSourceView>,
    #[serde(default)]
    pub channels: Vec<ChannelTriggerKindView>,
    #[serde(default)]
    pub operators: Vec<ConditionOpSpecView>,
}

/// Run status as serialized by the runtime's `SopRunStatus`. Unknown
/// variants from a newer daemon fold into [`SopRunStatusView::Unknown`]
/// so an older zerocode keeps rendering rather than dropping the run.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SopRunStatusView {
    #[default]
    Pending,
    Running,
    WaitingApproval,
    PausedCheckpoint,
    Completed,
    Failed,
    Cancelled,
    #[serde(other)]
    Unknown,
}

impl SopRunStatusView {
    /// True while the run is parked on an operator decision (approval gate
    /// or deterministic checkpoint).
    pub fn needs_input(self) -> bool {
        matches!(self, Self::WaitingApproval | Self::PausedCheckpoint)
    }

    /// True once the run has reached a terminal state.
    pub fn is_terminal(self) -> bool {
        matches!(self, Self::Completed | Self::Failed | Self::Cancelled)
    }
}

/// One run row from `sops/runs`; mirrors the runtime `SopRunSummary`.
/// Every field defaults so a field added daemon-side never breaks an
/// older zerocode.
#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(default)]
pub struct SopRunSummaryView {
    pub run_id: String,
    pub sop_name: String,
    pub status: SopRunStatusView,
    pub current_step: u32,
    pub total_steps: u32,
    pub started_at: String,
    pub completed_at: Option<String>,
    pub trigger_source: String,
    /// True while the run is live in the engine's active set rather than
    /// a retained terminal record.
    pub active: bool,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct SwitchRule {
    pub name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub when: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub goto: Option<u32>,
    #[serde(skip)]
    pub goto_buf: Option<String>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct StepRouting {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub when: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub next: Option<u32>,
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub terminal: bool,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub depends_on: Vec<u32>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub switch: Vec<SwitchRule>,
}

impl StepRouting {
    pub fn is_default(&self) -> bool {
        self == &Self::default()
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum StepFailure {
    #[default]
    Fail,
    Retry {
        max: u32,
    },
    Goto {
        step: u32,
    },
}

impl StepFailure {
    pub fn is_fail(&self) -> bool {
        matches!(self, Self::Fail)
    }
}

/// Mirror of runtime `PlannedToolCall`; drift is caught by the
/// `draft_wire_shape` tests on both sides.
#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct PlannedToolCall {
    pub tool: String,
    #[serde(default)]
    pub args: serde_json::Value,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pinned: Option<serde_json::Value>,
}

#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct StepPos {
    pub x: f64,
    pub y: f64,
}

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct SopStep {
    pub number: u32,
    pub title: String,
    pub body: String,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub suggested_tools: Vec<String>,
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub requires_confirmation: bool,
    #[serde(default)]
    pub kind: SopStepKind,
    #[serde(default, skip_serializing_if = "StepRouting::is_default")]
    pub routing: StepRouting,
    #[serde(default, skip_serializing_if = "StepFailure::is_fail")]
    pub on_failure: StepFailure,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub calls: Vec<PlannedToolCall>,
    #[serde(default, skip_serializing_if = "serde_json::Value::is_null")]
    pub schema: serde_json::Value,
    #[serde(default, skip_serializing_if = "serde_json::Value::is_null")]
    pub scope: serde_json::Value,
    #[serde(default, skip_serializing_if = "serde_json::Value::is_null")]
    pub mode: serde_json::Value,
    #[serde(default, skip_serializing_if = "serde_json::Value::is_null")]
    pub agent: serde_json::Value,
    /// Persisted canvas coordinate set by the web Blueprint editor. zerocode
    /// preserves it verbatim on round-trip; its TUI renders from the grid layout.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pos: Option<StepPos>,
    /// Editor-local raw JSON text for `calls`; never on the wire.
    #[serde(skip)]
    pub calls_buf: Option<String>,
}

impl Default for SopStep {
    fn default() -> Self {
        Self {
            number: 0,
            title: String::new(),
            body: String::new(),
            suggested_tools: Vec::new(),
            requires_confirmation: false,
            kind: SopStepKind::Execute,
            routing: StepRouting::default(),
            on_failure: StepFailure::Fail,
            calls: Vec::new(),
            schema: serde_json::Value::Null,
            scope: serde_json::Value::Null,
            mode: serde_json::Value::Null,
            agent: serde_json::Value::Null,
            pos: None,
            calls_buf: None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct SopDraft {
    pub name: String,
    pub description: String,
    pub version: String,
    pub priority: String,
    pub execution_mode: String,
    pub triggers: Vec<SopTriggerDraft>,
    pub steps: Vec<SopStep>,
    pub cooldown_secs: u64,
    pub max_concurrent: u32,
    pub deterministic: bool,
    #[serde(default, skip_serializing_if = "serde_json::Value::is_null")]
    pub agent: serde_json::Value,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct SopTriggerDraft {
    #[serde(rename = "type")]
    pub kind: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub channel: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub alias: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub path: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub expression: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub topic: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub condition: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub events: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub board: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub signal: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub calendar_source: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub calendar_ids: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub routing_key: Option<String>,
}

impl Default for SopTriggerDraft {
    fn default() -> Self {
        Self {
            kind: "manual".to_string(),
            channel: None,
            alias: None,
            path: None,
            expression: None,
            topic: None,
            condition: None,
            events: Vec::new(),
            board: None,
            signal: None,
            calendar_source: None,
            calendar_ids: Vec::new(),
            routing_key: None,
        }
    }
}

impl Default for SopDraft {
    fn default() -> Self {
        Self {
            name: String::new(),
            description: String::new(),
            version: "1.0.0".to_string(),
            priority: "normal".to_string(),
            execution_mode: "supervised".to_string(),
            triggers: vec![SopTriggerDraft {
                kind: "manual".to_string(),
                ..SopTriggerDraft::default()
            }],
            steps: vec![SopStep {
                number: 1,
                ..SopStep::default()
            }],
            cooldown_secs: 0,
            max_concurrent: 1,
            deterministic: false,
            agent: serde_json::Value::Null,
        }
    }
}

// ── Logs types ───────────────────────────────────────────────────

#[derive(Debug, Default, serde::Serialize)]
#[serde(rename_all = "snake_case")]
pub struct LogsQueryParams {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub since_ts: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub until_ts: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub until_id: Option<String>,
    /// Byte offset cap passed back from the previous page's
    /// `next_cursor_line_offset`. When set, the reader stops scanning
    /// at this offset so the follow-up page only sees lines strictly
    /// older than the previous one. Independent of id ordering.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub until_line_offset: Option<u64>,
    /// Segment-aware cursor passed back from the previous page's
    /// `next_segment_cursor`. Identifies both the segment file and the
    /// byte offset within it, so pagination continues across rotated
    /// archives. Takes precedence over `until_line_offset` when both
    /// are supplied.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub until_segment_cursor: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub severity_min: Option<u8>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub q: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub category: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub action: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub outcome: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub trace_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sop_run_id: Option<String>,
    #[serde(default)]
    pub hide_internal: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub limit: Option<usize>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct LogsQueryResult {
    pub events: Vec<serde_json::Value>,
    #[serde(default)]
    pub log_path: Option<String>,
    /// Legacy cursor: `(timestamp, id)` to feed back as `until_ts` +
    /// `until_id` for older. Tie-breaks same-timestamp events by
    /// lexicographic id, which can drop earlier-written events when id
    /// order diverges from file insertion order. Prefer
    /// [`Self::next_cursor_line_offset`] when available — it is
    /// independent of id ordering.
    pub next_cursor: Option<(String, String)>,
    /// Byte offset past the OLDEST event on the current page. Pass back
    /// as [`LogsQueryParams::until_line_offset`] on the next request to
    /// walk older pages deterministically regardless of id ordering.
    /// `None` when the page is empty, and also `None` when the oldest
    /// event on the page lives in a rotated archive rather than the
    /// active file — use [`Self::next_segment_cursor`] in that case.
    pub next_cursor_line_offset: Option<u64>,
    /// Segment-aware cursor for the oldest event on this page. Pass
    /// back as [`LogsQueryParams::until_segment_cursor`] to walk older
    /// pages across segment boundaries. Supersedes
    /// `next_cursor_line_offset` for `rotating`-mode deployments with
    /// multiple retained segments. Absent (deserialized as `None`) on
    /// daemons predating multi-segment reads.
    #[serde(default)]
    pub next_segment_cursor: Option<String>,
    pub at_end: bool,
    /// True when a retained segment could not be read and was left out of
    /// this page. `at_end` is then only "no older events among the segments
    /// that could be read", so the pane must not present the buffer as the
    /// complete history. Absent (deserialized as `false`) on daemons that
    /// predate the field.
    #[serde(default)]
    pub incomplete: bool,
}

/// Mirror of `zeroclaw_runtime::rpc::types::LogsGetResult`. Full log
/// event payload returned by the lazy-load `logs/get` RPC.
#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct LogsGetResult {
    pub event: serde_json::Value,
}

#[cfg(test)]
mod logs_query_tests {
    use super::LogsQueryResult;

    #[test]
    fn older_response_without_log_path_remains_compatible() {
        let result: LogsQueryResult = serde_json::from_value(serde_json::json!({
            "events": [],
            "next_cursor": null,
            "next_cursor_line_offset": null,
            "at_end": true
        }))
        .expect("older logs/query response");

        assert!(result.log_path.is_none());
    }
}

// ── Session / Agents types ───────────────────────────────────────

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionNewResult {
    pub session_id: String,
    #[serde(default)]
    pub message_count: usize,
    #[serde(default)]
    pub workspace_dir: Option<String>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionCancelResult {}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionStateResult {
    pub state: String,
    #[serde(default)]
    pub turn_id: Option<String>,
    /// `Some(empty)` is an authoritative cleared plan. `None` keeps
    /// compatibility with older daemons that do not expose plan state.
    #[serde(default)]
    pub plan: Option<Vec<crate::wire::PlanEntry>>,
}

/// Session-scoped overrides mirror of
/// `zeroclaw_runtime::rpc::session::SessionOverrides`. Sent on
/// `session/configure`; every field is optional and omitted when `None`.
#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionOverrides {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub model_provider: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub temperature: Option<f64>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionConfigureResult {
    #[serde(default)]
    pub overrides: SessionOverrides,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionGitBranchResult {
    #[serde(default)]
    pub branch: Option<String>,
    #[serde(default)]
    pub hash: Option<String>,
}

#[derive(Debug, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionApproveResult {}

#[derive(Debug, Clone)]
pub enum ApprovalDecision {
    AllowOnce,
    AllowAlways,
    Reject,
    RejectWithEdit { replacement: String },
}

impl ApprovalDecision {
    pub fn kind(&self) -> &'static str {
        match self {
            Self::AllowOnce => "allow_once",
            Self::AllowAlways => "allow_always",
            Self::Reject => "reject",
            Self::RejectWithEdit { .. } => "reject_with_edit",
        }
    }
}

// ── Dashboard types ──────────────────────────────────────────────

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct StatusResult {
    pub server_version: String,
    pub protocol_version: u64,
    pub active_sessions: usize,
    #[serde(default)]
    pub config_dir: Option<String>,
    #[serde(default)]
    pub config_file: Option<String>,
    #[serde(default)]
    pub config_kind: Option<String>,
    #[serde(default)]
    pub local_ipc_endpoint: Option<String>,
}

#[cfg(test)]
mod dashboard_status_tests {
    use super::*;

    #[test]
    fn status_result_decodes_runtime_context_fields() {
        let value = serde_json::json!({
            "server_version": "0.8.4",
            "protocol_version": 1,
            "active_sessions": 2,
            "config_dir": "/tmp/zeroclaw-profile",
            "config_file": "/tmp/zeroclaw-profile/config.toml",
            "config_kind": "temporary",
            "local_ipc_endpoint": "/tmp/zeroclaw-profile/data/daemon.sock",
            "shell_profile": {
                "name": "pwsh",
                "family": "powershell"
            }
        });

        let status: StatusResult = serde_json::from_value(value).unwrap();

        assert_eq!(status.config_dir.as_deref(), Some("/tmp/zeroclaw-profile"));
        assert_eq!(
            status.config_file.as_deref(),
            Some("/tmp/zeroclaw-profile/config.toml")
        );
        assert_eq!(status.config_kind.as_deref(), Some("temporary"));
        assert_eq!(
            status.local_ipc_endpoint.as_deref(),
            Some("/tmp/zeroclaw-profile/data/daemon.sock")
        );
    }

    #[test]
    fn status_result_decodes_legacy_payload_without_runtime_context() {
        let value = serde_json::json!({
            "server_version": "0.8.4",
            "protocol_version": 1,
            "active_sessions": 2
        });

        let status: StatusResult = serde_json::from_value(value).unwrap();

        assert_eq!(status.server_version, "0.8.4");
        assert_eq!(status.config_dir, None);
        assert_eq!(status.config_file, None);
        assert_eq!(status.config_kind, None);
        assert_eq!(status.local_ipc_endpoint, None);
    }
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionEntry {
    pub session_id: String,
    pub session_key: String,
    pub created_at: String,
    pub last_activity: String,
    pub message_count: usize,
    #[serde(default)]
    pub agent_alias: Option<String>,
    #[serde(default)]
    pub channel_id: Option<String>,
    #[serde(default)]
    pub name: Option<String>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionListResult {
    pub sessions: Vec<SessionEntry>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct AgentStatusEntry {
    pub alias: String,
    pub enabled: bool,
    /// Daemon-configured profile, not in-flight session telemetry.
    #[serde(default)]
    pub runtime_profile: Option<String>,
    #[serde(default)]
    pub live_sessions: usize,
    #[serde(default)]
    pub persisted_sessions: usize,
    #[serde(default)]
    pub channels: Vec<String>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct AgentsStatusResult {
    pub agents: Vec<AgentStatusEntry>,
}

#[cfg(test)]
mod runtime_profile_tests {
    use super::*;

    #[test]
    fn runtime_profile_accepts_legacy_and_current_agent_status() {
        let legacy: AgentStatusEntry = serde_json::from_value(serde_json::json!({
            "alias": "coder", "enabled": true
        }))
        .unwrap();
        assert!(legacy.runtime_profile.is_none());

        let current: AgentStatusEntry = serde_json::from_value(serde_json::json!({
            "alias": "coder", "enabled": true, "runtime_profile": "coding"
        }))
        .unwrap();
        assert_eq!(current.runtime_profile.as_deref(), Some("coding"));
    }
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct ModelStats {
    pub model: String,
    pub cost_usd: f64,
    pub total_tokens: u64,
    pub request_count: usize,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct AgentCostStats {
    pub agent_alias: String,
    pub cost_usd: f64,
    pub total_tokens: u64,
    pub request_count: usize,
}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct CostSummaryResult {
    pub session_cost_usd: f64,
    pub daily_cost_usd: f64,
    pub monthly_cost_usd: f64,
    pub total_tokens: u64,
    pub request_count: usize,
    #[serde(default)]
    pub by_model: std::collections::HashMap<String, ModelStats>,
    #[serde(default)]
    pub by_agent: std::collections::HashMap<String, AgentCostStats>,
}

/// One calendar month of organization spend (oldest first; the last entry may
/// be the partial current month).
#[derive(Debug, Clone, Default, serde::Deserialize)]
pub struct OrgMonthCost {
    #[serde(default)]
    pub cost_usd: f64,
}

/// Year-to-date billed totals for a single scope (the user, or the whole org).
#[derive(Debug, Clone, Default, serde::Deserialize)]
pub struct OrgScopeStat {
    #[serde(default)]
    pub ytd_cost_usd: f64,
    #[serde(default)]
    pub ytd_tokens: u64,
    #[serde(default)]
    pub monthly: Vec<OrgMonthCost>,
}

/// Organization-level billed snapshot returned by `cost/org`, deserialized from
/// the daemon's `org_cost.json`. Mirrors a typical billing-export cache shape
/// but is vendor-neutral here; absent on vanilla builds.
#[derive(Debug, Clone, Default, serde::Deserialize)]
pub struct OrgCost {
    #[serde(default)]
    pub year: i32,
    #[serde(default)]
    pub generated: String,
    /// Display label for the organization scope (e.g. "Acme"). Falls back to
    /// "Organization" when absent.
    #[serde(default)]
    pub org_label: Option<String>,
    #[serde(default)]
    pub personal: Option<OrgScopeStat>,
    #[serde(default)]
    pub org: Option<OrgScopeStat>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(tag = "kind", rename_all = "lowercase")]
pub enum CronSchedule {
    Cron {
        expr: String,
        #[serde(default)]
        tz: Option<String>,
    },
    At {
        at: String,
    },
    Every {
        every_ms: u64,
    },
}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct CronJobEntry {
    pub id: String,
    pub schedule: CronSchedule,
    pub command: String,
    #[serde(default)]
    pub prompt: Option<String>,
    #[serde(default)]
    pub name: Option<String>,
    #[serde(default)]
    pub agent_alias: String,
    #[serde(default)]
    pub enabled: bool,
    pub created_at: String,
    pub next_run: String,
    #[serde(default)]
    pub last_run: Option<String>,
    #[serde(default)]
    pub last_status: Option<String>,
    #[serde(default)]
    pub last_output: Option<String>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct CronListResult {
    pub jobs: Vec<CronJobEntry>,
}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct CronRunEntry {
    pub id: i64,
    pub job_id: String,
    pub started_at: String,
    pub finished_at: String,
    pub status: String,
    #[serde(default)]
    pub output: Option<String>,
    #[serde(default)]
    pub duration_ms: Option<i64>,
}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct CronRunsResult {
    pub runs: Vec<CronRunEntry>,
}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct CronTriggerResult {
    pub id: String,
    pub success: bool,
    pub output: String,
}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct MemoryEntryResult {
    pub key: String,
    pub content: String,
    pub category: String,
    pub timestamp: String,
    #[serde(default)]
    pub score: Option<f64>,
    #[serde(default)]
    pub namespace: String,
    #[serde(default)]
    pub importance: Option<f64>,
    #[serde(default)]
    pub agent_alias: Option<String>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct MemoryListResult {
    pub entries: Vec<MemoryEntryResult>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct MemorySearchResult {
    pub entries: Vec<MemoryEntryResult>,
}

/// Mirror of `zeroclaw_runtime::rpc::types::MemoryGetResult`. Full
/// memory entry payload returned by the lazy-load `memory/get` RPC.
#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct MemoryGetResult {
    pub entry: Option<MemoryEntryResult>,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct SessionMessagesResult {
    pub messages: Vec<MessageEntry>,
    /// Total projected entries for the session. With `start`, lets
    /// the Sessions pane size scrollback affordances without keeping
    /// the full history in memory.
    #[serde(default)]
    pub total: usize,
    /// Index of `messages[0]` in the full projected history.
    #[serde(default)]
    pub start: usize,
}

#[derive(Debug, Clone, Default, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct MessageEntry {
    pub role: String,
    pub content: String,
    #[serde(default)]
    pub kind: MessageEntryKind,
    #[serde(default)]
    pub tool_call_id: Option<String>,
    #[serde(default)]
    pub tool_name: Option<String>,
    #[serde(default)]
    pub tool_input: Option<serde_json::Value>,
    #[serde(default)]
    pub tool_output: Option<String>,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MessageEntryKind {
    #[default]
    Message,
    ToolCall,
    ToolResult,
    #[serde(other)]
    Unknown,
}

#[cfg(test)]
mod message_entry_kind_tests {
    use super::*;

    #[test]
    fn unknown_message_entry_kind_remains_readable() {
        let entry: MessageEntry = serde_json::from_value(serde_json::json!({
            "role": "assistant",
            "content": "future entry",
            "kind": "future_kind"
        }))
        .expect("unknown additive kind should remain readable");

        assert_eq!(entry.kind, MessageEntryKind::Unknown);
    }
}

impl MessageEntry {
    /// Classify the wire `role` string into the closed set the UI renders.
    /// Unknown roles map to [`MessageRole::Other`] so surfaces can fall back
    /// without string-matching at the call site.
    pub fn role(&self) -> MessageRole {
        MessageRole::from_wire(&self.role)
    }
}

/// Closed taxonomy of persisted message roles, as they arrive over the
/// `session/messages` wire. The daemon emits these as strings; this is the
/// single place that maps the wire form into a type the UI matches on.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MessageRole {
    User,
    Assistant,
    System,
    Other,
}

impl MessageRole {
    fn from_wire(role: &str) -> Self {
        match role {
            "user" => Self::User,
            "assistant" => Self::Assistant,
            "system" => Self::System,
            _ => Self::Other,
        }
    }
}

// ── TUI identity types ───────────────────────────────────────────

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct TuiListEntry {
    pub tui_id: String,
    pub connected_at_unix: i64,
    pub peer_label: String,
    /// Transport protocol: `"unix"` or `"wss"`.
    #[serde(default)]
    pub transport: String,
}

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub struct TuiListResult {
    pub tuis: Vec<TuiListEntry>,
}

#[cfg(test)]
mod sop_method_tests {
    use super::*;
    use serde_json::json;
    use tokio::sync::mpsc;

    fn make_rpc() -> (Arc<RpcOutbound>, mpsc::Receiver<String>) {
        let (tx, rx) = mpsc::channel::<String>(16);
        (Arc::new(RpcOutbound::new(tx)), rx)
    }

    /// Wire fixture mirrored by `sop::graph` serialization tests in
    /// zeroclaw-runtime. If this shape drifts, fix both sides together.
    fn graph_fixture() -> serde_json::Value {
        json!({
            "nodes": [
                {
                    "step": 1_000_000,
                    "title": "manual",
                    "kind": "trigger",
                    "subtitle": "manual",
                    "trigger_index": 0,
                    "inputs": [],
                    "outputs": [
                        {"class": "flow", "name": "event", "required": false}
                    ]
                },
                {
                    "step": 1,
                    "title": "First",
                    "kind": "step",
                    "inputs": [
                        {"class": "flow", "name": "in", "required": false},
                        {"class": "data", "name": "input", "data_type": "object", "required": true}
                    ],
                    "outputs": [
                        {"class": "flow", "name": "pr", "required": false}
                    ]
                }
            ],
            "wires": [
                {"class": "flow", "from_step": 1_000_000, "to_step": 1, "flow_role": "trigger", "from_pin": "event"},
                {"class": "flow", "from_step": 1, "to_step": 1, "flow_role": "switch", "from_pin": "pr"}
            ],
            "diagnostics": [
                {"severity": "error", "step": 1, "message": "required input `input` has no upstream producer of a compatible type"}
            ],
            "layout": {
                "positions": [
                    {"step": 1, "col": 1, "row": 0},
                    {"step": 1_000_000, "col": 0, "row": 0}
                ],
                "columns": 2,
                "rows": 1
            }
        })
    }

    #[test]
    fn graph_view_parses_runtime_wire_shape() {
        let view: SopGraphView = serde_json::from_value(graph_fixture()).unwrap();

        assert_eq!(view.nodes.len(), 2);
        let trigger = &view.nodes[0];
        assert_eq!(trigger.kind, NodeKind::Trigger);
        assert_eq!(trigger.trigger_index, Some(0));
        assert_eq!(trigger.outputs[0].class, PinClass::Flow);

        let step = &view.nodes[1];
        assert_eq!(step.kind, NodeKind::Step);
        assert_eq!(step.inputs[1].class, PinClass::Data);
        assert_eq!(step.inputs[1].data_type.as_deref(), Some("object"));
        assert!(step.inputs[1].required);

        assert_eq!(view.wires[0].flow_role, Some(FlowRole::Trigger));
        assert_eq!(view.wires[1].flow_role, Some(FlowRole::Switch));
        assert_eq!(view.wires[1].from_pin.as_deref(), Some("pr"));
        assert_eq!(view.diagnostics[0].severity, GraphSeverity::Error);
        assert_eq!(view.layout.columns, 2);
    }

    #[test]
    fn graph_view_roundtrips_without_shape_loss() {
        let view: SopGraphView = serde_json::from_value(graph_fixture()).unwrap();
        let reparsed: SopGraphView =
            serde_json::from_value(serde_json::to_value(&view).unwrap()).unwrap();
        assert_eq!(view, reparsed);
    }

    /// Pins the planned-call wire shape against runtime `PlannedToolCall`
    /// (`sop::types`). The editor-local `calls_buf` must never leak onto
    /// the wire.
    #[test]
    fn step_calls_serialize_to_canonical_wire() {
        let step = SopStep {
            number: 2,
            title: "compute".into(),
            body: "b".into(),
            calls: vec![PlannedToolCall {
                tool: "calculator".into(),
                args: json!({"function": "add", "values": "{{steps.1.value}}"}),
                pinned: Some(json!({"value": 3})),
            }],
            calls_buf: Some("editor scratch".into()),
            ..SopStep::default()
        };
        let value = serde_json::to_value(&step).unwrap();
        assert_eq!(
            value["calls"],
            json!([{
                "tool": "calculator",
                "args": {"function": "add", "values": "{{steps.1.value}}"},
                "pinned": {"value": 3}
            }])
        );
        assert!(
            value.get("calls_buf").is_none(),
            "calls_buf must not hit the wire"
        );

        let reparsed: SopStep = serde_json::from_value(value).unwrap();
        assert_eq!(reparsed.calls, step.calls);
        assert!(reparsed.calls_buf.is_none());
    }

    #[test]
    fn trigger_registry_view_parses_runtime_wire_shape() {
        let view: TriggerSourceRegistryView = serde_json::from_value(json!({
            "sources": ["webhook", "filesystem", "channel", "manual"],
            "bound": [
                {"source": "webhook", "fields": [{"name": "path", "kind": "text"}]},
                {"source": "filesystem", "fields": [
                    {"name": "path", "kind": "text"},
                    {"name": "events", "options": ["created", "modified", "deleted", "renamed"], "multi": true, "kind": "list"},
                    {"name": "condition", "kind": "expression"}
                ]},
                {"source": "manual", "fields": []}
            ],
            "channels": [
                {
                    "channel": "telegram",
                    "aliases": [{"alias": "prod", "enabled": true, "owning_agent": "main"}],
                    "configured": true,
                    "setup_path": "/config/channels/telegram"
                }
            ]
        }))
        .unwrap();

        assert!(
            !view.sources.is_empty(),
            "backend sources walk must survive deserialization so zerocode \
             renders the picker from it without reconstructing"
        );
        assert_eq!(view.bound.len(), 3);
        let fs = &view.bound[1];
        assert_eq!(fs.fields[1].kind, TriggerFieldKindView::List);
        assert!(fs.fields[1].multi);
        assert_eq!(fs.fields[2].kind, TriggerFieldKindView::Expression);
        assert!(view.channels[0].configured);
        assert_eq!(
            view.channels[0].aliases[0].owning_agent.as_deref(),
            Some("main")
        );
    }

    #[tokio::test]
    async fn sops_graph_view_sends_name_and_parses_result() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task = tokio::spawn(async move { client.sops_graph_view("deploy").await });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.sops_graph_view must send a wire request")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "sops/graph");
        assert_eq!(req["params"]["name"], "deploy");

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(&id, Some(graph_fixture()), None);

        let view = tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.sops_graph_view must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
        assert_eq!(view.nodes.len(), 2);
    }

    #[tokio::test]
    async fn sops_runs_sends_filter_and_parses_summaries() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task = tokio::spawn(async move { client.sops_runs(Some("deploy")).await });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.sops_runs must send a wire request")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "sops/runs");
        assert_eq!(req["params"]["sop"], "deploy");

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(
            &id,
            Some(json!({
                "runs": [
                    {
                        "run_id": "run-1",
                        "sop_name": "deploy",
                        "status": "waiting_approval",
                        "current_step": 2,
                        "total_steps": 5,
                        "started_at": "2026-08-02T00:00:00Z",
                        "completed_at": null,
                        "trigger_source": "manual",
                        "active": true
                    },
                    {
                        "run_id": "run-0",
                        "sop_name": "deploy",
                        "status": "some_future_status",
                        "current_step": 5,
                        "total_steps": 5,
                        "started_at": "2026-08-01T00:00:00Z",
                        "completed_at": "2026-08-01T00:05:00Z",
                        "trigger_source": "cron",
                        "active": false,
                        "some_future_field": {"nested": true}
                    }
                ]
            })),
            None,
        );

        let runs = tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.sops_runs must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
        assert_eq!(runs.len(), 2);
        assert_eq!(runs[0].status, SopRunStatusView::WaitingApproval);
        assert!(runs[0].status.needs_input());
        assert!(runs[0].active);
        assert_eq!(
            runs[1].status,
            SopRunStatusView::Unknown,
            "a status from a newer daemon must fold to Unknown, not fail the whole list"
        );
        assert!(!runs[1].status.is_terminal());
    }

    #[tokio::test]
    async fn sops_runs_unfiltered_sends_null_and_requires_runs_key() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task = tokio::spawn(async move { client.sops_runs(None).await });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.sops_runs must send a wire request")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "sops/runs");
        assert_eq!(req["params"]["sop"], serde_json::Value::Null);

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(&id, Some(json!({"not_runs": []})), None);

        let err = tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.sops_runs must resolve after the response is dispatched")
            .unwrap()
            .expect_err("a response without `runs` must error, not silently return empty");
        assert!(err.to_string().contains("missing runs"));
    }

    #[tokio::test]
    async fn sops_runs_tolerates_omissions_but_still_fails_closed_on_bad_shapes() {
        // The three cases the doc comment on `sops_runs` promises to tolerate
        // and to reject. A regression here means the compatibility claim on
        // the method has drifted from what serde actually does.
        async fn call_with(runs: serde_json::Value) -> anyhow::Result<Vec<SopRunSummaryView>> {
            let (rpc, mut write_rx) = make_rpc();
            let client = RpcClient::with_rpc(rpc.clone());
            let task = tokio::spawn(async move { client.sops_runs(None).await });
            let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
                .await
                .expect("client.sops_runs must send a wire request")
                .unwrap();
            let req: serde_json::Value = serde_json::from_str(&line).unwrap();
            let id = req["id"].as_str().unwrap().to_string();
            rpc.dispatch_response(&id, Some(json!({ "runs": runs })), None);
            tokio::time::timeout(std::time::Duration::from_secs(2), task)
                .await
                .expect("client.sops_runs must resolve after the response is dispatched")
                .unwrap()
        }

        // Tolerated: every field omitted, plus an unknown status string.
        let runs = call_with(json!([{ "status": "invented_by_a_newer_daemon" }]))
            .await
            .expect("omitted fields and an unknown status must deserialize, not fail the list");
        assert_eq!(runs.len(), 1);
        assert_eq!(runs[0].status, SopRunStatusView::Unknown);
        assert_eq!(runs[0].run_id, "");
        assert!(!runs[0].active);

        // Fails closed: a field whose JSON type changed.
        let err = call_with(json!([{ "run_id": "r1", "current_step": "not-a-number" }]))
            .await
            .expect_err("an incompatible field type must fail closed, not default silently");
        assert!(
            err.to_string().contains("current_step")
                || err.to_string().contains("invalid type")
                || err.to_string().contains("expected"),
            "error should name the type problem, got: {err}"
        );

        // Fails closed: `runs` present but not an array.
        let err = call_with(json!({ "unexpected": "container" }))
            .await
            .expect_err("a malformed runs container must fail closed");
        assert!(
            err.to_string().contains("invalid type") || err.to_string().contains("expected"),
            "error should name the container problem, got: {err}"
        );
    }

    #[tokio::test]
    async fn sops_wire_draft_sends_sop_and_edit_envelopes() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let sop = json!({"name": "deploy", "steps": []});
        let edit = json!({"op": "connect", "from": 1, "to": 2, "role": "sequence"});
        let task = {
            let (sop, edit) = (sop.clone(), edit.clone());
            tokio::spawn(async move { client.sops_wire_draft(sop, edit).await })
        };

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.sops_wire_draft must send a wire request")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "sops/wire-draft");
        assert_eq!(req["params"]["sop"], sop);
        assert_eq!(req["params"]["edit"], edit);

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(&id, Some(json!({"sop": {"name": "deploy"}})), None);
        tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.sops_wire_draft must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
    }
}

#[cfg(test)]
mod session_method_tests {
    use super::*;
    use serde_json::json;
    use tokio::sync::mpsc;

    fn make_rpc() -> (Arc<RpcOutbound>, mpsc::Receiver<String>) {
        let (tx, rx) = mpsc::channel::<String>(16);
        (Arc::new(RpcOutbound::new(tx)), rx)
    }

    #[tokio::test]
    async fn session_new_sends_correct_wire_params() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task =
            tokio::spawn(async move { client.session_new("my-agent", Some("/tmp/work")).await });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.session_new must send a wire request; a hang here wedges the TTY")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "session/new");
        assert_eq!(req["params"]["agent_alias"], "my-agent");
        assert_eq!(req["params"]["cwd"], "/tmp/work");

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(
            &id,
            Some(json!({"session_id":"s42","agent_alias":"my-agent","message_count":0})),
            None,
        );

        let result = tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.session_new must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
        assert_eq!(result.session_id, "s42");
    }

    #[tokio::test]
    async fn session_new_acp_declares_closed_zerocode_code_surface() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task = tokio::spawn(async move {
            client
                .session_new_acp("my-agent", Some("/tmp/work"), Some("s-acp"))
                .await
        });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.session_new_acp must send a wire request")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "session/new");
        assert_eq!(req["params"]["chat_mode"], "acp");
        assert_eq!(req["params"]["interaction_surface"], "zerocode_code");
        assert!(
            req["params"].get("interaction_context").is_none(),
            "ZeroCode must not send prompt prose or capability claims"
        );

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(
            &id,
            Some(json!({"session_id":"s-acp","workspace_dir":"/tmp/work"})),
            None,
        );
        tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.session_new_acp must resolve")
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn session_cancel_sends_session_id() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task = tokio::spawn(async move { client.session_cancel("s1").await });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.session_cancel must send a wire request; a hang here wedges the TTY")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "session/cancel");
        assert_eq!(req["params"]["session_id"], "s1");

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(&id, Some(json!({"session_id":"s1","cancelled":true})), None);
        tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.session_cancel must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn session_state_sends_session_id_and_returns_lifecycle() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task = tokio::spawn(async move { client.session_state("s1").await });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.session_state must send a wire request")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "session/state");
        assert_eq!(req["params"]["session_id"], "s1");

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(
            &id,
            Some(json!({"session_id":"s1","state":"running"})),
            None,
        );
        let result = tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.session_state must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
        assert_eq!(result.state, "running");
    }

    #[tokio::test]
    async fn cron_runs_sends_job_id_and_limit() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task = tokio::spawn(async move { client.cron_runs("job-1", Some(3)).await });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.cron_runs must send a wire request; a hang here wedges the TTY")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "cron/runs");
        assert_eq!(req["params"]["id"], "job-1");
        assert_eq!(req["params"]["limit"], 3);

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(
            &id,
            Some(json!({
                "runs": [{
                    "id": 7,
                    "job_id": "job-1",
                    "started_at": "2026-06-18T00:00:00Z",
                    "finished_at": "2026-06-18T00:00:02Z",
                    "status": "ok",
                    "output": "done",
                    "duration_ms": 2000
                }]
            })),
            None,
        );

        let result = tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.cron_runs must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
        assert_eq!(result.runs.len(), 1);
        assert_eq!(result.runs[0].job_id, "job-1");
        assert_eq!(result.runs[0].duration_ms, Some(2000));
    }

    #[tokio::test]
    async fn cron_trigger_sends_job_id() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task = tokio::spawn(async move { client.cron_trigger("job-1").await });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.cron_trigger must send a wire request; a hang here wedges the TTY")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "cron/trigger");
        assert_eq!(req["params"]["id"], "job-1");

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(
            &id,
            Some(json!({"id": "job-1", "success": true, "output": "done"})),
            None,
        );

        let result = tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.cron_trigger must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
        assert_eq!(result.id, "job-1");
        assert!(result.success);
        assert_eq!(result.output, "done");
    }

    #[tokio::test]
    async fn session_approve_sends_decision_and_request_id() {
        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task = tokio::spawn(async move {
            client
                .session_approve("s1", "req-1", ApprovalDecision::AllowOnce)
                .await
        });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.session_approve must send a wire request; a hang here wedges the TTY")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "session/approve");
        assert_eq!(req["params"]["decision"], "allow_once");
        assert_eq!(req["params"]["request_id"], "req-1");

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(
            &id,
            Some(json!({"session_id":"s1","request_id":"req-1","acknowledged":true})),
            None,
        );
        tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.session_approve must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn config_map_key_rename_sends_path_and_aliases() {
        assert_eq!(CONFIG_RENAME_TIMEOUT, std::time::Duration::from_secs(120));

        let (rpc, mut write_rx) = make_rpc();
        let client = RpcClient::with_rpc(rpc.clone());

        let task =
            tokio::spawn(async move { client.config_map_key_rename("agents", "old", "new").await });

        let line = tokio::time::timeout(std::time::Duration::from_secs(2), write_rx.recv())
            .await
            .expect("client.config_map_key_rename must send a wire request")
            .unwrap();
        let req: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(req["method"], "config/map-key-rename");
        assert_eq!(req["params"]["path"], "agents");
        assert_eq!(req["params"]["from"], "old");
        assert_eq!(req["params"]["to"], "new");

        let id = req["id"].as_str().unwrap().to_string();
        rpc.dispatch_response(
            &id,
            Some(json!({
                "path": "agents",
                "from": "old",
                "to": "new",
                "renamed": true,
                "warnings": ["workspace move skipped"]
            })),
            None,
        );

        let result = tokio::time::timeout(std::time::Duration::from_secs(2), task)
            .await
            .expect("client.config_map_key_rename must resolve after the response is dispatched")
            .unwrap()
            .unwrap();
        assert!(result.renamed);
        assert_eq!(result.warnings, vec!["workspace move skipped"]);
    }
}

#[cfg(test)]
mod notification_tests {
    use super::*;
    use tokio::sync::{broadcast, mpsc};

    /// Channels handed back by [`route_fixture`]. Aliased to keep the
    /// return type readable (clippy::type_complexity).
    type RouteFixture = (
        Arc<RpcOutbound>,
        broadcast::Sender<RpcNotification>,
        broadcast::Receiver<RpcNotification>,
        mpsc::UnboundedSender<RpcInboundRequest>,
        mpsc::UnboundedReceiver<RpcInboundRequest>,
        mpsc::Receiver<String>,
    );

    /// Build a fresh fixture for routing tests. The writer receiver is
    /// returned (not dropped) so `RpcOutbound`'s writer channel stays
    /// open — dropping it would make every `request`/`respond` fail with
    /// "Writer task closed".
    fn route_fixture() -> RouteFixture {
        let (writer_tx, writer_rx) = mpsc::channel::<String>(16);
        let rpc = Arc::new(RpcOutbound::new(writer_tx));
        let (notif_tx, notif_rx) = broadcast::channel::<RpcNotification>(16);
        let (inbound_tx, inbound_rx) = mpsc::unbounded_channel::<RpcInboundRequest>();
        (rpc, notif_tx, notif_rx, inbound_tx, inbound_rx, writer_rx)
    }

    #[tokio::test]
    async fn rtg_9739_delayed_wss_request_is_cancelled_after_quiesce_cut() {
        use futures_util::{SinkExt, StreamExt};
        use tokio_tungstenite::{
            MaybeTlsStream, WebSocketStream,
            tungstenite::{Message, protocol::Role},
        };

        let (client_io, server_io) = tokio::io::duplex(64 * 1024);
        let release_request = Arc::new(Notify::new());
        let server_release = Arc::clone(&release_request);
        let server = tokio::spawn(async move {
            let mut ws = WebSocketStream::from_raw_socket(server_io, Role::Server, None).await;
            let initialize = ws.next().await.unwrap().unwrap();
            let Message::Text(initialize) = initialize else {
                panic!("client must initialize with a text frame");
            };
            let initialize: Value = serde_json::from_str(initialize.as_str()).unwrap();
            ws.send(Message::Text(
                serde_json::json!({
                    "jsonrpc": "2.0",
                    "id": initialize["id"],
                    "result": {
                        "server_version": env!("CARGO_PKG_VERSION"),
                        "commands": []
                    }
                })
                .to_string()
                .into(),
            ))
            .await
            .unwrap();

            server_release.notified().await;
            ws.send(Message::Text(
                serde_json::json!({
                    "jsonrpc": "2.0",
                    "id": "delayed-during-quiesce",
                    "method": "elicitation/create",
                    "params": { "sessionId": "retiring-session" }
                })
                .to_string()
                .into(),
            ))
            .await
            .unwrap();

            let response = loop {
                let message = tokio::time::timeout(Duration::from_secs(1), ws.next())
                    .await
                    .expect("retired reader must answer the delayed request")
                    .expect("client transport remains open")
                    .unwrap();
                if let Message::Text(response) = message {
                    break serde_json::from_str::<Value>(response.as_str()).unwrap();
                }
            };
            assert!(
                tokio::time::timeout(Duration::from_millis(50), ws.next())
                    .await
                    .is_err(),
                "retired WSS request must be answered exactly once"
            );
            response
        });

        let client_ws =
            WebSocketStream::from_raw_socket(MaybeTlsStream::Plain(client_io), Role::Client, None)
                .await;
        let client = Arc::new(
            RpcClient::spawn_ws_session(client_ws, None, None, None, None, None)
                .await
                .unwrap(),
        );
        let mut inbound_requests = client.take_inbound_requests().unwrap();
        client.quiesce_inbound_reader().await;
        assert!(inbound_requests.recv().await.is_none());

        release_request.notify_one();
        let response = server.await.unwrap();
        assert_eq!(response["id"], "delayed-during-quiesce");
        assert_eq!(response["result"]["action"], "cancel");
        client.shutdown();
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn rtg_9739_local_request_is_cancelled_after_quiesce_cut() {
        let dir = tempfile::tempdir().unwrap();
        let socket = dir.path().join("rpc.sock");
        let listener = tokio::net::UnixListener::bind(&socket).unwrap();
        let release_request = Arc::new(Notify::new());
        let server_release = Arc::clone(&release_request);
        let server = tokio::spawn(async move {
            let (stream, _) = listener.accept().await.unwrap();
            let (read_half, mut write_half) = tokio::io::split(stream);
            let mut lines = BufReader::new(read_half).lines();
            let initialize = lines.next_line().await.unwrap().unwrap();
            let initialize: Value = serde_json::from_str(&initialize).unwrap();
            write_half
                .write_all(
                    format!(
                        "{}\n",
                        serde_json::json!({
                            "jsonrpc": "2.0",
                            "id": initialize["id"],
                            "result": {
                                "server_version": env!("CARGO_PKG_VERSION"),
                                "commands": []
                            }
                        })
                    )
                    .as_bytes(),
                )
                .await
                .unwrap();

            server_release.notified().await;
            write_half
                .write_all(
                    format!(
                        "{}\n",
                        serde_json::json!({
                            "jsonrpc": "2.0",
                            "id": "local-during-quiesce",
                            "method": "elicitation/create",
                            "params": { "sessionId": "retiring-session" }
                        })
                    )
                    .as_bytes(),
                )
                .await
                .unwrap();

            let response = tokio::time::timeout(Duration::from_secs(1), lines.next_line())
                .await
                .expect("retired local reader must answer the delayed request")
                .unwrap()
                .expect("client transport remains open");
            let response = serde_json::from_str::<Value>(&response).unwrap();
            assert!(
                tokio::time::timeout(Duration::from_millis(50), lines.next_line())
                    .await
                    .is_err(),
                "retired local request must be answered exactly once"
            );
            response
        });

        let client = Arc::new(RpcClient::connect(&socket, None, None).await.unwrap());
        let mut inbound_requests = client.take_inbound_requests().unwrap();
        client.quiesce_inbound_reader().await;
        assert!(inbound_requests.recv().await.is_none());

        release_request.notify_one();
        let response = server.await.unwrap();
        assert_eq!(response["id"], "local-during-quiesce");
        assert_eq!(response["result"]["action"], "cancel");
        client.shutdown();
    }

    /// Response frames — id + result/error, no method — should reach the
    /// pending outbound call via `dispatch_response` and emit nothing on
    /// the notification / inbound channels.
    #[tokio::test]
    async fn route_inbound_frame_routes_response_to_pending_call() {
        let (rpc, notif_tx, mut notif_rx, inbound_tx, mut inbound_rx, mut writer_rx) =
            route_fixture();
        // Register a pending outbound call so dispatch_response has a target.
        let call_task = {
            let rpc = Arc::clone(&rpc);
            tokio::spawn(async move { rpc.request("ping", serde_json::Value::Null).await })
        };
        // Drain the one outbound frame the request writes so the spawned
        // task makes progress and registers its pending id (`zc-out-0`,
        // the first id from a fresh RpcOutbound).
        let _outbound = writer_rx.recv().await.expect("request wrote a frame");
        let frame = serde_json::json!({
            "jsonrpc": "2.0",
            "id": "zc-out-0",
            "result": { "pong": true }
        });
        assert!(route_inbound_frame(&rpc, &notif_tx, Some(&inbound_tx), frame).is_none());

        let answer = call_task.await.unwrap().unwrap();
        assert_eq!(answer["pong"], true);
        assert!(inbound_rx.try_recv().is_err(), "inbound rx must stay empty");
        assert!(notif_rx.try_recv().is_err(), "notif rx must stay empty");
    }

    #[tokio::test]
    async fn inbound_response_batch_registration_precedes_flush_marker() {
        let (writer_tx, mut writer_rx) = mpsc::channel::<jsonrpc::OutboundMessage>(3);
        let rpc = Arc::new(RpcOutbound::new_transport(writer_tx));
        let client = Arc::new(RpcClient::with_rpc(rpc));
        client.respond_to_inbound_requests(vec![
            (
                serde_json::json!("elicitation-1"),
                Ok(serde_json::json!({ "action": "cancel" })),
            ),
            (
                serde_json::json!("elicitation-2"),
                Ok(serde_json::json!({ "action": "cancel" })),
            ),
        ]);

        let writer = tokio::spawn(async move {
            for expected_id in ["elicitation-1", "elicitation-2"] {
                let response = writer_rx.recv().await.expect("response frame");
                let jsonrpc::OutboundMessage::Frame(frame) = response else {
                    panic!("flush overtook the registered response batch");
                };
                let response: Value = serde_json::from_str(&frame).expect("valid response");
                assert_eq!(response["id"], expected_id);
            }

            let flush = writer_rx.recv().await.expect("flush marker");
            let jsonrpc::OutboundMessage::Flush(ack) = flush else {
                panic!("response batch must be followed by one flush marker");
            };
            let _ = ack.send(());
        });

        assert!(
            client
                .flush_outbound_with_timeout(Duration::from_secs(1))
                .await
        );
        writer.await.unwrap();
    }

    #[tokio::test]
    async fn pending_inbound_response_is_bounded_when_writer_queue_is_full() {
        let (writer_tx, writer_rx) = mpsc::channel::<jsonrpc::OutboundMessage>(1);
        let rpc = Arc::new(RpcOutbound::new_transport(writer_tx));
        let client = RpcClient::with_rpc(Arc::clone(&rpc));
        assert!(rpc.send_raw("occupied".to_string()).await);
        client.respond_to_inbound_request(
            serde_json::json!("elicitation-2"),
            Ok(serde_json::json!({ "action": "cancel" })),
        );

        assert!(
            !client
                .flush_outbound_with_timeout(Duration::from_millis(20))
                .await,
            "a response blocked on writer capacity must share the retirement budget"
        );

        drop(writer_rx);
        tokio::task::yield_now().await;
    }

    #[tokio::test]
    async fn flush_outbound_waits_for_delayed_writer_before_shutdown() {
        let (writer_tx, mut writer_rx) = mpsc::channel::<jsonrpc::OutboundMessage>(4);
        let rpc = Arc::new(RpcOutbound::new_transport(writer_tx));
        let delivered = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let delivered_by_writer = Arc::clone(&delivered);
        let writer = tokio::spawn(async move {
            while let Some(message) = writer_rx.recv().await {
                match message {
                    jsonrpc::OutboundMessage::Frame(_) => {
                        tokio::time::sleep(Duration::from_millis(25)).await;
                        delivered_by_writer.store(true, std::sync::atomic::Ordering::Release);
                    }
                    jsonrpc::OutboundMessage::Flush(ack) => {
                        let _ = ack.send(());
                    }
                }
            }
        });
        let mut client = RpcClient::with_rpc(Arc::clone(&rpc));
        client.writer_task = Some(writer);

        assert!(rpc.send_raw("terminal response".to_string()).await);
        assert!(client.flush_outbound().await);
        assert!(
            delivered.load(std::sync::atomic::Ordering::Acquire),
            "flush must wait for the delayed frame before the writer is retired"
        );
        client.shutdown();
    }

    #[tokio::test]
    async fn relayed_wss_flush_waits_for_outer_delivery_before_shutdown() {
        use futures_util::{SinkExt, StreamExt};
        use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        use tokio_tungstenite::{
            MaybeTlsStream, WebSocketStream,
            tungstenite::{Message, protocol::Role},
        };

        // Model the relayed transport as two byte streams joined by an outer
        // pump. Once initialization finishes, hold client-to-server delivery so
        // the inner WSS writer can finish while the daemon still has no bytes.
        let (client_io, pump_client_io) = tokio::io::duplex(128 * 1024);
        let (pump_server_io, server_io) = tokio::io::duplex(128 * 1024);
        let hold_outbound = Arc::new(AtomicBool::new(false));
        let release_outbound = Arc::new(tokio::sync::Notify::new());
        let pump_hold = Arc::clone(&hold_outbound);
        let pump_release = Arc::clone(&release_outbound);
        let pump = tokio::spawn(async move {
            let (mut client_read, mut client_write) = tokio::io::split(pump_client_io);
            let (mut server_read, mut server_write) = tokio::io::split(pump_server_io);
            let client_to_server = async move {
                let mut buf = vec![0_u8; 16 * 1024];
                loop {
                    let n = client_read.read(&mut buf).await?;
                    if n == 0 {
                        break;
                    }
                    if pump_hold.load(Ordering::Acquire) {
                        pump_release.notified().await;
                        pump_hold.store(false, Ordering::Release);
                    }
                    server_write.write_all(&buf[..n]).await?;
                }
                std::io::Result::Ok(())
            };
            let server_to_client = async move {
                tokio::io::copy(&mut server_read, &mut client_write).await?;
                std::io::Result::Ok(())
            };
            let _ = tokio::join!(client_to_server, server_to_client);
        });

        let delivered = Arc::new(AtomicUsize::new(0));
        let server_delivered = Arc::clone(&delivered);
        let server = tokio::spawn(async move {
            let mut ws = WebSocketStream::from_raw_socket(server_io, Role::Server, None).await;
            while let Some(Ok(message)) = ws.next().await {
                match message {
                    Message::Text(text) => {
                        let frame: Value = serde_json::from_str(text.as_str()).unwrap();
                        if frame["method"] == "initialize" {
                            ws.send(Message::Text(
                                serde_json::json!({
                                    "jsonrpc": "2.0",
                                    "id": frame["id"],
                                    "result": {
                                        "server_version": env!("CARGO_PKG_VERSION"),
                                        "commands": []
                                    }
                                })
                                .to_string()
                                .into(),
                            ))
                            .await
                            .unwrap();
                        } else if frame["id"] == "elicitation-relay" {
                            server_delivered.fetch_add(1, Ordering::AcqRel);
                        }
                    }
                    Message::Ping(payload) => {
                        ws.send(Message::Pong(b"unrelated-pong".to_vec().into()))
                            .await
                            .unwrap();
                        ws.send(Message::Pong(payload)).await.unwrap();
                    }
                    Message::Close(_) => break,
                    _ => {}
                }
            }
        });

        let client_ws =
            WebSocketStream::from_raw_socket(MaybeTlsStream::Plain(client_io), Role::Client, None)
                .await;
        let client = Arc::new(
            RpcClient::spawn_ws_session(client_ws, None, None, None, None, Some(pump))
                .await
                .unwrap(),
        );
        let mut inbound_requests = client.take_inbound_requests().unwrap();
        hold_outbound.store(true, Ordering::Release);
        client.respond_to_inbound_request(
            serde_json::json!("elicitation-relay"),
            Ok(serde_json::json!({ "action": "cancel" })),
        );

        client.quiesce_inbound_reader().await;
        assert!(
            tokio::time::timeout(Duration::from_secs(1), inbound_requests.recv())
                .await
                .is_ok_and(|request| request.is_none()),
            "quiesce must close the inbound queue so router draining terminates"
        );
        Arc::clone(&client).retire_after_outbound_flush_with_timeout(Duration::from_secs(1));
        tokio::task::yield_now().await;
        assert_eq!(delivered.load(Ordering::Acquire), 0);
        assert!(
            !client.writer_task.as_ref().unwrap().is_finished(),
            "retirement must keep the WSS writer alive before outer delivery"
        );
        assert_eq!(
            client.relay_pump_finished(),
            Some(false),
            "retirement must keep the relay pump alive before outer delivery"
        );

        release_outbound.notify_one();
        tokio::time::timeout(Duration::from_secs(1), async {
            while delivered.load(Ordering::Acquire) != 1
                || !client.writer_task.as_ref().unwrap().is_finished()
                || client.relay_pump_finished() != Some(true)
            {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("retirement should deliver once and reclaim the relayed WSS transport");

        server.abort();
    }

    #[tokio::test]
    async fn flush_outbound_times_out_when_writer_is_stalled() {
        let (writer_tx, _writer_rx) = mpsc::channel::<jsonrpc::OutboundMessage>(1);
        let rpc = Arc::new(RpcOutbound::new_transport(writer_tx));
        let client = RpcClient::with_rpc(rpc);

        assert!(
            !client
                .flush_outbound_with_timeout(Duration::from_millis(20))
                .await,
            "a stalled writer must not strand reconnect adoption"
        );
    }

    #[tokio::test]
    async fn retirement_keeps_timed_out_writer_alive_until_terminal_frame_drains() {
        let (writer_tx, mut writer_rx) = mpsc::channel::<jsonrpc::OutboundMessage>(4);
        let rpc = Arc::new(RpcOutbound::new_transport(writer_tx));
        let release = Arc::new(tokio::sync::Notify::new());
        let release_writer = Arc::clone(&release);
        let delivered = Arc::new(AtomicUsize::new(0));
        let delivered_writer = Arc::clone(&delivered);
        let writer = tokio::spawn(async move {
            while let Some(message) = writer_rx.recv().await {
                match message {
                    jsonrpc::OutboundMessage::Frame(frame) => {
                        release_writer.notified().await;
                        let response: Value = serde_json::from_str(&frame).expect("valid response");
                        assert_eq!(response["id"], "elicitation-retiring");
                        delivered_writer.fetch_add(1, Ordering::AcqRel);
                    }
                    jsonrpc::OutboundMessage::Flush(ack) => {
                        let _ = ack.send(());
                    }
                }
            }
        });
        let mut client = RpcClient::with_rpc(Arc::clone(&rpc));
        client.writer_task = Some(writer);
        let client = Arc::new(client);

        client.respond_to_inbound_request(
            serde_json::json!("elicitation-retiring"),
            Ok(serde_json::json!({ "action": "cancel" })),
        );
        assert!(
            !client
                .flush_outbound_with_timeout(Duration::from_millis(20))
                .await
        );
        Arc::clone(&client).retire_after_outbound_flush_with_timeout(Duration::from_secs(1));
        tokio::task::yield_now().await;
        assert!(
            !client.writer_task.as_ref().unwrap().is_finished(),
            "a missed fast flush must not abort the writer immediately"
        );

        release.notify_one();
        tokio::time::timeout(Duration::from_secs(1), async {
            while delivered.load(Ordering::Acquire) == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("terminal frame should drain during bounded retirement");
        tokio::time::timeout(Duration::from_secs(1), async {
            while !client.writer_task.as_ref().unwrap().is_finished() {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("retirement should reclaim the writer after its flush");
        assert_eq!(
            delivered.load(Ordering::Acquire),
            1,
            "retirement must deliver exactly one terminal response"
        );
    }

    #[tokio::test]
    async fn retirement_reclaims_a_permanently_stalled_writer_after_deadline() {
        let (writer_tx, mut writer_rx) = mpsc::channel::<jsonrpc::OutboundMessage>(4);
        let rpc = Arc::new(RpcOutbound::new_transport(writer_tx));
        let (blocked_tx, blocked_rx) = tokio::sync::oneshot::channel();
        let writer = tokio::spawn(async move {
            if matches!(
                writer_rx.recv().await,
                Some(jsonrpc::OutboundMessage::Frame(_))
            ) {
                let _ = blocked_tx.send(());
                std::future::pending::<()>().await;
            }
        });
        let mut client = RpcClient::with_rpc(Arc::clone(&rpc));
        client.writer_task = Some(writer);
        let client = Arc::new(client);

        assert!(rpc.send_raw("terminal response".to_string()).await);
        blocked_rx.await.expect("writer should stall on the frame");
        Arc::clone(&client).retire_after_outbound_flush_with_timeout(Duration::from_millis(20));

        tokio::time::timeout(Duration::from_secs(1), async {
            while !client.writer_task.as_ref().unwrap().is_finished() {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("retirement deadline should reclaim a permanently stalled writer");
    }

    async fn assert_disconnect_fails_pending_request(reason: &str) {
        let (rpc, _notif_tx, _notif_rx, _inbound_tx, _inbound_rx, mut writer_rx) = route_fixture();
        let call_task = {
            let rpc = Arc::clone(&rpc);
            tokio::spawn(async move { rpc.request("long-running", Value::Null).await })
        };
        writer_rx.recv().await.expect("request wrote a frame");
        assert_eq!(rpc.pending_count(), 1);

        let connection_state = Mutex::new(ConnectionState::Connected);
        disconnect_rpc(&rpc, &connection_state, reason.to_string());

        let error = call_task.await.unwrap().unwrap_err();
        assert_eq!(error.code, jsonrpc::error_codes::INTERNAL_ERROR);
        assert_eq!(error.message, format!("Connection closed: {reason}"));
        assert_eq!(rpc.pending_count(), 0);
        assert!(matches!(
            clone_connection_state(&connection_state),
            ConnectionState::Disconnected { reason: actual } if actual == reason
        ));
    }

    #[tokio::test]
    async fn local_reader_disconnect_fails_pending_request() {
        assert_disconnect_fails_pending_request("EOF (daemon closed connection)").await;
    }

    #[tokio::test]
    async fn wss_reader_disconnect_fails_pending_request() {
        assert_disconnect_fails_pending_request("EOF (WSS connection closed)").await;
    }

    #[tokio::test]
    async fn request_after_disconnect_is_rejected_without_write() {
        let (rpc, _notif_tx, _notif_rx, _inbound_tx, _inbound_rx, mut writer_rx) = route_fixture();
        let connection_state = Mutex::new(ConnectionState::Connected);
        let reason = "EOF (daemon closed connection)";
        disconnect_rpc(&rpc, &connection_state, reason.to_string());

        let error = rpc.request("too-late", Value::Null).await.unwrap_err();

        assert_eq!(error.code, jsonrpc::error_codes::INTERNAL_ERROR);
        assert_eq!(error.message, format!("Connection closed: {reason}"));
        assert_eq!(rpc.pending_count(), 0);
        assert!(
            writer_rx.try_recv().is_err(),
            "a closed transport must reject the request before writing a frame"
        );
    }

    #[tokio::test]
    async fn writer_failure_settles_admitted_and_rejects_future_request() {
        let (rpc, _notif_tx, _notif_rx, _inbound_tx, _inbound_rx, mut writer_rx) = route_fixture();
        let admitted = {
            let rpc = Arc::clone(&rpc);
            tokio::spawn(async move { rpc.request("admitted", Value::Null).await })
        };
        writer_rx
            .recv()
            .await
            .expect("admitted request wrote a frame");

        let connection_state = Mutex::new(ConnectionState::Connected);
        let reason = "broken pipe";
        disconnect_rpc(&rpc, &connection_state, reason.to_string());

        let admitted_error = admitted.await.unwrap().unwrap_err();
        let future_error = rpc.request("future", Value::Null).await.unwrap_err();
        assert_eq!(
            admitted_error.message,
            format!("Connection closed: {reason}")
        );
        assert_eq!(future_error.message, admitted_error.message);
        assert_eq!(rpc.pending_count(), 0);
        assert!(
            writer_rx.try_recv().is_err(),
            "writer failure must close admission before a future frame is queued"
        );
    }

    #[tokio::test]
    async fn weak_writer_owner_allows_receiver_to_close() {
        let (writer_tx, mut writer_rx) = mpsc::channel::<String>(1);
        let rpc = Arc::new(RpcOutbound::new(writer_tx));
        let writer_owner = Arc::downgrade(&rpc);

        drop(rpc);

        assert!(writer_owner.upgrade().is_none());
        assert!(
            writer_rx.recv().await.is_none(),
            "dropping external RPC owners must close the writer receiver"
        );
    }

    /// Notification frames — method, no id — should reach the
    /// notification broadcast and not the inbound-request channel.
    #[tokio::test]
    async fn route_inbound_frame_routes_notification() {
        let (rpc, notif_tx, mut notif_rx, inbound_tx, mut inbound_rx, _writer_rx) = route_fixture();
        let frame = serde_json::json!({
            "jsonrpc": "2.0",
            "method": "session/update",
            "params": { "type": "agent_message_chunk", "session_id": "s1", "text": "hi" }
        });
        assert!(route_inbound_frame(&rpc, &notif_tx, Some(&inbound_tx), frame).is_none());
        let notif = notif_rx.try_recv().expect("notification routed");
        assert_eq!(notif.method, "session/update");
        assert!(inbound_rx.try_recv().is_err());
    }

    /// Server-initiated request frames — both id and method — should
    /// reach the inbound-request broadcast and NOT be misclassified
    /// as a response (which would silently drop the elicitation prompt).
    #[tokio::test]
    async fn route_inbound_frame_routes_server_initiated_request() {
        let (rpc, notif_tx, mut notif_rx, inbound_tx, mut inbound_rx, _writer_rx) = route_fixture();
        let frame = serde_json::json!({
            "jsonrpc": "2.0",
            "id": "elicit-42",
            "method": "elicitation/create",
            "params": {
                "sessionId": "sess-1",
                "mode": "form",
                "message": "Pick one",
                "requestedSchema": { "type": "object", "properties": {} }
            }
        });
        assert!(route_inbound_frame(&rpc, &notif_tx, Some(&inbound_tx), frame).is_none());
        let req = inbound_rx.try_recv().expect("inbound request routed");
        assert_eq!(req.method, "elicitation/create");
        assert_eq!(req.id, serde_json::Value::String("elicit-42".to_string()));
        assert_eq!(req.params["sessionId"], "sess-1");
        assert!(notif_rx.try_recv().is_err());
    }

    #[tokio::test]
    async fn route_inbound_frame_returns_server_request_after_reader_quiesce() {
        let (rpc, notif_tx, mut notif_rx, _inbound_tx, mut inbound_rx, _writer_rx) =
            route_fixture();
        let request = route_inbound_frame(
            &rpc,
            &notif_tx,
            None,
            serde_json::json!({
                "jsonrpc": "2.0",
                "id": "too-late",
                "method": "elicitation/create",
                "params": { "sessionId": "retired-session" }
            }),
        )
        .expect("retired reader must retain the request for a terminal response");

        assert_eq!(request.id, "too-late");
        assert!(inbound_rx.try_recv().is_err());
        assert!(notif_rx.try_recv().is_err());
    }

    /// Frames with both fields but a numeric id — the JSON-RPC spec
    /// permits int ids, even though the daemon emits strings — must
    /// still route as a server-initiated request (we forward the
    /// `Value` verbatim so the response carries the same shape).
    #[tokio::test]
    async fn route_inbound_frame_handles_numeric_request_id() {
        let (rpc, notif_tx, _notif_rx, inbound_tx, mut inbound_rx, _writer_rx) = route_fixture();
        let frame = serde_json::json!({
            "jsonrpc": "2.0",
            "id": 7,
            "method": "elicitation/create",
            "params": {}
        });
        assert!(route_inbound_frame(&rpc, &notif_tx, Some(&inbound_tx), frame).is_none());
        let req = inbound_rx.try_recv().expect("inbound request routed");
        assert_eq!(req.id, serde_json::json!(7));
    }

    #[tokio::test]
    async fn response_bearing_requests_are_lossless_beyond_old_broadcast_capacity() {
        let (rpc, notif_tx, _notif_rx, inbound_tx, mut inbound_rx, _writer_rx) = route_fixture();
        for index in 0..2048 {
            assert!(
                route_inbound_frame(
                    &rpc,
                    &notif_tx,
                    Some(&inbound_tx),
                    serde_json::json!({
                        "jsonrpc": "2.0",
                        "id": index,
                        "method": "elicitation/create",
                        "params": { "sessionId": "session-1" }
                    }),
                )
                .is_none()
            );
        }

        for index in 0..2048 {
            let request = inbound_rx.try_recv().expect("request retained in order");
            assert_eq!(request.id, serde_json::json!(index));
        }
        assert!(inbound_rx.try_recv().is_err());
    }

    #[tokio::test]
    async fn response_bearing_request_queue_has_exactly_one_owner() {
        let (writer_tx, _writer_rx) = mpsc::channel::<String>(1);
        let client = RpcClient::with_rpc(Arc::new(RpcOutbound::new(writer_tx)));

        let _owner = client
            .take_inbound_requests()
            .expect("first app owner claims the receiver");
        let error = client
            .take_inbound_requests()
            .expect_err("a second owner must be rejected");
        assert!(error.to_string().contains("already claimed"));
    }

    fn make_notification(method: &str, params: serde_json::Value) -> RpcNotification {
        RpcNotification {
            method: method.to_string(),
            params,
        }
    }

    #[tokio::test]
    async fn parse_agent_message_chunk() {
        let params = serde_json::json!({
            "type": "agent_message_chunk",
            "session_id": "s1",
            "text": "hello"
        });
        let update = parse_session_update(&params).unwrap();
        match update {
            SessionUpdate::AgentMessageChunk { session_id, text } => {
                assert_eq!(session_id, "s1");
                assert_eq!(text, "hello");
            }
            other => panic!("unexpected: {other:?}"),
        }
    }

    #[tokio::test]
    async fn parse_approval_request() {
        let params = serde_json::json!({
            "type": "approval_request",
            "session_id": "s2",
            "request_id": "req-1",
            "tool_name": "shell",
            "arguments_summary": "ls /tmp",
            "timeout_secs": 60
        });
        let update = parse_session_update(&params).unwrap();
        assert!(matches!(update, SessionUpdate::ApprovalRequest { .. }));
    }

    #[test]
    fn parse_context_usage_keeps_budget_and_model_window_distinct() {
        let params = serde_json::json!({
            "type": "context_usage",
            "session_id": "s-context",
            "input_tokens": 100_000,
            "max_context_tokens": 180_000,
            "model_context_window": 200_000
        });

        assert!(matches!(
            parse_session_update(&params),
            Some(SessionUpdate::ContextUsage {
                session_id,
                input_tokens_source: None,
                input_tokens: Some(100_000),
                max_context_tokens: Some(180_000),
                model_context_window: Some(200_000),
            }) if session_id == "s-context"
        ));
    }

    #[test]
    fn parse_context_usage_decodes_the_estimate_provenance_marker() {
        let params = serde_json::json!({
            "type": "context_usage",
            "session_id": "s-context",
            "input_tokens": 4_200,
            "input_tokens_source": "estimate",
            "max_context_tokens": 180_000,
            "model_context_window": 200_000
        });

        assert!(matches!(
            parse_session_update(&params),
            Some(SessionUpdate::ContextUsage {
                input_tokens: Some(4_200),
                ref input_tokens_source,
                ..
            }) if input_tokens_source.as_deref() == Some("estimate")
        ));
    }

    #[test]
    fn parse_context_usage_decodes_the_provider_provenance_marker() {
        let params = serde_json::json!({
            "type": "context_usage",
            "session_id": "s-context",
            "input_tokens": 100_000,
            "input_tokens_source": "provider",
            "max_context_tokens": 180_000,
            "model_context_window": 200_000
        });

        assert!(matches!(
            parse_session_update(&params),
            Some(SessionUpdate::ContextUsage {
                ref input_tokens_source,
                ..
            }) if input_tokens_source.as_deref() == Some("provider")
        ));
    }

    #[test]
    fn parse_turn_complete_carries_optional_client_generation() {
        let update = parse_session_update(&serde_json::json!({
            "type": "turn_complete",
            "session_id": "s1",
            "outcome": "cancelled",
            "content": "cancelled",
            "client_turn_generation": 7,
        }))
        .expect("turn complete parses");
        assert!(matches!(
            update,
            SessionUpdate::TurnComplete {
                client_turn_generation: Some(7),
                ..
            }
        ));

        let legacy = parse_session_update(&serde_json::json!({
            "type": "turn_complete",
            "session_id": "s1",
            "outcome": "completed",
            "content": "done",
        }))
        .expect("legacy turn complete parses");
        assert!(matches!(
            legacy,
            SessionUpdate::TurnComplete {
                client_turn_generation: None,
                ..
            }
        ));
    }

    #[tokio::test]
    async fn router_converts_session_update_notifications() {
        let (bcast_tx, bcast_rx) = broadcast::channel::<RpcNotification>(16);
        let (update_tx, mut update_rx) = mpsc::channel::<SessionUpdate>(8);
        let _task = spawn_notification_router(bcast_rx, update_tx);

        bcast_tx
            .send(make_notification(
                "session/update",
                serde_json::json!({
                    "type": "agent_message_chunk",
                    "session_id": "s1",
                    "text": "streaming"
                }),
            ))
            .unwrap();

        let update = tokio::time::timeout(std::time::Duration::from_millis(100), update_rx.recv())
            .await
            .expect("timed out")
            .expect("channel closed");

        assert!(matches!(update, SessionUpdate::AgentMessageChunk { .. }));
    }

    #[tokio::test]
    async fn router_drops_unknown_method() {
        let (bcast_tx, bcast_rx) = broadcast::channel::<RpcNotification>(16);
        let (update_tx, mut update_rx) = mpsc::channel::<SessionUpdate>(8);
        let _task = spawn_notification_router(bcast_rx, update_tx);

        bcast_tx
            .send(make_notification("other/event", serde_json::json!({})))
            .unwrap();

        let result =
            tokio::time::timeout(std::time::Duration::from_millis(50), update_rx.recv()).await;
        assert!(result.is_err(), "unknown method must be dropped");
    }
}

#[cfg(test)]
mod tls_tests {
    use super::*;

    #[test]
    fn skip_verify_tls_config_builds_without_panic() {
        let tls = ClientTls {
            skip_verify: true,
            ..Default::default()
        };
        let cfg = RpcClient::wss_tls_config(&tls).expect("skip-verify config builds");
        assert!(Arc::strong_count(&cfg) >= 1);
    }

    #[test]
    fn default_tls_config_uses_public_roots() {
        let cfg = RpcClient::wss_tls_config(&ClientTls::default()).unwrap();
        assert!(!cfg.client_auth_cert_resolver.has_certs());
    }

    #[test]
    fn skip_verify_does_not_drop_the_client_cert() {
        // Critic gap #8: `skip_verify` relaxes SERVER verification only. It must
        // never silently drop the presented client certificate, or a relay/MITM
        // could downgrade an mTLS client to an anonymous one. Build a config with
        // skip_verify AND a real client cert+key and assert the resolver still
        // carries certs. (`has_certs` is a trait-object method on the resolver, so
        // no trait import is needed here.)
        let (_, ca_crt, ca_key) = crate::client_crypto::test_pki::gen_ca();
        let (csr_pem, key_pem) =
            crate::client_crypto::generate_client_csr("dev_skipverify").unwrap();
        let leaf =
            crate::client_crypto::test_pki::sign_csr(&ca_crt, &ca_key, "dev_skipverify", &csr_pem);

        let dir = tempfile::tempdir().unwrap();
        let cert_path = dir.path().join("client.crt");
        let key_path = dir.path().join("client.key");
        std::fs::write(&cert_path, leaf.as_bytes()).unwrap();
        std::fs::write(&key_path, key_pem.as_bytes()).unwrap();

        let tls = ClientTls {
            skip_verify: true,
            client_cert_path: Some(cert_path.to_string_lossy().into_owned()),
            client_key_path: Some(key_path.to_string_lossy().into_owned()),
            ..Default::default()
        };
        let cfg = RpcClient::wss_tls_config(&tls).expect("skip-verify + client cert builds");
        assert!(
            cfg.client_auth_cert_resolver.has_certs(),
            "skip_verify must not drop the presented client certificate"
        );
    }

    #[test]
    fn cached_daemon_ca_requires_single_certificate() {
        let (daemon_ca, _, _) = crate::client_crypto::test_pki::gen_ca();
        let (extra_ca, _, _) = crate::client_crypto::test_pki::gen_ca();
        let dir = tempfile::tempdir().unwrap();
        let ca_path = dir.path().join("ca.crt");
        std::fs::write(&ca_path, format!("{daemon_ca}\n{extra_ca}")).unwrap();

        let tls = ClientTls {
            ca_cert_path: Some(ca_path.to_string_lossy().into_owned()),
            ..Default::default()
        };
        let err = RpcClient::wss_tls_config(&tls).unwrap_err().to_string();
        assert!(
            err.contains("exactly one daemon CA certificate"),
            "got: {err}"
        );
    }

    #[test]
    fn relay_ca_path_takes_precedence_over_pins_and_tofu() {
        let dir = tempfile::tempdir().unwrap();
        let missing_ca = dir.path().join("relay-ca.pem");
        let relay = RelayDial {
            relay_addr: "127.0.0.1:443".into(),
            relay_host: "localhost".into(),
            node_id: "node".into(),
            relay_ca_path: Some(missing_ca.to_string_lossy().into_owned()),
            relay_insecure: false,
            relay_pin: Some("00".into()),
            relay_tofu: true,
            pin_store: None,
            outer_client_cert: None,
            outer_client_key: None,
        };

        assert!(
            relay_outer_connector(&relay).is_err(),
            "configured relay CA must be loaded before stored pins or TOFU can be used"
        );
    }
}

#[cfg(test)]
mod plan_parse_tests {
    use super::*;

    #[test]
    fn parses_plan_update() {
        let params = serde_json::json!({
            "type": "plan",
            "session_id": "sess-1",
            "entries": [
                { "content": "A", "status": "completed", "priority": "high" },
                { "content": "B", "status": "in_progress", "activeForm": "Doing B" }
            ]
        });
        let update = parse_session_update(&params).expect("plan parses");
        match update {
            SessionUpdate::Plan {
                session_id,
                entries,
            } => {
                assert_eq!(session_id, "sess-1");
                assert_eq!(entries.len(), 2);
                assert_eq!(entries[0].status, crate::wire::PlanStatus::Completed);
                assert_eq!(entries[1].active_form.as_deref(), Some("Doing B"));
            }
            _ => panic!("expected SessionUpdate::Plan"),
        }
    }

    #[test]
    fn parses_empty_plan_update_as_clear() {
        let params = serde_json::json!({
            "type": "plan",
            "session_id": "sess-2",
            "entries": []
        });
        match parse_session_update(&params).expect("empty plan parses") {
            SessionUpdate::Plan { entries, .. } => assert!(entries.is_empty()),
            _ => panic!("expected SessionUpdate::Plan"),
        }
    }

    #[test]
    fn parses_budget_warning_update() {
        let params = serde_json::json!({
            "type": "budget_warning",
            "session_id": "s1",
            "current_usd": 8.25,
            "limit_usd": 10.0,
            "period": "day",
        });
        match parse_session_update(&params) {
            Some(SessionUpdate::BudgetWarning {
                session_id,
                current_usd,
                limit_usd,
                period,
            }) => {
                assert_eq!(session_id, "s1");
                assert_eq!(current_usd, 8.25);
                assert_eq!(limit_usd, 10.0);
                assert_eq!(period, "day");
            }
            other => panic!("expected BudgetWarning, got {other:?}"),
        }
    }

    #[test]
    fn parses_history_trimmed_update() {
        let params = serde_json::json!({
            "type": "history_trimmed",
            "session_id": "sess-3",
            "dropped_messages": 12,
            "dropped_turns": 4,
            "kept_turns": 3,
            "reason": "history message limit exceeded"
        });

        assert!(matches!(
            parse_session_update(&params),
            Some(SessionUpdate::HistoryTrimmed {
                session_id,
                dropped_messages: 12,
                dropped_turns: Some(4),
                kept_turns: 3,
                reason,
                token_budget: None,
                tokens_before: None,
                tokens_after: None,
                tokens_before_source: None,
                tokens_after_source: None,
                unsatisfiable_floor: None,
            }) if session_id == "sess-3" && reason == "history message limit exceeded"
        ));
    }

    #[test]
    fn parses_legacy_history_trimmed_update_without_dropped_turns() {
        let params = serde_json::json!({
            "type": "history_trimmed",
            "session_id": "sess-3",
            "dropped_messages": 12,
            "kept_turns": 3,
            "reason": "history message limit exceeded"
        });

        assert!(matches!(
            parse_session_update(&params),
            Some(SessionUpdate::HistoryTrimmed {
                dropped_turns: None,
                ..
            })
        ));
    }

    #[test]
    fn parses_history_trimmed_token_accounting() {
        let params = serde_json::json!({
            "type": "history_trimmed",
            "session_id": "sess-4",
            "dropped_messages": 12,
            "kept_turns": 33,
            "reason": "context token budget exceeded",
            "token_budget": 500000,
            "tokens_before": 612000,
            "tokens_after": 117000,
            "tokens_before_source": "provider",
            "tokens_after_source": "calibrated"
        });

        assert!(matches!(
            parse_session_update(&params),
            Some(SessionUpdate::HistoryTrimmed {
                session_id,
                dropped_messages: 12,
                dropped_turns: None,
                kept_turns: 33,
                reason,
                token_budget: Some(500000),
                tokens_before: Some(612000),
                tokens_after: Some(117000),
                tokens_before_source: Some(source),
                tokens_after_source: Some(after_source),
                unsatisfiable_floor: None,
            }) if session_id == "sess-4"
                && reason == "context token budget exceeded"
                && source == "provider"
                && after_source == "calibrated"
        ));
    }

    #[test]
    fn plan_update_missing_entries_is_none() {
        let params = serde_json::json!({ "type": "plan", "session_id": "s" });
        assert!(parse_session_update(&params).is_none());
    }
}

/// Parser limits for the RELAY-PROTOCOL plane (client <-> relay outer session),
/// derived from `zeroclaw-relay-proto` so transport and application bounds
/// cannot drift apart.
fn relay_ws_config() -> tokio_tungstenite::tungstenite::protocol::WebSocketConfig {
    let mut cfg = tokio_tungstenite::tungstenite::protocol::WebSocketConfig::default();
    cfg.max_message_size = Some(crate::relay_proto::MAX_WS_MESSAGE);
    cfg.max_frame_size = Some(crate::relay_proto::MAX_WS_MESSAGE);
    cfg
}

/// Parser limits for the INNER RPC plane. This is NOT the relay budget: RPC
/// carries attachments up to `zeroclaw_runtime::rpc::attachments::MAX_REQUEST_BYTES`
/// (20 MiB), so a relay-sized cap would truncate legitimate traffic. 32 MiB
/// leaves encoding headroom above that limit while still replacing
/// tungstenite's unbounded-by-default 64 MiB with an explicit ceiling.
fn rpc_ws_config() -> tokio_tungstenite::tungstenite::protocol::WebSocketConfig {
    const RPC_WS_MAX: usize = 32 * 1024 * 1024;
    let mut cfg = tokio_tungstenite::tungstenite::protocol::WebSocketConfig::default();
    cfg.max_message_size = Some(RPC_WS_MAX);
    cfg.max_frame_size = Some(RPC_WS_MAX);
    cfg
}

#[cfg(test)]
mod relay_transport_tests {
    //! Client-side relay transport regressions: the setup budget, the pump's
    //! write-stall bound, and route isolation on an established tunnel.
    //!
    //! The budget tests run on a paused clock and assert the ELAPSED virtual
    //! time, not merely that an error came back. A test that only asserts the
    //! error passes just as happily against a budget of a day, because a paused
    //! clock auto-advances to whatever the next deadline happens to be.

    use super::*;
    use crate::relay_proto::{Control, SUBPROTOCOL, encode_data};
    use futures_util::{SinkExt, StreamExt};
    use tokio::io::AsyncReadExt;
    use tokio_tungstenite::tungstenite::Message;

    /// A listener that completes the TCP accept and then never speaks.
    async fn accept_then_silent_listener() -> (std::net::SocketAddr, tokio::task::JoinHandle<()>) {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let server = tokio::spawn(async move {
            let mut held = Vec::new();
            while let Ok((sock, _)) = listener.accept().await {
                held.push(sock);
            }
        });
        (addr, server)
    }

    fn relay_dial_to(addr: std::net::SocketAddr) -> RelayDial {
        RelayDial {
            relay_addr: addr.to_string(),
            relay_host: "localhost".into(),
            node_id: "node-1".into(),
            relay_ca_path: None,
            relay_insecure: true,
            relay_pin: None,
            relay_tofu: false,
            pin_store: None,
            outer_client_cert: None,
            outer_client_key: None,
        }
    }

    /// The longest a person will wait at a prompt before deciding the tool is
    /// hung. Deliberately a LITERAL, not derived from the constant under test:
    /// an assertion written in terms of that constant moves with it, so widening
    /// the budget to a day would still satisfy it. This is the bound that says
    /// what the budget is FOR.
    const HUMAN_SCALE_CEILING: Duration = Duration::from_secs(60);

    fn assert_spent_the_setup_budget(waited: tokio::time::Duration) {
        assert!(
            waited <= HUMAN_SCALE_CEILING,
            "the setup budget must stay human-scale: {waited:?}"
        );
        assert!(
            waited >= RELAY_SETUP_DEADLINE,
            "the setup must run until its budget, not fail early: {waited:?}"
        );
        assert!(
            waited <= RELAY_SETUP_DEADLINE + Duration::from_secs(1),
            "the setup must end AT its budget: {waited:?} against {RELAY_SETUP_DEADLINE:?}"
        );
    }

    /// The relay fallback is what a client reaches when the direct path is
    /// already down, so an unbounded setup here strands the session with no
    /// route left to try.
    #[tokio::test(start_paused = true)]
    async fn a_silent_relay_cannot_stall_the_rpc_connect() {
        let (addr, server) = accept_then_silent_listener().await;
        let relay = relay_dial_to(addr);

        let started = tokio::time::Instant::now();
        let err = format!(
            "{:#}",
            RpcClient::connect_wss_via_relay(
                "wss://127.0.0.1/",
                None,
                None,
                &ClientTls {
                    skip_verify: true,
                    ..Default::default()
                },
                &relay,
                None,
                None,
            )
            .await
            .expect_err("a silent relay must not hold the connect")
        );

        assert_spent_the_setup_budget(started.elapsed());
        assert!(err.contains("relay setup budget"), "got: {err}");
        server.abort();
    }

    /// The interactive trust probe runs before the operator is asked to confirm
    /// the pin, so a silent relay here hangs the prompt itself.
    #[tokio::test(start_paused = true)]
    async fn a_silent_relay_cannot_stall_the_trust_probe() {
        let (addr, server) = accept_then_silent_listener().await;

        let started = tokio::time::Instant::now();
        let err = format!(
            "{:#}",
            probe_relay_cert_pin(&addr.to_string(), "localhost")
                .await
                .expect_err("a silent relay must not hold the trust probe")
        );

        assert_spent_the_setup_budget(started.elapsed());
        assert!(err.contains("relay trust probe"), "got: {err}");
        server.abort();
    }

    /// A sink that accepts nothing, ever: the peer that stopped reading.
    struct StalledSink;

    impl futures_util::Sink<Message> for StalledSink {
        type Error = std::io::Error;

        fn poll_ready(
            self: std::pin::Pin<&mut Self>,
            _cx: &mut std::task::Context<'_>,
        ) -> std::task::Poll<std::result::Result<(), Self::Error>> {
            std::task::Poll::Pending
        }

        fn start_send(
            self: std::pin::Pin<&mut Self>,
            _item: Message,
        ) -> std::result::Result<(), Self::Error> {
            Ok(())
        }

        fn poll_flush(
            self: std::pin::Pin<&mut Self>,
            _cx: &mut std::task::Context<'_>,
        ) -> std::task::Poll<std::result::Result<(), Self::Error>> {
            std::task::Poll::Pending
        }

        fn poll_close(
            self: std::pin::Pin<&mut Self>,
            _cx: &mut std::task::Context<'_>,
        ) -> std::task::Poll<std::result::Result<(), Self::Error>> {
            std::task::Poll::Pending
        }
    }

    /// An established link that stops making progress must not pin the pump
    /// forever: the inner TLS stream behind it would block with it.
    #[tokio::test(start_paused = true)]
    async fn a_relay_write_that_never_progresses_gives_up() {
        let mut sink = StalledSink;

        let started = tokio::time::Instant::now();
        let sent = relay_send(&mut sink, Message::text("ping")).await;
        let waited = started.elapsed();

        assert!(
            !sent,
            "a write that never progresses must be reported failed"
        );
        // The literal ceiling again: a stall bound that can grow without limit
        // is the unbounded write this test exists to forbid.
        assert!(
            waited <= Duration::from_secs(120),
            "the write-stall bound must stay bounded in human terms: {waited:?}"
        );
        assert!(
            waited >= RELAY_WRITE_STALL && waited <= RELAY_WRITE_STALL + Duration::from_secs(1),
            "the write must give up AT the stall bound: {waited:?}"
        );
    }

    /// Echo the relay subprotocol back so the client's handshake completes.
    ///
    /// The error type is tungstenite's `ErrorResponse`, which carries a whole
    /// HTTP response and so trips the large-error lint; the signature is the
    /// library's, not ours, and this handshake never takes the error path.
    #[allow(clippy::result_large_err)]
    fn echo_subprotocol(
        req: &tokio_tungstenite::tungstenite::handshake::server::Request,
        mut resp: tokio_tungstenite::tungstenite::handshake::server::Response,
    ) -> std::result::Result<
        tokio_tungstenite::tungstenite::handshake::server::Response,
        tokio_tungstenite::tungstenite::handshake::server::ErrorResponse,
    > {
        if req
            .headers()
            .get("Sec-WebSocket-Protocol")
            .is_some_and(|v| v.to_str().is_ok_and(|v| v.contains(SUBPROTOCOL)))
        {
            resp.headers_mut().insert(
                "Sec-WebSocket-Protocol",
                SUBPROTOCOL.parse().expect("static subprotocol"),
            );
        }
        Ok(resp)
    }

    /// A relay stub that completes the outer TLS + WebSocket handshake, answers
    /// the route request with `Opened { conn_id }`, and then sends `frames`.
    async fn relay_stub(
        conn_id: u64,
        frames: Vec<Message>,
    ) -> (std::net::SocketAddr, tokio::task::JoinHandle<()>) {
        let (ca_pem, ca, ca_key) = crate::client_crypto::test_pki::gen_ca();
        let _ = ca_pem;
        let (cert, key) =
            crate::client_crypto::test_pki::gen_server_cert(&ca, &ca_key, &["localhost".into()]);
        let acceptor = crate::client_crypto::test_pki::tls_acceptor(&cert, &key);
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();

        let server = tokio::spawn(async move {
            let (tcp, _) = listener.accept().await.expect("accept");
            let tls = acceptor.accept(tcp).await.expect("relay outer TLS");
            let mut ws = tokio_tungstenite::accept_hdr_async(tls, echo_subprotocol)
                .await
                .expect("relay ws accept");

            // Wait for the route request before opening it.
            while let Some(Ok(msg)) = ws.next().await {
                if let Message::Text(t) = msg
                    && matches!(
                        Control::from_json(t.as_str()),
                        Ok(Control::Connect { .. } | Control::Enroll { .. })
                    )
                {
                    break;
                }
            }
            ws.send(Message::text(Control::Opened { conn_id }.to_json()))
                .await
                .expect("send Opened");
            for frame in frames {
                if ws.send(frame).await.is_err() {
                    break;
                }
            }
            // Hold the link open so the client's teardown is its own decision.
            while ws.next().await.is_some() {}
        });
        (addr, server)
    }

    /// A relay that forwards another route's DATA frame is mis-routing or
    /// injecting. The tunnel must end rather than hand those bytes to the inner
    /// TLS, and the client must never see the foreign payload.
    #[tokio::test]
    async fn a_frame_for_another_route_tears_the_tunnel_down() {
        let (addr, server) = relay_stub(
            7,
            vec![
                Message::binary(encode_data(9, b"FOREIGN")),
                Message::binary(encode_data(7, b"MINE")),
            ],
        )
        .await;

        let _serial = live_pumps::exclusive().await;
        // `_pump` must be a NAMED binding: `_` would drop the guard here and
        // retire the tunnel immediately, which would end the stream for a reason
        // that has nothing to do with what this test asserts.
        let (mut io, _pump) = dial_enrollment_through_relay(&relay_dial_to(addr))
            .await
            .expect("the tunnel opens")
            .split();
        let mut seen = Vec::new();
        let _ = tokio::time::timeout(Duration::from_secs(5), io.read_to_end(&mut seen)).await;

        assert!(
            !seen.windows(7).any(|w| w == b"FOREIGN"),
            "another route's payload must never reach the inner stream: {seen:?}"
        );
        assert!(
            seen.is_empty(),
            "the tunnel must end at the mis-addressed frame, before anything after it: {seen:?}"
        );
        server.abort();
    }

    /// The isolation check must not cost the tunnel its own traffic.
    #[tokio::test]
    async fn a_frame_for_this_route_is_delivered() {
        let (addr, server) = relay_stub(7, vec![Message::binary(encode_data(7, b"MINE"))]).await;

        let _serial = live_pumps::exclusive().await;
        // `_pump` must be a NAMED binding: `_` would drop the guard here and
        // retire the tunnel immediately, which would end the stream for a reason
        // that has nothing to do with what this test asserts.
        let (mut io, _pump) = dial_enrollment_through_relay(&relay_dial_to(addr))
            .await
            .expect("the tunnel opens")
            .split();
        let mut buf = [0u8; 4];
        tokio::time::timeout(Duration::from_secs(5), io.read_exact(&mut buf))
            .await
            .expect("the payload must arrive")
            .expect("read");

        assert_eq!(&buf, b"MINE");
        server.abort();
    }

    /// Control frames are routed too: credit for another conn must not resize
    /// this one's window, and another conn's close must not end this tunnel.
    #[tokio::test]
    async fn control_for_another_route_tears_the_tunnel_down() {
        let (addr, server) = relay_stub(
            7,
            vec![
                Message::text(
                    Control::Close {
                        conn_id: 9,
                        reason: "not yours".into(),
                    }
                    .to_json(),
                ),
                Message::binary(encode_data(7, b"MINE")),
            ],
        )
        .await;

        let _serial = live_pumps::exclusive().await;
        // `_pump` must be a NAMED binding: `_` would drop the guard here and
        // retire the tunnel immediately, which would end the stream for a reason
        // that has nothing to do with what this test asserts.
        let (mut io, _pump) = dial_enrollment_through_relay(&relay_dial_to(addr))
            .await
            .expect("the tunnel opens")
            .split();
        let mut seen = Vec::new();
        let _ = tokio::time::timeout(Duration::from_secs(5), io.read_to_end(&mut seen)).await;

        assert!(
            seen.is_empty(),
            "a control frame for another route must end the tunnel: {seen:?}"
        );
        server.abort();
    }

    /// A relay stub that opens the route and then stops reading entirely: it
    /// never answers, never acks, and never drains what the client writes. This
    /// is the shape that parks a pump in a DATA write or its closing handshake.
    async fn relay_stub_that_stops_reading(
        conn_id: u64,
    ) -> (std::net::SocketAddr, tokio::task::JoinHandle<()>) {
        let (ca_pem, ca, ca_key) = crate::client_crypto::test_pki::gen_ca();
        let _ = ca_pem;
        let (cert, key) =
            crate::client_crypto::test_pki::gen_server_cert(&ca, &ca_key, &["localhost".into()]);
        let acceptor = crate::client_crypto::test_pki::tls_acceptor(&cert, &key);
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();

        let server = tokio::spawn(async move {
            let (tcp, _) = listener.accept().await.expect("accept");
            let tls = acceptor.accept(tcp).await.expect("relay outer TLS");
            let mut ws = tokio_tungstenite::accept_hdr_async(tls, echo_subprotocol)
                .await
                .expect("relay ws accept");
            while let Some(Ok(msg)) = ws.next().await {
                if let Message::Text(t) = msg
                    && matches!(
                        Control::from_json(t.as_str()),
                        Ok(Control::Connect { .. } | Control::Enroll { .. })
                    )
                {
                    break;
                }
            }
            ws.send(Message::text(Control::Opened { conn_id }.to_json()))
                .await
                .expect("send Opened");
            // From here the relay is inert: it holds the link open and reads
            // nothing more.
            std::future::pending::<()>().await;
        });
        (addr, server)
    }

    /// The enrollment tunnel has no session to hand its pump to, so dropping the
    /// tunnel is the only thing that retires it. Proven against a relay that
    /// opened the route and then stopped reading, which is the state that would
    /// otherwise leave the task parked with the route still allocated.
    #[tokio::test]
    async fn dropping_an_enrollment_tunnel_retires_its_pump() {
        let _serial = live_pumps::exclusive().await;
        let (addr, server) = relay_stub_that_stops_reading(7).await;

        let tunnel = dial_enrollment_through_relay(&relay_dial_to(addr))
            .await
            .expect("the tunnel opens");
        let watch = tunnel
            .pump
            .abort_handle()
            .expect("a fresh tunnel guards a live pump");
        assert!(
            !watch.is_finished(),
            "the pump must be running while the tunnel is held"
        );

        let completed_before = live_pumps::completed();
        drop(tunnel);
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }

        assert!(
            watch.is_finished(),
            "dropping the tunnel must retire its pump, not detach it"
        );
        // Ending is not enough. Dropping the stream also unparks a pump sitting
        // in its read arm, so a detached pump would "finish" here too and this
        // test would pass while proving nothing. The pump must have been
        // ABORTED - stopped where it stood, without reaching the end of its
        // body - because that is the only behaviour that also retires a pump
        // parked in a relay write or its closing handshake.
        assert_eq!(
            live_pumps::completed(),
            completed_before,
            "the pump must be retired by the guard, not left to notice its stream closed"
        );
        server.abort();
    }

    /// The guard's contract on its own, independent of where the pump happens to
    /// be parked: a task it owns does not outlive it.
    #[tokio::test]
    async fn a_pump_guard_retires_its_task_wherever_it_is_parked() {
        let parked = tokio::spawn(async {
            std::future::pending::<()>().await;
        });
        let watch = parked.abort_handle();
        let guard = RelayPumpGuard(Some(parked));
        assert!(!watch.is_finished());

        drop(guard);
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }

        assert!(
            watch.is_finished(),
            "a task with no stream to notice must still be retired by its guard"
        );
    }

    /// Releasing hands the task on intact: the RPC path adopts its tunnel into a
    /// session that must keep running.
    #[tokio::test]
    async fn releasing_a_guard_keeps_the_task_running() {
        let parked = tokio::spawn(async {
            std::future::pending::<()>().await;
        });
        let watch = parked.abort_handle();
        let guard = RelayPumpGuard(Some(parked));

        let released = guard.release().expect("a live guard yields its task");
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }

        assert!(
            !watch.is_finished(),
            "a released pump belongs to its new owner and must keep running"
        );
        released.abort();
    }

    /// Replacing a client must reclaim its relay route. Nothing else can: the
    /// pump is a detached task and `RpcClient` has no destructor.
    #[tokio::test]
    async fn shutdown_reclaims_the_relay_pump() {
        let (tx, _rx) = mpsc::channel::<String>(1);
        let pump = tokio::spawn(async {
            std::future::pending::<()>().await;
        });
        let client = RpcClient::with_rpc_and_pump(Arc::new(RpcOutbound::new(tx)), Some(pump));
        assert_eq!(client.relay_pump_finished(), Some(false));

        client.shutdown();
        tokio::time::sleep(Duration::from_millis(50)).await;

        assert_eq!(
            client.relay_pump_finished(),
            Some(true),
            "the relay pump must not outlive the client that owned it"
        );
    }
}
