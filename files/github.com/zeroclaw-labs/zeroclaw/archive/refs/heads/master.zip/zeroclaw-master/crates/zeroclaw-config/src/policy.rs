use anyhow::Context as _;
use parking_lot::Mutex;
use std::collections::{HashMap, VecDeque};
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};
use zeroclaw_api::runtime_traits::ShellDialect;

// Re-export from zeroclaw-config.
pub use crate::autonomy::AutonomyLevel;

/// Risk score for shell command execution.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CommandRiskLevel {
    Low,
    Medium,
    High,
}

/// Classifies whether a tool operation is read-only or side-effecting.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ToolOperation {
    Read,
    Act,
}

/// Sliding-window action tracker for rate limiting.
#[derive(Debug)]
pub struct ActionTracker {
    state: Mutex<ActionTrackerState>,
}

#[derive(Debug)]
struct ActionTrackerState {
    /// Timestamps of successful actions (kept within the last hour).
    committed: Vec<Instant>,
    /// Calls admitted by a wrapper but not yet completed.
    in_flight: usize,
}

const ACTION_WINDOW: Duration = Duration::from_secs(3600);

fn retain_actions_after(actions: &mut Vec<Instant>, cutoff: Option<Instant>) {
    if let Some(cutoff) = cutoff {
        actions.retain(|timestamp| *timestamp > cutoff);
    }
}

impl Default for ActionTracker {
    fn default() -> Self {
        Self::new()
    }
}

impl ActionTracker {
    pub fn new() -> Self {
        Self {
            state: Mutex::new(ActionTrackerState {
                committed: Vec::new(),
                in_flight: 0,
            }),
        }
    }

    /// Record an action and return the current count within the window.
    pub fn record(&self) -> usize {
        let mut state = self.state.lock();
        let now = Instant::now();
        retain_actions_after(&mut state.committed, now.checked_sub(ACTION_WINDOW));
        state.committed.push(now);
        state.committed.len()
    }

    /// Count of actions in the current window without recording.
    pub fn count(&self) -> usize {
        let mut state = self.state.lock();
        retain_actions_after(
            &mut state.committed,
            Instant::now().checked_sub(ACTION_WINDOW),
        );
        state.committed.len()
    }

    #[cfg(test)]
    fn used(&self) -> usize {
        self.used_at(Instant::now())
    }

    fn used_at(&self, now: Instant) -> usize {
        let mut state = self.state.lock();
        retain_actions_after(&mut state.committed, now.checked_sub(ACTION_WINDOW));
        state.committed.len() + state.in_flight
    }

    fn try_record(&self, max: u32) -> bool {
        if max == 0 {
            return false;
        }

        let mut state = self.state.lock();
        let now = Instant::now();
        retain_actions_after(&mut state.committed, now.checked_sub(ACTION_WINDOW));
        if state.committed.len() + state.in_flight >= max as usize {
            return false;
        }
        state.committed.push(now);
        true
    }

    fn reserve(&self, max: u32) -> bool {
        if max == 0 {
            return false;
        }

        let mut state = self.state.lock();
        retain_actions_after(
            &mut state.committed,
            Instant::now().checked_sub(ACTION_WINDOW),
        );
        if state.committed.len() + state.in_flight >= max as usize {
            return false;
        }
        state.in_flight += 1;
        true
    }

    fn commit(&self) -> bool {
        let mut state = self.state.lock();
        if state.in_flight == 0 {
            return false;
        }
        state.in_flight -= 1;
        let now = Instant::now();
        retain_actions_after(&mut state.committed, now.checked_sub(ACTION_WINDOW));
        state.committed.push(now);
        true
    }

    fn release(&self) -> (bool, bool) {
        let mut state = self.state.lock();
        if state.in_flight == 0 {
            return (false, false);
        }
        state.in_flight -= 1;
        retain_actions_after(
            &mut state.committed,
            Instant::now().checked_sub(ACTION_WINDOW),
        );
        let is_empty = state.committed.is_empty() && state.in_flight == 0;
        (true, is_empty)
    }
}

impl Clone for ActionTracker {
    fn clone(&self) -> Self {
        let state = self.state.lock();
        Self {
            state: Mutex::new(ActionTrackerState {
                committed: state.committed.clone(),
                in_flight: 0,
            }),
        }
    }
}

/// Per-sender sliding-window rate limiter. The bucket map is Arc-shared
/// so cloned policies (SubAgents) consume from the same budgets.
#[derive(Debug)]
pub struct PerSenderTracker {
    buckets: std::sync::Arc<parking_lot::Mutex<HashMap<String, ActionTracker>>>,
}

impl PerSenderTracker {
    /// Bucket key used when no per-sender context is available (cron, CLI).
    pub const GLOBAL_KEY: &'static str = "__global__";

    /// Create an empty tracker with no sender buckets.
    pub fn new() -> Self {
        Self {
            buckets: std::sync::Arc::new(parking_lot::Mutex::new(HashMap::new())),
        }
    }

    /// Resolve the current sender key from the task-local, falling back to GLOBAL_KEY.
    fn current_key() -> String {
        zeroclaw_api::TOOL_LOOP_THREAD_ID
            .try_with(|v| v.clone())
            .ok()
            .flatten()
            .unwrap_or_else(|| Self::GLOBAL_KEY.to_string())
    }

    /// Record one action for the current sender. Returns `true` if allowed
    /// (count after recording <= max), `false` if budget exhausted.
    pub fn record_for_current(&self, max: u32) -> bool {
        let key = Self::current_key();
        self.record_within(&key, max)
    }

    /// Record one action for `key` when a slot remains.
    /// Rejected attempts are not recorded.
    pub fn record_within(&self, key: &str, max: u32) -> bool {
        if max == 0 {
            return false;
        }
        let mut buckets = self.buckets.lock();
        let tracker = buckets.entry(key.to_string()).or_default();
        tracker.try_record(max)
    }

    /// Atomically reserve one action slot for the current sender.
    pub fn reserve_for_current(&self, max: u32) -> Option<ActionReservation> {
        let key = Self::current_key();
        self.reserve_within(key, max)
    }

    fn reserve_within(&self, key: String, max: u32) -> Option<ActionReservation> {
        if max == 0 {
            return None;
        }
        {
            let mut buckets = self.buckets.lock();
            let admitted = match buckets.get(&key) {
                Some(tracker) => tracker.reserve(max),
                None => {
                    let tracker = ActionTracker::new();
                    let admitted = tracker.reserve(max);
                    buckets.insert(key.clone(), tracker);
                    admitted
                }
            };
            if !admitted {
                return None;
            }
        }
        Some(ActionReservation {
            tracker: self.clone(),
            key,
            finished: false,
        })
    }

    fn commit_reservation(&self, key: &str) -> bool {
        let buckets = self.buckets.lock();
        buckets.get(key).is_some_and(ActionTracker::commit)
    }

    fn release_reservation(&self, key: &str) -> bool {
        let mut buckets = self.buckets.lock();
        let Some(tracker) = buckets.get(key) else {
            return false;
        };
        let (released, remove_bucket) = tracker.release();
        if remove_bucket {
            buckets.remove(key);
        }
        released
    }

    /// Check if the current sender is at or over the limit (without recording).
    pub fn is_limited_for_current(&self, max: u32) -> bool {
        let key = Self::current_key();
        self.is_exhausted(&key, max)
    }

    pub fn is_exhausted(&self, key: &str, max: u32) -> bool {
        self.is_exhausted_at(key, max, Instant::now())
    }

    fn is_exhausted_at(&self, key: &str, max: u32, now: Instant) -> bool {
        let mut buckets = self.buckets.lock();
        let used = buckets.get(key).map_or(0, |tracker| tracker.used_at(now));
        if used == 0 {
            buckets.remove(key);
        }
        max == 0 || used >= max as usize
    }
}

/// One sender-scoped in-flight action slot.
///
/// Dropping an uncommitted reservation releases only this invocation's slot.
#[must_use = "dropping the reservation releases the action slot"]
pub struct ActionReservation {
    tracker: PerSenderTracker,
    key: String,
    finished: bool,
}

impl ActionReservation {
    /// Convert this in-flight slot into one committed action.
    pub fn commit(mut self) {
        let committed = self.tracker.commit_reservation(&self.key);
        assert!(committed, "owned action reservation must still exist");
        self.finished = true;
    }
}

impl Drop for ActionReservation {
    fn drop(&mut self) {
        if !self.finished {
            let _ = self.tracker.release_reservation(&self.key);
        }
    }
}

impl Clone for PerSenderTracker {
    fn clone(&self) -> Self {
        Self {
            buckets: std::sync::Arc::clone(&self.buckets),
        }
    }
}

impl Default for PerSenderTracker {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone)]
pub struct SecurityPolicy {
    pub autonomy: AutonomyLevel,
    /// Name of the risk profile this policy was built from. Used to gate
    /// delegation: a Delegate may only target an agent sharing the caller's
    /// risk profile. Empty when constructed outside the profile path.
    pub risk_profile_name: String,
    /// Whether and to which agents this profile may delegate.
    pub delegation_policy: crate::autonomy::DelegationPolicy,
    pub workspace_dir: PathBuf,
    pub config_path: Option<PathBuf>,
    pub data_dir: Option<PathBuf>,
    pub workspace_only: bool,
    pub allowed_commands: Vec<String>,
    pub forbidden_paths: Vec<String>,
    /// Directories the agent can read AND write under. Includes
    /// `RiskProfileConfig.allowed_roots` plus any cross-agent
    /// `AccessMode::ReadWrite` grants resolved from
    /// `agent.workspace.access` at policy construction time.
    pub allowed_roots: Vec<PathBuf>,
    /// Directories the agent can read but NOT write under. Populated
    /// from cross-agent `AccessMode::Read` grants at policy
    /// construction time. Empty when no read-only cross-agent access
    /// is configured.
    pub allowed_roots_read_only: Vec<PathBuf>,
    /// Directories the agent can write but NOT read under. Populated
    /// from cross-agent `AccessMode::Write` grants; read-side tools
    /// ignore this list.
    pub allowed_roots_write_only: Vec<PathBuf>,
    pub max_actions_per_hour: u32,
    pub max_cost_per_day_cents: u32,
    pub require_approval_for_medium_risk: bool,
    pub block_high_risk_commands: bool,
    pub shell_env_passthrough: Vec<String>,
    pub shell_timeout_secs: u64,
    /// Tool name allowlist. `None` is unrestricted (default for agents
    /// without an explicit `risk_profile.allowed_tools` setting).
    /// `Some(vec![])` denies every tool. `Some(list)` admits only the
    /// listed names. Enforced at the agent loop's tool-dispatch site.
    pub allowed_tools: Option<Vec<String>>,
    /// Tool name denylist. Subtracts from the allowed set (whether the
    /// allowed set comes from `allowed_tools` or from the unrestricted
    /// default). `None` and `Some(vec![])` both mean "exclude nothing".
    pub excluded_tools: Option<Vec<String>>,
    /// Tools that never require approval in this profile. Mirrors
    /// `RiskProfileConfig.auto_approve`.
    pub auto_approve: Vec<String>,
    /// Tools that always require approval in this profile. Mirrors
    /// `RiskProfileConfig.always_ask`.
    pub always_ask: Vec<String>,
    /// Whether the sandbox is enabled for this profile. `None`
    /// inherits the global default at the call site.
    pub sandbox_enabled: Option<bool>,
    /// Sandbox backend identifier (e.g. `"firejail"`, `"landlock"`).
    /// `None` inherits the global default.
    pub sandbox_backend: Option<String>,
    /// Extra arguments forwarded to firejail when `sandbox_backend`
    /// resolves to `"firejail"`.
    pub firejail_args: Vec<String>,
    /// Container image for the docker sandbox backend. `None` inherits the
    /// built-in default; carried here so status surfaces report the image the
    /// sandbox will actually run rather than assuming the default.
    pub sandbox_image: Option<String>,
    pub tracker: PerSenderTracker,
}

impl SecurityPolicy {
    /// True when `name` is admissible under the current policy.
    /// `allowed_tools = None` is unrestricted; `Some(list)` is the
    /// allowlist. `excluded_tools` always subtracts.
    pub fn is_tool_allowed(&self, name: &str) -> bool {
        let allowed = self
            .allowed_tools
            .as_ref()
            .is_none_or(|list| list.iter().any(|t| t == name));
        allowed && !self.is_tool_excluded(name)
    }

    pub fn is_tool_excluded(&self, name: &str) -> bool {
        self.excluded_tools
            .as_ref()
            .is_some_and(|list| list.iter().any(|t| t == name))
    }
}

/// Default allowed commands for Unix platforms.
#[cfg(not(target_os = "windows"))]
pub(crate) fn default_allowed_commands() -> Vec<String> {
    #[allow(unused_mut)]
    let mut cmds = vec![
        "git".into(),
        "npm".into(),
        "cargo".into(),
        "ls".into(),
        "cat".into(),
        "grep".into(),
        "find".into(),
        "echo".into(),
        "pwd".into(),
        "wc".into(),
        "head".into(),
        "tail".into(),
        "date".into(),
        "df".into(),
        "du".into(),
        "uname".into(),
        "uptime".into(),
        "hostname".into(),
        "python".into(),
        "python3".into(),
        "pip".into(),
        "node".into(),
    ];
    // `free` is Linux-only; it does not exist on macOS or other BSDs.
    #[cfg(target_os = "linux")]
    cmds.push("free".into());
    cmds
}

/// Default allowed commands for Windows platforms.
/// Includes both native Windows commands and their Unix equivalents
/// (available via Git for Windows, WSL, etc.).
#[cfg(target_os = "windows")]
pub(crate) fn default_allowed_commands() -> Vec<String> {
    vec![
        // Cross-platform tools
        "git".into(),
        "npm".into(),
        "cargo".into(),
        "echo".into(),
        // Windows-native equivalents
        "dir".into(),
        "type".into(),
        "findstr".into(),
        "where".into(),
        "more".into(),
        "date".into(),
        // Unix commands (available via Git for Windows / MSYS2)
        "ls".into(),
        "cat".into(),
        "grep".into(),
        "find".into(),
        "pwd".into(),
        "wc".into(),
        "head".into(),
        "tail".into(),
        "df".into(),
        "du".into(),
        "uname".into(),
        "uptime".into(),
        "hostname".into(),
        "python".into(),
        "python3".into(),
        "pip".into(),
        "node".into(),
    ]
}

/// Default forbidden paths for Unix platforms.
#[cfg(not(target_os = "windows"))]
pub(crate) fn default_forbidden_paths() -> Vec<String> {
    vec![
        "/etc".into(),
        "/root".into(),
        "/home".into(),
        "/usr".into(),
        "/bin".into(),
        "/sbin".into(),
        "/lib".into(),
        "/opt".into(),
        "/boot".into(),
        "/dev".into(),
        "/proc".into(),
        "/sys".into(),
        "/var".into(),
        "/tmp".into(),
        "~/.ssh".into(),
        "~/.gnupg".into(),
        "~/.aws".into(),
        "~/.config".into(),
    ]
}

/// Default forbidden paths for Windows platforms.
#[cfg(target_os = "windows")]
pub(crate) fn default_forbidden_paths() -> Vec<String> {
    vec![
        "C:\\Windows".into(),
        "C:\\Windows\\System32".into(),
        "C:\\Program Files".into(),
        "C:\\Program Files (x86)".into(),
        "C:\\ProgramData".into(),
        "~/.ssh".into(),
        "~/.gnupg".into(),
        "~/.aws".into(),
        "~/.config".into(),
    ]
}

fn roots_contain(roots: &[PathBuf], expanded: &Path) -> bool {
    roots.iter().any(|root| {
        let canonical = root.canonicalize().unwrap_or_else(|_| root.clone());
        expanded.starts_with(&canonical) || expanded.starts_with(root)
    })
}

fn path_contains(parent: &Path, child: &Path) -> bool {
    let canonical_parent = parent
        .canonicalize()
        .unwrap_or_else(|_| parent.to_path_buf());
    let canonical_child = child.canonicalize().unwrap_or_else(|_| child.to_path_buf());
    canonical_child.starts_with(&canonical_parent) || child.starts_with(parent)
}

/// Depth, in normal path components, of `prefix` when `target` starts with it.
/// Returns `None` when `prefix` is not a prefix of `target`.
///
/// Used to rank competing allow/deny matches by specificity so the most
/// specific rule wins: an explicit `forbidden_paths` entry nested under a
/// broad `allowed_roots` entry denies, while an `allowed_roots` entry nested
/// under a broad default forbidden root (e.g. `/home`) still allows.
fn prefix_match_depth(prefix: &Path, target: &Path) -> Option<usize> {
    if target.starts_with(prefix) {
        Some(
            prefix
                .components()
                .filter(|c| matches!(c, std::path::Component::Normal(_)))
                .count(),
        )
    } else {
        None
    }
}

/// Namespace in which competing path-policy rules are compared.
///
/// Lexical checks compare the configured spellings because they have not yet
/// resolved filesystem aliases. Resolved checks compare every rule after
/// symlink resolution so an alias cannot make an equivalent deny disappear.
#[derive(Clone, Copy)]
enum PathMatchNamespace {
    Configured,
    Resolved,
}

fn namespace_prefix_match_depth(
    prefix: &Path,
    target: &Path,
    namespace: PathMatchNamespace,
) -> Option<usize> {
    match namespace {
        PathMatchNamespace::Configured => prefix_match_depth(prefix, target),
        PathMatchNamespace::Resolved => resolve_symlinked_path(prefix)
            .and_then(|resolved_prefix| prefix_match_depth(&resolved_prefix, target)),
    }
}

/// Deepest (most specific) allow-root match depth for `expanded`, considering
/// the workspace directory and every provided allow-root list. `None` when no
/// allow rule matches. Every rule is compared in `namespace`; callers must use
/// the configured namespace for lexical targets and the resolved namespace for
/// resolved targets so competing depths are never derived from different path
/// spellings.
fn deepest_allow_depth(
    workspace_dir: &Path,
    root_lists: &[&[PathBuf]],
    expanded: &Path,
    namespace: PathMatchNamespace,
) -> Option<usize> {
    let mut best: Option<usize> = None;
    let mut consider = |root: &Path| {
        if let Some(depth) = namespace_prefix_match_depth(root, expanded, namespace) {
            best = Some(best.map_or(depth, |b| b.max(depth)));
        }
    };
    consider(workspace_dir);
    for list in root_lists {
        for root in *list {
            consider(root);
        }
    }
    best
}

/// Deepest (most specific) forbidden match depth for `expanded`. `None` when no
/// forbidden entry matches. Entries are compared in the same namespace as the
/// target and any competing allow rules.
fn deepest_forbidden_depth(
    forbidden_paths: &[String],
    expanded: &Path,
    namespace: PathMatchNamespace,
) -> Option<usize> {
    let mut best: Option<usize> = None;
    for forbidden in forbidden_paths {
        let forbidden_path = expand_user_path(forbidden);
        if let Some(depth) = namespace_prefix_match_depth(&forbidden_path, expanded, namespace) {
            best = Some(best.map_or(depth, |b| b.max(depth)));
        }
    }
    best
}

/// Decide whether a `forbidden_paths` entry should deny a path even though an
/// allow rule also matches. Deny wins when the most specific forbidden prefix
/// is at least as deep as the most specific allowing prefix, so an explicit
/// forbidden path nested under an allowed root takes effect, while a broad
/// default forbidden root (e.g. `/home`) does not override an operator's more
/// specific `allowed_roots` entry. A tie resolves to deny — an explicit "no"
/// at the same boundary as the allow should hold.
fn forbidden_overrides_allow(forbidden_depth: Option<usize>, allow_depth: Option<usize>) -> bool {
    match (forbidden_depth, allow_depth) {
        (Some(f), Some(a)) => f >= a,
        (Some(_), None) => true,
        (None, _) => false,
    }
}

/// Specific kind of escalation violation returned by
/// [`SecurityPolicy::ensure_no_escalation_beyond`]. Each variant names
/// the field that violated subset semantics so the SubAgent spawn path
/// can produce a precise error to the caller.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EscalationViolation {
    /// Child raises `autonomy` above the parent (e.g. parent
    /// `Supervised`, child `Full`). The autonomy level gates the
    /// entire `can_act` and approval flow, so silent escalation here
    /// would bypass every other guard.
    AutonomyAboveParent {
        child: AutonomyLevel,
        parent: AutonomyLevel,
    },
    /// `child.allowed_roots` contains a path the parent cannot rw.
    ReadWriteRootNotInParent { path: PathBuf },
    /// `child.allowed_roots_read_only` contains a path the parent
    /// cannot read at all (not in parent rw or read-only lists).
    ReadOnlyRootNotInParent { path: PathBuf },
    /// `child.allowed_roots_write_only` contains a path the parent
    /// cannot write at all (not in parent rw or write-only lists).
    WriteOnlyRootNotInParent { path: PathBuf },
    /// `child.allowed_commands` contains a shell command the parent
    /// has no allowance for.
    CommandNotInParent { command: String },
    /// Parent enforces workspace_only but the child override tries to
    /// turn it off.
    WorkspaceOnlyDisabledByChild,
    /// Child drops a forbidden_paths entry the parent enforces. Subset
    /// semantics on forbidden lists run the opposite direction from
    /// allowlists: parent ⊆ child, so the child can ADD entries but
    /// never DROP them.
    ForbiddenPathDroppedByChild { path: String },
    /// Child raises `shell_env_passthrough` to leak env vars the
    /// parent declined to forward.
    ShellEnvPassthroughExpanded { variable: String },
    /// Child override raises `max_actions_per_hour` above the
    /// parent's ceiling.
    MaxActionsExceeded { child: u32, parent: u32 },
    /// Child override raises `max_cost_per_day_cents` above the
    /// parent's ceiling.
    MaxCostExceeded { child: u32, parent: u32 },
    /// Child override raises `shell_timeout_secs` above the parent's
    /// ceiling. The shell budget is a runaway-process guard; raising
    /// it on the child side defeats the parent's intent.
    ShellTimeoutExceeded { child: u64, parent: u64 },
    /// Child flips `block_high_risk_commands` from `true` (parent) to
    /// `false`, opening the high-risk command surface the parent
    /// closed.
    BlockHighRiskCommandsDisabledByChild,
    /// Child flips `require_approval_for_medium_risk` from `true`
    /// (parent) to `false`, bypassing the human-in-the-loop step the
    /// parent required.
    RequireApprovalDisabledByChild,
}

impl std::fmt::Display for EscalationViolation {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::AutonomyAboveParent { child, parent } => {
                write!(f, "subagent autonomy={child:?} exceeds parent's {parent:?}")
            }
            Self::ReadWriteRootNotInParent { path } => write!(
                f,
                "subagent allowed_roots entry {path:?} is not contained within any of the parent's allowed_roots entries"
            ),
            Self::ReadOnlyRootNotInParent { path } => write!(
                f,
                "subagent allowed_roots_read_only entry {path:?} is not contained within the parent's allowed_roots or allowed_roots_read_only"
            ),
            Self::WriteOnlyRootNotInParent { path } => write!(
                f,
                "subagent allowed_roots_write_only entry {path:?} is not contained within the parent's allowed_roots or allowed_roots_write_only"
            ),
            Self::CommandNotInParent { command } => write!(
                f,
                "subagent allowed_commands entry {command:?} is not present on the parent's allowed_commands"
            ),
            Self::WorkspaceOnlyDisabledByChild => write!(
                f,
                "subagent attempts to disable workspace_only but the parent enforces it"
            ),
            Self::ForbiddenPathDroppedByChild { path } => write!(
                f,
                "subagent drops forbidden_paths entry {path:?} that the parent enforces"
            ),
            Self::ShellEnvPassthroughExpanded { variable } => write!(
                f,
                "subagent shell_env_passthrough entry {variable:?} is not present on the parent's list"
            ),
            Self::MaxActionsExceeded { child, parent } => write!(
                f,
                "subagent max_actions_per_hour={child} exceeds parent's {parent}"
            ),
            Self::MaxCostExceeded { child, parent } => write!(
                f,
                "subagent max_cost_per_day_cents={child} exceeds parent's {parent}"
            ),
            Self::ShellTimeoutExceeded { child, parent } => write!(
                f,
                "subagent shell_timeout_secs={child} exceeds parent's {parent}"
            ),
            Self::BlockHighRiskCommandsDisabledByChild => write!(
                f,
                "subagent attempts to set block_high_risk_commands=false but the parent enforces it"
            ),
            Self::RequireApprovalDisabledByChild => write!(
                f,
                "subagent attempts to set require_approval_for_medium_risk=false but the parent enforces it"
            ),
        }
    }
}

impl std::error::Error for EscalationViolation {}

impl Default for SecurityPolicy {
    fn default() -> Self {
        Self {
            autonomy: AutonomyLevel::Supervised,
            risk_profile_name: String::new(),
            delegation_policy: crate::autonomy::DelegationPolicy::default(),
            workspace_dir: PathBuf::from("."),
            config_path: None,
            data_dir: None,
            workspace_only: true,
            allowed_commands: default_allowed_commands(),
            forbidden_paths: default_forbidden_paths(),
            allowed_roots: Vec::new(),
            allowed_roots_read_only: Vec::new(),
            allowed_roots_write_only: Vec::new(),
            max_actions_per_hour: 20,
            max_cost_per_day_cents: 500,
            require_approval_for_medium_risk: true,
            block_high_risk_commands: true,
            shell_env_passthrough: vec![],
            shell_timeout_secs: 60,
            allowed_tools: None,
            excluded_tools: None,
            auto_approve: vec![],
            always_ask: vec![],
            sandbox_enabled: None,
            sandbox_backend: None,
            firejail_args: vec![],
            sandbox_image: None,
            tracker: PerSenderTracker::new(),
        }
    }
}

fn home_dir() -> Option<PathBuf> {
    #[cfg(not(target_os = "windows"))]
    {
        std::env::var_os("HOME").map(PathBuf::from)
    }
    #[cfg(target_os = "windows")]
    {
        std::env::var_os("USERPROFILE")
            .or_else(|| std::env::var_os("HOME"))
            .map(PathBuf::from)
    }
}

fn expand_user_path(path: &str) -> PathBuf {
    if path == "~"
        && let Some(home) = home_dir()
    {
        return home;
    }

    if let Some(stripped) = path.strip_prefix("~/")
        && let Some(home) = home_dir()
    {
        return home.join(stripped);
    }

    PathBuf::from(path)
}

/// Resolve `path` to its real target, following symlinks component by component.
///
/// Unlike [`Path::canonicalize`] this does NOT require the target to exist, so a
/// path whose leaf is about to be created (`touch link/new.txt`) still resolves,
/// while a symlinked component is followed to its target even when that target
/// does not exist yet (a *dangling* symlink `link -> /outside/new` — the write
/// would still land outside, so it must be resolved and blocked, exactly as
/// `file_write` blocks writing through a symlink leaf). Lexical `.`/`..` are
/// applied without touching the filesystem. Symlink chains are bounded to guard
/// against cycles: exhausting the hop budget returns `None` ("could not
/// resolve"), and callers fail closed by BLOCKING the path - a crafted cycle
/// never falls back to the literal input. An unreadable link is kept as a
/// literal component while resolution continues on its ancestors.
fn resolve_symlinked_path(path: &Path) -> Option<PathBuf> {
    let mut suffix: Vec<std::ffi::OsString> = Vec::new();
    let mut current = path.to_path_buf();
    // Bounds the number of `..`-style retries plus symlink hops so a symlink
    // cycle cannot spin forever. `None` on exhaustion means "could not resolve";
    // the caller FAILS CLOSED (blocks), so a crafted deep/cyclic symlink chain
    // cannot exhaust the budget and fall back to an allowed in-workspace path.
    let mut budget: u32 = 64;
    loop {
        // Canonicalizing the deepest EXISTING prefix normalizes it the same way
        // `is_resolved_path_allowed` normalizes the workspace root (e.g. `/tmp`
        // vs its real location), so ordinary in-workspace paths stay in-workspace.
        if let Ok(resolved) = current.canonicalize() {
            let mut result = resolved;
            for component in suffix.iter().rev() {
                result.push(component);
            }
            return Some(result);
        }
        // A *dangling* symlink cannot be canonicalized (its target does not
        // exist), yet a write through it still lands at the target. Follow it
        // explicitly so the resolved path reflects where the write would go.
        // Only symlink hops consume the budget (a symlink cycle is the only way
        // to loop forever); stripping non-existent trailing components is bounded
        // by the finite path depth, so a deeply-nested create is NOT false-blocked.
        if current
            .symlink_metadata()
            .is_ok_and(|m| m.file_type().is_symlink())
            && let Ok(target) = std::fs::read_link(&current)
        {
            if budget == 0 {
                return None;
            }
            budget -= 1;
            current = if target.is_absolute() {
                target
            } else {
                current
                    .parent()
                    .map(|parent| parent.join(&target))
                    .unwrap_or(target)
            };
            continue;
        }
        // Otherwise strip the trailing (non-existent) component and retry on the
        // parent. An absolute input terminates at the filesystem root, which
        // always canonicalizes; running out of components should be unreachable
        // for the absolute inputs the caller passes, so treat it as unresolvable
        // and fail closed rather than trusting the literal path.
        match (current.file_name(), current.parent()) {
            (Some(name), Some(parent)) if !parent.as_os_str().is_empty() => {
                suffix.push(name.to_os_string());
                current = parent.to_path_buf();
            }
            _ => return None,
        }
    }
}

/// Whether `path` is the host's discard-only null device.
///
/// This helper short-circuits filesystem authorization (`is_path_allowed`,
/// `is_resolved_path_*`, `resolve_policy_target`), so it recognizes only the
/// spelling that names the null device on the host evaluating policy:
///
/// - Unix: `/dev/null` is always allowed, before filesystem resolution and
///   regardless of workspace or `forbidden_paths` config (including a
///   forbidden `/dev`). The exception does not depend on the device node
///   resolving where policy is evaluated.
/// - Windows: `nul` / `\\.\nul`, case-insensitive. Here `/dev/null` is an
///   ordinary file at `\dev\null` on the current drive, so it gets normal
///   forbidden-path checks.
///
/// Each host's foreign spelling is an ordinary filename on that host and may be
/// a regular file or a symlink to a forbidden target, so it must go through
/// normal resolution and policy checks. Whether a *shell* treats a redirect
/// target as discard-only is a separate, dialect-aware decision
/// (`is_safe_device_redirect_target`): a POSIX `2>/dev/null` redirect is still
/// accepted on a Windows host, and a `cmd.exe` `2>nul` redirect on a Unix host.
///
/// Matching is exact. `nul.txt`, `/dev/null/extra`, and `/dev/zero` are not the
/// null device.
fn is_null_device(path: &Path) -> bool {
    #[cfg(not(target_os = "windows"))]
    {
        path == Path::new("/dev/null")
    }
    #[cfg(target_os = "windows")]
    {
        let s = path.to_string_lossy();
        let lower = s.to_ascii_lowercase();
        lower == "nul" || lower == r"\\.\nul"
    }
}

fn rootless_path(path: &Path) -> Option<PathBuf> {
    let mut relative = PathBuf::new();

    for component in path.components() {
        match component {
            std::path::Component::Prefix(_)
            | std::path::Component::RootDir
            | std::path::Component::CurDir => {}
            std::path::Component::ParentDir => return None,
            std::path::Component::Normal(part) => relative.push(part),
        }
    }

    if relative.as_os_str().is_empty() {
        None
    } else {
        Some(relative)
    }
}

struct NormalizedRootlessPath {
    drive: Option<u8>,
    text: String,
}

fn normalized_rootless_path_text(path: &Path) -> Option<NormalizedRootlessPath> {
    let mut text = path.to_string_lossy().replace('\\', "/");

    if let Some(rest) = text.strip_prefix("//?/UNC/") {
        text = rest.to_string();
    } else if let Some(rest) = text.strip_prefix("//?/") {
        text = rest.to_string();
    }

    let mut drive = None;
    let bytes = text.as_bytes();
    if bytes.len() >= 2 && bytes[1] == b':' && bytes[0].is_ascii_alphabetic() {
        drive = Some(bytes[0].to_ascii_lowercase());
        text = text[2..].to_string();
    }

    let parts: Vec<&str> = text
        .trim_start_matches('/')
        .split('/')
        .filter(|part| !part.is_empty() && *part != ".")
        .collect();

    if parts.is_empty() || parts.contains(&"..") {
        None
    } else {
        Some(NormalizedRootlessPath {
            drive,
            text: parts.join("/"),
        })
    }
}

fn workspace_prefixed_relative_suffix(path: &Path, workspace_dir: &Path) -> Option<PathBuf> {
    let path_text = normalized_rootless_path_text(path)?;
    let workspace_text = normalized_rootless_path_text(workspace_dir)?;

    if path_text.drive.is_some() && path_text.drive != workspace_text.drive {
        return None;
    }

    if path_text.text == workspace_text.text {
        return Some(PathBuf::new());
    }

    let prefix = format!("{}/", workspace_text.text);
    path_text
        .text
        .strip_prefix(&prefix)
        .map(|suffix| PathBuf::from(suffix.replace('/', std::path::MAIN_SEPARATOR_STR)))
}

/// Skip leading environment variable assignments (e.g. `FOO=bar cmd args`).
/// Returns the remainder starting at the first non-assignment word.
fn skip_env_assignments(s: &str) -> &str {
    let mut rest = s;
    loop {
        let Some(word) = rest.split_whitespace().next() else {
            return rest;
        };
        if is_env_assignment_word(word) {
            // Advance past this word
            rest = rest[word.len()..].trim_start();
        } else {
            return rest;
        }
    }
}

fn is_env_assignment_word(word: &str) -> bool {
    env_assignment_name(word).is_some()
}

fn env_assignment_name(word: &str) -> Option<&str> {
    let (raw_name, _) = word.split_once('=')?;
    normalized_assignment_name(raw_name)
}

fn normalized_assignment_name(raw_name: &str) -> Option<&str> {
    let name = raw_name.strip_suffix('+').unwrap_or(raw_name);
    let mut chars = name.chars();
    let first = chars.next()?;
    if (first.is_ascii_alphabetic() || first == '_')
        && chars.all(|c| c.is_ascii_alphanumeric() || c == '_')
    {
        Some(name)
    } else {
        None
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum QuoteState {
    None,
    Single,
    Double,
}

/// Which POSIX shell will parse a command, when that is known.
///
/// POSIX shells disagree on a few forms that decide where a heredoc body ends
/// or whether text runs as a command at all: bash expands `<<$'EOF'` and reads
/// `((x << 1))` as arithmetic, while dash ends that heredoc at a literal
/// `$EOF` line and runs `((...))` as nested subshells. The splitter refuses
/// those forms for [`PosixShell::Unknown`] and follows bash for
/// [`PosixShell::Bash`]. See [`SecurityPolicy::command_shell`] for how a
/// shell is identified.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
enum PosixShell {
    /// Any POSIX shell. Forms the shells read differently are refused.
    #[default]
    Unknown,
    /// GNU bash, in normal or POSIX mode (invoked as `sh`). The modeled forms
    /// read the same in bash 3.2 through 5.3, in either mode.
    Bash,
}

/// The language a command is checked in: the dialect, plus which POSIX shell
/// when the dialect is POSIX and the shell is known.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ShellGrammar {
    dialect: ShellDialect,
    /// Ignored unless `dialect` is [`ShellDialect::Posix`].
    posix_shell: PosixShell,
}

/// A dialect alone says nothing about which POSIX shell runs, so it converts
/// to the portable grammar.
impl From<ShellDialect> for ShellGrammar {
    fn from(dialect: ShellDialect) -> Self {
        Self {
            dialect,
            posix_shell: PosixShell::Unknown,
        }
    }
}

/// The shell a runtime will run a command with, as the runtime reports it
/// before building the command. Pass it to [`SecurityPolicy::command_shell`].
#[derive(Debug, Clone, Copy)]
pub struct ShellTarget<'a> {
    /// The runtime's shell language.
    pub dialect: ShellDialect,
    /// The runtime's [`RuntimeAdapter::shell_program`]: the configured
    /// program before host resolution. `None` when the host cannot inspect
    /// the program that runs (a container or WASM runtime).
    ///
    /// [`RuntimeAdapter::shell_program`]: crate::platform::RuntimeAdapter::shell_program
    pub program: Option<&'a std::ffi::OsStr>,
    /// The `PATH` the runtime will resolve a bare `program` on: a connected
    /// TUI's forwarded `PATH`, or `None` for the daemon's own.
    pub effective_path: Option<&'a std::ffi::OsStr>,
}

impl<'a> ShellTarget<'a> {
    /// What `runtime` reports, for a command built with `effective_path`.
    pub fn of(
        runtime: &'a dyn crate::platform::RuntimeAdapter,
        effective_path: Option<&'a std::ffi::OsStr>,
    ) -> Self {
        Self {
            dialect: runtime.shell_dialect(),
            program: runtime.shell_program(),
            effective_path,
        }
    }
}

/// The grammar a command is checked in, chosen once by
/// [`SecurityPolicy::command_shell`] and carried through the checks to
/// [`SecurityPolicy::confirm_built_shell`], so every check reads the command
/// the same way and the program that runs is held to that reading.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CommandShell {
    grammar: ShellGrammar,
}

/// Identify the POSIX shell a runtime will run, from the program it reports
/// and the `PATH` it will resolve that program on (see
/// [`SecurityPolicy::command_shell`]).
///
/// The program is resolved as the native runtime resolves it, on the same
/// `PATH`, to its canonical file; nothing is built. It is bash only when:
/// - The runtime reports a program. A container or WASM runtime runs a
///   program the host cannot inspect.
/// - No container sandbox can run the command. A container runs the
///   configured name or path inside its image, where it can be any shell.
///   Host sandboxes run the canonical host file.
/// - The program resolves to an executable named exactly `bash`. A bare name
///   counts when it resolves to bash on that `PATH`.
///
/// Everything else, including a `bash` link to another shell, is `Unknown`.
/// The runtime may still build a different program than this predicts, so a
/// command read as bash is checked again against the built program
/// ([`SecurityPolicy::confirm_built_shell`]).
fn resolve_posix_shell(
    program: Option<&std::ffi::OsStr>,
    effective_path: Option<&std::ffi::OsStr>,
    container_sandbox_possible: bool,
) -> PosixShell {
    #[cfg(unix)]
    {
        let Some(program) = program else {
            return PosixShell::Unknown;
        };
        if container_sandbox_possible {
            return PosixShell::Unknown;
        }
        let resolved = match effective_path {
            Some(path) => {
                crate::platform::resolve_executable_with_path(program, std::env::split_paths(path))
            }
            None => crate::platform::resolve_executable(program),
        };
        match resolved {
            Ok(canonical) if is_bash(&canonical) => PosixShell::Bash,
            _ => PosixShell::Unknown,
        }
    }
    #[cfg(not(unix))]
    {
        let _ = (program, effective_path, container_sandbox_possible);
        PosixShell::Unknown
    }
}

/// Whether a canonical executable path names bash.
#[cfg(unix)]
fn is_bash(canonical: &Path) -> bool {
    canonical.file_name() == Some(std::ffi::OsStr::new("bash"))
}

/// A heredoc queued on a command line, waiting for its body.
#[derive(Debug, Clone, PartialEq, Eq)]
struct HeredocDelimiter {
    /// The terminator line as bytes, or `None` when it cannot be proven.
    /// Bash compares terminator lines bytewise, and `$'\xc3'` can name bytes
    /// that are not UTF-8 on their own, so the terminator is not a `String`.
    terminator: Option<Vec<u8>>,
    /// `<<-`: leading tabs are removed from the start of each logical line
    /// before it is compared.
    strip_tabs: bool,
    /// The delimiter word was unquoted, so the body is expanded: a line
    /// ending in an odd number of backslashes continues onto the next one.
    joins_lines: bool,
}

/// Whether a heredoc body line ends in a backslash that continues it onto the
/// next line: an odd number of trailing backslashes (`\\` is an escaped one).
fn ends_with_line_continuation(line: &str) -> bool {
    line.bytes().rev().take_while(|&byte| byte == b'\\').count() % 2 == 1
}

/// What closes an open [`SegmentFrame`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SegmentFrameKind {
    /// `$(`, `<(`, `>(`, or a grouping `(`; closed by an unquoted `)`.
    Paren,
    /// Old-style command substitution; closed by the next unescaped backtick.
    Backtick,
}

/// A POSIX substitution or subshell that is open while splitting segments.
struct SegmentFrame {
    kind: SegmentFrameKind,
    /// The enclosing segment to resume when this frame closes, with a
    /// placeholder (`$()`, `<()`, `>()`, or ``` `` ```) standing in for the
    /// inner command. `None` for a grouping subshell, which is itself a segment
    /// boundary.
    resume: Option<String>,
    /// Quote state of the enclosing word: command substitution also opens
    /// inside double quotes.
    resume_quote: QuoteState,
    /// Inside `$((...))`, where `<<` is a shift rather than a heredoc.
    arithmetic: bool,
    /// Syntax state of the commands inside this frame.
    nest: SegmentNest,
    /// The enclosing heredoc queue, set aside while a substitution is open.
    /// Bash and dash parse `$(...)` and backticks (and Bash `<(...)`) with
    /// their own heredoc list: a newline inside starts only heredocs opened
    /// inside, and the enclosing ones start at the first newline after the
    /// substitution closes. A newline inside `$((...))` starts none either. A shared queue started the outer heredoc at the inner newline,
    /// swallowed the inner terminator, and then skipped the commands after the
    /// real outer terminator as the inner body. `None` for a grouping
    /// subshell, which shares the enclosing queue just as both shells do.
    outer_heredocs: Option<VecDeque<HeredocDelimiter>>,
    /// The outer frame of `$((`, or of a bare `((` when the shell is bash:
    /// the frame that holds the expression's text until it is confirmed.
    arithmetic_root: bool,
    /// For an arithmetic root: text of the expression, held back until the
    /// frame closes. It runs no command only if the expression is confirmed.
    arithmetic_text: Vec<String>,
    /// For an arithmetic root: whether its first inner group has closed yet.
    first_group_closed: bool,
    /// For an arithmetic root: the second `(` closed with `)` right after it.
    /// Bash then reads arithmetic, and dash reads `$((` as arithmetic always,
    /// so neither runs the text as commands.
    arithmetic_confirmed: bool,
    /// A bare `((` when the shell is not known to be bash. Bash reads
    /// `((...))` as an arithmetic command and dash as nested subshells, so a
    /// `<<` inside is a shift to one and a heredoc to the other.
    double_paren: bool,
}

/// Per-frame syntax that changes what a `)` means. Bash parses a whole
/// substitution before running it, so a `case` pattern's `)` or a `)` inside
/// `${...}` does not close `$(...)`. Treating either as the closer would
/// restore the enclosing quote state and hide the rest of the inner command
/// inside one quoted argument.
#[derive(Debug, Default, Clone, Copy)]
struct SegmentNest {
    /// Open `case` statements, whose pattern terminators are `)`.
    case_depth: usize,
    /// Open `${...}` parameter expansions, where `(` and `)` are literal.
    param_depth: usize,
}

fn segment_nest_mut<'a>(
    frames: &'a mut [SegmentFrame],
    top: &'a mut SegmentNest,
) -> &'a mut SegmentNest {
    match frames.last_mut() {
        Some(frame) => &mut frame.nest,
        None => top,
    }
}

/// Track `case`/`esac` keywords as the word in `current` ends. A keyword only
/// counts in command position: first in the simple command, or after words
/// that can precede a command (`then case`, `coproc case`, `time -p case`).
/// A lone `&` ends a command without ending the segment, so the word after it
/// is in command position too (`true & case`). `esac` also closes an empty
/// `case x in esac`. Missing a `case` lets its pattern `)` close the
/// substitution early, and missing an `esac` hides the real closer. Either
/// restores the enclosing quote over commands the shell runs.
fn note_case_keyword(current: &str, nest: &mut SegmentNest) {
    if !current.ends_with(|c: char| !c.is_whitespace()) {
        return;
    }
    let words: Vec<&str> = current[background_command_start(current)..]
        .split_whitespace()
        .collect();
    let Some((&last, before)) = words.split_last() else {
        return;
    };
    let prefix = match (last, before) {
        ("esac", [prefix @ .., "case", _, "in"]) => prefix,
        _ => before,
    };
    if !is_command_prefix(prefix) {
        return;
    }
    match last {
        "case" => nest.case_depth += 1,
        "esac" => nest.case_depth = nest.case_depth.saturating_sub(1),
        _ => {}
    }
}

/// Whether every word is a reserved word or prefix after which the next word
/// is still in command position.
fn is_command_prefix(words: &[&str]) -> bool {
    let mut previous = None;
    words.iter().all(|&word| {
        let prefix = match word {
            "!" | "{" | "coproc" | "do" | "elif" | "else" | "if" | "then" | "time" | "until"
            | "while" => true,
            // `time -p` and `time -p --` still time a pipeline.
            "-p" | "--" => matches!(previous, Some("time" | "-p")),
            _ => false,
        };
        previous = Some(word);
        prefix
    })
}

/// Byte offset just past the last `&` in `current` that ends a command,
/// rather than one in a redirection (`>&`, `<&`, `&>`) or escaped. A quoted
/// `&` can be mistaken for one, but its closing quote then sits in a word
/// before the keyword, and no command prefix contains a quote.
fn background_command_start(current: &str) -> usize {
    let bytes = current.as_bytes();
    let mut start = 0;
    for (index, &byte) in bytes.iter().enumerate() {
        if byte != b'&' {
            continue;
        }
        let before = index.checked_sub(1).and_then(|i| bytes.get(i));
        let backslashes = bytes[..index]
            .iter()
            .rev()
            .take_while(|&&b| b == b'\\')
            .count();
        if matches!(before, Some(b'>' | b'<'))
            || bytes.get(index + 1) == Some(&b'>')
            || backslashes % 2 == 1
        {
            continue;
        }
        start = index + 1;
    }
    start
}

fn push_segment(segments: &mut Vec<String>, current: &mut String) {
    let trimmed = current.trim();
    if !trimmed.is_empty() {
        segments.push(trimmed.to_string());
    }
    current.clear();
}

fn open_segment_frame(
    frames: &mut Vec<SegmentFrame>,
    segments: &mut Vec<String>,
    current: &mut String,
    quote: &mut QuoteState,
    pending_heredocs: &mut VecDeque<HeredocDelimiter>,
    kind: SegmentFrameKind,
    placeholder: Option<&str>,
    arithmetic: bool,
) {
    let resume = match placeholder {
        Some(placeholder) => {
            let mut resume = std::mem::take(current);
            resume.push_str(placeholder);
            Some(resume)
        }
        None => {
            emit_segment(frames, segments, current);
            None
        }
    };
    // Arithmetic carries into the parentheses of an arithmetic expression,
    // but a command substitution or backtick inside it is ordinary shell
    // syntax again (heredocs included).
    let arithmetic_root = arithmetic;
    let arithmetic = arithmetic
        || (placeholder.is_none() && frames.last().is_some_and(|frame| frame.arithmetic));
    frames.push(SegmentFrame {
        kind,
        resume,
        resume_quote: *quote,
        arithmetic,
        arithmetic_root,
        nest: SegmentNest::default(),
        outer_heredocs: placeholder
            .is_some()
            .then(|| std::mem::take(pending_heredocs)),
        arithmetic_text: Vec::new(),
        first_group_closed: false,
        arithmetic_confirmed: false,
        double_paren: false,
    });
    *quote = QuoteState::None;
}

/// End a segment of text. Inside a `$((` expression the text is held on that
/// frame until the expression is confirmed (see
/// [`SegmentFrame::arithmetic_confirmed`]); everywhere else it is a segment.
fn emit_segment(frames: &mut [SegmentFrame], segments: &mut Vec<String>, current: &mut String) {
    let root = if frames.last().is_some_and(|frame| frame.arithmetic) {
        frames.iter_mut().rev().find(|frame| frame.arithmetic_root)
    } else {
        None
    };
    match root {
        Some(root) => push_segment(&mut root.arithmetic_text, current),
        None => push_segment(segments, current),
    }
}

/// Pop the innermost frame. A `$((` frame's held text becomes segments unless
/// the expression was confirmed as arithmetic.
fn pop_segment_frame(
    frames: &mut Vec<SegmentFrame>,
    segments: &mut Vec<String>,
) -> Option<SegmentFrame> {
    let mut frame = frames.pop()?;
    if !frame.arithmetic_confirmed {
        segments.append(&mut frame.arithmetic_text);
    }
    Some(frame)
}

fn close_segment_frame(
    frames: &mut Vec<SegmentFrame>,
    segments: &mut Vec<String>,
    current: &mut String,
    quote: &mut QuoteState,
    pending_heredocs: &mut VecDeque<HeredocDelimiter>,
) {
    emit_segment(frames, segments, current);
    if let Some(frame) = pop_segment_frame(frames, segments) {
        *current = frame.resume.unwrap_or_default();
        *quote = frame.resume_quote;
        // Heredocs still pending here were opened inside the substitution with
        // no newline after them before it closed, so they have no body. Dash
        // reads them as empty and drops them. Bash carries them out to the
        // next line, so dropping them can only scan lines Bash treats as body,
        // never skip lines it runs.
        if let Some(outer) = frame.outer_heredocs {
            *pending_heredocs = outer;
        }
    }
}

/// Open a backtick substitution. Closing one is handled before quote and
/// comment state, because the shell finds the closer first (see the backtick
/// check in [`split_unquoted_segments_checked`]).
fn open_backtick_frame(
    frames: &mut Vec<SegmentFrame>,
    segments: &mut Vec<String>,
    current: &mut String,
    quote: &mut QuoteState,
    pending_heredocs: &mut VecDeque<HeredocDelimiter>,
) {
    open_segment_frame(
        frames,
        segments,
        current,
        quote,
        pending_heredocs,
        SegmentFrameKind::Backtick,
        Some("``"),
        false,
    );
}

/// Read the delimiter word after `<<` (or `<<-`), copying its raw text into
/// `current` and returning it with quotes and escapes removed.
///
/// The delimiter is one shell word: it ends at unquoted whitespace or a
/// metacharacter, and the rest of the line (`| wc -l`, more redirects, a
/// second `<<B`) is scanned as ordinary command text. Reading to the end of the
/// line instead made a delimiter like `EOF | wc -l` that never matches, so every
/// later command was skipped as heredoc body.
///
/// `None` means this is not a heredoc (`<<$(cmd)`). `Some(Err(()))` means it is
/// a heredoc whose delimiter this scanner cannot prove. Callers must not skip
/// lines in that case: a wrong terminator hides every command after the body.
/// `Some(Ok(delimiter))` is a one-line terminator the body matcher can compare
/// exactly. `strip_tabs` is the `<<-` operator: bash removes leading
/// tabs from the body and from the terminator line before comparing it.
///
/// `in_backtick` means a backtick substitution is open. The shell cuts its
/// text at the next unescaped backtick before parsing it, so that backtick
/// ends the delimiter word. The backslash removal done while cutting is not
/// modeled, so a delimiter with a backslash or backtick there is unproven.
fn read_heredoc_delimiter(
    chars: &mut std::iter::Peekable<std::str::Chars<'_>>,
    current: &mut String,
    backslash_is_literal: bool,
    in_backtick: bool,
    posix_shell: PosixShell,
) -> Option<Result<HeredocDelimiter, ()>> {
    let strip_tabs = if let Some(dash) = chars.next_if_eq(&'-') {
        current.push(dash);
        true
    } else {
        false
    };
    while let Some(blank) = chars.next_if(|ch| matches!(ch, ' ' | '\t')) {
        current.push(blank);
    }
    let mut raw = String::new();
    let mut quote = QuoteState::None;
    let mut ansi_c = false;
    while let Some(&ch) = chars.peek() {
        // Leave the closing backtick to the caller. A quote still open here is
        // reported below as an unfinished delimiter.
        if in_backtick && ch == '`' {
            break;
        }
        // An escape is part of the word, including when the escaped character
        // is itself a word boundary. Checking the boundary first turned
        // `<<E\ OF` into the delimiter `E\` (the space ended the word), which
        // never matches the terminator `E OF` and hides every later command.
        // Inside `$'...'` the backslash is an ANSI-C escape, not a shell
        // escape, so it does not protect the following character from ending
        // the quote.
        if quote == QuoteState::None && ch == '\\' && !backslash_is_literal && !ansi_c {
            chars.next();
            current.push(ch);
            raw.push(ch);
            match chars.peek() {
                // A backslash-newline joins the delimiter (`<<E\<newline>OF`
                // is `EOF`). Record the newline and keep reading the word.
                Some('\n') => {
                    let newline = chars.next().expect("peeked newline");
                    current.push(newline);
                    raw.push(newline);
                }
                // Any other escaped character is part of the word, even when
                // it would otherwise end it (`<<E\ OF` is `E OF`).
                Some(_) => {
                    let escaped = chars.next().expect("peeked escape");
                    current.push(escaped);
                    raw.push(escaped);
                }
                // A backslash at the end of the input is not a join. Leave it
                // in the word so the body scanner does not treat the following
                // line as part of the delimiter.
                None => {}
            }
            continue;
        }
        if quote == QuoteState::None
            && (ch.is_whitespace() || matches!(ch, ';' | '|' | '&' | '<' | '>' | '(' | ')'))
        {
            break;
        }
        chars.next();
        current.push(ch);
        raw.push(ch);
        match (quote, ch) {
            // Recognize `$'...'` / `$"..."` to find where the word ends, even
            // though such a delimiter is refused afterwards. Otherwise
            // `<<$'E\'OF'` is read as an ordinary single-quoted word whose `\'`
            // closes it, and the rest of the command is swallowed into it.
            (QuoteState::None, '$') if matches!(chars.peek(), Some('\'' | '"')) => {
                let opener = chars.next().expect("peeked quote");
                current.push(opener);
                raw.push(opener);
                quote = if opener == '\'' {
                    ansi_c = true;
                    QuoteState::Single
                } else {
                    QuoteState::Double
                };
            }
            (QuoteState::Single, '\'') if !ansi_c => quote = QuoteState::None,
            (QuoteState::Single, '\'') => {
                quote = QuoteState::None;
                ansi_c = false;
            }
            // An escaped `"`, `$`, `` ` ``, or `\` inside double quotes is part
            // of the word, not its closer. Stopping at `\"` turned `<<"E\" F"`
            // into the delimiter `E"`, which never matches `E" F`.
            (QuoteState::Double, '\\') if !backslash_is_literal => {
                if let Some(escaped) = chars.next_if(|next| matches!(next, '$' | '`' | '"' | '\\'))
                {
                    current.push(escaped);
                    raw.push(escaped);
                }
            }
            (QuoteState::Double, '"') => quote = QuoteState::None,
            (QuoteState::None, '\'') => quote = QuoteState::Single,
            (QuoteState::None, '"') => quote = QuoteState::Double,
            // Inside `$'...'`, `\'` is an escaped apostrophe, not the closer.
            (QuoteState::Single, '\\') if ansi_c => {
                if let Some(escaped) = chars.next() {
                    current.push(escaped);
                    raw.push(escaped);
                }
            }
            // A backslash-newline joins the delimiter word before quote removal,
            // quoted or not. Other escapes stay in the raw word for quote
            // removal afterwards.
            (QuoteState::None | QuoteState::Double, '\\')
                if !backslash_is_literal && chars.next_if_eq(&'\n').is_some() =>
            {
                current.push('\n');
                raw.push('\n');
            }
            _ => {}
        }
    }
    if chars.peek() == Some(&'(') {
        // `<<$(cmd)` is a command substitution, not a heredoc.
        return None;
    }
    if quote != QuoteState::None {
        // The opener is a heredoc, but its quote never closed. Do not skip a
        // body against a delimiter this scanner did not finish reading.
        return Some(Err(()));
    }
    if in_backtick && raw.contains(['\\', '`']) {
        return Some(Err(()));
    }
    let Some(delimiter) = remove_heredoc_delimiter_quotes(&raw, posix_shell) else {
        // `$'...'`, `$"..."`, and any other form whose terminator depends on
        // the shell. The opener is still a heredoc. Skipping its lines against a guessed
        // terminator is the bypass, so the caller scans them instead.
        return Some(Err(()));
    };
    // A newline in the delimiter is not a one-line terminator. An empty delimiter is the blank line after `<<''`, and a
    // carriage return can end a physical line. Both are matched before the
    // body line is trimmed.
    if delimiter.contains(&b'\n') {
        return Some(Err(()));
    }
    // A backslash-newline is removed before the word is read, so it is not
    // quoting. `<<E\<newline>OF` is the unquoted delimiter `EOF`, and its body
    // still joins continued lines. Counting that backslash as quoting left the
    // body literal: the scanner waited for a later physical `EOF` and skipped
    // the command bash runs after the joined terminator. A quote, or a
    // backslash that survives the removal, still leaves the body literal.
    let without_continuations = raw.replace("\\\n", "");
    let joins_lines = !without_continuations.contains(['\'', '"', '\\']);
    Some(Ok(HeredocDelimiter {
        terminator: Some(delimiter),
        strip_tabs,
        joins_lines,
    }))
}

/// Apply shell quote removal to a heredoc delimiter word, returning the
/// terminator line's bytes. `None` means the terminator depends on the shell
/// or is not modeled, so no body may be skipped against it.
///
/// `$"..."` is always refused: bash translates it through the locale catalog.
/// `$'...'` depends on the shell. Bash expands it before matching the
/// terminator, while dash (the usual `sh`) has no `$'...'` and ends `<<$'EOF'`
/// at a literal `$EOF` line. Modeling either one hides the commands after the
/// body from the other, so it is refused unless the shell is known to be
/// bash, and then expanded as bash does (see [`expand_bash_ansi_c_quote`]).
fn remove_heredoc_delimiter_quotes(raw: &str, posix_shell: PosixShell) -> Option<Vec<u8>> {
    let mut delimiter = Vec::new();
    let push = |delimiter: &mut Vec<u8>, ch: char| {
        delimiter.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes());
    };
    let mut chars = raw.chars().peekable();
    let mut quote = QuoteState::None;
    while let Some(ch) = chars.next() {
        match (quote, ch) {
            (QuoteState::Single, '\'') | (QuoteState::Double, '"') => quote = QuoteState::None,
            (QuoteState::None, '\'') => quote = QuoteState::Single,
            (QuoteState::None, '"') => quote = QuoteState::Double,
            (QuoteState::None, '$') if chars.next_if_eq(&'\'').is_some() => {
                if posix_shell != PosixShell::Bash {
                    return None;
                }
                expand_bash_ansi_c_quote(&mut chars, &mut delimiter)?;
            }
            (QuoteState::None, '$') if chars.peek() == Some(&'"') => return None,
            // A bare `$` or backtick in a heredoc delimiter is literal. Neither
            // shell expands `<<$EOF`, `<<"$EOF"`, or `<<`echo EOF``. Treating
            // every `$` as an unsupported expansion opened no heredoc, so a
            // quote in the body swallowed the following command.
            (QuoteState::None | QuoteState::Double, '\\') => match chars.next() {
                Some('\n') => {}
                Some(escaped)
                    if quote == QuoteState::None || matches!(escaped, '$' | '`' | '"' | '\\') =>
                {
                    push(&mut delimiter, escaped);
                }
                Some(escaped) => {
                    push(&mut delimiter, '\\');
                    push(&mut delimiter, escaped);
                }
                None => push(&mut delimiter, '\\'),
            },
            _ => push(&mut delimiter, ch),
        }
    }
    Some(delimiter)
}

/// Expand the body of a bash `$'...'` quote in a heredoc delimiter, after the
/// opening `$'`, through its closing `'`. Returns `None` for an escape whose
/// meaning varies, or an unclosed quote.
///
/// Every rule here reads the same in bash 3.2 through 5.3, in normal and
/// POSIX mode, as a heredoc delimiter:
/// - `\a \b \e \E \f \n \r \t \v` are control bytes, and `\\ \' \" \?` the
///   character itself.
/// - `\xH` and `\xHH` are one byte. `\x` with no hex digit stays `\x`.
/// - One to three octal digits are one byte, masked to eight bits (`\777` is
///   `0xff`, `\400` is NUL).
/// - Any other escape (`\q`, `\8`) keeps its backslash.
/// - A NUL byte ends the quoted part: the rest of it is dropped, escapes
///   still apply while finding its end, and text after the quote stays in the
///   delimiter (`$'E\0F'X` is `EX`).
///
/// `\c`, `\u`, and `\U` are refused: `\c?`, `\c\\`, and the Unicode escapes
/// changed meaning between bash 3.2 and 4.x, and `\cA` in a delimiter does
/// not match its expansion as a word. A backslash-newline is refused too.
fn expand_bash_ansi_c_quote(
    chars: &mut std::iter::Peekable<std::str::Chars<'_>>,
    delimiter: &mut Vec<u8>,
) -> Option<()> {
    let mut truncated = false;
    loop {
        let ch = chars.next()?;
        let byte = match ch {
            '\'' => return Some(()),
            '\\' => {
                let escaped = chars.next()?;
                match escaped {
                    'a' => Some(0x07),
                    'b' => Some(0x08),
                    'e' | 'E' => Some(0x1b),
                    'f' => Some(0x0c),
                    'n' => Some(b'\n'),
                    'r' => Some(b'\r'),
                    't' => Some(b'\t'),
                    'v' => Some(0x0b),
                    '\\' | '\'' | '"' | '?' => Some(escaped as u8),
                    'x' => {
                        let mut value: u32 = 0;
                        let mut digits = 0;
                        while digits < 2 {
                            let Some(digit) = chars.next_if(char::is_ascii_hexdigit) else {
                                break;
                            };
                            value = value * 16 + digit.to_digit(16)?;
                            digits += 1;
                        }
                        if digits == 0 {
                            if !truncated {
                                delimiter.extend_from_slice(b"\\x");
                            }
                            None
                        } else {
                            u8::try_from(value).ok()
                        }
                    }
                    '0'..='7' => {
                        let mut value = escaped.to_digit(8)?;
                        let mut digits = 1;
                        while digits < 3 {
                            let Some(digit) = chars.next_if(|next| matches!(next, '0'..='7'))
                            else {
                                break;
                            };
                            value = value * 8 + digit.to_digit(8)?;
                            digits += 1;
                        }
                        u8::try_from(value & 0xff).ok()
                    }
                    'c' | 'u' | 'U' | '\n' => return None,
                    other => {
                        if !truncated {
                            delimiter.push(b'\\');
                            delimiter.extend_from_slice(other.encode_utf8(&mut [0; 4]).as_bytes());
                        }
                        None
                    }
                }
            }
            other => {
                if !truncated {
                    delimiter.extend_from_slice(other.encode_utf8(&mut [0; 4]).as_bytes());
                }
                None
            }
        };
        match byte {
            Some(0) => truncated = true,
            Some(byte) if !truncated => delimiter.push(byte),
            _ => {}
        }
    }
}

/// Split a command into the simple commands a shell would run, so each one
/// can be checked on its own.
///
/// Segments end at unquoted `;`, newlines, `|`, `||`, and `&&`. Under the
/// POSIX dialect, command substitution (`$(...)`, `` `...` ``), process
/// substitution (`<(...)`, `>(...)`), and subshells (`(...)`) are boundaries
/// too: the inner command becomes its own segment, and the enclosing word keeps
/// a `$()`-style placeholder. Otherwise the closing `)` or backtick sticks to
/// the last inner word (`$(ls 2>/dev/null)` yields a `/dev/null)` redirect
/// target), and the inner command hides behind the outer one.
///
/// Every character other than those delimiters lands in a segment, except
/// heredoc bodies and confirmed `$((...))` arithmetic, which both bash and
/// dash read as data. That alone does not mean the checks see the rest. If the
/// scanner closes a substitution where the shell does not, it restores the
/// enclosing quote state, and commands the shell runs end up inside one quoted
/// argument that the checks never look into. The scanner therefore follows
/// the shell where a `)` or backtick is ambiguous (`case` patterns, `${...}`,
/// comments, backtick closers). As a backstop, a scan that ends with a frame,
/// quote, `case`, or `${` still open, or that meets a `)` closing nothing,
/// also returns the flat split that ignores substitutions, the split this
/// function made before it modeled them. That only adds segments to check,
/// so it refuses nothing the flat split accepted. It is not a proof: input
/// crafted to rebalance a misparse is only as safe as the specific rules.
/// Where the shells disagree or no split can bound a heredoc body (`<<` in a
/// bare `((`, a body running to the end inside an open substitution), the
/// split is refused instead.
/// Segments are returned in the order they end, so an inner command comes
/// before the command containing it.
fn split_unquoted_segments_checked(
    command: &str,
    shell: impl Into<ShellGrammar>,
) -> Result<Vec<String>, UnreadableHeredoc> {
    let shell = shell.into();
    let (mut segments, balanced) = scan_unquoted_segments(command, shell, true)?;
    if !balanced {
        let (flat, _) = scan_unquoted_segments(command, shell, false)?;
        segments.extend(flat);
    }
    Ok(segments)
}

/// A heredoc whose delimiter this scanner cannot prove. Its body is data, but
/// the commands after the real terminator still run. Skipping them hides a
/// forbidden path, and parsing them lets a quote in the body swallow the next
/// command. Either guess is a bypass, so the command is refused.
struct UnreadableHeredoc;

fn split_unquoted_segments(command: &str, shell: impl Into<ShellGrammar>) -> Vec<String> {
    split_unquoted_segments_checked(command, shell).unwrap_or_default()
}

/// One pass of [`split_unquoted_segments_checked`]. `model_substitutions`
/// enables the POSIX substitution, subshell, `case`, and comment model. The
/// returned flag is `false` when that model ended unbalanced.
fn scan_unquoted_segments(
    command: &str,
    shell: ShellGrammar,
    model_substitutions: bool,
) -> Result<(Vec<String>, bool), UnreadableHeredoc> {
    let dialect = shell.dialect;
    let mut segments = Vec::new();
    let mut current = String::new();
    let mut quote = QuoteState::None;
    let mut escaped = false;
    let backslash_is_literal = shell_uses_windows_path_syntax(dialect);
    let single_quotes_are_syntax = shell_uses_single_quote_syntax(dialect);
    // `cmd.exe` has no command substitution, and its parenthesized blocks are
    // not modeled here, so only the POSIX dialect splits at these boundaries.
    let posix_substitution = model_substitutions && matches!(dialect, ShellDialect::Posix);
    // A `)` that closed nothing and was not a `case` pattern terminator.
    let mut stray_closer = false;
    let mut frames: Vec<SegmentFrame> = Vec::new();
    // The previous character if it was unescaped syntax outside single quotes,
    // so `(` can tell `$(`, `<(`, and `>(` from a grouping subshell.
    let mut last_syntax_char: Option<char> = None;
    // `case` and `${...}` state outside every frame.
    let mut top_nest = SegmentNest::default();
    // Inside a `#` comment, until the next newline.
    let mut in_comment = false;
    // Heredoc state: Some(delim) while inside a heredoc body. `None` in the
    // pair means the opener is a heredoc whose delimiter this scanner cannot
    // prove. Its body runs to the end of the command, so the text stays data
    // instead of being parsed as shell.
    let mut heredoc_delimiter: Option<HeredocDelimiter> = None;
    // The command-frame depth that owns an unproven heredoc body. The body
    // ends when that frame closes, so it cannot hide the command after a
    // substitution. `None` means the opener was at top level: its body has no
    // frame to close it, so the following lines are scanned with quotes
    // disabled instead of being discarded.
    let mut heredoc_owner: Option<usize> = None;
    // After a top-level heredoc whose delimiter cannot be proven, quotes in
    // the remainder are not syntax. A quote in the body must not join the
    // following command into one word.
    let mut quotes_are_literal = false;
    // Accumulates the current line while inside a heredoc body, for terminator detection.
    let mut heredoc_line_buf = String::new();
    // The joined text of a logical body line whose physical lines so far each
    // ended in a line continuation (unquoted delimiters only).
    // A logical body line in progress (unquoted delimiters only): the joined
    // text of its physical lines so far, each of which ended in a line
    // continuation, and whether dash is still at the start of the line
    // (every line so far was exactly `\`). `None` at the start of a line.
    let mut heredoc_logical_line: Option<(String, bool)> = None;
    // Delimiters of heredocs opened on the current command line, in order.
    // Their bodies start at the next unquoted newline.
    // A substitution sets this queue aside and starts its own (see
    // `SegmentFrame::outer_heredocs`).
    let mut pending_heredocs: VecDeque<HeredocDelimiter> = VecDeque::new();
    // Backslash state for finding a backtick's closer, which ignores quotes,
    // comments, and heredoc bodies (see the backtick check below).
    let mut backtick_escaped = false;
    let mut chars = command.chars().peekable();

    while let Some(ch) = chars.next() {
        let opener = last_syntax_char.take();
        // Bash and dash find the end of a backtick substitution before they
        // parse the text inside: the next backtick not escaped by a backslash
        // closes it, inside a comment, a heredoc body, or a `$(` opened within
        // it. Bash does so inside quotes too, where dash rejects the whole
        // script. Following the inner syntax instead let a comment or quote
        // swallow the closer, so the next backtick restored the enclosing
        // double quote over commands the shell runs.
        if posix_substitution
            && let Some(backtick) = frames
                .iter()
                .rposition(|frame| frame.kind == SegmentFrameKind::Backtick)
        {
            if backtick_escaped {
                backtick_escaped = false;
            } else if ch == '\\' && !backslash_is_literal {
                backtick_escaped = true;
            } else if ch == '`' {
                while frames.len() > backtick {
                    close_segment_frame(
                        &mut frames,
                        &mut segments,
                        &mut current,
                        &mut quote,
                        &mut pending_heredocs,
                    );
                }
                // Comments, heredoc bodies, and escapes inside the backticks
                // end with them.
                in_comment = false;
                escaped = false;
                heredoc_delimiter = None;
                heredoc_logical_line = None;
                heredoc_line_buf.clear();
                if heredoc_owner.is_some_and(|owner| owner >= frames.len()) {
                    heredoc_owner = None;
                }
                continue;
            }
        }
        match quote {
            QuoteState::Single => {
                if ch == '\'' {
                    quote = QuoteState::None;
                }
                current.push(ch);
            }
            QuoteState::Double => {
                if escaped {
                    escaped = false;
                    current.push(ch);
                    continue;
                }
                if ch == '\\' && !backslash_is_literal {
                    escaped = true;
                    current.push(ch);
                    continue;
                }
                if posix_substitution && ch == '(' && opener == Some('$') {
                    let arithmetic = chars.peek() == Some(&'(');
                    open_segment_frame(
                        &mut frames,
                        &mut segments,
                        &mut current,
                        &mut quote,
                        &mut pending_heredocs,
                        SegmentFrameKind::Paren,
                        Some("()"),
                        arithmetic,
                    );
                    continue;
                }
                // No backtick substitution is open here (the check at the top
                // of the loop closes one), so this backtick opens one.
                if posix_substitution && ch == '`' {
                    open_backtick_frame(
                        &mut frames,
                        &mut segments,
                        &mut current,
                        &mut quote,
                        &mut pending_heredocs,
                    );
                    continue;
                }
                if ch == '"' {
                    quote = QuoteState::None;
                } else if ch == '$' {
                    last_syntax_char = Some(ch);
                }
                current.push(ch);
            }
            QuoteState::None => {
                // Heredoc bodies and comments are line-based and come first. A
                // backslash cannot extend a comment past its newline. In the
                // body of an unquoted delimiter it can: the terminator is
                // compared against logical lines (see below).
                if let Some(HeredocDelimiter {
                    terminator: delim,
                    strip_tabs,
                    joins_lines,
                }) = heredoc_delimiter.as_ref()
                {
                    // An unproven delimiter has no terminator this scanner can
                    // match. Bash still treats the following text as body, so
                    // keep it data through the end of the command. Parsing it
                    // lets a quote in the body swallow the next command.
                    if delim.is_none() {
                        match heredoc_owner {
                            // The body belongs to the command frame that was
                            // open when it started. A `)` that closes that
                            // frame is the end of the body, not more body text.
                            Some(owner)
                                if ch == ')'
                                    && frames.len() > owner
                                    && frames.last().is_some_and(|frame| {
                                        frame.kind == SegmentFrameKind::Paren
                                    }) =>
                            {
                                heredoc_delimiter = None;
                                heredoc_logical_line = None;
                                heredoc_line_buf.clear();
                                heredoc_owner = None;
                                close_segment_frame(
                                    &mut frames,
                                    &mut segments,
                                    &mut current,
                                    &mut quote,
                                    &mut pending_heredocs,
                                );
                            }
                            // At top level there is no frame to close the body.
                            // Discarding the rest hides commands bash runs
                            // after the real terminator. End the opaque line at
                            // the next newline and scan what follows, but do
                            // not let a quote in the body join those words.
                            None if ch == '\n' => {
                                heredoc_delimiter = None;
                                heredoc_logical_line = None;
                                heredoc_line_buf.clear();
                                quotes_are_literal = true;
                                push_segment(&mut segments, &mut current);
                            }
                            _ => {}
                        }
                        continue;
                    }
                    if ch == '\n' {
                        // `<<-` removes leading tabs before the comparison, and
                        // nothing else. A tab-only line is therefore the blank
                        // terminator of `<<-''`. Trimming spaces, or ignoring
                        // the dash, misses that terminator and hides the
                        // following command. A carriage return stays part of
                        // the line (`<<$'E\rF'` ends at `E<CR>F`).
                        //
                        // An unquoted delimiter's body is expanded, so a line
                        // ending in an odd number of backslashes continues onto
                        // the next one, and the shells find the terminator
                        // differently (both checked against bash 3.2 to 5.3 and
                        // dash 0.5.12):
                        // - Bash joins the physical lines and compares the
                        //   logical line. `<<-` strips leading tabs from each
                        //   physical line while the joined text is still empty.
                        // - Dash, at the start of a line, skips lines that are
                        //   exactly `\`, strips tabs, and compares the rest of
                        //   that one physical line. It joins nothing else.
                        // Both end at `\` then `EOF`, and neither at `body \`
                        // then `EOF`, where ending let a quote in the real body
                        // swallow a later command. Where only one ends (`EO\`
                        // then `F`), either guess hides the following commands
                        // from the other shell, so the command is refused.
                        let physical = std::mem::take(&mut heredoc_line_buf);
                        let (prefix, dash_at_line_start) =
                            heredoc_logical_line.take().unwrap_or((String::new(), true));
                        let strip = |line: &'_ str| -> String {
                            if *strip_tabs {
                                line.trim_start_matches('\t').to_string()
                            } else {
                                line.to_string()
                            }
                        };
                        let bash_line = if prefix.is_empty() {
                            strip(&physical)
                        } else {
                            physical.clone()
                        };
                        if *joins_lines && ends_with_line_continuation(&bash_line) {
                            let joined = format!("{prefix}{}", &bash_line[..bash_line.len() - 1]);
                            heredoc_logical_line =
                                Some((joined, dash_at_line_start && physical == "\\"));
                            continue;
                        }
                        let bash_ends =
                            delim.as_deref() == Some(format!("{prefix}{bash_line}").as_bytes());
                        let dash_ends = dash_at_line_start
                            && delim.as_deref() == Some(strip(&physical).as_bytes());
                        // Follow bash when it is the shell that runs the command.
                        if bash_ends != dash_ends && shell.posix_shell != PosixShell::Bash {
                            return Err(UnreadableHeredoc);
                        }
                        let ends = bash_ends;
                        if ends {
                            // Terminator line reached. Start the next queued
                            // heredoc body from the same command line, if any.
                            heredoc_delimiter = pending_heredocs.pop_front();
                            push_segment(&mut segments, &mut current);
                        }
                    } else {
                        heredoc_line_buf.push(ch);
                    }
                    continue;
                }

                // A comment runs to the newline. Its text stays in the segment,
                // and separators still split (conservative), but `)`, quotes,
                // backticks, backslashes, and `$(` inside it are not syntax, so
                // a comment cannot close a substitution early or continue past
                // its newline.
                if in_comment {
                    if ch == '\n' {
                        in_comment = false;
                    } else if !matches!(ch, ';' | '|' | '&') {
                        current.push(ch);
                        continue;
                    }
                }

                if escaped {
                    escaped = false;
                    current.push(ch);
                    continue;
                }
                if ch == '\\' && !backslash_is_literal {
                    escaped = true;
                    current.push(ch);
                    continue;
                }

                let in_arithmetic = frames.last().is_some_and(|frame| frame.arithmetic);
                // Arithmetic has no commands, so `case` there is a name.
                if posix_substitution
                    && !in_comment
                    && !in_arithmetic
                    && (ch.is_whitespace() || matches!(ch, ';' | '|' | '&' | ')'))
                {
                    note_case_keyword(&current, segment_nest_mut(&mut frames, &mut top_nest));
                }
                let SegmentNest {
                    case_depth,
                    param_depth,
                } = *segment_nest_mut(&mut frames, &mut top_nest);

                match ch {
                    '#' if posix_substitution
                        && !in_comment
                        && !in_arithmetic
                        && param_depth == 0
                        && (current.trim().is_empty()
                            || opener.is_some_and(char::is_whitespace)) =>
                    {
                        in_comment = true;
                        current.push(ch);
                    }
                    '{' if posix_substitution && opener == Some('$') => {
                        segment_nest_mut(&mut frames, &mut top_nest).param_depth += 1;
                        current.push(ch);
                    }
                    '}' if posix_substitution && param_depth > 0 => {
                        segment_nest_mut(&mut frames, &mut top_nest).param_depth -= 1;
                        current.push(ch);
                    }
                    '\'' if single_quotes_are_syntax && !quotes_are_literal => {
                        quote = QuoteState::Single;
                        current.push(ch);
                    }
                    '"' if !quotes_are_literal => {
                        quote = QuoteState::Double;
                        current.push(ch);
                    }
                    // Separators inside `$((...))` (`&&`, `||`, newlines) end
                    // text held for the expression, not command segments.
                    ';' => emit_segment(&mut frames, &mut segments, &mut current),
                    '\n' => {
                        emit_segment(&mut frames, &mut segments, &mut current);
                        heredoc_delimiter = pending_heredocs.pop_front();
                        heredoc_owner = match heredoc_delimiter.as_ref() {
                            // Top level has no frame. `saturating_sub(1)` on an
                            // empty stack is `Some(0)`, which cannot be told
                            // apart from a body owned by the outermost frame.
                            Some(HeredocDelimiter {
                                terminator: None, ..
                            }) if !frames.is_empty() => Some(frames.len() - 1),
                            _ => None,
                        };
                    }
                    '|' => {
                        if chars.next_if_eq(&'|').is_some() {
                            // Consume full `||`; both characters are separators.
                        }
                        emit_segment(&mut frames, &mut segments, &mut current);
                    }
                    '&' => {
                        if chars.next_if_eq(&'&').is_some() {
                            // `&&` is a separator; single `&` is handled separately.
                            emit_segment(&mut frames, &mut segments, &mut current);
                        } else {
                            current.push(ch);
                        }
                    }
                    '<' => {
                        current.push(ch);
                        // Detect `<<` (heredoc) but not `<<<` (here-string).
                        // Inside `$((...))`, `<<` is a left shift.
                        if chars.peek() == Some(&'<') {
                            if let Some(second) = chars.next() {
                                current.push(second);
                            }
                            if chars.peek() != Some(&'<') && !in_arithmetic {
                                // Inside a bare `((`, `<<` is a shift to bash and a
                                // heredoc to dash. Either reading hides the lines
                                // after it from the other shell.
                                if frames
                                    .iter()
                                    .rev()
                                    .take_while(|frame| frame.resume.is_none())
                                    .any(|frame| frame.double_paren)
                                {
                                    return Err(UnreadableHeredoc);
                                }
                                let in_backtick = frames
                                    .iter()
                                    .any(|frame| frame.kind == SegmentFrameKind::Backtick);
                                match read_heredoc_delimiter(
                                    &mut chars,
                                    &mut current,
                                    backslash_is_literal,
                                    in_backtick,
                                    shell.posix_shell,
                                ) {
                                    // A proven one-line delimiter. Its body is
                                    // data, so it is safe to skip.
                                    Some(Ok(delimiter)) => pending_heredocs.push_back(delimiter),
                                    // The opener is a heredoc, but its delimiter
                                    // uses syntax this scanner cannot prove
                                    // (`$"..."`, an unclosed quote, a newline
                                    // inside the word). There is no safe body
                                    // boundary to guess, so refuse the command.
                                    Some(Err(())) => return Err(UnreadableHeredoc),
                                    // Not a heredoc (`<<$(cmd)`). The following
                                    // text is ordinary command text.
                                    None => {}
                                }
                            }
                            // `<<<` falls through with no heredoc tracking.
                        } else {
                            last_syntax_char = Some(ch);
                        }
                    }
                    // Inside `${...}` only `$(` opens a frame; other parentheses
                    // are literal pattern text (`${x/)/y}`).
                    '(' if posix_substitution && (param_depth == 0 || opener == Some('$')) => {
                        match opener {
                            Some('$') => {
                                let arithmetic = chars.peek() == Some(&'(');
                                open_segment_frame(
                                    &mut frames,
                                    &mut segments,
                                    &mut current,
                                    &mut quote,
                                    &mut pending_heredocs,
                                    SegmentFrameKind::Paren,
                                    Some("()"),
                                    arithmetic,
                                );
                            }
                            Some('<' | '>') => open_segment_frame(
                                &mut frames,
                                &mut segments,
                                &mut current,
                                &mut quote,
                                &mut pending_heredocs,
                                SegmentFrameKind::Paren,
                                Some("()"),
                                false,
                            ),
                            // A subshell, or other `(` syntax (`f()`, `arr=(...)`)
                            // that is still a word boundary. A bare `((` is an
                            // arithmetic command to bash (with the same `))`
                            // test as `$((`) and nested subshells to dash.
                            _ => {
                                let double_paren = chars.peek() == Some(&'(')
                                    && !frames.last().is_some_and(|frame| frame.arithmetic);
                                let bash_arithmetic =
                                    double_paren && shell.posix_shell == PosixShell::Bash;
                                open_segment_frame(
                                    &mut frames,
                                    &mut segments,
                                    &mut current,
                                    &mut quote,
                                    &mut pending_heredocs,
                                    SegmentFrameKind::Paren,
                                    None,
                                    bash_arithmetic,
                                );
                                if double_paren
                                    && !bash_arithmetic
                                    && let Some(frame) = frames.last_mut()
                                {
                                    frame.double_paren = true;
                                }
                            }
                        }
                    }
                    ')' if posix_substitution && param_depth == 0 => {
                        if case_depth == 0
                            && frames
                                .last()
                                .is_some_and(|frame| frame.kind == SegmentFrameKind::Paren)
                        {
                            // Closing the first group of an arithmetic root. If
                            // `)` follows at once, the expression is arithmetic.
                            let group_of_root = frames.len() >= 2
                                && frames.last().is_some_and(|frame| {
                                    frame.arithmetic && !frame.arithmetic_root
                                });
                            if group_of_root
                                && let Some(root) = frames.iter_mut().rev().nth(1)
                                && root.arithmetic_root
                                && !root.first_group_closed
                            {
                                root.first_group_closed = true;
                                root.arithmetic_confirmed = chars.peek() == Some(&')');
                            }
                            close_segment_frame(
                                &mut frames,
                                &mut segments,
                                &mut current,
                                &mut quote,
                                &mut pending_heredocs,
                            );
                            // An unproven heredoc body belongs to the command
                            // frame that was just closed. Continuing it would
                            // hide the command after the substitution.
                            if heredoc_owner == Some(frames.len()) {
                                heredoc_delimiter = None;
                                heredoc_logical_line = None;
                                heredoc_line_buf.clear();
                                heredoc_owner = None;
                            }
                        } else {
                            // A `case` pattern terminator, or an unmatched `)`,
                            // ends the word before it without closing a frame.
                            stray_closer |= case_depth == 0;
                            push_segment(&mut segments, &mut current);
                        }
                    }
                    // No backtick substitution is open here (the check at the
                    // top of the loop closes one), so this backtick opens one.
                    '`' if posix_substitution => {
                        open_backtick_frame(
                            &mut frames,
                            &mut segments,
                            &mut current,
                            &mut quote,
                            &mut pending_heredocs,
                        );
                    }
                    _ => {
                        last_syntax_char = Some(ch);
                        current.push(ch);
                    }
                }
            }
        }
    }

    // A keyword at the very end (`...; esac`) has no delimiter after it.
    if posix_substitution
        && quote == QuoteState::None
        && !in_comment
        && !escaped
        && heredoc_delimiter.is_none()
    {
        note_case_keyword(&current, segment_nest_mut(&mut frames, &mut top_nest));
    }
    push_segment(&mut segments, &mut current);
    // Valid shell ends with every substitution, quote, `case`, and `${`
    // closed. Anything else means this model diverged from the shell's.
    let balanced = !posix_substitution
        || (!stray_closer
            && frames.is_empty()
            && quote == QuoteState::None
            && top_nest.case_depth == 0
            && top_nest.param_depth == 0);
    // A heredoc body that runs to the end inside an open substitution may
    // have swallowed its closer: bash ends a body at `EOF)` there and runs the
    // rest. Neither split can tell where commands resume, so refuse.
    if posix_substitution && heredoc_delimiter.is_some() && !frames.is_empty() {
        return Err(UnreadableHeredoc);
    }
    // Flush the enclosing text of any substitution left open, so an
    // unterminated `$(` cannot hide the command around it.
    while let Some(frame) = pop_segment_frame(&mut frames, &mut segments) {
        if let Some(mut resume) = frame.resume {
            push_segment(&mut segments, &mut resume);
        }
    }

    Ok((segments, balanced))
}

#[derive(Clone, Copy)]
struct RedirectionMetadata {
    marker_idx: usize,
    operator_end: usize,
    has_attached_word: bool,
    prefix_is_unquoted: bool,
    has_multiple_operators: bool,
}

struct ShellWord {
    text: String,
    is_assignment: bool,
    redirection: Option<RedirectionMetadata>,
}

fn split_shell_words_with_metadata(segment: &str, dialect: ShellDialect) -> Vec<ShellWord> {
    let backslash_is_literal = shell_uses_windows_path_syntax(dialect);
    let single_quotes_are_syntax = shell_uses_single_quote_syntax(dialect);
    let mut words = Vec::new();
    let mut current = String::new();
    let mut is_assignment = false;
    let mut assignment_prefix_is_unquoted = true;
    let mut word_prefix_is_unquoted = true;
    let mut redirection: Option<RedirectionMetadata> = None;
    let mut quote = QuoteState::None;
    let mut escaped = false;
    let mut in_word = false;

    let push_word = |words: &mut Vec<ShellWord>,
                     current: &mut String,
                     is_assignment: &mut bool,
                     assignment_prefix_is_unquoted: &mut bool,
                     word_prefix_is_unquoted: &mut bool,
                     redirection: &mut Option<RedirectionMetadata>,
                     in_word: &mut bool| {
        if *in_word {
            words.push(ShellWord {
                text: std::mem::take(current),
                is_assignment: *is_assignment,
                redirection: redirection.take(),
            });
            *is_assignment = false;
            *assignment_prefix_is_unquoted = true;
            *word_prefix_is_unquoted = true;
            *in_word = false;
        }
    };

    for ch in segment.chars() {
        match quote {
            QuoteState::Single => {
                if ch == '\'' {
                    quote = QuoteState::None;
                } else {
                    current.push(ch);
                    in_word = true;
                }
            }
            QuoteState::Double => {
                if escaped {
                    if matches!(ch, '$' | '`' | '"' | '\\') {
                        current.push(ch);
                    } else if ch != '\n' {
                        current.push('\\');
                        current.push(ch);
                    }
                    escaped = false;
                    if !is_assignment {
                        assignment_prefix_is_unquoted = false;
                    }
                    if redirection.is_none() {
                        word_prefix_is_unquoted = false;
                    }
                    if let Some(redirection) = &mut redirection {
                        redirection.has_attached_word = true;
                    }
                    in_word = true;
                    continue;
                }
                match ch {
                    '\\' if backslash_is_literal => {
                        if let Some(redirection) = &mut redirection {
                            redirection.has_attached_word = true;
                        }
                        current.push(ch);
                        in_word = true;
                    }
                    '\\' => {
                        escaped = true;
                        in_word = true;
                    }
                    '"' => quote = QuoteState::None,
                    _ => {
                        current.push(ch);
                        in_word = true;
                    }
                }
            }
            QuoteState::None => {
                if escaped {
                    current.push(ch);
                    escaped = false;
                    if !is_assignment {
                        assignment_prefix_is_unquoted = false;
                    }
                    if redirection.is_none() {
                        word_prefix_is_unquoted = false;
                    }
                    if let Some(redirection) = &mut redirection {
                        redirection.has_attached_word = true;
                    }
                    in_word = true;
                    continue;
                }
                match ch {
                    '\\' if backslash_is_literal => {
                        if let Some(redirection) = &mut redirection {
                            redirection.has_attached_word = true;
                        }
                        current.push(ch);
                        in_word = true;
                    }
                    '\\' => {
                        if let Some(redirection) = &mut redirection {
                            redirection.has_attached_word = true;
                        } else {
                            word_prefix_is_unquoted = false;
                        }
                        escaped = true;
                        in_word = true;
                    }
                    '\'' if single_quotes_are_syntax => {
                        if !is_assignment {
                            assignment_prefix_is_unquoted = false;
                        }
                        if let Some(redirection) = &mut redirection {
                            redirection.has_attached_word = true;
                        } else {
                            word_prefix_is_unquoted = false;
                        }
                        quote = QuoteState::Single;
                        in_word = true;
                    }
                    '"' => {
                        if !is_assignment {
                            assignment_prefix_is_unquoted = false;
                        }
                        if let Some(redirection) = &mut redirection {
                            redirection.has_attached_word = true;
                        } else {
                            word_prefix_is_unquoted = false;
                        }
                        quote = QuoteState::Double;
                        in_word = true;
                    }
                    _ if ch.is_whitespace() => {
                        push_word(
                            &mut words,
                            &mut current,
                            &mut is_assignment,
                            &mut assignment_prefix_is_unquoted,
                            &mut word_prefix_is_unquoted,
                            &mut redirection,
                            &mut in_word,
                        );
                    }
                    _ => {
                        if ch == '=' && !is_assignment && assignment_prefix_is_unquoted {
                            is_assignment = normalized_assignment_name(&current).is_some();
                        }
                        if matches!(ch, '<' | '>') {
                            match &mut redirection {
                                Some(redirection)
                                    if !redirection.has_attached_word
                                        && current.len() == redirection.operator_end =>
                                {
                                    redirection.operator_end += ch.len_utf8();
                                }
                                None => {
                                    redirection = Some(RedirectionMetadata {
                                        marker_idx: current.len(),
                                        operator_end: current.len() + ch.len_utf8(),
                                        has_attached_word: false,
                                        prefix_is_unquoted: word_prefix_is_unquoted,
                                        has_multiple_operators: false,
                                    });
                                }
                                Some(redirection) => {
                                    redirection.has_multiple_operators = true;
                                    redirection.has_attached_word = true;
                                }
                            }
                        } else if let Some(redirection) = &mut redirection {
                            redirection.has_attached_word = true;
                        }
                        current.push(ch);
                        in_word = true;
                    }
                }
            }
        }
    }

    if escaped {
        current.push('\\');
    }
    push_word(
        &mut words,
        &mut current,
        &mut is_assignment,
        &mut assignment_prefix_is_unquoted,
        &mut word_prefix_is_unquoted,
        &mut redirection,
        &mut in_word,
    );
    words
}

fn shell_words_after_env_assignments(segment: &str, dialect: ShellDialect) -> Vec<ShellWord> {
    let words = split_shell_words_with_metadata(segment, dialect);
    let first_command = words
        .iter()
        .position(|word| !word.is_assignment)
        .unwrap_or(words.len());
    words.into_iter().skip(first_command).collect()
}

struct NormalizedShellCommand {
    has_leading_env_assignment: bool,
    words: Vec<String>,
    has_ambiguous_redirection: bool,
}

fn normalized_shell_command(segment: &str, dialect: ShellDialect) -> NormalizedShellCommand {
    let raw_words = split_shell_words_with_metadata(segment, dialect);
    let mut has_leading_env_assignment = false;
    let mut words = Vec::with_capacity(raw_words.len());
    let mut has_ambiguous_redirection = false;
    let mut before_executable = true;
    let mut idx = 0;

    while idx < raw_words.len() {
        let raw = raw_words[idx].text.as_str();
        if before_executable && raw_words[idx].is_assignment {
            has_leading_env_assignment = true;
            idx += 1;
            continue;
        }

        let redirection_metadata = raw_words[idx].redirection;
        if redirection_metadata.is_some_and(|metadata| metadata.has_multiple_operators) {
            has_ambiguous_redirection = true;
        }
        let redirection = redirection_metadata.map_or(RedirectionArgument::None, |metadata| {
            parse_redirection_argument_at(raw, metadata)
        });
        let (prefix, consumes_next) = match redirection {
            RedirectionArgument::Target { prefix, .. } | RedirectionArgument::FdOnly { prefix } => {
                (prefix, false)
            }
            RedirectionArgument::NeedsNextToken { prefix } => (prefix, true),
            RedirectionArgument::None => {
                words.push(raw_words[idx].text.clone());
                before_executable = false;
                idx += 1;
                continue;
            }
        };

        let is_io_number = !prefix.is_empty()
            && prefix.chars().all(|c| c.is_ascii_digit())
            && redirection_metadata.is_some_and(|metadata| metadata.prefix_is_unquoted);
        if !prefix.is_empty() && !is_io_number {
            words.push(prefix.to_string());
            before_executable = false;
        }
        idx += if consumes_next { 2 } else { 1 };
    }

    NormalizedShellCommand {
        has_leading_env_assignment,
        words,
        has_ambiguous_redirection,
    }
}

fn is_git_write_verb(verb: &str) -> bool {
    matches!(
        verb.to_ascii_lowercase().as_str(),
        "am" | "commit"
            | "push"
            | "pull"
            | "reset"
            | "clean"
            | "rebase"
            | "merge"
            | "cherry-pick"
            | "revert"
            | "branch"
            | "checkout"
            | "switch"
            | "tag"
            // Index and working-tree mutations. These are conservatively gated
            // to medium risk; read-only subcommands such as `git stash list` are
            // over-approved in the safe direction rather than parsed further.
            | "add"
            | "rm"
            | "mv"
            | "restore"
            | "apply"
            | "stash"
    )
}

fn git_command_is_write(args: &[String]) -> bool {
    let Some(subcommand_idx) = git_effective_subcommand_index(args) else {
        return false;
    };
    let subcommand = args[subcommand_idx].as_str();
    if is_git_write_verb(subcommand) {
        return true;
    }

    match subcommand.to_ascii_lowercase().as_str() {
        "archive" => {
            if git_args_before_pathspec(args, subcommand_idx + 1).any(|arg| {
                arg.starts_with("-o") || git_arg_is_long_option_or_abbreviation(arg, "--output")
            }) {
                return true;
            }
        }
        "bundle" => {
            if git_first_non_option_before_pathspec(args, subcommand_idx + 1)
                .is_some_and(|action| git_arg_eq(action, "create"))
            {
                return true;
            }
        }
        "diff" | "diff-tree" | "diff-files" | "diff-index" | "log" | "show" | "whatchanged" => {
            if git_args_before_pathspec(args, subcommand_idx + 1)
                .any(|arg| git_arg_is_long_option_or_abbreviation(arg, "--output"))
            {
                return true;
            }
        }
        "fsck" => {
            // `git fsck --lost-found` writes recovered objects into
            // `.git/lost-found/`, so it mutates the repository despite `fsck`
            // being a read by default.
            if git_args_before_pathspec(args, subcommand_idx + 1)
                .any(|arg| git_arg_is_long_option_or_abbreviation(arg, "--lost-found"))
            {
                return true;
            }
        }
        "format-patch" => return true,
        _ => {}
    }

    git_arg_eq(subcommand, "worktree")
        && git_first_non_option_before_pathspec(args, subcommand_idx + 1)
            .is_some_and(|action| !git_arg_eq(action, "list"))
}

fn git_effective_subcommand_index(args: &[String]) -> Option<usize> {
    let mut idx = 0;
    while idx < args.len() {
        let arg = args[idx].as_str();

        match arg {
            "--" => return args.get(idx + 1).map(|_| idx + 1),
            // Global options whose value is a separate following token. Git
            // consumes that token as the option value, so the real subcommand is
            // the token after it. Missing any of these lets a value that
            // resembles a read verb hide the actual (possibly mutating)
            // subcommand from the approval classifier: `git --attr-source log
            // commit` runs `commit`, not `log`. `-c`/`--config-env` also take a
            // separate value and are included so this resolver is correct on its
            // own, independent of the allowlist gate that separately rejects
            // them.
            "-C" | "--git-dir" | "--work-tree" | "--namespace" | "--exec-path"
            | "--super-prefix" | "--attr-source" | "-c" | "--config-env" => {
                idx += 2;
            }
            "--bare"
            | "--no-replace-objects"
            | "--no-lazy-fetch"
            | "--no-optional-locks"
            | "--literal-pathspecs"
            | "--glob-pathspecs"
            | "--noglob-pathspecs"
            | "--icase-pathspecs"
            | "--no-pager"
            | "--paginate"
            | "--version"
            | "--help"
            | "-h"
            | "-p" => {
                idx += 1;
            }
            _ if arg.starts_with("-C") && arg.len() > 2 => {
                idx += 1;
            }
            _ if arg.starts_with("--git-dir=")
                || arg.starts_with("--work-tree=")
                || arg.starts_with("--namespace=")
                || arg.starts_with("--exec-path=")
                || arg.starts_with("--super-prefix=")
                || arg.starts_with("--attr-source=")
                || arg.starts_with("--config-env=") =>
            {
                idx += 1;
            }
            _ if arg.starts_with('-') => {
                idx += 1;
            }
            _ => return Some(idx),
        }
    }

    None
}

fn git_subcommand_is_policy_modeled(subcommand: &str) -> bool {
    if subcommand.bytes().any(|byte| byte.is_ascii_uppercase()) {
        return false;
    }

    is_git_write_verb(subcommand)
        || matches!(
            subcommand,
            "add"
                | "apply"
                | "archive"
                | "bisect"
                | "blame"
                | "bundle"
                | "cat-file"
                | "check-attr"
                | "check-ignore"
                | "check-mailmap"
                | "check-ref-format"
                | "clone"
                | "count-objects"
                | "describe"
                | "diff"
                | "diff-files"
                | "diff-index"
                | "diff-tree"
                | "fetch"
                | "for-each-ref"
                | "format-patch"
                | "fsck"
                | "gc"
                | "grep"
                | "help"
                | "init"
                | "log"
                | "ls-files"
                | "ls-remote"
                | "ls-tree"
                | "maintenance"
                | "merge-base"
                | "merge-tree"
                | "mv"
                | "name-rev"
                | "notes"
                | "range-diff"
                | "reflog"
                | "remote"
                | "restore"
                | "rev-list"
                | "rev-parse"
                | "rm"
                | "shortlog"
                | "show"
                | "show-branch"
                | "show-ref"
                | "sparse-checkout"
                | "stash"
                | "status"
                | "submodule"
                | "verify-commit"
                | "verify-tag"
                | "version"
                | "whatchanged"
                | "worktree"
        )
}

fn git_delegates_to_external_command(args: &[String]) -> bool {
    let Some(subcommand_idx) = git_effective_subcommand_index(args) else {
        return args
            .iter()
            .take_while(|arg| arg.as_str() != "--")
            .any(|arg| git_arg_is_paginate(arg) || git_arg_is_external_diff_option(arg));
    };

    if args[..subcommand_idx]
        .iter()
        .take_while(|arg| arg.as_str() != "--")
        .any(|arg| git_arg_is_paginate(arg) || git_arg_is_external_diff_option(arg))
    {
        return true;
    }

    let subcommand = args[subcommand_idx].as_str();
    if !git_subcommand_is_policy_modeled(subcommand) {
        return true;
    }

    if git_subcommand_selects_remote_helper(args, subcommand_idx, subcommand) {
        return true;
    }
    if git_subcommand_selects_transfer_program(args, subcommand_idx, subcommand) {
        return true;
    }
    let subcommand_args = || git_args_before_pathspec(args, subcommand_idx + 1);
    if (git_arg_eq(subcommand, "clone") && subcommand_args().any(git_arg_is_clone_process_control))
        || (git_arg_eq(subcommand, "init")
            && subcommand_args().any(git_arg_is_template_process_control))
        || (git_arg_eq(subcommand, "rebase")
            && subcommand_args().any(git_arg_is_rebase_process_control))
    {
        return true;
    }

    if git_arg_eq(subcommand, "difftool")
        || git_arg_eq(subcommand, "difftool--helper")
        || git_arg_eq(subcommand, "mergetool")
        || git_arg_eq(subcommand, "mergetool--helper")
        || git_arg_eq(subcommand, "submodule--helper")
    {
        return true;
    }

    if git_args_before_pathspec(args, subcommand_idx + 1).any(git_arg_is_external_diff_option) {
        return true;
    }

    match subcommand.to_ascii_lowercase().as_str() {
        "bisect" => git_first_non_option_before_pathspec(args, subcommand_idx + 1)
            .is_some_and(|arg| git_arg_eq(arg, "run")),
        "submodule" => git_first_non_option_before_pathspec(args, subcommand_idx + 1)
            .is_some_and(|arg| git_arg_eq(arg, "foreach")),
        "grep" => {
            git_args_before_pathspec(args, subcommand_idx + 1).any(git_arg_opens_files_in_pager)
        }
        "help" => git_args_before_pathspec(args, subcommand_idx + 1).any(|arg| {
            git_arg_eq(arg, "-w") || git_arg_is_long_option_or_abbreviation(arg, "--web")
        }),
        _ => false,
    }
}

fn git_args_before_pathspec(args: &[String], start: usize) -> impl Iterator<Item = &str> {
    args[start..]
        .iter()
        .map(String::as_str)
        .take_while(|arg| *arg != "--")
}

fn git_first_non_option_before_pathspec(args: &[String], start: usize) -> Option<&str> {
    git_args_before_pathspec(args, start).find(|arg| !arg.starts_with('-'))
}

fn git_arg_eq(arg: &str, expected: &str) -> bool {
    arg.eq_ignore_ascii_case(expected)
}

fn git_arg_starts_with(arg: &str, prefix: &str) -> bool {
    arg.get(..prefix.len())
        .is_some_and(|candidate| candidate.eq_ignore_ascii_case(prefix))
}

fn git_arg_is_paginate(arg: &str) -> bool {
    git_arg_eq(arg, "-p") || git_arg_eq(arg, "--paginate")
}

fn git_arg_is_external_diff_option(arg: &str) -> bool {
    git_arg_is_long_option_or_abbreviation(arg, "--ext-diff")
        || git_arg_eq(arg, "--extcmd")
        || git_arg_starts_with(arg, "--extcmd=")
}

fn git_subcommand_selects_transfer_program(
    args: &[String],
    subcommand_idx: usize,
    subcommand: &str,
) -> bool {
    let args = || git_args_before_pathspec(args, subcommand_idx + 1);
    match subcommand {
        "clone" | "fetch" | "ls-remote" | "pull" => {
            args().any(|arg| git_arg_is_long_option_or_abbreviation(arg, "--upload-pack"))
        }
        "push" => args().any(|arg| {
            git_arg_is_long_option_or_abbreviation(arg, "--receive-pack")
                || git_arg_is_long_option_or_abbreviation(arg, "--exec")
        }),
        "archive" => args().any(|arg| git_arg_is_long_option_or_abbreviation(arg, "--exec")),
        _ => false,
    }
}

fn git_arg_is_clone_process_control(arg: &str) -> bool {
    git_arg_is_long_option_or_abbreviation(arg, "--config")
        || git_arg_is_template_process_control(arg)
        || git_arg_eq(arg, "-u")
        || git_arg_starts_with(arg, "-u")
}

fn git_arg_is_template_process_control(arg: &str) -> bool {
    git_arg_is_long_option_or_abbreviation(arg, "--template")
}

fn git_arg_is_rebase_process_control(arg: &str) -> bool {
    git_arg_is_long_option_or_abbreviation(arg, "--exec")
        || arg
            .strip_prefix('-')
            .is_some_and(|options| !options.starts_with('-') && options.contains('x'))
}

fn git_arg_is_long_option_or_abbreviation(arg: &str, option: &str) -> bool {
    let supplied_name = arg.split_once('=').map_or(arg, |(name, _)| name);
    supplied_name.len() > 2 && option.starts_with(supplied_name)
}

fn git_arg_selects_remote_helper(arg: &str) -> bool {
    let endpoint = arg
        .split_once('=')
        .filter(|(name, _)| git_arg_is_long_option_or_abbreviation(name, "--remote"))
        .map_or(arg, |(_, value)| value);
    if endpoint
        .split_once("::")
        .is_some_and(|(transport, address)| {
            git_remote_helper_transport_is_valid(transport) && !address.is_empty()
        })
    {
        return true;
    }

    let Some((scheme, address)) = endpoint.split_once("://") else {
        return false;
    };
    git_remote_helper_transport_is_valid(scheme)
        && !address.is_empty()
        && ![
            "file", "ftp", "ftps", "git", "git+ssh", "http", "https", "rsync", "ssh", "ssh+git",
        ]
        .iter()
        .any(|known| scheme.eq_ignore_ascii_case(known))
}

fn git_remote_helper_transport_is_valid(transport: &str) -> bool {
    let mut chars = transport.chars();
    chars
        .next()
        .is_some_and(|first| first.is_ascii_alphanumeric())
        && chars.all(|ch| ch.is_ascii_alphanumeric() || matches!(ch, '+' | '-' | '.'))
}

fn git_subcommand_selects_remote_helper(
    args: &[String],
    subcommand_idx: usize,
    subcommand: &str,
) -> bool {
    let command_args = &args[subcommand_idx + 1..];
    if subcommand == "archive" {
        return git_archive_remote_selects_helper(command_args);
    }

    let scans_remote = match subcommand {
        "clone" | "fetch" | "ls-remote" | "pull" | "push" => true,
        "remote" | "submodule" => git_first_non_option_before_pathspec(args, subcommand_idx + 1)
            .is_some_and(|action| git_arg_eq(action, "add") || git_arg_eq(action, "set-url")),
        _ => false,
    };
    scans_remote
        && command_args.iter().enumerate().any(|(idx, arg)| {
            git_arg_selects_remote_helper(arg)
                && !git_helper_like_arg_is_inert_value(command_args, idx, subcommand)
        })
}

fn git_helper_like_arg_is_inert_value(args: &[String], idx: usize, subcommand: &str) -> bool {
    match (subcommand, args) {
        ("clone", [source, _]) if idx == 1 => git_arg_is_known_safe_remote_url(source),
        ("submodule", [action, source, _]) if idx == 2 && git_arg_eq(action, "add") => {
            git_arg_is_known_safe_remote_url(source)
        }
        _ => false,
    }
}

fn git_arg_is_known_safe_remote_url(arg: &str) -> bool {
    let Some((scheme, address)) = arg.split_once("://") else {
        return false;
    };
    !address.is_empty()
        && [
            "file", "ftp", "ftps", "git", "git+ssh", "http", "https", "rsync", "ssh", "ssh+git",
        ]
        .iter()
        .any(|known| scheme.eq_ignore_ascii_case(known))
}

fn git_archive_remote_selects_helper(args: &[String]) -> bool {
    let mut idx = 0;
    while let Some(arg) = args.get(idx).map(String::as_str) {
        if arg == "--" {
            return false;
        }
        if let Some((name, value)) = arg.split_once('=')
            && git_arg_is_long_option_or_abbreviation(name, "--remote")
            && git_arg_selects_remote_helper(value)
        {
            return true;
        }
        if !arg.contains('=') && git_arg_is_long_option_or_abbreviation(arg, "--remote") {
            match args.get(idx + 1).map(String::as_str) {
                Some(value) if git_arg_selects_remote_helper(value) => return true,
                _ => {}
            }
            idx += 2;
        } else {
            idx += 1;
        }
    }
    false
}

fn git_arg_opens_files_in_pager(arg: &str) -> bool {
    if git_arg_is_long_option_or_abbreviation(arg, "--open-files-in-pager") {
        return true;
    }
    // `git grep -O[<pager>]` opens matches in a pager (external command), even
    // when clustered behind other short flags (e.g. `-nO`). The scan is
    // case-sensitive: `-o` is `--only-matching`, a read. Stop at the first
    // value-consuming short option so its argument is not misread as flags.
    let Some(short_run) = arg.strip_prefix('-').filter(|run| !run.starts_with('-')) else {
        return false;
    };
    for ch in short_run.chars() {
        match ch {
            'O' => return true,
            // Options whose value consumes the remainder of the run (or the
            // next argument): `-A`/`-B`/`-C` (context), `-e`/`-f` (patterns),
            // `-m` (max-count), and any glued `=value`.
            'A' | 'B' | 'C' | 'e' | 'f' | 'm' | '=' => return false,
            _ => {}
        }
    }
    false
}

/// Detect a single unquoted `&` operator (background/chain). `&&` is allowed.
/// Strip fd-merge redirect patterns (`N>&M`, `N<&M`, `>&N`, `<&N`, `N>&-`, etc.)
/// so their `&` doesn't get flagged as a background operator.
fn strip_fd_merge_redirects(command: &str) -> String {
    use std::sync::OnceLock;
    // Matches patterns like: 2>&1, 1>&2, >&2, <&0, 2<&-, >&-
    static FD_MERGE_RE: OnceLock<regex::Regex> = OnceLock::new();
    let re = FD_MERGE_RE.get_or_init(|| {
        regex::Regex::new(r"\d*[><]&[\d-]").expect("FD_MERGE_RE regex must compile")
    });
    re.replace_all(command, "").to_string()
}

/// We treat any standalone `&` as unsafe in policy validation because it can
/// chain hidden sub-commands and escape foreground timeout expectations.
fn contains_unquoted_single_ampersand(command: &str, dialect: ShellDialect) -> bool {
    let mut quote = QuoteState::None;
    let mut escaped = false;
    let mut chars = command.chars().peekable();
    let backslash_is_literal = shell_uses_windows_path_syntax(dialect);
    let single_quotes_are_syntax = shell_uses_single_quote_syntax(dialect);

    while let Some(ch) = chars.next() {
        match quote {
            QuoteState::Single => {
                if ch == '\'' {
                    quote = QuoteState::None;
                }
            }
            QuoteState::Double => {
                if escaped {
                    escaped = false;
                    continue;
                }
                if ch == '\\' && !backslash_is_literal {
                    escaped = true;
                    continue;
                }
                if ch == '"' {
                    quote = QuoteState::None;
                }
            }
            QuoteState::None => {
                if escaped {
                    escaped = false;
                    continue;
                }
                if ch == '\\' && !backslash_is_literal {
                    escaped = true;
                    continue;
                }
                match ch {
                    '\'' if single_quotes_are_syntax => quote = QuoteState::Single,
                    '"' => quote = QuoteState::Double,
                    // This must consume the second '&' so `&&` is not later
                    // re-read as a lone trailing '&'.
                    '&' if chars.next_if_eq(&'&').is_none() => {
                        return true;
                    }
                    _ => {}
                }
            }
        }
    }

    false
}

/// Detect an unquoted character in a shell command.
fn contains_unquoted_char(command: &str, target: char, dialect: ShellDialect) -> bool {
    let mut quote = QuoteState::None;
    let mut escaped = false;
    let backslash_is_literal = shell_uses_windows_path_syntax(dialect);
    let single_quotes_are_syntax =
        matches!(dialect, ShellDialect::Posix | ShellDialect::PowerShell);

    for ch in command.chars() {
        match quote {
            QuoteState::Single => {
                if ch == '\'' {
                    quote = QuoteState::None;
                }
            }
            QuoteState::Double => {
                if escaped {
                    escaped = false;
                    continue;
                }
                if ch == '\\' && !backslash_is_literal {
                    escaped = true;
                    continue;
                }
                if ch == '"' {
                    quote = QuoteState::None;
                }
            }
            QuoteState::None => {
                if escaped {
                    escaped = false;
                    continue;
                }
                if ch == '\\' && !backslash_is_literal {
                    escaped = true;
                    continue;
                }
                match ch {
                    '\'' if single_quotes_are_syntax => quote = QuoteState::Single,
                    '"' => quote = QuoteState::Double,
                    _ if ch == target => return true,
                    _ => {}
                }
            }
        }
    }

    false
}

/// Returns true if `command` contains an unquoted `>` that is NOT a safe
/// stderr form (`2>/dev/null`, `2>&1`).
fn contains_unsafe_output_redirect_for_shell(command: &str, dialect: ShellDialect) -> bool {
    // Strip safe redirect-to-dev patterns (with word boundary enforcement),
    // then fd-merge patterns, then check for remaining `>`.
    use regex::Regex;
    use std::sync::OnceLock;

    static SAFE_OUTPUT_RE: OnceLock<Regex> = OnceLock::new();
    let re = SAFE_OUTPUT_RE.get_or_init(|| {
        Regex::new(&format!(
            r"\d*>[ ]?/dev/({})(\s|[;&|)]|$)",
            safe_device_redirect_names_pattern()
        ))
        .expect("static safe-device redirect regex must compile")
    });

    let safe = if matches!(dialect, ShellDialect::Posix) {
        re.replace_all(command, "$2").to_string()
    } else {
        command.to_string()
    };
    // Windows null device: strip `>nul`, `1>nul`, `2>nul`, `2>NUL`, and the
    // `\\.\nul` device form (case-insensitive) — the platform equivalent of the
    // `/dev/null` forms stripped above. A trailing non-boundary char (e.g.
    // `>nul.txt`, `>null`) is left intact so only the bare device matches.
    //
    // Gated on the effective shell: only Windows `cmd.exe` resolves `nul` to
    // the discard-only null device. Under a POSIX shell (Unix native or Docker
    // `sh -c`) `nul` is an ordinary relative filename, so
    // `echo x >nul` would create/truncate a workspace file — it must stay
    // flagged as an unsafe file redirect.
    let safe = if matches!(dialect, ShellDialect::WindowsCmd) {
        static SAFE_NUL_OUTPUT_RE: OnceLock<Regex> = OnceLock::new();
        let nul_re = SAFE_NUL_OUTPUT_RE.get_or_init(|| {
            Regex::new(r"(?i)\d*>[ ]?(?:\\\\\.\\)?nul(\s|[;&|)]|$)")
                .expect("SAFE_NUL_OUTPUT_RE regex must compile")
        });
        nul_re.replace_all(&safe, "$1").to_string()
    } else {
        safe
    };
    // Also strip fd-merge redirects (2>&1, 1>&2, >&N, etc.)
    let safe = strip_fd_merge_redirects(&safe);
    contains_unquoted_char(&safe, '>', dialect)
}

/// POSIX-dialect convenience wrapper for tests — the conservative default that
/// production reaches when it has no effective shell context. Production shell
/// tools call the `_for_shell` form with the runtime's actual dialect.
#[cfg(test)]
fn contains_unsafe_output_redirect(command: &str) -> bool {
    contains_unsafe_output_redirect_for_shell(command, ShellDialect::Posix)
}

/// Returns true if `command` contains an unquoted `<` that is NOT a heredoc (`<<`)
/// or a safe input redirect from `/dev/*`.
fn contains_unquoted_input_redirect(command: &str, dialect: ShellDialect) -> bool {
    // Strip here-strings (`<<<`) first, then heredocs (`<<`), then safe /dev/* sources
    // with word boundary enforcement.
    use regex::Regex;
    use std::sync::OnceLock;

    static SAFE_INPUT_RE: OnceLock<Regex> = OnceLock::new();
    let re = SAFE_INPUT_RE.get_or_init(|| {
        Regex::new(r"<[ ]?/dev/(null|zero)(\s|[;&|)]|$)").expect("SAFE_INPUT_RE regex must compile")
    });

    let safe = if matches!(dialect, ShellDialect::Posix) {
        let safe = command.replace("<<<", "").replace("<<", "");
        re.replace_all(&safe, "$2").to_string()
    } else {
        command.to_string()
    };
    // Also strip fd-merge redirects (<&0, <&-, etc.) so they don't leave a bare `<`
    let safe = strip_fd_merge_redirects(&safe);
    contains_unquoted_char(&safe, '<', dialect)
}

/// Detect unquoted shell variable expansions like `$HOME`, `$1`, `$?`.
/// Escaped dollars (`\$`) are ignored. Variables inside single quotes are
/// treated as literals and therefore ignored.
fn contains_unquoted_shell_variable_expansion(command: &str) -> bool {
    let mut quote = QuoteState::None;
    let mut escaped = false;
    let chars: Vec<char> = command.chars().collect();

    for i in 0..chars.len() {
        let ch = chars[i];

        match quote {
            QuoteState::Single => {
                if ch == '\'' {
                    quote = QuoteState::None;
                }
                continue;
            }
            QuoteState::Double => {
                if escaped {
                    escaped = false;
                    continue;
                }
                if ch == '\\' {
                    escaped = true;
                    continue;
                }
                if ch == '"' {
                    quote = QuoteState::None;
                    continue;
                }
            }
            QuoteState::None => {
                if escaped {
                    escaped = false;
                    continue;
                }
                if ch == '\\' {
                    escaped = true;
                    continue;
                }
                if ch == '\'' {
                    quote = QuoteState::Single;
                    continue;
                }
                if ch == '"' {
                    quote = QuoteState::Double;
                    continue;
                }
            }
        }

        if ch != '$' {
            continue;
        }

        let Some(next) = chars.get(i + 1).copied() else {
            continue;
        };
        if next.is_ascii_alphanumeric()
            || matches!(
                next,
                '_' | '{'
                    | '('
                    | '#'
                    | '?'
                    | '!'
                    | '$'
                    | '*'
                    | '@'
                    | '-'
                    | '='
                    | '+'
                    | '^'
                    | '~'
                    | '['
                    | '<'
            )
        {
            return true;
        }
    }

    false
}

fn contains_unmodeled_shell_word_expansion(command: &str, dialect: ShellDialect) -> bool {
    if command.contains("\\\n") || command.contains("\\\r\n") {
        return true;
    }

    // cmd.exe expands `%NAME%` variables, can expand `!NAME!` variables when
    // delayed expansion is enabled by host policy, and removes caret escapes
    // before launching the executable. The policy does not model those
    // transforms, so reject them before command identity or Git risk is accepted.
    if shell_uses_windows_path_syntax(dialect) && command.contains(['%', '!', '^']) {
        return true;
    }

    let mut quote = QuoteState::None;
    let mut escaped = false;
    let mut at_tilde_prefix = true;
    let mut assignment_name_valid = true;
    let mut assignment_name_len = 0usize;
    let mut in_assignment_value = false;
    let mut chars = command.chars().peekable();

    while let Some(ch) = chars.next() {
        match quote {
            QuoteState::Single => {
                if ch == '\'' {
                    quote = QuoteState::None;
                }
                at_tilde_prefix = false;
                assignment_name_valid = false;
                continue;
            }
            QuoteState::Double => {
                if escaped {
                    escaped = false;
                    at_tilde_prefix = false;
                    assignment_name_valid = false;
                    continue;
                }
                if ch == '\\' {
                    escaped = true;
                    at_tilde_prefix = false;
                    assignment_name_valid = false;
                    continue;
                }
                if ch == '"' {
                    quote = QuoteState::None;
                }
                at_tilde_prefix = false;
                assignment_name_valid = false;
                continue;
            }
            QuoteState::None => {
                if escaped {
                    escaped = false;
                    at_tilde_prefix = false;
                    assignment_name_valid = false;
                    continue;
                }
                if ch == '\\' {
                    escaped = true;
                    at_tilde_prefix = false;
                    assignment_name_valid = false;
                    continue;
                }
                if ch.is_whitespace() || matches!(ch, '|' | '&' | ';' | '<' | '>') {
                    at_tilde_prefix = true;
                    assignment_name_valid = true;
                    assignment_name_len = 0;
                    in_assignment_value = false;
                    continue;
                }
                if ch == '='
                    && !in_assignment_value
                    && assignment_name_valid
                    && assignment_name_len > 0
                {
                    in_assignment_value = true;
                    at_tilde_prefix = true;
                    continue;
                }
                if ch == ':' && in_assignment_value {
                    at_tilde_prefix = true;
                    continue;
                }
                match ch {
                    '\'' => {
                        quote = QuoteState::Single;
                        at_tilde_prefix = false;
                        assignment_name_valid = false;
                        continue;
                    }
                    '"' => {
                        quote = QuoteState::Double;
                        at_tilde_prefix = false;
                        assignment_name_valid = false;
                        continue;
                    }
                    '$' if chars.peek().is_some_and(|next| matches!(*next, '\'' | '"')) => {
                        return true;
                    }
                    // Parentheses participate in extended-glob syntax in
                    // supported configurable shells such as ksh. Even when
                    // the operator prefix is otherwise ordinary text, the
                    // shell can replace the token after policy validation.
                    // zsh EXTENDED_GLOB also gives unquoted `#` and `^`
                    // pattern meaning, while infix `~` excludes a pattern.
                    // Preserve leading and assignment-value `~` expansion.
                    '{' | '}' | '(' | ')' | '*' | '?' | '[' => return true,
                    '^' | '#' if dialect == ShellDialect::Posix => return true,
                    '~' if dialect == ShellDialect::Posix && !at_tilde_prefix => return true,
                    _ => {}
                }
                if !in_assignment_value {
                    let valid_name_char = if assignment_name_len == 0 {
                        ch.is_ascii_alphabetic() || ch == '_'
                    } else {
                        ch.is_ascii_alphanumeric()
                            || ch == '_'
                            || (ch == '+' && chars.peek().is_some_and(|next| *next == '='))
                    };
                    assignment_name_valid &= valid_name_char;
                    assignment_name_len += 1;
                }
                at_tilde_prefix = false;
            }
        }
    }

    false
}

fn strip_wrapping_quotes(token: &str) -> &str {
    token.trim_matches(|c| c == '"' || c == '\'')
}

fn looks_like_path(candidate: &str) -> bool {
    candidate.starts_with('/')
        || candidate.starts_with("./")
        || candidate.starts_with("../")
        || candidate == "~"
        || candidate.starts_with("~/")
        || (candidate.starts_with('~') && candidate.contains('/'))
        || candidate == "."
        || candidate == ".."
        || candidate.contains('/')
        // Windows path patterns: drive letters (C:\, D:\) and UNC paths (\\server\share)
        || (cfg!(target_os = "windows")
            && (candidate
                .get(1..3)
                .is_some_and(|s| s == ":\\" || s == ":/")
                || candidate.starts_with("\\\\")))
}

fn shell_uses_windows_path_syntax(dialect: ShellDialect) -> bool {
    matches!(dialect, ShellDialect::WindowsCmd | ShellDialect::PowerShell)
}

fn shell_uses_single_quote_syntax(dialect: ShellDialect) -> bool {
    matches!(dialect, ShellDialect::Posix | ShellDialect::PowerShell)
}

fn has_windows_drive_prefix(candidate: &str) -> bool {
    let bytes = candidate.as_bytes();
    bytes.len() >= 2 && bytes[0].is_ascii_alphabetic() && bytes[1] == b':'
}

fn is_windows_drive_relative(candidate: &str) -> bool {
    has_windows_drive_prefix(candidate)
        && !candidate
            .as_bytes()
            .get(2)
            .is_some_and(|separator| matches!(*separator, b'/' | b'\\'))
}

fn looks_like_path_for_shell(candidate: &str, dialect: ShellDialect) -> bool {
    looks_like_path(candidate)
        || (shell_uses_windows_path_syntax(dialect)
            && (candidate.contains('\\') || has_windows_drive_prefix(candidate)))
}

fn shell_path_tokens_equal(left: &str, right: &str, dialect: ShellDialect) -> bool {
    if shell_uses_windows_path_syntax(dialect) {
        // Backslash acceptance is a dialect concern (PowerShell/cmd accept `\`
        // on every host), but case sensitivity is a *host* concern. Normalize
        // separators for both sides, then compare with the host filesystem's
        // case rules so cross-platform `pwsh` on a case-sensitive host does not
        // treat `/tmp/Safe/tool` and `/tmp/safe/tool` as the same executable.
        host_path_tokens_equal(&left.replace('\\', "/"), &right.replace('\\', "/"))
    } else {
        expand_user_path(left) == expand_user_path(right)
    }
}

/// Compare two path tokens with the host filesystem's case semantics after `~`
/// expansion: case-insensitive on Windows, exact on case-sensitive Unix. An
/// explicit path is a trust anchor, so folding case on Unix would authorize a
/// differently cased — and potentially different — file.
fn host_path_tokens_equal(left: &str, right: &str) -> bool {
    let left = expand_user_path(left);
    let right = expand_user_path(right);
    #[cfg(target_os = "windows")]
    {
        left.as_os_str().eq_ignore_ascii_case(right.as_os_str())
    }
    #[cfg(not(target_os = "windows"))]
    {
        left == right
    }
}

fn attached_short_option_value(token: &str) -> Option<&str> {
    // Examples:
    // -f/etc/passwd   -> /etc/passwd
    // -C../outside    -> ../outside
    // -I./include     -> ./include
    let body = token.strip_prefix('-')?;
    if body.starts_with('-') || body.len() < 2 {
        return None;
    }
    let mut chars = body.chars();
    chars.next();
    let value = chars.as_str().trim_start_matches('=').trim();
    if value.is_empty() { None } else { Some(value) }
}

enum RedirectionArgument<'a> {
    Target { prefix: &'a str, target: &'a str },
    NeedsNextToken { prefix: &'a str },
    FdOnly { prefix: &'a str },
    None,
}

fn parse_redirection_argument_at(
    token: &str,
    metadata: RedirectionMetadata,
) -> RedirectionArgument<'_> {
    let prefix = &token[..metadata.marker_idx];
    let rest = &token[metadata.operator_end..];
    if let Some(after_amp) = rest.strip_prefix('&')
        && (after_amp == "-"
            || (!after_amp.is_empty() && after_amp.chars().all(|c| c.is_ascii_digit())))
    {
        return RedirectionArgument::FdOnly { prefix };
    }
    if rest.is_empty() && !metadata.has_attached_word {
        RedirectionArgument::NeedsNextToken { prefix }
    } else {
        RedirectionArgument::Target {
            prefix,
            target: rest,
        }
    }
}

const SAFE_DEVICE_REDIRECT_TARGETS: [&str; 4] =
    ["/dev/null", "/dev/stdout", "/dev/stderr", "/dev/zero"];

fn safe_device_redirect_names_pattern() -> String {
    SAFE_DEVICE_REDIRECT_TARGETS
        .iter()
        .map(|target| target.trim_start_matches("/dev/"))
        .collect::<Vec<_>>()
        .join("|")
}

fn is_safe_device_redirect_target(target: &str, dialect: ShellDialect) -> bool {
    let target = strip_wrapping_quotes(target).trim();
    if matches!(dialect, ShellDialect::Posix) && SAFE_DEVICE_REDIRECT_TARGETS.contains(&target) {
        return true;
    }
    // Windows null device: `nul`/`NUL` (case-insensitive) and the full `\\.\nul`
    // device form. Only under a native Windows `cmd.exe` shell does `nul` always
    // resolve to the discard-only null device. Under a POSIX shell (Unix native
    // or Docker `sh -c`) `nul` is an ordinary relative filename, so it
    // must not be treated as a safe device.
    matches!(dialect, ShellDialect::WindowsCmd)
        && (target.eq_ignore_ascii_case("nul") || target.eq_ignore_ascii_case(r"\\.\nul"))
}

/// Extract the basename using the shell dialect's path separators.
/// Windows command dialects accept both `/` and `\`, while POSIX treats `\`
/// as a literal that can escape the following character.
fn command_basename_for_shell(raw: &str, dialect: ShellDialect) -> &str {
    let after_fwd = raw.rsplit('/').next().unwrap_or(raw);
    if shell_uses_windows_path_syntax(dialect) {
        after_fwd.rsplit('\\').next().unwrap_or(after_fwd)
    } else {
        after_fwd
    }
}

/// Strip common Windows executable suffixes (.exe, .cmd, .bat) for uniform
/// matching against allowlists and risk tables. POSIX command dialects keep
/// suffixes literal even when the host itself is Windows.
fn strip_windows_exe_suffix_for_shell(name: &str, dialect: ShellDialect) -> &str {
    if shell_uses_windows_path_syntax(dialect) {
        name.strip_suffix(".exe")
            .or_else(|| name.strip_suffix(".cmd"))
            .or_else(|| name.strip_suffix(".bat"))
            .unwrap_or(name)
    } else {
        name
    }
}

/// Compare two bare command names using the same semantics everywhere a
/// command allowlist is interpreted. Path-like entries are handled by their
/// callers and deliberately do not pass through this case-folding rule.
fn command_names_equivalent(left: &str, right: &str) -> bool {
    let left_lower = left.to_ascii_lowercase();
    let right_lower = right.to_ascii_lowercase();
    if left_lower == right_lower {
        return true;
    }

    // On Windows, an omitted executable suffix does not distinguish command
    // names (for example, `git` and `git.exe` grant the same command access).
    #[cfg(target_os = "windows")]
    {
        for ext in &[".exe", ".cmd", ".bat"] {
            if right_lower == format!("{left_lower}{ext}") {
                return true;
            }
            if left_lower == format!("{right_lower}{ext}") {
                return true;
            }
        }
    }

    false
}

fn command_names_equivalent_for_shell(left: &str, right: &str, dialect: ShellDialect) -> bool {
    let left_lower = left.to_ascii_lowercase();
    let right_lower = right.to_ascii_lowercase();
    if left_lower == right_lower {
        return true;
    }

    if shell_uses_windows_path_syntax(dialect) {
        for ext in &[".exe", ".cmd", ".bat"] {
            if right_lower == format!("{left_lower}{ext}")
                || left_lower == format!("{right_lower}{ext}")
            {
                return true;
            }
        }
    }

    false
}

fn command_allowlist_entries_equivalent(left: &str, right: &str) -> bool {
    let left = strip_wrapping_quotes(left).trim();
    let right = strip_wrapping_quotes(right).trim();
    if left.is_empty() || right.is_empty() {
        return false;
    }

    // Preserve exact equality for paths. Case-folding a path would widen the
    // policy on case-sensitive filesystems.
    if looks_like_path(left) || looks_like_path(right) {
        return left == right;
    }

    command_names_equivalent(left, right)
}

fn is_allowlist_entry_match(
    allowed: &str,
    executable: &str,
    executable_base: &str,
    dialect: ShellDialect,
) -> bool {
    let allowed = strip_wrapping_quotes(allowed).trim();
    if allowed.is_empty() {
        return false;
    }

    // Explicit wildcard support for "allow any command name/path".
    if allowed == "*" {
        return true;
    }

    // Path-like allowlist entries must match the executable token exactly
    // after "~" expansion.
    if looks_like_path(allowed) {
        let allowed_path = expand_user_path(allowed);
        let executable_path = expand_user_path(executable);
        return executable_path == allowed_path;
    }

    // Command-name entries continue to match by basename, case-insensitively.
    // Callers lowercase the basename before it reaches here, so folding only
    // one side would leave an entry written as `Git` or `Docker` unable to
    // match anything.
    command_names_equivalent_for_shell(allowed, executable_base, dialect)
}

/// Decide whether a completed PowerShell token must be rejected by the bounded
/// grammar. Two shapes are rejected because the token the later provider, path,
/// allowlist, and risk checks would inspect differs from the argument
/// PowerShell actually binds:
///
///   * Mixed quoted and unquoted fragments in one token (`E'nv:'PATH`,
///     `C':'\win.ini`). PowerShell concatenates them before binding, so the
///     raw token with embedded quote delimiters can hide a provider path,
///     drive prefix, or `..` traversal.
///   * The bare stop-parsing token `--%` (also matched via the collapsed body
///     for forms whose quote delimiters were removed).
///
/// Fully bare and fully quoted tokens are accepted and parsed normally.
fn reject_powershell_token(has_bare: bool, has_quoted: bool, body: &str) -> bool {
    has_bare && (has_quoted || body == "--%")
}

/// Split a PowerShell command into simple pipeline stages.
///
/// PowerShell is an expression language, not just a command launcher. The
/// generic POSIX-oriented splitter cannot safely reason about constructs such
/// as `(...)`, script blocks, type literals, call operators, or backtick
/// escapes. This parser intentionally accepts only a bounded command grammar:
/// bare command invocations, quoted/plain arguments, simple variable reads,
/// and pipelines. Everything else fails closed.
fn split_powershell_pipeline_syntax(command: &str) -> Option<Vec<String>> {
    let mut segments = Vec::new();
    let mut current = String::new();
    let mut quote = QuoteState::None;
    let mut chars = command.chars().peekable();
    // Track each whitespace-delimited token so the bounded grammar can reject
    // two PowerShell constructs that would otherwise let policy inspect a token
    // different from the one PowerShell binds:
    //
    //   * The stop-parsing token `--%`, which makes PowerShell pass the rest of
    //     the line to a native command verbatim (`git --% push` reaches Git as
    //     `push` while policy only sees `--%`).
    //   * Mixed quoted/unquoted fragments in a single argument. PowerShell
    //     concatenates adjacent fragments before binding, so `E'nv:'PATH` binds
    //     as `Env:PATH` and `C':'\win.ini` as `C:\win.ini`. The later provider,
    //     path, allowlist, and risk checks see the raw token with quote
    //     delimiters still embedded, so a mixed token can hide a provider path,
    //     drive prefix, or `..` traversal from them.
    //
    // `token_body` accumulates the token with quote *delimiters* removed (so
    // `-"-"%` collapses to `--%`). `token_has_bare` records an unquoted
    // character and `token_has_quoted` records a quote delimiter; a token with
    // both is a mixed construction and is rejected. Fully bare and fully quoted
    // tokens are left for normal parsing.
    let mut token_body = String::new();
    let mut token_has_bare = false;
    let mut token_has_quoted = false;

    while let Some(ch) = chars.next() {
        // Backtick changes PowerShell parsing in every quoting mode. Supporting
        // it would require a complete lexer, so the bounded grammar rejects it.
        if ch == '`' || ch == '\0' {
            return None;
        }

        match quote {
            QuoteState::Single => {
                if ch == '\'' {
                    if chars.peek() == Some(&'\'') {
                        current.push(ch);
                        chars.next();
                        current.push(ch);
                        token_body.push(ch);
                        continue;
                    }
                    quote = QuoteState::None;
                    current.push(ch);
                } else {
                    token_body.push(ch);
                    current.push(ch);
                }
            }
            QuoteState::Double => {
                if ch == '"' {
                    if chars.peek() == Some(&'"') {
                        current.push(ch);
                        chars.next();
                        current.push(ch);
                        token_body.push(ch);
                        continue;
                    }
                    quote = QuoteState::None;
                    current.push(ch);
                } else {
                    token_body.push(ch);
                    current.push(ch);
                }
            }
            QuoteState::None => match ch {
                '\'' => {
                    quote = QuoteState::Single;
                    token_has_quoted = true;
                    current.push(ch);
                }
                '"' => {
                    quote = QuoteState::Double;
                    token_has_quoted = true;
                    current.push(ch);
                }
                ' ' | '\t' => {
                    if reject_powershell_token(token_has_bare, token_has_quoted, &token_body) {
                        return None;
                    }
                    token_body.clear();
                    token_has_bare = false;
                    token_has_quoted = false;
                    current.push(ch);
                }
                '|' => {
                    // `||` is a control-flow operator, not a pipeline.
                    if chars.peek() == Some(&'|') {
                        return None;
                    }
                    if reject_powershell_token(token_has_bare, token_has_quoted, &token_body) {
                        return None;
                    }
                    token_body.clear();
                    token_has_bare = false;
                    token_has_quoted = false;
                    let segment = current.trim();
                    if segment.is_empty() {
                        return None;
                    }
                    segments.push(segment.to_string());
                    current.clear();
                }
                // These characters introduce expressions, statements,
                // redirection, splatting, or alternate invocation forms.
                ';' | '\r' | '\n' | '&' | '(' | ')' | '{' | '}' | '[' | ']' | '<' | '>' | '@' => {
                    return None;
                }
                _ => {
                    token_body.push(ch);
                    token_has_bare = true;
                    current.push(ch);
                }
            },
        }
    }

    if quote != QuoteState::None {
        return None;
    }

    if reject_powershell_token(token_has_bare, token_has_quoted, &token_body) {
        return None;
    }

    let segment = current.trim();
    if segment.is_empty() {
        return None;
    }
    segments.push(segment.to_string());

    Some(segments)
}

fn split_simple_powershell_pipeline(command: &str) -> Option<Vec<String>> {
    let segments = split_powershell_pipeline_syntax(command)?;
    powershell_variables_are_simple(command).then_some(segments)
}

/// Return whether `command` fits the one canonical bounded PowerShell grammar.
///
/// Native PowerShell execution uses this to decide whether a setup statement
/// can be prepended without rewriting a full script. Inputs outside this
/// grammar must remain byte-for-byte unchanged so declarations, named blocks,
/// and other PowerShell syntax keep their native `-Command` behavior.
pub(crate) fn powershell_command_supports_statement_prelude(command: &str) -> bool {
    split_simple_powershell_pipeline(command).is_some()
}

/// Accept only `$Name` and `$Name.Property` reads outside single-quoted
/// literals. Subexpressions, braced variables, scoped variables, and special
/// variables are rejected because they change parsing or hide executable text.
fn powershell_variables_are_simple(command: &str) -> bool {
    let chars: Vec<char> = command.chars().collect();
    let mut quote = QuoteState::None;
    let mut i = 0;

    while i < chars.len() {
        let ch = chars[i];
        match quote {
            QuoteState::Single => {
                if ch == '\'' {
                    if chars.get(i + 1) == Some(&'\'') {
                        i += 2;
                        continue;
                    }
                    quote = QuoteState::None;
                }
                i += 1;
                continue;
            }
            QuoteState::Double => {
                if ch == '"' {
                    if chars.get(i + 1) == Some(&'"') {
                        i += 2;
                        continue;
                    }
                    quote = QuoteState::None;
                    i += 1;
                    continue;
                }
            }
            QuoteState::None => {
                if ch == '\'' {
                    quote = QuoteState::Single;
                    i += 1;
                    continue;
                }
                if ch == '"' {
                    quote = QuoteState::Double;
                    i += 1;
                    continue;
                }
            }
        }

        if ch != '$' {
            i += 1;
            continue;
        }

        i += 1;
        if i >= chars.len() || !(chars[i].is_ascii_alphabetic() || chars[i] == '_') {
            return false;
        }
        i += 1;
        while i < chars.len() && (chars[i].is_ascii_alphanumeric() || chars[i] == '_') {
            i += 1;
        }
        if chars.get(i) == Some(&':') {
            return false;
        }
        while chars.get(i) == Some(&'.') {
            i += 1;
            if i >= chars.len() || !(chars[i].is_ascii_alphabetic() || chars[i] == '_') {
                return false;
            }
            i += 1;
            while i < chars.len() && (chars[i].is_ascii_alphanumeric() || chars[i] == '_') {
                i += 1;
            }
        }
    }

    true
}

fn is_powershell_allowlist_entry_match(
    allowed: &str,
    executable: &str,
    executable_base: &str,
) -> bool {
    if allowed.trim() == "*" {
        return true;
    }

    let allowed = strip_wrapping_quotes(allowed).trim();
    if looks_like_path_for_shell(allowed, ShellDialect::PowerShell) {
        // An explicit path is the trust anchor, so it must match with the host
        // filesystem's case semantics: case-insensitive on Windows, exact on
        // case-sensitive Unix. Folding case on every host would let an
        // allowlist entry `/tmp/Safe/tool` authorize the distinct executable
        // `/tmp/safe/tool`.
        return shell_path_tokens_equal(allowed, executable, ShellDialect::PowerShell);
    }

    let allowed = strip_powershell_executable_suffix(allowed);
    allowed.eq_ignore_ascii_case(executable_base)
}

fn strip_powershell_executable_suffix(name: &str) -> &str {
    match name.rsplit_once('.') {
        Some((stem, extension)) if extension.eq_ignore_ascii_case("exe") => stem,
        _ => name,
    }
}

fn is_powershell_batch_file(name: &str) -> bool {
    name.rsplit_once('.').is_some_and(|(_, extension)| {
        extension.eq_ignore_ascii_case("cmd") || extension.eq_ignore_ascii_case("bat")
    })
}

fn is_powershell_provider_argument(argument: &str) -> bool {
    let argument = strip_wrapping_quotes(argument).to_ascii_lowercase();
    argument.contains("::")
        || [
            "alias:",
            "cert:",
            "env:",
            "function:",
            "hkcu:",
            "hklm:",
            "variable:",
            "wsman:",
        ]
        .iter()
        .any(|provider| argument.starts_with(provider))
}

fn is_known_read_only_powershell_command(base: &str) -> bool {
    matches!(
        base,
        "write-output"
            | "echo"
            | "get-date"
            | "get-childitem"
            | "gci"
            | "dir"
            | "ls"
            | "get-location"
            | "gl"
            | "pwd"
            | "get-content"
            | "gc"
            | "type"
            | "cat"
            | "test-path"
            | "resolve-path"
            | "measure-object"
            | "select-object"
            | "sort-object"
            | "compare-object"
            | "format-list"
            | "format-table"
            | "format-wide"
            | "format-custom"
    )
}

fn powershell_named_risk(base: &str) -> Option<CommandRiskLevel> {
    if is_known_read_only_powershell_command(base) {
        return Some(CommandRiskLevel::Low);
    }

    if matches!(
        base,
        "remove-item"
            | "clear-content"
            | "set-content"
            | "add-content"
            | "out-file"
            | "start-process"
            | "stop-process"
            | "invoke-webrequest"
            | "invoke-restmethod"
            | "invoke-expression"
            | "invoke-command"
            | "ac"
            | "clc"
            | "del"
            | "erase"
            | "rd"
            | "ri"
            | "rm"
            | "rmdir"
            | "sc"
            | "saps"
            | "start"
            | "kill"
            | "spps"
            | "curl"
            | "wget"
            | "iwr"
            | "irm"
            | "iex"
            | "icm"
    ) {
        return Some(CommandRiskLevel::High);
    }

    if matches!(
        base,
        "new-item"
            | "copy-item"
            | "move-item"
            | "rename-item"
            | "ni"
            | "copy"
            | "cp"
            | "cpi"
            | "move"
            | "mv"
            | "mi"
            | "ren"
            | "rni"
            | "mkdir"
            | "md"
    ) {
        return Some(CommandRiskLevel::Medium);
    }

    None
}

fn generic_segment_risk(
    base: &str,
    args: &[String],
    joined_segment: &str,
) -> Option<CommandRiskLevel> {
    if matches!(
        base,
        "rm" | "mkfs"
            | "dd"
            | "shutdown"
            | "reboot"
            | "halt"
            | "poweroff"
            | "sudo"
            | "su"
            | "chown"
            | "chmod"
            | "useradd"
            | "userdel"
            | "usermod"
            | "passwd"
            | "mount"
            | "umount"
            | "iptables"
            | "ufw"
            | "firewall-cmd"
            | "curl"
            | "wget"
            | "nc"
            | "ncat"
            | "netcat"
            | "scp"
            | "ssh"
            | "ftp"
            | "telnet"
            // Windows-specific high-risk commands retained from the existing
            // cross-platform compatibility policy.
            | "del"
            | "rmdir"
            | "format"
            | "reg"
            | "net"
            | "runas"
            | "icacls"
            | "takeown"
            | "powershell"
            | "pwsh"
            | "wmic"
            | "sc"
            | "netsh"
    ) {
        return Some(CommandRiskLevel::High);
    }

    if joined_segment.contains("rm -rf /")
        || joined_segment.contains("rm -fr /")
        || joined_segment.contains(":(){:|:&};:")
        || joined_segment.contains("del /s /q")
        || joined_segment.contains("rmdir /s /q")
        || joined_segment.contains("format c:")
    {
        return Some(CommandRiskLevel::High);
    }

    match base {
        "git" => Some(if git_command_is_write(args) {
            CommandRiskLevel::Medium
        } else {
            CommandRiskLevel::Low
        }),
        "npm" | "pnpm" | "yarn" => Some(
            if args.first().is_some_and(|verb| {
                let verb = verb.to_ascii_lowercase();
                matches!(
                    verb.as_str(),
                    "install" | "add" | "remove" | "uninstall" | "update" | "publish"
                )
            }) {
                CommandRiskLevel::Medium
            } else {
                CommandRiskLevel::Low
            },
        ),
        "cargo" => Some(
            if args.first().is_some_and(|verb| {
                let verb = verb.to_ascii_lowercase();
                matches!(
                    verb.as_str(),
                    "add" | "remove" | "install" | "clean" | "publish"
                )
            }) {
                CommandRiskLevel::Medium
            } else {
                CommandRiskLevel::Low
            },
        ),
        "touch" | "mkdir" | "mv" | "cp" | "ln" | "copy" | "xcopy" | "robocopy" | "move" | "ren"
        | "rename" | "mklink" => Some(CommandRiskLevel::Medium),
        _ => None,
    }
}

impl SecurityPolicy {
    // ── Risk Classification ──────────────────────────────────────────────
    // Risk is assessed per-segment (split on shell operators), and the
    // highest risk across all segments wins. This prevents bypasses like
    // `ls && rm -rf /` from being classified as Low just because `ls` is safe.

    /// Classify command risk. Any high-risk segment marks the whole command high.
    pub fn command_risk_level(&self, command: &str) -> CommandRiskLevel {
        self.command_risk_level_for_posix_like_shell(
            command,
            ShellGrammar::from(ShellDialect::Posix),
        )
    }

    fn command_risk_level_for_posix_like_shell(
        &self,
        command: &str,
        shell: ShellGrammar,
    ) -> CommandRiskLevel {
        let dialect = shell.dialect;
        let mut saw_medium = false;

        let Ok(segments) = split_unquoted_segments_checked(command, shell) else {
            // The body boundary cannot be proven, so the risk of the commands
            // after it cannot be proven either.
            return CommandRiskLevel::High;
        };
        for segment in segments {
            let cmd_part = skip_env_assignments(&segment);
            let normalized = normalized_shell_command(&segment, dialect);
            if normalized.has_ambiguous_redirection {
                return CommandRiskLevel::High;
            }
            let words = normalized.words;
            let Some(base_raw) = words.first() else {
                continue;
            };

            let base_owned = command_basename_for_shell(base_raw, dialect).to_ascii_lowercase();
            let base = strip_windows_exe_suffix_for_shell(&base_owned, dialect);

            let args: Vec<String> = words.iter().skip(1).cloned().collect();
            let joined_segment = cmd_part.to_ascii_lowercase();

            match generic_segment_risk(base, &args, &joined_segment) {
                Some(CommandRiskLevel::High) => return CommandRiskLevel::High,
                Some(CommandRiskLevel::Medium) => saw_medium = true,
                Some(CommandRiskLevel::Low) | None => {}
            }
        }

        if saw_medium {
            CommandRiskLevel::Medium
        } else {
            CommandRiskLevel::Low
        }
    }

    /// Classify command risk using the language the runtime will execute.
    pub fn command_risk_level_for_shell(
        &self,
        command: &str,
        dialect: ShellDialect,
    ) -> CommandRiskLevel {
        self.command_risk_level_for_grammar(command, ShellGrammar::from(dialect))
    }

    fn command_risk_level_for_grammar(
        &self,
        command: &str,
        shell: ShellGrammar,
    ) -> CommandRiskLevel {
        match shell.dialect {
            ShellDialect::Posix | ShellDialect::WindowsCmd => {
                return self.command_risk_level_for_posix_like_shell(command, shell);
            }
            ShellDialect::None => return CommandRiskLevel::High,
            ShellDialect::PowerShell => {}
        }

        let Some(segments) = split_simple_powershell_pipeline(command) else {
            return CommandRiskLevel::High;
        };
        let mut saw_medium = false;
        let has_pipeline = segments.len() > 1;

        for segment in segments {
            let mut words = segment.split_whitespace();
            let Some(base_raw) = words.next() else {
                return CommandRiskLevel::High;
            };
            let base_owned =
                command_basename_for_shell(base_raw, ShellDialect::PowerShell).to_ascii_lowercase();
            if is_powershell_batch_file(&base_owned) {
                return CommandRiskLevel::High;
            }
            let base = strip_powershell_executable_suffix(&base_owned);
            let arguments: Vec<&str> = words.collect();
            let arguments_cased: Vec<String> = arguments
                .iter()
                .map(|argument| (*argument).to_string())
                .collect();
            if arguments
                .iter()
                .any(|argument| is_powershell_provider_argument(argument))
                || (segment.contains('$')
                    && (has_pipeline || !matches!(base, "write-output" | "echo")))
            {
                return CommandRiskLevel::High;
            }

            if base_owned.ends_with(".ps1")
                || base_owned.ends_with(".psm1")
                || base_owned.ends_with(".psd1")
                || matches!(
                    base,
                    "." | "cmd"
                        | "command"
                        | "powershell"
                        | "pwsh"
                        | "sh"
                        | "bash"
                        | "zsh"
                        | "fish"
                        | "wsl"
                )
            {
                return CommandRiskLevel::High;
            }

            match powershell_named_risk(base) {
                Some(CommandRiskLevel::High) => return CommandRiskLevel::High,
                Some(CommandRiskLevel::Medium) => {
                    saw_medium = true;
                    continue;
                }
                Some(CommandRiskLevel::Low) => continue,
                None => {}
            }

            match generic_segment_risk(base, &arguments_cased, &segment.to_ascii_lowercase()) {
                Some(CommandRiskLevel::High) => return CommandRiskLevel::High,
                Some(CommandRiskLevel::Medium) => saw_medium = true,
                Some(CommandRiskLevel::Low) => {}
                // PowerShell resolves bare names through aliases, functions,
                // cmdlets, scripts, and applications. If none of the known
                // command families above recognizes the name, treating it as
                // low risk would let a mutable alias or function hide behind
                // the wildcard allowlist.
                None => return CommandRiskLevel::High,
            }
        }

        if saw_medium {
            CommandRiskLevel::Medium
        } else {
            CommandRiskLevel::Low
        }
    }

    /// Validate full command execution policy (allowlist + risk gate).
    ///
    /// Uses the conservative POSIX shell dialect. Shell tools that know the
    /// runtime's effective shell should call
    /// [`validate_command_execution_for_shell`](Self::validate_command_execution_for_shell)
    /// so the Windows `nul` null device is only accepted under `cmd.exe`.
    pub fn validate_command_execution(
        &self,
        command: &str,
        approved: bool,
    ) -> Result<CommandRiskLevel, String> {
        self.validate_command_execution_for_shell(command, approved, ShellDialect::Posix)
    }

    /// Validate a command against the policy and the runtime's shell language.
    ///
    /// The dialect decides platform-specific redirect safety (e.g. the Windows
    /// `nul` null device is discard-only under `cmd.exe` but an ordinary file
    /// under a POSIX shell).
    ///
    /// A POSIX command is read in the grammar every POSIX shell shares. A
    /// caller about to run the command should choose its grammar with
    /// [`Self::command_shell`] and check it with
    /// [`Self::validate_command_execution_in`].
    pub fn validate_command_execution_for_shell(
        &self,
        command: &str,
        approved: bool,
        dialect: ShellDialect,
    ) -> Result<CommandRiskLevel, String> {
        self.validate_command_execution_in_grammar(command, approved, ShellGrammar::from(dialect))
    }

    /// Choose the grammar to check a command in, for the shell `target`
    /// describes. A POSIX command is read in bash's grammar only when the
    /// program the runtime reports resolves, on the `PATH` it will use, to
    /// bash, and no container sandbox can run it. A bare name counts when it
    /// resolves to bash on that `PATH`; a link named `bash` to another shell
    /// does not. Nothing is built: the program is resolved and inspected only.
    ///
    /// Pass the result to every check of the command, then to
    /// [`Self::confirm_built_shell`] once the runtime has built it.
    pub fn command_shell(&self, target: ShellTarget<'_>) -> CommandShell {
        let posix_shell = match target.dialect {
            ShellDialect::Posix => resolve_posix_shell(
                target.program,
                target.effective_path,
                self.container_sandbox_possible(),
            ),
            _ => PosixShell::Unknown,
        };
        CommandShell {
            grammar: ShellGrammar {
                dialect: target.dialect,
                posix_shell,
            },
        }
    }

    /// [`Self::validate_command_execution_for_shell`], in the grammar
    /// [`Self::command_shell`] chose.
    pub fn validate_command_execution_in(
        &self,
        command: &str,
        approved: bool,
        shell: CommandShell,
    ) -> Result<CommandRiskLevel, String> {
        self.validate_command_execution_in_grammar(command, approved, shell.grammar)
    }

    /// Hold the program the runtime built to the grammar its command was
    /// checked in. Call it after building the command and before any sandbox
    /// wraps it: a host sandbox replaces the outer program with its own
    /// launcher, which is not the shell.
    ///
    /// A command checked in bash's grammar is refused unless `built_program`
    /// canonicalizes to bash. A command checked in the portable grammar reads
    /// the same in any POSIX shell, so it needs no confirmation.
    pub fn confirm_built_shell(
        &self,
        shell: CommandShell,
        built_program: &std::ffi::OsStr,
    ) -> Result<(), String> {
        if shell.grammar.posix_shell != PosixShell::Bash {
            return Ok(());
        }
        #[cfg(unix)]
        {
            let built = Path::new(built_program);
            if built.is_absolute()
                && std::fs::canonicalize(built).is_ok_and(|canonical| is_bash(&canonical))
            {
                return Ok(());
            }
        }
        Err(format!(
            "Command blocked: it was checked as a bash command, but the runtime built {} to run it",
            Path::new(built_program).display()
        ))
    }

    fn validate_command_execution_in_grammar(
        &self,
        command: &str,
        approved: bool,
        shell: ShellGrammar,
    ) -> Result<CommandRiskLevel, String> {
        let dialect = shell.dialect;
        if dialect == ShellDialect::None {
            return Err("Command blocked: configured runtime has no shell access".into());
        }

        // Path confinement here is specific to Windows shell dialects, whose
        // relative forms (`..\x`, `C:x`) the host-default PathGuardedTool
        // scanner cannot recognize. Run it before the allowlist so a path-shaped
        // executable cannot be rejected as merely unknown before confinement
        // reports the actual boundary violation. POSIX path policy is already
        // enforced by that wrapper; running it again here would reject legitimate
        // absolute arguments an operator explicitly allowed (e.g. `rm -rf /tmp/x`).
        if shell_uses_windows_path_syntax(dialect)
            && let Some(path) = self.forbidden_path_argument_impl(command, shell, false)
        {
            return Err(format!("Command blocked: forbidden path argument: {path}"));
        }

        if !self.is_command_allowed_for_grammar(command, shell) {
            return Err(format!("Command not allowed by security policy: {command}"));
        }

        let risk = self.command_risk_level_for_grammar(command, shell);

        if risk == CommandRiskLevel::High {
            if self.block_high_risk_commands
                && !self.is_command_explicitly_allowed_for_shell(command, shell)
            {
                return Err("Command blocked: high-risk command is disallowed by policy".into());
            }
            if self.autonomy == AutonomyLevel::Supervised && !approved {
                return Err(
                    "Command requires explicit approval (approved=true): high-risk operation"
                        .into(),
                );
            }
        }

        if risk == CommandRiskLevel::Medium
            && self.autonomy == AutonomyLevel::Supervised
            && self.require_approval_for_medium_risk
            && !approved
        {
            return Err(
                "Command requires explicit approval (approved=true): medium-risk operation".into(),
            );
        }

        Ok(risk)
    }

    fn is_command_explicitly_allowed_for_shell(&self, command: &str, shell: ShellGrammar) -> bool {
        let dialect = shell.dialect;
        match dialect {
            ShellDialect::PowerShell => {
                let Some(segments) = split_powershell_pipeline_syntax(command) else {
                    return false;
                };
                segments.iter().all(|segment| {
                    let raw_executable =
                        strip_wrapping_quotes(segment.split_whitespace().next().unwrap_or(""))
                            .trim();
                    let base_owned =
                        command_basename_for_shell(raw_executable, dialect).to_ascii_lowercase();
                    let base = strip_powershell_executable_suffix(&base_owned);
                    !base.is_empty()
                        && !is_powershell_batch_file(&base_owned)
                        && self.allowed_commands.iter().any(|allowed| {
                            allowed.trim() != "*"
                                && is_powershell_allowlist_entry_match(
                                    allowed,
                                    raw_executable,
                                    base,
                                )
                        })
                })
            }
            ShellDialect::Posix | ShellDialect::WindowsCmd => {
                self.is_command_explicitly_allowed(command, shell)
            }
            ShellDialect::None => false,
        }
    }

    fn is_command_explicitly_allowed(&self, command: &str, shell: ShellGrammar) -> bool {
        let dialect = shell.dialect;
        // A split that refuses a heredoc proves no command is listed.
        let Ok(segments) = split_unquoted_segments_checked(command, shell) else {
            return false;
        };
        for segment in &segments {
            let normalized = normalized_shell_command(segment, dialect);
            if normalized.has_ambiguous_redirection {
                return false;
            }
            let words = normalized.words;
            let executable = words.first().map(String::as_str).unwrap_or_default();
            let base_cmd_owned =
                command_basename_for_shell(executable, dialect).to_ascii_lowercase();
            let base_cmd = strip_windows_exe_suffix_for_shell(&base_cmd_owned, dialect);

            if base_cmd.is_empty() {
                continue;
            }

            let explicitly_listed = self.allowed_commands.iter().any(|allowed| {
                let allowed = strip_wrapping_quotes(allowed).trim();
                // Skip wildcard — it does not count as an explicit entry.
                if allowed.is_empty() || allowed == "*" {
                    return false;
                }
                is_allowlist_entry_match(allowed, executable, base_cmd, dialect)
            });

            if !explicitly_listed {
                return false;
            }
        }

        // At least one real command must be present.
        segments.iter().any(|s| {
            normalized_shell_command(s.trim(), dialect)
                .words
                .first()
                .is_some_and(|w| !w.is_empty())
        })
    }

    // ── Layered Command Allowlist ──────────────────────────────────────────
    // Defence-in-depth: five independent gates run in order before the
    // per-segment allowlist check. Each gate targets a specific bypass
    // technique. If any gate rejects, the whole command is blocked.

    pub fn is_command_allowed(&self, command: &str) -> bool {
        self.is_command_allowed_for_shell(command, ShellDialect::Posix)
    }

    /// Check the command allowlist using the runtime's actual shell language.
    ///
    /// Allowlist + shell-safety check against a specific shell dialect. The
    /// dialect selects the command grammar (PowerShell vs POSIX-like) and gates
    /// platform-specific redirect safety (the Windows `nul` null device is only
    /// discard-safe under `cmd.exe`).
    pub fn is_command_allowed_for_shell(&self, command: &str, dialect: ShellDialect) -> bool {
        self.is_command_allowed_for_grammar(command, ShellGrammar::from(dialect))
    }

    fn is_command_allowed_for_grammar(&self, command: &str, shell: ShellGrammar) -> bool {
        match shell.dialect {
            ShellDialect::PowerShell => self.is_simple_powershell_command_allowed(command),
            ShellDialect::Posix | ShellDialect::WindowsCmd => {
                self.is_posix_like_command_allowed(command, shell)
            }
            ShellDialect::None => false,
        }
    }

    fn is_simple_powershell_command_allowed(&self, command: &str) -> bool {
        if self.autonomy == AutonomyLevel::ReadOnly {
            return false;
        }

        let has_wildcard = self.allowed_commands.iter().any(|c| c.trim() == "*");
        // Preserve the existing trusted-environment escape hatch shared with
        // POSIX/cmd policy: wildcard plus disabled high-risk blocking opts out
        // of command-level syntax restrictions. In every other configuration,
        // apply the complete bounded PowerShell grammar before a named command
        // can qualify for an allowlist or high-risk exemption.
        if has_wildcard && !self.block_high_risk_commands {
            return true;
        }

        let Some(segments) = split_simple_powershell_pipeline(command) else {
            return false;
        };

        for segment in &segments {
            let mut words = segment.split_whitespace();
            let raw_executable = strip_wrapping_quotes(words.next().unwrap_or("")).trim();
            if raw_executable.is_empty()
                || raw_executable.starts_with('$')
                || raw_executable.starts_with(['\'', '"'])
            {
                return false;
            }

            let base_owned = command_basename_for_shell(raw_executable, ShellDialect::PowerShell)
                .to_ascii_lowercase();
            if is_powershell_batch_file(&base_owned) {
                return false;
            }
            let base = strip_powershell_executable_suffix(&base_owned);
            if !self
                .allowed_commands
                .iter()
                .any(|allowed| is_powershell_allowlist_entry_match(allowed, raw_executable, base))
            {
                return false;
            }

            let args_cased: Vec<String> = words.map(str::to_string).collect();
            if args_cased
                .iter()
                .any(|argument| is_powershell_provider_argument(argument))
            {
                return false;
            }
            let args: Vec<String> = args_cased
                .iter()
                .map(|word| word.to_ascii_lowercase())
                .collect();
            if !self.is_args_safe(base, &args, &args_cased) {
                return false;
            }
        }

        true
    }

    fn is_posix_like_command_allowed(&self, command: &str, shell: ShellGrammar) -> bool {
        let dialect = shell.dialect;
        if self.autonomy == AutonomyLevel::ReadOnly {
            return false;
        }

        // When the operator has explicitly opted out of all command-level
        // restrictions (wildcard + no high-risk blocking), skip the
        // subshell/expansion guard entirely. This allows backticks,
        // $(), heredocs, etc. in trusted environments.
        let has_wildcard = self.allowed_commands.iter().any(|c| c.trim() == "*");
        if has_wildcard && !self.block_high_risk_commands {
            // The opt-out skips syntax restrictions, but not a heredoc whose
            // body boundary cannot be proven. The path and risk checks refuse
            // that command for the same reason.
            return split_unquoted_segments_checked(command, shell).is_ok();
        }

        if command.contains('`')
            || contains_unquoted_shell_variable_expansion(command)
            || contains_unmodeled_shell_word_expansion(command, dialect)
            || command.contains("<(")
            || command.contains(">(")
        {
            return false;
        }

        // POSIX subshells split into their own segments below, so `(git status)`
        // would be checked as plain `git status`. Keep rejecting unquoted
        // grouping syntax here so the segment split does not widen the strict
        // allowlist; `$(`, `<(`, `>(`, and backticks are rejected above.
        // `contains_unmodeled_shell_word_expansion` already rejects unquoted
        // `(` and `)` as extended-glob syntax, so this duplicates that check on
        // purpose: the allowlist must not rely on the glob rule staying broad.
        if matches!(dialect, ShellDialect::Posix)
            && (contains_unquoted_char(command, '(', dialect)
                || contains_unquoted_char(command, ')', dialect))
        {
            return false;
        }

        // Block shell redirections that target files. Allow safe forms:
        //   - `2>/dev/null`, `>/dev/null`, `1>/dev/null` (output suppression)
        //   - `2>&1`, `1>&2` (fd merging)
        //   - `<<` heredocs, `<<<` here-strings (input literals)
        if contains_unsafe_output_redirect_for_shell(command, dialect) {
            return false;
        }
        if contains_unquoted_input_redirect(command, dialect) {
            return false;
        }

        // Block `tee` — it can write to arbitrary files, bypassing the
        // redirect check above (e.g. `echo secret | tee /etc/crontab`)
        if command
            .split_whitespace()
            .any(|w| w == "tee" || w.ends_with("/tee"))
        {
            return false;
        }

        // Block background command chaining (`&`), which can hide extra
        // sub-commands and outlive timeout expectations. Keep `&&` allowed.
        // Strip fd-merge redirects (N>&M, N<&M) first so their `&` isn't
        // flagged as background chaining.
        let ampersand_check = strip_fd_merge_redirects(command);
        if contains_unquoted_single_ampersand(&ampersand_check, dialect) {
            return false;
        }

        // Split on unquoted command separators and validate each sub-command.
        // An unreadable heredoc yields no segments, which must not read as
        // "every segment is allowed".
        let Ok(segments) = split_unquoted_segments_checked(command, shell) else {
            return false;
        };
        for segment in &segments {
            let normalized = normalized_shell_command(segment, dialect);
            if normalized.has_ambiguous_redirection || normalized.has_leading_env_assignment {
                return false;
            }
            let words = normalized.words;
            let executable = words.first().map(String::as_str).unwrap_or_default();
            let base_cmd_owned =
                command_basename_for_shell(executable, dialect).to_ascii_lowercase();
            let base_cmd = strip_windows_exe_suffix_for_shell(&base_cmd_owned, dialect);

            if base_cmd.is_empty() {
                continue;
            }

            if !self
                .allowed_commands
                .iter()
                .any(|allowed| is_allowlist_entry_match(allowed, executable, base_cmd, dialect))
            {
                return false;
            }

            // Validate arguments for the command.
            // Both case-preserved and lowercased argument lists are provided:
            //   - `args_cased` for case-sensitive comparisons (e.g. git -C vs -c)
            //   - `args` (lowercased) for case-insensitive matches (e.g. subcommand names)
            let args_cased: Vec<String> = words.iter().skip(1).cloned().collect();
            let args: Vec<String> = args_cased.iter().map(|w| w.to_ascii_lowercase()).collect();
            if !self.is_args_safe(base_cmd, &args, &args_cased) {
                return false;
            }
        }

        // At least one command must be present
        segments.iter().any(|s| {
            normalized_shell_command(s.trim(), dialect)
                .words
                .first()
                .is_some_and(|w| !w.is_empty())
        })
    }

    fn is_args_safe(&self, base: &str, args: &[String], args_cased: &[String]) -> bool {
        let base = base.to_ascii_lowercase();
        match base.as_str() {
            "find" => {
                // GNU/BSD find execution predicates allow arbitrary child commands.
                !args
                    .iter()
                    .any(|arg| matches!(arg.as_str(), "-exec" | "-execdir" | "-ok" | "-okdir"))
            }
            "git" => {
                !args_cased.iter().any(|arg| arg.starts_with("-c"))
                    && !git_delegates_to_external_command(args_cased)
                    && !args.iter().any(|arg| {
                        arg == "--config-env"
                            || arg.starts_with("--config-env=")
                            || arg == "--exec-path"
                            || arg.starts_with("--exec-path=")
                            || arg == "config"
                            || arg.starts_with("config.")
                            || arg == "alias"
                            || arg.starts_with("alias.")
                    })
            }
            // `env` is also a command carrier. Its option, assignment, and
            // child-command grammar varies across platforms, so accepting
            // arguments here would let the nested executable bypass this
            // allowlist and risk-classification boundary.
            "env" => args.is_empty(),
            "python" | "python3" => !args
                .iter()
                .any(|arg| arg.starts_with("-c") || arg.starts_with("-m")),
            "node" => {
                // -e/--eval evaluates argument as JavaScript
                // -p/--print same as --eval but prints the result
                // starts_with covers glued form: node -e'code' (one whitespace token)
                // Ref: https://nodejs.org/api/cli.html
                !args.iter().any(|arg| {
                    arg.starts_with("-e")
                        || arg.starts_with("--eval")
                        || arg.starts_with("-p")
                        || arg.starts_with("--print")
                })
            }
            "pip" | "pip3" => {
                // install/download fetch external packages; setup.py runs arbitrary code
                // Ref: https://blog.phylum.io/python-package-installation-attacks/
                !args.iter().any(|arg| arg == "install" || arg == "download")
            }
            "npm" => {
                // exec can fetch+run remote packages (npx behavior)
                // install fetches external packages; lifecycle scripts run arbitrary code
                // Ref: https://cheatsheetseries.owasp.org/cheatsheets/NPM_Security_Cheat_Sheet.html
                !args.iter().any(|arg| {
                    arg == "exec" || arg == "install" || arg == "i" || arg == "add" || arg == "ci"
                })
            }
            "cargo" => {
                // install fetches+builds external crate; build.rs executes arbitrary code
                // Ref: https://shnatsel.medium.com/do-not-run-any-cargo-commands-on-untrusted-projects
                !args.iter().any(|arg| arg == "install")
            }
            _ => true,
        }
    }

    /// Scan `command` for forbidden path arguments against a specific shell
    /// dialect. The dialect gates which redirect targets count as safe devices
    /// (the Windows `nul` null device is only a safe device under `cmd.exe`) and
    /// which relative forms are recognized as paths — Windows-relative paths are
    /// understood for both cmd.exe and PowerShell, including cross-platform
    /// PowerShell runtimes.
    pub fn forbidden_path_argument_for_shell(
        &self,
        command: &str,
        dialect: ShellDialect,
    ) -> Option<String> {
        self.forbidden_path_argument_impl(command, ShellGrammar::from(dialect), false)
    }

    /// Like [`SecurityPolicy::forbidden_workspace_path_argument`], but against
    /// a specific shell dialect: it uses the effective shell's path syntax and
    /// classifies platform-specific safe redirect devices by the shell that will
    /// execute the command, resolving relative candidates through symlinks
    /// before the workspace-boundary check.
    pub fn forbidden_workspace_path_argument_for_shell(
        &self,
        command: &str,
        dialect: ShellDialect,
    ) -> Option<String> {
        self.forbidden_path_argument_impl(command, ShellGrammar::from(dialect), true)
    }

    /// [`Self::forbidden_workspace_path_argument_for_shell`], in the grammar
    /// [`Self::command_shell`] chose.
    pub fn forbidden_workspace_path_argument_in(
        &self,
        command: &str,
        shell: CommandShell,
    ) -> Option<String> {
        self.forbidden_path_argument_impl(command, shell.grammar, true)
    }

    /// [`Self::forbidden_path_argument`], reading a POSIX command in the
    /// grammar [`Self::command_shell`] chose. The path syntax stays the host
    /// default's, as in [`Self::forbidden_path_argument`]; only which POSIX
    /// shell parses the command is taken from `shell`.
    pub fn forbidden_path_argument_in(&self, command: &str, shell: CommandShell) -> Option<String> {
        #[cfg(target_os = "windows")]
        let dialect = ShellDialect::WindowsCmd;
        #[cfg(not(target_os = "windows"))]
        let dialect = ShellDialect::Posix;

        let posix_shell = if dialect == shell.grammar.dialect {
            shell.grammar.posix_shell
        } else {
            PosixShell::Unknown
        };
        self.forbidden_path_argument_impl(
            command,
            ShellGrammar {
                dialect,
                posix_shell,
            },
            false,
        )
    }

    fn forbidden_path_argument_impl(
        &self,
        command: &str,
        shell: ShellGrammar,
        resolve_workspace: bool,
    ) -> Option<String> {
        let dialect = shell.dialect;
        if split_unquoted_segments_checked(command, shell).is_err() {
            // Name the opener rather than a path. The shell wrapper refuses
            // any `Some`, and guessing which later command runs is the bypass.
            return Some("unreadable heredoc delimiter".into());
        }
        let forbidden_candidate = |raw: &str| {
            let candidate = strip_wrapping_quotes(raw).trim();
            if candidate.is_empty() || candidate.contains("://") {
                return None;
            }
            if !looks_like_path_for_shell(candidate, dialect) {
                return None;
            }
            // String-level policy: absolute paths outside the workspace, `..`
            // traversal, `~user` forms, and forbidden prefixes.
            if !self.is_path_allowed_for_shell(candidate, dialect) {
                return Some(candidate.to_string());
            }
            // A workspace-relative argument can still escape the boundary via a
            // symlink whose target is outside the workspace: the string check
            // above passes because the literal path has no `..` and is not
            // absolute, yet the real target is elsewhere. The file tools already
            // block this by canonicalizing before checking; mirror that here for
            // the path-shaped argument forms this static scan can see (a full
            // boundary needs the execution-time sandbox). Resolve the deepest
            // existing ancestor (the leaf may be about to be created, e.g.
            // `touch link/new.txt`) and re-check the resolved target with the
            // symlink-aware policy.
            // For a command that runs IN the workspace, also resolve symlinks and
            // re-check: a workspace-relative arg can point outside via an
            // in-workspace symlink, which the string check above misses. A
            // command argument may be read OR written, so accept the resolved
            // target if it is allowed for EITHER (mirrors the string
            // `is_path_allowed`, which honors both read-only and write-only
            // roots). Fail closed otherwise: a target outside every allowed root
            // is blocked, and so is one that cannot be resolved at all (a symlink
            // cycle exhausting the hop budget) - `None` means "unresolvable", not
            // "allowed" - so a crafted chain cannot dodge the check.
            if resolve_workspace {
                match self.resolve_command_path_argument(candidate, dialect) {
                    Some(resolved)
                        if self.is_resolved_path_allowed(&resolved)
                            || self.is_resolved_path_readable(&resolved) => {}
                    _ => return Some(candidate.to_string()),
                }
            }
            None
        };
        let forbidden_non_redirect_candidate = |raw: &str| {
            let candidate = strip_wrapping_quotes(raw).trim();
            if candidate.is_empty() || candidate.contains("://") {
                return None;
            }
            if candidate.starts_with('-') {
                if let Some((_, value)) = candidate.split_once('=')
                    && let Some(blocked) = forbidden_candidate(value)
                {
                    return Some(blocked);
                }
                if let Some(value) = attached_short_option_value(candidate)
                    && let Some(blocked) = forbidden_candidate(value)
                {
                    return Some(blocked);
                }
                return None;
            }
            forbidden_candidate(candidate)
        };
        let executable_has_explicit_path_allowlist = |raw: &str| {
            let executable = strip_wrapping_quotes(raw).trim();
            self.allowed_commands.iter().any(|allowed| {
                let allowed = strip_wrapping_quotes(allowed).trim();
                allowed != "*"
                    && looks_like_path_for_shell(allowed, dialect)
                    && shell_path_tokens_equal(allowed, executable, dialect)
            })
        };

        for segment in split_unquoted_segments(command, shell) {
            let words = shell_words_after_env_assignments(&segment, dialect);
            let Some(executable) = words.first() else {
                continue;
            };

            let executable_redirect = executable
                .redirection
                .map_or(RedirectionArgument::None, |metadata| {
                    parse_redirection_argument_at(&executable.text, metadata)
                });

            let executable_without_redirect = match executable_redirect {
                RedirectionArgument::Target { prefix, .. }
                | RedirectionArgument::NeedsNextToken { prefix }
                | RedirectionArgument::FdOnly { prefix } => strip_wrapping_quotes(prefix).trim(),
                RedirectionArgument::None => strip_wrapping_quotes(&executable.text).trim(),
            };
            if !executable_has_explicit_path_allowlist(executable_without_redirect)
                && let Some(blocked) = forbidden_non_redirect_candidate(executable_without_redirect)
            {
                return Some(blocked);
            }
            let mut next_is_redirect_target = false;
            // Cover inline forms like `cat</etc/passwd`.
            match executable_redirect {
                RedirectionArgument::Target { target, .. } => {
                    if !is_safe_device_redirect_target(target, dialect)
                        && let Some(blocked) = forbidden_candidate(target)
                    {
                        return Some(blocked);
                    }
                }
                RedirectionArgument::NeedsNextToken { .. } => {
                    next_is_redirect_target = true;
                }
                RedirectionArgument::FdOnly { .. } | RedirectionArgument::None => {}
            }

            for token in words.iter().skip(1) {
                let candidate = strip_wrapping_quotes(&token.text).trim();
                if candidate.is_empty() {
                    continue;
                }

                if next_is_redirect_target {
                    next_is_redirect_target = false;
                    if is_safe_device_redirect_target(candidate, dialect) {
                        continue;
                    }
                    if let Some(blocked) = forbidden_candidate(candidate) {
                        return Some(blocked);
                    }
                    continue;
                }

                if candidate.contains("://") {
                    continue;
                }

                let redirection = token
                    .redirection
                    .map_or(RedirectionArgument::None, |metadata| {
                        parse_redirection_argument_at(&token.text, metadata)
                    });
                match redirection {
                    RedirectionArgument::Target { prefix, target } => {
                        if let Some(blocked) = forbidden_non_redirect_candidate(prefix) {
                            return Some(blocked);
                        }
                        if is_safe_device_redirect_target(target, dialect) {
                            continue;
                        }
                        if let Some(blocked) = forbidden_candidate(target) {
                            return Some(blocked);
                        }
                    }
                    RedirectionArgument::NeedsNextToken { prefix } => {
                        if let Some(blocked) = forbidden_non_redirect_candidate(prefix) {
                            return Some(blocked);
                        }
                        next_is_redirect_target = true;
                        continue;
                    }
                    RedirectionArgument::FdOnly { prefix } => {
                        if let Some(blocked) = forbidden_non_redirect_candidate(prefix) {
                            return Some(blocked);
                        }
                        continue;
                    }
                    RedirectionArgument::None => {}
                }

                // Handle option assignment forms like `--file=/etc/passwd`.
                if let Some(blocked) = forbidden_non_redirect_candidate(candidate) {
                    return Some(blocked);
                }
                if candidate.starts_with('-') {
                    continue;
                }
            }
        }

        None
    }

    /// Return the first path-like executable or argument blocked by path
    /// policy using the host platform's default shell syntax.
    ///
    /// String-level command path guard: flags a path argument that is absolute
    /// and outside the workspace, uses `..` traversal, a `~user` form, or a
    /// forbidden prefix. Best-effort token parsing, intended as a safety gate
    /// before command execution. Does NOT resolve symlinks, so it is safe for
    /// callers whose working directory is NOT the workspace (e.g. cron jobs run
    /// in `data_dir`). Shell/skill tools, which run IN the workspace, should use
    /// [`SecurityPolicy::forbidden_workspace_path_argument`], which additionally
    /// follows in-workspace symlinks to block escapes.
    pub fn forbidden_path_argument(&self, command: &str) -> Option<String> {
        #[cfg(target_os = "windows")]
        let dialect = ShellDialect::WindowsCmd;
        #[cfg(not(target_os = "windows"))]
        let dialect = ShellDialect::Posix;

        self.forbidden_path_argument_for_shell(command, dialect)
    }

    /// Like [`SecurityPolicy::forbidden_path_argument`] but for a command that
    /// runs IN the workspace: each workspace-relative path argument is also
    /// resolved (following symlinks, including dangling ones) and re-checked
    /// against the workspace boundary with the host platform's default shell
    /// syntax, catching an in-workspace symlink that points outside for the
    /// argument forms this static scan can see.
    ///
    /// This is best-effort, defense-in-depth hardening over a token-scanned
    /// command line - NOT a complete workspace boundary, and NOT equivalent to
    /// the file tools, which resolve an operation-aware target at the call site.
    /// It flags a *path-shaped* argument (one with a separator, e.g. `link/x`, a
    /// redirect target, or an absolute / `..` form) that escapes via an
    /// in-workspace symlink. It does NOT, and cannot from a static parse, cover:
    /// a *bare* argument with no separator (`cat somelink`) that is a symlink; a
    /// path computed at run time via variable expansion or command substitution
    /// (`$VAR`, `$(...)`), `eval`, or a write done inside an executed script
    /// (`sh ./x.sh`, where only the script path is scanned); a quoted path
    /// holding whitespace (`"link dir/out"`), which the whitespace tokenizer
    /// fragments; read-vs-write direction (an argument may be read or written, so
    /// a resolved target allowed for EITHER passes, unlike the operation-aware
    /// file tools); or non-Unix relative forms (a `link\file` path on Windows). A
    /// shell command is Turing-complete; complete containment is the execution
    /// boundary (the OS sandbox and the broader granular sandbox-policy work),
    /// not this preflight.
    pub fn forbidden_workspace_path_argument(&self, command: &str) -> Option<String> {
        #[cfg(target_os = "windows")]
        let dialect = ShellDialect::WindowsCmd;
        #[cfg(not(target_os = "windows"))]
        let dialect = ShellDialect::Posix;

        self.forbidden_workspace_path_argument_for_shell(command, dialect)
    }

    fn is_path_allowed_for_shell(&self, path: &str, dialect: ShellDialect) -> bool {
        if !shell_uses_windows_path_syntax(dialect) {
            return self.is_path_allowed(path);
        }

        // `C:relative` resolves against a per-drive current directory on
        // Windows rather than the configured workspace. There is no stable
        // workspace-relative interpretation, so fail closed on every host.
        if is_windows_drive_relative(path) {
            return false;
        }

        // PowerShell accepts backslashes as path separators on every host.
        // Normalize only for policy evaluation; the original command remains
        // unchanged for process construction.
        let normalized = path.replace('\\', "/");

        // A drive-qualified path cannot name the Unix workspace. This matters
        // for cross-platform PowerShell, where host-native `Path` parsing would
        // otherwise treat `C:/outside` as an ordinary relative path.
        #[cfg(not(target_os = "windows"))]
        if self.workspace_only && has_windows_drive_prefix(&normalized) {
            return false;
        }

        // On Windows, a leading slash without a drive is rooted on the current
        // drive. It is not workspace-relative even though `Path::is_absolute`
        // intentionally reports false for this form.
        #[cfg(target_os = "windows")]
        if self.workspace_only && normalized.starts_with('/') && !normalized.starts_with("//") {
            return false;
        }

        self.is_path_allowed(&normalized)
    }

    /// Resolve a shell command path argument to the canonical target used for
    /// workspace-boundary checks. Relative arguments are taken relative to the
    /// workspace directory; `~` is expanded. Because a command may be about to
    /// CREATE the leaf (e.g. `touch dir/new.txt`), symlinks are resolved on the
    /// deepest existing ancestor and any non-existent trailing components are
    /// re-appended, so an in-workspace symlink pointing outside is followed to
    /// its real target. Relative arguments are joined onto the workspace
    /// directory BEFORE resolving. Returns `None` when no trustworthy target
    /// exists: a null byte in the input, or an unresolvable path (a symlink
    /// cycle exhausting the resolver's hop budget). Callers MUST treat `None`
    /// as a block (fail closed), never as "nothing to re-check" - see
    /// `forbidden_path_argument_impl`.
    fn resolve_command_path_argument(
        &self,
        candidate: &str,
        dialect: ShellDialect,
    ) -> Option<PathBuf> {
        if candidate.contains('\0') {
            return None;
        }
        let normalized;
        let candidate = if shell_uses_windows_path_syntax(dialect) {
            normalized = candidate.replace('\\', "/");
            normalized.as_str()
        } else {
            candidate
        };
        let expanded = expand_user_path(candidate);
        let joined = if expanded.is_absolute() {
            expanded
        } else {
            self.workspace_dir.join(expanded)
        };
        resolve_symlinked_path(&joined)
    }

    /// Check if a file path is allowed (no path traversal, within workspace)
    pub fn is_path_allowed(&self, path: &str) -> bool {
        // Block null bytes (can truncate paths in C-backed syscalls)
        if path.contains('\0') {
            return false;
        }

        // Block path traversal: check for ".." as a path component
        if Path::new(path)
            .components()
            .any(|c| matches!(c, std::path::Component::ParentDir))
        {
            return false;
        }

        // Block URL-encoded traversal attempts (e.g. ..%2f)
        let lower = path.to_lowercase();
        if lower.contains("..%2f") || lower.contains("%2f..") {
            return false;
        }

        // Reject "~user" forms because the shell expands them at runtime and
        // they can escape workspace policy.
        if path.starts_with('~') && path != "~" && !path.starts_with("~/") {
            return false;
        }

        // Expand "~" for consistent matching with forbidden paths and allowlists.
        let expanded_path = expand_user_path(path);

        // The host null device is always permitted regardless of workspace or
        // forbidden-path config (`/dev/null` on Unix, `nul` on Windows); the
        // rest of /dev remains blocked as usual.
        if is_null_device(&expanded_path) {
            return true;
        }

        if expanded_path.is_absolute() {
            let in_workspace = expanded_path.starts_with(&self.workspace_dir);
            let in_allowed_root = self
                .allowed_roots
                .iter()
                .any(|root| expanded_path.starts_with(root));
            let in_read_only_root = self
                .allowed_roots_read_only
                .iter()
                .any(|root| expanded_path.starts_with(root));
            let in_write_only_root = self
                .allowed_roots_write_only
                .iter()
                .any(|root| expanded_path.starts_with(root));

            if in_workspace || in_allowed_root || in_read_only_root || in_write_only_root {
                // Deny-before-allow when a `forbidden_paths` entry is at least
                // as specific as the allowing root, so an explicit forbidden
                // path nested under an allowed root (or the workspace) still
                // blocks. A broad default forbidden root (e.g. `/home`) does
                // not override a more specific operator allowlist entry.
                let allow_depth = deepest_allow_depth(
                    &self.workspace_dir,
                    &[
                        &self.allowed_roots,
                        &self.allowed_roots_read_only,
                        &self.allowed_roots_write_only,
                    ],
                    &expanded_path,
                    PathMatchNamespace::Configured,
                );
                let forbidden_depth = deepest_forbidden_depth(
                    &self.forbidden_paths,
                    &expanded_path,
                    PathMatchNamespace::Configured,
                );
                if forbidden_overrides_allow(forbidden_depth, allow_depth) {
                    return false;
                }
                return true;
            }

            // Absolute path outside workspace/allowed roots — block when
            // workspace_only, or fall through to forbidden-prefix check.
            if self.workspace_only {
                return false;
            }
        }

        // Block forbidden paths using path-component-aware matching
        for forbidden in &self.forbidden_paths {
            let forbidden_path = expand_user_path(forbidden);
            if expanded_path.starts_with(forbidden_path) {
                return false;
            }
        }

        true
    }

    pub fn is_resolved_path_readable(&self, resolved: &Path) -> bool {
        // Preserve the unconditional null-device exception before attempting
        // filesystem resolution: on Unix `/dev/null` is always readable even if
        // the device node does not resolve; on Windows `nul` / `\\.\nul` are
        // not canonicalizable paths. See `is_null_device`.
        if is_null_device(resolved) {
            return true;
        }
        // Keep the target in the same filesystem namespace as every policy
        // prefix, even when a caller supplies an absolute but not yet fully
        // resolved spelling. Failure to resolve (for example, a symlink cycle)
        // must deny rather than fall back to a potentially aliased path.
        let Some(resolved_path) = resolve_symlinked_path(resolved) else {
            return false;
        };
        let resolved = resolved_path.as_path();

        // Universal POSIX device files: any operator running on Linux,
        // macOS, or BSD expects these to be readable. Adding them to
        // the per-agent config would be friction without security
        // benefit (they have no agent-relevant content).
        const POSIX_DEVICE_READS: &[&str] =
            &["/dev/null", "/dev/zero", "/dev/random", "/dev/urandom"];
        for device in POSIX_DEVICE_READS {
            if resolved == Path::new(device) {
                return true;
            }
        }

        // Workspace + read-write allowlist + read-only allowlist.
        // Inlined rather than delegating to `is_resolved_path_allowed`
        // so the write-only allowlist is intentionally NOT in scope
        // here.
        let workspace_root = self
            .workspace_dir
            .canonicalize()
            .unwrap_or_else(|_| self.workspace_dir.clone());

        let allow_depth = deepest_allow_depth(
            &workspace_root,
            &[&self.allowed_roots, &self.allowed_roots_read_only],
            resolved,
            PathMatchNamespace::Resolved,
        );

        if allow_depth.is_some() {
            // Deny-before-allow: an explicit `forbidden_paths` entry at least as
            // specific as the allowing root denies reads even inside the
            // workspace or a read allowlist. A broad default forbidden root
            // (e.g. `/home`) does not override a more specific allowlist entry.
            let forbidden_depth = deepest_forbidden_depth(
                &self.forbidden_paths,
                resolved,
                PathMatchNamespace::Resolved,
            );
            if forbidden_overrides_allow(forbidden_depth, allow_depth) {
                return false;
            }
            return true;
        }

        for root in &self.allowed_roots_write_only {
            if namespace_prefix_match_depth(root, resolved, PathMatchNamespace::Resolved).is_some()
            {
                return false;
            }
        }

        // Forbidden paths gate after the explicit allowlists so the
        // allowlists can coexist with broad default forbidden roots
        // such as `/home` and `/tmp`.
        if deepest_forbidden_depth(
            &self.forbidden_paths,
            resolved,
            PathMatchNamespace::Resolved,
        )
        .is_some()
        {
            return false;
        }
        if !self.workspace_only {
            return true;
        }
        false
    }

    fn configured_approved_roots(&self, resolved: &Path, include_read_only: bool) -> Vec<PathBuf> {
        let mut approved_roots = Vec::new();
        for root in std::iter::once(&self.workspace_dir).chain(self.allowed_roots.iter()) {
            let canonical = root.canonicalize().unwrap_or_else(|_| root.clone());
            if resolved.starts_with(&canonical) && !approved_roots.contains(&canonical) {
                approved_roots.push(canonical);
            }
        }
        if include_read_only {
            for root in &self.allowed_roots_read_only {
                let canonical = root.canonicalize().unwrap_or_else(|_| root.clone());
                if resolved.starts_with(&canonical) && !approved_roots.contains(&canonical) {
                    approved_roots.push(canonical);
                }
            }
        }
        approved_roots
    }

    fn approved_roots(&self, resolved: &Path, include_read_only: bool) -> Vec<PathBuf> {
        // A non-workspace-only policy authorizes paths outside every configured
        // root (subject to the ordinary forbidden-path checks). It therefore
        // has no bounded discovery root; callers may continue searching for a
        // parent-owned resource. The compatibility accessor below retains the
        // configured-root result for handle-bound file delivery.
        if !self.workspace_only {
            return Vec::new();
        }
        self.configured_approved_roots(resolved, include_read_only)
    }

    /// Return every canonical bounded root that authorizes reading `resolved`.
    ///
    /// A path can be covered by overlapping grants, such as a workspace nested
    /// in a broader explicit allowed root. Callers that discover a parent-owned
    /// resource must consider every applicable boundary; choosing the first one
    /// would make valid access depend on grant order. Returns an empty vector
    /// when no bounded allowlist root contains the path (for example, a fully
    /// permissive non-`workspace_only` policy or a device path). Assumes
    /// `resolved` is already canonical and has passed
    /// [`Self::is_resolved_path_readable`].
    pub fn approved_read_roots(&self, resolved: &Path) -> Vec<PathBuf> {
        self.approved_roots(resolved, true)
    }

    /// Return the first canonical configured root that authorizes reading
    /// `resolved`.
    ///
    /// This compatibility accessor intentionally ignores `workspace_only` to
    /// preserve the existing configured-root contract for handle-bound callers.
    /// It is not the first value from [`Self::approved_read_roots`];
    /// parent-resource discovery must use that plural accessor instead.
    pub fn approved_read_root(&self, resolved: &Path) -> Option<PathBuf> {
        self.configured_approved_roots(resolved, true)
            .into_iter()
            .next()
    }

    /// Canonicalize a caller-supplied path into the same filesystem namespace
    /// the policy prefixes live in, exactly as the internal readability and
    /// allowlist checks do before they compare.
    ///
    /// Every accessor that takes a `resolved` path — `is_resolved_path_readable`,
    /// `is_resolved_path_allowed`, `approved_read_root`, `approved_read_roots`,
    /// `approved_write_roots` — assumes its input is already canonical. Callers
    /// that authorize a request and then bind the granted operation to a root
    /// MUST resolve the request once through this accessor and carry the
    /// returned target into both the check and the operation. Feeding the raw
    /// request spelling to `approved_read_root` while checking readability on a
    /// separately resolved target lets an alias that resolves inside an
    /// entitled root pass readability yet fall out of every configured root
    /// (returning `None`/`Unconfined`), after which the operation would touch
    /// the still-swappable raw path outside the boundary. Returns `None` when
    /// the path cannot be resolved (a symlink cycle, or a target whose parents
    /// do not exist); the caller MUST fail closed.
    pub fn resolve_policy_target(&self, path: &Path) -> Option<PathBuf> {
        // The host null device may not be canonicalizable (`/dev/null` on Unix
        // when the device node does not resolve, `nul` on Windows). Return it
        // as-is so callers that resolve before checking still see the
        // exception instead of failing closed.
        if is_null_device(path) {
            return Some(path.to_path_buf());
        }
        resolve_symlinked_path(path)
    }

    /// Return every canonical bounded root that authorizes writing `resolved`.
    ///
    /// This intentionally excludes `allowed_roots_read_only`; callers use it
    /// when a parent-owned resource may be discovered before a mutation.
    /// Assumes `resolved` is already canonical and has passed
    /// [`Self::is_resolved_path_allowed`].
    pub fn approved_write_roots(&self, resolved: &Path) -> Vec<PathBuf> {
        self.approved_roots(resolved, false)
    }

    pub fn is_resolved_path_allowed(&self, resolved: &Path) -> bool {
        // Preserve the unconditional null-device exception before attempting
        // filesystem resolution: on Unix `/dev/null` is always writable even if
        // the device node does not resolve; on Windows `nul` / `\\.\nul` are
        // not canonicalizable paths. See `is_null_device`.
        if is_null_device(resolved) {
            return true;
        }
        // See `is_resolved_path_readable`: authorization compares the target,
        // allow roots, and forbidden entries only after the same resolution
        // step, and fails closed when no trustworthy target can be produced.
        let Some(resolved_path) = resolve_symlinked_path(resolved) else {
            return false;
        };
        let resolved = resolved_path.as_path();

        if is_null_device(resolved) {
            return true;
        }

        // Prefer canonical workspace root so `/a/../b` style config paths don't
        // cause false positives or negatives.
        let workspace_root = self
            .workspace_dir
            .canonicalize()
            .unwrap_or_else(|_| self.workspace_dir.clone());

        // Extra allowed roots and write-only cross-agent grants authorize this
        // write path. `is_resolved_path_readable` intentionally does not include
        // write-only roots because `AccessMode::Write` is one-way by design.
        let allow_depth = deepest_allow_depth(
            &workspace_root,
            &[&self.allowed_roots, &self.allowed_roots_write_only],
            resolved,
            PathMatchNamespace::Resolved,
        );

        if allow_depth.is_some() {
            // Deny-before-allow: an explicit `forbidden_paths` entry at least as
            // specific as the allowing root denies even inside the workspace or
            // an allowed root, preventing symlink escapes and sensitive-directory
            // access. A broad default forbidden root (e.g. `/home`) does not
            // override a more specific operator allowlist entry.
            let forbidden_depth = deepest_forbidden_depth(
                &self.forbidden_paths,
                resolved,
                PathMatchNamespace::Resolved,
            );
            if forbidden_overrides_allow(forbidden_depth, allow_depth) {
                return false;
            }
            return true;
        }

        // For paths outside workspace/allowlist, block forbidden roots to
        // prevent symlink escapes and sensitive directory access.
        if deepest_forbidden_depth(
            &self.forbidden_paths,
            resolved,
            PathMatchNamespace::Resolved,
        )
        .is_some()
        {
            return false;
        }

        // When workspace_only is disabled the user explicitly opted out of
        // workspace confinement after forbidden-path checks are applied.
        if !self.workspace_only {
            return true;
        }

        false
    }

    fn runtime_config_dirs(&self) -> Vec<PathBuf> {
        let canon = |p: &Path| p.canonicalize().unwrap_or_else(|_| p.to_path_buf());
        let mut dirs: Vec<PathBuf> = Vec::new();
        if let Some(parent) = self.config_path.as_deref().and_then(Path::parent) {
            dirs.push(canon(parent));
        }
        if let Some(parent) = self.workspace_dir.parent() {
            let dir = canon(parent);
            if !dirs.contains(&dir) {
                dirs.push(dir);
            }
        }
        if let Some(data_dir) = self.data_dir.as_deref() {
            let dir = canon(data_dir);
            if !dirs.contains(&dir) {
                dirs.push(dir);
            }
        }
        dirs
    }

    pub fn is_runtime_config_path(&self, resolved: &Path) -> bool {
        let Some(file_name) = resolved.file_name().and_then(|value| value.to_str()) else {
            return false;
        };
        let is_protected_name = file_name == "config.toml"
            || file_name == "config.toml.bak"
            || file_name.starts_with(".config.toml.tmp-")
            || file_name == "estop-state.json"
            || file_name == "otp-secret"
            || file_name == "webauthn_credentials.json";
        if !is_protected_name {
            return false;
        }
        let Some(parent) = resolved.parent() else {
            return false;
        };
        self.runtime_config_dirs()
            .iter()
            .any(|dir| parent == dir.as_path())
    }

    pub fn runtime_config_violation_message(&self, resolved: &Path) -> String {
        format!(
            "Refusing to modify ZeroClaw runtime config/state file: {}. Use dedicated config tools or edit it manually outside the agent loop.",
            resolved.display()
        )
    }

    pub fn resolved_path_violation_message(&self, resolved: &Path) -> String {
        let guidance = if self.allowed_roots.is_empty() {
            "Add the directory to [autonomy].allowed_roots (for example: allowed_roots = [\"/absolute/path\"]), or move the file into the workspace."
        } else {
            "Add a matching parent directory to [autonomy].allowed_roots, or move the file into the workspace."
        };

        format!(
            "Resolved path escapes workspace allowlist: {}. {}",
            resolved.display(),
            guidance
        )
    }

    /// Check if autonomy level permits any action at all
    pub fn can_act(&self) -> bool {
        self.autonomy != AutonomyLevel::ReadOnly
    }

    // ── Tool Operation Gating ──────────────────────────────────────────────
    // Read operations bypass autonomy and rate checks because they have
    // no side effects. Act operations must pass both the autonomy gate
    // (not read-only) and the sliding-window rate limiter.

    /// Check whether autonomy permits a tool operation without recording it.
    pub fn authorize_tool_operation(
        &self,
        operation: ToolOperation,
        operation_name: &str,
    ) -> Result<(), String> {
        match operation {
            ToolOperation::Read => Ok(()),
            ToolOperation::Act => {
                if !self.can_act() {
                    return Err(format!(
                        "Security policy: read-only mode, cannot perform '{operation_name}'"
                    ));
                }
                Ok(())
            }
        }
    }

    /// Enforce policy and record an action for callers without a rate-limit wrapper.
    pub fn enforce_tool_operation(
        &self,
        operation: ToolOperation,
        operation_name: &str,
    ) -> Result<(), String> {
        self.authorize_tool_operation(operation, operation_name)?;
        if operation == ToolOperation::Act && !self.record_action() {
            return Err("Rate limit exceeded: action budget exhausted".to_string());
        }
        Ok(())
    }

    /// Atomically reserve one action slot for a production-wrapped invocation.
    pub fn reserve_action(&self) -> Option<ActionReservation> {
        self.tracker.reserve_for_current(self.max_actions_per_hour)
    }

    /// Record an action for the current sender and check if rate-limited.
    /// Returns `true` if allowed, `false` if budget exhausted.
    pub fn record_action(&self) -> bool {
        self.tracker.record_for_current(self.max_actions_per_hour)
    }

    /// Check if the current sender would be rate-limited without recording.
    pub fn is_rate_limited(&self) -> bool {
        self.tracker
            .is_limited_for_current(self.max_actions_per_hour)
    }

    pub fn resolve_tool_path(&self, path: &str) -> PathBuf {
        let expanded = expand_user_path(path);
        if expanded.is_absolute() {
            expanded
        } else if let Some(workspace_hint) = rootless_path(&self.workspace_dir) {
            if let Ok(stripped) = expanded.strip_prefix(&workspace_hint) {
                if stripped.as_os_str().is_empty() {
                    self.workspace_dir.clone()
                } else {
                    self.workspace_dir.join(stripped)
                }
            } else if let Some(stripped) =
                workspace_prefixed_relative_suffix(&expanded, &self.workspace_dir)
            {
                if stripped.as_os_str().is_empty() {
                    self.workspace_dir.clone()
                } else {
                    self.workspace_dir.join(stripped)
                }
            } else {
                self.workspace_dir.join(expanded)
            }
        } else {
            self.workspace_dir.join(expanded)
        }
    }

    pub fn is_under_allowed_root(&self, path: &str) -> bool {
        let expanded = expand_user_path(path);
        if !expanded.is_absolute() {
            return false;
        }
        roots_contain(&self.allowed_roots, &expanded)
            || roots_contain(&self.allowed_roots_write_only, &expanded)
    }

    #[must_use]
    pub fn is_under_read_only_allowed_root(&self, path: &str) -> bool {
        let expanded = expand_user_path(path);
        if !expanded.is_absolute() {
            return false;
        }
        roots_contain(&self.allowed_roots_read_only, &expanded)
    }

    /// Union of all three root tiers; directionality is enforced later
    /// by the resolved-path checks.
    #[must_use]
    pub fn is_under_any_allowed_root(&self, path: &str) -> bool {
        self.is_under_allowed_root(path) || self.is_under_read_only_allowed_root(path)
    }

    pub fn ensure_no_escalation_beyond(
        &self,
        parent: &SecurityPolicy,
    ) -> Result<(), EscalationViolation> {
        // Autonomy: child must not exceed parent. ReadOnly < Supervised
        // < Full per the AutonomyLevel ordering.
        if self.autonomy > parent.autonomy {
            return Err(EscalationViolation::AutonomyAboveParent {
                child: self.autonomy,
                parent: parent.autonomy,
            });
        }

        for root in &self.allowed_roots {
            if !parent.allowed_roots.iter().any(|p| path_contains(p, root)) {
                return Err(EscalationViolation::ReadWriteRootNotInParent { path: root.clone() });
            }
        }
        for root in &self.allowed_roots_read_only {
            let in_parent_rw = parent.allowed_roots.iter().any(|p| path_contains(p, root));
            let in_parent_ro = parent
                .allowed_roots_read_only
                .iter()
                .any(|p| path_contains(p, root));
            if !in_parent_rw && !in_parent_ro {
                return Err(EscalationViolation::ReadOnlyRootNotInParent { path: root.clone() });
            }
        }
        for root in &self.allowed_roots_write_only {
            let in_parent_rw = parent.allowed_roots.iter().any(|p| path_contains(p, root));
            let in_parent_wo = parent
                .allowed_roots_write_only
                .iter()
                .any(|p| path_contains(p, root));
            if !in_parent_rw && !in_parent_wo {
                return Err(EscalationViolation::WriteOnlyRootNotInParent { path: root.clone() });
            }
        }
        for cmd in &self.allowed_commands {
            if !parent
                .allowed_commands
                .iter()
                .any(|p| command_allowlist_entries_equivalent(p, cmd))
            {
                return Err(EscalationViolation::CommandNotInParent {
                    command: cmd.clone(),
                });
            }
        }
        if parent.workspace_only && !self.workspace_only {
            return Err(EscalationViolation::WorkspaceOnlyDisabledByChild);
        }

        // Forbidden paths run the OPPOSITE direction from allowlists:
        // the parent's forbidden set must be a subset of the child's,
        // i.e. the child cannot drop a parent's forbidden entry.
        for parent_forbidden in &parent.forbidden_paths {
            if !self.forbidden_paths.iter().any(|c| c == parent_forbidden) {
                return Err(EscalationViolation::ForbiddenPathDroppedByChild {
                    path: parent_forbidden.clone(),
                });
            }
        }

        // shell_env_passthrough is a leak surface: every child entry
        // must already be on the parent's list.
        for var in &self.shell_env_passthrough {
            if !parent.shell_env_passthrough.iter().any(|p| p == var) {
                return Err(EscalationViolation::ShellEnvPassthroughExpanded {
                    variable: var.clone(),
                });
            }
        }

        if self.max_actions_per_hour > parent.max_actions_per_hour {
            return Err(EscalationViolation::MaxActionsExceeded {
                child: self.max_actions_per_hour,
                parent: parent.max_actions_per_hour,
            });
        }
        if self.max_cost_per_day_cents > parent.max_cost_per_day_cents {
            return Err(EscalationViolation::MaxCostExceeded {
                child: self.max_cost_per_day_cents,
                parent: parent.max_cost_per_day_cents,
            });
        }
        if self.shell_timeout_secs > parent.shell_timeout_secs {
            return Err(EscalationViolation::ShellTimeoutExceeded {
                child: self.shell_timeout_secs,
                parent: parent.shell_timeout_secs,
            });
        }
        if parent.block_high_risk_commands && !self.block_high_risk_commands {
            return Err(EscalationViolation::BlockHighRiskCommandsDisabledByChild);
        }
        if parent.require_approval_for_medium_risk && !self.require_approval_for_medium_risk {
            return Err(EscalationViolation::RequireApprovalDisabledByChild);
        }

        Ok(())
    }

    pub fn from_risk_profile(
        risk_profile: &crate::schema::RiskProfileConfig,
        workspace_dir: &Path,
    ) -> Self {
        Self::from_profiles(risk_profile, None, workspace_dir)
    }

    pub fn from_profiles(
        risk_profile: &crate::schema::RiskProfileConfig,
        runtime_profile: Option<&crate::schema::RuntimeProfileConfig>,
        workspace_dir: &Path,
    ) -> Self {
        // When autonomy is Full, disable workspace_only so the agent can
        // access paths outside the workspace. Forbidden-path checks still
        // apply, preventing access to sensitive system directories.
        let effective_workspace_only = if risk_profile.level == AutonomyLevel::Full {
            false
        } else {
            risk_profile.workspace_only
        };

        let runtime_default = crate::schema::RuntimeProfileConfig::default();
        let runtime = runtime_profile.unwrap_or(&runtime_default);

        Self {
            autonomy: risk_profile.level,
            risk_profile_name: String::new(),
            delegation_policy: risk_profile.delegation_policy.clone(),
            workspace_dir: workspace_dir.to_path_buf(),
            // Set by `for_agent` once the install root is known; the
            // profile-only constructor has no config path.
            config_path: None,
            // Set by `for_agent` once the data dir is known; the
            // profile-only constructor has no data dir.
            data_dir: None,
            workspace_only: effective_workspace_only,
            allowed_commands: risk_profile.allowed_commands.clone(),
            forbidden_paths: risk_profile.forbidden_paths.clone(),
            allowed_roots: risk_profile
                .allowed_roots
                .iter()
                .filter(|root| {
                    let t = root.trim();
                    !t.is_empty() && t != crate::traits::UNSET_DISPLAY && t != "*"
                })
                .map(|root| {
                    let expanded = expand_user_path(root);
                    if expanded.is_absolute() {
                        expanded
                    } else {
                        workspace_dir.join(expanded)
                    }
                })
                .collect(),
            allowed_roots_read_only: Vec::new(),
            allowed_roots_write_only: Vec::new(),
            max_actions_per_hour: runtime.max_actions_per_hour,
            max_cost_per_day_cents: runtime.max_cost_per_day_cents,
            require_approval_for_medium_risk: risk_profile.require_approval_for_medium_risk,
            block_high_risk_commands: risk_profile.block_high_risk_commands,
            shell_env_passthrough: risk_profile.shell_env_passthrough.clone(),
            shell_timeout_secs: runtime.shell_timeout_secs,
            allowed_tools: risk_profile.effective_allowed_tools(),
            excluded_tools: if risk_profile.excluded_tools.is_empty() {
                None
            } else {
                Some(risk_profile.excluded_tools.clone())
            },
            auto_approve: risk_profile.auto_approve.clone(),
            always_ask: risk_profile.always_ask.clone(),
            sandbox_enabled: risk_profile.sandbox_enabled,
            sandbox_backend: risk_profile.sandbox_backend.clone(),
            sandbox_image: risk_profile.sandbox_image.clone(),
            firejail_args: risk_profile.firejail_args.clone(),
            tracker: PerSenderTracker::new(),
        }
    }

    /// Whether the sandbox chosen for this profile may be a container, which
    /// runs its image's shell rather than the host's. `auto` may pick Docker
    /// when no host sandbox is available, so it counts. A disabled sandbox and
    /// the host backends, which fall back to no sandbox, do not.
    fn container_sandbox_possible(&self) -> bool {
        if self.sandbox_enabled == Some(false) {
            return false;
        }
        let backend = self
            .sandbox_backend
            .as_deref()
            .map(str::trim)
            .filter(|backend| !backend.is_empty())
            .map(crate::schema::parse_sandbox_backend)
            .unwrap_or_default();
        matches!(
            backend,
            crate::schema::SandboxBackend::Auto | crate::schema::SandboxBackend::Docker
        )
    }

    pub fn for_agent(config: &crate::schema::Config, agent_alias: &str) -> anyhow::Result<Self> {
        let risk_profile = config.risk_profile_for_agent(agent_alias).ok_or_else(|| {
            ::zeroclaw_log::record!(
                ERROR,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                    .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                    .with_attrs(::serde_json::json!({"agent_alias": agent_alias})),
                "SecurityPolicy::for_agent: agent has no resolvable risk_profile"
            );
            anyhow::Error::msg(format!(
                "agents.{agent_alias} has no resolvable risk_profile (load-time validation should have caught this)"
            ))
        })?;
        let runtime_profile = config.runtime_profile_for_agent(agent_alias);
        // Per-agent workspace becomes the SecurityPolicy boundary so
        // file_read/write/edit and the shell tool jail to the agent's
        // own dir, not the install-wide legacy path.
        let agent_workspace = config.agent_workspace_dir(agent_alias);
        // The per-agent workspace is the shell tool's spawn cwd and the file-tool
        // jail root. Create it here so every path that builds a per-agent policy
        // (agent loop, gateway, channels) has the directory present. A missing cwd
        // makes the shell tool's process spawn fail with ENOENT on a fresh agent.
        std::fs::create_dir_all(&agent_workspace).with_context(|| {
            format!(
                "SecurityPolicy::for_agent: failed to create agent workspace dir {}",
                agent_workspace.display()
            )
        })?;
        let mut policy = Self::from_profiles(risk_profile, runtime_profile, &agent_workspace);
        if let Some(agent_cfg) = config.agents.get(agent_alias) {
            policy.risk_profile_name = agent_cfg.risk_profile.trim().to_string();
        }
        policy.config_path = Some(config.config_path.clone());
        // Runtime data dir: same predicate extends there so state files
        // that the gateway constructs with `&config.data_dir`
        // (`webauthn_credentials.json` for WebAuthnManager) are protected
        // from agent overwrites when `data_dir` overlaps an allowed root.
        policy.data_dir = Some(config.data_dir.clone());

        policy
            .allowed_roots_read_only
            .push(config.shared_workspace_dir().join("skills"));

        if let Some(agent_cfg) = config.agents.get(agent_alias) {
            for (sibling_alias, mode) in &agent_cfg.workspace.access {
                let sibling_dir = config.agent_workspace_dir(sibling_alias.as_str());
                match mode {
                    crate::multi_agent::AccessMode::Read => {
                        policy.allowed_roots_read_only.push(sibling_dir);
                    }
                    crate::multi_agent::AccessMode::Write => {
                        policy.allowed_roots_write_only.push(sibling_dir);
                    }
                    crate::multi_agent::AccessMode::ReadWrite => {
                        policy.allowed_roots.push(sibling_dir);
                    }
                }
            }

            // The escape-hatch flag retains its all-paths semantics —
            // agents that genuinely need to read or write outside any
            // per-agent scope opt in here. Defaults to false.
            if agent_cfg.workspace.unrestricted_filesystem {
                policy.workspace_only = false;
            }
        }

        Ok(policy)
    }

    pub fn prompt_summary(&self) -> String {
        use std::fmt::Write;

        let mut out = String::new();

        // Autonomy level
        let _ = writeln!(out, "**Autonomy level**: {:?}", self.autonomy);

        // Workspace constraint
        if self.workspace_only {
            let _ = writeln!(
                out,
                "**Workspace boundary**: file operations are restricted to `{}`.",
                self.workspace_dir.display()
            );
        }

        // Allowed roots
        if !self.allowed_roots.is_empty() {
            let roots: Vec<String> = self
                .allowed_roots
                .iter()
                .map(|p| format!("`{}`", p.display()))
                .collect();
            let _ = writeln!(out, "**Additional allowed paths**: {}", roots.join(", "));
        }

        // Allowed commands
        if !self.allowed_commands.is_empty() {
            let cmds: Vec<String> = self
                .allowed_commands
                .iter()
                .map(|c| format!("`{c}`"))
                .collect();
            let _ = writeln!(
                out,
                "**Allowed shell commands**: {}. \
                 You may execute these commands freely.",
                cmds.join(", ")
            );
        }

        // Forbidden paths
        if !self.forbidden_paths.is_empty() {
            let paths: Vec<String> = self
                .forbidden_paths
                .iter()
                .map(|p| format!("`{p}`"))
                .collect();
            let _ = writeln!(
                out,
                "**Forbidden paths**: {}. \
                 Avoid accessing these paths.",
                paths.join(", ")
            );
        }

        // Risk controls
        if self.block_high_risk_commands {
            let _ = writeln!(
                out,
                "Exercise caution with destructive commands (rm, kill, reboot, etc.)."
            );
        }
        if self.require_approval_for_medium_risk {
            let _ = writeln!(
                out,
                "**Medium-risk commands** require user approval before execution."
            );
        }

        // Rate limit
        let _ = writeln!(
            out,
            "**Rate limit**: max {} actions per hour per chat (each conversation has its own independent budget).",
            self.max_actions_per_hour
        );

        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn default_policy() -> SecurityPolicy {
        SecurityPolicy::default()
    }

    // Platform-specific test paths: Unix uses `/…` paths, Windows uses
    // `C:\…` paths so that `Path::is_absolute()` returns the correct
    // value on each platform.

    #[cfg(not(target_os = "windows"))]
    fn tp_ws() -> PathBuf {
        PathBuf::from("/home/user/.zeroclaw/workspace")
    }
    #[cfg(target_os = "windows")]
    fn tp_ws() -> PathBuf {
        PathBuf::from("C:\\Users\\user\\.zeroclaw\\workspace")
    }

    #[cfg(not(target_os = "windows"))]
    fn tp_ws_shared() -> PathBuf {
        PathBuf::from("/home/user/.zeroclaw/shared")
    }
    #[cfg(target_os = "windows")]
    fn tp_ws_shared() -> PathBuf {
        PathBuf::from("C:\\Users\\user\\.zeroclaw\\shared")
    }

    #[cfg(not(target_os = "windows"))]
    fn tp_outside1() -> &'static str {
        "/home/user/other/file.txt"
    }
    #[cfg(target_os = "windows")]
    fn tp_outside1() -> &'static str {
        "C:\\Users\\user\\other\\file.txt"
    }

    #[cfg(not(target_os = "windows"))]
    fn tp_outside2() -> &'static str {
        "/tmp/file.txt"
    }
    #[cfg(target_os = "windows")]
    fn tp_outside2() -> &'static str {
        "C:\\Users\\Public\\file.txt"
    }

    #[cfg(not(target_os = "windows"))]
    fn tp_sys() -> &'static str {
        "/etc"
    }
    #[cfg(target_os = "windows")]
    fn tp_sys() -> &'static str {
        "C:\\Windows\\System32"
    }

    #[cfg(not(target_os = "windows"))]
    fn tp_sys_sub(sub: &str) -> String {
        format!("/{sub}")
    }
    #[cfg(target_os = "windows")]
    fn tp_sys_sub(sub: &str) -> String {
        format!("C:\\Windows\\{}", sub.replace('/', "\\"))
    }

    #[cfg(not(target_os = "windows"))]
    fn tp_proj() -> PathBuf {
        PathBuf::from("/projects")
    }
    #[cfg(target_os = "windows")]
    fn tp_proj() -> PathBuf {
        PathBuf::from("C:\\projects")
    }

    #[cfg(not(target_os = "windows"))]
    fn tp_data() -> PathBuf {
        PathBuf::from("/data")
    }
    #[cfg(target_os = "windows")]
    fn tp_data() -> PathBuf {
        PathBuf::from("C:\\data")
    }

    #[cfg(not(target_os = "windows"))]
    fn tp_rw() -> PathBuf {
        PathBuf::from("/rw-data")
    }
    #[cfg(target_os = "windows")]
    fn tp_rw() -> PathBuf {
        PathBuf::from("C:\\rw-data")
    }

    #[cfg(not(target_os = "windows"))]
    fn tp_ro() -> PathBuf {
        PathBuf::from("/ro-shared")
    }
    #[cfg(target_os = "windows")]
    fn tp_ro() -> PathBuf {
        PathBuf::from("C:\\ro-shared")
    }

    #[test]
    fn is_tool_allowed_none_is_unrestricted() {
        let p = SecurityPolicy {
            allowed_tools: None,
            excluded_tools: None,
            ..SecurityPolicy::default()
        };
        assert!(p.is_tool_allowed("shell"));
        assert!(p.is_tool_allowed("spawn_subagent"));
        assert!(p.is_tool_allowed("anything_else"));
    }

    #[test]
    fn is_tool_allowed_some_empty_denies_all() {
        let p = SecurityPolicy {
            allowed_tools: Some(vec![]),
            ..SecurityPolicy::default()
        };
        assert!(!p.is_tool_allowed("shell"));
        assert!(!p.is_tool_allowed("spawn_subagent"));
    }

    #[test]
    fn is_tool_allowed_allowlist_admits_only_listed() {
        let p = SecurityPolicy {
            allowed_tools: Some(vec!["shell".into(), "memory_recall".into()]),
            ..SecurityPolicy::default()
        };
        assert!(p.is_tool_allowed("shell"));
        assert!(p.is_tool_allowed("memory_recall"));
        assert!(!p.is_tool_allowed("spawn_subagent"));
        assert!(!p.is_tool_allowed("file_write"));
    }

    #[test]
    fn is_tool_allowed_excluded_overrides_allowlist() {
        let p = SecurityPolicy {
            allowed_tools: Some(vec!["shell".into(), "spawn_subagent".into()]),
            excluded_tools: Some(vec!["spawn_subagent".into()]),
            ..SecurityPolicy::default()
        };
        assert!(p.is_tool_allowed("shell"));
        assert!(
            !p.is_tool_allowed("spawn_subagent"),
            "excluded_tools must subtract from allowlist"
        );
    }

    #[test]
    fn is_tool_allowed_excluded_alone_subtracts_from_unrestricted() {
        let p = SecurityPolicy {
            allowed_tools: None,
            excluded_tools: Some(vec!["spawn_subagent".into()]),
            ..SecurityPolicy::default()
        };
        assert!(p.is_tool_allowed("shell"));
        assert!(!p.is_tool_allowed("spawn_subagent"));
    }

    #[test]
    fn is_tool_excluded_reflects_denylist_independent_of_allowlist() {
        // No denylist → nothing excluded, regardless of allowlist.
        let none = SecurityPolicy {
            allowed_tools: Some(vec!["shell".into()]),
            excluded_tools: None,
            ..SecurityPolicy::default()
        };
        assert!(!none.is_tool_excluded("shell"));
        assert!(
            !none.is_tool_excluded("deploy__run"),
            "a tool omitted from the allowlist is not 'excluded' — the denylist is separate"
        );

        // Denylist subtracts by name, independent of the allowlist.
        let denied = SecurityPolicy {
            allowed_tools: None,
            excluded_tools: Some(vec!["deploy__status".into()]),
            ..SecurityPolicy::default()
        };
        assert!(denied.is_tool_excluded("deploy__status"));
        assert!(!denied.is_tool_excluded("deploy__run"));
    }

    #[test]
    fn from_profiles_propagates_every_risk_profile_field() {
        use crate::schema::RiskProfileConfig;
        use std::path::Path;

        let rp = RiskProfileConfig {
            level: AutonomyLevel::ReadOnly,
            workspace_only: true,
            allowed_commands: vec!["only_this".into()],
            forbidden_paths: vec!["/secret".into()],
            require_approval_for_medium_risk: false,
            block_high_risk_commands: false,
            shell_env_passthrough: vec!["EDITOR".into(), "PAGER".into()],
            auto_approve: vec!["memory_recall".into()],
            always_ask: vec!["shell".into()],
            allowed_roots: vec!["/tmp/extra".into()],
            delegation_policy: crate::autonomy::DelegationPolicy::default(),
            approval_route: None,
            allowed_tools: vec!["shell".into(), "memory_recall".into()],
            deny_all_tools: false,
            excluded_tools: vec!["spawn_subagent".into()],
            sandbox_enabled: Some(true),
            sandbox_backend: Some("firejail".into()),
            firejail_args: vec!["--net=none".into()],
            sandbox_image: None,
        };

        let policy = SecurityPolicy::from_profiles(&rp, None, Path::new("/ws"));

        assert_eq!(policy.autonomy, AutonomyLevel::ReadOnly, "level → autonomy");
        assert!(policy.workspace_only, "workspace_only");
        assert_eq!(policy.allowed_commands, vec!["only_this".to_string()]);
        assert_eq!(policy.forbidden_paths, vec!["/secret".to_string()]);
        assert!(!policy.require_approval_for_medium_risk);
        assert!(!policy.block_high_risk_commands);
        assert_eq!(
            policy.shell_env_passthrough,
            vec!["EDITOR".to_string(), "PAGER".to_string()]
        );
        assert_eq!(
            policy.auto_approve,
            vec!["memory_recall".to_string()],
            "auto_approve must reach the policy"
        );
        assert_eq!(
            policy.always_ask,
            vec!["shell".to_string()],
            "always_ask must reach the policy"
        );
        assert!(
            policy.allowed_roots.iter().any(|p| p.ends_with("extra")),
            "allowed_roots expansion must reach the policy"
        );
        assert_eq!(
            policy.allowed_tools.as_deref(),
            Some(&["shell".to_string(), "memory_recall".to_string()][..]),
            "allowed_tools must reach the policy"
        );
        assert_eq!(
            policy.excluded_tools.as_deref(),
            Some(&["spawn_subagent".to_string()][..]),
            "excluded_tools must reach the policy"
        );
        assert_eq!(policy.sandbox_enabled, Some(true), "sandbox_enabled");
        assert_eq!(
            policy.sandbox_backend.as_deref(),
            Some("firejail"),
            "sandbox_backend"
        );
        assert_eq!(
            policy.firejail_args,
            vec!["--net=none".to_string()],
            "firejail_args"
        );
    }

    #[test]
    fn from_profiles_full_autonomy_drops_workspace_only() {
        use crate::schema::RiskProfileConfig;
        use std::path::Path;

        let rp = RiskProfileConfig {
            level: AutonomyLevel::Full,
            workspace_only: true,
            ..RiskProfileConfig::default()
        };

        let policy = SecurityPolicy::from_profiles(&rp, None, Path::new("/ws"));
        assert!(
            !policy.workspace_only,
            "Full autonomy must drop workspace_only even when the profile sets it true"
        );
    }

    #[test]
    fn from_profiles_legacy_empty_allowed_tools_means_unrestricted() {
        use crate::schema::RiskProfileConfig;
        use std::path::Path;

        // Both an omitted field (Default → empty) and an explicit
        // `allowed_tools = []` deserialize to the same legacy state and must
        // map to unrestricted — an empty list is NOT deny-all.
        let risk = RiskProfileConfig {
            allowed_tools: vec![],
            deny_all_tools: false,
            ..RiskProfileConfig::default()
        };

        let policy = SecurityPolicy::from_profiles(&risk, None, Path::new("/ws"));

        assert!(
            policy.allowed_tools.is_none(),
            "legacy empty allowed_tools must map to unrestricted (None)"
        );
        assert!(
            policy.is_tool_allowed("filesystem__write_file"),
            "legacy empty allowed_tools is unrestricted, not deny-all"
        );
    }

    #[test]
    fn from_profiles_deny_all_tools_flag_means_deny_all() {
        use crate::schema::RiskProfileConfig;
        use std::path::Path;

        let risk = RiskProfileConfig {
            allowed_tools: vec![],
            deny_all_tools: true, // explicit deny-all gate
            ..RiskProfileConfig::default()
        };

        let policy = SecurityPolicy::from_profiles(&risk, None, Path::new("/ws"));

        assert_eq!(
            policy.allowed_tools,
            Some(vec![]),
            "deny_all_tools = true must map to Some(vec![]) (deny-all), not None (unrestricted)"
        );
        assert!(
            !policy.is_tool_allowed("shell"),
            "deny_all_tools denies built-in tools"
        );
        assert!(
            !policy.is_tool_allowed("filesystem__write_file"),
            "deny_all_tools also denies MCP-discovered tools — no auto-admit under deny-all"
        );
    }

    #[test]
    fn from_profiles_legacy_none_sentinel_means_deny_all() {
        use crate::schema::RiskProfileConfig;
        use std::path::Path;

        let risk = RiskProfileConfig {
            allowed_tools: vec![
                RiskProfileConfig::LEGACY_DENY_ALL_TOOLS_SENTINEL.into(),
                RiskProfileConfig::LEGACY_DENY_ALL_TOOLS_SENTINEL.into(),
            ],
            ..RiskProfileConfig::default()
        };

        let policy = SecurityPolicy::from_profiles(&risk, None, Path::new("/ws"));

        assert!(!policy.is_tool_allowed("shell"));
        assert!(!policy.is_tool_allowed("filesystem__write_file"));
    }

    #[test]
    fn from_profiles_nonempty_allowed_tools_preserves_closed_set() {
        use crate::schema::RiskProfileConfig;
        use std::path::Path;

        let risk = RiskProfileConfig {
            allowed_tools: vec!["shell".into(), "memory_recall".into()],
            ..RiskProfileConfig::default()
        };

        let policy = SecurityPolicy::from_profiles(&risk, None, Path::new("/ws"));

        assert_eq!(
            policy.allowed_tools.as_deref(),
            Some(&["shell".to_string(), "memory_recall".to_string()][..]),
            "nonempty allowed_tools preserves the explicit closed set"
        );
        assert!(policy.is_tool_allowed("shell"));
        assert!(policy.is_tool_allowed("memory_recall"));
        assert!(!policy.is_tool_allowed("file_write"));
    }

    #[test]
    fn from_profiles_with_runtime_profile_propagates_budget_caps() {
        use crate::schema::RuntimeProfileConfig;
        use std::path::Path;

        let risk = crate::schema::RiskProfileConfig {
            level: AutonomyLevel::Supervised,
            ..crate::schema::RiskProfileConfig::default()
        };
        let runtime = RuntimeProfileConfig {
            max_actions_per_hour: 99,
            max_cost_per_day_cents: 1234,
            shell_timeout_secs: 300,
            ..RuntimeProfileConfig::default()
        };

        let policy = SecurityPolicy::from_profiles(&risk, Some(&runtime), Path::new("/ws"));

        assert_eq!(policy.max_actions_per_hour, 99);
        assert_eq!(policy.max_cost_per_day_cents, 1234);
        assert_eq!(policy.shell_timeout_secs, 300);
    }

    #[test]
    fn from_profiles_without_runtime_profile_uses_defaults() {
        use std::path::Path;

        let risk = crate::schema::RiskProfileConfig {
            level: AutonomyLevel::Supervised,
            ..crate::schema::RiskProfileConfig::default()
        };

        let policy = SecurityPolicy::from_profiles(&risk, None, Path::new("/ws"));

        assert_eq!(policy.max_actions_per_hour, 20);
        assert_eq!(policy.max_cost_per_day_cents, 500);
        assert_eq!(policy.shell_timeout_secs, 60);
    }

    fn unix_forbidden_path_policy() -> SecurityPolicy {
        SecurityPolicy {
            workspace_dir: PathBuf::from("/workspace"),
            forbidden_paths: vec!["/dev".into(), "/etc".into()],
            ..SecurityPolicy::default()
        }
    }

    fn readonly_policy() -> SecurityPolicy {
        SecurityPolicy {
            autonomy: AutonomyLevel::ReadOnly,
            ..SecurityPolicy::default()
        }
    }

    fn full_policy() -> SecurityPolicy {
        SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            ..SecurityPolicy::default()
        }
    }

    // ── AutonomyLevel ────────────────────────────────────────

    #[test]
    fn autonomy_default_is_supervised() {
        assert_eq!(AutonomyLevel::default(), AutonomyLevel::Supervised);
    }

    #[test]
    fn autonomy_serde_roundtrip() {
        let json = serde_json::to_string(&AutonomyLevel::Full).unwrap();
        assert_eq!(json, "\"full\"");
        let parsed: AutonomyLevel = serde_json::from_str("\"readonly\"").unwrap();
        assert_eq!(parsed, AutonomyLevel::ReadOnly);
        let parsed2: AutonomyLevel = serde_json::from_str("\"supervised\"").unwrap();
        assert_eq!(parsed2, AutonomyLevel::Supervised);
    }

    #[test]
    fn can_act_readonly_false() {
        assert!(!readonly_policy().can_act());
    }

    #[test]
    fn can_act_supervised_true() {
        assert!(default_policy().can_act());
    }

    #[test]
    fn can_act_full_true() {
        assert!(full_policy().can_act());
    }

    #[test]
    fn enforce_tool_operation_read_allowed_in_readonly_mode() {
        let p = readonly_policy();
        assert!(
            p.enforce_tool_operation(ToolOperation::Read, "memory_recall")
                .is_ok()
        );
    }

    #[test]
    fn enforce_tool_operation_act_blocked_in_readonly_mode() {
        let p = readonly_policy();
        let err = p
            .enforce_tool_operation(ToolOperation::Act, "memory_store")
            .unwrap_err();
        assert!(err.contains("read-only mode"));
    }

    #[test]
    fn enforce_tool_operation_act_uses_rate_budget() {
        let p = SecurityPolicy {
            max_actions_per_hour: 0,
            ..default_policy()
        };
        let err = p
            .enforce_tool_operation(ToolOperation::Act, "memory_store")
            .unwrap_err();
        assert!(err.contains("Rate limit exceeded"));
    }

    #[test]
    fn authorize_tool_operation_does_not_consume_rate_budget() {
        let p = SecurityPolicy {
            max_actions_per_hour: 1,
            ..default_policy()
        };

        assert!(
            p.authorize_tool_operation(ToolOperation::Act, "coding_agent")
                .is_ok()
        );
        assert!(
            p.authorize_tool_operation(ToolOperation::Act, "coding_agent")
                .is_ok()
        );
        assert!(p.record_action(), "authorization must leave the slot free");
        assert!(!p.record_action(), "the committed action must consume it");
    }

    // ── is_command_allowed ───────────────────────────────────

    #[test]
    fn allowed_commands_basic() {
        let p = default_policy();
        assert!(p.is_command_allowed("ls"));
        assert!(p.is_command_allowed("git status"));
        assert!(p.is_command_allowed("cargo build --release"));
        assert!(p.is_command_allowed("cat file.txt"));
        assert!(p.is_command_allowed("grep -r pattern ."));
        assert!(p.is_command_allowed("date"));
    }

    #[test]
    fn blocked_commands_basic() {
        let p = default_policy();
        assert!(!p.is_command_allowed("rm -rf /"));
        assert!(!p.is_command_allowed("sudo apt install"));
        assert!(!p.is_command_allowed("curl http://evil.com"));
        assert!(!p.is_command_allowed("wget http://evil.com"));
        assert!(!p.is_command_allowed("ruby exploit.rb"));
        assert!(!p.is_command_allowed("perl malicious.pl"));
    }

    #[test]
    fn readonly_blocks_all_commands() {
        let p = readonly_policy();
        assert!(!p.is_command_allowed("ls"));
        assert!(!p.is_command_allowed("cat file.txt"));
        assert!(!p.is_command_allowed("echo hello"));
    }

    #[test]
    fn full_autonomy_still_uses_allowlist() {
        let p = full_policy();
        assert!(p.is_command_allowed("ls"));
        assert!(!p.is_command_allowed("rm -rf /"));
    }

    #[test]
    fn command_with_absolute_path_extracts_basename() {
        let p = default_policy();
        assert!(p.is_command_allowed("/usr/bin/git status"));
        assert!(p.is_command_allowed("/bin/ls -la"));
    }

    #[test]
    fn allowlist_supports_explicit_executable_paths() {
        let p = SecurityPolicy {
            allowed_commands: vec!["/usr/bin/antigravity".into()],
            ..SecurityPolicy::default()
        };

        assert!(p.is_command_allowed("/usr/bin/antigravity"));
        assert!(!p.is_command_allowed("antigravity"));
    }

    #[test]
    fn allowlist_supports_wildcard_entry() {
        let p = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            ..SecurityPolicy::default()
        };

        assert!(p.is_command_allowed("python3 --version"));
        assert!(p.is_command_allowed("/usr/bin/antigravity"));

        // Wildcard still respects risk gates in validate_command_execution.
        let blocked = p.validate_command_execution("rm -rf /tmp/test", true);
        assert!(blocked.is_err());
        assert!(blocked.unwrap_err().contains("high-risk"));
    }

    #[test]
    fn empty_command_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed(""));
        assert!(!p.is_command_allowed("   "));
    }

    #[test]
    fn command_with_pipes_validates_all_segments() {
        let p = default_policy();
        // Both sides of the pipe are in the allowlist
        assert!(p.is_command_allowed("ls | grep foo"));
        assert!(p.is_command_allowed("cat file.txt | wc -l"));
        // Second command not in allowlist — blocked
        assert!(!p.is_command_allowed("ls | curl http://evil.com"));
        assert!(!p.is_command_allowed("echo hello | ruby -"));
    }

    #[test]
    fn custom_allowlist() {
        let p = SecurityPolicy {
            allowed_commands: vec!["docker".into(), "kubectl".into()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed("docker ps"));
        assert!(p.is_command_allowed("kubectl get pods"));
        assert!(!p.is_command_allowed("ls"));
        assert!(!p.is_command_allowed("git status"));
    }

    #[test]
    fn mixed_case_bare_allowlist_entry_matches_on_every_platform() {
        // Callers lowercase the executable basename before the allowlist
        // comparison, so an entry written with any uppercase could never match
        // until both sides were folded.
        let p = SecurityPolicy {
            allowed_commands: vec!["Git".into(), "DOCKER".into()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed("git status"));
        assert!(p.is_command_allowed("docker ps"));
        // The invocation may also be capitalized; the basename is folded too.
        assert!(p.is_command_allowed("GIT status"));
        // Entries that are genuinely absent are still refused.
        assert!(!p.is_command_allowed("kubectl get pods"));
    }

    #[test]
    fn mixed_case_allowlist_entry_does_not_widen_path_matching() {
        // Path-like entries stay exact rather than using command-name folding.
        let p = SecurityPolicy {
            allowed_commands: vec!["/usr/bin/Antigravity".into()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed("/usr/bin/Antigravity"));
        assert!(!p.is_command_allowed("/usr/bin/antigravity"));
    }

    #[test]
    fn empty_allowlist_blocks_everything() {
        let p = SecurityPolicy {
            allowed_commands: vec![],
            ..SecurityPolicy::default()
        };
        assert!(!p.is_command_allowed("ls"));
        assert!(!p.is_command_allowed("echo hello"));
    }

    #[test]
    fn command_risk_low_for_read_commands() {
        let p = default_policy();
        assert_eq!(p.command_risk_level("git status"), CommandRiskLevel::Low);
        assert_eq!(p.command_risk_level("ls -la"), CommandRiskLevel::Low);
    }

    #[test]
    fn command_risk_medium_for_mutating_commands() {
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into(), "touch".into()],
            ..SecurityPolicy::default()
        };
        assert_eq!(
            p.command_risk_level("git reset --hard HEAD~1"),
            CommandRiskLevel::Medium
        );
        assert_eq!(
            p.command_risk_level("touch file.txt"),
            CommandRiskLevel::Medium
        );
    }

    #[test]
    fn git_value_taking_global_options_do_not_hide_a_mutating_subcommand() {
        // Regression for the approval-classification bypass where a value-taking
        // git global option hid the real subcommand from the risk classifier.
        //
        // `--attr-source`, `-c`, and `--config-env` each take a *separate*
        // following token as their value. Git consumes that token, so the real
        // subcommand is the one after it. When the resolver skipped only the
        // flag (not its value), a value that looks like a read verb hid the
        // actual mutating subcommand and the write was classified Low instead of
        // Medium, dropping the approval requirement.
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        for command in [
            // The value (`log`/`HEAD`) resembles a read verb; the real
            // subcommand `commit` mutates and must stay Medium.
            "git --attr-source log commit",
            "git --attr-source HEAD commit",
            "git --attr-source=HEAD commit",
        ] {
            assert_eq!(
                p.command_risk_level(command),
                CommandRiskLevel::Medium,
                "value-taking global option must not hide the write subcommand: {command}"
            );
        }
    }

    #[test]
    fn git_attr_source_read_stays_low() {
        // The fix must not over-approximate: an ordinary read behind
        // `--attr-source` stays Low so it is not needlessly gated.
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        for command in [
            "git --attr-source HEAD status",
            "git --attr-source=HEAD log",
            "git --attr-source HEAD diff",
        ] {
            assert_eq!(
                p.command_risk_level(command),
                CommandRiskLevel::Low,
                "ordinary read behind --attr-source should stay low: {command}"
            );
        }
    }

    #[test]
    fn command_risk_high_for_dangerous_commands() {
        let p = SecurityPolicy {
            allowed_commands: vec!["rm".into()],
            ..SecurityPolicy::default()
        };
        assert_eq!(
            p.command_risk_level("rm -rf /tmp/test"),
            CommandRiskLevel::High
        );
    }

    #[test]
    fn command_risk_classifies_powershell_commands() {
        let p = default_policy();
        for command in [
            "Remove-Item important.txt",
            "Set-Content output.txt value",
            "Start-Process calc.exe",
            "Invoke-WebRequest https://example.com",
            "ri important.txt",
            "iwr https://example.com",
            "ac output.txt value",
            "clc output.txt",
            "wsl.exe --exec rm important.txt",
        ] {
            assert_eq!(
                p.command_risk_level_for_shell(command, ShellDialect::PowerShell),
                CommandRiskLevel::High,
                "PowerShell-native command should be high risk: {command}"
            );
        }

        for command in [
            "New-Item output.txt",
            "Copy-Item from.txt to.txt",
            "ni output.txt",
        ] {
            assert_eq!(
                p.command_risk_level_for_shell(command, ShellDialect::PowerShell),
                CommandRiskLevel::Medium,
                "PowerShell-native mutation should be medium risk: {command}"
            );
        }

        for command in ["Write-Output safe", "Get-Date", "Get-ChildItem"] {
            assert_eq!(
                p.command_risk_level_for_shell(command, ShellDialect::PowerShell),
                CommandRiskLevel::Low,
                "read-only PowerShell command should stay low risk: {command}"
            );
        }
    }

    #[test]
    fn powershell_only_names_do_not_change_other_shell_dialects() {
        let p = default_policy();

        for command in [
            "ri file.txt",
            "iwr example.test",
            "ni file.txt",
            "md output",
            "start app",
        ] {
            assert_eq!(
                p.command_risk_level_for_shell(command, ShellDialect::Posix),
                CommandRiskLevel::Low,
                "PowerShell risk names must not leak into POSIX: {command}"
            );
            assert_eq!(
                p.command_risk_level_for_shell(command, ShellDialect::WindowsCmd),
                CommandRiskLevel::Low,
                "PowerShell risk names must not leak into cmd.exe: {command}"
            );
        }
    }

    #[test]
    fn validate_command_blocks_powershell_native_command_via_wildcard() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };

        let error = p
            .validate_command_execution_for_shell(
                "Remove-Item important.txt",
                true,
                ShellDialect::PowerShell,
            )
            .expect_err("PowerShell-native high-risk commands must be blocked");
        assert!(error.contains("high-risk"));
    }

    #[test]
    fn validate_command_allows_low_risk_powershell_command_via_wildcard() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };

        let risk = p
            .validate_command_execution_for_shell(
                "Write-Output safe",
                false,
                ShellDialect::PowerShell,
            )
            .expect("low-risk PowerShell commands should not require approval");
        assert_eq!(risk, CommandRiskLevel::Low);
    }

    #[test]
    fn powershell_stop_parsing_token_is_rejected_by_grammar() {
        // `--%` is PowerShell's stop-parsing token: it strips itself and passes
        // the remaining arguments to a native command verbatim. Without special
        // handling the policy would classify `git --% push` by its first token
        // `--%` (low risk) while Git actually receives `push`. The bounded
        // grammar must reject the unquoted operator so it never reaches the
        // named risk classifier.
        assert_eq!(
            split_powershell_pipeline_syntax("git --% push origin main"),
            None
        );
        assert_eq!(
            split_powershell_pipeline_syntax("git --% reset --hard"),
            None
        );
        assert_eq!(split_simple_powershell_pipeline("git --% push"), None);
        // Also rejected when it is the trailing token or inside a pipeline stage.
        assert_eq!(split_powershell_pipeline_syntax("echo hi | git --%"), None);

        // A quoted `--%` is an ordinary literal argument, not the operator, so
        // it must NOT trip the guard (avoid over-blocking legitimate strings).
        assert!(split_powershell_pipeline_syntax("echo \"--%\"").is_some());
        assert!(split_powershell_pipeline_syntax("echo '--%'").is_some());
        // A token that merely contains `--%` as a substring is not the operator.
        assert!(split_powershell_pipeline_syntax("echo --%tail").is_some());

        // Mixed quoting must not launder the operator: PowerShell assembles
        // adjacent quoted and unquoted fragments into one token, so `-"-"%`,
        // `"-"-%`, and `--"%"` all reach the parser as the stop-parsing `--%`
        // while a naive "any quote makes it a literal" check would let them
        // through. The guard collapses quote delimiters and still rejects them
        // because at least one character of the token is bare.
        assert_eq!(
            split_powershell_pipeline_syntax("git -\"-\"% push origin main"),
            None
        );
        assert_eq!(
            split_powershell_pipeline_syntax("git \"-\"-% reset --hard"),
            None
        );
        assert_eq!(split_powershell_pipeline_syntax("git --\"%\" push"), None);
        assert_eq!(split_powershell_pipeline_syntax("git -'-'% push"), None);
        // A fully quoted `--%` stays a literal argument (no bare character).
        assert!(split_powershell_pipeline_syntax("echo \"--%\"").is_some());
        // But `x"--%"` is a mixed bare+quoted token (PowerShell binds it as
        // `x--%`), so it is rejected by the mixed-quoting guard.
        assert_eq!(split_powershell_pipeline_syntax("echo x\"--%\""), None);
    }

    #[test]
    fn validate_command_blocks_powershell_stop_parsing_git_mutation() {
        // Default Windows-style policy: `git` is on the default allowlist and
        // the policy is supervised with medium-risk approval enabled. Before the
        // fix, `git --% push` was classified Low and ran without approval.
        let p = default_policy();

        for command in [
            "git --% push origin main",
            "git --% reset --hard",
            "git --% clean -fdx",
        ] {
            let error = p
                .validate_command_execution_for_shell(command, false, ShellDialect::PowerShell)
                .expect_err("stop-parsing native mutation must not be silently allowed");
            assert!(
                error.contains("not allowed by security policy"),
                "unexpected acceptance for {command}: {error}"
            );
        }

        // Approval must not launder the stop-parsing token either: the command
        // is rejected outright rather than downgraded to an approved mutation.
        let approved = p.validate_command_execution_for_shell(
            "git --% push origin main",
            true,
            ShellDialect::PowerShell,
        );
        assert!(
            approved.is_err(),
            "approval must not bypass the grammar guard"
        );

        // The equivalent parsed command is still governed normally: an ordinary
        // `git push` remains a recognized medium-risk mutation.
        assert_eq!(
            p.command_risk_level_for_shell("git push origin main", ShellDialect::PowerShell),
            CommandRiskLevel::Medium,
        );
    }

    #[test]
    fn powershell_grammar_rejects_mixed_quoted_tokens() {
        // PowerShell concatenates adjacent quoted and unquoted fragments before
        // binding an argument, so a token that mixes bare and quoted characters
        // reaches the native command as a different string than policy's later
        // provider, path, allowlist, and risk checks inspect. The bounded
        // grammar rejects such tokens so those checks never see a laundered
        // provider path, drive prefix, or `..` traversal.
        for command in [
            // `Env:`/provider access hidden by an interior quote.
            "cat E'nv:'PATH",
            "cat \"env\":path",
            // Drive prefix split by a quote: binds as `C:\Windows\win.ini`.
            "cat C':'\\Windows\\win.ini",
            // `..` traversal split across a quote boundary.
            "cat .'.'\\secret.txt",
            "cat \"..\"\\secret.txt",
        ] {
            assert_eq!(
                split_powershell_pipeline_syntax(command),
                None,
                "mixed quoted/unquoted token must be rejected: {command}"
            );
        }

        // Fully bare and fully quoted tokens remain valid — only the *mix* is
        // rejected, so ordinary quoted arguments are not over-blocked.
        assert!(split_powershell_pipeline_syntax("cat env:path").is_some());
        assert!(split_powershell_pipeline_syntax("cat \"env:path\"").is_some());
        assert!(split_powershell_pipeline_syntax("cat 'env:path'").is_some());
        assert!(split_powershell_pipeline_syntax("cat \"my file.txt\"").is_some());
    }

    #[test]
    fn validate_blocks_powershell_provider_hidden_by_mixed_quoting() {
        // End-to-end through the dialect-aware validator: a default-allowlisted
        // read command must not launder an `Env:` provider read past policy by
        // splitting the provider prefix with a quote.
        let p = default_policy();
        let denied = p.validate_command_execution_for_shell(
            "cat E'nv:'PATH",
            true,
            ShellDialect::PowerShell,
        );
        assert!(
            denied.is_err(),
            "quote-hidden provider path must be rejected, got {denied:?}"
        );

        // The unobscured provider form is still recognized and blocked too, so
        // the guard is not the only thing standing between policy and `Env:`.
        assert!(
            p.command_risk_level_for_shell("cat env:path", ShellDialect::PowerShell)
                == CommandRiskLevel::High
        );
    }

    #[test]
    fn powershell_stop_parsing_token_still_follows_trusted_optout() {
        // The wildcard + disabled high-risk-blocking escape hatch intentionally
        // skips the bounded grammar, exactly as it does for backticks and
        // subexpressions. `--%` is not special-cased against that contract.
        let trusted = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        assert!(
            trusted
                .validate_command_execution_for_shell(
                    "git --% push origin main",
                    true,
                    ShellDialect::PowerShell,
                )
                .is_ok(),
            "trusted opt-out must keep bypassing the grammar for --% too"
        );
    }

    #[test]
    fn validate_command_requires_approval_for_medium_risk() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            require_approval_for_medium_risk: true,
            allowed_commands: vec!["touch".into()],
            ..SecurityPolicy::default()
        };

        let denied = p.validate_command_execution("touch test.txt", false);
        assert!(denied.is_err());
        assert!(denied.unwrap_err().contains("requires explicit approval"),);

        let allowed = p.validate_command_execution("touch test.txt", true);
        assert_eq!(allowed.unwrap(), CommandRiskLevel::Medium);
    }

    #[test]
    fn shell_policy_normalizes_non_git_executable_and_arguments() {
        let p = SecurityPolicy {
            allowed_commands: vec!["cat".into(), "find".into()],
            ..SecurityPolicy::default()
        };

        assert!(p.is_command_allowed_for_shell("c\\at ./src/main.rs", ShellDialect::Posix,));
        assert!(!p.is_command_allowed_for_shell("c\\at ./src/main.rs", ShellDialect::WindowsCmd,));

        assert!(!p.is_command_allowed("find . '-exec' echo"));
        assert_eq!(p.forbidden_path_argument("cat './src/main.rs'"), None);

        #[cfg(not(target_os = "windows"))]
        assert_eq!(
            p.forbidden_path_argument("cat ..\\/secret.txt"),
            Some("../secret.txt".into())
        );
        #[cfg(target_os = "windows")]
        assert_eq!(
            p.forbidden_path_argument("cat ..\\/secret.txt"),
            Some("..\\/secret.txt".into())
        );
    }

    #[test]
    fn posix_policy_does_not_inherit_windows_executable_syntax() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        // Docker executes POSIX `sh` even on a Windows host. Backslashes escape
        // the next character there, while cmd.exe treats them as path separators.
        for command in [r"attacker\git status", "git.exe status"] {
            assert!(
                p.validate_command_execution_for_shell(command, false, ShellDialect::Posix)
                    .is_err(),
                "POSIX must not treat {command:?} as allowlisted git"
            );
            assert!(
                p.validate_command_execution_for_shell(command, false, ShellDialect::WindowsCmd)
                    .is_ok(),
                "cmd.exe semantics must remain available for {command:?}"
            );
        }

        assert_eq!(
            p.command_risk_level_for_shell(r"attacker\git commit", ShellDialect::Posix),
            CommandRiskLevel::Low
        );
        assert_eq!(
            p.command_risk_level_for_shell(r"attacker\git commit", ShellDialect::WindowsCmd),
            CommandRiskLevel::Medium
        );
    }

    #[test]
    fn git_archive_remote_and_output_writes_enforce_policy_boundary() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            require_approval_for_medium_risk: true,
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        for command in [
            "git archive --format --remote=ext::helper HEAD",
            "git archive --prefix --remote=ext::helper HEAD",
        ] {
            let err = p
                .validate_command_execution(command, false)
                .expect_err("archive helper remotes must fail before execution");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{command}: {err}"
            );
        }

        for command in [
            "git archive --format --remote=https://example.invalid/repo HEAD",
            "git archive --prefix --remote=https://example.invalid/repo HEAD",
            "git archive -- --remote=ext::helper",
        ] {
            let risk = p
                .validate_command_execution(command, false)
                .expect("safe remotes and operands must remain allowed");
            assert_eq!(risk, CommandRiskLevel::Low, "{command}");
        }

        for command in [
            "git archive --output=./archive.tar HEAD",
            "git archive --output ./archive.tar HEAD",
            "git archive --out=./archive.tar HEAD",
            "git archive -o ./archive.tar HEAD",
            "git archive -o./archive.tar HEAD",
            "git bundle create ./repo.bundle HEAD",
            "git diff --output=./review-output.patch",
            "git diff --output ./review-output.patch",
            "git format-patch -1 HEAD",
            "git format-patch --output-directory=./patches -1 HEAD",
            "git format-patch --output-directory ./patches -1 HEAD",
            "git format-patch -o ./patches -1 HEAD",
            "git log --output=./review-output.log -1",
            "git show --output ./review-output.txt HEAD",
        ] {
            let err = p
                .validate_command_execution(command, false)
                .expect_err("Git output-file options must require approval");
            assert!(err.contains("medium-risk operation"), "{command}: {err}");

            let risk = p
                .validate_command_execution(command, true)
                .expect("approved Git output-file options must remain available");
            assert_eq!(risk, CommandRiskLevel::Medium, "{command}");
        }

        for command in [
            "git archive HEAD",
            "git archive -- --output=./archive.tar",
            "git diff -- --output=./review-output.patch",
            "git log -- --output=./review-output.log",
            "git show -- --output=./review-output.txt",
        ] {
            let risk = p
                .validate_command_execution(command, false)
                .expect("output-looking operands after -- must remain allowed");
            assert_eq!(risk, CommandRiskLevel::Low, "{command}");
        }
    }

    #[test]
    fn shell_environment_assignments_rejected_at_policy_boundary() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            require_approval_for_medium_risk: true,
            allowed_commands: vec!["git".into(), "env".into(), "ls".into(), "grep".into()],
            ..SecurityPolicy::default()
        };

        for command in [
            "ZC_ALIAS='!/usr/bin/true' git --config-env=alias.zcprobe=ZC_ALIAS zcprobe",
            "ZC_ALIAS='!/usr/bin/true' git --config-env alias.zcprobe=ZC_ALIAS zcprobe",
            "GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=alias.zcprobe GIT_CONFIG_VALUE_0='!/usr/bin/true' git zcprobe",
            "GIT_CONFIG_PARAMETERS='alias.zcprobe=!/usr/bin/true' git zcprobe",
            "GIT_CONFIG_COUNT+=1 git zcprobe",
            "GIT_CONFIG_KEY_0+=alias.zcprobe git zcprobe",
            "GIT_CONFIG_VALUE_0+='!/usr/bin/true' git zcprobe",
            "GIT_CONFIG_PARAMETERS+='alias.zcprobe=!/usr/bin/true' git zcprobe",
            "GIT_CONFIG_GLOBAL=./zc-config git zcprobe",
            "GIT_CONFIG_SYSTEM=./zc-config git zcprobe",
            "GIT_CONFIG_NOGLOBAL=1 git zcprobe",
            "GIT_CONFIG_NOSYSTEM=1 git zcprobe",
            "GIT_CONFIG_GLOBAL=./zc-config >/dev/null git zcprobe",
            ">/dev/null GIT_CONFIG_SYSTEM=./zc-config git zcprobe",
            "git -c alias.zcprobe='!/usr/bin/true' zcprobe",
            "git -calias.zcprobe='!/usr/bin/true' zcprobe",
            "git '-c' foo.bar=ENV status",
            "git '-cfoo.bar=ENV' status",
            "git '--config-env' foo.bar=ENV status",
            "git '--config-env=foo.bar=ENV' status",
            "git --config-env\\=foo.bar=ENV status",
            "git --exec-path ./tools zcprobe",
            "git --exec-path=./tools zcprobe",
            "env GIT_CONFIG_GLOBAL=./zc-config git zcprobe",
            "/usr/bin/env GIT_CONFIG_SYSTEM=./zc-config git zcprobe",
            "env git status",
        ] {
            assert!(!p.is_command_allowed(command), "{command}");
            let err = p
                .validate_command_execution(command, false)
                .expect_err("command-scope Git process controls must fail before execution");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{err}"
            );
        }

        for command in [
            "GIT_EXEC_PATH=./tools git zcprobe",
            "GIT_SSH_COMMAND=./tools/zcprobe git fetch ssh://example.invalid/repo",
            "GIT_SSH_COMMAND+=./tools/zcprobe git fetch ssh://example.invalid/repo",
            "PATH=./tools:/usr/bin git zcprobe",
            "PATH+=:./tools git zcprobe",
            "PATH=./tools:/usr/bin ls",
            "PATH+=:./tools ls",
            "LD_PRELOAD=./tools/zcprobe.so ls",
        ] {
            assert!(!p.is_command_allowed(command), "{command}");
            let err = p
                .validate_command_execution(command, false)
                .expect_err("leading environment assignments must fail before execution");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{command}: {err}"
            );
        }

        assert!(p.is_command_allowed("env"));
        let env_only = p
            .validate_command_execution("env", false)
            .expect("bare env has no nested command to bypass policy");
        assert_eq!(env_only, CommandRiskLevel::Low);

        for command in [
            "git difftool --no-prompt --extcmd=./helper -- file",
            "git difftool --no-prompt -x ./helper -- file",
            "git difftool --tool=vimdiff -- file",
            "git difftool--helper --extcmd=./helper -- file",
            "git mergetool --tool=vimdiff file",
            "git mergetool--helper --tool=vimdiff file",
            "git diff --ext-diff -- file",
            "git diff --ext-d -- file",
            "git diff --ext -- file",
            "git log --ext-diff -1",
            "git show --ext-diff --stat HEAD",
            "git -p status",
            "git --paginate status",
            "git grep -O pattern",
            "git grep -O./pager pattern",
            "git grep --open-files-in-pager pattern",
            "git grep --open-files-in-pager=./pager pattern",
            "git grep --open-files-in-pag pattern",
            "git grep --open-files-in-pag=./pager pattern",
            "git help -w status",
            "git help --web status",
            "git help --we status",
            "git --no-pager bisect run ./helper",
            "git -C . submodule --quiet foreach './helper'",
            "git submodule--helper foreach -- './helper'",
            "git zcprobe",
            "git fetch --upload-pack=./helper origin main",
            "git fetch --upload-pack ./helper origin main",
            "git ls-remote --upload-pack=./helper origin",
            "git pull --upload-pack=./helper origin main",
            "git pull --upload-pack ./helper origin main",
            "git push --receive-pack=./helper origin main",
            "git push --exec ./helper origin main",
            "git archive --exec=./helper HEAD",
            "git archive --exec ./helper HEAD",
            "git clone --config core.sshCommand=./helper ssh://example.invalid/repo ./dst",
            "git clone --config=core.sshCommand=./helper ssh://example.invalid/repo ./dst",
            "git clone --template=./hooks https://example.invalid/repo ./dst",
            "git clone --template ./hooks https://example.invalid/repo ./dst",
            "git init --template=./hooks ./dst",
            "git init --template ./hooks ./dst",
            "git rebase --exec=./helper main",
            "git rebase --exec ./helper main",
            "git rebase -x ./helper main",
            "git rebase -x./helper main",
            "git rebase -ix ./helper main",
            "git clone -u ./helper ssh://example.invalid/repo ./dst",
            "git clone -u./helper ssh://example.invalid/repo ./dst",
            "git STATUS",
            "git COMMIT -m test",
            "git fetch --upl=./helper origin main",
            "git pull --upl=./helper origin main",
            "git push --rece=./helper origin main",
            "git push --exe=./helper origin main",
            "git archive --exe=./helper HEAD",
            "git clone --conf=core.sshCommand=./helper ssh://example.invalid/repo ./dst",
            "git clone --temp=./hooks https://example.invalid/repo ./dst",
            "git init --temp=./hooks ./dst",
            "git rebase --exe=./helper main",
            "git ls-remote 'ext::sh -c true'",
            "git fetch helper::payload",
            "git clone ext::helper ./dst",
            "git push ext::helper main",
            "git remote add origin ext::helper",
            "git ls-remote evil://host/repo",
            "git fetch evil://host/repo",
            "git clone evil://host/repo ./dst",
            "git push evil://host/repo main",
            "git clone -- ext::helper ./dst",
            "git fetch -- ext::helper main",
            "git ls-remote -- ext::helper",
            "git push -- ext::helper main",
            "git ls-remote 'evil://host/repo?x=y'",
            "git clone 'ext::helper arg=value' ./dst",
            "git ls-remote 1foo::payload",
            "git ls-remote 1foo://host/repo",
            "git clone --depth 1 ext::helper ./dst",
            "git fetch --dep 1 ext::helper",
            "git clone --bra main ext::helper ./dst",
            "git remote add --mas main origin ext::helper",
            "git submodule add --na origin ext::helper ./dst",
            "git pull -s ours ext::helper",
            "git pull --strategy ours ext::helper",
            "git pull --jobs ext::helper",
            "git pull -j ext::helper",
            "git archive --format=tar --remote=ext::helper HEAD",
            "git archive --for=tar --rem=ext::helper HEAD",
            "git archive --remote=https://example.invalid/repo --remote=ext::helper HEAD",
            "git archive --remote https://example.invalid/repo --remote ext::helper HEAD",
            "git archive --remote -- --remote=ext::helper HEAD",
            "git clone --server-option --remote=ext::helper https://example.invalid/repo dst",
        ] {
            assert!(!p.is_command_allowed(command), "{command}");
            let err = p
                .validate_command_execution(command, false)
                .expect_err("Git delegated-execution surfaces must fail before execution");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{command}: {err}"
            );
        }

        for command in [
            "git 2>&1> /dev/null commit -m test",
            "git <&0> /dev/null commit -m test",
        ] {
            assert!(!p.is_command_allowed(command), "{command}");
            let err = p
                .validate_command_execution(command, false)
                .expect_err("ambiguous packed redirections must fail closed");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{command}: {err}"
            );
        }

        let status = p
            .validate_command_execution("git status", false)
            .expect("read-only Git status should remain allowed");
        assert_eq!(status, CommandRiskLevel::Low);

        for command in [
            "git diff --stat",
            "git diff --no-ext-diff --stat",
            "git log --oneline -1",
            "git show --stat --no-patch HEAD",
            "git submodule status",
            "git diff -- --ext-diff",
            "git diff -- --ext-d",
            "git diff -- --ext",
            "git log -- --ext-diff",
            "git submodule status foreach",
            "git submodule status -- foreach",
            "git bisect log run",
            "git --no-pager status",
            "git log -p -1",
            "git grep -o pattern",
            "git fetch origin main",
            "git worktree list",
            "git -C . worktree list --porcelain",
            "git ls-remote origin",
            "git clone https://example.invalid/repo ./dst",
            "git clone git+ssh://example.invalid/repo ./dst",
            "git clone ssh+git://example.invalid/repo ./dst",
            "git diff -- ext::helper",
            "git diff ext::helper",
            "git status ext::helper",
            "git grep -- --open-files-in-pag",
            "git grep -- --open-files-in-pag=./pager",
            "git help -- --we",
            "git log -- --upload-pack=./helper",
            "git clone https://example.invalid/repo ./dst::name",
            "git clone https://example.invalid/repo ./evil://dst",
            "git clone https://example.invalid/repo evil://dst",
            "git submodule status ./evil://path",
            "git submodule add https://example.invalid/repo evil://path",
            "git archive -- --remote=ext::helper",
            "git archive --remote=https://example.invalid/repo --remote=ssh://example.invalid/repo HEAD",
        ] {
            let allowed = p
                .validate_command_execution(command, false)
                .expect("read-only Git commands should remain allowed");
            assert_eq!(allowed, CommandRiskLevel::Low, "{command}");
        }

        let commit_denied = p
            .validate_command_execution("git commit -m test", false)
            .expect_err("Git write verbs still require approval");
        assert!(
            commit_denied.contains("medium-risk operation"),
            "{commit_denied}"
        );

        for command in [
            ">/dev/null git commit -m test",
            "<<<payload git commit -m test",
            "git -C . 2>&1 commit -m test",
            "git -C . >/dev/null commit -m test",
            "git -C . <<<payload commit -m test",
            "git -C . <<< payload commit -m test",
            r#"git -C . <<<" " commit -m test"#,
            r#"git -C . <<<"" commit -m test"#,
            r#"git -C . <<<'' commit -m test"#,
            "git -C . <<<123 commit -m test",
            r#"git -C . <<<"<" commit -m test"#,
            r#"git -C . <<<">" commit -m test"#,
            "git -C . <<<\\  commit -m test",
            "git -C . commit -m test 2>&1",
            "git -C . commit -m test >/dev/null",
            "git -C . commit -m test <<<payload",
        ] {
            assert!(p.is_command_allowed(command), "{command}");
            let err = p
                .validate_command_execution(command, false)
                .expect_err("redirections must not hide a Git write verb");
            assert!(err.contains("medium-risk operation"), "{command}: {err}");
        }

        let commit_allowed = p
            .validate_command_execution("git commit -m test", true)
            .expect("runtime-approved Git write verb should remain allowed");
        assert_eq!(commit_allowed, CommandRiskLevel::Medium);

        let push_allowed = p
            .validate_command_execution("git push origin main", true)
            .expect("runtime-approved Git push to a configured remote should remain allowed");
        assert_eq!(push_allowed, CommandRiskLevel::Medium);

        let init_allowed = p
            .validate_command_execution("git init ./dst", false)
            .expect("plain Git init should remain allowed");
        assert_eq!(init_allowed, CommandRiskLevel::Low);

        let rebase_denied = p
            .validate_command_execution("git rebase main", false)
            .expect_err("Git rebase without an exec hook should still require approval");
        assert!(rebase_denied.contains("medium-risk operation"));

        let rebase_allowed = p
            .validate_command_execution("git rebase main", true)
            .expect("runtime-approved Git rebase without an exec hook should remain allowed");
        assert_eq!(rebase_allowed, CommandRiskLevel::Medium);

        for command in [
            "git am ./change.mbox",
            "git pull origin main",
            "git -C . pull origin main",
            "git worktree add ./dst HEAD",
            "git -C . worktree add ./dst HEAD",
        ] {
            let denied = p
                .validate_command_execution(command, false)
                .expect_err("Git mutations and lifecycle hooks must require approval");
            assert!(
                denied.contains("medium-risk operation"),
                "{command}: {denied}"
            );

            let allowed = p
                .validate_command_execution(command, true)
                .expect("runtime-approved Git mutations should remain available");
            assert_eq!(allowed, CommandRiskLevel::Medium, "{command}");
        }

        let global_option_commit_denied = p
            .validate_command_execution("git -C . commit -m test", false)
            .expect_err("Git write verbs behind global options still require approval");
        assert!(
            global_option_commit_denied.contains("medium-risk operation"),
            "{global_option_commit_denied}"
        );

        let global_option_commit_allowed = p
            .validate_command_execution("git -C . commit -m test", true)
            .expect("runtime-approved Git write verb behind global options should remain allowed");
        assert_eq!(global_option_commit_allowed, CommandRiskLevel::Medium);
    }

    #[test]
    fn git_read_verb_mutating_args_are_gated_at_the_enforcement_boundary() {
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        // Read-by-default verbs that mutate via an argument must require
        // approval instead of staying Low.
        for command in [
            "git fsck --lost-found",
            "git fsck --lost",
            "git fsck --l",
            "git diff --output=/tmp/out",
            "git diff --output /tmp/out",
            "git -C . log --output=/tmp/out",
            "git show --output=/tmp/out",
            "git whatchanged --output=/tmp/out",
            "git diff-tree --output=/tmp/out HEAD",
            "git diff-index --output=/tmp/out HEAD",
            "git diff-files --output=/tmp/out",
        ] {
            let denied = p
                .validate_command_execution(command, false)
                .expect_err("Git read verbs that mutate via arguments must require approval");
            assert!(
                denied.contains("medium-risk operation"),
                "{command}: {denied}"
            );
            let approved = p
                .validate_command_execution(command, true)
                .expect("runtime-approved mutating Git read verb should remain allowed");
            assert_eq!(approved, CommandRiskLevel::Medium, "{command}");
        }

        // Plain reads and look-alike options stay Low.
        for command in [
            "git fsck",
            "git diff --output-indicator-new=+ HEAD",
            "git diff -O/tmp/order HEAD",
            "git whatchanged --stat",
        ] {
            let allowed = p
                .validate_command_execution(command, false)
                .expect("plain Git reads should remain allowed without approval");
            assert_eq!(allowed, CommandRiskLevel::Low, "{command}");
        }

        // `git grep -O` / `--open-files-in-pager` runs a pager (external
        // command), even clustered behind other short flags; it must be
        // rejected outright, not merely gated.
        for command in [
            "git grep -O foo",
            "git grep -Ovim foo",
            "git grep -nO foo",
            "git grep --open-files-in-pager=sh foo",
        ] {
            let err = p
                .validate_command_execution(command, true)
                .expect_err("Git grep pager execution must be rejected even with approval");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{command}: {err}"
            );
        }

        // `-o` is `--only-matching` (a read) and stays allowed and Low; the
        // pager scan is case-sensitive and stops at value-consuming flags.
        for command in ["git grep -o needle", "git grep -no needle"] {
            let allowed = p
                .validate_command_execution(command, false)
                .expect("git grep --only-matching should remain a read");
            assert_eq!(allowed, CommandRiskLevel::Low, "{command}");
        }
    }

    #[test]
    fn git_index_and_worktree_mutations_require_approval() {
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        // Verbs that mutate the index or working tree. These stay command-
        // allowed but must require approval rather than classifying Low.
        for command in [
            "git add .",
            "git add -A",
            "git rm --cached secret",
            "git mv a b",
            "git restore src/main.rs",
            "git restore --staged src/main.rs",
            "git apply patch.diff",
            "git stash",
            "git stash push -m wip",
            "git -C . add .",
        ] {
            assert!(p.is_command_allowed(command), "{command}");
            let denied = p
                .validate_command_execution(command, false)
                .expect_err("index/working-tree mutations must require approval");
            assert!(
                denied.contains("medium-risk operation"),
                "{command}: {denied}"
            );
            let approved = p
                .validate_command_execution(command, true)
                .expect("runtime-approved mutation should remain allowed");
            assert_eq!(approved, CommandRiskLevel::Medium, "{command}");
        }
    }

    #[cfg(not(target_os = "windows"))]
    #[test]
    fn unix_literal_backslash_executable_is_not_allowlist_match() {
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        for command in [
            r#""g\it" status"#,
            r#"'foo\git' status"#,
            r#"'git>helper' status"#,
            r#""git<helper" status"#,
            r#""FOO=bar" git status"#,
            r#"FOO\=bar git status"#,
            r#"git\" status"#,
            r#"\"git status"#,
            r#""git\"" status"#,
            r#"'git ' status"#,
            r#"' git' status"#,
            "git\\  status",
            r#"'git '>/dev/null status"#,
            r#"' git'>/dev/null status"#,
            r#"'2'>/dev/null git status"#,
            r#"\2>/dev/null git status"#,
            "git\\ >/dev/null status",
        ] {
            let result = p.validate_command_execution(command, false);
            assert!(result.is_err(), "{command}: {result:?}");
            let err = result.unwrap_err();
            assert!(
                err.contains("Command not allowed by security policy"),
                "{err}"
            );
        }
    }

    #[test]
    fn git_unmodeled_shell_expansions_rejected_at_policy_boundary() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            require_approval_for_medium_risk: true,
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        for command in [
            concat!("git -C . com\\", "\n", "mit -m test"),
            "git -C {.,commit} -m test",
            "git -C . $'commit' -m test",
            "git -C . $\"commit\" -m test",
            "git -C . $=verb -m test",
            "git -C . $+verb -m test",
            "git -C . $^verb -m test",
            "git -C . $~verb -m test",
            "git -C . \"$[2+3]\" -m test",
            "git -C . \"$<\" -m test",
            "git -C . com* -m test",
            "git -C . @(commit) -m test",
            "git -C . +(commit) -m test",
            "git -C . !(status) -m test",
            "git -C . ^status -m test",
        ] {
            let err = p
                .validate_command_execution(command, false)
                .expect_err("unmodeled shell expansion must be rejected before execution");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{err}"
            );
        }

        for command in ["git -C . com#mit -m test", "git -C . crates~status -m test"] {
            let err = p
                .validate_command_execution(command, false)
                .expect_err("zsh extended glob must be rejected before execution");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{err}"
            );
        }

        for command in [
            "git -C ~/repo status",
            "FOO=~/repo git status",
            "FOO=x:~/repo git status",
        ] {
            assert!(!contains_unmodeled_shell_word_expansion(
                command,
                ShellDialect::Posix,
            ));
        }

        for command in ["echo C#", "echo file~backup"] {
            assert!(contains_unmodeled_shell_word_expansion(
                command,
                ShellDialect::Posix,
            ));
            assert!(!contains_unmodeled_shell_word_expansion(
                command,
                ShellDialect::WindowsCmd,
            ));
        }
        assert!(contains_unmodeled_shell_word_expansion(
            "echo %USERPROFILE%",
            ShellDialect::WindowsCmd,
        ));
        assert!(!contains_unmodeled_shell_word_expansion(
            "echo %USERPROFILE%",
            ShellDialect::Posix,
        ));
    }

    #[test]
    fn windows_backslash_executable_is_not_normalized_to_allowlisted_command() {
        let p = SecurityPolicy {
            allowed_commands: vec!["cat".into()],
            ..SecurityPolicy::default()
        };

        let err = p
            .validate_command_execution_for_shell(
                "c\\at ./src/main.rs",
                false,
                ShellDialect::WindowsCmd,
            )
            .expect_err("Windows path separators must not become allowlisted command text");
        assert!(
            err.contains("Command not allowed by security policy"),
            "{err}"
        );
    }

    #[cfg(target_os = "windows")]
    #[test]
    fn windows_single_quotes_remain_literal_executable_text() {
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        let err = p
            .validate_command_execution("g'i't.exe status", false)
            .expect_err("cmd.exe single quotes must not normalize to an allowlisted executable");
        assert!(
            err.contains("Command not allowed by security policy"),
            "{err}"
        );
    }

    #[cfg(target_os = "windows")]
    #[test]
    fn windows_cmd_expansions_cannot_hide_git_write_verbs() {
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        for command in [
            "git %ZC_GIT_VERB%",
            "git !ZC_GIT_VERB!",
            "git co^mmit -m test",
        ] {
            assert!(!p.is_command_allowed(command), "{command}");
            let err = p
                .validate_command_execution(command, false)
                .expect_err("cmd.exe transformations must fail closed before execution");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{command}: {err}"
            );
        }
    }

    #[test]
    fn validate_command_blocks_high_risk_via_wildcard() {
        // Wildcard allows the command through is_command_allowed, but
        // block_high_risk_commands still rejects it because "*" does not
        // count as an explicit allowlist entry.
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            allowed_commands: vec!["*".into()],
            ..SecurityPolicy::default()
        };

        let result = p.validate_command_execution("rm -rf /tmp/test", true);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("high-risk"));
    }

    #[test]
    fn validate_command_allows_explicitly_listed_high_risk() {
        // When a high-risk command is explicitly in allowed_commands, the
        // block_high_risk_commands gate is bypassed — the operator has made
        // a deliberate decision to permit it.
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            allowed_commands: vec!["curl".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };

        let result = p.validate_command_execution("curl https://api.example.com/data", true);
        assert_eq!(result.unwrap(), CommandRiskLevel::High);
    }

    #[test]
    fn validate_command_allows_wget_when_explicitly_listed() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            allowed_commands: vec!["wget".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };

        let result =
            p.validate_command_execution("wget https://releases.example.com/v1.tar.gz", true);
        assert_eq!(result.unwrap(), CommandRiskLevel::High);
    }

    #[test]
    fn validate_command_blocks_non_listed_high_risk_when_another_is_allowed() {
        // Allowing curl explicitly should not exempt wget.
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            allowed_commands: vec!["curl".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };

        let result = p.validate_command_execution("wget https://evil.com", true);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("not allowed"));
    }

    #[test]
    fn validate_command_explicit_rm_bypasses_high_risk_block() {
        // Operator explicitly listed "rm" — they accept the risk.
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            allowed_commands: vec!["rm".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };

        let result = p.validate_command_execution("rm -rf /tmp/test", true);
        assert_eq!(result.unwrap(), CommandRiskLevel::High);
    }

    #[test]
    fn validate_command_high_risk_still_needs_approval_in_supervised() {
        // Even when explicitly allowed, supervised mode still requires
        // approval for high-risk commands (the approval gate is separate
        // from the block gate).
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            allowed_commands: vec!["curl".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };

        let denied = p.validate_command_execution("curl https://api.example.com", false);
        assert!(denied.is_err());
        assert!(denied.unwrap_err().contains("requires explicit approval"));

        let allowed = p.validate_command_execution("curl https://api.example.com", true);
        assert_eq!(allowed.unwrap(), CommandRiskLevel::High);
    }

    #[test]
    fn validate_command_pipe_needs_all_segments_explicitly_allowed() {
        // When a pipeline contains a high-risk command, every segment
        // must be explicitly allowed for the exemption to apply.
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            allowed_commands: vec!["curl".into(), "grep".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };

        let result = p.validate_command_execution("curl https://api.example.com | grep data", true);
        assert_eq!(result.unwrap(), CommandRiskLevel::High);
    }

    #[test]
    fn validate_command_full_mode_skips_medium_risk_approval_gate() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            require_approval_for_medium_risk: true,
            allowed_commands: vec!["touch".into()],
            ..SecurityPolicy::default()
        };

        let result = p.validate_command_execution("touch test.txt", false);
        assert_eq!(result.unwrap(), CommandRiskLevel::Medium);
    }

    #[test]
    fn validate_command_rejects_background_chain_bypass() {
        let p = default_policy();
        let result = p.validate_command_execution("ls & python3 -c 'print(1)'", false);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("not allowed"));
    }

    // ── is_path_allowed ─────────────────────────────────────

    #[test]
    fn relative_paths_allowed() {
        let p = default_policy();
        assert!(p.is_path_allowed("file.txt"));
        assert!(p.is_path_allowed("src/main.rs"));
        assert!(p.is_path_allowed("deep/nested/dir/file.txt"));
    }

    #[test]
    fn path_traversal_blocked() {
        let p = default_policy();
        assert!(!p.is_path_allowed("../etc/passwd"));
        assert!(!p.is_path_allowed("../../root/.ssh/id_rsa"));
        assert!(!p.is_path_allowed("foo/../../../etc/shadow"));
        assert!(!p.is_path_allowed(".."));
    }

    #[test]
    fn absolute_paths_blocked_when_workspace_only() {
        let p = default_policy();
        assert!(!p.is_path_allowed(&tp_sys_sub("etc/passwd")));
        assert!(!p.is_path_allowed(&tp_sys_sub("root/.ssh/id_rsa")));
        assert!(!p.is_path_allowed(tp_outside2()));
    }

    #[test]
    fn absolute_path_inside_workspace_allowed_when_workspace_only() {
        let ws = tp_ws();
        let p = SecurityPolicy {
            workspace_dir: ws.clone(),
            workspace_only: true,
            ..SecurityPolicy::default()
        };
        assert!(p.is_path_allowed(&format!("{}/images/example.png", ws.display())));
        assert!(p.is_path_allowed(&format!("{}/file.txt", ws.display())));
        assert!(!p.is_path_allowed(tp_outside1()));
        assert!(!p.is_path_allowed(tp_outside2()));
    }

    #[test]
    fn absolute_path_in_allowed_root_permitted_when_workspace_only() {
        let ws = tp_ws();
        let shared = tp_ws_shared();
        let p = SecurityPolicy {
            workspace_dir: ws.clone(),
            workspace_only: true,
            allowed_roots: vec![shared.clone()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_path_allowed(&format!("{}/data.txt", shared.display())));
        assert!(p.is_path_allowed(&format!("{}/file.txt", ws.display())));
        assert!(!p.is_path_allowed(tp_outside1()));
    }

    #[test]
    fn absolute_paths_allowed_when_not_workspace_only() {
        let p = SecurityPolicy {
            workspace_only: false,
            forbidden_paths: vec![],
            ..SecurityPolicy::default()
        };
        assert!(p.is_path_allowed("/tmp/file.txt"));
    }

    #[test]
    fn forbidden_paths_blocked() {
        let p = SecurityPolicy {
            workspace_only: false,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_path_allowed(&tp_sys_sub("etc/passwd")));
        assert!(!p.is_path_allowed(&tp_sys_sub("root/.bashrc")));
        assert!(!p.is_path_allowed("~/.ssh/id_rsa"));
        assert!(!p.is_path_allowed("~/.gnupg/pubring.kbx"));
    }

    // ── deny-before-allow with most-specific-match wins ─────────────────
    //
    // `forbidden_paths` must apply even when a path also falls under the
    // workspace or an allowed root. Specificity (matched path-component
    // depth) breaks ties so a narrow explicit forbidden entry beats a broad
    // allowed root, while a narrow allowed root still beats a broad *default*
    // forbidden root such as `/home`.

    #[test]
    fn forbidden_overrides_allow_specificity_rules() {
        // Forbidden deeper than allow => deny.
        assert!(forbidden_overrides_allow(Some(4), Some(3)));
        // Equal depth => deny (explicit forbidden at the allow boundary wins).
        assert!(forbidden_overrides_allow(Some(3), Some(3)));
        // Broad forbidden shallower than a specific allow => allow.
        assert!(!forbidden_overrides_allow(Some(1), Some(3)));
        // Forbidden with no competing allow => deny.
        assert!(forbidden_overrides_allow(Some(2), None));
        // No forbidden match => allow.
        assert!(!forbidden_overrides_allow(None, Some(3)));
        assert!(!forbidden_overrides_allow(None, None));
    }

    #[cfg(not(target_os = "windows"))]
    #[test]
    fn forbidden_path_nested_under_allowed_root_is_denied() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/srv/ws"),
            workspace_only: false,
            allowed_roots: vec![PathBuf::from("/home/me/project")],
            forbidden_paths: vec!["/home/me/project/secrets".into()],
            ..SecurityPolicy::default()
        };
        // The allowed root itself and non-forbidden children remain allowed.
        assert!(p.is_path_allowed("/home/me/project/main.rs"));
        // The explicit, more-specific forbidden subtree is denied even though
        // it falls under an allowed_roots entry (the reported repro).
        assert!(!p.is_path_allowed("/home/me/project/secrets/key.txt"));
        assert!(!p.is_path_allowed("/home/me/project/secrets"));
    }

    #[cfg(not(target_os = "windows"))]
    #[test]
    fn allowed_root_more_specific_than_broad_default_forbidden_still_allows() {
        // Default forbidden paths include broad roots like `/home`. An operator
        // allowlist that is more specific than that broad root must still work.
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/srv/ws"),
            workspace_only: false,
            allowed_roots: vec![PathBuf::from("/home/me/project")],
            forbidden_paths: default_forbidden_paths(),
            ..SecurityPolicy::default()
        };
        assert!(p.is_path_allowed("/home/me/project/main.rs"));
        // A sibling under the broad forbidden `/home` that is NOT under the
        // allowlist is still denied.
        assert!(!p.is_path_allowed("/home/me/other/file.txt"));
    }

    #[cfg(not(target_os = "windows"))]
    #[test]
    fn forbidden_path_nested_in_workspace_is_denied() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/srv/ws"),
            workspace_only: true,
            forbidden_paths: vec!["/srv/ws/secrets".into()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_path_allowed("/srv/ws/notes.md"));
        assert!(!p.is_path_allowed("/srv/ws/secrets/token"));
    }

    #[cfg(not(target_os = "windows"))]
    #[test]
    fn resolved_path_allowed_honors_forbidden_under_allowed_root() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/srv/ws"),
            workspace_only: false,
            allowed_roots: vec![PathBuf::from("/home/me/project")],
            forbidden_paths: vec!["/home/me/project/secrets".into()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_resolved_path_allowed(Path::new("/home/me/project/main.rs")));
        assert!(!p.is_resolved_path_allowed(Path::new("/home/me/project/secrets/key.txt")));
    }

    #[cfg(not(target_os = "windows"))]
    #[test]
    fn resolved_path_allowed_narrow_allow_beats_broad_default_forbidden() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/srv/ws"),
            workspace_only: false,
            allowed_roots: vec![PathBuf::from("/home/me/project")],
            forbidden_paths: default_forbidden_paths(),
            ..SecurityPolicy::default()
        };
        assert!(p.is_resolved_path_allowed(Path::new("/home/me/project/main.rs")));
    }

    #[cfg(not(target_os = "windows"))]
    #[test]
    fn resolved_path_readable_honors_forbidden_under_allowed_root() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/srv/ws"),
            workspace_only: false,
            allowed_roots: vec![PathBuf::from("/home/me/project")],
            forbidden_paths: vec!["/home/me/project/secrets".into()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_resolved_path_readable(Path::new("/home/me/project/main.rs")));
        assert!(!p.is_resolved_path_readable(Path::new("/home/me/project/secrets/key.txt")));
    }

    #[cfg(not(target_os = "windows"))]
    #[test]
    fn resolved_path_readable_narrow_allow_beats_broad_default_forbidden() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/srv/ws"),
            workspace_only: false,
            allowed_roots: vec![PathBuf::from("/home/me/project")],
            forbidden_paths: default_forbidden_paths(),
            ..SecurityPolicy::default()
        };
        assert!(p.is_resolved_path_readable(Path::new("/home/me/project/main.rs")));
    }

    #[cfg(unix)]
    #[test]
    fn resolved_write_denies_forbidden_symlink_alias_with_missing_leaf() {
        use std::os::unix::fs::symlink;

        let tmp = tempfile::tempdir().unwrap();
        let real_root = tmp.path().join("real");
        let project = real_root.join("project");
        let secrets = project.join("secrets");
        let public = project.join("public");
        let workspace = tmp.path().join("workspace");
        std::fs::create_dir_all(&secrets).unwrap();
        std::fs::create_dir_all(&public).unwrap();
        std::fs::create_dir_all(&workspace).unwrap();

        let alias = tmp.path().join("alias");
        symlink(&real_root, &alias).unwrap();

        let policy = SecurityPolicy {
            workspace_dir: workspace,
            workspace_only: true,
            allowed_roots: vec![project.clone()],
            forbidden_paths: vec![alias.join("project/secrets").display().to_string()],
            ..SecurityPolicy::default()
        };

        let denied = secrets.join("new-key.txt");
        assert!(
            !denied.exists(),
            "the create target must remain non-existent"
        );
        let resolved_denied = resolve_symlinked_path(&denied).unwrap();
        assert!(
            !policy.is_resolved_path_allowed(&resolved_denied),
            "a forbidden alias must deny the equivalent canonical create target"
        );

        let allowed = resolve_symlinked_path(&public.join("new-note.txt")).unwrap();
        assert!(
            policy.is_resolved_path_allowed(&allowed),
            "a sibling beneath the canonical allowed root must remain writable"
        );
    }

    #[cfg(unix)]
    #[test]
    fn resolved_read_denies_forbidden_symlink_alias() {
        use std::os::unix::fs::symlink;

        let tmp = tempfile::tempdir().unwrap();
        let real_root = tmp.path().join("real");
        let project = real_root.join("project");
        let secrets = project.join("secrets");
        let public = project.join("public");
        let workspace = tmp.path().join("workspace");
        std::fs::create_dir_all(&secrets).unwrap();
        std::fs::create_dir_all(&public).unwrap();
        std::fs::create_dir_all(&workspace).unwrap();
        std::fs::write(secrets.join("key.txt"), b"secret").unwrap();
        std::fs::write(public.join("note.txt"), b"public").unwrap();

        let alias = tmp.path().join("alias");
        symlink(&real_root, &alias).unwrap();

        let policy = SecurityPolicy {
            workspace_dir: workspace,
            workspace_only: true,
            allowed_roots_read_only: vec![project],
            forbidden_paths: vec![alias.join("project/secrets").display().to_string()],
            ..SecurityPolicy::default()
        };

        let denied = secrets.join("key.txt").canonicalize().unwrap();
        assert!(
            !policy.is_resolved_path_readable(&denied),
            "a forbidden alias must deny the equivalent canonical read target"
        );

        let allowed = public.join("note.txt").canonicalize().unwrap();
        assert!(
            policy.is_resolved_path_readable(&allowed),
            "a sibling beneath the canonical read-only root must remain readable"
        );
    }

    #[test]
    fn empty_path_allowed() {
        let p = default_policy();
        assert!(p.is_path_allowed(""));
    }

    #[test]
    fn dotfile_in_workspace_allowed() {
        let p = default_policy();
        assert!(p.is_path_allowed(".gitignore"));
        assert!(p.is_path_allowed(".env"));
    }

    // ── from_config ─────────────────────────────────────────

    #[test]
    fn from_config_maps_all_fields() {
        let risk = crate::schema::RiskProfileConfig {
            level: AutonomyLevel::Full,
            workspace_only: false,
            allowed_commands: vec!["docker".into()],
            forbidden_paths: vec!["/secret".into()],
            require_approval_for_medium_risk: false,
            block_high_risk_commands: false,
            shell_env_passthrough: vec!["DATABASE_URL".into()],
            ..crate::schema::RiskProfileConfig::default()
        };
        let runtime = crate::schema::RuntimeProfileConfig {
            max_actions_per_hour: 100,
            max_cost_per_day_cents: 1000,
            ..crate::schema::RuntimeProfileConfig::default()
        };
        let workspace = PathBuf::from("/tmp/test-workspace");
        let policy = SecurityPolicy::from_profiles(&risk, Some(&runtime), &workspace);

        assert_eq!(policy.autonomy, AutonomyLevel::Full);
        assert!(!policy.workspace_only);
        assert_eq!(policy.allowed_commands, vec!["docker"]);
        assert_eq!(policy.forbidden_paths, vec!["/secret"]);
        assert_eq!(policy.max_actions_per_hour, 100);
        assert_eq!(policy.max_cost_per_day_cents, 1000);
        assert!(!policy.require_approval_for_medium_risk);
        assert!(!policy.block_high_risk_commands);
        assert_eq!(policy.shell_env_passthrough, vec!["DATABASE_URL"]);
        assert_eq!(policy.workspace_dir, PathBuf::from("/tmp/test-workspace"));
    }

    #[test]
    fn from_config_full_autonomy_overrides_workspace_only() {
        //: Full autonomy should disable workspace_only even if the
        // config default keeps it true.
        let autonomy_config = crate::schema::RiskProfileConfig {
            level: AutonomyLevel::Full,
            ..crate::schema::RiskProfileConfig::default()
        };
        let workspace = PathBuf::from("/tmp/test-workspace");
        let policy = SecurityPolicy::from_risk_profile(&autonomy_config, &workspace);

        assert_eq!(policy.autonomy, AutonomyLevel::Full);
        assert!(
            !policy.workspace_only,
            "Full autonomy must override workspace_only to false"
        );
    }

    #[test]
    fn from_config_supervised_preserves_workspace_only() {
        let autonomy_config = crate::schema::RiskProfileConfig {
            level: AutonomyLevel::Supervised,
            ..crate::schema::RiskProfileConfig::default()
        };
        let workspace = PathBuf::from("/tmp/test-workspace");
        let policy = SecurityPolicy::from_risk_profile(&autonomy_config, &workspace);

        assert!(
            policy.workspace_only,
            "Supervised autonomy must preserve workspace_only default (true)"
        );
    }

    #[test]
    fn from_config_normalizes_allowed_roots() {
        let autonomy_config = crate::schema::RiskProfileConfig {
            allowed_roots: vec!["~/Desktop".into(), "shared-data".into()],
            ..crate::schema::RiskProfileConfig::default()
        };
        let workspace = tp_ws();
        let policy = SecurityPolicy::from_risk_profile(&autonomy_config, &workspace);

        let expected_home_root = if let Some(home) = home_dir() {
            home.join("Desktop")
        } else {
            PathBuf::from("~/Desktop")
        };

        assert_eq!(policy.allowed_roots[0], expected_home_root);
        assert_eq!(policy.allowed_roots[1], workspace.join("shared-data"));
    }

    #[test]
    fn resolved_path_violation_message_includes_allowed_roots_guidance() {
        let p = default_policy();
        let msg = p.resolved_path_violation_message(Path::new("/tmp/outside.txt"));
        assert!(msg.contains("escapes workspace"));
        assert!(msg.contains("allowed_roots"));
    }

    // ── Default policy ──────────────────────────────────────

    #[test]
    fn default_policy_has_sane_values() {
        let p = SecurityPolicy::default();
        assert_eq!(p.autonomy, AutonomyLevel::Supervised);
        assert!(p.workspace_only);
        assert!(!p.allowed_commands.is_empty());
        assert!(!p.forbidden_paths.is_empty());
        assert!(p.max_actions_per_hour > 0);
        assert!(p.max_cost_per_day_cents > 0);
        assert!(p.require_approval_for_medium_risk);
        assert!(p.block_high_risk_commands);
        assert!(p.shell_env_passthrough.is_empty());
    }

    // ── ActionTracker / rate limiting ───────────────────────

    #[test]
    fn action_tracker_starts_at_zero() {
        let tracker = ActionTracker::new();
        assert_eq!(tracker.count(), 0);
    }

    #[test]
    fn action_tracker_records_actions() {
        let tracker = ActionTracker::new();
        assert_eq!(tracker.record(), 1);
        assert_eq!(tracker.record(), 2);
        assert_eq!(tracker.record(), 3);
        assert_eq!(tracker.count(), 3);
    }

    #[test]
    fn action_tracker_retains_actions_when_cutoff_is_unavailable() {
        let mut actions = vec![Instant::now(), Instant::now()];

        retain_actions_after(&mut actions, None);

        assert_eq!(actions.len(), 2);
    }

    #[test]
    fn record_action_allows_within_limit() {
        let p = SecurityPolicy {
            max_actions_per_hour: 5,
            ..SecurityPolicy::default()
        };
        for _ in 0..5 {
            assert!(p.record_action(), "should allow actions within limit");
        }
    }

    #[test]
    fn record_action_blocks_over_limit() {
        let p = SecurityPolicy {
            max_actions_per_hour: 3,
            ..SecurityPolicy::default()
        };
        assert!(p.record_action()); // 1
        assert!(p.record_action()); // 2
        assert!(p.record_action()); // 3
        assert!(!p.record_action()); // 4 — over limit
    }

    #[test]
    fn is_rate_limited_reflects_count() {
        let p = SecurityPolicy {
            max_actions_per_hour: 2,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_rate_limited());
        p.record_action();
        assert!(!p.is_rate_limited());
        p.record_action();
        assert!(p.is_rate_limited());
    }

    #[test]
    fn action_tracker_clone_is_independent() {
        let tracker = ActionTracker::new();
        tracker.record();
        tracker.record();
        let cloned = tracker.clone();
        assert_eq!(cloned.count(), 2);
        tracker.record();
        assert_eq!(tracker.count(), 3);
        assert_eq!(cloned.count(), 2); // clone is independent
    }

    #[test]
    fn action_tracker_clone_does_not_copy_in_flight_usage() {
        let tracker = ActionTracker::new();
        assert!(tracker.reserve(1));

        let cloned = tracker.clone();

        assert_eq!(cloned.used(), 0);
    }

    // ── Edge cases: command injection ────────────────────────

    #[test]
    fn command_injection_semicolon_blocked() {
        let p = default_policy();
        // First word is "ls;" (with semicolon) — doesn't match "ls" in allowlist.
        // This is a safe default: chained commands are blocked.
        assert!(!p.is_command_allowed("ls; rm -rf /"));
    }

    #[test]
    fn command_injection_semicolon_no_space() {
        let p = default_policy();
        assert!(!p.is_command_allowed("ls;rm -rf /"));
    }

    #[test]
    fn quoted_semicolons_do_not_split_sqlite_command() {
        let p = SecurityPolicy {
            allowed_commands: vec!["sqlite3".into()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed(
            "sqlite3 /tmp/test.db \"CREATE TABLE t(id INT); INSERT INTO t VALUES(1); SELECT * FROM t;\""
        ));
        assert_eq!(
            p.command_risk_level(
                "sqlite3 /tmp/test.db \"CREATE TABLE t(id INT); INSERT INTO t VALUES(1); SELECT * FROM t;\""
            ),
            CommandRiskLevel::Low
        );
    }

    #[test]
    fn unquoted_semicolon_after_quoted_sql_still_splits_commands() {
        let p = SecurityPolicy {
            allowed_commands: vec!["sqlite3".into()],
            ..SecurityPolicy::default()
        };
        assert!(!p.is_command_allowed("sqlite3 /tmp/test.db \"SELECT 1;\"; rm -rf /"));
    }

    #[test]
    fn command_injection_backtick_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("echo `whoami`"));
        assert!(!p.is_command_allowed("echo `rm -rf /`"));
    }

    #[test]
    fn command_injection_dollar_paren_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("echo $(cat /etc/passwd)"));
        assert!(!p.is_command_allowed("echo $(rm -rf /)"));
    }

    #[test]
    fn command_injection_dollar_paren_literal_inside_single_quotes_allowed() {
        let p = default_policy();
        assert!(p.is_command_allowed("echo '$(cat /etc/passwd)'"));
    }

    #[test]
    fn command_injection_dollar_brace_literal_inside_single_quotes_allowed() {
        let p = default_policy();
        assert!(p.is_command_allowed("echo '${HOME}'"));
    }

    #[test]
    fn command_injection_dollar_brace_unquoted_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("echo ${HOME}"));
    }

    #[test]
    fn command_with_env_var_prefix() {
        let p = default_policy();
        // "FOO=bar" is the first word — not in allowlist
        assert!(!p.is_command_allowed("FOO=bar rm -rf /"));
    }

    #[test]
    fn command_newline_injection_blocked() {
        let p = default_policy();
        // Newline splits into two commands; "rm" is not in allowlist
        assert!(!p.is_command_allowed("ls\nrm -rf /"));
        // Both allowed — OK
        assert!(p.is_command_allowed("ls\necho hello"));
    }

    #[test]
    fn command_injection_and_chain_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("ls && rm -rf /"));
        assert!(!p.is_command_allowed("echo ok && curl http://evil.com"));
        // Both allowed — OK
        assert!(p.is_command_allowed("ls && echo done"));
    }

    #[test]
    fn command_injection_or_chain_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("ls || rm -rf /"));
        // Both allowed — OK
        assert!(p.is_command_allowed("ls || echo fallback"));
    }

    #[test]
    fn command_injection_background_chain_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("ls & rm -rf /"));
        assert!(!p.is_command_allowed("ls&rm -rf /"));
        assert!(!p.is_command_allowed("echo ok & python3 -c 'print(1)'"));
    }

    #[test]
    fn command_injection_redirect_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("echo secret > /etc/crontab"));
        assert!(!p.is_command_allowed("ls >> /tmp/exfil.txt"));
        assert!(!p.is_command_allowed("cat < /etc/passwd"));
        assert!(!p.is_command_allowed("echo secret > output.txt"));
        // Path-prefix bypass: /dev/null followed by extra path component
        assert!(!p.is_command_allowed("echo secret>/dev/nullextra"));
        assert!(!p.is_command_allowed("echo secret > /dev/null/../../etc/passwd"));
        assert!(!p.is_command_allowed("echo secret>/dev/stderrfoo"));
        // Word→non-word boundary bypasses
        assert!(!p.is_command_allowed("ls 2>/dev/stderr.log"));
        assert!(!p.is_command_allowed("cat>/dev/zero/path"));
        assert!(!p.is_command_allowed("echo>/dev/stdout.bak"));
    }

    // ── Interpreter argument injection ────────────────────

    #[test]
    fn interpreter_inline_eval_blocked() {
        let p = default_policy();
        // python: -c executes code string, -m runs arbitrary module
        assert!(!p.is_command_allowed("python3 -c 'import os; os.system(\"id\")'"));
        assert!(!p.is_command_allowed("python -c '__import__(\"os\").system(\"id\")'"));
        assert!(!p.is_command_allowed("python3 -m http.server"));
        assert!(!p.is_command_allowed("python3 -m pip install evil"));
        // Broad -m block: these are intentional collateral
        assert!(!p.is_command_allowed("python3 -m pytest"));
        assert!(!p.is_command_allowed("python3 -m mypy src/"));
        assert!(!p.is_command_allowed("python3 -m venv .venv"));
        // Glued form: -mhttp.server is one token
        assert!(!p.is_command_allowed("python3 -mhttp.server"));
        // node: -e/--eval evaluates JS, -p/--print evaluates and prints
        assert!(!p.is_command_allowed("node -e 'require(\"child_process\").execSync(\"id\")'"));
        assert!(!p.is_command_allowed("node --eval 'process.exit(1)'"));
        assert!(!p.is_command_allowed("node --eval=process.exit(1)"));
        assert!(!p.is_command_allowed("node -p '1+1'"));
        assert!(!p.is_command_allowed("node --print 'process.env'"));
        assert!(!p.is_command_allowed("node --print=process.env"));
        // Glued form bypass: -c'code' is one whitespace token
        assert!(!p.is_command_allowed("python3 -c'import os'"));
        assert!(!p.is_command_allowed("node -e'process.exit()'"));
        // Flag with other args before it
        assert!(!p.is_command_allowed("python3 -W ignore -c 'import os'"));
    }

    #[test]
    fn package_manager_install_blocked() {
        let p = default_policy();
        // pip: install/download fetch external packages and run setup.py
        assert!(!p.is_command_allowed("pip install evil-package"));
        assert!(!p.is_command_allowed("pip3 install evil-package"));
        assert!(!p.is_command_allowed("pip download evil-package"));
        // npm: exec fetches remote, install runs lifecycle scripts
        assert!(!p.is_command_allowed("npm exec -- malicious-pkg"));
        assert!(!p.is_command_allowed("npm install malicious-pkg"));
        assert!(!p.is_command_allowed("npm i malicious-pkg"));
        assert!(!p.is_command_allowed("npm add malicious-pkg"));
        assert!(!p.is_command_allowed("npm ci"));
        // cargo: install fetches+builds external crate (build.rs runs arbitrary code)
        assert!(!p.is_command_allowed("cargo install malicious-crate"));
    }

    #[test]
    fn safe_interpreter_usage_allowed() {
        let p = default_policy();
        // Running local files is safe — user trusts their workspace
        assert!(p.is_command_allowed("python3 script.py"));
        assert!(p.is_command_allowed("node app.js"));
        // Read-only / local workspace operations
        assert!(p.is_command_allowed("pip list"));
        assert!(p.is_command_allowed("pip freeze"));
        assert!(p.is_command_allowed("pip show requests"));
        assert!(p.is_command_allowed("npm test"));
        assert!(p.is_command_allowed("npm list"));
        assert!(p.is_command_allowed("cargo build"));
        assert!(p.is_command_allowed("cargo test"));
        assert!(p.is_command_allowed("cargo run"));
    }

    #[test]
    fn safe_redirect_to_dev_null_allowed() {
        let p = default_policy();
        assert!(p.is_command_allowed("echo secret > /dev/null"));
        assert!(p.is_command_allowed("ls 2> /dev/null"));
        assert!(p.is_command_allowed("find . 2>&1 > /dev/null"));
        assert!(p.is_command_allowed("cat</dev/null"));
    }

    #[test]
    fn windows_nul_redirect_allowed_only_under_cmd_exe() {
        // The Windows null device is a safe discard-only redirect target — but
        // ONLY under a native Windows `cmd.exe` shell. Under a POSIX shell (Unix
        // native or Docker `sh -c`) `nul` is an ordinary relative
        // filename, so `>nul` must stay blocked to prevent a workspace-file write.
        use ShellDialect::{Posix, WindowsCmd};
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into(), "echo".into()],
            ..SecurityPolicy::default()
        };

        for cmd in [
            "git -C E:/repo ls-tree -r --name-only HEAD path 2>nul",
            "echo x >nul",
            "echo x 1>NUL",
            "echo x 2>Nul",
            "echo x > nul",     // target as a separate token
            r"echo x >\\.\nul", // full device form
        ] {
            // cmd.exe: nul resolves to the discard-only null device.
            assert!(
                p.is_command_allowed_for_shell(cmd, WindowsCmd),
                "cmd.exe must allow the nul null device: {cmd}"
            );
            // POSIX shell: the SAME command must be blocked (nul is a real file).
            assert!(
                !p.is_command_allowed_for_shell(cmd, Posix),
                "POSIX shell must block a redirect to `nul` (an ordinary file): {cmd}"
            );
        }

        // The default (dialect-less) entry point is POSIX/fail-closed, so it
        // blocks `nul`; configured runtime consumers pass their actual dialect.
        assert!(!p.is_command_allowed("echo x >nul"));

        // The redirect gate itself: nul is stripped as safe only under cmd.exe.
        assert!(!contains_unsafe_output_redirect_for_shell(
            "git status 2>nul",
            WindowsCmd
        ));
        assert!(contains_unsafe_output_redirect_for_shell(
            "git status 2>nul",
            Posix
        ));
        assert!(!contains_unsafe_output_redirect_for_shell(
            r"echo x >\\.\nul",
            WindowsCmd
        ));
        assert!(contains_unsafe_output_redirect_for_shell(
            r"echo x >\\.\nul",
            Posix
        ));

        // POSIX device paths are safe only for the POSIX shell. A real file and
        // a non-bare `nul`-prefixed name stay blocked under both dialects.
        assert!(p.is_command_allowed_for_shell("git status 2>/dev/null", Posix));
        assert!(!p.is_command_allowed_for_shell("git status 2>/dev/null", WindowsCmd));
        assert!(!p.is_command_allowed_for_shell("echo secret 2>out.txt", WindowsCmd));
        assert!(!p.is_command_allowed_for_shell("echo secret >nul.txt", WindowsCmd));
        assert!(contains_unsafe_output_redirect_for_shell(
            "echo secret >nul.txt",
            WindowsCmd
        ));
    }

    #[test]
    fn windows_cmd_operator_and_device_redirects_are_fail_closed() {
        use ShellDialect::{Posix, WindowsCmd};
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };

        for command in [
            "git status 'x & whoami'",
            r"git status x\&whoami",
            "git status 'x | whoami'",
            "git status 'x > /dev/null'",
            "git status >/dev/null",
            "git status </dev/zero",
        ] {
            assert!(
                p.validate_command_execution_for_shell(command, false, WindowsCmd)
                    .is_err(),
                "cmd.exe must reject policy-hidden operator or POSIX device redirect: {command}"
            );
        }

        for command in [
            "git status 'x & whoami'",
            r"git status x\&whoami",
            "git status 'x | whoami'",
            "git status 'x > /dev/null'",
            "git status >/dev/null",
            "git status </dev/zero",
        ] {
            assert!(
                p.validate_command_execution_for_shell(command, false, Posix)
                    .is_ok(),
                "POSIX must retain quoted, escaped, and safe-device behavior: {command}"
            );
        }
    }

    #[test]
    fn safe_redirect_to_dev_stdout_allowed() {
        let p = default_policy();
        assert!(p.is_command_allowed("echo hello > /dev/stdout"));
        assert!(p.is_command_allowed("cat /dev/zero > /dev/stdout"));
    }

    #[test]
    fn safe_redirect_to_dev_stderr_allowed() {
        let p = default_policy();
        assert!(p.is_command_allowed("echo error > /dev/stderr"));
        assert!(p.is_command_allowed("ls 1> /dev/stderr"));
    }

    #[test]
    fn safe_redirect_to_dev_zero_allowed() {
        let p = default_policy();
        assert!(p.is_command_allowed("cat /dev/zero > /dev/null"));
    }

    #[test]
    fn safe_file_descriptor_redirect_allowed() {
        let p = default_policy();
        assert!(p.is_command_allowed("find . 2>&1"));
        assert!(p.is_command_allowed("echo hello 1>&2"));
        assert!(p.is_command_allowed("ls 2>&1 > /dev/null"));
        // Bare fd redirects (implicit fd number)
        assert!(p.is_command_allowed("echo error >&2"));
        assert!(p.is_command_allowed("cat <&0"));
        assert!(p.is_command_allowed("echo >&-"));
        assert!(p.is_command_allowed("echo 3>&-"));
    }

    #[test]
    fn heredoc_and_herestring_allowed() {
        let p = default_policy();
        assert!(p.is_command_allowed("cat << 'EOF'"));
        assert!(p.is_command_allowed("cat <<EOF"));
        assert!(p.is_command_allowed("cat <<< 'hello'"));
        // Input redirects from files still blocked
        assert!(!p.is_command_allowed("cat < /etc/passwd"));
        // Output redirects to files still blocked
        assert!(!p.is_command_allowed("echo secret > output.txt"));
    }

    #[test]
    fn multiline_heredoc_allowed() {
        let p = default_policy();
        // Multiline heredoc body must not be split into separate segments that
        // fail the allowlist check on the body lines.
        assert!(p.is_command_allowed("cat <<EOF\nhello world\nEOF"));
        assert!(p.is_command_allowed("cat <<'EOF'\nhello world\nEOF"));
        assert!(p.is_command_allowed("cat << EOF\nhello world\nEOF"));
        // Quoted delimiter variant
        assert!(p.is_command_allowed("cat <<\"EOF\"\nhello world\nEOF"));
        // Heredoc followed by an allowed command is still two valid segments
        assert!(p.is_command_allowed("cat <<EOF\nhello\nEOF\necho done"));
        // Heredoc followed by a disallowed command must be blocked
        assert!(!p.is_command_allowed("cat <<EOF\nhello\nEOF\nrm -rf /"));
        // Unterminated heredoc — entire input stays as one segment (safe: cat is allowed).
        assert!(p.is_command_allowed("cat <<EOF\nhello world"));
    }

    #[test]
    fn redirect_helper_unit_tests() {
        assert!(!contains_unquoted_input_redirect(
            "cat << 'EOF'",
            ShellDialect::Posix
        ));
        assert!(!contains_unquoted_input_redirect(
            "cat <<< 'hello'",
            ShellDialect::Posix
        ));
        assert!(contains_unquoted_input_redirect(
            "cat < /etc/passwd",
            ShellDialect::Posix
        ));
        assert!(!contains_unquoted_input_redirect(
            "echo 'a<b'",
            ShellDialect::Posix
        ));
        assert!(!contains_unquoted_input_redirect(
            "cat</dev/null",
            ShellDialect::Posix
        ));
        // Input redirect word→non-word bypass (same fix as output redirects)
        assert!(contains_unquoted_input_redirect(
            "cat</dev/null.secret",
            ShellDialect::Posix
        ));
        assert!(contains_unquoted_input_redirect(
            "cat </dev/zero/etc/passwd",
            ShellDialect::Posix
        ));
        assert!(!contains_unsafe_output_redirect("cmd 2>/dev/null"));
        assert!(!contains_unsafe_output_redirect("cmd >/dev/null"));
        assert!(!contains_unsafe_output_redirect("cmd 1>/dev/null"));
        assert!(!contains_unsafe_output_redirect("cmd 2>&1"));
        assert!(!contains_unsafe_output_redirect("cmd 1>&2"));
        assert!(!contains_unsafe_output_redirect("echo > /dev/stdout"));
        assert!(!contains_unsafe_output_redirect("echo > /dev/stderr"));
        assert!(!contains_unsafe_output_redirect("echo > /dev/zero"));
        assert!(contains_unsafe_output_redirect("echo hi > file.txt"));
        assert!(!contains_unsafe_output_redirect("echo 'a>b'"));
        // Word→non-word boundary bypasses: dot, slash, or other non-operator chars
        // after a safe device name must NOT strip the redirect
        assert!(contains_unsafe_output_redirect("ls 2>/dev/stderr.log"));
        assert!(contains_unsafe_output_redirect("cat>/dev/zero/path"));
        assert!(contains_unsafe_output_redirect("echo>/dev/stdout.bak"));
    }

    #[test]
    fn quoted_ampersand_and_redirect_literals_are_not_treated_as_operators() {
        let p = default_policy();
        assert!(p.is_command_allowed("echo \"A&B\""));
        assert!(p.is_command_allowed("echo \"A>B\""));
        assert!(p.is_command_allowed("echo \"A<B\""));
    }

    #[test]
    fn git_dash_c_uppercase_is_allowed() {
        // git -C (change directory) must not be
        // conflated with git -c (set config override) after arg lowercasing.
        let p = default_policy();
        assert!(
            p.is_command_allowed("git -C /home/user/repo status --short"),
            "git -C is benign and should be allowed"
        );
        assert!(
            p.is_command_allowed("git -C /home/user/repo log --oneline -1"),
            "git -C with log should be allowed"
        );
        // git -c (lowercase) is still blocked — config override injection
        assert!(
            !p.is_command_allowed("git -c core.editor=\"rm -rf /\" commit"),
            "git -c must remain blocked"
        );
    }

    #[test]
    fn command_argument_injection_blocked() {
        let p = default_policy();
        for command in [
            "find . -exec rm -rf '{}' +",
            "find / -ok cat '{}' ';'",
            "find . -execdir git commit '{}' +",
            "find . -okdir env GIT_CONFIG_GLOBAL=./zc-config git zcprobe '{}' ';'",
        ] {
            assert!(!p.is_command_allowed(command), "{command}");
            let err = p
                .validate_command_execution(command, false)
                .expect_err("find command carriers must fail before child execution");
            assert!(
                err.contains("Command not allowed by security policy"),
                "{command}: {err}"
            );
        }
        // git config/alias can execute commands
        assert!(!p.is_command_allowed("git config core.editor \"rm -rf /\""));
        assert!(!p.is_command_allowed("git alias.st status"));
        assert!(!p.is_command_allowed("git -c core.editor=calc.exe commit"));
        assert!(!p.is_command_allowed("git --config-env=alias.st=ZC_ALIAS status"));
        // Legitimate commands should still work
        assert!(p.is_command_allowed("find . -name '*.txt'"));
        assert!(p.is_command_allowed("git status"));
        assert!(p.is_command_allowed("git add ."));
    }

    #[test]
    fn command_injection_dollar_brace_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("echo ${IFS}cat${IFS}/etc/passwd"));
    }

    #[test]
    fn command_injection_plain_dollar_var_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("cat $HOME/.ssh/id_rsa"));
        assert!(!p.is_command_allowed("cat $SECRET_FILE"));
    }

    #[test]
    fn command_injection_tee_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("echo secret | tee /etc/crontab"));
        assert!(!p.is_command_allowed("ls | /usr/bin/tee outfile"));
        assert!(!p.is_command_allowed("tee file.txt"));
    }

    #[test]
    fn command_injection_process_substitution_blocked() {
        let p = default_policy();
        assert!(!p.is_command_allowed("cat <(echo pwned)"));
        assert!(!p.is_command_allowed("ls >(cat /etc/passwd)"));
    }

    #[test]
    fn command_env_var_prefix_with_allowed_cmd() {
        let p = default_policy();
        // Per-invocation environment changes can alter executable resolution or
        // command behavior before the allowlist and risk model see it.
        assert!(!p.is_command_allowed("FOO=bar ls"));
        assert!(!p.is_command_allowed("LANG=C grep pattern file"));
        assert!(!p.is_command_allowed("FOO=bar rm -rf /"));
    }

    #[test]
    fn forbidden_path_argument_detects_absolute_path() {
        let p = unix_forbidden_path_policy();
        assert_eq!(
            p.forbidden_path_argument("cat /etc/passwd"),
            Some("/etc/passwd".into())
        );
    }

    #[test]
    fn forbidden_path_argument_detects_parent_dir_reference() {
        let p = default_policy();
        assert_eq!(
            p.forbidden_path_argument("cat ../secret.txt"),
            Some("../secret.txt".into())
        );
        assert_eq!(
            p.forbidden_path_argument("find .. -name '*.rs'"),
            Some("..".into())
        );
    }

    #[test]
    fn powershell_path_guard_blocks_windows_relative_and_executable_paths() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            workspace_dir: tp_ws(),
            allowed_commands: vec!["cat".into(), "git".into()],
            ..SecurityPolicy::default()
        };

        for (command, blocked_path) in [
            ("cat ..\\secret.txt", "..\\secret.txt"),
            ("cat .\\..\\secret.txt", ".\\..\\secret.txt"),
            ("cat ~\\.ssh\\id_rsa", "~\\.ssh\\id_rsa"),
            ("cat C:secret.txt", "C:secret.txt"),
            ("..\\git.exe status", "..\\git.exe"),
        ] {
            assert_eq!(
                p.forbidden_path_argument_for_shell(command, ShellDialect::PowerShell),
                Some(blocked_path.to_string()),
                "PowerShell path should be blocked: {command}"
            );

            let error = p
                .validate_command_execution_for_shell(command, true, ShellDialect::PowerShell)
                .expect_err("named allowlists must not bypass PowerShell path confinement");
            assert!(
                error.contains("forbidden path argument"),
                "unexpected rejection for {command}: {error}"
            );
        }

        assert_eq!(
            p.forbidden_path_argument_for_shell("cat .\\src\\main.rs", ShellDialect::PowerShell),
            None
        );
        assert_eq!(
            p.forbidden_path_argument_for_shell(".\\git.exe status", ShellDialect::PowerShell),
            None
        );

        let explicit_path_policy = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            workspace_dir: tp_ws(),
            allowed_commands: vec!["/usr/bin/antigravity".into()],
            ..SecurityPolicy::default()
        };
        assert!(
            explicit_path_policy
                .validate_command_execution_for_shell(
                    "/usr/bin/antigravity",
                    true,
                    ShellDialect::PowerShell,
                )
                .is_ok(),
            "an exact executable-path allowlist must retain its existing meaning"
        );
    }

    #[test]
    fn powershell_allowlist_accepts_case_insensitive_exe_suffix() {
        assert!(is_powershell_allowlist_entry_match(
            "git.EXE", "git.exe", "git"
        ));
    }

    #[test]
    fn powershell_allowlist_accepts_windows_relative_path_spelling() {
        assert!(is_powershell_allowlist_entry_match(
            r".\tools\git.exe",
            "./tools/git.exe",
            "git"
        ));
    }

    #[cfg(not(target_os = "windows"))]
    #[test]
    fn powershell_allowlist_path_is_case_sensitive_on_unix() {
        // The explicit path is the trust anchor. On a case-sensitive host,
        // `/tmp/Safe/tool` and `/tmp/safe/tool` can be different executables,
        // so a differently cased request must not inherit the allowlist grant.
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            workspace_dir: tp_ws(),
            allowed_commands: vec!["/tmp/Safe/tool".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };

        // Exact case remains authorized.
        assert!(
            p.validate_command_execution_for_shell(
                "/tmp/Safe/tool",
                true,
                ShellDialect::PowerShell,
            )
            .is_ok(),
            "exact-case explicit path must stay authorized"
        );

        // Differently cased executable must NOT match the trusted entry.
        assert!(
            p.validate_command_execution_for_shell(
                "/tmp/safe/tool",
                true,
                ShellDialect::PowerShell,
            )
            .is_err(),
            "case-distinct executable must not inherit the allowlist grant on a case-sensitive host"
        );

        // The workspace-exemption path (forbidden_path_argument) must apply the
        // same case rule: the differently cased executable is not exempted by
        // the trusted entry, so it is subject to path confinement.
        assert!(
            !is_powershell_allowlist_entry_match("/tmp/Safe/tool", "/tmp/safe/tool", "tool"),
            "path allowlist match must be case-sensitive on Unix"
        );
        assert!(
            is_powershell_allowlist_entry_match("/tmp/Safe/tool", "/tmp/Safe/tool", "tool"),
            "exact-case path allowlist match must still succeed"
        );
    }

    #[test]
    fn forbidden_path_argument_allows_workspace_relative_paths() {
        let p = default_policy();
        assert_eq!(p.forbidden_path_argument("cat src/main.rs"), None);
        assert_eq!(p.forbidden_path_argument("grep -r todo ./src"), None);
    }

    #[test]
    fn forbidden_path_argument_detects_option_assignment_paths() {
        let p = unix_forbidden_path_policy();
        assert_eq!(
            p.forbidden_path_argument("grep --file=/etc/passwd root ./src"),
            Some("/etc/passwd".into())
        );
        assert_eq!(
            p.forbidden_path_argument("cat --input=../secret.txt"),
            Some("../secret.txt".into())
        );
    }

    #[test]
    fn forbidden_path_argument_allows_safe_option_assignment_paths() {
        let p = default_policy();
        assert_eq!(
            p.forbidden_path_argument("grep --file=./patterns.txt root ./src"),
            None
        );
    }

    #[test]
    fn forbidden_path_argument_detects_short_option_attached_paths() {
        let p = unix_forbidden_path_policy();
        assert_eq!(
            p.forbidden_path_argument("grep -f/etc/passwd root ./src"),
            Some("/etc/passwd".into())
        );
        assert_eq!(
            p.forbidden_path_argument("git -C../outside status"),
            Some("../outside".into())
        );
    }

    #[test]
    fn forbidden_path_argument_allows_safe_short_option_attached_paths() {
        let p = default_policy();
        assert_eq!(
            p.forbidden_path_argument("grep -f./patterns.txt root ./src"),
            None
        );
        assert_eq!(p.forbidden_path_argument("git -C./repo status"), None);
    }

    #[test]
    fn forbidden_path_argument_detects_tilde_user_paths() {
        let p = default_policy();
        assert_eq!(
            p.forbidden_path_argument("cat ~root/.ssh/id_rsa"),
            Some("~root/.ssh/id_rsa".into())
        );
        // Bare `~user` with no path component is not a forbidden path argument:
        // narrowed to avoid false-positives on non-path `~`-prefixed tokens
        // (e.g. `~20`). A `~user/...` form with a slash still blocks (above).
        assert_eq!(p.forbidden_path_argument("ls ~nobody"), None);
    }

    #[test]
    fn forbidden_path_argument_ignores_tilde_non_path_and_heredoc_body() {
        let p = unix_forbidden_path_policy();

        // Tilde-then-non-slash tokens are not home paths: `~20`, `~589`, `~foo`.
        assert_eq!(
            p.forbidden_path_argument("echo \"about ~20 percent\""),
            None
        );
        assert_eq!(
            p.forbidden_path_argument("python3 -c \"print('about ~589 lines')\""),
            None
        );
        assert_eq!(
            p.forbidden_path_argument("printf 'roughly ~foo here\\n'"),
            None
        );

        // Heredoc body content is stdin data, never an argv path argument.
        let heredoc =
            "cat <<'EOF' > ./out.txt\nthis line has ~20 percent and /etc/passwd mentioned\nEOF";
        assert_eq!(p.forbidden_path_argument(heredoc), None);

        // Security preserved: real forbidden home/absolute path arguments still block.
        assert_eq!(
            p.forbidden_path_argument("cat ~/.ssh/id_rsa"),
            Some("~/.ssh/id_rsa".into())
        );
        assert_eq!(
            p.forbidden_path_argument("cat ~root/.ssh/id_rsa"),
            Some("~root/.ssh/id_rsa".into())
        );
        assert_eq!(
            p.forbidden_path_argument("cat /etc/shadow"),
            Some("/etc/shadow".into())
        );
        // A forbidden path used as a real argument on the heredoc opener line
        // must still block, even when a heredoc body follows.
        assert_eq!(
            p.forbidden_path_argument("cat /etc/passwd <<'EOF'\nbody ~20\nEOF"),
            Some("/etc/passwd".into())
        );
    }

    #[test]
    fn forbidden_path_argument_blocks_path_after_quoted_heredoc_like_text() {
        let p = unix_forbidden_path_policy();
        // These assertions encode POSIX shell semantics against a Unix
        // policy fixture, so pin the dialect instead of inheriting the
        // host default (WindowsCmd on Windows, where `/dev` devices and
        // heredoc forms classify differently by design).
        let posix =
            |command: &str| p.forbidden_path_argument_for_shell(command, ShellDialect::Posix);

        assert_eq!(
            posix("printf \"<<EOF\nbody\nEOF\" /etc/shadow"),
            Some("/etc/shadow".into())
        );

        // Single-quoted variant of the same shape.
        assert_eq!(
            posix("printf '<<EOF\nbody\nEOF' /etc/passwd"),
            Some("/etc/passwd".into())
        );
    }

    #[test]
    fn forbidden_path_argument_ignores_quoted_redirection_markers() {
        let p = unix_forbidden_path_policy();

        assert_eq!(
            p.forbidden_path_argument("cat 'literal>' --file=/etc/passwd"),
            Some("/etc/passwd".into())
        );
    }

    #[test]
    fn forbidden_path_argument_detects_input_redirection_paths() {
        let p = unix_forbidden_path_policy();
        assert_eq!(
            p.forbidden_path_argument("cat </etc/passwd"),
            Some("/etc/passwd".into())
        );
        assert_eq!(
            p.forbidden_path_argument("cat</etc/passwd"),
            Some("/etc/passwd".into())
        );
    }

    #[test]
    fn forbidden_path_argument_allows_safe_device_redirect_targets() {
        let p = unix_forbidden_path_policy();
        // These assertions encode POSIX shell semantics against a Unix
        // policy fixture, so pin the dialect instead of inheriting the
        // host default (WindowsCmd on Windows, where `/dev` devices and
        // heredoc forms classify differently by design).
        let posix =
            |command: &str| p.forbidden_path_argument_for_shell(command, ShellDialect::Posix);
        assert_eq!(posix("ls missing 2>/dev/null"), None);
        assert_eq!(posix("ls missing 2> /dev/null"), None);
        assert_eq!(posix("echo hi >/dev/stdout"), None);
        assert_eq!(posix("echo hi > /dev/stdout"), None);
        assert_eq!(posix("echo err 1>/dev/stderr"), None);
        assert_eq!(posix("echo err 1> /dev/stderr"), None);
        assert_eq!(posix("cat </dev/zero"), None);
        assert_eq!(posix("cat < /dev/zero"), None);
        // Bare-argument device classification is host-gated BENEATH the
        // dialect: the harmless-device carve-out for a bare `/dev/null`
        // argument exists only on Unix hosts, so pinning Posix does not
        // unify this case. Assert both arms so the split stays visible.
        #[cfg(not(target_os = "windows"))]
        assert_eq!(posix("cat /dev/null"), None);
        #[cfg(target_os = "windows")]
        assert_eq!(posix("cat /dev/null"), Some("/dev/null".into()));
        assert_eq!(posix("cat ./safe.txt>/dev/null"), None);
        assert_eq!(posix("cat> /dev/null"), None);
        assert_eq!(posix("cat ./safe.txt>&2"), None);
    }

    #[test]
    fn forbidden_path_argument_blocks_unsafe_redirect_targets() {
        let p = unix_forbidden_path_policy();
        // These assertions encode POSIX shell semantics against a Unix
        // policy fixture, so pin the dialect instead of inheriting the
        // host default (WindowsCmd on Windows, where `/dev` devices and
        // heredoc forms classify differently by design).
        let posix =
            |command: &str| p.forbidden_path_argument_for_shell(command, ShellDialect::Posix);
        assert_eq!(posix("echo hi >/etc/passwd"), Some("/etc/passwd".into()));
        assert_eq!(posix("echo hi > /etc/passwd"), Some("/etc/passwd".into()));
        assert_eq!(
            posix("echo hi >/dev/stderr.log"),
            Some("/dev/stderr.log".into())
        );
        assert_eq!(
            posix("echo hi > /dev/stderr.log"),
            Some("/dev/stderr.log".into())
        );
        assert_eq!(
            posix("cat </dev/zero/etc/passwd"),
            Some("/dev/zero/etc/passwd".into())
        );
        assert_eq!(
            posix("echo hi >/dev/null/../../etc/passwd"),
            Some("/dev/null/../../etc/passwd".into())
        );
        assert_eq!(
            posix("cat</dev/null /etc/passwd"),
            Some("/etc/passwd".into())
        );
        assert_eq!(
            posix("cat /etc/passwd>/dev/null"),
            Some("/etc/passwd".into())
        );
        assert_eq!(
            posix("cat /etc/passwd> /dev/null"),
            Some("/etc/passwd".into())
        );
        assert_eq!(posix("cat /etc/passwd>&2"), Some("/etc/passwd".into()));
        assert_eq!(
            posix("grep --file=/etc/passwd>/dev/null root"),
            Some("/etc/passwd".into())
        );
    }

    /// POSIX command substitution, process substitution, subshells, and
    /// backticks close with a character that is not whitespace. The scanner
    /// must end the inner command there instead of gluing `)` or `` ` `` onto
    /// the last word, which turned `$(cmd 2>/dev/null)` into a blocked
    /// `/dev/null)` redirect target.
    #[test]
    fn forbidden_path_argument_allows_safe_devices_inside_posix_substitutions() {
        let p = unix_forbidden_path_policy();
        let posix =
            |command: &str| p.forbidden_path_argument_for_shell(command, ShellDialect::Posix);
        for command in [
            "x=$(echo a 2>/dev/null)",
            "x=$(echo a 2>/dev/null); echo \"$x\"",
            "x=\"$(echo a 2>/dev/null)\"",
            "echo \"$(ls 2>/dev/null)\" \"$(ls 2> /dev/null)\"",
            "x=$(echo $(echo a 2>/dev/null) 2>/dev/null)",
            "x=$(cat </dev/null)",
            "x=$(cat</dev/null)",
            "(echo a 2>/dev/null)",
            "(cd sub && ls 2>/dev/null) | wc -l",
            "(echo a) 2>/dev/null",
            "x=`echo a 2>/dev/null`",
            "echo \"`echo a 2>/dev/null`\"",
            "diff <(sort a 2>/dev/null) <(sort b 2>/dev/null)",
            "for b in $(which -a zeroclaw 2>/dev/null); do echo $b; done",
            "find . \\( -name a -o -name b \\) 2>/dev/null",
            "echo $((1 + 2)) 2>/dev/null",
            "grep -E '(a|b)' file 2>/dev/null",
            "echo ')' 2>/dev/null",
            // A command substitution inside arithmetic uses ordinary shell
            // syntax, so its quoted heredoc body is data, not a command.
            "echo \"$(( $(cat <<'EOF' | wc -l\n/etc/passwd\nEOF\n) + 1 ))\"",
            "x=\"$(case a in a) echo a 2>/dev/null;; esac)\"",
            // Heredoc bodies stay data, including with more text after the
            // delimiter and several heredocs on one line.
            "cat <<'EOF' | wc -l\n/etc/passwd\nEOF",
            "cat <<A - <<B\n/etc/passwd\nA\n/etc/shadow\nB",
            "cat <<-EOF\n\t/etc/passwd\n\tEOF",
            "cat <<\"E F\"\n/etc/passwd\nE F",
            // Delimiter quote removal follows the shell: inside double quotes
            // a backslash before an ordinary character stays, before `$`
            // it goes, and a backslash-newline joins the word either way.
            "cat <<\"E\\OF\"\n/etc/passwd\nE\\OF",
            "cat <<\"E\\$F\"\n/etc/passwd\nE$F",
            "cat <<E\\\nOF\n/etc/passwd\nEOF",
            // A trailing backslash joins the next line into the delimiter, so
            // the line after it is body, not a command. Bash warns that it
            // wanted `Ehello` and never runs a command placed after that line.
            "cat <<E\\\n/etc/passwd\nEpasswd",
            // An escaped space or metacharacter is part of the delimiter word.
            "cat <<E\\ OF\n/etc/passwd\nE OF",
            "cat <<$EOF\necho 'https://example.invalid\n$EOF",
            "cat <<\"E\\\" F\"\necho 'https://example.invalid\nE\" F",
            "cat <<E\\;OF\n/etc/passwd\nE;OF",
            // A heredoc opened inside a substitution reads its body there; the
            // outer heredoc's body starts after the line the substitution
            // closes on. A subshell shares the enclosing heredoc queue.
            "cat <<A $(cat <<B\n/etc/passwd\nB\n)\n/etc/shadow\nA",
            "echo \"$(cat <<OUT $(cat <<IN\n/etc/passwd\nIN\n)\n/etc/shadow\nOUT\n)\"",
            "cat <<A && (echo s\n/etc/passwd\nA\necho t)",
        ] {
            assert_eq!(posix(command), None, "{command}");
        }
    }

    /// Splitting at substitution boundaries must expose the inner command to
    /// the scan, never hide it: lookalike devices and forbidden paths inside a
    /// substitution stay blocked and are reported without the closing `)`.
    #[test]
    fn forbidden_path_argument_scans_inside_posix_substitutions() {
        let p = unix_forbidden_path_policy();
        let posix =
            |command: &str| p.forbidden_path_argument_for_shell(command, ShellDialect::Posix);
        for (command, blocked) in [
            ("x=$(echo a 2>/dev/nullx)", "/dev/nullx"),
            (
                "x=$(echo a 2>/dev/null/../../etc/passwd)",
                "/dev/null/../../etc/passwd",
            ),
            ("x=$(cat /etc/passwd)", "/etc/passwd"),
            ("x=$(cat /etc/passwd 2>/dev/null)", "/etc/passwd"),
            // Double quotes do not stop command substitution, so the inner
            // command is scanned too.
            ("x=\"$(cat /etc/passwd)\"", "/etc/passwd"),
            ("echo \"`cat /etc/shadow`\"", "/etc/shadow"),
            ("x=`cat /etc/passwd`", "/etc/passwd"),
            ("(cat /etc/passwd)", "/etc/passwd"),
            ("(echo a) >/etc/passwd", "/etc/passwd"),
            ("diff <(cat /etc/passwd) b", "/etc/passwd"),
            ("x=$(echo $(cat /etc/passwd))", "/etc/passwd"),
            // Unbalanced or `case`-style closers are boundaries, not hiding
            // places.
            ("case x in a) cat /etc/passwd;; esac", "/etc/passwd"),
            ("echo a) cat /etc/passwd", "/etc/passwd"),
            // Arithmetic `<<` is a shift, not a heredoc that swallows the rest.
            ("echo $((8 << 1)); cat /etc/passwd", "/etc/passwd"),
            ("echo $((8<<1))\ncat /etc/passwd\n1", "/etc/passwd"),
            // A `)` that bash does not treat as the substitution's closer must
            // not end it early. Closing early would restore the outer double
            // quote and hide the rest of the command inside one argument.
            (
                "echo \"$(case x in x) cat /etc/passwd;; esac)\"",
                "/etc/passwd",
            ),
            ("echo $(case x in x) cat /etc/passwd;; esac)", "/etc/passwd"),
            (
                "echo \"$(case x in (x) cat /etc/passwd;; esac)\"",
                "/etc/passwd",
            ),
            (
                "echo \"$(case x in a) (cd a) ;; x) cat /etc/passwd;; esac)\"",
                "/etc/passwd",
            ),
            (
                "echo \"$(if true; then case x in x) cat /etc/passwd;; esac; fi)\"",
                "/etc/passwd",
            ),
            (
                "echo \"`case x in x) cat /etc/passwd;; esac`\"",
                "/etc/passwd",
            ),
            ("echo \"$(echo ${x/)/y}; cat /etc/passwd)\"", "/etc/passwd"),
            ("echo \"${x:-$(cat /etc/passwd)}\"", "/etc/passwd"),
            (
                "echo \"$(echo a # comment )\ncat /etc/passwd\n)\"",
                "/etc/passwd",
            ),
            // The heredoc delimiter is one word; the rest of its line and every
            // command after the terminator are still scanned.
            (
                "echo \"$(( $(cat <<'EOF' | wc -l\nhello\nEOF\n) + 1 ))\"; cat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<'EOF' | wc -l\nhello\nEOF\ncat /etc/passwd",
                "/etc/passwd",
            ),
            ("cat <<EOF >out\nhello\nEOF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<'EOF' /etc/passwd\nhello\nEOF", "/etc/passwd"),
            (
                "cat <<A - <<B\none\nA\ntwo\nB\ncat /etc/passwd",
                "/etc/passwd",
            ),
            ("cat <<-EOF\n\thello\n\tEOF\ncat /etc/passwd", "/etc/passwd"),
            // A delimiter that is not a plain word opens no heredoc.
            ("cat <<$(echo E)\nE\ncat /etc/passwd", "/etc/passwd"),
            // A backslash does not continue a comment past its newline.
            ("cat \"$(echo ok # \\\n)\" /etc/passwd", "/etc/passwd"),
            ("echo ok # \\\ncat /etc/passwd", "/etc/passwd"),
            // Inside double quotes a backslash before an ordinary character is
            // part of the delimiter, so the body ends at `E\OF`, not `EOF`.
            (
                "cat <<\"E\\OF\"\nhello\nE\\OF\ncat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<\"E\\$F\"\nhello\nE$F\ncat /etc/passwd",
                "/etc/passwd",
            ),
            // A backslash-newline inside the delimiter joins it into one word.
            ("cat <<E\\\nOF\nhello\nEOF\ncat /etc/passwd", "/etc/passwd"),
            // An escaped space or metacharacter stays inside the delimiter.
            // Stopping at it made a terminator that never matches, so the
            // trailing command was skipped as body.
            ("cat <<E\\ OF\nhello\nE OF\ncat /etc/passwd", "/etc/passwd"),
            (
                "cat <<E\\ \\ OF\nhello\nE  OF\ncat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<E\\\tOF\nhello\nE\tOF\ncat /etc/passwd",
                "/etc/passwd",
            ),
            ("cat <<E\\;OF\nhello\nE;OF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<E\\|OF\nhello\nE|OF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<E\\&OF\nhello\nE&OF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<E\\<OF\nhello\nE<OF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<E\\>OF\nhello\nE>OF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<E\\(OF\nhello\nE(OF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<E\\)OF\nhello\nE)OF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<E\\#OF\nhello\nE#OF\ncat /etc/passwd", "/etc/passwd"),
            (
                "cat <<E\\\"OF\nhello\nE\"OF\ncat /etc/passwd",
                "/etc/passwd",
            ),
            ("cat <<E\\'OF\nhello\nE'OF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<E\\$OF\nhello\nE$OF\ncat /etc/passwd", "/etc/passwd"),
            ("cat <<E\\`OF\nhello\nE`OF\ncat /etc/passwd", "/etc/passwd"),
            (
                "cat <<E\\\\OF\nhello\nE\\OF\ncat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<E\\\\\\ OF\nhello\nE\\ OF\ncat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<\"E\\\nOF\"\nhello\nEOF\ncat /etc/passwd",
                "/etc/passwd",
            ),
            // Each command substitution has its own heredoc queue, so an inner
            // newline starts only the inner heredoc. A shared queue started the
            // outer one first and skipped the trailing command.
            (
                "echo \"$(cat <<OUT $(cat <<IN\n\nIN\n)\nouter\nOUT\n)\"; cat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<A $(cat <<B\nb\nB\n)\na\nA\ncat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<A `cat <<B\nb\nB\n`\na\nA\ncat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<A <(cat <<B\nb\nB\n)\na\nA\ncat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<A - $(cat <<B\nb\nB\n) <<C\na\nA\nc\nC\ncat /etc/passwd",
                "/etc/passwd",
            ),
            ("cat <<A $(echo x\n)\na\nA\ncat /etc/passwd", "/etc/passwd"),
            // A subshell is not a substitution: its newline starts the
            // enclosing heredoc, so the body ends inside the subshell.
            (
                "cat <<A && (echo s\na\nA\necho t)\ncat /etc/passwd",
                "/etc/passwd",
            ),
            ("cat <<A && (echo s\na\nA\ncat /etc/passwd)", "/etc/passwd"),
            // An inner heredoc whose substitution closes before a newline has
            // no body inside it and is dropped, so the lines after are scanned.
            ("echo \"$(cat <<B)\"\ncat /etc/passwd\nB", "/etc/passwd"),
            // An expansion the scanner cannot model (`$(...)`) opens no
            // heredoc, so the following lines stay scanned.
            // A bare `$` in a delimiter is literal. Opening no heredoc let the
            // quote in the body swallow the trailing read.
            (
                "cat <<$EOF\necho 'https://example.invalid\n$EOF\ncat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "cat <<E$HOME\necho 'https://example.invalid\nE$HOME\ncat /etc/passwd",
                "/etc/passwd",
            ),
            // `$"..."` depends on the locale catalog, so its terminator cannot
            // be proven. The body is still data through the end of the command.
            // Parsing it lets the quote swallow the following path.
            // `\"` inside a double-quoted delimiter is part of the word.
            (
                "echo \"$(cat <<\"E\\\" F\"\nhello\nE\" F\n)\"; cat /etc/passwd",
                "/etc/passwd",
            ),
            // `<<''` ends at the next completely blank line. A quote in that
            // body is data, so it cannot swallow the command after the blank.
            (
                "cat <<''\necho 'https://example.invalid\n\ncat /etc/passwd",
                "/etc/passwd",
            ),
            // `<<-` strips leading tabs before comparing the terminator. A
            // tab-only line ends `<<-''`; leaving the tab in the comparison
            // never matches and hides the following command.
            (
                "cat <<-''\necho 'https://example.invalid\n\t\ncat /etc/passwd",
                "/etc/passwd",
            ),
            (
                "echo \"$(cat <<$\"EOF\"\necho 'https://example.invalid\nEOF\n)\"; cat /etc/passwd",
                "unreadable heredoc delimiter",
            ),
            // At top level the unproven body has no frame to close it. The
            // opener line stays data, and the lines after it are scanned
            // without treating a quote in the body as syntax.
            (
                "cat <<$\"EOF\"\necho 'https://example.invalid\nEOF\ncat /etc/passwd",
                "unreadable heredoc delimiter",
            ),
            // A leading backslash is quote removal, so the terminator is
            // `EOF`, not `\EOF`.
            ("cat <<\\EOF\nhello\nEOF\ncat /etc/passwd", "/etc/passwd"),
            (
                "cat <<$(echo EOF)\nhello\nEOF\ncat /etc/passwd",
                "/etc/passwd",
            ),
        ] {
            assert_eq!(posix(command), Some(blocked.into()), "{command}");
        }
    }

    /// `cmd.exe` has no `$(...)` or backtick substitution, so those characters
    /// stay ordinary word characters under the Windows command dialect.
    #[test]
    fn windows_cmd_does_not_split_posix_substitution_syntax() {
        assert_eq!(
            split_unquoted_segments("echo `a` $(b)", ShellDialect::WindowsCmd),
            vec!["echo `a` $(b)".to_string()]
        );
    }

    #[test]
    fn posix_segments_split_at_substitution_boundaries() {
        let split = |command: &str| split_unquoted_segments(command, ShellDialect::Posix);
        // Segments are returned in the order they end: inner commands first.
        assert_eq!(split("x=$(echo a)"), vec!["echo a", "x=$()"]);
        assert_eq!(split("x=\"$(echo a)\""), vec!["echo a", "x=\"$()\""]);
        assert_eq!(split("x=`echo a`"), vec!["echo a", "x=``"]);
        assert_eq!(split("(echo a) && b"), vec!["echo a", "b"]);
        assert_eq!(split("diff <(a) >(b)"), vec!["a", "b", "diff <() >()"]);
        assert_eq!(split("x=$(a $(b) c) d"), vec!["b", "a $() c", "x=$() d"]);
        assert_eq!(split("x=$(a; b)"), vec!["a", "b", "x=$()"]);
        // Confirmed `$((...))` arithmetic runs no command, so its text is not
        // a segment, and its `<<` is a shift rather than a heredoc.
        assert_eq!(split("echo $((1 << 2))"), vec!["echo $()"]);
        assert_eq!(split("echo $(( (a + b) / 2 ))"), vec!["echo $()"]);
        // Without `))` right after the second `(`'s match, bash runs a
        // subshell, so the text is scanned as commands.
        assert_eq!(split("x=$((echo a) )"), vec!["echo a", "x=$()"]);
        assert_eq!(split("x=$((a)+(b))"), vec!["a", "+", "b", "x=$()"]);
        // A bare `((` is scanned as commands: dash runs it as subshells.
        assert_eq!(split("((echo a))"), vec!["echo a"]);
        // Unbalanced input keeps every word: an unterminated substitution
        // still flushes the command around it, and a stray `)` is a boundary.
        // Because the model diverged from the shell's, the flat split that
        // ignores substitutions is checked as well.
        assert_eq!(
            split("cat a $(echo b"),
            vec!["echo b", "cat a $()", "cat a $(echo b"]
        );
        assert_eq!(
            split("cat a `echo b"),
            vec!["echo b", "cat a ``", "cat a `echo b"]
        );
        assert_eq!(split("echo a) b"), vec!["echo a", "b", "echo a) b"]);
        // A balanced command gets no flat split, including a trailing `esac`
        // and an empty `case`.
        assert_eq!(
            split("case x in x) a;; esac"),
            vec!["case x in x", "a", "esac"]
        );
        assert_eq!(
            split("x=$(case x in esac)"),
            vec!["case x in esac", "x=$()"]
        );
        // Quoted and escaped parentheses and backticks are literal.
        assert_eq!(split("echo '$(a)' '`b`'"), vec!["echo '$(a)' '`b`'"]);
        assert_eq!(
            split("echo \\$\\(a\\) \\`b\\`"),
            vec!["echo \\$\\(a\\) \\`b\\`"]
        );
        assert_eq!(split("echo \"(a)\""), vec!["echo \"(a)\""]);
        // A quote inside a substitution does not leak into the outer word.
        assert_eq!(
            split("x=\"$(echo \")\")\""),
            vec!["echo \")\"", "x=\"$()\""]
        );
        // `case` pattern terminators end a segment inside the substitution
        // without closing it; `esac` lets the next `)` close it again.
        assert_eq!(
            split("x=\"$(case a in a) b;; esac)\""),
            vec!["case a in a", "b", "esac", "x=\"$()\""]
        );
        // Inside `${...}`, `(` and `)` are literal, but `$(` still nests.
        assert_eq!(split("x=$(echo ${y/)/z})"), vec!["echo ${y/)/z}", "x=$()"]);
        assert_eq!(
            split("echo \"${y:-$(b)}\""),
            vec!["b", "echo \"${y:-$()}\""]
        );
        // A comment's `)` does not close the substitution, and the comment
        // ends at the newline. Mid-word `#` and `${#x}` are not comments.
        assert_eq!(split("x=$(a # c )\nb\n)"), vec!["a # c )", "b", "x=$()"]);
        assert_eq!(split("x=$(a#b) ${#y}"), vec!["a#b", "x=$() ${#y}"]);
        // A command substitution inside arithmetic recognizes heredocs again.
        assert_eq!(
            split("echo $(( $(cat <<'E'\n)\nE\n) + 1 ))"),
            vec!["cat <<'E'", "echo $()"]
        );
        // The heredoc delimiter is one word, and the body starts at the next
        // newline, so the rest of the line is its own segment.
        assert_eq!(
            split("cat <<'E' | wc -l\nbody\nE\nnext"),
            vec!["cat <<'E'", "wc -l", "next"]
        );
        // An inner heredoc's body is read inside its substitution, and the
        // outer heredoc's body starts after the line the substitution closes on.
        assert_eq!(
            split("cat <<A $(cat <<B\nb\nB\n)\na\nA\nnext"),
            vec!["cat <<B", "cat <<A $()", "next"]
        );
        // A comment ends at its newline even after a trailing backslash.
        assert_eq!(
            split("x=\"$(a # c \\\n)\" b"),
            vec!["a # c \\", "x=\"$()\" b"]
        );
        // An escaped space is part of the delimiter, not the end of the word.
        assert_eq!(
            split("cat <<E\\ OF | wc -l\nbody\nE OF\nnext"),
            vec!["cat <<E\\ OF", "wc -l", "next"]
        );
        // `$"..."` is locale-dependent, so the split refuses rather than
        // guessing which of the following lines are commands.
        assert!(
            split_unquoted_segments_checked("cat <<$\"EOF\"\nbody\nEOF\nnext", ShellDialect::Posix)
                .is_err()
        );
    }

    /// Commands inside substitutions and subshells carry their own risk.
    #[test]
    fn command_risk_level_sees_commands_inside_posix_substitutions() {
        let p = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        for command in [
            "x=$(rm -rf ./build)",
            "x=\"$(rm -rf ./build)\"",
            "x=`rm -rf ./build`",
            "echo \"`rm -rf ./build`\"",
            "(rm -rf ./build)",
            "echo ok && (cd sub; rm -rf ./build)",
            "diff <(rm -rf ./build) b",
            "echo \"$(case x in x) rm -rf ./build;; esac)\"",
            "echo $(case x in x) rm -rf ./build;; esac)",
            "echo \"$(echo ${x/)/y}; rm -rf ./build)\"",
            "echo \"$(echo a # )\nrm -rf ./build\n)\"",
            // An apostrophe in a comment is not a quote, so it cannot swallow
            // the next line's command.
            "ls # don't\nrm -rf ./build",
            "ls # don't; rm -rf ./build",
            "echo \"$(( $(cat <<'EOF' | wc -l\nhello\nEOF\n) + 1 ))\"; rm -rf ./build",
            "cat <<'EOF' | wc -l\nhello\nEOF\nrm -rf ./build",
            "echo ok # \\\nrm -rf ./build",
            "cat <<\"E\\OF\"\nhello\nE\\OF\nrm -rf ./build",
            "cat <<E\\\nOF\nhello\nEOF\nrm -rf ./build",
            "cat <<E\\ OF\nhello\nE OF\nrm -rf ./build",
            "cat <<E\\;OF\nhello\nE;OF\nrm -rf ./build",
            "cat <<E\\|OF\nhello\nE|OF\nrm -rf ./build",
            "cat <<E\\(OF\nhello\nE(OF\nrm -rf ./build",
            "echo \"$(cat <<OUT $(cat <<IN\n\nIN\n)\nouter\nOUT\n)\"; rm -rf ./build",
            "cat <<A && (echo s\na\nA\necho t)\nrm -rf ./build",
            "echo \"$(cat <<$'EOF'\nhello\nEOF\n)\"; rm -rf ./build",
            "cat <<$'E\\x4fF'\nhello\nEOF\nrm -rf ./build",
            "cat <<$'E\\101F'\nhello\nEAF\nrm -rf ./build",
            concat!("cat <<$'E", r"\077", "F'\nhello\nE?F\nrm -rf ./build"),
            concat!("cat <<$'E", r"\501", "F'\nhello\nEAF\nrm -rf ./build"),
            "cat <<$EOF\necho 'https://example.invalid\n$EOF\nrm -rf ./build",
            concat!(
                "echo \"$(cat <<$'E",
                r"\0",
                "F'\nhello\nE\n)\"; rm -rf ./build"
            ),
            concat!(
                "echo \"$(cat <<$'E",
                r"\0",
                "F'X\nhello\nEX\n)\"; rm -rf ./build"
            ),
            // `$"..."` is not a proven delimiter, so its body is scanned too.
            "echo \"$(cat <<\"E\\\" F\"\nhello\nE\" F\n)\"; rm -rf ./build",
            "cat <<''\necho 'https://example.invalid\n\nrm -rf ./build",
            "cat <<-''\necho 'https://example.invalid\n\t\nrm -rf ./build",
            "echo \"$(cat <<$\"EOF\"\necho 'https://example.invalid\nEOF\n)\"; rm -rf ./build",
            "cat <<$\"EOF\"\necho 'https://example.invalid\nEOF\nrm -rf ./build",
            "cat <<$'E\\rF'\necho 'https://example.invalid\nE\rF\nrm -rf ./build",
            "cat <<\\EOF\nhello\nEOF\nrm -rf ./build",
            "cat <<$'E\\ OF'\nhello\nE\\ OF\nrm -rf ./build",
        ] {
            assert_eq!(
                p.command_risk_level(command),
                CommandRiskLevel::High,
                "{command}"
            );
        }
        assert_eq!(
            p.command_risk_level("x=$(git rev-parse HEAD 2>/dev/null)"),
            CommandRiskLevel::Low
        );
    }

    /// Where the scanner and the shell disagree on which `)` or backtick ends
    /// a substitution, the scan restores the enclosing double quote over text
    /// the shell runs. In each command here, bash runs the forbidden command
    /// (dash runs it too, or rejects the whole script).
    #[test]
    fn posix_substitution_closers_follow_the_shell() {
        let p = unix_forbidden_path_policy();
        let posix =
            |command: &str| p.forbidden_path_argument_for_shell(command, ShellDialect::Posix);
        let risk = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        for command in [
            // A lone `&`, `coproc`, and `time -p` leave the next word in
            // command position, so its `case` pattern `)` does not close.
            "echo \"$(echo \"$(true & case x in x) wc -l /etc/passwd;; esac)\")\"",
            "echo \"$(true&case x in x) wc -l /etc/passwd;; esac)\"",
            "echo \"$(coproc case x in x) wc -l /etc/passwd;; esac)\"",
            "echo \"$(time -p case x in x) wc -l /etc/passwd;; esac)\"",
            // An empty `case` is closed by its `esac`, so the next `)` closes
            // the substitution.
            "echo \"$(case x in esac)\"; wc -l /etc/passwd",
            // `case` inside arithmetic is a name, not a statement, so it does
            // not hold the real closer open.
            "echo \"$($((case x in (x) echo a)))\"; wc -l /etc/passwd",
            // The next unescaped backtick closes a backtick substitution, even
            // inside a comment, a quote, or a `(` opened within it.
            "echo \"`#x`\"\necho `wc -l /etc/passwd`",
            "echo `echo 'a`; wc -l /etc/passwd #'`",
            "x=\"`x=1 (case x in x) echo a)`\"; wc -l /etc/passwd",
            // A heredoc opened inside backticks ends with them.
            "echo `cat <<EOF`\nwc -l /etc/passwd\nEOF",
            // Dash runs `((...))` as nested subshells, not arithmetic.
            "((wc -l /etc/passwd))",
        ] {
            assert_eq!(posix(command), Some("/etc/passwd".into()), "{command}");
            let high = command.replace("wc -l /etc/passwd", "rm -rf ./build");
            assert_eq!(
                risk.command_risk_level(&high),
                CommandRiskLevel::High,
                "{high}"
            );
        }
        // An unterminated `case` in backticks: the shell reports the error
        // when it runs the substitution, then runs the rest.
        assert_eq!(
            risk.command_risk_level("x=\"`x=1 (case x in x) git status)`\"; rm -rf ./build"),
            CommandRiskLevel::High
        );
        // Balanced, valid commands are not refused by the closer rules.
        for command in [
            "case x in esac",
            "x=$(case x in esac)",
            "case x in x) echo a;; esac",
            "echo \"`echo a`\" `date`",
            "true & case x in x) echo a;; esac",
        ] {
            assert_eq!(posix(command), None, "{command}");
            assert!(risk.is_command_allowed(command), "{command}");
        }
    }

    /// `$((...))` whose second `(` closes right before `)` is arithmetic in
    /// both bash and dash, so its text names no file and runs no command.
    /// Substitutions inside it still run and are still scanned. Any other
    /// `$((` or a bare `((` is scanned as commands.
    #[test]
    fn posix_confirmed_arithmetic_is_not_a_command() {
        let p = unix_forbidden_path_policy();
        let posix =
            |command: &str| p.forbidden_path_argument_for_shell(command, ShellDialect::Posix);
        for command in [
            "echo \"$(( total / count ))\"",
            "echo $((10 / 2))",
            "echo $(( (a + b) / 2 ))",
            "x=$(( $(wc -l < input.txt) / 2 ))",
            // Separators inside the expression do not end a command there.
            "echo \"$(( total /\n count ))\"",
            "echo $(( a / 2 || b / 2 ))",
            "echo $(( a / 2 && b / 2 ))",
        ] {
            assert_eq!(posix(command), None, "{command}");
            assert_eq!(
                p.command_risk_level(command),
                CommandRiskLevel::Low,
                "{command}"
            );
        }
        for command in [
            "echo $(( $(wc -l < /etc/passwd) / 2 ))",
            "echo \"$(( `wc -l < /etc/passwd` / 2 ))\"",
            // Bash reads these as command substitutions holding a subshell.
            "x=$((cat /etc/passwd) )",
            "x=$((true) ; cat /etc/passwd)",
            "x=\"$((true)|cat /etc/passwd)\"",
            "((cat /etc/passwd))",
            // Unconfirmed text keeps every separated command.
            "x=$((true) ; cat /etc/passwd\n)",
            "x=$((true) && cat /etc/passwd)",
        ] {
            assert_eq!(posix(command), Some("/etc/passwd".into()), "{command}");
        }
    }

    /// Heredoc forms whose body boundary differs between shells, or that
    /// neither split can bound, are refused rather than guessed.
    #[test]
    fn ambiguous_heredoc_boundaries_are_refused() {
        let p = unix_forbidden_path_policy();
        let risk = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        for command in [
            // Bash ends a body inside `$(` at `EOF)`, then runs the rest.
            "x=$(cat <<EOF\nhello\nEOF); wc -l /etc/passwd",
            "echo \"$(cat <<EOF\nhello\nEOF)\"; wc -l /etc/passwd",
            // Bash shifts inside `((`, so the next line runs. Dash reads a
            // subshell with a heredoc whose body is that line.
            "((x=8<<1))\nwc -l /etc/passwd\n1",
            "(( x = 8 << 1 ))\nwc -l /etc/passwd",
        ] {
            assert_eq!(
                p.forbidden_path_argument_for_shell(command, ShellDialect::Posix),
                Some("unreadable heredoc delimiter".into()),
                "{command}"
            );
            let high = command.replace("wc -l /etc/passwd", "rm -rf ./build");
            assert_eq!(
                risk.command_risk_level(&high),
                CommandRiskLevel::High,
                "{high}"
            );
            assert!(!risk.is_command_allowed(command), "{command}");
        }
        // A heredoc in a spaced subshell means the same to both shells.
        assert_eq!(
            p.forbidden_path_argument_for_shell(
                "( (cat <<EOF\nhello\nEOF\n) )\nwc -l /etc/passwd",
                ShellDialect::Posix
            ),
            Some("/etc/passwd".into())
        );
    }

    /// `$'...'` heredoc delimiters mean different things to bash and dash, the
    /// usual `sh`. Bash expands them (bytewise, with NUL truncation) before
    /// matching the terminator. Dash has no `$'...'` and ends `<<$'EOF'` at a
    /// literal `$EOF` line. Either model hides commands from the other shell,
    /// so the delimiter is unproven and the command is refused.
    #[test]
    fn ansi_c_heredoc_delimiters_are_refused() {
        let p = unix_forbidden_path_policy();
        let risk = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        for command in [
            // Dash ends the body at `$EOF` and runs the next line.
            "cat <<$'EOF'\nx\n$EOF\nwc -l /etc/passwd\nEOF",
            // Bash ends at `X` (the NUL truncates the quoted part, escaped
            // quote included), not `BX`.
            concat!(
                "echo \"$(cat <<$'",
                r"\0A\'B",
                "'X\nhello\nX\nwc -l /etc/passwd\nBX\n)\"\n)\""
            ),
            // Bash builds bytes, so this ends at `EéF`, not `EÃ©F`.
            concat!(
                "echo \"$(cat <<$'E",
                r"\xc3\xa9",
                "F'\nhello\nEéF\nwc -l /etc/passwd\nEÃ©F\n)\"\n)\""
            ),
            "cat <<$'E\\101F'\nhello\nEAF\nwc -l /etc/passwd",
            "cat <<E$'O'F\nhello\nEOF\nwc -l /etc/passwd",
        ] {
            assert_eq!(
                p.forbidden_path_argument_for_shell(command, ShellDialect::Posix),
                Some("unreadable heredoc delimiter".into()),
                "{command}"
            );
            let high = command.replace("wc -l /etc/passwd", "rm -rf ./build");
            assert_eq!(
                risk.command_risk_level(&high),
                CommandRiskLevel::High,
                "{high}"
            );
            assert!(!risk.is_command_allowed(command), "{command}");
        }
    }

    fn bash_grammar() -> ShellGrammar {
        ShellGrammar {
            dialect: ShellDialect::Posix,
            posix_shell: PosixShell::Bash,
        }
    }

    /// When the shell is known to be bash, the forms POSIX shells disagree on
    /// are read the way bash 3.2 through 5.3 read them, in normal and POSIX
    /// mode, instead of being refused.
    #[test]
    fn bash_grammar_expands_ansi_c_heredoc_delimiters_bytewise() {
        let p = unix_forbidden_path_policy();
        let bash = |command: &str| p.forbidden_path_argument_impl(command, bash_grammar(), false);
        // (delimiter word, the terminator line bash matches)
        for (word, terminator) in [
            ("$'EOF'", "EOF"),
            ("$'E\\x41F'", "EAF"),
            ("$'E\\x4g'", "E\u{4}g"),
            ("$'E\\xg'", "E\\xg"),
            ("$'E\\101F'", "EAF"),
            ("$'E\\0101'", "E\u{8}1"),
            ("$'E\\tF'", "E\tF"),
            ("$'E\\rF'", "E\rF"),
            ("$'E\\'F'", "E'F"),
            ("$'E\\qF'", "E\\qF"),
            ("$'E\\xc3\\xa9F'", "EéF"),
            ("E$'O'F", "EOF"),
            // A NUL ends the quoted part; escapes still apply while skipping
            // the rest of it, and text after the quote stays.
            ("$'E\\0F'X", "EX"),
            ("$'E\\400F'", "E"),
            ("$'E\\x00Q'", "E"),
            ("$'\\0A\\'B'X", "X"),
        ] {
            // The body is data, including a lookalike of dash's terminator.
            let body = format!("cat <<{word}\n/etc/passwd\n$EOF\n{terminator}");
            assert_eq!(bash(&body), None, "{body:?}");
            // The command after the terminator runs and is scanned.
            let after = format!("cat <<{word}\nhello\n{terminator}\nwc -l /etc/passwd");
            assert_eq!(bash(&after), Some("/etc/passwd".into()), "{after:?}");
        }
        // `\777` is the byte 0xff, which no UTF-8 line contains, so bash never
        // matches the terminator and the body runs to the end.
        assert_eq!(bash("cat <<$'E\\777F'\n/etc/passwd\nE\u{ff}F"), None);
        // Inside a substitution the quoted command after the real terminator
        // is scanned (Greptile's `\0A\'B'X` case).
        assert_eq!(
            bash("echo \"$(cat <<$'\\0A\\'B'X\nhello\nX\nwc -l /etc/passwd\nBX\n)\"\n)\""),
            Some("/etc/passwd".into())
        );
        // Escapes whose meaning varies across bash versions, `$"..."`, and a
        // newline in the delimiter stay refused.
        for word in [
            "$'E\\cAF'",
            "$'E\\c?F'",
            "$'E\\u00e9F'",
            "$'E\\U0001F600F'",
            "$'E\\nF'",
            "$'E\\\nF'",
            "$\"EOF\"",
            "$'EOF",
        ] {
            let command = format!("cat <<{word}\nhello\nEOF\nwc -l /etc/passwd");
            assert_eq!(
                bash(&command),
                Some("unreadable heredoc delimiter".into()),
                "{command:?}"
            );
        }
        // The portable grammar still refuses every `$'...'` delimiter.
        assert_eq!(
            p.forbidden_path_argument_for_shell(
                "cat <<$'EOF'\nhello\nEOF\nwc -l /etc/passwd",
                ShellDialect::Posix
            ),
            Some("unreadable heredoc delimiter".into())
        );
    }

    /// Bash reads a bare `((...))` as arithmetic when the second `(` closes
    /// with `)` right after it, and as nested subshells otherwise.
    #[test]
    fn bash_grammar_reads_bare_double_parentheses_as_arithmetic() {
        let p = unix_forbidden_path_policy();
        let bash = |command: &str| p.forbidden_path_argument_impl(command, bash_grammar(), false);
        let risk = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        for command in [
            "(( x = 10 / 2 ))",
            "((y = x / 2)); echo \"$y\"",
            "(( (a + b) / 2 ))",
            // Arithmetic: bash reports an expression error and runs nothing.
            "((cat /etc/passwd))",
        ] {
            assert_eq!(bash(command), None, "{command}");
            assert_eq!(
                risk.command_risk_level_for_grammar(command, bash_grammar()),
                CommandRiskLevel::Low,
                "{command}"
            );
        }
        for command in [
            // `<<` is a shift, so the next line runs.
            "((x=8<<1))\nwc -l /etc/passwd\n1",
            "(( x = 8 << 1 ))\nwc -l /etc/passwd",
            // Without `))` after the second `(`'s match, these are subshells.
            "((cat /etc/passwd) )",
            "((true) ; cat /etc/passwd)",
            "(( $(wc -l < /etc/passwd) / 2 ))",
        ] {
            assert_eq!(bash(command), Some("/etc/passwd".into()), "{command}");
        }
        // The portable grammar refuses the shift and scans `((cmd))`, which
        // dash runs as subshells.
        assert_eq!(
            p.forbidden_path_argument_for_shell(
                "((x=8<<1))\nwc -l /etc/passwd\n1",
                ShellDialect::Posix
            ),
            Some("unreadable heredoc delimiter".into())
        );
        assert_eq!(
            p.forbidden_path_argument_for_shell("((cat /etc/passwd))", ShellDialect::Posix),
            Some("/etc/passwd".into())
        );
        // The `EOF)` terminator inside a quoted substitution varies across
        // bash versions, so it stays refused even for bash.
        assert_eq!(
            bash("echo \"$(cat <<EOF\nhello\nEOF)\"; wc -l /etc/passwd"),
            Some("unreadable heredoc delimiter".into())
        );
    }

    /// The host's canonical bash, or `None` where there is none to test with.
    #[cfg(unix)]
    fn host_bash() -> Option<PathBuf> {
        let bash = crate::platform::resolve_executable(std::ffi::OsStr::new("bash")).ok()?;
        std::fs::canonicalize(bash).ok()
    }

    /// A canonical POSIX shell on this host that is not bash, to link a fake
    /// `bash` name to.
    #[cfg(unix)]
    fn host_shell_other_than_bash() -> Option<PathBuf> {
        ["/bin/sh", "dash", "zsh", "ksh"]
            .into_iter()
            .find_map(|shell| {
                let resolved =
                    crate::platform::resolve_executable(std::ffi::OsStr::new(shell)).ok()?;
                let canonical = std::fs::canonicalize(resolved).ok()?;
                (canonical.file_name() != Some(std::ffi::OsStr::new("bash"))).then_some(canonical)
            })
    }

    /// A `PATH` holding one directory with `bash` linked to `target`.
    #[cfg(unix)]
    fn path_with_bash_linked_to(dir: &Path, target: &Path) -> std::ffi::OsString {
        let bin = dir.join(format!(
            "bin-{}",
            target.file_name().unwrap().to_string_lossy()
        ));
        std::fs::create_dir_all(&bin).unwrap();
        std::os::unix::fs::symlink(target, bin.join("bash")).unwrap();
        bin.into_os_string()
    }

    /// The shell is identified from the canonical executable the program
    /// resolves to on the `PATH` it will run with, never from its name
    /// alone: `sh` linked to bash is bash, and a `bash` link to another shell
    /// is not. A container sandbox, or a runtime that reports no program,
    /// keeps the portable grammar.
    #[cfg(unix)]
    #[test]
    fn resolve_posix_shell_follows_the_canonical_executable() {
        let Some(bash) = host_bash() else {
            eprintln!("skipping: no bash on this host");
            return;
        };
        let dir = tempfile::tempdir().unwrap();
        let resolve = |program: &str, path: Option<&std::ffi::OsStr>, container: bool| {
            resolve_posix_shell(Some(std::ffi::OsStr::new(program)), path, container)
        };
        let bash_str = bash.to_str().unwrap();
        assert_eq!(resolve(bash_str, None, false), PosixShell::Bash);
        // A container sandbox runs the configured path inside its image,
        // where it can be any shell.
        assert_eq!(resolve(bash_str, None, true), PosixShell::Unknown);
        assert_eq!(resolve_posix_shell(None, None, false), PosixShell::Unknown);
        assert_eq!(resolve("/no/such/bash", None, false), PosixShell::Unknown);

        let sh = dir.path().join("sh");
        std::os::unix::fs::symlink(&bash, &sh).unwrap();
        assert_eq!(resolve(sh.to_str().unwrap(), None, false), PosixShell::Bash);
        assert_eq!(
            resolve(sh.to_str().unwrap(), None, true),
            PosixShell::Unknown
        );

        // A bare name is resolved on the `PATH` the command runs with.
        let real = path_with_bash_linked_to(dir.path(), &bash);
        assert_eq!(resolve("bash", Some(&real), false), PosixShell::Bash);
        assert_eq!(resolve("bash", Some(&real), true), PosixShell::Unknown);
        let Some(other) = host_shell_other_than_bash() else {
            eprintln!("skipping the spoof cases: no POSIX shell other than bash");
            return;
        };
        let spoofed = path_with_bash_linked_to(dir.path(), &other);
        assert_eq!(resolve("bash", Some(&spoofed), false), PosixShell::Unknown);
        let fake_bash = std::path::PathBuf::from(&spoofed).join("bash");
        assert_eq!(
            resolve(fake_bash.to_str().unwrap(), None, false),
            PosixShell::Unknown
        );
    }

    #[test]
    fn container_sandbox_is_possible_only_for_auto_and_docker_backends() {
        let policy = |enabled: Option<bool>, backend: Option<&str>| SecurityPolicy {
            sandbox_enabled: enabled,
            sandbox_backend: backend.map(str::to_string),
            ..SecurityPolicy::default()
        };
        for (enabled, backend) in [
            (None, None),
            (None, Some("auto")),
            (None, Some("")),
            (None, Some("docker")),
            (Some(true), Some("Docker")),
        ] {
            assert!(
                policy(enabled, backend).container_sandbox_possible(),
                "{enabled:?} {backend:?}"
            );
        }
        for (enabled, backend) in [
            (Some(false), None),
            (Some(false), Some("docker")),
            (None, Some("none")),
            (None, Some("landlock")),
            (None, Some("firejail")),
            (None, Some("bubblewrap")),
            (None, Some("sandbox-exec")),
        ] {
            assert!(
                !policy(enabled, backend).container_sandbox_possible(),
                "{enabled:?} {backend:?}"
            );
        }
    }

    /// A policy with its sandbox off, so the host program runs.
    fn unsandboxed_wildcard_policy() -> SecurityPolicy {
        SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            sandbox_enabled: Some(false),
            ..SecurityPolicy::default()
        }
    }

    /// Through the public checks: a command bound for bash is read in bash's
    /// grammar, so a bash `$'...'` heredoc is accepted, and the dialect-only
    /// checks, which know no program, refuse it.
    #[cfg(unix)]
    #[test]
    fn policy_reads_commands_in_the_targets_grammar() {
        let Some(bash) = host_bash() else {
            eprintln!("skipping: no bash on this host");
            return;
        };
        let command = "cat <<$'EOF'\nhello\nEOF";
        let policy = unsandboxed_wildcard_policy();
        let shell = policy.command_shell(ShellTarget {
            dialect: ShellDialect::Posix,
            program: Some(bash.as_os_str()),
            effective_path: None,
        });
        assert_eq!(
            policy.validate_command_execution_in(command, false, shell),
            Ok(CommandRiskLevel::Low)
        );
        assert_eq!(policy.forbidden_path_argument_in(command, shell), None);
        assert_eq!(
            policy.forbidden_workspace_path_argument_in(command, shell),
            None
        );
        assert!(
            policy
                .validate_command_execution_for_shell(command, false, ShellDialect::Posix)
                .is_err()
        );
        assert_eq!(
            policy.forbidden_path_argument(command),
            Some("unreadable heredoc delimiter".into())
        );
        // Another dialect never takes the POSIX shell's grammar.
        let cmd = policy.command_shell(ShellTarget {
            dialect: ShellDialect::WindowsCmd,
            program: Some(bash.as_os_str()),
            effective_path: None,
        });
        assert_eq!(cmd.grammar.posix_shell, PosixShell::Unknown);
    }

    /// A policy keeps the portable grammar whenever the program that runs
    /// may not be bash. Under bash, `<<$'EOF'` ends at `EOF` and hides the
    /// `wc` line as heredoc body. Dash ends it at the literal `$EOF` line and
    /// runs `wc`. A bare `bash` can resolve to dash on a connected TUI's
    /// `PATH`, a container sandbox runs its image's program at the configured
    /// name or path, and a container runtime reports no program at all.
    #[cfg(unix)]
    #[test]
    fn policy_keeps_portable_grammar_when_bash_is_not_bound() {
        let (Some(bash), Some(other)) = (host_bash(), host_shell_other_than_bash()) else {
            eprintln!("skipping: needs bash and another POSIX shell");
            return;
        };
        let dir = tempfile::tempdir().unwrap();
        let spoofed = path_with_bash_linked_to(dir.path(), &other);
        let command = "cat <<$'EOF'\nx\n$EOF\nwc -l /etc/passwd\nEOF";
        let unsandboxed = unsandboxed_wildcard_policy();
        let docker = SecurityPolicy {
            sandbox_enabled: Some(true),
            sandbox_backend: Some("docker".into()),
            ..unsandboxed.clone()
        };
        let auto = SecurityPolicy {
            sandbox_enabled: None,
            sandbox_backend: None,
            ..unsandboxed.clone()
        };
        let posix = |program: Option<&'static std::ffi::OsStr>, path| ShellTarget {
            dialect: ShellDialect::Posix,
            program,
            effective_path: path,
        };
        let bash_path: &'static std::ffi::OsStr =
            Box::leak(bash.into_os_string().into_boxed_os_str());
        for (name, policy, target) in [
            (
                "bare bash on a forwarded PATH where it is dash",
                &unsandboxed,
                posix(
                    Some(std::ffi::OsStr::new("bash")),
                    Some(spoofed.as_os_str()),
                ),
            ),
            ("docker sandbox", &docker, posix(Some(bash_path), None)),
            ("auto sandbox", &auto, posix(Some(bash_path), None)),
            ("container runtime", &unsandboxed, posix(None, None)),
        ] {
            let shell = policy.command_shell(target);
            assert_eq!(shell.grammar.posix_shell, PosixShell::Unknown, "{name}");
            assert!(
                policy
                    .validate_command_execution_in(command, false, shell)
                    .is_err(),
                "{name}"
            );
            assert_eq!(
                policy.forbidden_path_argument_in(command, shell),
                Some("unreadable heredoc delimiter".into()),
                "{name}"
            );
        }
    }

    /// A command read in bash's grammar runs only in bash. The runtime can
    /// build a different program than the policy predicted, and a host
    /// sandbox's launcher is never the shell, so the check runs before any
    /// sandbox wraps the command. A portable reading needs no confirmation.
    #[cfg(unix)]
    #[test]
    fn confirm_built_shell_holds_bash_reads_to_bash() {
        let (Some(bash), Some(other)) = (host_bash(), host_shell_other_than_bash()) else {
            eprintln!("skipping: needs bash and another POSIX shell");
            return;
        };
        let policy = unsandboxed_wildcard_policy();
        let read_as_bash = policy.command_shell(ShellTarget {
            dialect: ShellDialect::Posix,
            program: Some(bash.as_os_str()),
            effective_path: None,
        });
        assert_eq!(read_as_bash.grammar.posix_shell, PosixShell::Bash);
        let portable = policy.command_shell(ShellTarget {
            dialect: ShellDialect::Posix,
            program: Some(other.as_os_str()),
            effective_path: None,
        });
        assert_eq!(portable.grammar.posix_shell, PosixShell::Unknown);

        let dir = tempfile::tempdir().unwrap();
        let sh_to_bash = dir.path().join("sh");
        std::os::unix::fs::symlink(&bash, &sh_to_bash).unwrap();
        assert_eq!(
            policy.confirm_built_shell(read_as_bash, bash.as_os_str()),
            Ok(())
        );
        assert_eq!(
            policy.confirm_built_shell(read_as_bash, sh_to_bash.as_os_str()),
            Ok(())
        );
        for built in [
            other.as_os_str(),
            std::ffi::OsStr::new("bash"),
            std::ffi::OsStr::new("/no/such/bash"),
            std::ffi::OsStr::new("/usr/bin/firejail"),
        ] {
            assert!(
                policy.confirm_built_shell(read_as_bash, built).is_err(),
                "{built:?}"
            );
            assert_eq!(
                policy.confirm_built_shell(portable, built),
                Ok(()),
                "{built:?}"
            );
        }
    }

    /// A config with one agent on a sandbox-free risk profile.
    fn one_agent_config(dir: &Path) -> crate::schema::Config {
        use crate::schema::{AliasedAgentConfig, Config, RiskProfileConfig};

        let mut cfg = Config {
            data_dir: dir.join("data"),
            config_path: dir.join("config.toml"),
            ..Config::default()
        };
        cfg.risk_profiles.insert(
            "default".into(),
            RiskProfileConfig {
                sandbox_enabled: Some(false),
                ..RiskProfileConfig::default()
            },
        );
        cfg.agents.insert(
            "agent_a".into(),
            AliasedAgentConfig {
                risk_profile: "default".into(),
                ..AliasedAgentConfig::default()
            },
        );
        cfg
    }

    /// The grammar follows the runtime the factory builds from the same
    /// config, not a shell the policy recorded. With `[runtime].shell` set to
    /// bash, a native runtime reads commands as bash and the program it
    /// builds confirms it. A Docker runtime reports no program, so it keeps
    /// the portable grammar whatever the host's own shells are.
    #[cfg(all(unix, not(target_os = "android")))]
    #[test]
    fn grammar_follows_the_runtime_the_factory_builds() {
        let Some(bash) = host_bash() else {
            eprintln!("skipping: no bash on this host");
            return;
        };
        let dir = tempfile::tempdir().unwrap();
        let mut cfg = one_agent_config(dir.path());
        cfg.runtime.shell = Some(bash.to_string_lossy().into_owned());

        cfg.runtime.kind = crate::schema::RuntimeKind::Native;
        let policy = SecurityPolicy::for_agent(&cfg, "agent_a").unwrap();
        let runtime = crate::platform::create_runtime(&cfg.runtime).unwrap();
        let shell = policy.command_shell(ShellTarget::of(runtime.as_ref(), None));
        assert_eq!(shell.grammar.posix_shell, PosixShell::Bash);
        let built = runtime
            .build_shell_command("true", &policy.workspace_dir)
            .unwrap();
        assert_eq!(
            policy.confirm_built_shell(shell, built.as_std().get_program()),
            Ok(())
        );

        cfg.runtime.kind = crate::schema::RuntimeKind::Docker;
        let policy = SecurityPolicy::for_agent(&cfg, "agent_a").unwrap();
        let runtime = crate::platform::create_runtime(&cfg.runtime).unwrap();
        assert_eq!(runtime.shell_program(), None);
        let shell = policy.command_shell(ShellTarget::of(runtime.as_ref(), None));
        assert_eq!(shell.grammar.posix_shell, PosixShell::Unknown);
    }

    /// The body of an unquoted heredoc is expanded, so a line ending in an odd
    /// number of backslashes continues onto the next one. Bash compares the
    /// joined line, stripping `<<-` tabs while it is still empty. Dash skips
    /// lines that are exactly `\` at the start of a line and compares the
    /// next physical line alone. Each case was run in bash 3.2 through 5.3
    /// and dash 0.5.12.
    #[test]
    fn heredoc_terminators_follow_line_continuation() {
        let p = unix_forbidden_path_policy();
        let posix =
            |command: &str| p.forbidden_path_argument_for_shell(command, ShellDialect::Posix);
        let risk = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        // Bash joins these into the terminator and runs the next line; dash
        // reads on. The shells disagree, so the command is refused.
        for command in [
            "cat <<EOF\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<EOF\nE\\\nO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<EOF\nEOF\\\n\nwc -l /etc/passwd\nEOF",
            "cat <<-EOF\n\tEO\\\nF\nwc -l /etc/passwd\nEOF",
            "echo \"$(cat <<EOF\nEO\\\nF\n)\"; wc -l /etc/passwd\nEOF\n)\"",
            // A backslash-newline in the delimiter is removed before the word
            // is read, so `<<E\<newline>OF` is the unquoted delimiter `EOF`.
            // The body still joins. Counting that backslash as quoting waited
            // for the later physical `EOF` and skipped the read bash runs
            // after the joined line. The closing text after that `EOF` also
            // rebalanced the substitution, so no fallback ran.
            "cat <<E\\\nOF\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "echo \"$(cat <<E\\\nOF\nEO\\\nF\n)\"; wc -l /etc/passwd\nEOF\n)\"",
            "cat <<EOF\nE\\\n\\\nOF\nwc -l /etc/passwd\nEOF",
            // Bash strips the tab before an empty continuation and ends at
            // `EOF`; dash does not skip a tab-indented `\` line.
            "cat <<-EOF\n\t\\\nEOF\nwc -l /etc/passwd\nEOF",
            "cat <<-EOF\n\t\\\n\tEOF\nwc -l /etc/passwd\nEOF",
            "cat <<-EOF\n\\\n\tEO\\\nF\nwc -l /etc/passwd\nEOF",
        ] {
            assert_eq!(
                posix(command),
                Some("unreadable heredoc delimiter".into()),
                "{command:?}"
            );
            let high = command.replace("wc -l /etc/passwd", "rm -rf ./build");
            assert_eq!(
                risk.command_risk_level(&high),
                CommandRiskLevel::High,
                "{high:?}"
            );
            assert!(!risk.is_command_allowed(command), "{command:?}");
        }
        // Both shells end at a terminator after lines that are exactly `\`,
        // with `<<-` tabs stripped from it, and run the read that follows.
        for command in [
            "cat <<-EOF\n\\\n\tEOF\nwc -l /etc/passwd",
            "cat <<EOF\n\\\nEOF\nwc -l /etc/passwd",
            "cat <<EOF\n\\\n\\\nEOF\nwc -l /etc/passwd",
        ] {
            assert_eq!(posix(command), Some("/etc/passwd".into()), "{command:?}");
        }
        // Both shells read on past a physical `EOF` that continues a line, so
        // the quote in the real body is data and the read after it runs.
        assert_eq!(
            posix("cat <<EOF\nbody \\\nEOF\necho 'x\nEOF\nwc -l /etc/passwd #'"),
            Some("/etc/passwd".into())
        );
        // No join: the whole read is body in both shells.
        for command in [
            // Quoted delimiters leave backslash-newlines literal. A
            // continuation inside an otherwise quoted word is still quoting,
            // so the body does not join and the read stays data.
            "cat <<'EOF'\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<\"EOF\"\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<\\EOF\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<\"E\\\nOF\"\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<E\\\n'OF'\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            // An even number of backslashes is an escaped backslash.
            "cat <<EOF\nEO\\\\\nF\nwc -l /etc/passwd\nEOF",
            // `<<-` strips tabs only at the start of the logical line.
            "cat <<-EOF\n\tEO\\\n\tF\nwc -l /etc/passwd\nEOF",
            // A continued line that does not spell the terminator.
            "cat <<EOF\nE\\\n OF\nwc -l /etc/passwd\nEOF",
            "cat <<EOF\n \\\nEOF\nwc -l /etc/passwd\nEOF",
        ] {
            assert_eq!(posix(command), None, "{command:?}");
        }
    }

    /// Bash ends an unquoted heredoc body at a joined line that spells the
    /// terminator, stripping `<<-` tabs while the joined text is empty, so
    /// under bash the command after it is scanned rather than refused.
    #[test]
    fn bash_grammar_ends_heredocs_at_joined_terminators() {
        let p = unix_forbidden_path_policy();
        let bash = |command: &str| p.forbidden_path_argument_impl(command, bash_grammar(), false);
        for command in [
            "cat <<EOF\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            // Continuations in an unquoted delimiter are removed before
            // quote removal, so the body still joins its terminator.
            "cat <<E\\\nOF\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "echo \"$(cat <<E\\\nOF\nEO\\\nF\n)\"; wc -l /etc/passwd\nEOF\n)\"",
            "cat <<EOF\nE\\\nO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<EOF\nEOF\\\n\nwc -l /etc/passwd\nEOF",
            "cat <<EOF\nE\\\n\\\nOF\nwc -l /etc/passwd\nEOF",
            "cat <<-EOF\n\tEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<-EOF\n\t\\\nEOF\nwc -l /etc/passwd\nEOF",
            "cat <<-EOF\n\t\\\n\tEOF\nwc -l /etc/passwd\nEOF",
            "cat <<-EOF\n\\\n\tEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<-EOF\n\\\n\tEOF\nwc -l /etc/passwd",
        ] {
            assert_eq!(bash(command), Some("/etc/passwd".into()), "{command:?}");
        }
        // The body before the joined terminator is still data.
        assert_eq!(bash("cat <<EOF\n/etc/passwd\nEO\\\nF"), None);
        // Bash reads on past a continued physical `EOF`, past an indented
        // continuation, and through quoted delimiters, which do not join.
        for command in [
            "cat <<EOF\nbody \\\nEOF\n/etc/passwd\nEOF",
            "cat <<EOF\n \\\nEOF\nwc -l /etc/passwd\nEOF",
            "cat <<'EOF'\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<\"E\\\nOF\"\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<E\\\n'OF'\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            "cat <<-EOF\n\tEO\\\n\tF\nwc -l /etc/passwd\nEOF",
        ] {
            assert_eq!(bash(command), None, "{command:?}");
        }
        // Strict allowlists still refuse every line continuation, including
        // quoted delimiters. A plain quoted heredoc remains admissible.
        let strict = SecurityPolicy {
            allowed_commands: vec!["cat".into()],
            ..SecurityPolicy::default()
        };
        assert!(!strict.is_command_allowed_for_grammar(
            "cat <<E\\\nOF\nEO\\\nF\nwc -l /etc/passwd",
            bash_grammar(),
        ));
        assert!(!strict.is_command_allowed_for_grammar(
            "cat <<\"E\\\nOF\"\nEO\\\nF\nwc -l /etc/passwd\nEOF",
            bash_grammar(),
        ));
        assert!(
            strict.is_command_allowed_for_grammar(
                "cat <<'EOF'\nwc -l /etc/passwd\nEOF",
                bash_grammar(),
            )
        );
    }

    /// The strict allowlist decision for grouping and substitution syntax is
    /// unchanged: segment splitting must not turn a previously rejected
    /// `(git status)` into an accepted one.
    #[test]
    fn strict_allowlist_still_rejects_posix_grouping_and_substitution() {
        let p = default_policy();
        assert!(p.is_command_allowed("git status 2>/dev/null"));
        // Escaped and quoted parentheses are literal, not grouping syntax.
        assert!(p.is_command_allowed("find . \\( -name a -o -name b \\)"));
        assert!(p.is_command_allowed("grep -E '(a|b)' file"));
        for command in [
            "(git status)",
            "(git status 2>/dev/null)",
            "(git status) 2>/dev/null",
            "git status && (git log)",
            "x=$(git status)",
            "git status `git log`",
            "git status )",
        ] {
            assert!(!p.is_command_allowed(command), "{command}");
        }
    }

    /// The dialect divergence that broke the host-defaulting tests on Windows,
    /// pinned as intended behavior: under `cmd.exe` the safe null device is
    /// `nul`, while `/dev/null` is an ordinary forbidden-prefix path, and a
    /// bare leading-slash redirect target is rooted on the current drive
    /// rather than being workspace-relative.
    #[test]
    fn forbidden_path_argument_windows_cmd_classifies_devices_by_dialect() {
        let p = unix_forbidden_path_policy();
        let windows_cmd =
            |command: &str| p.forbidden_path_argument_for_shell(command, ShellDialect::WindowsCmd);

        // Host-independent dialect facts: the cmd.exe null device is safe,
        // and a drive-relative form fails closed on every host because it
        // resolves against a per-drive current directory.
        assert_eq!(windows_cmd("dir missing 2>nul"), None);
        assert_eq!(windows_cmd("dir missing 2> nul"), None);
        assert_eq!(
            windows_cmd("type C:relative.txt"),
            Some("C:relative.txt".into())
        );

        // The `/dev/null` classification under the Windows dialect is
        // host-gated, not dialect-gated: on a Windows host a bare leading
        // slash is rooted on the current drive and fails closed, while on
        // POSIX hosts the Unix device path remains acceptable. Assert both
        // arms so the split stays visible instead of surprising the next
        // host-defaulting caller.
        #[cfg(target_os = "windows")]
        assert_eq!(
            windows_cmd("dir missing 2>/dev/null"),
            Some("/dev/null".into())
        );
        #[cfg(not(target_os = "windows"))]
        assert_eq!(windows_cmd("dir missing 2>/dev/null"), None);
    }

    // ── Edge cases: path traversal ──────────────────────────

    #[test]
    fn path_traversal_encoded_dots() {
        let p = default_policy();
        // Literal ".." in path — always blocked
        assert!(!p.is_path_allowed("foo/..%2f..%2fetc/passwd"));
    }

    #[test]
    fn path_traversal_double_dot_in_filename() {
        let p = default_policy();
        // ".." in a filename (not a path component) is allowed
        assert!(p.is_path_allowed("my..file.txt"));
        // But actual traversal components are still blocked
        assert!(!p.is_path_allowed("../etc/passwd"));
        assert!(!p.is_path_allowed("foo/../etc/passwd"));
    }

    #[test]
    fn path_with_null_byte_blocked() {
        let p = default_policy();
        assert!(!p.is_path_allowed("file\0.txt"));
    }

    #[test]
    fn path_symlink_style_absolute() {
        let p = default_policy();
        assert!(!p.is_path_allowed(&tp_sys_sub("proc/self/root/etc/passwd")));
    }

    #[test]
    fn path_home_tilde_ssh() {
        let p = SecurityPolicy {
            workspace_only: false,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_path_allowed("~/.ssh/id_rsa"));
        assert!(!p.is_path_allowed("~/.gnupg/secring.gpg"));
        assert!(!p.is_path_allowed("~root/.ssh/id_rsa"));
        assert!(!p.is_path_allowed("~nobody"));
    }

    #[test]
    fn path_var_run_blocked() {
        let p = SecurityPolicy {
            workspace_only: false,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_path_allowed(&tp_sys_sub("var/run/docker.sock")));
    }

    // ── Edge cases: rate limiter boundary ────────────────────

    #[test]
    fn rate_limit_exactly_at_boundary() {
        let p = SecurityPolicy {
            max_actions_per_hour: 1,
            ..SecurityPolicy::default()
        };
        assert!(p.record_action()); // 1 — exactly at limit
        assert!(!p.record_action()); // 2 — over
        assert!(!p.record_action()); // 3 — still over
    }

    #[test]
    fn rate_limit_zero_blocks_everything() {
        let p = SecurityPolicy {
            max_actions_per_hour: 0,
            ..SecurityPolicy::default()
        };
        assert!(!p.record_action());
        assert!(p.reserve_action().is_none());
    }

    #[test]
    fn action_reservation_drop_releases_exact_slot() {
        let p = SecurityPolicy {
            max_actions_per_hour: 2,
            ..SecurityPolicy::default()
        };

        let first = p.reserve_action().expect("first reservation");
        let second = p.reserve_action().expect("second reservation");
        assert!(p.reserve_action().is_none(), "both slots are reserved");

        drop(first);
        let replacement = p.reserve_action().expect("only first slot was released");
        second.commit();
        assert!(
            p.reserve_action().is_none(),
            "second reservation committed while replacement remains in flight"
        );

        drop(replacement);
        let final_slot = p.reserve_action().expect("replacement slot was released");
        final_slot.commit();
        assert!(p.reserve_action().is_none(), "both slots are now committed");
    }

    #[test]
    fn action_reservations_are_isolated_by_sender() {
        let tracker = PerSenderTracker::new();
        let sender_a = tracker
            .reserve_within("sender-a".to_string(), 1)
            .expect("sender A reservation");

        assert!(
            tracker.reserve_within("sender-a".to_string(), 1).is_none(),
            "sender A has no second slot"
        );
        let sender_b = tracker
            .reserve_within("sender-b".to_string(), 1)
            .expect("sender B has an independent slot");

        sender_a.commit();
        drop(sender_b);
        assert!(
            tracker.reserve_within("sender-b".to_string(), 1).is_some(),
            "releasing sender B is independent from sender A's commit"
        );
    }

    #[test]
    fn released_reservation_removes_empty_sender_bucket() {
        let tracker = PerSenderTracker::new();
        let reservation = tracker
            .reserve_within("ephemeral-sender".to_string(), 1)
            .expect("reservation");
        assert!(tracker.buckets.lock().contains_key("ephemeral-sender"));

        drop(reservation);

        assert!(!tracker.buckets.lock().contains_key("ephemeral-sender"));
    }

    #[test]
    fn zero_budget_does_not_create_sender_bucket() {
        let tracker = PerSenderTracker::new();

        assert!(!tracker.record_within("zero-budget", 0));
        assert!(
            tracker
                .reserve_within("zero-budget".to_string(), 0)
                .is_none()
        );
        assert!(tracker.buckets.lock().is_empty());
    }

    #[test]
    fn expired_success_is_evicted_when_budget_is_read() {
        let tracker = PerSenderTracker::new();
        assert!(tracker.record_within("expired-sender", 1));
        let after_window = {
            let buckets = tracker.buckets.lock();
            let action_tracker = buckets.get("expired-sender").expect("sender bucket");
            let state = action_tracker.state.lock();
            state.committed[0]
                .checked_add(ACTION_WINDOW + Duration::from_secs(1))
                .expect("test timestamp")
        };

        assert!(!tracker.is_exhausted_at("expired-sender", 1, after_window));
        assert!(!tracker.buckets.lock().contains_key("expired-sender"));
    }

    #[test]
    fn rate_limit_high_allows_many() {
        let p = SecurityPolicy {
            max_actions_per_hour: 10000,
            ..SecurityPolicy::default()
        };
        for _ in 0..100 {
            assert!(p.record_action());
        }
    }

    // ── Edge cases: autonomy + command combos ────────────────

    #[test]
    fn readonly_blocks_even_safe_commands() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::ReadOnly,
            allowed_commands: vec!["ls".into(), "cat".into()],
            ..SecurityPolicy::default()
        };
        assert!(!p.is_command_allowed("ls"));
        assert!(!p.is_command_allowed("cat"));
        assert!(!p.can_act());
    }

    #[test]
    fn supervised_allows_listed_commands() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            allowed_commands: vec!["git".into()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed("git status"));
        assert!(!p.is_command_allowed("docker ps"));
    }

    #[test]
    fn full_autonomy_still_respects_forbidden_paths() {
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            workspace_only: false,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_path_allowed(&tp_sys_sub("etc/shadow")));
        assert!(!p.is_path_allowed(&tp_sys_sub("root/.bashrc")));
    }

    #[test]
    fn workspace_only_false_allows_resolved_outside_workspace() {
        let workspace = std::env::temp_dir().join("zeroclaw_test_ws_only_false");
        let _ = std::fs::create_dir_all(&workspace);
        let canonical_workspace = workspace
            .canonicalize()
            .unwrap_or_else(|_| workspace.clone());

        let p = SecurityPolicy {
            workspace_dir: canonical_workspace.clone(),
            workspace_only: false,
            forbidden_paths: vec!["/etc".into(), "/var".into()],
            ..SecurityPolicy::default()
        };

        // Path outside workspace should be allowed when workspace_only=false
        let outside = std::env::var_os("HOME")
            .map(std::path::PathBuf::from)
            .unwrap_or_else(|| PathBuf::from("/home"))
            .join("zeroclaw_outside_ws");
        assert!(
            p.is_resolved_path_allowed(&outside),
            "workspace_only=false must allow resolved paths outside workspace"
        );

        // Forbidden paths must still be blocked even with workspace_only=false
        assert!(
            !p.is_resolved_path_allowed(Path::new("/etc/passwd")),
            "forbidden paths must be blocked even when workspace_only=false"
        );
        assert!(
            !p.is_resolved_path_allowed(Path::new("/var/zeroclaw-forbidden-test/nonexistent.sock")),
            "forbidden /var must be blocked even when workspace_only=false"
        );

        let _ = std::fs::remove_dir_all(&workspace);
    }

    #[test]
    fn workspace_only_true_blocks_resolved_outside_workspace() {
        let workspace = std::env::temp_dir().join("zeroclaw_test_ws_only_true");
        let _ = std::fs::create_dir_all(&workspace);
        let canonical_workspace = workspace
            .canonicalize()
            .unwrap_or_else(|_| workspace.clone());

        let p = SecurityPolicy {
            workspace_dir: canonical_workspace.clone(),
            workspace_only: true,
            ..SecurityPolicy::default()
        };

        // Path inside workspace — allowed
        let inside = canonical_workspace.join("subdir");
        assert!(
            p.is_resolved_path_allowed(&inside),
            "path inside workspace must be allowed"
        );

        // Path outside workspace — blocked
        let outside = std::env::temp_dir()
            .canonicalize()
            .unwrap_or_else(|_| std::env::temp_dir())
            .join("zeroclaw_outside_ws_true");
        assert!(
            !p.is_resolved_path_allowed(&outside),
            "workspace_only=true must block resolved paths outside workspace"
        );

        let _ = std::fs::remove_dir_all(&workspace);
    }

    // ── is_resolved_path_readable: read-only allowlist + POSIX devs ──

    #[cfg(unix)]
    #[test]
    fn readable_includes_posix_device_files() {
        // /dev/null and friends are universally-readable system paths
        // operators expect to work for shell-idiom CLI tooling.
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/tmp/zeroclaw-test-ws"),
            workspace_only: true,
            ..SecurityPolicy::default()
        };
        for device in ["/dev/null", "/dev/zero", "/dev/random", "/dev/urandom"] {
            assert!(
                p.is_resolved_path_readable(Path::new(device)),
                "POSIX device file {device} must be readable"
            );
        }
    }

    #[cfg(unix)]
    #[test]
    fn resolved_write_check_preserves_symlinks_to_the_null_device() {
        use std::os::unix::fs::symlink;

        let tmp = tempfile::tempdir().unwrap();
        let null_alias = tmp.path().join("null-alias");
        symlink("/dev/null", &null_alias).unwrap();
        let policy = SecurityPolicy {
            workspace_dir: tmp.path().to_path_buf(),
            workspace_only: true,
            ..SecurityPolicy::default()
        };

        assert!(policy.is_resolved_path_readable(Path::new("/dev/null")));
        assert!(policy.is_resolved_path_allowed(Path::new("/dev/null")));
        // Both reads and writes retain the longstanding resolved-target
        // exception for POSIX devices.
        assert!(policy.is_resolved_path_readable(&null_alias));
        assert!(
            policy.is_resolved_path_allowed(&null_alias),
            "a symlink to the null device must retain write authorization"
        );
    }

    #[cfg(target_os = "windows")]
    #[test]
    fn resolved_path_checks_allow_the_windows_null_device() {
        let policy = SecurityPolicy {
            workspace_dir: PathBuf::from(r"C:\\workspace"),
            workspace_only: true,
            ..SecurityPolicy::default()
        };

        for spelling in ["nul", "NUL", "Nul", r"\\.\nul", r"\\.\NUL"] {
            let device = Path::new(spelling);
            assert!(
                policy.is_path_allowed(spelling),
                "native null device {spelling:?} must be allowed"
            );
            assert!(
                policy.is_resolved_path_readable(device),
                "native null device {spelling:?} must be readable before resolution"
            );
            assert!(
                policy.is_resolved_path_allowed(device),
                "native null device {spelling:?} must be writable before resolution"
            );
            assert_eq!(
                policy.resolve_policy_target(device),
                Some(device.to_path_buf()),
                "native null device {spelling:?} is not canonicalizable and is returned as-is"
            );
        }
    }

    /// On Windows, `/dev/null` is the ordinary file `\dev\null` on the current
    /// drive, not the null device. With workspace confinement disabled, an
    /// explicit operator deny on `/dev` must still reject it (for example a
    /// native PowerShell `Get-Content '/dev/null'` cron job), while native
    /// `NUL` stays usable and a POSIX-dialect `2>/dev/null` redirect keeps its
    /// separate, dialect-aware exception.
    #[cfg(target_os = "windows")]
    #[test]
    fn windows_dev_null_is_an_ordinary_file_under_explicit_deny() {
        let policy = SecurityPolicy {
            workspace_dir: PathBuf::from(r"C:\workspace"),
            workspace_only: false,
            forbidden_paths: vec!["/dev".into()],
            ..SecurityPolicy::default()
        };

        assert!(
            !policy.is_path_allowed("/dev/null"),
            "/dev/null is an ordinary file on Windows and must honor the explicit /dev deny"
        );
        assert!(
            policy
                .forbidden_path_argument_for_shell(
                    "Get-Content '/dev/null'",
                    ShellDialect::PowerShell
                )
                .is_some(),
            "a native PowerShell read of /dev/null must be rejected under the explicit deny"
        );

        for spelling in ["NUL", "nul", r"\\.\NUL"] {
            let device = Path::new(spelling);
            assert!(policy.is_path_allowed(spelling), "{spelling:?}");
            assert!(
                policy.is_resolved_path_readable(device),
                "{spelling:?} read"
            );
            assert!(
                policy.is_resolved_path_allowed(device),
                "{spelling:?} write"
            );
        }

        assert_eq!(
            policy.forbidden_path_argument_for_shell("ls missing 2>/dev/null", ShellDialect::Posix),
            None,
            "POSIX /dev/null redirects keep their dialect-aware exception on Windows"
        );
    }

    /// On Unix, `nul`, `NUL`, and `\\.\nul` are ordinary filenames, not the
    /// null device. The Windows discard spelling must not short-circuit
    /// filesystem authorization: an alias with one of those names is resolved
    /// like any other path and denied when its target is forbidden or outside
    /// every allowed root. `/dev/null` and its aliases stay usable.
    #[cfg(unix)]
    #[test]
    fn unix_foreign_null_spellings_get_no_filesystem_exception() {
        use std::os::unix::fs::symlink;

        let tmp = tempfile::tempdir().unwrap();
        let root = tmp.path().canonicalize().unwrap();
        let workspace = root.join("ws");
        let secret_dir = workspace.join("secret");
        let outside_dir = root.join("outside");
        std::fs::create_dir_all(&secret_dir).unwrap();
        std::fs::create_dir_all(&outside_dir).unwrap();
        let secret = secret_dir.join("key");
        let outside = outside_dir.join("key");
        let notes = workspace.join("notes.txt");
        for file in [&secret, &outside, &notes] {
            std::fs::write(file, "x").unwrap();
        }

        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            workspace_only: true,
            // The forbidden directory sits inside the workspace, so every
            // alias below is lexically in-workspace: only resolution of the
            // alias to its target can deny it. `/dev` is forbidden to show
            // the `/dev/null` exception survives a forbidden parent.
            forbidden_paths: vec![secret_dir.to_string_lossy().into_owned(), "/dev".into()],
            ..SecurityPolicy::default()
        };

        // Control: an ordinary in-workspace alias is authorized, so the
        // denials below come from the target, not from the fixture location.
        let ok_alias = workspace.join("ok-alias");
        symlink(&notes, &ok_alias).unwrap();
        assert!(policy.is_resolved_path_readable(&ok_alias));
        assert!(policy.is_resolved_path_allowed(&ok_alias));

        for (name, target) in [
            ("nul", &secret),
            ("NUL", &outside),
            (r"\\.\nul", &secret),
            (r"\\.\NUL", &outside),
        ] {
            let alias = workspace.join(name);
            symlink(target, &alias).unwrap();
            assert_eq!(
                policy.resolve_policy_target(&alias),
                Some(target.clone()),
                "{name:?} is an ordinary Unix filename and must resolve to its target"
            );
            assert!(
                !policy.is_resolved_path_readable(&alias),
                "{name:?} alias to {target:?} must not be readable"
            );
            assert!(
                !policy.is_resolved_path_allowed(&alias),
                "{name:?} alias to {target:?} must not be writable"
            );
            std::fs::remove_file(alias).unwrap();
        }

        // A bare foreign spelling gains nothing from its name: it is resolved
        // against the process CWD (never returned raw) and, because that CWD
        // is outside this workspace, authorization is denied.
        for name in ["nul", "NUL", r"\\.\nul"] {
            let bare = Path::new(name);
            let target = policy.resolve_policy_target(bare);
            assert_ne!(
                target.as_deref(),
                Some(bare),
                "{name:?} must not be returned as an unresolved device spelling"
            );
            assert!(
                target.as_deref().is_none_or(Path::is_absolute),
                "{name:?} must resolve to an absolute target or fail closed, got {target:?}"
            );
            assert!(!policy.is_resolved_path_readable(bare), "{name:?} read");
            assert!(!policy.is_resolved_path_allowed(bare), "{name:?} write");
        }

        // `/dev/null` and an alias to it remain usable even though `/dev` is
        // forbidden.
        let null_alias = workspace.join("null-alias");
        symlink("/dev/null", &null_alias).unwrap();
        for device in [Path::new("/dev/null"), null_alias.as_path()] {
            assert!(policy.is_resolved_path_readable(device), "{device:?} read");
            assert!(policy.is_resolved_path_allowed(device), "{device:?} write");
        }
    }

    /// The generic null-device exception is host-native. On Unix, `/dev/null`
    /// is always allowed: before filesystem resolution, even when `/dev` is
    /// forbidden, with or without workspace confinement. On Windows it is an
    /// ordinary file (see `windows_dev_null_is_an_ordinary_file_under_explicit_deny`).
    /// Shell redirects stay dialect-aware on every host: a POSIX
    /// `2>/dev/null` and a `cmd.exe` `2>nul` both pass their own scans.
    #[test]
    fn null_device_exception_is_host_native() {
        let confined = SecurityPolicy {
            workspace_dir: PathBuf::from("/workspace"),
            workspace_only: true,
            forbidden_paths: vec!["/dev".into(), "/etc".into()],
            ..SecurityPolicy::default()
        };

        #[cfg(not(target_os = "windows"))]
        {
            // Same shape as the Windows regression: no workspace confinement,
            // an explicit operator deny on `/dev`. Unix `/dev/null` still wins.
            let unconfined = SecurityPolicy {
                workspace_dir: PathBuf::from("/workspace"),
                workspace_only: false,
                forbidden_paths: vec!["/dev".into()],
                ..SecurityPolicy::default()
            };
            let dev_null = Path::new("/dev/null");
            for policy in [&confined, &unconfined] {
                assert!(
                    policy.is_path_allowed("/dev/null"),
                    "/dev/null must always be allowed on Unix, even with /dev forbidden"
                );
                assert!(
                    policy.is_resolved_path_readable(dev_null),
                    "/dev/null must stay readable before filesystem resolution"
                );
                assert!(
                    policy.is_resolved_path_allowed(dev_null),
                    "/dev/null must stay writable before filesystem resolution"
                );
                assert_eq!(
                    policy.resolve_policy_target(dev_null),
                    Some(dev_null.to_path_buf()),
                    "/dev/null must be returned as-is, not resolved and re-checked"
                );
            }
        }

        // The exception is exact. These sit outside the workspace under the
        // forbidden `/dev` prefix and must not match the null device.
        for spelling in ["/dev/zero", "/dev/null/extra", "/dev/null.txt"] {
            assert!(
                !confined.is_path_allowed(spelling),
                "non-null path {spelling:?} must not inherit the null-device exception"
            );
            assert!(
                !confined.is_resolved_path_allowed(Path::new(spelling)),
                "non-null path {spelling:?} must not be writable via the null-device exception"
            );
        }

        // Redirect safety is decided by the shell dialect, not the host's
        // filesystem exception, so these hold on every host.
        let policy = &confined;
        assert_eq!(
            policy.forbidden_path_argument_for_shell("ls missing 2>/dev/null", ShellDialect::Posix),
            None,
            "POSIX /dev/null redirect must be allowed on every host"
        );
        assert_eq!(
            policy.forbidden_workspace_path_argument_for_shell(
                "ls missing 2>/dev/null",
                ShellDialect::Posix,
            ),
            None,
            "workspace scan must not re-block a POSIX /dev/null redirect"
        );
        assert_eq!(
            policy.forbidden_path_argument_for_shell("dir missing 2>nul", ShellDialect::WindowsCmd),
            None,
            "cmd.exe nul redirect must be allowed on every host"
        );
        assert_eq!(
            policy.forbidden_path_argument_for_shell("dir missing 2>NUL", ShellDialect::WindowsCmd),
            None
        );
        assert_eq!(
            policy.forbidden_workspace_path_argument_for_shell(
                r"dir missing 2>\\.\nul",
                ShellDialect::WindowsCmd,
            ),
            None,
            "workspace scan must not re-block a cmd.exe \\\\.\\\\nul redirect"
        );
    }

    #[test]
    fn readable_includes_read_only_allowlist_paths() {
        let tmp = tempfile::tempdir().unwrap();
        let read_only_root = tmp.path().join("docs");
        std::fs::create_dir_all(&read_only_root).unwrap();
        let inside = read_only_root.join("guide.md");
        std::fs::write(&inside, "x").unwrap();

        let canonical_inside = inside.canonicalize().unwrap();
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/tmp/elsewhere"),
            workspace_only: true,
            allowed_roots_read_only: vec![read_only_root.clone()],
            ..SecurityPolicy::default()
        };
        assert!(
            p.is_resolved_path_readable(&canonical_inside),
            "read-only allowlist entries must be readable"
        );
        // The same path is NOT writable (is_resolved_path_allowed is
        // strict-rw and does not consult allowed_roots_read_only).
        assert!(
            !p.is_resolved_path_allowed(&canonical_inside),
            "read-only allowlist entries must NOT be writable via is_resolved_path_allowed"
        );
    }

    // ── for_agent: workspace.access populates allowlist tiers ──

    #[test]
    fn for_agent_routes_workspace_access_into_correct_allowlist_tier() {
        use crate::multi_agent::{AccessMode, AgentAlias};
        use crate::schema::{AliasedAgentConfig, Config, RiskProfileConfig};

        let mut cfg = Config {
            data_dir: PathBuf::from("/tmp/zeroclaw-for-agent-test"),
            config_path: PathBuf::from("/tmp/zeroclaw-for-agent-test/config.toml"),
            ..Config::default()
        };
        cfg.risk_profiles.insert(
            "default".into(),
            RiskProfileConfig {
                workspace_only: true,
                ..RiskProfileConfig::default()
            },
        );

        cfg.agents.insert(
            "writable_sibling".into(),
            AliasedAgentConfig {
                risk_profile: "default".into(),
                ..AliasedAgentConfig::default()
            },
        );
        cfg.agents.insert(
            "readonly_sibling".into(),
            AliasedAgentConfig {
                risk_profile: "default".into(),
                ..AliasedAgentConfig::default()
            },
        );

        let mut test_agent = AliasedAgentConfig {
            risk_profile: "default".into(),
            ..AliasedAgentConfig::default()
        };
        test_agent
            .workspace
            .access
            .insert(AgentAlias::from("writable_sibling"), AccessMode::Write);
        test_agent
            .workspace
            .access
            .insert(AgentAlias::from("readonly_sibling"), AccessMode::Read);
        cfg.agents.insert("test_agent".into(), test_agent);

        let policy = SecurityPolicy::for_agent(&cfg, "test_agent").unwrap();

        let writable_sibling_dir = cfg.agent_workspace_dir("writable_sibling");
        let readonly_sibling_dir = cfg.agent_workspace_dir("readonly_sibling");

        assert!(
            policy
                .allowed_roots_write_only
                .contains(&writable_sibling_dir),
            "AccessMode::Write must land in allowed_roots_write_only; got {:?}",
            policy.allowed_roots_write_only
        );
        assert!(
            !policy.allowed_roots.contains(&writable_sibling_dir),
            "AccessMode::Write must NOT land in allowed_roots (read+write tier); got {:?}",
            policy.allowed_roots
        );
        assert!(
            policy
                .allowed_roots_read_only
                .contains(&readonly_sibling_dir),
            "AccessMode::Read must land in allowed_roots_read_only; got {:?}",
            policy.allowed_roots_read_only
        );
        assert!(
            !policy
                .allowed_roots_read_only
                .contains(&writable_sibling_dir),
            "Write-mode entry must NOT also appear on the read-only list"
        );
        assert!(
            !policy
                .allowed_roots_write_only
                .contains(&readonly_sibling_dir),
            "Read-mode entry must NOT also appear on the write-only list"
        );
        assert!(
            policy.workspace_only,
            "unrestricted_filesystem stays default-false → workspace_only stays true"
        );
    }

    #[test]
    fn write_only_root_blocks_reads_and_admits_writes() {
        // AccessMode::Write grants write access without read access.
        // is_resolved_path_allowed (write-side) must accept paths under
        // a write-only root; is_resolved_path_readable (read-side) must
        // refuse them.
        let mut policy = SecurityPolicy::default();
        let write_only_root =
            std::env::temp_dir().join(format!("zeroclaw_wo_root_{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&write_only_root).unwrap();
        let canonical = write_only_root.canonicalize().unwrap();
        policy.allowed_roots_write_only.push(canonical.clone());
        policy.workspace_only = false;

        let target = canonical.join("write_only_target.txt");
        assert!(
            policy.is_resolved_path_allowed(&target),
            "write-only root must be writable via is_resolved_path_allowed"
        );
        assert!(
            !policy.is_resolved_path_readable(&target),
            "write-only root must NOT be readable via is_resolved_path_readable"
        );

        let _ = std::fs::remove_dir_all(canonical);
    }

    #[test]
    fn for_agent_creates_the_per_agent_workspace_dir() {
        use crate::schema::{AliasedAgentConfig, Config, RiskProfileConfig};

        let root =
            std::env::temp_dir().join(format!("zeroclaw-for-agent-mkdir-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        let mut cfg = Config {
            data_dir: root.join("data"),
            config_path: root.join("config.toml"),
            ..Config::default()
        };
        cfg.risk_profiles
            .insert("default".into(), RiskProfileConfig::default());
        cfg.agents.insert(
            "agent_a".into(),
            AliasedAgentConfig {
                risk_profile: "default".into(),
                ..AliasedAgentConfig::default()
            },
        );

        let ws = cfg.agent_workspace_dir("agent_a");
        assert!(
            !ws.exists(),
            "precondition: workspace dir must not exist yet"
        );

        let policy = SecurityPolicy::for_agent(&cfg, "agent_a").unwrap();

        assert!(
            ws.exists(),
            "for_agent must create the per-agent workspace dir at the chokepoint"
        );
        assert_eq!(
            policy.workspace_dir, ws,
            "policy cwd/jail root must be the created workspace dir"
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn for_agent_unrestricted_filesystem_disables_workspace_only() {
        use crate::schema::{AliasedAgentConfig, Config, RiskProfileConfig};

        let mut cfg = Config {
            data_dir: PathBuf::from("/tmp/zeroclaw-for-agent-unrestricted"),
            config_path: PathBuf::from("/tmp/zeroclaw-for-agent-unrestricted/config.toml"),
            ..Config::default()
        };
        cfg.risk_profiles.insert(
            "default".into(),
            RiskProfileConfig {
                workspace_only: true,
                ..RiskProfileConfig::default()
            },
        );
        let mut test_agent = AliasedAgentConfig {
            risk_profile: "default".into(),
            ..AliasedAgentConfig::default()
        };
        test_agent.workspace.unrestricted_filesystem = true;
        cfg.agents.insert("test_agent".into(), test_agent);

        let policy = SecurityPolicy::for_agent(&cfg, "test_agent").unwrap();

        assert!(
            !policy.workspace_only,
            "unrestricted_filesystem=true must flip workspace_only off at the policy level"
        );
    }

    // ── Edge cases: from_config preserves tracker ────────────

    #[test]
    fn from_config_creates_fresh_tracker() {
        let risk = crate::schema::RiskProfileConfig {
            level: AutonomyLevel::Full,
            workspace_only: false,
            allowed_commands: vec![],
            forbidden_paths: vec![],
            require_approval_for_medium_risk: true,
            block_high_risk_commands: true,
            ..crate::schema::RiskProfileConfig::default()
        };
        let runtime = crate::schema::RuntimeProfileConfig {
            max_actions_per_hour: 10,
            max_cost_per_day_cents: 100,
            ..crate::schema::RuntimeProfileConfig::default()
        };
        let workspace = PathBuf::from("/tmp/test");
        let policy = SecurityPolicy::from_profiles(&risk, Some(&runtime), &workspace);
        assert!(!policy.is_rate_limited());
    }

    // ── Checklist #3: Filesystem scoped (no /) ──────────────

    #[test]
    fn checklist_root_path_blocked() {
        let p = default_policy();
        assert!(!p.is_path_allowed(tp_sys()));
        assert!(!p.is_path_allowed(&tp_sys_sub("anything")));
    }

    #[test]
    fn checklist_all_system_dirs_blocked() {
        let p = SecurityPolicy {
            workspace_only: false,
            ..SecurityPolicy::default()
        };
        #[cfg(not(target_os = "windows"))]
        {
            for dir in ["/etc", "/root", "/proc", "/sys", "/dev", "/var", "/tmp"] {
                assert!(
                    p.forbidden_paths.iter().any(|f| f == dir),
                    "Default forbidden_paths must include {dir} on Unix"
                );
                assert!(
                    !p.is_path_allowed(dir),
                    "System dir should be blocked: {dir}"
                );
            }
        }
        #[cfg(target_os = "windows")]
        {
            for dir in [
                "C:\\Windows",
                "C:\\Windows\\System32",
                "C:\\Program Files",
                "C:\\ProgramData",
            ] {
                assert!(
                    p.forbidden_paths.iter().any(|f| f == dir),
                    "Default forbidden_paths must include {dir} on Windows"
                );
                assert!(
                    !p.is_path_allowed(dir),
                    "System dir should be blocked: {dir}"
                );
            }
        }
        for dot in &["~/.ssh", "~/.gnupg", "~/.aws"] {
            assert!(
                p.forbidden_paths.iter().any(|f| f == dot),
                "Default forbidden_paths must include {dot}"
            );
            assert!(
                !p.is_path_allowed(dot),
                "Sensitive dotfile dir should be blocked: {dot}"
            );
        }
    }

    #[test]
    fn checklist_sensitive_dotfiles_blocked() {
        let p = SecurityPolicy {
            workspace_only: false,
            ..SecurityPolicy::default()
        };
        for path in [
            "~/.ssh/id_rsa",
            "~/.gnupg/secring.gpg",
            "~/.aws/credentials",
            "~/.config/secrets",
        ] {
            assert!(
                !p.is_path_allowed(path),
                "Sensitive dotfile should be blocked: {path}"
            );
        }
    }

    #[test]
    fn checklist_null_byte_injection_blocked() {
        let p = default_policy();
        assert!(!p.is_path_allowed("safe\0/../../../etc/passwd"));
        assert!(!p.is_path_allowed("\0"));
        assert!(!p.is_path_allowed("file\0"));
    }

    #[test]
    fn checklist_workspace_only_blocks_absolute_outside_workspace() {
        let p = SecurityPolicy {
            workspace_only: true,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_path_allowed(&tp_sys_sub("any/absolute/path")));
        assert!(p.is_path_allowed("relative/path.txt"));
    }

    #[test]
    fn checklist_resolved_path_must_be_in_workspace() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/home/user/project"),
            ..SecurityPolicy::default()
        };
        // Inside workspace — allowed
        assert!(p.is_resolved_path_allowed(Path::new("/home/user/project/src/main.rs")));
        // Outside workspace — blocked (symlink escape)
        assert!(!p.is_resolved_path_allowed(Path::new("/etc/passwd")));
        assert!(!p.is_resolved_path_allowed(Path::new("/home/user/other_project/file")));
        // Root — blocked
        assert!(!p.is_resolved_path_allowed(Path::new("/")));
    }

    #[test]
    fn checklist_default_policy_is_workspace_only() {
        let p = SecurityPolicy::default();
        assert!(
            p.workspace_only,
            "Default policy must be workspace_only=true"
        );
    }

    #[test]
    fn checklist_default_forbidden_paths_comprehensive() {
        let p = SecurityPolicy::default();
        #[cfg(not(target_os = "windows"))]
        {
            for dir in ["/etc", "/root", "/proc", "/sys", "/dev", "/var", "/tmp"] {
                assert!(
                    p.forbidden_paths.iter().any(|f| f == dir),
                    "Default forbidden_paths must include {dir} on Unix"
                );
            }
        }
        #[cfg(target_os = "windows")]
        {
            for dir in [
                "C:\\Windows",
                "C:\\Windows\\System32",
                "C:\\Program Files",
                "C:\\ProgramData",
            ] {
                assert!(
                    p.forbidden_paths.iter().any(|f| f == dir),
                    "Default forbidden_paths must include {dir} on Windows"
                );
            }
        }
        for dot in &["~/.ssh", "~/.gnupg", "~/.aws", "~/.config"] {
            assert!(
                p.forbidden_paths.iter().any(|f| f == dot),
                "Default forbidden_paths must include {dot}"
            );
        }
    }

    // ── §1.2 Path resolution / symlink bypass tests ──────────

    #[test]
    fn resolved_path_blocks_outside_workspace() {
        let workspace = std::env::temp_dir().join("zeroclaw_test_resolved_path");
        let _ = std::fs::create_dir_all(&workspace);

        // Use the canonicalized workspace so starts_with checks match
        let canonical_workspace = workspace
            .canonicalize()
            .unwrap_or_else(|_| workspace.clone());

        let policy = SecurityPolicy {
            workspace_dir: canonical_workspace.clone(),
            ..SecurityPolicy::default()
        };

        // A resolved path inside the workspace should be allowed
        let inside = canonical_workspace.join("subdir").join("file.txt");
        assert!(
            policy.is_resolved_path_allowed(&inside),
            "path inside workspace should be allowed"
        );

        // A resolved path outside the workspace should be blocked
        let canonical_temp = std::env::temp_dir()
            .canonicalize()
            .unwrap_or_else(|_| std::env::temp_dir());
        let outside = canonical_temp.join("outside_workspace_zeroclaw");
        assert!(
            !policy.is_resolved_path_allowed(&outside),
            "path outside workspace must be blocked"
        );

        let _ = std::fs::remove_dir_all(&workspace);
    }

    #[test]
    fn resolved_path_blocks_root_escape() {
        let policy = SecurityPolicy {
            workspace_dir: PathBuf::from("/home/zeroclaw_user/project"),
            ..SecurityPolicy::default()
        };

        assert!(
            !policy.is_resolved_path_allowed(Path::new("/etc/passwd")),
            "resolved path to /etc/passwd must be blocked"
        );
        assert!(
            !policy.is_resolved_path_allowed(Path::new("/root/.bashrc")),
            "resolved path to /root/.bashrc must be blocked"
        );
    }

    #[cfg(unix)]
    #[test]
    fn resolved_path_blocks_symlink_escape() {
        use std::os::unix::fs::symlink;

        let root = std::env::temp_dir().join("zeroclaw_test_symlink_escape");
        let workspace = root.join("workspace");
        let outside = root.join("outside_target");

        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&workspace).unwrap();
        std::fs::create_dir_all(&outside).unwrap();

        // Create a symlink inside workspace pointing outside
        let link_path = workspace.join("escape_link");
        symlink(&outside, &link_path).unwrap();

        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };

        // The resolved symlink target should be outside workspace
        let resolved = link_path.canonicalize().unwrap();
        assert!(
            !policy.is_resolved_path_allowed(&resolved),
            "symlink-resolved path outside workspace must be blocked"
        );

        let _ = std::fs::remove_dir_all(&root);
    }

    /// Regression for the shell workspace-boundary bypass: a direct path-shaped
    /// command argument that reaches outside the workspace through an
    /// in-workspace symlink must be blocked. The leaf may not exist yet (the
    /// command is about to create it), so resolution must follow the symlinked
    /// ancestor.
    #[cfg(unix)]
    #[test]
    fn forbidden_path_argument_blocks_symlink_escape() {
        use std::os::unix::fs::symlink;

        let root = std::env::temp_dir().join(format!(
            "zeroclaw_test_shell_symlink_escape_{}",
            std::process::id()
        ));
        let workspace = root.join("workspace");
        let outside = root.join("outside_target");
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&workspace).unwrap();
        std::fs::create_dir_all(&outside).unwrap();

        // `link` inside the workspace points at the outside directory.
        symlink(&outside, workspace.join("link")).unwrap();

        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };

        // Writing a NEW file through the symlink (leaf does not exist yet).
        assert_eq!(
            policy
                .forbidden_workspace_path_argument("touch link/new.txt")
                .as_deref(),
            Some("link/new.txt"),
            "creating a file through an in-workspace symlink to outside must be blocked"
        );
        // Redirect target through the symlink.
        assert!(
            policy
                .forbidden_workspace_path_argument("echo hi > link/out.txt")
                .is_some(),
            "shell redirect through an escaping symlink must be blocked"
        );
        // Reading an existing file through the symlink.
        std::fs::write(outside.join("secret.txt"), b"x").unwrap();
        assert!(
            policy
                .forbidden_workspace_path_argument("cat link/secret.txt")
                .is_some(),
            "reading through an escaping symlink must be blocked"
        );
        assert_eq!(
            policy
                .forbidden_workspace_path_argument_for_shell(
                    r"cat link\secret.txt",
                    ShellDialect::PowerShell,
                )
                .as_deref(),
            Some(r"link\secret.txt"),
            "PowerShell backslash paths must retain workspace symlink resolution"
        );
        assert_eq!(
            policy
                .forbidden_workspace_path_argument_for_shell(
                    r"cat link\secret.txt",
                    ShellDialect::WindowsCmd,
                )
                .as_deref(),
            Some(r"link\secret.txt"),
            "cmd.exe backslash paths must retain workspace symlink resolution"
        );
        assert_eq!(
            policy
                .forbidden_workspace_path_argument_for_shell(
                    r"cat link\secret.txt",
                    ShellDialect::Posix,
                )
                .as_deref(),
            None,
            "POSIX backslash escapes must retain their existing tokenization"
        );

        // PowerShell single quotes preserve a path with spaces as one argument.
        // The path guard must inspect that complete path before the shell resolves
        // the in-workspace symlink.
        symlink(&outside, workspace.join("link dir")).unwrap();
        assert_eq!(
            policy
                .forbidden_workspace_path_argument_for_shell(
                    r"cat 'link dir\secret.txt'",
                    ShellDialect::PowerShell,
                )
                .as_deref(),
            Some(r"link dir\secret.txt"),
            "PowerShell quoted paths must retain symlink-boundary checks"
        );

        // A DANGLING symlink (its target directory does not exist yet) still
        // escapes on write, so it must be blocked even though it cannot be
        // `canonicalize`d.
        symlink(outside.join("nonexistent_dir"), workspace.join("dangling")).unwrap();
        assert!(
            policy
                .forbidden_workspace_path_argument("echo x > dangling/new.txt")
                .is_some(),
            "writing through a dangling symlink to outside must be blocked"
        );

        // A symlink CYCLE exhausts the resolver's hop budget. It must fail
        // CLOSED (block), not fall back to the pristine in-workspace path.
        symlink(workspace.join("cycle_b"), workspace.join("cycle_a")).unwrap();
        symlink(workspace.join("cycle_a"), workspace.join("cycle_b")).unwrap();
        assert!(
            policy
                .forbidden_workspace_path_argument("cat cycle_a/file")
                .is_some(),
            "an unresolvable symlink cycle must fail closed (be blocked)"
        );

        // Scoping check: the STRING-only guard (used by cron, whose cwd is NOT
        // the workspace) must NOT resolve symlinks, so it does not over-block a
        // workspace-relative path here. The resolve step is scoped to the
        // workspace-cwd variant used above.
        assert_eq!(
            policy.forbidden_path_argument("cat link/secret.txt"),
            None,
            "string-only guard must not resolve symlinks (keeps cron unaffected)"
        );

        let _ = std::fs::remove_dir_all(&root);
    }

    /// Non-regression: a symlink that stays INSIDE the workspace, and ordinary
    /// workspace-relative paths, must still be allowed after the resolve check.
    #[cfg(unix)]
    #[test]
    fn forbidden_path_argument_allows_in_workspace_paths() {
        use std::os::unix::fs::symlink;

        let root = std::env::temp_dir().join(format!(
            "zeroclaw_test_shell_in_workspace_{}",
            std::process::id()
        ));
        let workspace = root.join("workspace");
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(workspace.join("real_dir")).unwrap();
        std::fs::create_dir_all(workspace.join("sub")).unwrap();

        // `inside` points at another directory WITHIN the workspace.
        symlink(workspace.join("real_dir"), workspace.join("inside")).unwrap();

        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };

        assert_eq!(
            policy.forbidden_workspace_path_argument("touch inside/new.txt"),
            None,
            "an in-workspace symlink target must remain allowed"
        );
        assert_eq!(
            policy.forbidden_workspace_path_argument("touch sub/out.txt"),
            None,
            "an ordinary workspace-relative path must remain allowed"
        );
        assert_eq!(
            policy.forbidden_workspace_path_argument("echo hi > sub/out.txt"),
            None,
            "an ordinary workspace-relative redirect target must remain allowed"
        );

        let _ = std::fs::remove_dir_all(&root);
    }

    /// Non-regression: a path under an `allowed_roots_read_only` grant (outside
    /// the workspace) must stay READABLE - the command guard checks read OR
    /// write, so the resolve step must not drop read-only roots.
    #[cfg(unix)]
    #[test]
    fn forbidden_path_argument_allows_read_only_root() {
        let root = std::env::temp_dir().join(format!(
            "zeroclaw_test_shell_read_only_root_{}",
            std::process::id()
        ));
        let workspace = root.join("workspace");
        let shared = root.join("shared_readonly");
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&workspace).unwrap();
        std::fs::create_dir_all(&shared).unwrap();
        std::fs::write(shared.join("data.txt"), b"x").unwrap();

        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            allowed_roots_read_only: vec![shared.clone()],
            workspace_only: true,
            ..SecurityPolicy::default()
        };

        let cmd = format!("cat {}/data.txt", shared.display());
        assert_eq!(
            policy.forbidden_workspace_path_argument(&cmd),
            None,
            "reading under an allowed read-only root must remain allowed"
        );

        let _ = std::fs::remove_dir_all(&root);
    }

    #[cfg(unix)]
    #[test]
    fn allowed_roots_permits_paths_outside_workspace() {
        use std::os::unix::fs::symlink;

        let root = std::env::temp_dir().join("zeroclaw_test_allowed_roots");
        let workspace = root.join("workspace");
        let extra = root.join("extra_root");
        let extra_file = extra.join("data.txt");

        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&workspace).unwrap();
        std::fs::create_dir_all(&extra).unwrap();
        std::fs::write(&extra_file, "test").unwrap();

        // Symlink inside workspace pointing to extra root
        let link_path = workspace.join("link_to_extra");
        symlink(&extra, &link_path).unwrap();

        let resolved = link_path.join("data.txt").canonicalize().unwrap();

        // Without allowed_roots — blocked (symlink escape)
        let policy_without = SecurityPolicy {
            workspace_dir: workspace.clone(),
            allowed_roots: vec![],
            ..SecurityPolicy::default()
        };
        assert!(
            !policy_without.is_resolved_path_allowed(&resolved),
            "without allowed_roots, symlink target must be blocked"
        );

        // With allowed_roots — permitted
        let policy_with = SecurityPolicy {
            workspace_dir: workspace.clone(),
            allowed_roots: vec![extra.clone()],
            ..SecurityPolicy::default()
        };
        assert!(
            policy_with.is_resolved_path_allowed(&resolved),
            "with allowed_roots containing the target, symlink must be allowed"
        );

        // Unrelated path still blocked
        let unrelated = root.join("unrelated");
        std::fs::create_dir_all(&unrelated).unwrap();
        assert!(
            !policy_with.is_resolved_path_allowed(&unrelated.canonicalize().unwrap()),
            "paths outside workspace and allowed_roots must still be blocked"
        );

        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn is_path_allowed_blocks_null_bytes() {
        let policy = default_policy();
        assert!(
            !policy.is_path_allowed("file\0.txt"),
            "paths with null bytes must be blocked"
        );
    }

    #[test]
    fn is_path_allowed_blocks_url_encoded_traversal() {
        let policy = default_policy();
        assert!(
            !policy.is_path_allowed("..%2fetc%2fpasswd"),
            "URL-encoded path traversal must be blocked"
        );
        assert!(
            !policy.is_path_allowed("subdir%2f..%2f..%2fetc"),
            "URL-encoded parent dir traversal must be blocked"
        );
    }

    #[test]
    fn resolve_tool_path_expands_tilde() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/workspace"),
            ..SecurityPolicy::default()
        };
        let resolved = p.resolve_tool_path("~/Documents/file.txt");
        // Should expand ~ to home dir, not join with workspace
        assert!(resolved.is_absolute());
        assert!(!resolved.starts_with("/workspace"));
        assert!(resolved.to_string_lossy().ends_with("Documents/file.txt"));
    }

    #[test]
    fn resolve_tool_path_keeps_absolute() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/workspace"),
            ..SecurityPolicy::default()
        };
        let resolved = p.resolve_tool_path("/some/absolute/path");
        assert_eq!(resolved, PathBuf::from("/some/absolute/path"));
    }

    #[test]
    fn resolve_tool_path_joins_relative() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/workspace"),
            ..SecurityPolicy::default()
        };
        let resolved = p.resolve_tool_path("relative/path.txt");
        assert_eq!(resolved, PathBuf::from("/workspace/relative/path.txt"));
    }

    #[test]
    fn resolve_tool_path_normalizes_workspace_prefixed_relative_paths() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/zeroclaw-data/workspace"),
            ..SecurityPolicy::default()
        };
        let resolved = p.resolve_tool_path("zeroclaw-data/workspace/scripts/daily.py");
        assert_eq!(
            resolved,
            PathBuf::from("/zeroclaw-data/workspace/scripts/daily.py")
        );
    }

    #[test]
    fn resolve_tool_path_normalizes_windows_workspace_prefixed_relative_paths() {
        let workspace = PathBuf::from(r"C:\Users\me\.zeroclaw\agents\default\workspace");
        let p = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };
        let resolved =
            p.resolve_tool_path(r"Users\me\.zeroclaw\agents\default\workspace\nested\out.txt");

        assert_eq!(resolved, workspace.join("nested").join("out.txt"));
    }

    #[test]
    fn resolve_tool_path_does_not_normalize_mismatched_drive_prefixed_relative_paths() {
        let workspace = PathBuf::from(r"C:\Users\me\.zeroclaw\agents\default\workspace");
        let p = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };
        let resolved =
            p.resolve_tool_path(r"D:Users\me\.zeroclaw\agents\default\workspace\nested\out.txt");

        assert_ne!(resolved, workspace.join("nested").join("out.txt"));
    }

    #[test]
    fn is_under_allowed_root_matches_allowed_roots() {
        let p = SecurityPolicy {
            workspace_dir: tp_ws(),
            workspace_only: true,
            allowed_roots: vec![tp_proj(), tp_data()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_under_allowed_root(&format!("{}/myapp/src/main.rs", tp_proj().display())));
        assert!(p.is_under_allowed_root(&format!("{}/file.csv", tp_data().display())));
        assert!(!p.is_under_allowed_root(&tp_sys_sub("etc/passwd")));
        assert!(!p.is_under_allowed_root("relative/path"));
    }

    #[test]
    fn is_under_allowed_root_returns_false_for_empty_roots() {
        let p = SecurityPolicy {
            workspace_dir: tp_ws(),
            workspace_only: true,
            allowed_roots: vec![],
            ..SecurityPolicy::default()
        };
        assert!(!p.is_under_allowed_root(&format!("{}/any/path", tp_proj().display())));
    }

    // ── SecurityPolicy read/read-write split ────────────────────────

    #[test]
    fn is_under_read_only_allowed_root_matches_only_read_only_list() {
        let p = SecurityPolicy {
            workspace_dir: tp_ws(),
            workspace_only: true,
            allowed_roots: vec![tp_rw()],
            allowed_roots_read_only: vec![tp_ro()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_under_read_only_allowed_root(&format!("{}/notes.md", tp_ro().display())));
        assert!(!p.is_under_read_only_allowed_root(&format!("{}/file.csv", tp_rw().display())));
        assert!(!p.is_under_read_only_allowed_root(&tp_sys_sub("etc/passwd")));
        assert!(!p.is_under_read_only_allowed_root("relative"));
    }

    #[test]
    fn is_under_any_allowed_root_unions_read_only_and_read_write() {
        let p = SecurityPolicy {
            workspace_dir: tp_ws(),
            workspace_only: true,
            allowed_roots: vec![tp_rw()],
            allowed_roots_read_only: vec![tp_ro()],
            ..SecurityPolicy::default()
        };
        assert!(p.is_under_any_allowed_root(&format!("{}/file.csv", tp_rw().display())));
        assert!(p.is_under_any_allowed_root(&format!("{}/notes.md", tp_ro().display())));
        assert!(!p.is_under_any_allowed_root(&tp_sys_sub("etc/passwd")));
    }

    #[test]
    fn is_under_allowed_root_does_not_see_read_only_entries() {
        let p = SecurityPolicy {
            workspace_dir: tp_ws(),
            workspace_only: true,
            allowed_roots: vec![],
            allowed_roots_read_only: vec![tp_ro()],
            ..SecurityPolicy::default()
        };
        assert!(!p.is_under_allowed_root(&format!("{}/notes.md", tp_ro().display())));
        assert!(p.is_under_any_allowed_root(&format!("{}/notes.md", tp_ro().display())));
    }

    // ── SubAgent escalation validator ──────────────────────────────

    fn parent_policy_for_escalation_tests() -> SecurityPolicy {
        SecurityPolicy {
            workspace_dir: PathBuf::from("/workspace"),
            workspace_only: true,
            allowed_roots: vec![PathBuf::from("/projects"), PathBuf::from("/data")],
            allowed_roots_read_only: vec![PathBuf::from("/shared-docs")],
            allowed_commands: vec!["git".into(), "cargo".into(), "ls".into()],
            max_actions_per_hour: 100,
            max_cost_per_day_cents: 500,
            ..SecurityPolicy::default()
        }
    }

    #[test]
    fn ensure_no_escalation_accepts_identical_policy() {
        let parent = parent_policy_for_escalation_tests();
        let child = parent.clone();
        assert!(child.ensure_no_escalation_beyond(&parent).is_ok());
    }

    #[test]
    fn ensure_no_escalation_accepts_narrowed_child() {
        let parent = parent_policy_for_escalation_tests();
        let child = SecurityPolicy {
            allowed_roots: vec![PathBuf::from("/projects")],
            allowed_roots_read_only: vec![PathBuf::from("/shared-docs")],
            allowed_commands: vec!["git".into()],
            max_actions_per_hour: 50,
            max_cost_per_day_cents: 250,
            ..parent.clone()
        };
        assert!(child.ensure_no_escalation_beyond(&parent).is_ok());
    }

    #[test]
    fn ensure_no_escalation_accepts_case_equivalent_command_names() {
        let parent = SecurityPolicy {
            allowed_commands: vec!["Git".into(), "DOCKER".into()],
            ..parent_policy_for_escalation_tests()
        };
        let child = SecurityPolicy {
            allowed_commands: vec!["git".into(), "docker".into()],
            ..parent.clone()
        };

        assert!(child.ensure_no_escalation_beyond(&parent).is_ok());
    }

    #[test]
    fn ensure_no_escalation_keeps_command_paths_case_sensitive() {
        let parent = SecurityPolicy {
            allowed_commands: vec!["/usr/bin/Git".into()],
            ..parent_policy_for_escalation_tests()
        };
        let child = SecurityPolicy {
            allowed_commands: vec!["/usr/bin/git".into()],
            ..parent.clone()
        };

        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("case-distinct paths must not be treated as equivalent");
        assert!(matches!(
            err,
            EscalationViolation::CommandNotInParent { ref command }
            if command == "/usr/bin/git"
        ));
    }

    #[test]
    fn ensure_no_escalation_accepts_rw_root_downgraded_to_read_only_on_child() {
        // A SubAgent giving up its write privilege is a narrowing,
        // not an escalation.
        let parent = parent_policy_for_escalation_tests();
        let child = SecurityPolicy {
            allowed_roots: Vec::new(),
            allowed_roots_read_only: vec![PathBuf::from("/projects")],
            ..parent.clone()
        };
        assert!(child.ensure_no_escalation_beyond(&parent).is_ok());
    }

    #[test]
    fn ensure_no_escalation_rejects_new_rw_root_not_in_parent() {
        let parent = parent_policy_for_escalation_tests();
        let child = SecurityPolicy {
            allowed_roots: vec![PathBuf::from("/projects"), PathBuf::from("/secrets")],
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("new rw root must be rejected");
        assert!(matches!(
            err,
            EscalationViolation::ReadWriteRootNotInParent { ref path }
            if path == &PathBuf::from("/secrets")
        ));
    }

    #[test]
    fn ensure_no_escalation_rejects_new_read_only_root_not_in_parent() {
        let parent = parent_policy_for_escalation_tests();
        let child = SecurityPolicy {
            allowed_roots_read_only: vec![PathBuf::from("/etc")],
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("new read-only root must be rejected");
        assert!(matches!(
            err,
            EscalationViolation::ReadOnlyRootNotInParent { ref path }
            if path == &PathBuf::from("/etc")
        ));
    }

    #[test]
    fn ensure_no_escalation_rejects_new_command_not_in_parent() {
        let parent = parent_policy_for_escalation_tests();
        let child = SecurityPolicy {
            allowed_commands: vec!["git".into(), "rm".into()],
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("new command must be rejected");
        assert!(matches!(
            err,
            EscalationViolation::CommandNotInParent { ref command }
            if command == "rm"
        ));
    }

    #[test]
    fn ensure_no_escalation_rejects_workspace_only_disabled_by_child() {
        let parent = parent_policy_for_escalation_tests();
        let child = SecurityPolicy {
            workspace_only: false,
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("disabling workspace_only when parent enforces it must be rejected");
        assert_eq!(err, EscalationViolation::WorkspaceOnlyDisabledByChild);
    }

    #[test]
    fn ensure_no_escalation_rejects_higher_max_actions() {
        let parent = parent_policy_for_escalation_tests();
        let child = SecurityPolicy {
            max_actions_per_hour: 200,
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("higher max_actions_per_hour must be rejected");
        assert!(matches!(
            err,
            EscalationViolation::MaxActionsExceeded { child, parent } if child == 200 && parent == 100
        ));
    }

    #[test]
    fn ensure_no_escalation_rejects_higher_max_cost() {
        let parent = parent_policy_for_escalation_tests();
        let child = SecurityPolicy {
            max_cost_per_day_cents: 1000,
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("higher max_cost_per_day_cents must be rejected");
        assert!(matches!(
            err,
            EscalationViolation::MaxCostExceeded { child, parent } if child == 1000 && parent == 500
        ));
    }

    #[test]
    fn ensure_no_escalation_rejects_higher_autonomy() {
        let parent = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            ..parent_policy_for_escalation_tests()
        };
        let child = SecurityPolicy {
            autonomy: AutonomyLevel::Full,
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("Full child under Supervised parent must be rejected");
        assert!(matches!(
            err,
            EscalationViolation::AutonomyAboveParent { child, parent }
            if child == AutonomyLevel::Full && parent == AutonomyLevel::Supervised
        ));
    }

    #[test]
    fn ensure_no_escalation_accepts_subpath_narrowing_inside_parent_root() {
        // Parent grants /projects rw; child narrows to /projects/repo —
        // a containment relation, not exact equality. Must accept.
        let parent = parent_policy_for_escalation_tests();
        let child = SecurityPolicy {
            allowed_roots: vec![PathBuf::from("/projects/repo")],
            allowed_roots_read_only: vec![],
            ..parent.clone()
        };
        assert!(child.ensure_no_escalation_beyond(&parent).is_ok());
    }

    #[test]
    fn ensure_no_escalation_rejects_dropped_forbidden_path() {
        let parent = SecurityPolicy {
            forbidden_paths: vec!["/etc/secrets".into(), "/root".into()],
            ..parent_policy_for_escalation_tests()
        };
        let child = SecurityPolicy {
            forbidden_paths: vec!["/root".into()],
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("child dropping a parent's forbidden_paths entry must be rejected");
        assert!(matches!(
            err,
            EscalationViolation::ForbiddenPathDroppedByChild { ref path }
            if path == "/etc/secrets"
        ));
    }

    #[test]
    fn ensure_no_escalation_rejects_expanded_shell_env_passthrough() {
        let parent = SecurityPolicy {
            shell_env_passthrough: vec!["PATH".into()],
            ..parent_policy_for_escalation_tests()
        };
        let child = SecurityPolicy {
            shell_env_passthrough: vec!["PATH".into(), "AWS_SECRET_ACCESS_KEY".into()],
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("child adding a shell_env_passthrough entry must be rejected");
        assert!(matches!(
            err,
            EscalationViolation::ShellEnvPassthroughExpanded { ref variable }
            if variable == "AWS_SECRET_ACCESS_KEY"
        ));
    }

    #[test]
    fn ensure_no_escalation_rejects_higher_shell_timeout() {
        let parent = SecurityPolicy {
            shell_timeout_secs: 30,
            ..parent_policy_for_escalation_tests()
        };
        let child = SecurityPolicy {
            shell_timeout_secs: 600,
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("higher shell_timeout_secs must be rejected");
        assert!(matches!(
            err,
            EscalationViolation::ShellTimeoutExceeded { child, parent }
            if child == 600 && parent == 30
        ));
    }

    #[test]
    fn ensure_no_escalation_rejects_disabled_block_high_risk_commands() {
        let parent = SecurityPolicy {
            block_high_risk_commands: true,
            ..parent_policy_for_escalation_tests()
        };
        let child = SecurityPolicy {
            block_high_risk_commands: false,
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("child flipping block_high_risk_commands off must be rejected");
        assert_eq!(
            err,
            EscalationViolation::BlockHighRiskCommandsDisabledByChild
        );
    }

    #[test]
    fn ensure_no_escalation_rejects_disabled_require_approval() {
        let parent = SecurityPolicy {
            require_approval_for_medium_risk: true,
            ..parent_policy_for_escalation_tests()
        };
        let child = SecurityPolicy {
            require_approval_for_medium_risk: false,
            ..parent.clone()
        };
        let err = child
            .ensure_no_escalation_beyond(&parent)
            .expect_err("child flipping require_approval_for_medium_risk off must be rejected");
        assert_eq!(err, EscalationViolation::RequireApprovalDisabledByChild);
    }

    #[test]
    fn from_risk_profile_leaves_allowed_roots_read_only_empty() {
        // RiskProfileConfig has no read-only-roots concept; it's
        // populated by the multi-agent runtime when it builds the
        // per-agent policy from workspace.access.
        let profile = crate::schema::RiskProfileConfig {
            allowed_roots: vec!["/projects".to_string()],
            ..crate::schema::RiskProfileConfig::default()
        };
        let policy = SecurityPolicy::from_risk_profile(&profile, Path::new("/workspace"));
        assert_eq!(policy.allowed_roots, vec![PathBuf::from("/projects")]);
        assert!(
            policy.allowed_roots_read_only.is_empty(),
            "read-only roots come from workspace.access, not RiskProfileConfig"
        );
    }

    #[test]
    fn runtime_config_paths_are_protected() {
        let workspace = PathBuf::from("/tmp/zeroclaw-profile/workspace");
        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };
        let config_dir = workspace.parent().unwrap();

        assert!(policy.is_runtime_config_path(&config_dir.join("config.toml")));
        assert!(policy.is_runtime_config_path(&config_dir.join("config.toml.bak")));
        assert!(policy.is_runtime_config_path(&config_dir.join(".config.toml.tmp-1234")));
        // The active_workspace.toml marker file was retired with the
        // [workspace] block; protection is no longer required and not
        // claimed.
        assert!(!policy.is_runtime_config_path(&config_dir.join("active_workspace.toml")));
    }

    #[test]
    fn runtime_state_files_in_config_dir_are_protected() {
        let workspace = PathBuf::from("/tmp/zeroclaw-profile/workspace");
        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };
        let config_dir = workspace.parent().unwrap();

        // The state files are protected when they live in a runtime config dir.
        assert!(policy.is_runtime_config_path(&config_dir.join("estop-state.json")));
        assert!(policy.is_runtime_config_path(&config_dir.join("webauthn_credentials.json")));
        assert!(policy.is_runtime_config_path(&config_dir.join("otp-secret")));

        // Same names inside the workspace itself are NOT protected — those
        // are user-owned files; only the runtime-state files at config_dir
        // are sensitive.
        assert!(!policy.is_runtime_config_path(&workspace.join("estop-state.json")));
        assert!(!policy.is_runtime_config_path(&workspace.join("webauthn_credentials.json")));
        assert!(!policy.is_runtime_config_path(&workspace.join("otp-secret")));

        // Unrelated filenames are unaffected.
        assert!(!policy.is_runtime_config_path(&config_dir.join("notes.md")));
        assert!(!policy.is_runtime_config_path(&config_dir.join("agent-state.json")));
        assert!(!policy.is_runtime_config_path(&config_dir.join("otp-state.json")));
    }

    #[test]
    fn runtime_state_files_in_data_dir_are_protected() {
        let workspace = PathBuf::from("/tmp/zeroclaw-profile/workspace");
        let data_dir = PathBuf::from("/tmp/zeroclaw-profile/data");
        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            data_dir: Some(data_dir.clone()),
            ..SecurityPolicy::default()
        };

        // The WebAuthn credentials file under data_dir is protected.
        assert!(policy.is_runtime_config_path(&data_dir.join("webauthn_credentials.json")));

        // The same file under the workspace is not — that's a user-owned
        // file, not a WebAuthn store.
        assert!(!policy.is_runtime_config_path(&workspace.join("webauthn_credentials.json")));

        // Unrelated files under data_dir are unaffected.
        assert!(!policy.is_runtime_config_path(&data_dir.join("logs.txt")));
        assert!(!policy.is_runtime_config_path(&data_dir.join("cache.bin")));

        // Without `data_dir` set, the predicate falls back to the
        // config-dir-only behavior (matches the legacy flat layout where
        // everything lives under one tree).
        let legacy_policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };
        assert!(!legacy_policy.is_runtime_config_path(&PathBuf::from(
            "/tmp/zeroclaw-profile/data/webauthn_credentials.json"
        )));
    }

    #[test]
    fn workspace_files_are_not_runtime_config_paths() {
        let workspace = PathBuf::from("/tmp/zeroclaw-profile/workspace");
        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };
        let nested_dir = workspace.join("notes");

        assert!(!policy.is_runtime_config_path(&workspace.join("notes.txt")));
        assert!(!policy.is_runtime_config_path(&nested_dir.join("config.toml")));
    }

    #[test]
    fn is_runtime_config_path_protects_install_root_for_nested_agent_layout() {
        let install_root = PathBuf::from("/tmp/zeroclaw-install-nested");
        let workspace = install_root
            .join("agents")
            .join("agent-alpha")
            .join("workspace");
        let config_path = install_root.join("config.toml");

        let policy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            config_path: Some(config_path.clone()),
            ..SecurityPolicy::default()
        };

        // The real config at the install root is now protected.
        assert!(policy.is_runtime_config_path(&config_path));
        assert!(policy.is_runtime_config_path(&install_root.join("config.toml.bak")));
        assert!(policy.is_runtime_config_path(&install_root.join(".config.toml.tmp-42")));

        // Legacy fallback (config_path = None) only guards
        // `workspace.parent()`, so it misses the nested install-root
        // config. This is exactly the gap the config_path field closes.
        let legacy = SecurityPolicy {
            workspace_dir: workspace.clone(),
            ..SecurityPolicy::default()
        };
        assert!(!legacy.is_runtime_config_path(&config_path));

        // A config.toml inside the agent workspace is still not a runtime
        // config path under either policy.
        assert!(!policy.is_runtime_config_path(&workspace.join("config.toml")));
        assert!(!legacy.is_runtime_config_path(&workspace.join("config.toml")));
    }

    // ── prompt_summary ──────────────────────────────────────

    #[test]
    fn prompt_summary_includes_autonomy_level() {
        let p = default_policy();
        let summary = p.prompt_summary();
        assert!(
            summary.contains("Supervised"),
            "should mention autonomy level"
        );
    }

    #[test]
    fn prompt_summary_includes_workspace_boundary_when_workspace_only() {
        let p = SecurityPolicy {
            workspace_dir: PathBuf::from("/home/user/project"),
            workspace_only: true,
            ..SecurityPolicy::default()
        };
        let summary = p.prompt_summary();
        assert!(
            summary.contains("Workspace boundary"),
            "should mention workspace boundary"
        );
        assert!(
            summary.contains("/home/user/project"),
            "should mention workspace path"
        );
    }

    #[test]
    fn prompt_summary_omits_workspace_boundary_when_not_workspace_only() {
        let p = SecurityPolicy {
            workspace_only: false,
            ..SecurityPolicy::default()
        };
        let summary = p.prompt_summary();
        assert!(
            !summary.contains("Workspace boundary"),
            "should not mention workspace boundary"
        );
    }

    #[test]
    fn prompt_summary_includes_allowed_commands() {
        let p = SecurityPolicy {
            allowed_commands: vec!["git".into(), "ls".into()],
            ..SecurityPolicy::default()
        };
        let summary = p.prompt_summary();
        assert!(summary.contains("`git`"), "should list allowed commands");
        assert!(summary.contains("`ls`"), "should list allowed commands");
        assert!(
            summary.contains("You may execute these commands freely"),
            "should mention allowed commands positively"
        );
    }

    #[test]
    fn prompt_summary_includes_forbidden_paths() {
        let p = SecurityPolicy {
            workspace_only: false,
            forbidden_paths: vec!["/etc".into(), "~/.ssh".into()],
            ..SecurityPolicy::default()
        };
        let summary = p.prompt_summary();
        assert!(summary.contains("`/etc`"), "should list forbidden paths");
        assert!(summary.contains("`~/.ssh`"), "should list forbidden paths");
    }

    #[test]
    fn prompt_summary_includes_rate_limit() {
        let p = SecurityPolicy {
            max_actions_per_hour: 42,
            ..SecurityPolicy::default()
        };
        let summary = p.prompt_summary();
        assert!(summary.contains("42"), "should mention rate limit");
        assert!(
            summary.contains("actions per hour"),
            "should explain rate limit"
        );
    }

    #[test]
    fn prompt_summary_includes_risk_controls() {
        let p = SecurityPolicy {
            block_high_risk_commands: true,
            require_approval_for_medium_risk: true,
            ..SecurityPolicy::default()
        };
        let summary = p.prompt_summary();
        assert!(
            summary.contains("Exercise caution with destructive commands"),
            "should mention high-risk caution"
        );
        assert!(
            summary.contains("Medium-risk commands"),
            "should mention medium-risk approval"
        );
    }

    #[test]
    fn prompt_summary_includes_allowed_roots() {
        let p = SecurityPolicy {
            allowed_roots: vec![PathBuf::from("/shared/data"), PathBuf::from("/opt/tools")],
            ..SecurityPolicy::default()
        };
        let summary = p.prompt_summary();
        assert!(
            summary.contains("`/shared/data`"),
            "should list allowed roots"
        );
        assert!(
            summary.contains("`/opt/tools`"),
            "should list allowed roots"
        );
    }

    #[test]
    fn wildcard_with_block_high_risk_false_allows_everything() {
        let p = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            workspace_only: false,
            ..SecurityPolicy::default()
        };
        assert!(
            p.validate_command_execution("rm -rf /tmp/test", true)
                .is_ok()
        );
        assert!(p.validate_command_execution("nohup firefox", true).is_ok());
        assert!(
            p.validate_command_execution("ls /usr/bin/firefox", true)
                .is_ok()
        );
    }

    #[test]
    fn wildcard_with_block_high_risk_true_still_blocks() {
        // Ensure the existing safety net is preserved: wildcard + block_high_risk_commands=true
        // should still block high-risk commands.
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::Supervised,
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };
        let result = p.validate_command_execution("rm -rf /tmp/test", true);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("high-risk"));
    }

    // ── Shell guard bypass with wildcard + unblocked ──────────

    #[test]
    fn wildcard_unblocked_allows_backticks() {
        let p = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed("echo `whoami`"));
        assert!(p.is_command_allowed("ls `which git`"));
    }

    #[test]
    fn wildcard_unblocked_allows_dollar_paren() {
        let p = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed("echo $(cat /etc/hostname)"));
        assert!(p.is_command_allowed("echo $(rm -rf /)"));
    }

    #[test]
    fn wildcard_unblocked_allows_dollar_brace() {
        let p = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed("echo ${HOME}"));
        assert!(p.is_command_allowed("echo ${PATH}"));
    }

    #[test]
    fn wildcard_unblocked_allows_process_substitution() {
        let p = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed("diff <(ls dir1) <(ls dir2)"));
        assert!(p.is_command_allowed("tee >(grep error > errors.log)"));
    }

    #[test]
    fn approved_read_roots_returns_every_applicable_boundary() {
        let ws = tempfile::tempdir().unwrap();
        let ws_canon = ws.path().canonicalize().unwrap();
        let policy = SecurityPolicy {
            workspace_dir: ws.path().to_path_buf(),
            ..SecurityPolicy::default()
        };
        // A path inside the workspace is bounded by its canonical workspace root.
        assert_eq!(
            policy.approved_read_roots(&ws_canon.join("sub").join("a.txt")),
            vec![ws_canon.clone()]
        );
        assert_eq!(
            policy.approved_read_root(&ws_canon.join("sub").join("a.txt")),
            Some(ws_canon.clone())
        );
        // A path outside every allowlist has no bounded roots.
        let outside = tempfile::tempdir().unwrap();
        let outside_canon = outside.path().canonicalize().unwrap();
        assert!(
            policy
                .approved_read_roots(&outside_canon.join("x"))
                .is_empty()
        );
    }

    #[test]
    fn unrestricted_policy_has_no_discovery_boundary_but_preserves_handle_root() {
        let workspace = tempfile::tempdir().unwrap();
        let workspace_canon = workspace.path().canonicalize().unwrap();
        let policy = SecurityPolicy {
            workspace_dir: workspace.path().to_path_buf(),
            workspace_only: false,
            forbidden_paths: Vec::new(),
            ..SecurityPolicy::default()
        };
        let path = workspace_canon.join("nested").join("file.txt");

        assert!(policy.approved_read_roots(&path).is_empty());
        assert!(policy.approved_write_roots(&path).is_empty());
        assert_eq!(policy.approved_read_root(&path), Some(workspace_canon));
    }

    #[test]
    fn approved_read_roots_include_overlapping_readable_grants() {
        let parent = tempfile::tempdir().unwrap();
        let nested_workspace = parent.path().join("workspace");
        std::fs::create_dir(&nested_workspace).unwrap();
        let parent_canon = parent.path().canonicalize().unwrap();
        let workspace_canon = nested_workspace.canonicalize().unwrap();
        let policy = SecurityPolicy {
            workspace_dir: nested_workspace,
            allowed_roots: vec![parent.path().to_path_buf()],
            allowed_roots_read_only: vec![parent.path().to_path_buf()],
            ..SecurityPolicy::default()
        };
        assert_eq!(
            policy.approved_read_roots(&workspace_canon.join("doc.pdf")),
            vec![workspace_canon, parent_canon]
        );
    }

    #[test]
    fn approved_write_roots_exclude_read_only_parent_grants() {
        let workspace = tempfile::tempdir().unwrap();
        let parent = tempfile::tempdir().unwrap();
        let child = parent.path().join("writable-child");
        std::fs::create_dir(&child).unwrap();
        let parent_canon = parent.path().canonicalize().unwrap();
        let child_canon = child.canonicalize().unwrap();
        let policy = SecurityPolicy {
            workspace_dir: workspace.path().to_path_buf(),
            allowed_roots: vec![child.clone()],
            allowed_roots_read_only: vec![parent.path().to_path_buf()],
            ..SecurityPolicy::default()
        };

        assert_eq!(
            policy.approved_read_roots(&child_canon.join("file")),
            vec![child_canon.clone(), parent_canon]
        );
        assert_eq!(
            policy.approved_write_roots(&child_canon.join("file")),
            vec![child_canon]
        );
    }

    #[test]
    fn wildcard_unblocked_allows_pipes_and_chains() {
        let p = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        assert!(p.is_command_allowed("ps aux | grep python | wc -l"));
        assert!(p.is_command_allowed("echo hello && echo world"));
    }

    #[test]
    fn wildcard_blocked_still_runs_shell_guard() {
        // allowed_commands=["*"] but block_high_risk_commands=true (default)
        // — the shell expansion guard must still fire.
        let p = SecurityPolicy {
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_command_allowed("echo `whoami`"));
        assert!(!p.is_command_allowed("echo $(cat /etc/passwd)"));
        assert!(!p.is_command_allowed("echo ${HOME}"));
        assert!(!p.is_command_allowed("diff <(ls dir1) <(ls dir2)"));
    }

    #[test]
    fn specific_allowlist_still_runs_shell_guard() {
        // Non-wildcard allowlist — the guard must always run regardless
        // of block_high_risk_commands.
        let p = SecurityPolicy {
            allowed_commands: vec!["echo".into(), "ls".into(), "diff".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_command_allowed("echo `whoami`"));
        assert!(!p.is_command_allowed("echo $(cat /etc/passwd)"));
        assert!(!p.is_command_allowed("echo ${HOME}"));
        assert!(!p.is_command_allowed("diff <(ls dir1) <(ls dir2)"));
    }

    #[test]
    fn specific_allowlist_with_block_true_still_runs_shell_guard() {
        let p = SecurityPolicy {
            allowed_commands: vec!["echo".into(), "ls".into()],
            block_high_risk_commands: true,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_command_allowed("echo `whoami`"));
        assert!(!p.is_command_allowed("echo $(rm -rf /)"));
        assert!(!p.is_command_allowed("echo ${HOME}"));
    }

    #[test]
    fn wildcard_unblocked_readonly_still_blocked() {
        // Even with wildcard + unblocked, ReadOnly trumps everything.
        let p = SecurityPolicy {
            autonomy: AutonomyLevel::ReadOnly,
            allowed_commands: vec!["*".into()],
            block_high_risk_commands: false,
            ..SecurityPolicy::default()
        };
        assert!(!p.is_command_allowed("ls"));
        assert!(!p.is_command_allowed("echo `whoami`"));
    }

    #[test]
    fn per_sender_tracker_isolates_counts() {
        let t = PerSenderTracker::new();
        // sender A rejects its third call without recording it
        assert!(t.record_within("chat_a", 2)); // count=1
        assert!(t.record_within("chat_a", 2)); // count=2
        assert!(!t.record_within("chat_a", 2)); // remains count=2
        // sender B is unaffected — its bucket is empty
        assert!(t.record_within("chat_b", 2)); // count=1
        assert!(t.record_within("chat_b", 2)); // count=2
        assert!(!t.record_within("chat_b", 2)); // remains count=2
    }

    #[test]
    fn per_sender_tracker_global_key_fallback() {
        let t = PerSenderTracker::new();
        assert!(!t.is_exhausted(PerSenderTracker::GLOBAL_KEY, 1));
        t.record_within(PerSenderTracker::GLOBAL_KEY, u32::MAX);
        // after 1 action, count=1 ≥ 1 → exhausted at max=1
        assert!(t.is_exhausted(PerSenderTracker::GLOBAL_KEY, 1));
    }

    #[test]
    fn per_sender_tracker_is_exhausted_reads_without_spurious_insert() {
        let t = PerSenderTracker::new();
        // Key "ghost" has never been recorded — should not be exhausted at max=1
        assert!(!t.is_exhausted("ghost", 1));
    }

    #[test]
    fn attached_short_option_value_handles_multibyte_token() {
        // A multibyte char immediately after the dash must not panic on a
        // byte-index slice. Regression for a char-boundary abort.
        assert_eq!(
            attached_short_option_value("-é/etc/passwd"),
            Some("/etc/passwd")
        );
        assert_eq!(attached_short_option_value("-—"), None);
        assert_eq!(
            attached_short_option_value("-f/etc/passwd"),
            Some("/etc/passwd")
        );
        assert_eq!(attached_short_option_value("-f"), None);
        assert_eq!(attached_short_option_value("--long"), None);
    }
}
