//! Shared wasmtime component-model plumbing for all plugin worlds.

use anyhow::Result;
use std::collections::VecDeque;
use std::sync::{Arc, Mutex, OnceLock};
use std::time::Duration;
use wasmtime::component::{Component, ResourceTable};
use wasmtime::{Config, Engine, Store};
use wasmtime_wasi::{WasiCtx, WasiCtxView, WasiView};
use wasmtime_wasi_http::{WasiHttpCtx, WasiHttpCtxView, WasiHttpView};

use crate::component_limits::PluginResourceLimiter;
use crate::config::ResolvedPluginConfig;
use crate::egress::{AuthorizedEgress, EgressError, EgressHostService, build_tls_client_config};
use crate::error::PluginError;
use crate::host::AdmittedComponent;
use crate::instance::PluginInstanceScope;
use crate::services::{
    ConfigLookupError, PluginHostServices, PluginStateError, PluginStateKey, PluginStateValue,
    SecretLookupError,
};
use crate::wasi_http::PluginEgressHooks;
use crate::{PluginCapability, PluginPermission};

/// Hard safety ceiling for ZeroClaw-owned WIT imports in one service frame.
///
/// A fixed limit avoids retaining live operator configuration in warm stores.
const MAX_HOST_CALLS_PER_FRAME: u64 = 1_000;

#[derive(Clone, Default)]
pub struct InboundQueue {
    inner: Arc<Mutex<VecDeque<HostInboundMessage>>>,
}

/// A host-side inbound message, decoupled from any one WIT world's generated
/// type. The channel world's `Host` impl converts this into its bindings type
/// when the plugin polls.
#[derive(Clone, Debug, Default)]
pub struct HostInboundMessage {
    pub id: String,
    pub sender: String,
    pub reply_target: String,
    pub content: String,
    pub channel: String,
    pub channel_alias: Option<String>,
    pub timestamp: u64,
    pub thread_ts: Option<String>,
    pub interruption_scope_id: Option<String>,
    pub subject: Option<String>,
}

impl InboundQueue {
    /// Push a received message onto the queue for the plugin to drain. A
    /// poisoned lock is recovered rather than swallowed, so a panic in one
    /// producer cannot silently stop every later inbound message from landing.
    pub fn enqueue(&self, msg: HostInboundMessage) {
        let mut q = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        q.push_back(msg);
    }

    /// Pop the next queued message, or `None` when empty. Recovers a poisoned
    /// lock so a producer panic does not strand the queued backlog.
    pub fn poll(&self) -> Option<HostInboundMessage> {
        let mut q = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        q.pop_front()
    }

    /// Count of messages currently waiting. Recovers a poisoned lock so the
    /// drain side keeps reporting real depth after a producer panic.
    pub fn pending(&self) -> u32 {
        let q = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        q.len() as u32
    }
}

/// Resolved execution and allocation limits applied to a plugin store. The host
/// builds this from `[plugins.limits]` config and hands it to `new_store`.
/// There is deliberately no `Default`: limits always come from the config
/// registry so no code path can construct an unsandboxed store by accident.
#[derive(Debug, Clone, Copy)]
pub struct PluginLimits {
    pub call_fuel: u64,
    pub max_memory_bytes: usize,
    pub max_table_elements: usize,
    pub max_instances: usize,
    /// Wall-clock ceiling for one guest export, including awaited host work.
    pub call_timeout: Duration,
}

#[cfg(test)]
pub(crate) fn test_limits(call_fuel: u64) -> PluginLimits {
    PluginLimits {
        call_fuel,
        max_memory_bytes: 1024 * 1024,
        max_table_elements: 100,
        max_instances: 10,
        call_timeout: Duration::from_secs(30),
    }
}

/// Complete host-side inputs for constructing one scoped plugin store.
///
/// The immutable instance scope supplies identity and effective grants. Limits
/// remain a per-store materialized view of canonical host configuration, while
/// the inbound queue is a process-local resource owned by this store.
pub(crate) struct PluginStoreSpec {
    scope: PluginInstanceScope,
    services: PluginHostServices,
    limits: PluginLimits,
    inbound: InboundQueue,
    http: bool,
    egress: Option<EgressHostService>,
}

impl PluginStoreSpec {
    /// Create a store specification with no host-fed inbound messages.
    #[must_use]
    pub(crate) fn new(
        scope: PluginInstanceScope,
        services: PluginHostServices,
        limits: PluginLimits,
    ) -> Self {
        Self {
            scope,
            services,
            limits,
            inbound: InboundQueue::default(),
            http: false,
            egress: None,
        }
    }

    /// Attach HTTP only when this scope was granted `HttpClient`.
    ///
    /// Adapters opt into the surface explicitly. This prevents adding a grant
    /// to a scope from silently widening an adapter that has not implemented
    /// and tested the corresponding component boundary.
    ///
    /// This grants the *surface*, never the *reach*. Without a service from
    /// [`Self::with_egress_policy`] the store still links `wasi:http` and still
    /// answers `http_enabled()`, but every request the guest issues is denied
    /// Keeping the linker attached rather than dropping it is what
    /// keeps store construction and the store/linker coherence check stable
    /// while the answer to "may this instance reach the network" moves to the
    /// host-owned egress boundary.
    #[must_use]
    pub(crate) fn with_granted_http(mut self) -> Self {
        self.http = self.scope.grants().allows(PluginPermission::HttpClient);
        self
    }

    /// Attach the host-owned egress authority for this instance.
    ///
    /// `None` (the default) means deny-by-default: no destination is reachable.
    /// The service is shared, not per-store — cloning it into several stores is
    /// what makes one connection budget span every store of one instance.
    #[must_use]
    pub(crate) fn with_egress_policy(mut self, egress: Option<EgressHostService>) -> Self {
        self.egress = egress;
        self
    }

    /// Attach the queue shared with a host-owned inbound listener.
    #[must_use]
    pub(crate) fn with_inbound(mut self, inbound: InboundQueue) -> Self {
        self.inbound = inbound;
        self
    }
}

pub mod bindings {
    pub mod tool {
        wasmtime::component::bindgen!({
            world: "tool-plugin",
            path: "wit/v0",
            imports: {
                default: async,
                "zeroclaw:plugin/websocket": async | trappable,
            },
            exports: { default: async },
            with: {
                "zeroclaw:plugin/sockets.connection": crate::sockets::SocketConnection,
                "zeroclaw:plugin/websocket.connection": crate::component_websocket::WebSocketConnection,
            },
        });
    }
    pub mod channel {
        wasmtime::component::bindgen!({
            world: "channel-plugin",
            path: "wit/v0",
            imports: {
                default: async,
                "zeroclaw:plugin/websocket": async | trappable,
            },
            exports: { default: async },
            with: {
                "zeroclaw:plugin/sockets.connection": crate::sockets::SocketConnection,
                "zeroclaw:plugin/websocket.connection": crate::component_websocket::WebSocketConnection,
            },
        });
    }
    pub mod memory {
        wasmtime::component::bindgen!({
            world: "memory-plugin",
            path: "wit/v0",
            imports: { default: async },
            exports: { default: async },
        });
    }
}

pub struct PluginState {
    scope: PluginInstanceScope,
    services: PluginHostServices,
    call_config: CallConfig,
    host_calls_remaining: u64,
    wasi: WasiCtx,
    table: ResourceTable,
    http: Option<HttpSurface>,
    /// The host-owned egress authority for socket and WebSocket imports.
    /// `None` is deny-by-default, exactly as for `wasi:http`.
    egress: Option<EgressHostService>,
    inbound: InboundQueue,
    limits: PluginResourceLimiter,
    fuel_per_call: u64,
    call_timeout: Duration,
}

/// The outbound-HTTP half of a store: wasmtime's per-store context paired with
/// ZeroClaw's policy hooks. They are one field because `WasiHttpCtxView` needs
/// both, and because a context without hooks would be the unmediated `wasi:http`
/// the host-owned egress boundary exists to remove.
struct HttpSurface {
    ctx: WasiHttpCtx,
    hooks: PluginEgressHooks,
}

/// The host-dispatched service frame that is currently active.
///
/// This is the authority for phase-specific imports. Keeping it in the same
/// state machine as the resolved config prevents a separate boolean grant from
/// drifting away from the config revision it is meant to protect.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum PluginCallPhase {
    Standard,
    ToolExecute,
    ChannelService,
}

/// Lazily materialized config for exactly one host-dispatched service frame.
///
/// This is a transient view, not another canonical config store. It is cleared
/// after every frame so live resolvers observe changes on their next invocation
/// while all reads within one frame share one revision.
enum CallConfig {
    Inactive,
    Unresolved(PluginCallPhase),
    Resolved(PluginCallPhase, ResolvedPluginConfig),
    Failed(PluginCallPhase),
}

impl CallConfig {
    fn phase(&self) -> Option<PluginCallPhase> {
        match self {
            Self::Inactive => None,
            Self::Unresolved(phase) | Self::Resolved(phase, _) | Self::Failed(phase) => {
                Some(*phase)
            }
        }
    }
}

/// Warm component state held between export calls.
pub(crate) type WarmPluginState<Bindings> = Option<(Store<PluginState>, Bindings)>;

impl PluginState {
    /// Build store state from one typed, host-issued specification.
    /// `HttpClient` is the only grant that can widen the host surface here, and
    /// only after the adapter calls [`PluginStoreSpec::with_granted_http`]. That
    /// opt-in attaches a `WasiHttpCtx` so the gated `wasi:http` import can be
    /// linked. Other grants are consumed by adapters or host services where
    /// implemented and do not widen ambient WASI.
    pub(crate) fn new(spec: PluginStoreSpec) -> Self {
        let http = spec.http.then(|| HttpSurface {
            ctx: WasiHttpCtx::new(),
            hooks: PluginEgressHooks::new(spec.scope.clone(), spec.egress.clone()),
        });
        Self {
            scope: spec.scope,
            services: spec.services,
            call_config: CallConfig::Inactive,
            host_calls_remaining: 0,
            wasi: WasiCtx::builder().build(),
            table: ResourceTable::new(),
            http,
            egress: spec.egress,
            inbound: spec.inbound,
            limits: PluginResourceLimiter::new(spec.limits),
            fuel_per_call: spec.limits.call_fuel,
            call_timeout: spec.limits.call_timeout,
        }
    }

    /// Immutable host-owned identity and authority for this store.
    #[must_use]
    pub(crate) fn scope(&self) -> &PluginInstanceScope {
        &self.scope
    }

    /// The egress authority transport imports authorize through, or `None`
    /// when this instance has no reach at all.
    #[must_use]
    pub(crate) fn egress_service(&self) -> Option<EgressHostService> {
        self.egress.clone()
    }

    /// The store's resource table, which holds host-owned connection resources.
    #[must_use]
    pub(crate) fn resource_table(&self) -> &ResourceTable {
        &self.table
    }

    /// Mutable access to the store's resource table.
    pub(crate) fn resource_table_mut(&mut self) -> &mut ResourceTable {
        &mut self.table
    }

    /// Whether the admitted scope holds `permission`. Optional host imports are
    /// linked from this answer, so a grant and an import cannot disagree.
    #[must_use]
    pub(crate) fn permission_enabled(&self, permission: PluginPermission) -> bool {
        self.scope.grants().allows(permission)
    }

    /// Build the TLS client configuration for one authorized connection.
    ///
    /// Starts from the roots plugin HTTPS trusts, unless the authorization's TLS
    /// profile keeps no system roots, and applies that profile, reading any
    /// referenced certificate material from this frame's resolved config. The
    /// material is host-consumed: this read does not go through the
    /// guest-facing `secrets` gate, and the runtime marks every
    /// profile-referenced property host-only so that gate refuses it.
    ///
    /// The configuration is built for the one connection that asked for it and
    /// is owned by that connection, which drops it on close. Nothing else keeps
    /// it, and the profile's CA and client-identity material lives only in this
    /// frame's transient config view, so a rotation reaches connections opened
    /// in later frames. System roots are the exception: they come from the
    /// plugin HTTPS trust assembly, which is read once per process.
    ///
    /// # Errors
    ///
    /// Returns [`EgressError`] for an authorization issued under another
    /// admission than this store's, including one with an equal logical
    /// instance ID, trust roots that could not be assembled in time, an
    /// unavailable referenced secret, or invalid certificate material.
    pub(crate) async fn tls_client_config(
        &mut self,
        authorized: &AuthorizedEgress,
    ) -> Result<Arc<rustls::ClientConfig>, EgressError> {
        // Admission issuance, not logical identity: a separately admitted scope
        // can share this store's instance ID while carrying different grants.
        // Checked before any trust root, config, or secret is read.
        if !authorized.request().scope().same_issuance(&self.scope) {
            return Err(EgressError::AuthorizationScopeMismatch);
        }
        let profile = authorized.tls_profile();
        if profile.is_some_and(|profile| {
            profile.custom_ca().is_some() || profile.client_identity().is_some()
        }) {
            self.with_call_config(|config| config.ensure_tls_authorization(authorized))
                .map_err(|_| EgressError::TlsConfigMismatch)??;
        }
        // A profile that keeps no system roots never reads them, so it neither
        // waits on nor depends on the machine-store assembly.
        let roots = if crate::egress::trusts_system_roots(profile) {
            crate::wasi_http::plugin_trust_roots(
                tokio::time::Instant::now() + crate::egress::EGRESS_CONNECT_DEADLINE,
            )
            .await
            .map_err(|_| {
                EgressError::PolicyUnavailable("plugin trust roots unavailable".to_string())
            })?
        } else {
            Arc::new(rustls::RootCertStore::empty())
        };
        if profile.is_some_and(|profile| {
            profile.custom_ca().is_some() || profile.client_identity().is_some()
        }) {
            self.with_call_config(|config| config.tls_client_config(authorized, &roots))
                .map_err(|_| EgressError::TlsConfigMismatch)?
        } else {
            build_tls_client_config(profile, &roots, |_| Err(EgressError::TlsConfigMismatch))
        }
    }

    fn start_call(&mut self, phase: PluginCallPhase) {
        self.call_config = CallConfig::Unresolved(phase);
        self.host_calls_remaining = MAX_HOST_CALLS_PER_FRAME;
    }

    /// Open a frame without a store: a service frame for this instance's
    /// capability when `service` is set, otherwise a metadata frame.
    #[cfg(test)]
    pub(crate) fn start_test_frame(&mut self, service: bool) {
        let phase = match (service, self.scope.id().capability()) {
            (true, PluginCapability::Tool) => PluginCallPhase::ToolExecute,
            (true, PluginCapability::Channel) => PluginCallPhase::ChannelService,
            _ => PluginCallPhase::Standard,
        };
        self.start_call(phase);
    }

    fn finish_call(&mut self) {
        self.call_config = CallConfig::Inactive;
        self.host_calls_remaining = 0;
    }

    fn with_call_config<T>(
        &mut self,
        use_config: impl FnOnce(&ResolvedPluginConfig) -> T,
    ) -> Result<T, PluginError> {
        let phase = self.call_config.phase().ok_or_else(|| {
            PluginError::InvalidConfig(
                "plugin host service called outside an active invocation frame".to_string(),
            )
        })?;
        if matches!(self.call_config, CallConfig::Unresolved(_)) {
            match self.services.resolve_config(&self.scope) {
                Ok(config) => self.call_config = CallConfig::Resolved(phase, config),
                Err(error) => {
                    self.call_config = CallConfig::Failed(phase);
                    return Err(error);
                }
            }
        }
        match &self.call_config {
            CallConfig::Resolved(_, config) => Ok(use_config(config)),
            CallConfig::Inactive | CallConfig::Unresolved(_) | CallConfig::Failed(_) => Err(
                PluginError::InvalidConfig("plugin call config could not be resolved".to_string()),
            ),
        }
    }

    /// Resolve public configuration lazily for the active service frame.
    pub(crate) fn public_config(&mut self) -> Result<serde_json::Value, PluginError> {
        self.with_call_config(|config| config.public_json().clone())
    }

    /// Charge one ZeroClaw-owned host import against the active call budget.
    pub(crate) fn charge_host_call(&mut self) -> bool {
        if matches!(self.call_config, CallConfig::Inactive) || self.host_calls_remaining == 0 {
            return false;
        }
        self.host_calls_remaining -= 1;
        true
    }

    /// Whether the active frame may use this instance's scoped host services.
    ///
    /// Durable state, secrets, and new socket or WebSocket connections all
    /// require it, so a metadata probe cannot reach the network or storage.
    pub(crate) fn instance_services_enabled(&self) -> bool {
        matches!(
            (self.call_config.phase(), self.scope.id().capability()),
            (Some(PluginCallPhase::ToolExecute), PluginCapability::Tool)
                | (
                    Some(PluginCallPhase::ChannelService),
                    PluginCapability::Channel
                )
        )
    }

    /// Resolve the typed public object for a guest host-service call.
    pub(crate) fn guest_public_config(&mut self) -> Result<serde_json::Value, ConfigLookupError> {
        if !self.charge_host_call()
            || !matches!(
                (self.call_config.phase(), self.scope.id().capability()),
                (
                    Some(PluginCallPhase::ChannelService),
                    PluginCapability::Channel
                )
            )
        {
            return Err(ConfigLookupError::Unavailable);
        }
        if !self.scope.grants().allows(PluginPermission::ConfigRead) {
            return Err(ConfigLookupError::AccessDenied);
        }
        self.public_config()
            .map_err(|_| ConfigLookupError::Unavailable)
    }

    /// Resolve one secret from the same config revision used by this call.
    pub(crate) fn secret(&mut self, name: &str) -> Result<String, SecretLookupError> {
        if !self.charge_host_call() {
            return Err(SecretLookupError::Unavailable);
        }
        if !self.instance_services_enabled() {
            return Err(SecretLookupError::Unavailable);
        }
        if !self.scope.grants().allows(PluginPermission::ConfigRead) {
            return Err(SecretLookupError::AccessDenied);
        }
        self.with_call_config(|config| {
            if config.is_host_only(name) {
                return Err(SecretLookupError::AccessDenied);
            }
            config
                .secret(name)
                .map(ToOwned::to_owned)
                .ok_or(SecretLookupError::NotFound)
        })
        .map_err(|_| SecretLookupError::Unavailable)?
    }

    /// Read durable state under the immutable store-owned instance scope.
    pub(crate) async fn state_get(
        &mut self,
        key: String,
    ) -> Result<Option<PluginStateValue>, PluginStateError> {
        if !self.charge_host_call() || !self.instance_services_enabled() {
            return Err(PluginStateError::Unavailable);
        }
        if !self.scope.grants().allows(PluginPermission::StateRead) {
            return Err(PluginStateError::AccessDenied);
        }
        let key = PluginStateKey::parse(key)?;
        let state = self.services.state().clone();
        let scope = self.scope.clone();
        state.get(&scope, &key).await
    }

    /// Commit durable state with compare-and-swap semantics.
    pub(crate) async fn state_put(
        &mut self,
        key: String,
        value: Vec<u8>,
        expected_revision: Option<u64>,
    ) -> Result<u64, PluginStateError> {
        if !self.charge_host_call() || !self.instance_services_enabled() {
            return Err(PluginStateError::Unavailable);
        }
        if !self.scope.grants().allows(PluginPermission::StateWrite) {
            return Err(PluginStateError::AccessDenied);
        }
        let key = PluginStateKey::parse(key)?;
        let state = self.services.state().clone();
        let scope = self.scope.clone();
        state.put(&scope, &key, &value, expected_revision).await
    }

    /// Delete durable state with compare-and-swap semantics.
    pub(crate) async fn state_delete(
        &mut self,
        key: String,
        expected_revision: u64,
    ) -> Result<(), PluginStateError> {
        if !self.charge_host_call() || !self.instance_services_enabled() {
            return Err(PluginStateError::Unavailable);
        }
        if !self.scope.grants().allows(PluginPermission::StateWrite) {
            return Err(PluginStateError::AccessDenied);
        }
        let key = PluginStateKey::parse(key)?;
        let state = self.services.state().clone();
        let scope = self.scope.clone();
        state.delete(&scope, &key, expected_revision).await
    }

    /// Whether this state was built with outbound HTTP attached.
    pub(crate) fn http_enabled(&self) -> bool {
        self.http.is_some()
    }

    /// The inbound queue this plugin drains. Host code holds a clone to enqueue.
    pub(crate) fn inbound(&self) -> &InboundQueue {
        &self.inbound
    }

    /// Host-owned wall-clock ceiling for one guest export call.
    pub(crate) fn call_timeout(&self) -> Duration {
        self.call_timeout
    }
}

impl WasiView for PluginState {
    fn ctx(&mut self) -> WasiCtxView<'_> {
        WasiCtxView {
            ctx: &mut self.wasi,
            table: &mut self.table,
        }
    }
}

impl WasiHttpView for PluginState {
    /// Hand `wasi:http` ZeroClaw's policy hooks instead of
    /// `wasmtime_wasi_http::default_hooks()`. The default hooks send every
    /// request the guest asks for; these submit it to the host-owned egress
    /// boundary first and own the connect (see [`crate::wasi_http`]).
    fn http(&mut self) -> WasiHttpCtxView<'_> {
        let surface = self
            .http
            .as_mut()
            .expect("wasi:http called on a plugin without the HttpClient permission");
        WasiHttpCtxView {
            ctx: &mut surface.ctx,
            table: &mut self.table,
            hooks: &mut surface.hooks,
        }
    }
}

/// Wire the sandboxed WASI p2 surface into a plugin linker.
pub fn add_wasi(linker: &mut wasmtime::component::Linker<PluginState>) -> Result<()> {
    wt(
        wasmtime_wasi::p2::add_to_linker_async(linker),
        "failed to add WASI imports to plugin linker",
    )
}

/// Wire the outbound `wasi:http` surface into a plugin linker. Only call this
/// for a linker that backs stores built with the `HttpClient` permission; the
/// store's `WasiHttpView::http` panics otherwise, which keeps a permission
/// mismatch from silently granting network access.
pub fn add_wasi_http(linker: &mut wasmtime::component::Linker<PluginState>) -> Result<()> {
    wt(
        wasmtime_wasi_http::p2::add_only_http_to_linker_async(linker),
        "failed to add wasi:http imports to plugin linker",
    )
}

/// Which optional host imports a store's linker exposes, derived from the
/// store's own admitted scope. Also the key for cached linkers, which bounds
/// the cache by these flags.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub(crate) struct OptionalImports {
    pub(crate) http: bool,
    pub(crate) sockets: bool,
    pub(crate) websocket: bool,
}

impl OptionalImports {
    /// The imports `state`'s scope authorizes.
    pub(crate) fn for_store(state: &PluginState) -> Self {
        Self {
            http: state.http_enabled(),
            sockets: state.permission_enabled(PluginPermission::SocketClient),
            websocket: state.permission_enabled(PluginPermission::WebSocketClient),
        }
    }
}

/// Refuse to instantiate when a linker's optional imports differ from what the
/// store's scope grants. The linker is derived from the same scope, so this is
/// defense in depth: a future caller cannot pair a store with a wider linker.
pub(crate) fn ensure_imports_coherent(
    store: &Store<PluginState>,
    imports: OptionalImports,
) -> Result<()> {
    ensure_http_coherent(store, imports.http)?;
    ensure_permission_coherent(
        store,
        PluginPermission::SocketClient,
        "zeroclaw:plugin/sockets",
        imports.sockets,
    )?;
    ensure_permission_coherent(
        store,
        PluginPermission::WebSocketClient,
        "zeroclaw:plugin/websocket",
        imports.websocket,
    )
}

/// Refuse an optional import whose presence differs from the store's grant.
pub(crate) fn ensure_permission_coherent(
    store: &Store<PluginState>,
    permission: PluginPermission,
    import_name: &str,
    linker_has_import: bool,
) -> Result<()> {
    let granted = store.data().permission_enabled(permission);
    if granted != linker_has_import {
        anyhow::bail!(
            "plugin store/linker mismatch for {import_name}: store {permission:?}={granted}, \
             linker import={linker_has_import}; refusing to instantiate"
        );
    }
    Ok(())
}

pub fn ensure_http_coherent(store: &Store<PluginState>, linker_has_http: bool) -> Result<()> {
    let store_has_http = store.data().http_enabled();
    if store_has_http != linker_has_http {
        anyhow::bail!(
            "plugin store/linker http mismatch: store HttpClient={store_has_http}, \
             linker wasi:http={linker_has_http}; refusing to instantiate"
        );
    }
    Ok(())
}

pub fn engine() -> &'static Engine {
    static ENGINE: OnceLock<Engine> = OnceLock::new();
    ENGINE.get_or_init(|| {
        let mut config = Config::new();
        config.consume_fuel(true);
        Engine::new(&config).expect("async-capable wasmtime engine")
    })
}

/// Build a Wasmtime store whose imports are derived from one admitted scope.
pub(crate) fn new_store(spec: PluginStoreSpec) -> Store<PluginState> {
    let call_fuel = spec.limits.call_fuel;
    let state = PluginState::new(spec);
    let mut store = Store::new(engine(), state);
    store.limiter(|state| &mut state.limits);
    set_call_fuel(&mut store, call_fuel);
    // Tokio deadlines can only be observed while the Wasmtime future yields.
    // All host imports are async; this additionally prevents uninterrupted
    // guest computation from starving the deadline until its full fuel budget
    // is exhausted. Invariant: `engine()` unconditionally enables fuel and the
    // interval literal is non-zero, which are the only documented error cases.
    store
        .fuel_async_yield_interval(Some(100_000))
        .expect("plugin engine enables fuel and async yield interval is non-zero");
    store
}

fn set_call_fuel(store: &mut Store<PluginState>, call_fuel: u64) {
    store
        .set_fuel(call_fuel)
        .expect("fuel is enabled on the plugin engine");
}

/// Reset a warm store's fuel before a call so reused channel/memory stores get
/// a fresh per-call budget instead of draining across their lifetime.
pub fn refuel(store: &mut Store<PluginState>) {
    let call_fuel = store.data().fuel_per_call;
    set_call_fuel(store, call_fuel);
}

/// Cancellation-safe owner of one active host-service frame.
pub(crate) struct ActivePluginCall<'a> {
    store: &'a mut Store<PluginState>,
}

impl<'a> ActivePluginCall<'a> {
    /// Start a standard frame where phase-specific services are unavailable.
    pub(crate) fn new(store: &'a mut Store<PluginState>) -> Self {
        Self::start(store, PluginCallPhase::Standard)
    }

    /// Start a tool-execute frame where scoped secrets are available.
    pub(crate) fn tool_execute(store: &'a mut Store<PluginState>) -> Self {
        Self::start(store, PluginCallPhase::ToolExecute)
    }

    /// Start a channel service frame where scoped secrets are available.
    pub(crate) fn channel_service(store: &'a mut Store<PluginState>) -> Self {
        Self::start(store, PluginCallPhase::ChannelService)
    }

    fn start(store: &'a mut Store<PluginState>, phase: PluginCallPhase) -> Self {
        refuel(store);
        store.data_mut().start_call(phase);
        Self { store }
    }

    pub(crate) fn store_mut(&mut self) -> &mut Store<PluginState> {
        self.store
    }
}

impl Drop for ActivePluginCall<'_> {
    fn drop(&mut self) {
        self.store.data_mut().finish_call();
    }
}

pub fn wt<T>(r: wasmtime::Result<T>, ctx: &'static str) -> Result<T> {
    r.map_err(|e| anyhow::Error::msg(format!("{ctx}: {e}")))
}

/// Error returned when a guest export exceeds its host-owned wall-clock bound.
pub(crate) fn call_timeout_error(deadline: Duration) -> anyhow::Error {
    anyhow::Error::msg(format!(
        "plugin call exceeded wall-clock deadline of {} ms",
        deadline.as_millis()
    ))
}

/// Error returned after a warm instance has been discarded because a call into
/// it was interrupted or failed inside Wasmtime.
pub(crate) fn unavailable_instance_error() -> anyhow::Error {
    anyhow::Error::msg("plugin instance is unavailable: a previous call failed or was interrupted")
}

/// Hint appended to instantiation failures, pointing plugin authors at the
/// most common cause: a vendored `wit/v0` copy that has drifted from the
/// host's current WIT. Phrased conditionally ("if this is a WIT ... mismatch")
/// because it is appended to *every* instantiation failure, including non-WIT
/// causes such as a too-small memory limit — so it must read as a lead to
/// check, not an assertion of the cause. Kept as a `const` so it has one
/// source of truth and tests can assert against it instead of a literal.
const WIT_DRIFT_HINT: &str = "if this is a WIT interface/type mismatch, your plugin's vendored wit/v0 may have drifted — rebuild it against the WIT shipped with this host version";

/// Like [`wt`], but for component instantiation specifically. Instantiation
/// failures are where a stale vendored `wit/v0` copy surfaces, and wasmtime's
/// error there is a chain (e.g. "while linking ... caused by: type mismatch
/// for ..."). Unlike `wt`, this preserves the full chain via the alternate
/// `{:#}` Display instead of flattening it to the top-level message, and
/// appends [`WIT_DRIFT_HINT`] so the failure is actionable.
pub fn wt_instantiate<T>(r: wasmtime::Result<T>, ctx: &'static str) -> Result<T> {
    r.map_err(|e| anyhow::Error::msg(format!("{ctx}: {e:#} (hint: {WIT_DRIFT_HINT})")))
}

/// Compile or deserialize the exact component bytes retained by admission.
pub fn load_component(component: &AdmittedComponent) -> Result<Component> {
    wt(load_inner(component), "failed to load WASM component")
}

#[cfg(feature = "plugins-wasm-cranelift")]
fn load_inner(component: &AdmittedComponent) -> wasmtime::Result<Component> {
    Component::new(engine(), component.bytes())
}

#[cfg(not(feature = "plugins-wasm-cranelift"))]
fn load_inner(component: &AdmittedComponent) -> wasmtime::Result<Component> {
    // SAFETY: the file is a wasmtime-produced `.cwasm` for this engine; a
    // mismatched artifact is rejected by deserialize's version check.
    unsafe { Component::deserialize(engine(), component.bytes()) }
}

/// Run one warm guest export inside its host-service frame, bounded by the
/// wall-clock deadline.
///
/// The `(Store, bindings)` pair is moved out of the shared slot before
/// awaiting. If the deadline fires, or if the caller cancels and drops this
/// future, the in-flight Wasmtime future is dropped and unwound and the
/// interrupted store is discarded (the slot is left empty) rather than resumed.
/// The `ActivePluginCall` frame refuels the store and exposes the phase's
/// config/secrets for the call, then clears that transient view on drop.
///
/// `$body` returns the export's own Wasmtime result. `Err` means the call
/// failed inside Wasmtime: a guest trap, exhausted fuel, a failed host import,
/// or a result that could not be lifted. Wasmtime refuses every later call
/// into a store after the first three, and the last skips the export's
/// post-return cleanup, so the store is discarded as an interrupted one is,
/// and the error is reported with `$context`. An error the export itself
/// returns arrives inside `Ok`, and the store goes back to its slot. Return a
/// host-side failure inside `Ok` as well: `?` turns any `std::error::Error`
/// into a Wasmtime error, which would discard a healthy store.
macro_rules! call_plugin_frame {
    ($self:expr, $constructor:ident, $context:expr, $body:expr) => {{
        let mut guard = $self.state.lock().await;
        match guard.take() {
            None => Err(crate::component::unavailable_instance_error()),
            Some((mut store, mut bindings)) => {
                let deadline = store.data().call_timeout();
                let mut active_call = crate::component::ActivePluginCall::$constructor(&mut store);
                let f = $body;
                let outcome =
                    ::tokio::time::timeout(deadline, f(active_call.store_mut(), &mut bindings))
                        .await;
                drop(active_call);
                match outcome {
                    Ok(Ok(value)) => {
                        *guard = Some((store, bindings));
                        Ok(value)
                    }
                    Ok(Err(error)) => crate::component::wt(Err(error), $context),
                    Err(_) => Err(crate::component::call_timeout_error(deadline)),
                }
            }
        }
    }};
}
pub(crate) use call_plugin_frame;

macro_rules! call_plugin {
    ($self:expr, $context:expr, $body:expr) => {{ crate::component::call_plugin_frame!($self, new, $context, $body) }};
}
pub(crate) use call_plugin;

macro_rules! call_tool_execute {
    ($self:expr, $context:expr, $body:expr) => {{ crate::component::call_plugin_frame!($self, tool_execute, $context, $body) }};
}
pub(crate) use call_tool_execute;

/// Run one warm channel export inside the channel-service frame, bounded by
/// the wall-clock deadline, first rebuilding the instance from host-owned
/// inputs when an earlier call discarded it.
///
/// `$body` returns the export's own Wasmtime result. `Err` means the call
/// failed inside Wasmtime: a guest trap, exhausted fuel, a failed host import,
/// or a result that could not be lifted. Wasmtime refuses every later call
/// into a store after the first three, and the last skips the export's
/// post-return cleanup, so the instance is discarded, as it is after a missed
/// deadline, and the error is reported with `$context`. An error the export
/// itself returns arrives inside `Ok`, and the instance goes back to its slot.
///
/// Both kinds of discard count against the channel's rebuild budget, so a
/// hung export cannot reconnect the plugin at every deadline. The
/// `waits_on_person` form leaves missed deadlines out, for an export that
/// waits for a person to answer, such as an approval prompt: a slow answer
/// is not a broken plugin.
macro_rules! call_channel {
    (@call $self:expr, $count_missed_deadline:expr, $context:expr, $body:expr) => {{
        'plugin_call: {
            let mut guard = $self.state.lock().await;
            if guard.is_none() {
                match $self.reinstantiate().await {
                    Ok(pair) => *guard = Some(pair),
                    Err(error) => break 'plugin_call Err(error),
                }
            }
            let Some((mut store, mut bindings)) = guard.take() else {
                break 'plugin_call Err(crate::component::unavailable_instance_error());
            };
            let deadline = store.data().call_timeout();
            let mut active_call = crate::component::ActivePluginCall::channel_service(&mut store);
            let f = $body;
            let outcome =
                ::tokio::time::timeout(deadline, f(active_call.store_mut(), &mut bindings)).await;
            drop(active_call);
            match outcome {
                Ok(Ok(value)) => {
                    *guard = Some((store, bindings));
                    Ok(value)
                }
                Ok(Err(error)) => {
                    $self.instance_failed();
                    crate::component::wt(Err(error), $context)
                }
                Err(_) => {
                    if $count_missed_deadline {
                        $self.instance_failed();
                    }
                    Err(crate::component::call_timeout_error(deadline))
                }
            }
        }
    }};
    ($self:expr, waits_on_person, $context:expr, $body:expr) => {{
        crate::component::call_channel!(@call $self, false, $context, $body)
    }};
    ($self:expr, $context:expr, $body:expr) => {{
        crate::component::call_channel!(@call $self, true, $context, $body)
    }};
}
pub(crate) use call_channel;

/// Run one direct owned-store call inside its host-service frame, bounded by
/// the wall-clock deadline. Used during instantiation and metadata probing,
/// where there is no warm slot to poison: a timed-out or cancelled call drops
/// its local store. The RAII frame guard drops the transient resolved-config
/// view on success, error, trap, panic unwinding, or future cancellation.
macro_rules! call_store_frame {
    ($store:ident, $constructor:ident, $body:expr) => {{
        let deadline = $store.data().call_timeout();
        let mut active_call = crate::component::ActivePluginCall::$constructor(&mut $store);
        let f = $body;
        match ::tokio::time::timeout(deadline, f(active_call.store_mut())).await {
            Ok(result) => {
                drop(active_call);
                result
            }
            Err(_) => {
                drop(active_call);
                Err(crate::component::call_timeout_error(deadline))
            }
        }
    }};
}
pub(crate) use call_store_frame;

macro_rules! call_store {
    ($store:ident, $body:expr) => {{ crate::component::call_store_frame!($store, new, $body) }};
}
pub(crate) use call_store;

macro_rules! call_channel_store {
    ($store:ident, $body:expr) => {{ crate::component::call_store_frame!($store, channel_service, $body) }};
}
pub(crate) use call_channel_store;

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::{PluginConfigResolver, resolve_plugin_config};
    use crate::{PluginCapability, PluginManifest};
    use std::collections::HashMap;
    use std::sync::atomic::{AtomicUsize, Ordering};

    fn scope(
        binding: &str,
        grants: impl IntoIterator<Item = PluginPermission>,
    ) -> PluginInstanceScope {
        crate::instance::test_scope(PluginCapability::Tool, binding, grants)
    }

    fn spec(grants: impl IntoIterator<Item = PluginPermission>, call_fuel: u64) -> PluginStoreSpec {
        PluginStoreSpec::new(
            scope("main", grants),
            crate::services::test_host_services(),
            test_limits(call_fuel),
        )
        .with_granted_http()
    }

    #[cfg(feature = "plugins-wasm-cranelift")]
    const RESOURCE_COMPONENT: &str = r#"
        (component
          (core module $m
            (memory 1 4) (memory 1 4)
            (table 2 8 funcref) (table 2 8 funcref)
            (func (export "memory-first") (param i32) (result i32)
              local.get 0 memory.grow 0)
            (func (export "memory-second") (param i32) (result i32)
              local.get 0 memory.grow 1)
            (func (export "table-first") (param i32) (result i32)
              ref.null func local.get 0 table.grow 0)
            (func (export "table-second") (param i32) (result i32)
              ref.null func local.get 0 table.grow 1))
          (core instance $i (instantiate $m))
          (func (export "memory-first") (param "delta" u32) (result s32)
            (canon lift (core func $i "memory-first")))
          (func (export "memory-second") (param "delta" u32) (result s32)
            (canon lift (core func $i "memory-second")))
          (func (export "table-first") (param "delta" u32) (result s32)
            (canon lift (core func $i "table-first")))
          (func (export "table-second") (param "delta" u32) (result s32)
            (canon lift (core func $i "table-second"))))
    "#;

    #[cfg(feature = "plugins-wasm-cranelift")]
    fn resource_store() -> Store<PluginState> {
        let mut spec = spec([], 1_000_000);
        spec.limits.max_memory_bytes = 3 * 65536;
        spec.limits.max_table_elements = 6;
        new_store(spec)
    }

    #[cfg(feature = "plugins-wasm-cranelift")]
    #[tokio::test]
    async fn store_resource_budget_spans_memories() {
        let component =
            Component::new(engine(), wat::parse_str(RESOURCE_COMPONENT).unwrap()).unwrap();
        let linker = wasmtime::component::Linker::new(engine());
        let mut store = resource_store();
        let instance = linker
            .instantiate_async(&mut store, &component)
            .await
            .unwrap();
        for (name, delta, expected) in [
            ("memory-first", 1, 1),
            ("memory-second", 1, -1),
            ("memory-second", 0, 1),
        ] {
            set_call_fuel(&mut store, 1_000_000);
            let func = instance
                .get_typed_func::<(u32,), (i32,)>(&mut store, name)
                .unwrap();
            assert_eq!(
                func.call_async(&mut store, (delta,)).await.unwrap(),
                (expected,),
                "{name}"
            );
        }
    }

    #[cfg(feature = "plugins-wasm-cranelift")]
    #[tokio::test]
    async fn store_resource_budget_spans_tables() {
        let component =
            Component::new(engine(), wat::parse_str(RESOURCE_COMPONENT).unwrap()).unwrap();
        let linker = wasmtime::component::Linker::new(engine());
        let mut store = resource_store();
        let instance = linker
            .instantiate_async(&mut store, &component)
            .await
            .unwrap();
        for (name, delta, expected) in [
            ("table-first", 2, 2),
            ("table-second", 1, -1),
            ("table-second", 0, 2),
        ] {
            set_call_fuel(&mut store, 1_000_000);
            let func = instance
                .get_typed_func::<(u32,), (i32,)>(&mut store, name)
                .unwrap();
            assert_eq!(
                func.call_async(&mut store, (delta,)).await.unwrap(),
                (expected,),
                "{name}"
            );
        }
    }

    #[cfg(feature = "plugins-wasm-cranelift")]
    #[tokio::test]
    async fn store_resource_budget_includes_initial_allocations() {
        let component =
            Component::new(engine(), wat::parse_str(RESOURCE_COMPONENT).unwrap()).unwrap();
        let linker = wasmtime::component::Linker::new(engine());
        for memory_budget in [true, false] {
            let mut spec = spec([], 1_000_000);
            if memory_budget {
                spec.limits.max_memory_bytes = 65536;
            } else {
                spec.limits.max_table_elements = 3;
            }
            let mut store = new_store(spec);
            assert!(
                linker
                    .instantiate_async(&mut store, &component)
                    .await
                    .is_err()
            );
        }
    }

    #[cfg(feature = "plugins-wasm-cranelift")]
    #[tokio::test]
    async fn store_resource_budget_spans_instances_but_not_stores() {
        let component =
            Component::new(engine(), wat::parse_str(RESOURCE_COMPONENT).unwrap()).unwrap();
        let linker = wasmtime::component::Linker::new(engine());
        for (bytes, elements, instances) in [
            (3 * 65536, 100, 10),
            (1024 * 1024, 6, 10),
            (1024 * 1024, 100, 1),
        ] {
            // Each store admits one instance, then reaches exactly one of the
            // aggregate memory, aggregate table, or configured instance limits.
            for _ in 0..2 {
                let mut spec = spec([], 1_000_000);
                spec.limits.max_memory_bytes = bytes;
                spec.limits.max_table_elements = elements;
                spec.limits.max_instances = instances;
                let mut store = new_store(spec);
                linker
                    .instantiate_async(&mut store, &component)
                    .await
                    .unwrap();
                assert!(
                    linker
                        .instantiate_async(&mut store, &component)
                        .await
                        .is_err()
                );
            }
        }
    }

    fn secret_manifest(capability: PluginCapability) -> PluginManifest {
        PluginManifest {
            name: "fixture".to_string(),
            version: "0.1.0".to_string(),
            description: None,
            author: None,
            wasm_path: Some("fixture.wasm".to_string()),
            wasm_sha256: None,
            capabilities: vec![capability],
            provides: None,
            permissions: vec![PluginPermission::ConfigRead],
            config_schema: Some(serde_json::json!({
                "$schema": "https://json-schema.org/draft/2020-12/schema",
                "type": "object",
                "properties": {
                    "revision": {"type": "string"},
                    "api_key": {"type": "string", "x-secret": true}
                },
                "required": ["revision", "api_key"],
                "additionalProperties": false
            })),
            signature: None,
            publisher_key: None,
            egress: Default::default(),
        }
    }

    fn secret_scope(
        manifest: &PluginManifest,
        capability: PluginCapability,
        binding: &str,
        grant_config: bool,
    ) -> PluginInstanceScope {
        PluginInstanceScope::from_manifest(
            manifest,
            capability,
            binding,
            grant_config.then_some(PluginPermission::ConfigRead),
        )
        .expect("valid secret test scope")
    }

    fn configured(revision: &str, secret: &str) -> HashMap<String, String> {
        HashMap::from([
            ("revision".to_string(), revision.to_string()),
            ("api_key".to_string(), secret.to_string()),
        ])
    }

    fn static_services(
        manifest: PluginManifest,
        values: HashMap<String, String>,
    ) -> PluginHostServices {
        crate::services::test_services(PluginConfigResolver::new(move |scope| {
            resolve_plugin_config(&manifest, scope, Some(&values))
        }))
    }

    #[test]
    fn denied_secret_lookup_never_invokes_the_resolver() {
        for (capability, phase) in [
            (PluginCapability::Tool, PluginCallPhase::ToolExecute),
            (PluginCapability::Channel, PluginCallPhase::ChannelService),
        ] {
            let manifest = secret_manifest(capability);
            let denied = secret_scope(&manifest, capability, "main", false);
            let calls = Arc::new(AtomicUsize::new(0));
            let resolver_calls = Arc::clone(&calls);
            let services = crate::services::test_services(PluginConfigResolver::new(move |_| {
                resolver_calls.fetch_add(1, Ordering::SeqCst);
                panic!("denied lookup must not invoke config resolution")
            }));
            let mut state =
                PluginState::new(PluginStoreSpec::new(denied, services, test_limits(1_000)));

            state.start_call(phase);
            if capability == PluginCapability::Channel {
                assert_eq!(
                    state.guest_public_config(),
                    Err(ConfigLookupError::AccessDenied)
                );
            }
            assert_eq!(
                state.secret("api_key"),
                Err(SecretLookupError::AccessDenied)
            );
            state.finish_call();
            assert_eq!(calls.load(Ordering::SeqCst), 0);
        }
    }

    #[test]
    fn disabled_secret_frame_never_invokes_the_resolver() {
        let manifest = secret_manifest(PluginCapability::Channel);
        let scope = secret_scope(&manifest, PluginCapability::Channel, "main", true);
        let calls = Arc::new(AtomicUsize::new(0));
        let resolver_calls = Arc::clone(&calls);
        let services = crate::services::test_services(PluginConfigResolver::new(move |_| {
            resolver_calls.fetch_add(1, Ordering::SeqCst);
            panic!("disabled secret frame must not invoke config resolution")
        }));
        let mut state = PluginState::new(PluginStoreSpec::new(scope, services, test_limits(1_000)));

        state.start_call(PluginCallPhase::Standard);
        assert_eq!(
            state.guest_public_config(),
            Err(ConfigLookupError::Unavailable)
        );
        assert_eq!(state.secret("api_key"), Err(SecretLookupError::Unavailable));
        state.finish_call();
        assert_eq!(calls.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn mismatched_secret_phase_never_invokes_the_resolver() {
        for (capability, phase) in [
            (PluginCapability::Channel, PluginCallPhase::ToolExecute),
            (PluginCapability::Tool, PluginCallPhase::ChannelService),
        ] {
            let manifest = secret_manifest(capability);
            let scope = secret_scope(&manifest, capability, "main", true);
            let calls = Arc::new(AtomicUsize::new(0));
            let resolver_calls = Arc::clone(&calls);
            let services = crate::services::test_services(PluginConfigResolver::new(move |_| {
                resolver_calls.fetch_add(1, Ordering::SeqCst);
                panic!("a mismatched call phase must not resolve secrets")
            }));
            let mut state =
                PluginState::new(PluginStoreSpec::new(scope, services, test_limits(1_000)));

            state.start_call(phase);
            assert_eq!(state.secret("api_key"), Err(SecretLookupError::Unavailable));
            state.finish_call();
            assert_eq!(calls.load(Ordering::SeqCst), 0);
        }
    }

    #[test]
    fn guest_cannot_read_a_secret_reserved_for_the_host() {
        let manifest = secret_manifest(PluginCapability::Tool);
        let scope = secret_scope(&manifest, PluginCapability::Tool, "main", true);
        let values = configured("one", "private-key-pem");
        let services = crate::services::test_services(PluginConfigResolver::new(move |scope| {
            resolve_plugin_config(&manifest, scope, Some(&values)).map(|config| {
                config.reserve_for_host([zeroclaw_api::plugin_key::SecretPropertyRef::parse(
                    "api_key",
                )
                .expect("portable")])
            })
        }));
        let mut state = PluginState::new(PluginStoreSpec::new(scope, services, test_limits(1_000)));

        state.start_call(PluginCallPhase::ToolExecute);
        assert_eq!(
            state.secret("api_key"),
            Err(SecretLookupError::AccessDenied)
        );
        let host_view = state
            .with_call_config(|config| config.secret("api_key").map(ToOwned::to_owned))
            .expect("resolved config");
        assert_eq!(host_view.as_deref(), Some("private-key-pem"));
    }

    #[test]
    fn channel_service_reads_secret_from_its_call_config_revision() {
        let manifest = secret_manifest(PluginCapability::Channel);
        let scope = secret_scope(&manifest, PluginCapability::Channel, "main", true);
        let services = static_services(manifest, configured("one", "channel-token"));
        let mut state = PluginState::new(PluginStoreSpec::new(scope, services, test_limits(1_000)));

        state.start_call(PluginCallPhase::ChannelService);
        state.host_calls_remaining = 2;
        assert_eq!(
            state.guest_public_config().expect("public config"),
            serde_json::json!({"revision": "one"})
        );
        assert_eq!(state.secret("api_key"), Ok("channel-token".to_string()));
        assert_eq!(
            state.guest_public_config(),
            Err(ConfigLookupError::Unavailable),
            "public config and secrets must share one host-call budget"
        );
        state.finish_call();
    }

    #[test]
    fn secret_lookup_rejects_a_view_from_another_scope_issuance() {
        let manifest = Arc::new(secret_manifest(PluginCapability::Tool));
        let requested = secret_scope(&manifest, PluginCapability::Tool, "main", true);
        let issued = secret_scope(&manifest, PluginCapability::Tool, "backup", true);
        let resolver_manifest = Arc::clone(&manifest);
        let services = crate::services::test_services(PluginConfigResolver::new(move |_| {
            let values = configured("one", "backup-token");
            resolve_plugin_config(&resolver_manifest, &issued, Some(&values))
        }));
        let mut state = PluginState::new(PluginStoreSpec::new(
            requested,
            services,
            test_limits(1_000),
        ));

        state.start_call(PluginCallPhase::ToolExecute);
        assert_eq!(state.secret("api_key"), Err(SecretLookupError::Unavailable));
        state.finish_call();
    }

    /// A socket-capable tool manifest whose `ca_pem` secret a TLS profile
    /// references.
    fn tls_manifest() -> PluginManifest {
        PluginManifest {
            permissions: vec![PluginPermission::ConfigRead, PluginPermission::SocketClient],
            config_schema: Some(serde_json::json!({
                "$schema": "https://json-schema.org/draft/2020-12/schema",
                "type": "object",
                "properties": {
                    "ca_pem": {"type": "string", "x-secret": true}
                },
                "additionalProperties": false
            })),
            ..secret_manifest(PluginCapability::Tool)
        }
    }

    fn tls_scope(
        manifest: &PluginManifest,
        grants: impl IntoIterator<Item = PluginPermission>,
    ) -> PluginInstanceScope {
        PluginInstanceScope::from_manifest(manifest, PluginCapability::Tool, "main", grants)
            .expect("valid TLS test scope")
    }

    /// An egress authority granting `service.example`, with a `private-ca`
    /// profile that trusts only the instance's `ca_pem` secret.
    fn tls_egress() -> EgressHostService {
        use crate::egress::{EgressPolicy, EgressPolicyResolver, TlsProfile, TlsProfileName};

        EgressHostService::with_private_connection_accounting(EgressPolicyResolver::new(|_| {
            let hosts = ["service.example".to_string()];
            EgressPolicy::new(&hosts, &[], &[], 4)?
                .with_tls_profiles([TlsProfile::new(
                    TlsProfileName::new("private-ca")?,
                    &hosts,
                    false,
                    Some(
                        zeroclaw_api::plugin_key::SecretPropertyRef::parse("ca_pem")
                            .expect("portable"),
                    ),
                    None,
                )?])
                .map(|policy| {
                    policy.with_tls_config_witness(crate::egress::TlsConfigWitness::new([0; 32]))
                })
        }))
    }

    /// Authorize one TLS connection to `service.example` under `scope`.
    fn authorize_tls(egress: &EgressHostService, scope: &PluginInstanceScope) -> AuthorizedEgress {
        use crate::egress::{EgressRequest, EgressTransport};

        let request =
            EgressRequest::new(scope.clone(), EgressTransport::Tls, "service.example", 443)
                .and_then(|request| request.with_tls_profile("private-ca"))
                .expect("valid TLS request");
        egress
            .authorize_addresses(request, [std::net::SocketAddr::from(([1, 1, 1, 1], 443))])
            .expect("the grant and the profile cover the destination")
    }

    /// A private CA and a `service.example` server identity it signed.
    struct TestCa {
        pem: String,
        server: Arc<rustls::ServerConfig>,
    }

    impl TestCa {
        fn new(name: &str) -> Self {
            let ca_key = rcgen::KeyPair::generate().expect("CA key");
            let mut ca_params =
                rcgen::CertificateParams::new(vec![name.to_string()]).expect("CA parameters");
            ca_params
                .distinguished_name
                .push(rcgen::DnType::CommonName, name);
            ca_params.is_ca = rcgen::IsCa::Ca(rcgen::BasicConstraints::Unconstrained);
            let ca = ca_params.self_signed(&ca_key).expect("self-sign CA");
            let server_key = rcgen::KeyPair::generate().expect("server key");
            let server = rcgen::CertificateParams::new(vec!["service.example".to_string()])
                .expect("server parameters")
                .signed_by(&server_key, &ca, &ca_key)
                .expect("sign server certificate");
            let server = rustls::ServerConfig::builder_with_provider(Arc::new(
                rustls::crypto::ring::default_provider(),
            ))
            .with_safe_default_protocol_versions()
            .expect("ring offers the default protocol versions")
            .with_no_client_auth()
            .with_single_cert(
                vec![server.der().clone()],
                rustls::pki_types::PrivateKeyDer::Pkcs8(server_key.serialize_der().into()),
            )
            .expect("server configuration");
            Self {
                pem: ca.pem(),
                server: Arc::new(server),
            }
        }

        /// Whether `client` completes an in-memory handshake with this CA's
        /// server. Bounded, so a stalled handshake fails instead of hanging.
        async fn verifies(&self, client: Arc<rustls::ClientConfig>) -> bool {
            let (client_io, server_io) = tokio::io::duplex(64 * 1024);
            let name =
                rustls::pki_types::ServerName::try_from("service.example").expect("server name");
            let handshake = async {
                tokio::join!(
                    tokio_rustls::TlsConnector::from(client).connect(name, client_io),
                    tokio_rustls::TlsAcceptor::from(Arc::clone(&self.server)).accept(server_io),
                )
            };
            matches!(
                tokio::time::timeout(Duration::from_secs(10), handshake).await,
                Ok((Ok(_), _))
            )
        }
    }

    #[tokio::test]
    async fn tls_config_rejects_same_id_different_grants_before_any_secret_read() {
        let manifest = tls_manifest();
        let issued = tls_scope(
            &manifest,
            [PluginPermission::ConfigRead, PluginPermission::SocketClient],
        );
        let config_only = tls_scope(&manifest, [PluginPermission::ConfigRead]);
        assert_eq!(
            issued.id(),
            config_only.id(),
            "both admissions share one logical instance ID"
        );
        let calls = Arc::new(AtomicUsize::new(0));
        let resolver_calls = Arc::clone(&calls);
        let services = crate::services::test_services(PluginConfigResolver::new(move |_| {
            resolver_calls.fetch_add(1, Ordering::SeqCst);
            panic!("a foreign authorization must not resolve config or secrets")
        }));
        let mut state = PluginState::new(PluginStoreSpec::new(
            config_only,
            services,
            test_limits(1_000),
        ));
        let authorized = authorize_tls(&tls_egress(), &issued);

        state.start_call(PluginCallPhase::ToolExecute);
        let result = state.tls_client_config(&authorized).await;
        state.finish_call();

        assert!(
            matches!(result, Err(EgressError::AuthorizationScopeMismatch)),
            "{result:?}"
        );
        assert_eq!(calls.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn tls_config_is_rebuilt_per_connection() {
        let manifest = Arc::new(tls_manifest());
        let scope = tls_scope(
            &manifest,
            [PluginPermission::ConfigRead, PluginPermission::SocketClient],
        );
        let first_ca = TestCa::new("First Plugin Test CA");
        let second_ca = TestCa::new("Second Plugin Test CA");
        let ca_pem = Arc::new(std::sync::RwLock::new(first_ca.pem.clone()));
        let calls = Arc::new(AtomicUsize::new(0));
        let resolver_manifest = Arc::clone(&manifest);
        let resolver_ca_pem = Arc::clone(&ca_pem);
        let resolver_calls = Arc::clone(&calls);
        let services = crate::services::test_services(PluginConfigResolver::new(move |scope| {
            resolver_calls.fetch_add(1, Ordering::SeqCst);
            let ca_pem = resolver_ca_pem
                .read()
                .unwrap_or_else(|error| error.into_inner())
                .clone();
            let values = HashMap::from([("ca_pem".to_string(), ca_pem)]);
            resolve_plugin_config(&resolver_manifest, scope, Some(&values)).map(|config| {
                config.with_tls_config_witness(crate::egress::TlsConfigWitness::new([0; 32]))
            })
        }));
        let mut state = PluginState::new(PluginStoreSpec::new(
            scope.clone(),
            services,
            test_limits(1_000),
        ));
        let egress = tls_egress();

        state.start_call(PluginCallPhase::ToolExecute);
        let first = state
            .tls_client_config(&authorize_tls(&egress, &scope))
            .await
            .expect("first connection's configuration");
        state.finish_call();

        *ca_pem.write().unwrap_or_else(|error| error.into_inner()) = second_ca.pem.clone();

        state.start_call(PluginCallPhase::ToolExecute);
        let second = state
            .tls_client_config(&authorize_tls(&egress, &scope))
            .await
            .expect("second connection's configuration");
        state.finish_call();

        assert_eq!(
            calls.load(Ordering::SeqCst),
            2,
            "each connection resolves the canonical config again"
        );
        assert!(
            !Arc::ptr_eq(&first, &second),
            "each connection owns its own configuration"
        );
        assert!(
            first_ca.verifies(Arc::clone(&first)).await,
            "the first connection trusts the CA it was built from"
        );
        assert!(
            second_ca.verifies(Arc::clone(&second)).await,
            "the rotated CA reaches the next connection"
        );
        assert!(
            !first_ca.verifies(second).await,
            "the replaced CA is no longer trusted by the next connection"
        );
    }

    #[tokio::test]
    async fn tls_unresolved_frame_rejects_policy_captured_before_dns_wait() {
        use crate::egress::{
            EgressPolicy, EgressPolicyResolver, EgressRequest, EgressTransport, TlsConfigWitness,
            TlsProfile, TlsProfileName,
        };
        let manifest = Arc::new(tls_manifest());
        let scope = tls_scope(
            &manifest,
            [PluginPermission::ConfigRead, PluginPermission::SocketClient],
        );
        let ca = TestCa::new("dns-race");
        // One canonical test config supplies both views; change it at the DNS wait.
        let source = Arc::new(std::sync::RwLock::new((0_u8, ca.pem.clone())));
        let policy_source = source.clone();
        let arrived = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        let egress = EgressHostService::with_test_resolver(
            EgressPolicyResolver::new(move |_| {
                let source = policy_source.read().unwrap();
                let hosts = ["service.example".to_string()];
                EgressPolicy::new(&hosts, &[], &[], 4)?
                    .with_tls_profiles([TlsProfile::new(
                        TlsProfileName::new("private-ca")?,
                        &hosts,
                        false,
                        Some(zeroclaw_api::plugin_key::SecretPropertyRef::parse("ca_pem").unwrap()),
                        None,
                    )?])
                    .map(|policy| {
                        policy.with_tls_config_witness(TlsConfigWitness::new([source.0; 32]))
                    })
            }),
            |_, port| vec![std::net::SocketAddr::from(([1, 1, 1, 1], port))],
        )
        .with_test_dns_pause(arrived.clone(), release.clone());
        let config_source = source.clone();
        let calls = Arc::new(AtomicUsize::new(0));
        let config_calls = calls.clone();
        let services = crate::services::test_services(PluginConfigResolver::new(move |scope| {
            config_calls.fetch_add(1, Ordering::SeqCst);
            let source = config_source.read().unwrap();
            resolve_plugin_config(
                &manifest,
                scope,
                Some(&HashMap::from([("ca_pem".into(), source.1.clone())])),
            )
            .map(|config| config.with_tls_config_witness(TlsConfigWitness::new([source.0; 32])))
        }));
        let mut state = PluginState::new(PluginStoreSpec::new(
            scope.clone(),
            services,
            test_limits(1_000),
        ));
        state.start_call(PluginCallPhase::ToolExecute);
        let request =
            EgressRequest::new(scope.clone(), EgressTransport::Tls, "service.example", 443)
                .unwrap()
                .with_tls_profile("private-ca")
                .unwrap();
        let authorization = egress.authorize(request.clone());
        tokio::pin!(authorization);
        tokio::select! { biased;
            result = &mut authorization => panic!("DNS must be paused: {result:?}"),
            () = arrived.notified() => {}
        }
        source.write().unwrap().0 = 1;
        release.notify_one();
        let old = authorization.await.unwrap();
        assert_eq!(
            calls.load(Ordering::SeqCst),
            0,
            "frame was still unresolved at the DNS wait"
        );
        assert!(matches!(
            state.tls_client_config(&old).await,
            Err(EgressError::TlsConfigMismatch)
        ));
        drop(old);
        // Denied authorization relinquishes its budget; a coherent request succeeds.
        let current = egress
            .authorize_addresses(
                request.clone(),
                [std::net::SocketAddr::from(([1, 1, 1, 1], 443))],
            )
            .unwrap();
        assert!(
            ca.verifies(state.tls_client_config(&current).await.unwrap())
                .await
        );
        drop(current);
        state.finish_call();
        // Cancellation while DNS is queued must not reserve a connection lease.
        {
            let pending = egress.authorize(request.clone());
            tokio::pin!(pending);
            tokio::select! { biased;
                result = &mut pending => panic!("DNS must be paused: {result:?}"),
                () = arrived.notified() => {}
            }
        }
        let leases = (0..4)
            .map(|_| {
                egress
                    .authorize_addresses(
                        request.clone(),
                        [std::net::SocketAddr::from(([1, 1, 1, 1], 443))],
                    )
                    .unwrap()
            })
            .collect::<Vec<_>>();
        assert_eq!(leases.len(), 4);
    }

    #[test]
    fn one_frame_shares_one_live_revision_and_next_frame_refreshes() {
        let manifest = Arc::new(secret_manifest(PluginCapability::Tool));
        let scope = secret_scope(&manifest, PluginCapability::Tool, "main", true);
        let values = Arc::new(std::sync::RwLock::new(configured("one", "token-one")));
        let calls = Arc::new(AtomicUsize::new(0));
        let resolver_manifest = Arc::clone(&manifest);
        let resolver_values = Arc::clone(&values);
        let resolver_calls = Arc::clone(&calls);
        let services = crate::services::test_services(PluginConfigResolver::new(move |scope| {
            resolver_calls.fetch_add(1, Ordering::SeqCst);
            let values = resolver_values
                .read()
                .unwrap_or_else(|error| error.into_inner());
            resolve_plugin_config(&resolver_manifest, scope, Some(&values))
        }));
        let mut state = PluginState::new(PluginStoreSpec::new(scope, services, test_limits(1_000)));

        state.start_call(PluginCallPhase::ToolExecute);
        assert_eq!(
            state.public_config().expect("public config")["revision"],
            "one"
        );
        *values.write().unwrap_or_else(|error| error.into_inner()) = configured("two", "token-two");
        assert_eq!(state.secret("api_key"), Ok("token-one".to_string()));
        assert_eq!(state.secret("api_key"), Ok("token-one".to_string()));
        assert_eq!(calls.load(Ordering::SeqCst), 1);
        state.finish_call();

        state.start_call(PluginCallPhase::ToolExecute);
        assert_eq!(
            state.public_config().expect("public config")["revision"],
            "two"
        );
        assert_eq!(state.secret("api_key"), Ok("token-two".to_string()));
        assert_eq!(calls.load(Ordering::SeqCst), 2);
        state.finish_call();
    }

    #[test]
    fn failed_resolution_is_cached_for_the_frame() {
        let manifest = secret_manifest(PluginCapability::Tool);
        let scope = secret_scope(&manifest, PluginCapability::Tool, "main", true);
        let calls = Arc::new(AtomicUsize::new(0));
        let resolver_calls = Arc::clone(&calls);
        let services = crate::services::test_services(PluginConfigResolver::new(move |_| {
            resolver_calls.fetch_add(1, Ordering::SeqCst);
            Err(PluginError::InvalidConfig("resolver detail".to_string()))
        }));
        let mut state = PluginState::new(PluginStoreSpec::new(scope, services, test_limits(1_000)));

        state.start_call(PluginCallPhase::ToolExecute);
        assert_eq!(state.secret("api_key"), Err(SecretLookupError::Unavailable));
        assert_eq!(state.secret("api_key"), Err(SecretLookupError::Unavailable));
        assert_eq!(calls.load(Ordering::SeqCst), 1);
        state.finish_call();
    }

    #[test]
    fn host_call_budget_exhausts_and_resets_per_frame() {
        let manifest = secret_manifest(PluginCapability::Tool);
        let scope = secret_scope(&manifest, PluginCapability::Tool, "main", true);
        let services = static_services(manifest, configured("one", "token"));
        let mut state = PluginState::new(PluginStoreSpec::new(scope, services, test_limits(1_000)));

        state.start_call(PluginCallPhase::ToolExecute);
        for _ in 0..MAX_HOST_CALLS_PER_FRAME {
            assert_eq!(state.secret("api_key"), Ok("token".to_string()));
        }
        assert_eq!(state.secret("api_key"), Err(SecretLookupError::Unavailable));
        state.finish_call();

        state.start_call(PluginCallPhase::ToolExecute);
        assert_eq!(state.secret("api_key"), Ok("token".to_string()));
        state.finish_call();
    }

    #[tokio::test]
    async fn cancellation_drops_the_active_config_and_budget() {
        let manifest = secret_manifest(PluginCapability::Tool);
        let scope = secret_scope(&manifest, PluginCapability::Tool, "main", true);
        let services = static_services(manifest, configured("one", "token"));
        let mut store = new_store(PluginStoreSpec::new(scope, services, test_limits(1_000)));

        let cancelled = tokio::time::timeout(std::time::Duration::from_millis(1), async {
            let mut active_call = ActivePluginCall::new(&mut store);
            active_call
                .store_mut()
                .data_mut()
                .public_config()
                .expect("config resolves inside an active frame");
            std::future::pending::<()>().await;
            drop(active_call);
        })
        .await;

        assert!(cancelled.is_err(), "pending invocation must be cancelled");
        assert!(store.data_mut().public_config().is_err());
        assert_eq!(store.data().call_config.phase(), None);
        assert_eq!(store.data().host_calls_remaining, 0);
    }

    #[tokio::test]
    async fn logging_and_inbound_share_the_frame_budget() {
        use bindings::tool::zeroclaw::plugin::logging::{
            Host as LoggingHost, LogLevel, PluginAction, PluginEvent,
        };

        let mut state = PluginState::new(spec([], 1_000));
        state.inbound().enqueue(sample_inbound("budgeted"));
        state.start_call(PluginCallPhase::Standard);
        state.host_calls_remaining = 1;

        <PluginState as LoggingHost>::log_record(
            &mut state,
            LogLevel::Info,
            PluginEvent {
                function_name: "fixture::execute".to_string(),
                action: PluginAction::Note,
                outcome: None,
                duration_ms: None,
                attrs: None,
                message: "budget test".to_string(),
            },
        )
        .await;
        assert_eq!(state.host_calls_remaining, 0);
        assert_eq!(
            <PluginState as bindings::channel::zeroclaw::plugin::inbound::Host>::inbound_pending(
                &mut state
            )
            .await,
            0
        );
        assert_eq!(
            state.inbound().pending(),
            1,
            "exhaustion must not drain data"
        );
        state.finish_call();

        state.start_call(PluginCallPhase::Standard);
        let message =
            <PluginState as bindings::channel::zeroclaw::plugin::inbound::Host>::inbound_poll(
                &mut state,
            )
            .await
            .expect("a fresh frame can reach the queued message");
        assert_eq!(message.id, "budgeted");
        state.finish_call();
    }

    #[test]
    fn http_absent_without_permission() {
        let state = PluginState::new(spec([], 0));
        assert!(
            !state.http_enabled(),
            "no HttpClient permission means no outbound HTTP context"
        );
    }

    #[test]
    fn http_absent_for_unrelated_permissions() {
        let state = PluginState::new(spec(
            [
                PluginPermission::ConfigRead,
                PluginPermission::MemoryRead,
                PluginPermission::FileRead,
            ],
            0,
        ));
        assert!(
            !state.http_enabled(),
            "only HttpClient attaches the HTTP context"
        );
    }

    #[test]
    fn http_present_with_permission() {
        let state = PluginState::new(spec([PluginPermission::HttpClient], 0));
        assert!(
            state.http_enabled(),
            "HttpClient attaches the outbound HTTP context"
        );
    }

    #[test]
    fn grant_does_not_enable_http_without_adapter_opt_in() {
        let granted_scope = scope("main", [PluginPermission::HttpClient]);
        let state = PluginState::new(PluginStoreSpec::new(
            granted_scope,
            crate::services::test_host_services(),
            test_limits(0),
        ));

        assert!(
            !state.http_enabled(),
            "an adapter must explicitly opt into its tested HTTP boundary"
        );
    }

    #[test]
    fn http_coherence_accepts_matching_store_and_linker() {
        let granted = new_store(spec([PluginPermission::HttpClient], 0));
        assert!(
            ensure_http_coherent(&granted, true).is_ok(),
            "granted store paired with an http linker is coherent"
        );
        let plain = new_store(spec([], 0));
        assert!(
            ensure_http_coherent(&plain, false).is_ok(),
            "ungranted store paired with a plain linker is coherent"
        );
    }

    #[test]
    fn http_coherence_rejects_a_store_linker_mismatch() {
        // A registration path that links wasi:http against a store with no
        // HttpClient context (or the reverse) is refused at instantiate time
        // with a named error, not a WasiHttpView::http panic on first call.
        let granted = new_store(spec([PluginPermission::HttpClient], 0));
        assert!(
            ensure_http_coherent(&granted, false).is_err(),
            "granted store with a plain linker cannot back its own permission"
        );
        let plain = new_store(spec([], 0));
        assert!(
            ensure_http_coherent(&plain, true).is_err(),
            "plain store with an http linker would panic on first outbound call"
        );
    }

    #[test]
    fn socket_imports_follow_the_admitted_grant() {
        let granted = new_store(spec([PluginPermission::SocketClient], 0));
        let imports = OptionalImports::for_store(granted.data());
        assert!(imports.sockets && !imports.http);
        assert!(ensure_imports_coherent(&granted, imports).is_ok());
        assert!(
            ensure_imports_coherent(
                &granted,
                OptionalImports {
                    sockets: false,
                    ..imports
                }
            )
            .is_err(),
            "a granted store must not be paired with a linker missing its import"
        );

        let plain = new_store(spec([], 0));
        assert!(!OptionalImports::for_store(plain.data()).sockets);
        assert!(
            ensure_imports_coherent(
                &plain,
                OptionalImports {
                    http: false,
                    sockets: true,
                    websocket: false,
                }
            )
            .is_err(),
            "an ungranted store must never be linked with the socket import"
        );
        assert!(
            plain.data().egress_service().is_none(),
            "a store built without an egress authority has no reach"
        );
    }

    #[cfg(feature = "plugins-wasm-cranelift")]
    #[test]
    fn http_linker_builds_only_when_granted() {
        // The base linker (no wasi:http) always builds.
        let mut base = wasmtime::component::Linker::<PluginState>::new(engine());
        add_wasi(&mut base).expect("base WASI links");

        // Adding wasi:http on top must also succeed; this is the surface an
        // HttpClient-granted plugin gets. A store built without the permission
        // never reaches this linker, so its WasiHttpView is never invoked.
        add_wasi_http(&mut base).expect("wasi:http links onto a granted linker");
    }

    fn sample_inbound(id: &str) -> HostInboundMessage {
        HostInboundMessage {
            id: id.to_string(),
            sender: "caller".to_string(),
            content: format!("body-{id}"),
            channel: "inkbox".to_string(),
            ..Default::default()
        }
    }

    #[test]
    fn inbound_queue_drains_fifo() {
        let q = InboundQueue::default();
        assert_eq!(q.pending(), 0);
        assert!(q.poll().is_none(), "empty queue polls none");

        q.enqueue(sample_inbound("1"));
        q.enqueue(sample_inbound("2"));
        q.enqueue(sample_inbound("3"));
        assert_eq!(q.pending(), 3);

        assert_eq!(q.poll().unwrap().id, "1");
        assert_eq!(q.poll().unwrap().id, "2");
        assert_eq!(q.pending(), 1);
        assert_eq!(q.poll().unwrap().id, "3");
        assert!(q.poll().is_none(), "drained queue polls none");
        assert_eq!(q.pending(), 0);
    }

    #[test]
    fn inbound_queue_handle_is_shared() {
        // A listener clone and the store's clone must see the same queue, so a
        // message enqueued by the host listener is visible to the plugin drain.
        let listener = InboundQueue::default();
        let store_side = listener.clone();
        listener.enqueue(sample_inbound("x"));
        assert_eq!(store_side.pending(), 1, "clone shares the backing queue");
        assert_eq!(store_side.poll().unwrap().id, "x");
        assert_eq!(
            listener.pending(),
            0,
            "drain on one clone empties the other"
        );
    }

    #[test]
    fn inbound_queue_survives_a_poisoned_lock() {
        // A producer that panics while holding the lock must not permanently
        // silence the queue: later enqueue/poll/pending recover the poison and
        // keep delivering, since silent inbound loss is worse than a noisy trap.
        let q = InboundQueue::default();
        q.enqueue(sample_inbound("before"));

        let poisoned = q.clone();
        let _ = std::thread::spawn(move || {
            let _guard = poisoned.inner.lock().unwrap();
            panic!("poison the queue lock");
        })
        .join();

        assert!(q.inner.is_poisoned(), "lock is poisoned after the panic");
        assert_eq!(q.pending(), 1, "pending recovers the poisoned lock");
        q.enqueue(sample_inbound("after"));
        assert_eq!(q.pending(), 2, "enqueue recovers and appends");
        assert_eq!(q.poll().unwrap().id, "before", "drain recovers, FIFO holds");
        assert_eq!(q.poll().unwrap().id, "after");
        assert_eq!(q.pending(), 0);
    }

    #[test]
    fn plugin_state_exposes_its_inbound_queue() {
        let q = InboundQueue::default();
        let state = PluginState::new(spec([], 0).with_inbound(q.clone()));
        q.enqueue(sample_inbound("y"));
        assert_eq!(
            state.inbound().pending(),
            1,
            "state shares the supplied queue"
        );
    }

    #[test]
    fn engine_enables_fuel_metering() {
        let mut store = Store::new(engine(), PluginState::new(spec([], 0)));
        store
            .set_fuel(123)
            .expect("fuel must be enabled on the shared plugin engine");
        assert_eq!(store.get_fuel().expect("get_fuel"), 123);
    }

    #[test]
    fn new_store_seeds_configured_budget() {
        let store = new_store(spec([], 777));
        assert_eq!(store.get_fuel().expect("get_fuel"), 777);
    }

    #[test]
    fn zero_budget_traps_before_any_work() {
        let store = new_store(spec([], 0));
        assert_eq!(
            store.get_fuel().expect("get_fuel"),
            0,
            "a zero budget leaves no fuel, so the first consuming instruction traps"
        );
    }

    #[test]
    fn refuel_restores_per_call_budget_on_a_warm_store() {
        let mut store = new_store(spec([], 500));
        store.set_fuel(3).expect("set_fuel");
        assert_eq!(store.get_fuel().expect("get_fuel"), 3);
        refuel(&mut store);
        assert_eq!(
            store.get_fuel().expect("get_fuel"),
            500,
            "refuel must reset a drained warm store to the configured per-call budget"
        );
    }

    #[test]
    fn store_enables_periodic_async_fuel_yields() {
        let mut store = new_store(spec([], 500));
        store
            .fuel_async_yield_interval(Some(100_000))
            .expect("plugin stores support async fuel yields");
    }

    #[test]
    fn stores_share_only_their_issued_instance_scope() {
        let primary = scope("primary", []);
        let primary_store = new_store(PluginStoreSpec::new(
            primary.clone(),
            crate::services::test_host_services(),
            test_limits(0),
        ));
        let second_primary_store = new_store(PluginStoreSpec::new(
            primary,
            crate::services::test_host_services(),
            test_limits(0),
        ));
        let backup_store = new_store(PluginStoreSpec::new(
            scope("backup", []),
            crate::services::test_host_services(),
            test_limits(0),
        ));

        assert!(std::ptr::eq(
            primary_store.data().scope().id(),
            second_primary_store.data().scope().id()
        ));
        assert_ne!(
            primary_store.data().scope().id(),
            backup_store.data().scope().id(),
            "separate bindings must not share a host-service namespace"
        );
    }

    #[test]
    fn wt_instantiate_passes_through_on_success() {
        let value = wt_instantiate(Ok(42), "failed to instantiate tool plugin")
            .expect("Ok is passed through unchanged");
        assert_eq!(value, 42);
    }

    #[test]
    fn wt_instantiate_preserves_the_chain_and_appends_the_drift_hint() {
        // Shaped like a real wasmtime component-model mismatch: a root cause
        // (the WIT type mismatch) wrapped with an intermediate linking
        // context, the way `instantiate_async` failures actually chain. This
        // is `wasmtime::Error` (what `instantiate_async` actually returns),
        // not `anyhow::Error` — the two are distinct types in this wasmtime
        // version, though `Error::context` chains the same way.
        let err =
            wasmtime::Error::msg("type mismatch for `plugin-action`: expected 5 cases, found 4")
                .context("while linking zeroclaw:plugin/logging");

        let decorated = wt_instantiate::<()>(Err(err), "failed to instantiate tool plugin")
            .expect_err("Err must stay an error");
        let rendered = format!("{decorated}");

        assert!(
            rendered.contains("failed to instantiate tool plugin"),
            "must keep the caller-supplied context: {rendered}"
        );
        assert!(
            rendered.contains("type mismatch for"),
            "must preserve the root cause via the alternate {{:#}} Display, \
             not just the top-level message: {rendered}"
        );
        assert!(
            rendered.contains("while linking zeroclaw:plugin/logging"),
            "must preserve the intermediate chain link too: {rendered}"
        );
        assert!(
            rendered.contains(WIT_DRIFT_HINT),
            "must append the wit/v0 drift hint: {rendered}"
        );
    }
}
