//! Inbound message debouncing for rapid senders.

use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;

use tokio::sync::Mutex;
use tokio::task::JoinHandle;

/// Result of submitting a message to the debouncer.
pub enum DebounceResult {
    /// The message was accumulated and a timer is running. The caller should
    /// skip processing — the debounced message will arrive via `rx` when the
    /// window expires.
    Pending {
        rx: tokio::sync::oneshot::Receiver<String>,
        /// `false` when this message opened a new accumulation bucket, `true`
        /// when it extended one that was already open — the receiver handed
        /// out for the bucket's previous message resolves to `Err`, and this
        /// receiver replaces it.
        ///
        /// The distinction is decided under the debouncer's own lock. A caller
        /// that keeps per-bucket state cannot reconstruct it afterwards:
        /// checking any mirror of "is the bucket still open" races the window
        /// expiry, and a bucket that fired in between would swallow a receiver
        /// belonging to the next one.
        extended: bool,
    },
    /// Debouncing is disabled (window = 0); pass the message through immediately.
    Passthrough(String),
}

struct DebouncerEntry {
    messages: Vec<String>,
    timer_handle: JoinHandle<()>,
    /// Sender for the final concatenated message. Replaced on each reset.
    result_tx: Option<tokio::sync::oneshot::Sender<String>>,
}

/// Accumulates rapid inbound messages per sender and fires a single combined
/// message after the debounce window elapses without new input.
pub struct MessageDebouncer {
    window: Duration,
    entries: Arc<Mutex<HashMap<String, DebouncerEntry>>>,
}

impl MessageDebouncer {
    /// Create a new debouncer with the given window.
    /// A zero duration disables debouncing (all messages pass through).
    pub fn new(window: Duration) -> Self {
        Self {
            window,
            entries: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Returns `true` when debouncing is active (non-zero window).
    pub fn enabled(&self) -> bool {
        !self.window.is_zero()
    }

    /// Submit a message for debouncing using the debouncer's default window.
    ///
    /// - If the window is zero, returns [`DebounceResult::Passthrough`] immediately.
    /// - Otherwise, accumulates the message under `sender_key` and returns
    ///   [`DebounceResult::Pending`] with a receiver that will eventually yield the
    ///   concatenated messages once the window expires.
    ///
    /// Each new message resets the timer. When the timer fires it concatenates all
    /// accumulated messages with `"\n"` and sends them through the oneshot channel.
    pub async fn debounce(&self, sender_key: &str, message: &str) -> DebounceResult {
        self.debounce_inner(sender_key, message, self.window).await
    }

    /// Submit a message for debouncing with an explicit per-call window.
    ///
    /// Behaves identically to [`debounce`](Self::debounce) but uses the provided
    /// `window` instead of the debouncer's default. This is used by channels that
    /// override the global debounce window (e.g., per-alias Telegram config).
    pub async fn debounce_with_window(
        &self,
        sender_key: &str,
        message: &str,
        window: Duration,
    ) -> DebounceResult {
        self.debounce_inner(sender_key, message, window).await
    }

    /// Cancel and remove an open accumulation bucket.
    ///
    /// Dropping the bucket's result sender wakes its receiver with an error,
    /// so callers can retire any position reserved for the cancelled turn.
    /// The next message for the same key always opens a fresh bucket.
    pub async fn cancel(&self, sender_key: &str) -> bool {
        let entry = self.entries.lock().await.remove(sender_key);
        if let Some(entry) = entry {
            entry.timer_handle.abort();
            true
        } else {
            false
        }
    }

    async fn debounce_inner(
        &self,
        sender_key: &str,
        message: &str,
        window: Duration,
    ) -> DebounceResult {
        if window.is_zero() {
            return DebounceResult::Passthrough(message.to_owned());
        }

        let mut entries = self.entries.lock().await;
        let entries_ref = Arc::clone(&self.entries);
        let key = sender_key.to_owned();

        if let Some(entry) = entries.get_mut(&key) {
            entry.timer_handle.abort();
            entry.messages.push(message.to_owned());

            let (tx, rx) = tokio::sync::oneshot::channel();
            entry.result_tx = Some(tx);

            entry.timer_handle = zeroclaw_spawn::spawn!(async move {
                tokio::time::sleep(window).await;
                fire_debounced(&entries_ref, &key).await;
            });

            DebounceResult::Pending { rx, extended: true }
        } else {
            let (tx, rx) = tokio::sync::oneshot::channel();

            let key_clone = key.clone();
            let entries_spawn = Arc::clone(&self.entries);
            let handle = zeroclaw_spawn::spawn!(async move {
                tokio::time::sleep(window).await;
                fire_debounced(&entries_spawn, &key_clone).await;
            });

            entries.insert(
                key,
                DebouncerEntry {
                    messages: vec![message.to_owned()],
                    timer_handle: handle,
                    result_tx: Some(tx),
                },
            );

            DebounceResult::Pending {
                rx,
                extended: false,
            }
        }
    }
}

/// Called when the debounce timer fires. Removes the entry, concatenates all
/// accumulated messages, and sends the result through the oneshot channel.
async fn fire_debounced(entries: &Mutex<HashMap<String, DebouncerEntry>>, key: &str) {
    let mut map = entries.lock().await;
    if let Some(entry) = map.remove(key) {
        let combined = entry.messages.join("\n");
        if let Some(tx) = entry.result_tx {
            let _ = tx.send(combined);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn passthrough_when_disabled() {
        let debouncer = MessageDebouncer::new(Duration::ZERO);
        assert!(!debouncer.enabled());
        match debouncer.debounce("user1", "hello").await {
            DebounceResult::Passthrough(msg) => assert_eq!(msg, "hello"),
            DebounceResult::Pending { .. } => panic!("expected Passthrough"),
        }
    }

    #[tokio::test]
    async fn single_message_fires_after_window() {
        let debouncer = MessageDebouncer::new(Duration::from_millis(50));
        let rx = match debouncer.debounce("user1", "hello").await {
            DebounceResult::Pending { rx, .. } => rx,
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };
        let combined = rx.await.unwrap();
        assert_eq!(combined, "hello");
    }

    #[tokio::test]
    async fn multiple_messages_concatenated() {
        let debouncer = MessageDebouncer::new(Duration::from_millis(100));

        let _rx1 = match debouncer.debounce("user1", "hello").await {
            DebounceResult::Pending { rx, .. } => rx,
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };

        tokio::time::sleep(Duration::from_millis(30)).await;
        let rx2 = match debouncer.debounce("user1", "world").await {
            DebounceResult::Pending { rx, .. } => rx,
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };

        let combined = rx2.await.unwrap();
        assert_eq!(combined, "hello\nworld");
    }

    #[tokio::test]
    async fn extended_flag_tracks_bucket_boundaries() {
        let debouncer = MessageDebouncer::new(Duration::from_millis(50));

        // First message opens a bucket…
        let rx1 = match debouncer.debounce("user1", "one").await {
            DebounceResult::Pending { rx, extended } => {
                assert!(!extended, "first message must open a bucket");
                rx
            }
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };

        // …a rapid follow-up extends it and supersedes the first receiver…
        let rx2 = match debouncer.debounce("user1", "two").await {
            DebounceResult::Pending { rx, extended } => {
                assert!(extended, "rapid follow-up must extend the open bucket");
                rx
            }
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };
        assert!(rx1.await.is_err(), "superseded receiver must resolve Err");
        assert_eq!(rx2.await.unwrap(), "one\ntwo");

        // …and once the bucket fired, the next message opens a new one.
        match debouncer.debounce("user1", "three").await {
            DebounceResult::Pending { extended, .. } => {
                assert!(!extended, "a delivered bucket must not be extendable");
            }
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        }
    }

    #[tokio::test]
    async fn different_senders_independent() {
        let debouncer = MessageDebouncer::new(Duration::from_millis(50));

        let rx_a = match debouncer.debounce("alice", "hi alice").await {
            DebounceResult::Pending { rx, .. } => rx,
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };
        let rx_b = match debouncer.debounce("bob", "hi bob").await {
            DebounceResult::Pending { rx, .. } => rx,
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };

        assert_eq!(rx_a.await.unwrap(), "hi alice");
        assert_eq!(rx_b.await.unwrap(), "hi bob");
    }

    #[tokio::test]
    async fn cancel_makes_the_next_message_open_a_fresh_bucket() {
        let debouncer = MessageDebouncer::new(Duration::from_millis(50));
        let cancelled = match debouncer.debounce("user1", "before stop").await {
            DebounceResult::Pending { rx, extended } => {
                assert!(!extended);
                rx
            }
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };

        assert!(debouncer.cancel("user1").await);
        assert!(cancelled.await.is_err());

        let fresh = match debouncer.debounce("user1", "after stop").await {
            DebounceResult::Pending { rx, extended } => {
                assert!(!extended);
                rx
            }
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };
        assert_eq!(fresh.await.unwrap(), "after stop");
        assert!(!debouncer.cancel("user1").await);
    }

    #[tokio::test]
    async fn debounce_with_window_passthrough_when_zero() {
        let debouncer = MessageDebouncer::new(Duration::from_millis(100));
        assert!(debouncer.enabled());
        match debouncer
            .debounce_with_window("user1", "hello", Duration::ZERO)
            .await
        {
            DebounceResult::Passthrough(msg) => assert_eq!(msg, "hello"),
            DebounceResult::Pending { .. } => panic!("expected Passthrough"),
        }
    }

    #[tokio::test]
    async fn debounce_with_window_overrides_default() {
        let debouncer = MessageDebouncer::new(Duration::from_millis(5000)); // long default
        let rx = match debouncer
            .debounce_with_window("user1", "fast", Duration::from_millis(50))
            .await
        {
            DebounceResult::Pending { rx, .. } => rx,
            DebounceResult::Passthrough(_) => panic!("expected Pending"),
        };
        let combined = rx.await.unwrap();
        assert_eq!(combined, "fast");
    }
}
