//! `zerorelay` - the ZeroClaw nominated relay (blind forwarder, blind by
//! default).
//!
//! Runs a public rendezvous: daemons behind NAT register over an outer TLS +
//! WebSocket session and clients reach them by an opaque `node_id`. The relay
//! pipes the inner client<->daemon mTLS as ciphertext and never terminates it.
//!
//! `--frontdoor` (default off) opts into the browser enrollment path, which is
//! **relay-terminated**: the relay serves the page and performs the enrollment
//! exchange for browsers, so it sees their pairing code and issued certificate.
//! It announces that with a startup warning. The data plane stays blind in
//! every mode.
//!
//! `[dashboard]` (default off) serves allowlisted daemons' web dashboards at
//! per-node hosts `https://<label>.<domain>/`, with the operator's wildcard
//! certificate. That route is relay-terminated too: the relay forwards those
//! dashboards' plaintext HTTP, and warns at startup.
//!
//! `zerorelay` is a standalone networking app (not daemon-path code), so bare
//! `tokio::spawn` is the right primitive here; the `zeroclaw_spawn::spawn!` rule
//! is for in-daemon tasks. Mirrors the `apps/zerocode` exemption (and lib.rs).
#![allow(clippy::disallowed_methods)]

use std::fs::File;
use std::io::BufReader;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;

use std::collections::HashSet;

use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use rustls::pki_types::{CertificateDer, PrivateKeyDer};
use serde::Deserialize;
use tokio_rustls::TlsAcceptor;
use zerorelay::{
    Admission, AdmissionPolicy, DashboardConfig, PublicOpenGuard, RelayConfig, RelayServer,
    RelayStatus, check_dashboard_startup,
};

/// Package version and `git describe` build id stamped by `build.rs`.
const VERSION: &str = env!("ZEROCLAW_VERSION");

#[derive(Parser, Debug)]
#[command(
    name = "zerorelay",
    about = "ZeroClaw nominated relay (blind forwarder)",
    version = VERSION
)]
struct Cli {
    #[command(subcommand)]
    command: Option<Command>,

    /// Path to a relay.toml ([bind]/[tls]/[admission]/[limits]). Values it sets
    /// are the base config; any CLI flag below overrides the file. The
    /// [admission] section hot-reloads on SIGHUP. See relay.example.toml.
    #[arg(long)]
    config: Option<String>,

    /// Address to listen on for daemon and client connections. [default: 0.0.0.0:8443]
    #[arg(long)]
    bind: Option<String>,

    /// PEM certificate for the relay's own outer TLS identity (chain). When this
    /// and --tls-key are omitted, the relay SELF-PROVISIONS a cert (no openssl).
    #[arg(long)]
    tls_cert: Option<String>,

    /// PEM private key for `--tls-cert`.
    #[arg(long)]
    tls_key: Option<String>,

    /// Directory for the self-provisioned TLS material (CA + server cert, written
    /// on first run when --tls-cert/--tls-key are not given, reused after).
    /// Default: $ZERORELAY_DATA_DIR or $HOME/.zerorelay, under tls/.
    #[arg(long)]
    tls_dir: Option<String>,

    /// Extra Subject Alternative Name(s) for the self-provisioned cert (the relay's
    /// public hostname / IP). localhost + 127.0.0.1 are always included. Repeatable.
    #[arg(long = "tls-san")]
    tls_san: Vec<String>,

    /// Admission mode: `open` (any signed daemon may register) or `allowlist`.
    /// [default: open]
    #[arg(long)]
    registration_mode: Option<String>,

    /// Allowed daemon pubkey fingerprints (sha256 hex), allowlist mode. Unioned
    /// with the file's [admission] allow list. Repeatable.
    #[arg(long = "allow")]
    allow: Vec<String>,

    /// Denied daemon pubkey fingerprints (always rejected). Unioned with the
    /// file's deny list. Repeatable.
    #[arg(long = "deny")]
    deny: Vec<String>,

    /// Optional shared-secret gate a daemon must present in its Hello.
    #[arg(long)]
    relay_token: Option<String>,

    /// Cap on simultaneously-open client connections per node-id. [default: 256]
    #[arg(long)]
    max_conns_per_node: Option<usize>,

    /// Drop a client connection after this many seconds of inactivity. [default: 300]
    #[arg(long)]
    idle_timeout_secs: Option<u64>,

    /// Lease TTL (seconds) advertised to daemons at registration. [default: 300]
    #[arg(long)]
    lease_ttl_secs: Option<u64>,

    /// Global cap on sockets past accept but not yet admitted (TLS handshake, WS
    /// upgrade, first control frame, and any refusal reply); excess sockets are
    /// shed. Admitted connections do not count. [default: 256]
    #[arg(long)]
    max_pending_handshakes: Option<usize>,

    /// Ceiling on simultaneously registered daemons. [default: 1024]
    #[arg(long)]
    max_registered_nodes: Option<usize>,

    /// Deadline (seconds) covering TLS accept, the WS upgrade, and the first
    /// control frame. [default: 10]
    #[arg(long)]
    handshake_timeout_secs: Option<u64>,

    /// Write a per-node metrics snapshot (JSON) to this path, refreshed on a timer
    /// and on SIGUSR1. Read it back with `zerorelay status --file <path>`.
    #[arg(long)]
    status_file: Option<String>,

    /// Serve the browser enrollment frontdoor (default off). Enabling makes this
    /// relay a trusted code origin AND a participant in browser enrollment - see
    /// relay.example.toml [frontdoor] for the trust implications.
    #[arg(long)]
    frontdoor: bool,

    /// Explicitly allow OPEN, tokenless registration on a public (non-loopback)
    /// bind. Without this, such a configuration refuses to start: any daemon on
    /// the internet could register and squat unclaimed node-ids. Prefer setting
    /// [admission] relay_token or mode = "allowlist".
    #[arg(long)]
    allow_public_open: bool,
}

/// A `relay.toml`: every value optional, CLI flags override. The `[admission]`
/// slice is what SIGHUP re-reads and swaps live.
#[derive(Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
struct FileConfig {
    bind: Option<String>,
    #[serde(default)]
    tls: TlsFile,
    #[serde(default)]
    admission: AdmissionFile,
    #[serde(default)]
    limits: LimitsFile,
    #[serde(default)]
    frontdoor: FrontdoorFile,
    #[serde(default)]
    dashboard: DashboardFile,
}

#[derive(Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
struct DashboardFile {
    /// Serve allowlisted daemons' dashboards at `https://<label>.<domain>/`.
    /// OFF by default; see relay.example.toml [dashboard] for the trust
    /// implications.
    enabled: Option<bool>,
    /// The dashboard domain; `*.<domain>` must resolve to this relay.
    domain: Option<String>,
    /// A publicly trusted certificate (chain) and key covering `*.<domain>`.
    cert: Option<String>,
    key: Option<String>,
    /// Registration-key fingerprints (sha256 hex) of the daemons whose
    /// dashboards this relay serves. Required.
    #[serde(default)]
    allow: Vec<String>,
    /// Concurrent dashboard connections to one daemon. [default: 64]
    max_conns_per_node: Option<usize>,
    /// Concurrent dashboard connections from one browser address. [default: 16]
    max_conns_per_ip: Option<usize>,
}

/// The dashboard's TLS identity, served for server names under its domain.
struct DashboardTls {
    domain: String,
    certs: Vec<CertificateDer<'static>>,
    key: PrivateKeyDer<'static>,
}

// By hand, so the private key can never reach a log or a panic message.
impl std::fmt::Debug for DashboardTls {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DashboardTls")
            .field("domain", &self.domain)
            .field("certs", &self.certs.len())
            .finish_non_exhaustive()
    }
}

/// Resolve `[dashboard]`: its routing settings and its certificate, or `None`
/// when it is off. Refuses what [`check_dashboard_startup`] refuses, and a
/// dashboard without its own certificate: browsers must get a publicly
/// trusted one, which a self-provisioned relay certificate is not.
fn resolve_dashboard(file: &DashboardFile) -> Result<Option<(DashboardConfig, DashboardTls)>> {
    if !file.enabled.unwrap_or(false) {
        return Ok(None);
    }
    let cfg = DashboardConfig {
        domain: file.domain.clone().unwrap_or_default(),
        allow: normalize_admission_fingerprints(&file.allow)?,
        max_conns_per_node: file.max_conns_per_node.unwrap_or(64),
        max_conns_per_ip: file.max_conns_per_ip.unwrap_or(16),
    };
    check_dashboard_startup(&cfg)?;
    let (Some(cert), Some(key)) = (&file.cert, &file.key) else {
        anyhow::bail!(
            "refusing to start: [dashboard] needs cert and key, a publicly trusted certificate \
             for *.{} (browsers do not trust a self-provisioned one)",
            cfg.domain
        );
    };
    let tls = DashboardTls {
        domain: cfg.domain.clone(),
        certs: load_certs(cert).with_context(|| format!("loading [dashboard] cert {cert}"))?,
        key: load_key(key).with_context(|| format!("loading [dashboard] key {key}"))?,
    };
    Ok(Some((cfg, tls)))
}

/// Present the dashboard certificate for server names under its domain and
/// the relay's own everywhere else.
#[derive(Debug)]
struct DashboardSni {
    relay: Arc<rustls::sign::CertifiedKey>,
    dashboard: Arc<rustls::sign::CertifiedKey>,
    /// `.<domain>`
    suffix: String,
}

impl rustls::server::ResolvesServerCert for DashboardSni {
    fn resolve(
        &self,
        hello: rustls::server::ClientHello<'_>,
    ) -> Option<Arc<rustls::sign::CertifiedKey>> {
        let under_domain = hello
            .server_name()
            .is_some_and(|name| name.to_ascii_lowercase().ends_with(&self.suffix));
        Some(Arc::clone(if under_domain {
            &self.dashboard
        } else {
            &self.relay
        }))
    }
}

#[derive(Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
struct FrontdoorFile {
    /// Serve the browser enrollment frontdoor from this relay. OFF by default:
    /// enabling makes this relay a trusted code origin for enrolling browsers
    /// and a principal in their enrollment (see relay.example.toml for the
    /// trust implications).
    enabled: Option<bool>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
struct TlsFile {
    cert: Option<String>,
    key: Option<String>,
    dir: Option<String>,
    #[serde(default)]
    sans: Vec<String>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
struct AdmissionFile {
    /// "open" | "allowlist".
    mode: Option<String>,
    #[serde(default)]
    allow: Vec<String>,
    #[serde(default)]
    deny: Vec<String>,
    relay_token: Option<String>,
    /// Outer-mTLS variant (additive admission on the OUTER TLS): "off" (default),
    /// "optional", or "required". When on, `outer_client_ca` verifies the peer's
    /// outer client cert. The inner mTLS is unaffected.
    outer_client_auth: Option<String>,
    /// PEM CA verifying outer client certs (required when outer_client_auth is on).
    outer_client_ca: Option<String>,
    /// Route to the node-id named by the outer client cert's CN, falling back to
    /// the `Connect` frame (default false; only meaningful with outer client auth).
    route_by_client_cert: Option<bool>,
    /// See the --allow-public-open flag: opt-in for open+tokenless on a public bind.
    allow_public_open: Option<bool>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
struct LimitsFile {
    max_conns_per_node: Option<usize>,
    idle_timeout_secs: Option<u64>,
    lease_ttl_secs: Option<u64>,
    /// Per-source-IP connection-handshake rate cap (A6).
    accept_burst_per_ip: Option<u32>,
    accept_rate_per_ip: Option<f64>,
    /// Per-node-id client-connect rate cap (A6).
    connect_burst_per_node: Option<u32>,
    connect_rate_per_node: Option<f64>,
    /// Global pre-classification handshake bound + deadline (slowloris).
    max_pending_handshakes: Option<usize>,
    handshake_timeout_secs: Option<u64>,
    /// Aggregate ceiling on simultaneously registered daemons.
    max_registered_nodes: Option<usize>,
}

/// The CLI admission overrides, captured so SIGHUP can re-apply them on top of a
/// freshly re-read file without re-parsing argv.
#[derive(Clone)]
struct AdmissionOverlay {
    mode: Option<String>,
    allow: Vec<String>,
    deny: Vec<String>,
    relay_token: Option<String>,
}

/// Resolve the admission policy: file `[admission]` as the base, CLI overlay on
/// top. Scalars (mode, relay_token) take the CLI value when present; the allow /
/// deny lists are the UNION of file + CLI. Deny always wins at admission time.
fn normalize_admission_fingerprint(value: &str) -> Result<String> {
    let normalized: String = value.trim().chars().filter(|c| *c != ':').collect();
    if normalized.len() != 64 || !normalized.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        anyhow::bail!(
            "invalid relay admission fingerprint '{value}': expected 64 hexadecimal characters, optionally colon-delimited"
        );
    }
    Ok(normalized.to_ascii_lowercase())
}

fn normalize_admission_fingerprints(entries: &[String]) -> Result<HashSet<String>> {
    entries
        .iter()
        .map(|entry| normalize_admission_fingerprint(entry))
        .collect()
}

fn resolve_admission(file: &AdmissionFile, overlay: &AdmissionOverlay) -> Result<AdmissionPolicy> {
    let mode_str = overlay.mode.clone().or_else(|| file.mode.clone());
    let registration_mode = match mode_str.as_deref() {
        None | Some("open") => Admission::Open,
        Some("allowlist") => Admission::Allowlist,
        Some(other) => anyhow::bail!("invalid admission mode '{other}' (open|allowlist)"),
    };
    let mut allow = normalize_admission_fingerprints(&file.allow)?;
    allow.extend(normalize_admission_fingerprints(&overlay.allow)?);
    let mut deny = normalize_admission_fingerprints(&file.deny)?;
    deny.extend(normalize_admission_fingerprints(&overlay.deny)?);
    let relay_token = overlay
        .relay_token
        .clone()
        .or_else(|| file.relay_token.clone());
    Ok(AdmissionPolicy {
        registration_mode,
        allow,
        deny,
        relay_token,
    })
}

/// Load and parse a relay.toml.
fn load_file_config(path: &str) -> Result<FileConfig> {
    let text =
        std::fs::read_to_string(path).with_context(|| format!("reading relay config {path}"))?;
    toml::from_str(&text).with_context(|| format!("parsing relay config {path}"))
}

/// Read a relay `--status-file` snapshot and print it as a per-node table.
fn print_status(path: &str) -> Result<()> {
    let text = std::fs::read_to_string(path).with_context(|| {
        format!("reading status file {path} (is --status-file set on the relay?)")
    })?;
    let status: RelayStatus =
        serde_json::from_str(text.trim()).with_context(|| format!("parsing status file {path}"))?;
    if status.nodes.is_empty() {
        println!("no registered nodes");
        return Ok(());
    }
    println!(
        "{:<34}  {:>5}  {:>6}  {:>8}  {:>8}",
        "node_id", "live", "total", "frames", "rejected"
    );
    for n in &status.nodes {
        println!(
            "{:<34}  {:>5}  {:>6}  {:>8}  {:>8}",
            n.node_id, n.conns_live, n.conns_total, n.frames_relayed, n.connects_rejected
        );
    }
    Ok(())
}

#[derive(Subcommand, Debug)]
enum Command {
    /// TCP-connect to a running relay and exit 0 if reachable. For container
    /// HEALTHCHECK on shell-less images.
    Healthcheck {
        /// Address to probe.
        #[arg(long, default_value = "127.0.0.1:8443")]
        addr: String,
    },
    /// Print the running relay's per-node metrics from its --status-file snapshot
    /// (counts only, never payloads). Send the relay SIGUSR1 first to refresh it.
    Status {
        /// Path to the relay's --status-file.
        #[arg(long)]
        file: String,
    },
}

#[tokio::main]
async fn main() -> Result<()> {
    let cli = Cli::parse();

    if let Some(Command::Healthcheck { addr }) = &cli.command {
        tokio::net::TcpStream::connect(addr)
            .await
            .with_context(|| format!("relay not reachable at {addr}"))?;
        return Ok(());
    }

    if let Some(Command::Status { file }) = &cli.command {
        return print_status(file);
    }

    // relay.toml is the base; CLI flags override. Absent --config => an empty
    // file config, so the CLI + builtin defaults reproduce the prior behavior.
    let file = match cli.config.as_deref() {
        Some(path) => load_file_config(path)?,
        None => FileConfig::default(),
    };

    // The CLI admission overlay is captured so SIGHUP can re-apply it onto a
    // freshly re-read file.
    let overlay = AdmissionOverlay {
        mode: cli.registration_mode.clone(),
        allow: cli.allow.clone(),
        deny: cli.deny.clone(),
        relay_token: cli.relay_token.clone(),
    };
    let admission = resolve_admission(&file.admission, &overlay)?;

    // Outer-mTLS variant (additive): optionally require/accept an outer client
    // cert, verified against outer_client_ca. The inner mTLS is untouched.
    let outer_verifier = build_outer_client_verifier(&file.admission)?;
    let route_by_client_cert = file.admission.route_by_client_cert.unwrap_or(false);

    // TLS material: CLI flag -> file [tls] -> self-provision.
    let tls_cert = cli.tls_cert.clone().or_else(|| file.tls.cert.clone());
    let tls_key = cli.tls_key.clone().or_else(|| file.tls.key.clone());
    let tls_dir = cli.tls_dir.clone().or_else(|| file.tls.dir.clone());
    let mut tls_sans = file.tls.sans.clone();
    tls_sans.extend(cli.tls_san.iter().cloned());
    // `[dashboard]` is resolved, and refused if it must be, before any TLS
    // material or socket is set up.
    let dashboard = resolve_dashboard(&file.dashboard)?;
    let dashboard_tls = dashboard.as_ref().map(|(_, tls)| tls);
    let acceptor = match (tls_cert, tls_key) {
        // Bring-your-own (e.g. a public-CA cert for the relay's hostname).
        (Some(cert), Some(key)) => {
            build_tls_acceptor(&cert, &key, outer_verifier.clone(), dashboard_tls)
                .with_context(|| format!("loading relay TLS material from {cert} / {key}"))?
        }
        // Self-provision a cert on first run - no openssl needed.
        (None, None) => provision_tls_acceptor(
            tls_dir.as_deref(),
            &tls_sans,
            outer_verifier.clone(),
            dashboard_tls,
        )?,
        _ => {
            anyhow::bail!("tls cert and key must be given together (or neither, to self-provision)")
        }
    };

    let bind = cli
        .bind
        .clone()
        .or_else(|| file.bind.clone())
        .unwrap_or_else(|| "0.0.0.0:8443".to_string());
    let cfg = RelayConfig {
        registration_mode: admission.registration_mode.clone(),
        allow: admission.allow.clone(),
        deny: admission.deny.clone(),
        relay_token: admission.relay_token.clone(),
        lease_ttl: Duration::from_secs(
            cli.lease_ttl_secs
                .or(file.limits.lease_ttl_secs)
                .unwrap_or(300),
        ),
        max_conns_per_node: cli
            .max_conns_per_node
            .or(file.limits.max_conns_per_node)
            .unwrap_or(256),
        idle_timeout: Duration::from_secs(
            cli.idle_timeout_secs
                .or(file.limits.idle_timeout_secs)
                .unwrap_or(300),
        ),
        accept_burst_per_ip: file.limits.accept_burst_per_ip.unwrap_or(30),
        accept_rate_per_ip: file.limits.accept_rate_per_ip.unwrap_or(10.0),
        connect_burst_per_node: file.limits.connect_burst_per_node.unwrap_or(60),
        connect_rate_per_node: file.limits.connect_rate_per_node.unwrap_or(20.0),
        route_by_client_cert,
        max_pending_handshakes: cli
            .max_pending_handshakes
            .or(file.limits.max_pending_handshakes)
            .unwrap_or(256),
        handshake_timeout: Duration::from_secs(
            cli.handshake_timeout_secs
                .or(file.limits.handshake_timeout_secs)
                .unwrap_or(10),
        ),
        max_registered_nodes: cli
            .max_registered_nodes
            .or(file.limits.max_registered_nodes)
            .unwrap_or(1024),
        frontdoor_enabled: cli.frontdoor || file.frontdoor.enabled.unwrap_or(false),
        dashboard: dashboard.map(|(cfg, _)| cfg),
    };

    // Fail closed (AGENTS.md: new external surfaces default closed): an OPEN,
    // tokenless relay on a public bind admits any daemon on the internet and
    // lets unclaimed node-ids be squatted. Refuse to start unless the operator
    // explicitly opts in — loopback binds (dev/tests) are unaffected. The same
    // guard is re-applied to every SIGHUP reload below, which is why the CLI
    // opt-in is kept rather than consumed here.
    PublicOpenGuard::new(
        &bind,
        cli.allow_public_open || file.admission.allow_public_open.unwrap_or(false),
    )
    .check_startup(&admission)?;

    let listener = tokio::net::TcpListener::bind(&bind)
        .await
        .with_context(|| format!("binding relay on {bind}"))?;
    let addr = listener.local_addr()?;
    eprintln!(
        "zerorelay listening on {addr} (outer TLS, mode: {:?}, frontdoor: {})",
        cfg.registration_mode,
        if cfg.frontdoor_enabled { "on" } else { "off" }
    );
    if cfg.frontdoor_enabled {
        eprintln!(
            "zerorelay WARNING: the browser enrollment frontdoor is enabled. This \
             relay now SERVES the enrollment page and PERFORMS the enrollment \
             exchange with the daemon on each browser's behalf, because a browser \
             cannot speak the daemon's TLS enrollment protocol itself. For those \
             browsers this relay therefore sees the PAIRING CODE and the ISSUED \
             CERTIFICATE, and could use a pairing code it observes to enrol a \
             client of its own. It does NOT see their private keys, which are \
             generated in the browser. Browser enrollment through this relay is \
             relay-terminated, not end-to-end: anyone who can modify this relay \
             can intercept it. The short-auth-string only lets an operator DETECT \
             a substituted daemon CA. Browsers are offered enrollment only - no \
             sessions - and the blind-forwarder guarantee still holds for the RPC \
             plane and for zerocode/native enrollment. Disable [frontdoor] to \
             withdraw that trust."
        );
    }
    if let Some(dashboard) = &cfg.dashboard {
        eprintln!(
            "zerorelay WARNING: [dashboard] is enabled. This relay serves the web dashboards \
             of {} allowlisted daemon(s) at https://<label>.{}/ and ENDS THOSE BROWSERS' TLS: \
             it forwards their dashboard traffic to the daemon in plaintext over the daemon's \
             relay link. Anyone who can modify this relay can read and change that traffic, \
             including session cookies, and act as a signed-in user, with an \
             administrator's session as an administrator. The blind-forwarder guarantee \
             still holds for the RPC plane and for zerocode/native clients. Disable \
             [dashboard] to withdraw that trust.",
            dashboard.allow.len(),
            dashboard.domain
        );
    }

    let server = RelayServer::new(cfg);
    spawn_sighup_reloader(
        server.clone(),
        cli.config.clone(),
        overlay,
        bind.clone(),
        cli.allow_public_open,
    );
    spawn_status_dumper(server.clone(), cli.status_file.clone());
    server.serve(listener, acceptor).await
}

/// On SIGUSR1, snapshot per-node metrics to stderr (and to `--status-file` when
/// set) - a read-only operational surface for a shell-less/stateless relay. Also
/// refreshes the status file on a slow timer so `zerorelay status --file` stays
/// reasonably current. No-op for the signal half on non-unix.
#[cfg(unix)]
fn spawn_status_dumper(server: RelayServer, status_file: Option<String>) {
    use std::time::Duration as StdDuration;
    tokio::spawn(async move {
        let mut usr1 =
            match tokio::signal::unix::signal(tokio::signal::unix::SignalKind::user_defined1()) {
                Ok(s) => s,
                Err(e) => {
                    eprintln!("zerorelay: cannot install SIGUSR1 handler ({e}); status dump off");
                    return;
                }
            };
        let mut tick = tokio::time::interval(StdDuration::from_secs(15));
        loop {
            let on_signal = tokio::select! {
                _ = usr1.recv() => true,
                _ = tick.tick() => false,
            };
            let status = server.status().await;
            let json = serde_json::to_string(&status).unwrap_or_else(|_| "{}".to_string());
            if let Some(path) = status_file.as_deref() {
                let _ = std::fs::write(path, format!("{json}\n"));
            }
            if on_signal {
                eprintln!("zerorelay status: {json}");
            }
        }
    });
}

#[cfg(not(unix))]
fn spawn_status_dumper(server: RelayServer, status_file: Option<String>) {
    use std::time::Duration as StdDuration;
    tokio::spawn(async move {
        let mut tick = tokio::time::interval(StdDuration::from_secs(15));
        loop {
            tick.tick().await;
            if let Some(path) = status_file.as_deref() {
                let status = server.status().await;
                let json = serde_json::to_string(&status).unwrap_or_else(|_| "{}".to_string());
                let _ = std::fs::write(path, format!("{json}\n"));
            }
        }
    });
}

/// One admission reload: re-read the file, re-apply the startup CLI overlay, and
/// swap the live policy - unless the fail-closed public-open guard refuses it.
///
/// `bind` and `cli_allow_public_open` are carried from startup because neither
/// hot-reloads: the listener is already bound, and the opt-in is a deliberate
/// operator choice. Without them a reload could turn a token-gated or
/// allowlisted public relay into an open, tokenless one - the exact
/// configuration startup refuses. The opt-in is the CLI flag OR the freshly
/// re-read file's own `allow_public_open`, matching startup's rule so an
/// operator who genuinely wants an open public relay can still say so in the
/// same edit.
///
/// Unix-only, like the SIGHUP handler that drives it.
#[cfg(unix)]
fn reload_admission_once(
    server: &RelayServer,
    path: &str,
    overlay: &AdmissionOverlay,
    bind: &str,
    cli_allow_public_open: bool,
) -> Result<()> {
    let file = load_file_config(path)?;
    let policy = resolve_admission(&file.admission, overlay)?;
    let guard = PublicOpenGuard::new(
        bind,
        cli_allow_public_open || file.admission.allow_public_open.unwrap_or(false),
    );
    server.reload_admission(policy, &guard)
}

/// On SIGHUP, re-read the config file's `[admission]` section and swap the live
/// admission policy (allow/deny/mode/token), re-applying the startup CLI overlay.
/// Live connections are untouched. No-op when there is no `--config` file.
#[cfg(unix)]
fn spawn_sighup_reloader(
    server: RelayServer,
    config_path: Option<String>,
    overlay: AdmissionOverlay,
    bind: String,
    cli_allow_public_open: bool,
) {
    tokio::spawn(async move {
        let mut sighup = match tokio::signal::unix::signal(tokio::signal::unix::SignalKind::hangup())
        {
            Ok(s) => s,
            Err(e) => {
                eprintln!("zerorelay: cannot install SIGHUP handler ({e}); admission reload off");
                return;
            }
        };
        while sighup.recv().await.is_some() {
            let Some(path) = config_path.as_deref() else {
                eprintln!("zerorelay: SIGHUP ignored (no --config to reload)");
                continue;
            };
            match reload_admission_once(&server, path, &overlay, &bind, cli_allow_public_open) {
                Ok(()) => eprintln!("zerorelay: reloaded admission from {path} (SIGHUP)"),
                Err(e) => {
                    eprintln!("zerorelay: SIGHUP reload failed, keeping current policy ({e:#})");
                }
            }
        }
    });
}

#[cfg(not(unix))]
fn spawn_sighup_reloader(
    _server: RelayServer,
    _config_path: Option<String>,
    _overlay: AdmissionOverlay,
    _bind: String,
    _cli_allow_public_open: bool,
) {
}

/// Build an outer client-cert verifier for the outer-mTLS variant, or `None` when
/// `outer_client_auth` is off. "optional" accepts unauthenticated peers too;
/// "required" rejects a peer without a valid outer client cert.
fn build_outer_client_verifier(
    admission: &AdmissionFile,
) -> Result<Option<Arc<dyn rustls::server::danger::ClientCertVerifier>>> {
    let mode = admission.outer_client_auth.as_deref().unwrap_or("off");
    match mode {
        "off" => Ok(None),
        "optional" | "required" => {
            let ca = admission.outer_client_ca.clone().ok_or_else(|| {
                anyhow::Error::msg(format!(
                    "[admission].outer_client_auth = {mode} requires [admission].outer_client_ca"
                ))
            })?;
            let verifier = zeroclaw_tls::build_client_verifier(&zeroclaw_tls::ClientAuthParams {
                ca_cert_path: ca,
                require_client_cert: mode == "required",
                pinned_certs: vec![],
                crl_path: String::new(),
            })?;
            Ok(Some(verifier))
        }
        other => {
            anyhow::bail!("invalid [admission].outer_client_auth '{other}' (off|optional|required)")
        }
    }
}

/// Build the outer TLS acceptor from the relay's own server cert + key. Outer TLS
/// is server-authenticated; `client_verifier` adds the optional outer-mTLS variant
/// (additive admission), but the inner mTLS stays the real RPC security boundary.
///
/// With `[dashboard]`, server names under its domain get the dashboard
/// certificate, and the listener offers HTTP/1.1 alone by ALPN: over HTTP/2 a
/// browser may reuse one connection for every host a certificate covers,
/// which would carry one dashboard's requests to another's daemon. The relay
/// plane's own clients offer no ALPN, so they are unaffected.
fn build_tls_acceptor(
    cert_path: &str,
    key_path: &str,
    client_verifier: Option<Arc<dyn rustls::server::danger::ClientCertVerifier>>,
    dashboard: Option<&DashboardTls>,
) -> Result<TlsAcceptor> {
    let certs = load_certs(cert_path)?;
    let key = load_key(key_path)?;
    let provider = rustls::crypto::ring::default_provider();
    let key_provider = provider.key_provider;
    let builder = rustls::ServerConfig::builder_with_provider(Arc::new(provider))
        .with_safe_default_protocol_versions()
        .context("ring provider supports the default protocol versions")?;
    let builder = match client_verifier {
        Some(v) => builder.with_client_cert_verifier(v),
        None => builder.with_no_client_auth(),
    };
    let config = match dashboard {
        None => builder
            .with_single_cert(certs, key)
            .context("relay cert/key are not a valid pair")?,
        Some(dashboard) => {
            let certified = |certs: Vec<CertificateDer<'static>>,
                             key: PrivateKeyDer<'static>,
                             what: &str|
             -> Result<Arc<rustls::sign::CertifiedKey>> {
                let signing = key_provider
                    .load_private_key(key)
                    .with_context(|| format!("{what} key is not a usable private key"))?;
                Ok(Arc::new(rustls::sign::CertifiedKey::new(certs, signing)))
            };
            let mut config = builder.with_cert_resolver(Arc::new(DashboardSni {
                relay: certified(certs, key, "relay")?,
                dashboard: certified(
                    dashboard.certs.clone(),
                    dashboard.key.clone_key(),
                    "[dashboard]",
                )?,
                suffix: format!(".{}", dashboard.domain),
            }));
            config.alpn_protocols = vec![b"http/1.1".to_vec()];
            config
        }
    };
    Ok(TlsAcceptor::from(Arc::new(config)))
}

/// Self-provision the relay's outer TLS cert (CA + server leaf with SANs) on first
/// run, reusing the daemon's `zeroclaw-tls` machinery so no openssl is needed.
/// Reused on later runs. Prints the CA path daemons/clients should trust.
fn provision_tls_acceptor(
    tls_dir: Option<&str>,
    extra_sans: &[String],
    client_verifier: Option<Arc<dyn rustls::server::danger::ClientCertVerifier>>,
    dashboard: Option<&DashboardTls>,
) -> Result<TlsAcceptor> {
    let dir = tls_dir.map(PathBuf::from).unwrap_or_else(default_tls_dir);
    let mut sans = vec!["localhost".to_string(), "127.0.0.1".to_string()];
    for s in extra_sans {
        if !s.is_empty() && !sans.contains(s) {
            sans.push(s.clone());
        }
    }
    let mats = zeroclaw_tls::ensure_server_materials(&dir, &sans)
        .with_context(|| format!("self-provisioning relay TLS in {}", dir.display()))?;
    let acceptor = build_tls_acceptor(
        &mats.server_cert_path.to_string_lossy(),
        &mats.server_key_path.to_string_lossy(),
        client_verifier,
        dashboard,
    )?;
    eprintln!("zerorelay: self-provisioned outer TLS in {}", dir.display());
    eprintln!("  SANs: {}", sans.join(", "));
    eprintln!("  Trust this relay on daemons/clients with its CA:");
    eprintln!(
        "    daemon  [relay] relay_ca_path = \"{}\"",
        mats.ca_cert_path.display()
    );
    eprintln!("    zerocode  --relay-ca {}", mats.ca_cert_path.display());
    Ok(acceptor)
}

/// Default location for self-provisioned relay TLS material.
fn default_tls_dir() -> PathBuf {
    std::env::var_os("ZERORELAY_DATA_DIR")
        .map(PathBuf::from)
        .or_else(|| std::env::var_os("HOME").map(|h| PathBuf::from(h).join(".zerorelay")))
        .unwrap_or_else(|| PathBuf::from("./zerorelay"))
        .join("tls")
}

fn load_certs(path: &str) -> Result<Vec<CertificateDer<'static>>> {
    let mut rd = BufReader::new(File::open(path).with_context(|| format!("opening {path}"))?);
    let certs: Vec<_> = rustls_pemfile::certs(&mut rd).collect::<Result<_, _>>()?;
    if certs.is_empty() {
        anyhow::bail!("no certificates found in {path}");
    }
    Ok(certs)
}

fn load_key(path: &str) -> Result<PrivateKeyDer<'static>> {
    let mut rd = BufReader::new(File::open(path).with_context(|| format!("opening {path}"))?);
    rustls_pemfile::private_key(&mut rd)?.with_context(|| format!("no private key in {path}"))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn dashboard_file() -> DashboardFile {
        DashboardFile {
            enabled: Some(true),
            domain: Some("relay.example.com".into()),
            allow: vec!["ab".repeat(32)],
            ..DashboardFile::default()
        }
    }

    #[test]
    fn the_dashboard_is_off_unless_enabled() {
        assert!(
            resolve_dashboard(&DashboardFile::default())
                .unwrap()
                .is_none()
        );
        let file: FileConfig = toml::from_str(
            "[dashboard]\nenabled = false\ndomain = \"relay.example.com\"\n\
             allow = []\nmax_conns_per_node = 8\nmax_conns_per_ip = 4\n",
        )
        .unwrap();
        assert!(resolve_dashboard(&file.dashboard).unwrap().is_none());
        assert!(
            toml::from_str::<FileConfig>("[dashboard]\nhosts = []\n").is_err(),
            "an unknown [dashboard] key is refused"
        );
    }

    #[test]
    fn an_enabled_dashboard_needs_an_allowlist_and_its_own_certificate() {
        // Open admission is the default; without the list any registering
        // daemon would get a host under this relay's domain.
        let mut unlisted = dashboard_file();
        unlisted.allow.clear();
        let err = resolve_dashboard(&unlisted).unwrap_err().to_string();
        assert!(err.contains("allow is empty"), "{err}");

        let err = resolve_dashboard(&dashboard_file())
            .unwrap_err()
            .to_string();
        assert!(err.contains("needs cert and key"), "{err}");

        let mut garbled = dashboard_file();
        garbled.allow = vec!["not-a-fingerprint".into()];
        assert!(resolve_dashboard(&garbled).is_err());

        let mut no_domain = dashboard_file();
        no_domain.domain = None;
        assert!(resolve_dashboard(&no_domain).is_err());
    }

    /// Accept any server certificate: the test asserts WHICH certificate the
    /// relay presents, not the PKI.
    #[derive(Debug)]
    struct AnyServerCert;
    impl rustls::client::danger::ServerCertVerifier for AnyServerCert {
        fn verify_server_cert(
            &self,
            _e: &CertificateDer<'_>,
            _i: &[CertificateDer<'_>],
            _n: &rustls::pki_types::ServerName<'_>,
            _o: &[u8],
            _t: rustls::pki_types::UnixTime,
        ) -> std::result::Result<rustls::client::danger::ServerCertVerified, rustls::Error>
        {
            Ok(rustls::client::danger::ServerCertVerified::assertion())
        }
        fn verify_tls12_signature(
            &self,
            _m: &[u8],
            _c: &CertificateDer<'_>,
            _d: &rustls::DigitallySignedStruct,
        ) -> std::result::Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error>
        {
            Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
        }
        fn verify_tls13_signature(
            &self,
            _m: &[u8],
            _c: &CertificateDer<'_>,
            _d: &rustls::DigitallySignedStruct,
        ) -> std::result::Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error>
        {
            Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
        }
        fn supported_verify_schemes(&self) -> Vec<rustls::SignatureScheme> {
            rustls::crypto::ring::default_provider()
                .signature_verification_algorithms
                .supported_schemes()
        }
    }

    /// Handshake with `server_name`, offering `alpn`: the leaf the relay
    /// presented and the protocol it chose.
    async fn handshake(
        acceptor: TlsAcceptor,
        server_name: &str,
        alpn: &[&[u8]],
    ) -> (Vec<u8>, Option<Vec<u8>>) {
        let (client_io, server_io) = tokio::io::duplex(64 * 1024);
        let server = tokio::spawn(async move { acceptor.accept(server_io).await.map(drop) });
        let mut cfg = rustls::ClientConfig::builder_with_provider(Arc::new(
            rustls::crypto::ring::default_provider(),
        ))
        .with_safe_default_protocol_versions()
        .unwrap()
        .dangerous()
        .with_custom_certificate_verifier(Arc::new(AnyServerCert))
        .with_no_client_auth();
        cfg.alpn_protocols = alpn.iter().map(|p| p.to_vec()).collect();
        let name = rustls::pki_types::ServerName::try_from(server_name.to_string()).unwrap();
        let tls = tokio_rustls::TlsConnector::from(Arc::new(cfg))
            .connect(name, client_io)
            .await
            .expect("the handshake completes");
        let (_, session) = tls.get_ref();
        let leaf = session.peer_certificates().unwrap()[0].as_ref().to_vec();
        let alpn = session.alpn_protocol().map(<[u8]>::to_vec);
        server.await.unwrap().unwrap();
        (leaf, alpn)
    }

    #[tokio::test]
    async fn dashboard_names_get_the_dashboard_certificate_over_http_1_1_only() {
        let relay_dir = tempfile::tempdir().unwrap();
        let relay = zeroclaw_tls::ensure_server_materials(relay_dir.path(), &["relay.test".into()])
            .unwrap();
        let dash_dir = tempfile::tempdir().unwrap();
        let dash = zeroclaw_tls::ensure_server_materials(dash_dir.path(), &["*.relay.test".into()])
            .unwrap();
        let dashboard = DashboardTls {
            domain: "relay.test".into(),
            certs: load_certs(&dash.server_cert_path.to_string_lossy()).unwrap(),
            key: load_key(&dash.server_key_path.to_string_lossy()).unwrap(),
        };
        let relay_leaf = load_certs(&relay.server_cert_path.to_string_lossy()).unwrap()[0]
            .as_ref()
            .to_vec();
        let dash_leaf = dashboard.certs[0].as_ref().to_vec();
        let acceptor = build_tls_acceptor(
            &relay.server_cert_path.to_string_lossy(),
            &relay.server_key_path.to_string_lossy(),
            None,
            Some(&dashboard),
        )
        .unwrap();

        let label = "a".repeat(26);
        let browser: &[&[u8]] = &[b"h2", b"http/1.1"];
        let (leaf, alpn) =
            handshake(acceptor.clone(), &format!("{label}.relay.test"), browser).await;
        assert_eq!(
            leaf, dash_leaf,
            "a dashboard name gets the dashboard certificate"
        );
        assert_eq!(
            alpn.as_deref(),
            Some(&b"http/1.1"[..]),
            "never HTTP/2, which would share a connection across dashboard hosts"
        );
        let (leaf, _) = handshake(acceptor.clone(), "relay.test", browser).await;
        assert_eq!(
            leaf, relay_leaf,
            "the relay's own name keeps its certificate"
        );
        // The relay plane's clients offer no ALPN and are unaffected.
        let (leaf, alpn) = handshake(acceptor, "relay.test", &[]).await;
        assert_eq!(leaf, relay_leaf);
        assert_eq!(alpn, None);
    }

    fn overlay(
        mode: Option<&str>,
        allow: &[&str],
        deny: &[&str],
        token: Option<&str>,
    ) -> AdmissionOverlay {
        AdmissionOverlay {
            mode: mode.map(str::to_string),
            allow: allow.iter().map(|s| s.to_string()).collect(),
            deny: deny.iter().map(|s| s.to_string()).collect(),
            relay_token: token.map(str::to_string),
        }
    }

    fn fingerprint(hex: char) -> String {
        hex.to_string().repeat(64)
    }

    #[test]
    fn shipped_example_config_parses() {
        // The relay.example.toml we ship (and bake into the image) must parse with
        // `deny_unknown_fields` on, so a stale key never silently no-ops.
        let text = include_str!("../relay.example.toml");
        let file: FileConfig = toml::from_str(text).expect("example relay.toml parses");
        assert_eq!(file.bind.as_deref(), Some("0.0.0.0:8443"));
        assert_eq!(file.tls.dir.as_deref(), Some("/data/tls"));
        assert_eq!(file.admission.mode.as_deref(), Some("open"));
        assert_eq!(file.limits.max_conns_per_node, Some(256));
    }

    #[test]
    fn cli_overrides_file_scalars_and_unions_lists() {
        let file = AdmissionFile {
            mode: Some("open".into()),
            allow: vec![fingerprint('a')],
            deny: vec![fingerprint('b')],
            relay_token: Some("file_tok".into()),
            ..Default::default()
        };
        // CLI flips the mode + token and adds an allow entry.
        let cli_allow = fingerprint('c');
        let pol = resolve_admission(
            &file,
            &overlay(Some("allowlist"), &[&cli_allow], &[], Some("cli_tok")),
        )
        .unwrap();
        assert_eq!(pol.registration_mode, Admission::Allowlist); // CLI wins
        assert_eq!(pol.relay_token.as_deref(), Some("cli_tok")); // CLI wins
        assert!(pol.allow.contains(&fingerprint('a')) && pol.allow.contains(&fingerprint('c'))); // union
        assert!(pol.deny.contains(&fingerprint('b')));
    }

    #[test]
    fn file_only_admission_resolves() {
        let file = AdmissionFile {
            mode: Some("allowlist".into()),
            allow: vec![fingerprint('d')],
            ..Default::default()
        };
        let pol = resolve_admission(&file, &overlay(None, &[], &[], None)).unwrap();
        assert_eq!(pol.registration_mode, Admission::Allowlist);
        assert!(pol.allow.contains(&fingerprint('d')));
        assert!(pol.relay_token.is_none());
    }

    #[test]
    fn missing_mode_defaults_to_open_and_bad_mode_errors() {
        let empty = AdmissionFile::default();
        let pol = resolve_admission(&empty, &overlay(None, &[], &[], None)).unwrap();
        assert_eq!(pol.registration_mode, Admission::Open);
        assert!(resolve_admission(&empty, &overlay(Some("nonsense"), &[], &[], None)).is_err());
    }

    #[test]
    fn admission_fingerprints_are_normalized_before_policy_evaluation() {
        let allow = fingerprint('a');
        let deny = fingerprint('b');
        let colon_delimited_upper = |value: &str| {
            value
                .as_bytes()
                .chunks(2)
                .map(|chunk| std::str::from_utf8(chunk).unwrap().to_ascii_uppercase())
                .collect::<Vec<_>>()
                .join(":")
        };
        let file = AdmissionFile {
            mode: Some("allowlist".into()),
            allow: vec![colon_delimited_upper(&allow)],
            deny: vec![colon_delimited_upper(&deny)],
            ..Default::default()
        };

        let policy = resolve_admission(&file, &overlay(None, &[], &[], None)).unwrap();
        assert!(policy.allow.contains(&allow));
        assert!(policy.deny.contains(&deny));
    }

    #[test]
    fn malformed_admission_fingerprint_fails_closed() {
        let file = AdmissionFile {
            deny: vec!["not-a-sha256-fingerprint".into()],
            ..Default::default()
        };

        let err = resolve_admission(&file, &overlay(None, &[], &[], None))
            .expect_err("malformed deny entries must reject the policy");
        assert!(err.to_string().contains("64 hexadecimal"));
    }

    #[test]
    fn unknown_config_key_is_rejected() {
        // deny_unknown_fields: a typo'd key fails loudly instead of silently
        // running stale defaults.
        let bad = "bind = \"0.0.0.0:1\"\n[admission]\nmodee = \"open\"\n";
        assert!(toml::from_str::<FileConfig>(bad).is_err());
    }
}

/// SIGHUP reload plumbing. Startup enforces the fail-closed public-open rule,
/// but the reload path re-reads the file and swaps the policy live: without the
/// bind and the CLI opt-in carried into it, an operator could edit a token-gated
/// or allowlisted config into an open, tokenless one and activate it with a
/// signal - reaching the exact configuration startup refuses. (The rule itself
/// is unit-tested in the library; these cover the wiring.)
#[cfg(all(test, unix))]
mod reload_guard_tests {
    use super::*;

    fn write_config(dir: &tempfile::TempDir, body: &str) -> String {
        let path = dir.path().join("relay.toml");
        std::fs::write(&path, body).expect("write relay.toml");
        path.to_string_lossy().into_owned()
    }

    fn no_overlay() -> AdmissionOverlay {
        AdmissionOverlay {
            mode: None,
            allow: vec![],
            deny: vec![],
            relay_token: None,
        }
    }

    #[test]
    fn reload_refuses_to_open_a_public_relay_without_the_opt_in() {
        let server = RelayServer::new(RelayConfig {
            registration_mode: Admission::Allowlist,
            ..RelayConfig::default()
        });
        let dir = tempfile::tempdir().expect("tempdir");
        // The operator rewrites a guarded config into open + tokenless.
        let path = write_config(&dir, "[admission]\nmode = \"open\"\n");

        let err = reload_admission_once(&server, &path, &no_overlay(), "0.0.0.0:8443", false)
            .expect_err("an unguarded public open policy must not be swapped in");
        let msg = format!("{err:#}");
        assert!(
            msg.contains("refusing to reload admission") && msg.contains("--allow-public-open"),
            "the refusal must name the guard and the way out, got: {msg}"
        );

        // The same edit WITH the explicit opt-in is accepted: the guard gates the
        // deliberateness of the change, it does not forbid open public relays.
        let path = write_config(
            &dir,
            "[admission]\nmode = \"open\"\nallow_public_open = true\n",
        );
        reload_admission_once(&server, &path, &no_overlay(), "0.0.0.0:8443", false)
            .expect("an explicit opt-in must reload");
    }

    #[test]
    fn reload_carries_the_bind_and_cli_opt_in_from_startup() {
        let server = RelayServer::new(RelayConfig::default());
        let dir = tempfile::tempdir().expect("tempdir");
        let path = write_config(&dir, "[admission]\nmode = \"open\"\n");

        // A loopback bind is not a public surface: the same file reloads.
        reload_admission_once(&server, &path, &no_overlay(), "127.0.0.1:8443", false)
            .expect("a loopback relay is unaffected by the guard");
        // A public bind with the startup CLI opt-in still reloads: the flag is
        // carried rather than consumed at startup.
        reload_admission_once(&server, &path, &no_overlay(), "0.0.0.0:8443", true)
            .expect("--allow-public-open from startup must survive into reloads");
        // Same file, same public bind, no opt-in: refused.
        assert!(
            reload_admission_once(&server, &path, &no_overlay(), "0.0.0.0:8443", false).is_err(),
            "a public bind without the opt-in must be refused"
        );
        // A token gates open mode, so this reload is admissible again.
        let path = write_config(
            &dir,
            "[admission]\nmode = \"open\"\nrelay_token = \"a-long-secret\"\n",
        );
        reload_admission_once(&server, &path, &no_overlay(), "0.0.0.0:8443", false)
            .expect("a token-gated open relay is guarded");
    }
}
