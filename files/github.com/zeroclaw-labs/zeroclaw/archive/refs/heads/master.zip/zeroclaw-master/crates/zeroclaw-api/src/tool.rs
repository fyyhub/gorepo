use crate::media::RenderedMarker;
use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use tokio_util::sync::CancellationToken;

tokio::task_local! {
    static TOOL_EXECUTION_CONTEXT: ToolExecutionContext;
}

/// Per-call execution inputs supplied by the turn owner.
///
/// The token is a handle to the owner's cancellation state. Spawned tasks do
/// not inherit the task-local scope; capture the context or a child token
/// before spawning work that should stop with the call.
#[derive(Debug, Clone, Default)]
pub struct ToolExecutionContext {
    cancellation_token: Option<CancellationToken>,
}

/// The execution future was dropped because its owner cancelled the call.
#[derive(Debug, Clone, Copy, thiserror::Error)]
#[error("Tool execution cancelled")]
pub struct ToolExecutionCancelled;

impl ToolExecutionContext {
    pub fn new(cancellation_token: Option<CancellationToken>) -> Self {
        Self { cancellation_token }
    }

    pub fn cancellation_token(&self) -> Option<&CancellationToken> {
        self.cancellation_token.as_ref()
    }

    /// Context for the future currently being polled, if it has a scope.
    pub fn current() -> Option<Self> {
        TOOL_EXECUTION_CONTEXT.try_with(Clone::clone).ok()
    }

    /// Scope the future and drop it when the token is cancelled.
    ///
    /// An empty context masks any outer token. Cancellation wins when both
    /// branches are ready, and a pre-cancelled token never polls the future.
    /// Dropping a future does not undo side effects or await child cleanup.
    pub async fn run<T>(
        &self,
        future: impl std::future::Future<Output = anyhow::Result<T>>,
    ) -> anyhow::Result<T> {
        TOOL_EXECUTION_CONTEXT
            .scope(self.clone(), async {
                match self.cancellation_token() {
                    Some(token) => {
                        tokio::select! {
                            biased;
                            () = token.cancelled() => Err(ToolExecutionCancelled.into()),
                            result = future => result,
                        }
                    }
                    None => future.await,
                }
            })
            .await
    }
}

#[macro_export]
macro_rules! tool_attribution {
    ($ty:ty, $kind:expr) => {
        $crate::tool_attribution!($ty, $kind, $crate::attribution::ToolProvenance::Native);
    };
    ($ty:ty, $kind:expr, $provenance:expr) => {
        impl $crate::attribution::Attributable for $ty {
            fn role(&self) -> $crate::attribution::Role {
                $crate::attribution::Role::Tool($kind)
            }
            fn alias(&self) -> &str {
                <Self as $crate::tool::Tool>::name(self)
            }
            fn tool_provenance(&self) -> $crate::attribution::ToolProvenance {
                $provenance
            }
        }
    };
}

#[macro_export]
macro_rules! mock_tool_attribution {
    ($($ty:ty),+ $(,)?) => {
        $(
            $crate::tool_attribution!($ty, $crate::attribution::ToolKind::Plugin);
        )+
    };
}

/// Typed tool output. The LLM-facing string is derived from the structured
/// value exactly once, at construction, so the two can never drift. `Deref` to
/// `str` keeps every text read site working on the rendered form.
///
/// Wire format: serializes as a bare string when no structured value is
/// attached (byte-identical to the legacy `output: String` field), and as an
/// object with `text`, an optional `data` value, and — only when the tool
/// declared attachments — an `attachments` array. Both shapes deserialize.
///
/// `attachments` is the attachment identity contract: a tool that produced a
/// file the model should see as media records it here, and nothing in `text`
/// is ever scanned for marker syntax to recover that fact. See
/// `tool_carrier` for the carrier grammar this feeds on the history side.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct ToolOutput {
    text: String,
    data: Option<serde_json::Value>,
    attachments: Vec<RenderedMarker>,
}

impl ToolOutput {
    /// Plain text output with no structured value.
    pub fn text(text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            data: None,
            attachments: Vec::new(),
        }
    }

    /// Structured output; the display text is the pretty-printed JSON.
    pub fn json(data: serde_json::Value) -> Self {
        let text = serde_json::to_string_pretty(&data).unwrap_or_else(|_| data.to_string());
        Self {
            text,
            data: Some(data),
            attachments: Vec::new(),
        }
    }

    /// Structured output rendered with custom display text.
    pub fn json_with_text(data: serde_json::Value, text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            data: Some(data),
            attachments: Vec::new(),
        }
    }

    /// Declare one media attachment produced by this tool. The marker's
    /// `target` is the exact path or URI the multimodal loader should resolve;
    /// the attachment rides alongside the text and is never recovered by
    /// scanning it.
    pub fn with_attachment(mut self, marker: RenderedMarker) -> Self {
        self.attachments.push(marker);
        self
    }

    /// The attachments this tool declared, in declaration order.
    pub fn attachments(&self) -> &[RenderedMarker] {
        &self.attachments
    }

    /// Take the declared attachments, leaving the text and structured value.
    pub fn take_attachments(&mut self) -> Vec<RenderedMarker> {
        std::mem::take(&mut self.attachments)
    }

    /// Rewrite the display text in place, keeping the structured value and the
    /// declared attachments. Use this instead of rebuilding the output from a
    /// `String` (`.into()` goes through [`ToolOutput::text`], which drops both).
    pub fn map_text(&mut self, f: impl FnOnce(&str) -> String) {
        self.text = f(&self.text);
    }

    /// The structured value, when the tool declared one.
    pub fn data(&self) -> Option<&serde_json::Value> {
        self.data.as_ref()
    }

    /// Take the structured value, when the tool declared one.
    pub fn into_data(self) -> Option<serde_json::Value> {
        self.data
    }

    pub fn as_str(&self) -> &str {
        &self.text
    }

    pub fn into_string(self) -> String {
        self.text
    }
}

impl std::ops::Deref for ToolOutput {
    type Target = str;
    fn deref(&self) -> &str {
        &self.text
    }
}

impl std::fmt::Display for ToolOutput {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.text)
    }
}

impl From<String> for ToolOutput {
    fn from(text: String) -> Self {
        Self::text(text)
    }
}

impl From<&str> for ToolOutput {
    fn from(text: &str) -> Self {
        Self::text(text)
    }
}

impl From<serde_json::Value> for ToolOutput {
    fn from(data: serde_json::Value) -> Self {
        Self::json(data)
    }
}

impl PartialEq<str> for ToolOutput {
    fn eq(&self, other: &str) -> bool {
        self.text == other
    }
}

impl PartialEq<&str> for ToolOutput {
    fn eq(&self, other: &&str) -> bool {
        self.text == *other
    }
}

impl PartialEq<String> for ToolOutput {
    fn eq(&self, other: &String) -> bool {
        &self.text == other
    }
}

impl Serialize for ToolOutput {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        match (&self.data, self.attachments.is_empty()) {
            (None, true) => serializer.serialize_str(&self.text),
            _ => {
                use serde::ser::SerializeStruct;
                // `data` is an optional field and `attachments` is written
                // only when non-empty, so the object stays as close to the
                // pre-attachment wire shape as the content allows.
                let len = 1
                    + usize::from(self.data.is_some())
                    + usize::from(!self.attachments.is_empty());
                let mut s = serializer.serialize_struct("ToolOutput", len)?;
                s.serialize_field("text", &self.text)?;
                if let Some(data) = &self.data {
                    s.serialize_field("data", data)?;
                }
                if !self.attachments.is_empty() {
                    s.serialize_field("attachments", &self.attachments)?;
                }
                s.end()
            }
        }
    }
}

/// Deserialize a `data` field that is PRESENT: any value, `null` included,
/// maps to `Some`, so an explicit structured null survives the round trip
/// (a field that is absent stays `None` through `#[serde(default)]`).
/// Without this, `Option`'s null-to-`None` rule collapsed
/// `{"text":"x","data":null}` to text-only output, and reserialization
/// changed the wire shape from an object to a bare string.
fn deserialize_present_data<'de, D>(deserializer: D) -> Result<Option<serde_json::Value>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    Ok(Some(serde_json::Value::deserialize(deserializer)?))
}

impl<'de> Deserialize<'de> for ToolOutput {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        #[derive(Deserialize)]
        #[serde(untagged)]
        enum Repr {
            Text(String),
            Structured {
                text: String,
                #[serde(default, deserialize_with = "deserialize_present_data")]
                data: Option<serde_json::Value>,
                #[serde(default)]
                attachments: Option<Vec<RenderedMarker>>,
            },
        }
        Ok(match Repr::deserialize(deserializer)? {
            Repr::Text(text) => Self::text(text),
            Repr::Structured {
                text,
                data,
                attachments,
            } => {
                let mut output = match data {
                    Some(data) => Self::json_with_text(data, text),
                    None => Self::text(text),
                };
                output.attachments = attachments.unwrap_or_default();
                output
            }
        })
    }
}

/// Result of a tool execution
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolResult {
    pub success: bool,
    pub output: ToolOutput,
    pub error: Option<String>,
}

impl ToolResult {
    /// Successful result from any output form (`String`, `&str`, `Value`).
    pub fn ok(output: impl Into<ToolOutput>) -> Self {
        Self {
            success: true,
            output: output.into(),
            error: None,
        }
    }

    /// Attach one media reference to this result, marking it as a deliberate
    /// attachment rather than text the model happens to be able to read.
    pub fn with_attachment(mut self, marker: RenderedMarker) -> Self {
        self.output = self.output.with_attachment(marker);
        self
    }

    /// Failed result with no output.
    pub fn err(error: impl Into<String>) -> Self {
        Self {
            success: false,
            output: ToolOutput::default(),
            error: Some(error.into()),
        }
    }

    /// Failed result that still carries partial output.
    pub fn partial(output: impl Into<ToolOutput>, error: impl Into<String>) -> Self {
        Self {
            success: false,
            output: output.into(),
            error: Some(error.into()),
        }
    }
}

/// Loud, actionable banner that filesystem-touching tools surface when the
/// active runtime uses an **ephemeral workspace** — e.g. a Docker container
/// with no host volume mount, where the workspace is a private tmpfs. In that
/// mode writes succeed *inside the container* but never reach the host and are
/// discarded when the session ends, and reads may return stale or empty data.
/// Surfacing this prevents silent data loss.
///
/// `file_write` refuses outright (it exists only to persist data). The
/// general-purpose `shell`, `file_read`, and `file_edit` tools stay usable but
/// attach this warning so the agent — and through it the user — knows the
/// workspace is ephemeral and how to fix it.
pub const EPHEMERAL_WORKSPACE_WARNING: &str = "\u{26a0}\u{fe0f} EPHEMERAL WORKSPACE: the active runtime uses an ephemeral workspace \
     (tmpfs / no host volume mount). Files written here do NOT persist on the host after this \
     session ends, and reads may return stale or empty data. To make the workspace persistent, \
     set `runtime.docker.mount_workspace = true` in your config and ensure the workspace \
     directory is bind-mounted into the container.";

pub fn with_ephemeral_workspace_warning(text: &str) -> String {
    if text.is_empty() {
        EPHEMERAL_WORKSPACE_WARNING.to_string()
    } else {
        format!("{EPHEMERAL_WORKSPACE_WARNING}\n\n{text}")
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolSpec {
    pub name: String,
    pub description: String,
    pub parameters: std::sync::Arc<serde_json::Value>,
    /// Declared structured-output schema, when the tool has one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub output: Option<serde_json::Value>,
    /// Parameter name → runtime option domain, for params whose value
    /// sets come from live config.
    #[serde(default, skip_serializing_if = "std::collections::BTreeMap::is_empty")]
    pub param_domains: std::collections::BTreeMap<String, OptionDomain>,
}

impl ToolSpec {
    /// Spec with name, description, and parameter schema only; no
    /// structured output declaration and no domain-typed parameters.
    pub fn new(
        name: impl Into<String>,
        description: impl Into<String>,
        parameters: serde_json::Value,
    ) -> Self {
        Self {
            name: name.into(),
            description: description.into(),
            parameters: std::sync::Arc::new(parameters),
            output: None,
            param_domains: std::collections::BTreeMap::new(),
        }
    }
}

/// Closed set of runtime-resolvable option domains a tool parameter can
/// draw its values from. Tools *declare* the domain; resolution happens
/// where live config is visible (the runtime), so surfaces render real
/// selectable choices instead of free-text guessing.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OptionDomain {
    /// Configured channel refs the agent listens on (e.g. `telegram.prod`).
    ChannelRefs,
    /// Peers reachable by this agent: peer agents, external peers, and
    /// peer groups. Cascades on a sibling `channel` argument when present.
    PeerTargets,
    /// Configured peer group names.
    PeerGroups,
    /// Configured agent aliases.
    AgentAliases,
    /// Names of tools registered in the active tool set.
    ToolNames,
    /// Memory categories present in the configured backend.
    MemoryCategories,
}

/// One resolved choice for a domain-typed parameter.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OptionEntry {
    /// The literal value to store in the argument.
    pub value: String,
    /// Human-facing label; falls back to `value` when empty.
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub label: String,
    /// Short qualifier shown next to the label (e.g. `peer agent`,
    /// `group: 3 members`, `disabled`).
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub hint: String,
}

impl OptionEntry {
    pub fn new(value: impl Into<String>) -> Self {
        Self {
            value: value.into(),
            label: String::new(),
            hint: String::new(),
        }
    }

    pub fn with_hint(mut self, hint: impl Into<String>) -> Self {
        self.hint = hint.into();
        self
    }

    pub fn with_label(mut self, label: impl Into<String>) -> Self {
        self.label = label.into();
        self
    }
}

/// Reference implementation of the [`Tool::invocation_triggers`] matching
/// contract: `true` when `trigger` occurs in `haystack` at a word boundary.
/// Both are compared case-insensitively; the caller passes an
/// already-lowercased `haystack` and a lowercased `trigger`. A boundary is
/// the start/end of the string or any non-alphanumeric *character*
/// (Unicode-aware), so a trigger matches only as a whole word or phrase
/// (`dev` misses inside `device`, `send this to` hits inside `please send
/// this to marta`). Boundaries and retry advancement are character-based, so
/// multibyte trigger or haystack text is handled without panics or
/// misclassification. Empty triggers never match.
#[must_use]
pub fn invocation_trigger_matches(haystack_lower: &str, trigger_lower: &str) -> bool {
    if trigger_lower.is_empty() {
        return false;
    }
    // `find` returns a byte offset of a valid substring, so `start` and
    // `start + trigger.len()` are always char boundaries — the surrounding
    // slices below are safe to index.
    let mut search_start = 0;
    while let Some(rel) = haystack_lower[search_start..].find(trigger_lower) {
        let start = search_start + rel;
        let end = start + trigger_lower.len();
        let left_ok = haystack_lower[..start]
            .chars()
            .next_back()
            .is_none_or(|c| !c.is_alphanumeric());
        let right_ok = haystack_lower[end..]
            .chars()
            .next()
            .is_none_or(|c| !c.is_alphanumeric());
        if left_ok && right_ok {
            return true;
        }
        // Advance one whole character past this occurrence's start so the next
        // slice index stays on a boundary (byte + 1 could split a multibyte
        // character and panic).
        match haystack_lower[start..].chars().next() {
            Some(c) => search_start = start + c.len_utf8(),
            None => break,
        }
    }
    false
}

/// Whether `tool_name` takes an `approved` argument that only the runtime
/// may set, from the operator's approval decision for that call. A value the
/// model supplies is never an approval.
pub fn takes_runtime_approval(tool_name: &str) -> bool {
    matches!(
        tool_name,
        "shell" | "schedule" | "cron_add" | "cron_update" | "cron_run"
    )
}

/// Clear the approval on a call a wrapper makes to `tool_name` directly.
///
/// The runtime writes `approved` only on the call it dispatched, under the
/// outer tool's name. A wrapper that invokes a child tool itself, such as a
/// pipeline step or a skill alias, has no approval decision for the child,
/// so the child runs unapproved whatever its arguments say.
pub fn clear_runtime_approval(tool_name: &str, args: &mut serde_json::Value) {
    if takes_runtime_approval(tool_name)
        && let Some(args) = args.as_object_mut()
    {
        args.insert("approved".to_string(), serde_json::Value::Bool(false));
    }
}

#[async_trait]
pub trait Tool: Send + Sync + crate::attribution::Attributable {
    /// True when this tool does work that does not carry the RPC principal's
    /// current authority: nested, scheduled or headless runs, turns on another
    /// agent, shared procedures, or other principals' sessions. Non-admin RPC
    /// sessions omit it whatever their selectors admit. Wrappers forward the
    /// target's value so a renamed skill cannot bypass that restriction. This
    /// describes implementation support, not a stored authorization decision.
    fn requires_unrestricted_principal(&self) -> bool {
        false
    }

    /// Tool name (used in LLM function calling)
    fn name(&self) -> &str;

    /// Human-readable description
    fn description(&self) -> &str;

    /// JSON schema for parameters
    fn parameters_schema(&self) -> serde_json::Value;

    /// JSON schema describing the structured output this tool attaches to
    /// `ToolOutput::data`, when it declares one. `None` means the tool
    /// emits display text only; authoring surfaces fall back to
    /// sample-derived shapes from captured runs.
    fn output_schema(&self) -> Option<serde_json::Value> {
        None
    }

    /// Option domains for parameters whose value sets live in runtime
    /// config rather than the static schema (channel refs, peer targets,
    /// ...). Surfaces resolve these through the runtime to render real
    /// selectable choices. Default: no domain-typed parameters.
    fn param_domains(&self) -> Vec<(&'static str, OptionDomain)> {
        Vec::new()
    }

    /// Lowercase phrases that suggest an inbound message wants this tool —
    /// e.g. routing wording or configured destination names for a delivery
    /// tool. A pre-turn prefilter may scan the message against these and
    /// nudge the model to consider the tool; the tool itself is never called
    /// by the prefilter.
    ///
    /// **Matching contract:** case-insensitive, **word-boundary** — a trigger
    /// matches only where it is bounded by non-alphanumeric characters or the
    /// message ends (see [`invocation_trigger_matches`]). So `dev` does not
    /// fire inside `device` and `ops` does not fire inside `stops`; a trigger
    /// only hits as a whole word or phrase. Entries should still be wording
    /// that, taken whole, indicates this tool — avoid single common words.
    /// A config-derived name that happens to equal a common word can still
    /// over-fire; the hint is advisory (the model, not the prefilter, decides
    /// to call), so the cost of a false positive is a wasted nudge, never an
    /// action. Entries derived from runtime config (aliases, group names)
    /// must be computed live per call, never cached across reloads. Default:
    /// no triggers; the tool does not participate in prefilter hints.
    fn invocation_triggers(&self) -> Vec<String> {
        Vec::new()
    }

    /// Execute the tool with given arguments
    async fn execute(&self, args: serde_json::Value) -> anyhow::Result<ToolResult>;

    /// Execute with turn-scoped cancellation while preserving legacy tools.
    /// Tools that start child work can override this method to pass the
    /// context or a child token explicitly, and use [`ToolExecutionContext::run`]
    /// to scope and cancel their execution future.
    async fn execute_with_context(
        &self,
        args: serde_json::Value,
        context: &ToolExecutionContext,
    ) -> anyhow::Result<ToolResult> {
        context.run(self.execute(args)).await
    }

    /// Assemble this tool's spec. The default recomposes it from
    /// `parameters_schema()` and allocates a fresh `Arc` per call, so tools
    /// with large stored schemas override it to hand out `Arc::clone`
    /// instead (see `McpToolWrapper`). Delegating wrappers around a
    /// `dyn Tool` MUST forward `spec()` to the inner tool — relying on this
    /// default silently reintroduces a per-iteration deep clone of the
    /// inner schema and breaks `Arc` identity for downstream sharing.
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            name: self.name().to_string(),
            description: self.description().to_string(),
            parameters: std::sync::Arc::new(self.parameters_schema()),
            output: self.output_schema(),
            param_domains: self
                .param_domains()
                .into_iter()
                .map(|(name, domain)| (name.to_string(), domain))
                .collect(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn tool_context_masks_and_restores_nested_scopes() {
        assert!(ToolExecutionContext::current().is_none());
        let token = CancellationToken::new();
        let context = ToolExecutionContext::new(Some(token.clone()));
        let observed = context
            .run(async {
                assert!(
                    ToolExecutionContext::current()
                        .unwrap()
                        .cancellation_token()
                        .is_some()
                );
                let error = ToolExecutionContext::default()
                    .run::<()>(async {
                        assert!(
                            ToolExecutionContext::current()
                                .unwrap()
                                .cancellation_token()
                                .is_none()
                        );
                        let mut children = tokio::task::JoinSet::new();
                        children.spawn(async { ToolExecutionContext::current() });
                        assert!(children.join_next().await.unwrap().unwrap().is_none());
                        anyhow::bail!("inner failure")
                    })
                    .await
                    .unwrap_err();
                assert_eq!(error.to_string(), "inner failure");
                Ok(ToolExecutionContext::current()
                    .unwrap()
                    .cancellation_token()
                    .unwrap()
                    .clone())
            })
            .await
            .unwrap();
        assert!(ToolExecutionContext::current().is_none());
        token.cancel();
        assert!(observed.is_cancelled());
    }

    #[tokio::test]
    async fn tool_context_scope_is_restored_when_future_is_dropped() {
        let context = ToolExecutionContext::new(Some(CancellationToken::new()));
        let mut call = Box::pin(context.run(async {
            assert!(ToolExecutionContext::current().is_some());
            std::future::pending::<anyhow::Result<()>>().await
        }));
        std::future::poll_fn(|cx| {
            assert!(std::future::Future::poll(call.as_mut(), cx).is_pending());
            std::task::Poll::Ready(())
        })
        .await;
        assert!(ToolExecutionContext::current().is_none());
        drop(call);
        assert!(ToolExecutionContext::current().is_none());
    }

    #[tokio::test]
    async fn tool_context_pre_cancelled_does_not_poll_ready_future() {
        let token = CancellationToken::new();
        token.cancel();
        let context = ToolExecutionContext::new(Some(token));
        let polls = std::sync::atomic::AtomicUsize::new(0);
        let result = context
            .run(std::future::poll_fn(|_| {
                polls.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                std::task::Poll::Ready(Ok(()))
            }))
            .await;
        assert!(result.unwrap_err().is::<ToolExecutionCancelled>());
        assert_eq!(polls.load(std::sync::atomic::Ordering::SeqCst), 0);
        assert!(ToolExecutionContext::current().is_none());
    }

    #[tokio::test]
    async fn tool_context_cancellation_drops_a_polled_future() {
        struct DropProbe(std::sync::Arc<std::sync::atomic::AtomicBool>);
        impl Drop for DropProbe {
            fn drop(&mut self) {
                self.0.store(true, std::sync::atomic::Ordering::SeqCst);
            }
        }

        let token = CancellationToken::new();
        let context = ToolExecutionContext::new(Some(token.clone()));
        let dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let mut call = Box::pin(context.run(async {
            let _guard = DropProbe(dropped.clone());
            std::future::pending::<anyhow::Result<()>>().await
        }));
        std::future::poll_fn(|cx| {
            assert!(std::future::Future::poll(call.as_mut(), cx).is_pending());
            std::task::Poll::Ready(())
        })
        .await;
        assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
        token.cancel();
        assert!(call.await.unwrap_err().is::<ToolExecutionCancelled>());
        assert!(dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert!(ToolExecutionContext::current().is_none());
    }

    #[tokio::test]
    async fn tool_context_concurrent_futures_keep_independent_tokens() {
        let first_token = CancellationToken::new();
        let second_token = CancellationToken::new();
        let first = ToolExecutionContext::new(Some(first_token.clone()));
        let second = ToolExecutionContext::new(Some(second_token.clone()));
        let barrier = tokio::sync::Barrier::new(2);
        let capture = || async {
            barrier.wait().await;
            tokio::task::yield_now().await;
            Ok(ToolExecutionContext::current()
                .unwrap()
                .cancellation_token()
                .unwrap()
                .clone())
        };
        let (first_seen, second_seen) = tokio::join!(first.run(capture()), second.run(capture()));
        let first_seen = first_seen.unwrap();
        let second_seen = second_seen.unwrap();
        first_token.cancel();
        assert!(first_seen.is_cancelled());
        assert!(!second_seen.is_cancelled());
        second_token.cancel();
        assert!(second_seen.is_cancelled());
        assert!(ToolExecutionContext::current().is_none());
    }

    struct LegacyContextProbe;
    crate::mock_tool_attribution!(LegacyContextProbe);

    #[async_trait]
    impl Tool for LegacyContextProbe {
        fn name(&self) -> &str {
            "legacy_context_probe"
        }
        fn description(&self) -> &str {
            "Reads the scoped context through the legacy method"
        }
        fn parameters_schema(&self) -> serde_json::Value {
            serde_json::json!({})
        }
        async fn execute(&self, _args: serde_json::Value) -> anyhow::Result<ToolResult> {
            assert!(
                ToolExecutionContext::current()
                    .unwrap()
                    .cancellation_token()
                    .is_some()
            );
            Ok(ToolResult::ok("legacy completed"))
        }
    }

    #[tokio::test]
    async fn tool_context_default_bridge_scopes_legacy_execute() {
        let context = ToolExecutionContext::new(Some(CancellationToken::new()));
        let result = LegacyContextProbe
            .execute_with_context(serde_json::json!({}), &context)
            .await
            .unwrap();
        assert!(result.success);
        assert!(ToolExecutionContext::current().is_none());
    }

    #[test]
    fn tool_spec_arc_parameters_serialize_transparently() {
        let schema = serde_json::json!({
            "type": "object",
            "properties": { "command": { "type": "string" } },
            "required": ["command"]
        });
        let spec = ToolSpec {
            name: "shell".to_string(),
            description: "Run commands".to_string(),
            parameters: std::sync::Arc::new(schema.clone()),
            output: None,
            param_domains: std::collections::BTreeMap::new(),
        };
        let arc_params = serde_json::to_string(&spec.parameters).expect("arc serializes");
        let plain_params = serde_json::to_string(&schema).expect("plain value serializes");
        assert_eq!(arc_params, plain_params);

        let arc_json = serde_json::to_string(&spec).expect("spec serializes");
        let back: ToolSpec = serde_json::from_str(&arc_json).expect("spec deserializes");
        assert_eq!(back.name, spec.name);
        assert_eq!(*back.parameters, *spec.parameters);
    }

    #[test]
    fn trigger_matches_are_word_bounded() {
        // Whole-word / phrase hits.
        assert!(invocation_trigger_matches(
            "please send this to marta",
            "send this to"
        ));
        assert!(invocation_trigger_matches(
            "reply by voice please",
            "by voice"
        ));
        assert!(invocation_trigger_matches("route to dev", "dev"));
        assert!(invocation_trigger_matches("dev", "dev"));
        // Substring-inside-word must NOT hit.
        assert!(!invocation_trigger_matches(
            "check the device status",
            "dev"
        ));
        assert!(!invocation_trigger_matches("the bus stops here", "ops"));
        assert!(!invocation_trigger_matches("recall everything", "all"));
        // Bounded by punctuation counts as a word boundary.
        assert!(invocation_trigger_matches("send to: dev.", "dev"));
        // Empty trigger never matches.
        assert!(!invocation_trigger_matches("anything", ""));
    }

    #[test]
    fn trigger_matches_are_utf8_safe() {
        // A multibyte trigger whose first occurrence is glued to another
        // ideograph (rejected) and whose second occurrence is space-bounded
        // (accepted). The byte-offset retry `start + 1` would land inside the
        // leading multibyte character and panic; the char-based advance must
        // reject the first, survive, and accept the second.
        assert!(invocation_trigger_matches("料理番 送信 する", "送信"));
        // Same trigger with only the glued occurrence must NOT match, and must
        // not panic while scanning past it.
        assert!(!invocation_trigger_matches("料理送信番", "送信"));
        // A single ideograph is alphanumeric under Unicode, so an adjacent
        // ideograph is not a boundary — no false positive inside CJK text.
        assert!(!invocation_trigger_matches("東京都", "京"));
        // But the same single-character trigger is bounded by ASCII spaces.
        assert!(invocation_trigger_matches("go to 京 now", "京"));
    }

    #[test]
    fn invocation_triggers_default_to_empty() {
        struct Plain;
        impl crate::attribution::Attributable for Plain {
            fn role(&self) -> crate::attribution::Role {
                crate::attribution::Role::Tool(crate::attribution::ToolKind::Plugin)
            }
            fn alias(&self) -> &str {
                "plain"
            }
        }
        #[async_trait]
        impl Tool for Plain {
            fn name(&self) -> &str {
                "plain"
            }
            fn description(&self) -> &str {
                "no triggers"
            }
            fn parameters_schema(&self) -> serde_json::Value {
                serde_json::json!({"type": "object"})
            }
            async fn execute(&self, _args: serde_json::Value) -> anyhow::Result<ToolResult> {
                Ok(ToolResult::ok("ok"))
            }
        }
        assert!(Plain.invocation_triggers().is_empty());
    }

    #[test]
    fn text_output_serializes_as_bare_string() {
        let r = ToolResult::ok("hello");
        let json = serde_json::to_value(&r).unwrap();
        assert_eq!(json["output"], serde_json::json!("hello"));
    }

    #[test]
    fn legacy_string_output_deserializes() {
        let r: ToolResult =
            serde_json::from_str(r#"{"success":true,"output":"plain","error":null}"#).unwrap();
        assert_eq!(r.output, "plain");
        assert!(r.output.data().is_none());
    }

    #[test]
    fn json_output_roundtrips_with_data() {
        let data = serde_json::json!({"status": 200, "body": {"ok": true}});
        let r = ToolResult::ok(data.clone());
        let wire = serde_json::to_string(&r).unwrap();
        let back: ToolResult = serde_json::from_str(&wire).unwrap();
        assert_eq!(back.output.data(), Some(&data));
        assert_eq!(back.output.as_str(), r.output.as_str());
    }

    #[test]
    fn json_string_value_keeps_structured_form() {
        // A JSON string *value* must stay data-carrying, not collapse to Text.
        let r = ToolResult::ok(serde_json::json!("quoted"));
        let wire = serde_json::to_string(&r).unwrap();
        let back: ToolResult = serde_json::from_str(&wire).unwrap();
        assert_eq!(back.output.data(), Some(&serde_json::json!("quoted")));
    }

    #[test]
    fn explicit_null_data_round_trips_as_structured_null() {
        // `data: null` is presence, not absence: the round trip must keep
        // the object shape instead of collapsing to text-only and then to a
        // bare string on reserialization.
        let output = ToolOutput::json_with_text(serde_json::Value::Null, "x");
        assert_eq!(output.data(), Some(&serde_json::Value::Null));
        let wire = serde_json::to_string(&output).expect("serializes");
        assert_eq!(wire, "{\"text\":\"x\",\"data\":null}");
        let back: ToolOutput = serde_json::from_str(&wire).expect("object deserializes");
        assert_eq!(back, output);
        assert_eq!(back.data(), Some(&serde_json::Value::Null));
        assert_eq!(
            serde_json::to_string(&back).expect("reserializes"),
            wire,
            "reserialization must be stable, not a bare string"
        );
    }

    #[test]
    fn text_only_object_canonicalizes_to_bare_string() {
        // An object with `text` and neither `data` nor `attachments` reads as
        // text-only output and serializes back as the legacy bare string.
        let back: ToolOutput =
            serde_json::from_str("{\"text\":\"read\"}").expect("text-only object deserializes");
        assert_eq!(back.as_str(), "read");
        assert!(back.data().is_none());
        assert!(back.attachments().is_empty());
        assert_eq!(
            serde_json::to_string(&back).expect("reserializes"),
            "\"read\"",
            "text-only canonicalizes to the legacy wire shape"
        );
    }

    #[test]
    fn deref_and_display_expose_rendered_text() {
        let out = ToolOutput::json(serde_json::json!({"a": 1}));
        assert!(out.contains("\"a\": 1"));
        assert_eq!(out.to_string(), out.as_str());
    }

    #[test]
    fn plain_text_output_still_serializes_as_a_bare_string() {
        let output = ToolOutput::text("plain result");
        assert_eq!(
            serde_json::to_string(&output).expect("serializes"),
            "\"plain result\"",
            "no data and no attachments must keep the legacy wire shape"
        );
        let back: ToolOutput =
            serde_json::from_str("\"plain result\"").expect("bare string deserializes");
        assert_eq!(back, output);
        assert!(back.attachments().is_empty());
    }

    #[test]
    fn structured_output_serializes_with_text_and_data_as_before() {
        let output = ToolOutput::json(serde_json::json!({"a": 1}));
        let wire = serde_json::to_string(&output).expect("serializes");
        assert_eq!(
            wire, "{\"text\":\"{\\n  \\\"a\\\": 1\\n}\",\"data\":{\"a\":1}}",
            "structured output without attachments keeps the legacy object shape"
        );
        let back: ToolOutput = serde_json::from_str(&wire).expect("object deserializes");
        assert_eq!(back, output);
        assert!(back.attachments().is_empty());
    }

    #[test]
    fn attachments_ride_the_object_only_when_present() {
        let output = ToolOutput::text("image read").with_attachment(crate::media::RenderedMarker {
            target: "/tmp/shot.png".to_string(),
            kind: crate::media::MarkerKind::Image,
        });
        let wire = serde_json::to_string(&output).expect("serializes");
        assert_eq!(
            wire,
            "{\"text\":\"image read\",\"attachments\":[{\"target\":\"/tmp/shot.png\",\"kind\":\"image\"}]}"
        );
        let back: ToolOutput = serde_json::from_str(&wire).expect("object deserializes");
        assert_eq!(back, output);
        assert_eq!(back.attachments().len(), 1);
    }

    #[test]
    fn legacy_object_without_attachments_deserializes_to_none() {
        let back: ToolOutput = serde_json::from_str("{\"text\":\"read\",\"data\":{\"a\":1}}")
            .expect("legacy object deserializes");
        assert_eq!(back.as_str(), "read");
        assert_eq!(back.data(), Some(&serde_json::json!({"a": 1})));
        assert!(back.attachments().is_empty());
    }

    #[test]
    fn with_attachment_declares_without_touching_text() {
        let result =
            ToolResult::ok("File: /tmp/shot.png").with_attachment(crate::media::RenderedMarker {
                target: "/tmp/shot.png".to_string(),
                kind: crate::media::MarkerKind::Image,
            });
        assert_eq!(result.output.as_str(), "File: /tmp/shot.png");
        assert_eq!(result.output.attachments().len(), 1);
        let mut output = result.output;
        let taken = output.take_attachments();
        assert_eq!(taken.len(), 1);
        assert!(output.attachments().is_empty());
        assert_eq!(output.as_str(), "File: /tmp/shot.png");
    }

    #[test]
    fn ephemeral_warning_names_cause_and_fix() {
        assert!(EPHEMERAL_WORKSPACE_WARNING.contains("EPHEMERAL WORKSPACE"));
        assert!(EPHEMERAL_WORKSPACE_WARNING.contains("tmpfs"));
        assert!(EPHEMERAL_WORKSPACE_WARNING.contains("mount_workspace"));
        // Line continuations must not leave doubled spaces.
        assert!(!EPHEMERAL_WORKSPACE_WARNING.contains("  "));
    }

    #[test]
    fn empty_text_returns_banner_alone() {
        assert_eq!(
            with_ephemeral_workspace_warning(""),
            EPHEMERAL_WORKSPACE_WARNING
        );
    }

    #[test]
    fn map_text_keeps_data_and_attachments() {
        let marker = crate::media::RenderedMarker {
            target: "/ws/images/out.png".into(),
            kind: crate::media::MarkerKind::Image,
        };
        let mut output = ToolOutput::json_with_text(serde_json::json!({"k": 1}), "body")
            .with_attachment(marker.clone());
        output.map_text(with_ephemeral_workspace_warning);
        assert!(output.as_str().starts_with(EPHEMERAL_WORKSPACE_WARNING));
        assert!(output.as_str().ends_with("\n\nbody"));
        assert_eq!(output.data(), Some(&serde_json::json!({"k": 1})));
        assert_eq!(output.attachments(), std::slice::from_ref(&marker));
    }

    #[test]
    fn nonempty_text_keeps_body_below_banner() {
        let out = with_ephemeral_workspace_warning("body");
        assert!(out.starts_with(EPHEMERAL_WORKSPACE_WARNING));
        assert!(out.ends_with("\n\nbody"));
    }
}
