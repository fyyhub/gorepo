# Workflow Directory Layout

GitHub Actions only loads workflow entry files from:

- `.github/workflows/*.yml`
- `.github/workflows/*.yaml`

Subdirectories are not valid locations for workflow entry files.

Repository convention:

1. Keep runnable workflow entry files at `.github/workflows/` root.
2. Keep cross-tooling/local CI scripts under `dev/` or `scripts/ci/` when used outside Actions.

Workflow behavior documentation in this directory:

- `.github/workflows/master-branch-flow.md`

## Bespoke CI gate provenance

Every repository-specific CI gate must record the invariant it protects, the
issue, pull request, or incident that motivated it, and the condition under
which it can be retired. Keep a short breadcrumb beside the job or the step in the
workflow YAML.

For script-backed gates, keep the durable explanation in this
registry rather than in source comments covered by the comment-hygiene gate.

| Gate | Protected invariant | Origin | Retirement condition |
|---|---|---|---|
| Repository Structure | Index gitlinks match `.gitmodules`, and only the approved translation submodule is present. | [PR #8516](https://github.com/zeroclaw-labs/zeroclaw/pull/8516) | Retire only when submodules are removed or an equivalent repository-policy check enforces the same restriction. |
| Zerocode RPC Boundary | Zerocode depends only on shared `zeroclaw-api` contracts; runtime and other implementation behavior remains behind RPC. | [PR #7850](https://github.com/zeroclaw-labs/zeroclaw/pull/7850) | Retire only if the architecture intentionally permits implementation dependencies or an equivalent dependency-boundary check replaces it. |
| Nix Hash Drift | `nix/hashes.json` contains exactly the fixed-output hash keys required by Git dependencies in `Cargo.lock`. | [PR #8336](https://github.com/zeroclaw-labs/zeroclaw/pull/8336) | Retire only when Nix no longer uses the tracked hash registry or another mechanism enforces the same synchronization. |
| Installer Drift | Tracked installer, packaging, container, Nix, and installation-documentation surfaces match the canonical generator specification, and the tracked OpenRPC contract document matches `zeroclaw-rpc-proto`. | [PR #7558](https://github.com/zeroclaw-labs/zeroclaw/pull/7558) | Retire only when those surfaces are no longer generated and tracked, or an equivalent consistency check replaces this gate. |
| Plugin gateway ingress | The `plugins gateway ingress` leg of `check-plugin-backends` runs the gateway's plugin webhook HTTP handler tests (`--lib plugin_webhook`) and the plugin webhook golden frames (`--test golden_frames plugin_webhook`) in required CI, and `scripts/ci/plugin_backend_change_filter.sh` selects the job for the gateway's plugin webhook handler and tests, its router and manifest, the golden harness and fixtures, the shared webhook types in `zeroclaw-api`, and the plugin webhook ingress in `zeroclaw-infra`. | [Issue #11003](https://github.com/zeroclaw-labs/zeroclaw/issues/11003) | Retire only when a default-feature required job compiles and tests the gateway's `plugins-wasm` code, or plugin webhook ingress leaves the gateway. |
| Required Windows Job Selection | `scripts/ci/windows_test_scope.py --required-jobs` selects compilation, voice-wake, service smoke and task-owner recovery from package ownership and relevant source controls. The required gate checks selected execution against job results. Missing or ambiguous evidence selects all jobs; master pushes and merge-queue runs always execute them. `windows_recovery_change_filter.sh` remains a compatibility entrypoint to the same selector. | [PR #10867](https://github.com/zeroclaw-labs/zeroclaw/pull/10867), [PR #11498](https://github.com/zeroclaw-labs/zeroclaw/pull/11498) | Retire only when these checks run unconditionally at acceptable cost or equivalent required Windows coverage replaces the jobs and their selection contract. |
| Plugin Artifact Smoke | `scripts/ci/plugin_artifact_smoke.sh` takes one `zeroclaw` binary and proves it installs and executes a real tool component through the operator's commands and an agent turn. The plugin stays unused until the operator enables the plugin system, turns discovery on, and approves the tool. Values configured for a package that does not request them are not delivered. Payload digests and the host's WIT world are enforced at install, strict signature mode refuses unsigned, untrusted, and edited packages, and a plugin that does not load is skipped instead of stopping the agent. With the opposite expectation the same script requires that the binary has no `plugin` command. The stable release runs it against every 64-bit archive except the experimental Android one, on a runner of that archive's platform (`plugin-smoke`, gating `publish` and `docker`), the manual Cross-Platform Build workflow rehearses the same legs, and an xtask test keeps the leg list equal to the registry's per-target plugin policy. | [Issue #10994](https://github.com/zeroclaw-labs/zeroclaw/issues/10994) | Retire only when no build or artifact carries the plugin host, or an equivalent check executes a plugin from every artifact that claims plugin support. |
| Desktop Dashboard Smoke | A staged desktop kernel sidecar serves the embedded web dashboard at the gateway root when launched from an empty working directory with an isolated config directory (`scripts/desktop/smoke-dashboard.sh`, run before `cargo tauri build` by the Linux and Windows desktop jobs in `release-stable-manual.yml`; the macOS job runs an equivalent inline step). A kernel built without `embedded-web` fails it. | [PR #9032](https://github.com/zeroclaw-labs/zeroclaw/pull/9032) added the macOS release check; [issue #11004](https://github.com/zeroclaw-labs/zeroclaw/issues/11004) covers the desktop packages on every platform. | Retire only when the desktop kernel no longer carries dashboard assets (the separate gateway process serves them) and an equivalent gateway-process smoke replaces it. |
