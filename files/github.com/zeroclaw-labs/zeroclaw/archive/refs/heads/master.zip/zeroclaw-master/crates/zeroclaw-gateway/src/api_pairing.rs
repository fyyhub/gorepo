//! Device management and pairing API handlers.

use super::{AppState, ConfigWriteGuard};
use crate::dashboard_session::{DashboardAuth, DashboardCaller, SessionAuth, SessionRejection};
use axum::Extension;
use axum::{
    extract::{ConnectInfo, State},
    http::{HeaderMap, StatusCode},
    response::{IntoResponse, Json},
};
use chrono::{DateTime, Utc};
use parking_lot::Mutex;
use rusqlite::Connection;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::net::SocketAddr;
use std::path::{Path, PathBuf};
use std::sync::Arc;

/// Metadata about a paired device.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeviceInfo {
    pub id: String,
    pub name: Option<String>,
    pub device_type: Option<String>,
    pub paired_at: DateTime<Utc>,
    pub last_seen: DateTime<Utc>,
    pub ip_address: Option<String>,
    /// macOS TCC permissions (and equivalent on other OSes) the device reports as granted.
    /// Pushed by the desktop app via POST /api/devices/me/capabilities.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub capabilities: Option<Vec<String>>,
}

#[derive(Clone, Copy)]
enum VoiceDeviceKey<'a> {
    TokenHash(&'a str),
    DeviceId(&'a str),
}

impl<'a> VoiceDeviceKey<'a> {
    fn column_and_value(self) -> (&'static str, &'a str) {
        match self {
            Self::TokenHash(value) => ("token_hash", value),
            Self::DeviceId(value) => ("id", value),
        }
    }
}

/// Registry of paired devices backed by SQLite.
#[derive(Debug)]
pub struct DeviceRegistry {
    cache: Mutex<HashMap<String, DeviceInfo>>,
    db_path: PathBuf,
}

impl DeviceRegistry {
    pub fn new(workspace_dir: &Path) -> Result<Self, rusqlite::Error> {
        let db_path = workspace_dir.join("devices.db");
        let conn = Connection::open(&db_path)?;
        conn.execute_batch(
            "PRAGMA journal_mode = WAL;
             PRAGMA synchronous = NORMAL;
             PRAGMA temp_store = MEMORY;
             CREATE TABLE IF NOT EXISTS devices (
                token_hash TEXT PRIMARY KEY,
                id TEXT NOT NULL,
                name TEXT,
                device_type TEXT,
                paired_at TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                ip_address TEXT,
                capabilities TEXT
            )",
        )?;

        // Additive migrations are checked explicitly; I/O/schema failures return
        // to gateway startup rather than panicking or being treated as duplicates.
        let columns = conn
            .prepare("PRAGMA table_info(devices)")?
            .query_map([], |row| row.get::<_, String>(1))?
            .collect::<Result<Vec<_>, _>>()?;
        for column in ["capabilities", "voice_preferences"] {
            if !columns.iter().any(|name| name == column) {
                conn.execute(&format!("ALTER TABLE devices ADD COLUMN {column} TEXT"), [])?;
            }
        }

        // Warm the in-memory cache from DB
        let mut cache = HashMap::new();
        let mut stmt = conn
            .prepare("SELECT token_hash, id, name, device_type, paired_at, last_seen, ip_address, capabilities FROM devices")
            ?;
        let rows = stmt.query_map([], |row| {
            let token_hash: String = row.get(0)?;
            let id: String = row.get(1)?;
            let name: Option<String> = row.get(2)?;
            let device_type: Option<String> = row.get(3)?;
            let paired_at_str: String = row.get(4)?;
            let last_seen_str: String = row.get(5)?;
            let ip_address: Option<String> = row.get(6)?;
            let capabilities_json: Option<String> = row.get(7)?;
            let paired_at = DateTime::parse_from_rfc3339(&paired_at_str)
                .map(|dt| dt.with_timezone(&Utc))
                .unwrap_or_else(|_| Utc::now());
            let last_seen = DateTime::parse_from_rfc3339(&last_seen_str)
                .map(|dt| dt.with_timezone(&Utc))
                .unwrap_or_else(|_| Utc::now());
            let capabilities = capabilities_json
                .as_deref()
                .and_then(|s| serde_json::from_str::<Vec<String>>(s).ok());
            Ok((
                token_hash,
                DeviceInfo {
                    id,
                    name,
                    device_type,
                    paired_at,
                    last_seen,
                    ip_address,
                    capabilities,
                },
            ))
        })?;
        for row in rows {
            let (hash, info) = row?;
            cache.insert(hash, info);
        }

        Ok(Self {
            cache: Mutex::new(cache),
            db_path,
        })
    }

    #[cfg(test)]
    pub(crate) fn with_db_path(db_path: PathBuf) -> Self {
        Self {
            cache: Mutex::new(HashMap::new()),
            db_path,
        }
    }

    fn open_db(&self) -> Result<Connection, rusqlite::Error> {
        let conn = Connection::open(&self.db_path)?;
        conn.execute_batch(
            "PRAGMA journal_mode = WAL;
             PRAGMA synchronous = NORMAL;
             PRAGMA temp_store = MEMORY;",
        )?;
        Ok(conn)
    }

    fn voice_preferences(
        &self,
        key: VoiceDeviceKey<'_>,
    ) -> anyhow::Result<Option<DeviceVoicePreferences>> {
        use rusqlite::OptionalExtension;
        let (column, value) = key.column_and_value();
        let conn = self.open_db()?;
        let row: Option<(String, Option<String>)> = conn
            .query_row(
                &format!("SELECT id, voice_preferences FROM devices WHERE {column} = ?1"),
                [value],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .optional()?;
        row.map(|(device_id, json)| {
            Ok(DeviceVoicePreferences {
                device_id,
                preferences: match json {
                    Some(json) => serde_json::from_str(&json)?,
                    None => VoicePreferences::default(),
                },
            })
        })
        .transpose()
    }

    fn save_voice_preferences_authorized<G, R>(
        &self,
        key: VoiceDeviceKey<'_>,
        update: VoicePreferencesUpdate,
        authorize: impl FnOnce() -> Result<G, R>,
    ) -> anyhow::Result<Result<bool, R>> {
        use rusqlite::OptionalExtension;
        let (column, value) = key.column_and_value();
        let mut conn = self.open_db()?;
        let tx = conn.transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)?;
        let _authorization = match authorize() {
            Ok(authorization) => authorization,
            Err(refusal) => return Ok(Err(refusal)),
        };
        // Read and merge under the writer lock, so a field another screen saved
        // in the meantime is kept rather than replaced by this caller's copy.
        let stored: Option<Option<String>> = tx
            .query_row(
                &format!("SELECT voice_preferences FROM devices WHERE {column} = ?1"),
                [value],
                |row| row.get(0),
            )
            .optional()?;
        let Some(stored) = stored else {
            return Ok(Ok(false));
        };
        let stored = match stored {
            Some(json) => serde_json::from_str(&json)?,
            None => VoicePreferences::default(),
        };
        let updated = tx.execute(
            &format!("UPDATE devices SET voice_preferences = ?1 WHERE {column} = ?2"),
            rusqlite::params![serde_json::to_string(&update.apply_to(stored))?, value],
        )? == 1;
        tx.commit()?;
        Ok(Ok(updated))
    }

    pub fn register(&self, token_hash: String, info: DeviceInfo) -> Result<(), rusqlite::Error> {
        let capabilities_json = info
            .capabilities
            .as_ref()
            .and_then(|c| serde_json::to_string(c).ok());
        let conn = self.open_db()?;
        conn.execute(
            "INSERT OR REPLACE INTO devices (token_hash, id, name, device_type, paired_at, last_seen, ip_address, capabilities) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
            rusqlite::params![
                token_hash,
                info.id,
                info.name,
                info.device_type,
                info.paired_at.to_rfc3339(),
                info.last_seen.to_rfc3339(),
                info.ip_address,
                capabilities_json,
            ],
        )?;
        self.cache.lock().insert(token_hash, info);
        Ok(())
    }

    pub fn reconcile_from_token_hashes(
        &self,
        token_hashes: &[String],
    ) -> Result<usize, rusqlite::Error> {
        let conn = self.open_db()?;
        let mut cache = self.cache.lock();
        let now = Utc::now();
        let now_str = now.to_rfc3339();
        let mut inserted = 0usize;
        for token_hash in token_hashes {
            if cache.contains_key(token_hash) {
                continue;
            }
            let info = DeviceInfo {
                id: uuid::Uuid::new_v4().to_string(),
                name: None,
                device_type: Some("legacy".to_string()),
                paired_at: now,
                last_seen: now,
                ip_address: None,
                capabilities: None,
            };
            let affected = conn.execute(
                "INSERT OR IGNORE INTO devices (token_hash, id, name, device_type, paired_at, last_seen, ip_address, capabilities) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
                rusqlite::params![
                    token_hash,
                    info.id,
                    info.name,
                    info.device_type,
                    now_str,
                    now_str,
                    info.ip_address,
                    None::<String>,
                ],
            )?;
            if affected > 0 {
                cache.insert(token_hash.clone(), info);
                inserted += 1;
            }
        }
        Ok(inserted)
    }

    pub fn list(&self) -> Result<Vec<DeviceInfo>, rusqlite::Error> {
        let conn = self.open_db()?;
        let mut stmt = conn.prepare(
            "SELECT token_hash, id, name, device_type, paired_at, last_seen, ip_address, capabilities FROM devices",
        )?;
        let rows = stmt.query_map([], |row| {
            let id: String = row.get(1)?;
            let name: Option<String> = row.get(2)?;
            let device_type: Option<String> = row.get(3)?;
            let paired_at_str: String = row.get(4)?;
            let last_seen_str: String = row.get(5)?;
            let ip_address: Option<String> = row.get(6)?;
            let capabilities_json: Option<String> = row.get(7)?;
            let paired_at = DateTime::parse_from_rfc3339(&paired_at_str)
                .map(|dt| dt.with_timezone(&Utc))
                .unwrap_or_else(|_| Utc::now());
            let last_seen = DateTime::parse_from_rfc3339(&last_seen_str)
                .map(|dt| dt.with_timezone(&Utc))
                .unwrap_or_else(|_| Utc::now());
            let capabilities = capabilities_json
                .as_deref()
                .and_then(|s| serde_json::from_str::<Vec<String>>(s).ok());
            Ok(DeviceInfo {
                id,
                name,
                device_type,
                paired_at,
                last_seen,
                ip_address,
                capabilities,
            })
        })?;
        rows.collect()
    }

    pub fn revoke(&self, device_id: &str) -> Result<Option<String>, rusqlite::Error> {
        self.revoke_authorized(device_id, || Ok(()))?
    }

    fn revoke_authorized<R>(
        &self,
        device_id: &str,
        authorize: impl FnOnce() -> Result<(), R>,
    ) -> Result<Result<Option<String>, R>, rusqlite::Error> {
        let mut conn = self.open_db()?;
        let tx = conn.transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)?;
        if let Err(refusal) = authorize() {
            return Ok(Err(refusal));
        }
        let deleted: Option<String> = tx
            .query_row(
                "DELETE FROM devices WHERE id = ?1 RETURNING token_hash",
                rusqlite::params![device_id],
                |row| row.get::<_, String>(0),
            )
            .map(Some)
            .or_else(|e| match e {
                rusqlite::Error::QueryReturnedNoRows => Ok(None),
                other => Err(other),
            })?;
        // Release the database writer before taking the cache lock. Reconciliation
        // takes the cache first and also writes this table.
        tx.commit()?;
        if let Some(hash) = deleted.as_ref() {
            self.cache.lock().remove(hash);
        }
        Ok(Ok(deleted))
    }

    /// Delete every device row and clear the in-memory cache. Returns the
    /// number of rows removed. Pairs with `PairingGuard::revoke_all_tokens`
    /// for the "rotate after compromise — nuke everything" path so the device
    /// registry does not silently coexist with the now-revoked token set.
    pub fn clear(&self) -> Result<usize, rusqlite::Error> {
        let conn = self.open_db()?;
        let removed = conn.execute("DELETE FROM devices", [])?;
        self.cache.lock().clear();
        Ok(removed)
    }

    pub fn update_last_seen(&self, token_hash: &str) {
        let now = Utc::now();
        // Last-seen is a best-effort touch — a write failure here is
        // observable (the row's last_seen stays stale) but does not affect
        // pairing or revocation, so swallow the error rather than poisoning
        // the caller.
        if let Ok(conn) = self.open_db() {
            let _ = conn.execute(
                "UPDATE devices SET last_seen = ?1 WHERE token_hash = ?2",
                rusqlite::params![now.to_rfc3339(), token_hash],
            );
        }
        if let Some(device) = self.cache.lock().get_mut(token_hash) {
            device.last_seen = now;
        }
    }

    pub fn update_capabilities(&self, token_hash: &str, capabilities: Vec<String>) -> bool {
        let json = serde_json::to_string(&capabilities).unwrap_or_else(|_| "[]".into());
        let conn = match self.open_db() {
            Ok(c) => c,
            Err(_) => return false,
        };
        let updated = conn
            .execute(
                "UPDATE devices SET capabilities = ?1, last_seen = ?2 WHERE token_hash = ?3",
                rusqlite::params![json, Utc::now().to_rfc3339(), token_hash],
            )
            .unwrap_or(0);
        if updated > 0
            && let Some(device) = self.cache.lock().get_mut(token_hash)
        {
            device.capabilities = Some(capabilities);
            device.last_seen = Utc::now();
        }
        updated > 0
    }

    pub fn device_count(&self) -> usize {
        self.cache.lock().len()
    }
}

use crate::api::{extract_bearer_token, require_auth};

/// POST /api/pairing/initiate — initiate a new pairing session
pub async fn initiate_pairing(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> impl IntoResponse {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }

    match state
        .pairing
        .generate_new_pairing_code(crate::live_pairing_code_policy(&state))
    {
        Some(code) => Json(serde_json::json!({
            "pairing_code": code,
            "message": "New pairing code generated"
        }))
        .into_response(),
        None => (
            StatusCode::SERVICE_UNAVAILABLE,
            "Pairing is disabled or not available",
        )
            .into_response(),
    }
}

/// POST /api/pair — submit pairing code (for new device pairing)
pub async fn submit_pairing_enhanced(
    State(state): State<AppState>,
    ConnectInfo(peer_addr): ConnectInfo<SocketAddr>,
    headers: HeaderMap,
    Json(body): Json<serde_json::Value>,
) -> impl IntoResponse {
    let code = body["code"].as_str().unwrap_or("");
    let device_name = body["device_name"].as_str().map(String::from);
    let device_type = body["device_type"].as_str().map(String::from);

    // Derive the brute-force lockout key from the real connection peer, only trusting
    // forwarded headers behind a configured proxy. Reading it straight from
    // `X-Forwarded-For` let an unauthenticated client vary the header to dodge the
    // per-client lockout entirely. Mirrors the legacy `/pair` handler.
    let client_id =
        super::client_key_from_request(Some(peer_addr), &headers, state.trust_forwarded_headers);

    // Brute-force protection, mirroring the legacy `/pair` handler: a coarse
    // per-key request cap plus the shared auth rate limiter. Both are keyed on
    // the connection-derived client id (not a spoofable header), so this handler
    // cannot bypass rate limiting by rotating untrusted forwarding headers.
    if !state.rate_limiter.allow_pair(&client_id) {
        return (
            StatusCode::TOO_MANY_REQUESTS,
            Json(serde_json::json!({
                "paired": false,
                "error": "Too many pairing requests. Please retry later.",
                "retry_after": super::RATE_LIMIT_WINDOW_SECS,
            })),
        )
            .into_response();
    }
    if let Err(e) = state.auth_limiter.check_rate_limit(&client_id) {
        return (
            StatusCode::TOO_MANY_REQUESTS,
            Json(serde_json::json!({
                "paired": false,
                "error": format!("Too many auth attempts. Try again in {}s.", e.retry_after_secs),
                "retry_after": e.retry_after_secs,
            })),
        )
            .into_response();
    }

    match state.pairing.try_pair(code, &client_id).await {
        Ok(Some(token)) => {
            let token_hash = {
                use sha2::{Digest, Sha256};
                let hash = Sha256::digest(token.as_bytes());
                hex::encode(hash)
            };

            if let Some(ref registry) = state.device_registry {
                if let Err(e) = registry.register(
                    token_hash.clone(),
                    DeviceInfo {
                        id: uuid::Uuid::new_v4().to_string(),
                        name: device_name,
                        device_type,
                        paired_at: Utc::now(),
                        last_seen: Utc::now(),
                        ip_address: Some(client_id),
                        capabilities: None,
                    },
                ) {
                    ::zeroclaw_log::record!(
                        ERROR,
                        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                            .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                            .with_attrs(::serde_json::json!({"error": format!("{e}")})),
                        "device registry insert failed after successful pairing; rolling back in-process token"
                    );
                    state.pairing.revoke_token_hash(&token_hash);
                    return (
                        StatusCode::INTERNAL_SERVER_ERROR,
                        Json(serde_json::json!({
                            "paired": false,
                            "persisted": false,
                            "error": format!("Device registry error: {e}"),
                            "message": "Pairing failed; the in-process token was not retained.",
                        })),
                    )
                        .into_response();
                }
            }
            if let Err(e) = super::persist_pairing_tokens(&state).await {
                ::zeroclaw_log::record!(
                    ERROR,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                        .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                        .with_attrs(::serde_json::json!({"error": format!("{e}")})),
                    "pairing token persistence failed; rolling back in-process token"
                );
                state.pairing.revoke_token_hash(&token_hash);
                return (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    Json(serde_json::json!({
                        "paired": false,
                        "persisted": false,
                        "error": format!("Token persistence error: {e}"),
                        "message": "Pairing failed; the in-process token was not retained.",
                    })),
                )
                    .into_response();
            }
            Json(serde_json::json!({
                "paired": true,
                "persisted": true,
                "token": token,
                "message": "Pairing successful"
            }))
            .into_response()
        }
        Ok(None) => {
            // Feed the shared auth limiter so repeated invalid codes trip the
            // cross-request lockout, exactly as the legacy `/pair` handler does.
            state.auth_limiter.record_attempt(&client_id);
            (
                StatusCode::BAD_REQUEST,
                Json(serde_json::json!({
                    "paired": false,
                    "error": "Invalid or expired pairing code",
                })),
            )
                .into_response()
        }
        Err(lockout_secs) => (
            StatusCode::TOO_MANY_REQUESTS,
            Json(serde_json::json!({
                "paired": false,
                "error": format!("Too many attempts. Locked out for {lockout_secs}s"),
                "retry_after": lockout_secs,
            })),
        )
            .into_response(),
    }
}

/// GET /api/devices — list paired devices
pub async fn list_devices(State(state): State<AppState>, headers: HeaderMap) -> impl IntoResponse {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }

    let devices = match state.device_registry.as_ref() {
        Some(r) => match r.list() {
            Ok(devices) => devices,
            Err(e) => {
                ::zeroclaw_log::record!(
                    ERROR,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                        .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                        .with_attrs(::serde_json::json!({"error": format!("{e}")})),
                    "device registry list failed"
                );
                return (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    format!("Device registry error: {e}"),
                )
                    .into_response();
            }
        },
        None => Vec::new(),
    };

    let current_device_id = extract_bearer_token(&headers).and_then(|token| {
        let hash = super::PairingGuard::token_hash(token);
        state
            .device_registry
            .as_ref()?
            .cache
            .lock()
            .get(&hash)
            .map(|device| device.id.clone())
    });
    let count = devices.len();
    Json(serde_json::json!({
        "devices": devices,
        "current_device_id": current_device_id,
        "count": count
    }))
    .into_response()
}

/// Delete `device_id` and invalidate its bearer token as one revocation.
///
/// An admitted config commit serializes this synchronous removal of both the
/// durable device row and the live token with all other credential writes.
pub(crate) fn revoke_device_credential<R>(
    state: &AppState,
    registry: &DeviceRegistry,
    device_id: &str,
    _commit: &ConfigWriteGuard,
    authorize: impl FnOnce() -> Result<(), R>,
) -> Result<Result<bool, rusqlite::Error>, R> {
    match registry.revoke_authorized(device_id, authorize) {
        Ok(Ok(Some(hash))) => {
            state.pairing.revoke_token_hash(&hash);
            Ok(Ok(true))
        }
        Ok(Ok(None)) => Ok(Ok(false)),
        Ok(Err(refusal)) => Err(refusal),
        Err(error) => Ok(Err(error)),
    }
}

/// The response when a revocation's config commit is refused before
/// anything changed: the daemon generation is closing.
pub(crate) fn revocation_not_admitted(
    error: zeroclaw_runtime::live_config_authority::ConfigCommitError,
) -> (StatusCode, String) {
    (
        StatusCode::SERVICE_UNAVAILABLE,
        format!("Revocation refused without any change: {error}"),
    )
}

/// Recheck the operator under the config writer before either device route
/// removes a credential. Keep the verified cookie for a rotation's later mint.
#[allow(clippy::result_large_err)]
async fn revoke_operator_device(
    state: &AppState,
    headers: &HeaderMap,
    device_id: &str,
    dashboard: Option<&DashboardAuth>,
) -> Result<(ConfigWriteGuard, Option<Arc<SessionAuth>>), axum::response::Response> {
    require_auth(state, headers).map_err(IntoResponse::into_response)?;
    let registry = state.device_registry.as_ref().ok_or_else(|| {
        (
            StatusCode::SERVICE_UNAVAILABLE,
            "Device registry is disabled",
        )
            .into_response()
    })?;
    let begin = || async {
        state
            .begin_config_commit()
            .await
            .map_err(|error| revocation_not_admitted(error).into_response())
    };
    let mut commit = begin().await?;
    let cookie = match crate::dashboard_session::current_caller() {
        Some(DashboardCaller::Session(mut session)) if state.pairing.require_pairing() => {
            let dashboard =
                dashboard.ok_or_else(|| SessionRejection::Invalid.body().into_response())?;
            match dashboard.operator_at_write(state, &session, &commit) {
                Some(result) => result.map_err(IntoResponse::into_response)?,
                None => {
                    // Refresh a changed policy or a due credential without blocking
                    // unrelated config writes on the identity provider.
                    drop(commit);
                    session = match dashboard.recheck(state, &session).await {
                        DashboardCaller::Session(fresh) => fresh,
                        DashboardCaller::Rejected(rejection) => {
                            return Err(rejection.body().into_response());
                        }
                    };
                    commit = begin().await?;
                    dashboard
                        .operator_at_write(state, &session, &commit)
                        .unwrap_or_else(|| Err(SessionRejection::Expired.body()))
                        .map_err(IntoResponse::into_response)?;
                }
            }
            Some(session)
        }
        _ => None,
    };
    // Device registration and capability updates also write this database,
    // independently of the config writer. Check again after that SQLite wait.
    let revoked = revoke_device_credential(state, registry, device_id, &commit, || {
        match (dashboard, cookie.as_deref()) {
            (Some(auth), Some(session)) => auth
                .operator_at_write(state, session, &commit)
                .unwrap_or_else(|| Err(SessionRejection::Expired.body())),
            _ => require_auth(state, headers),
        }
    })
    .map_err(IntoResponse::into_response)?;
    match revoked {
        Ok(true) => Ok((commit, cookie)),
        Ok(false) => Err((StatusCode::NOT_FOUND, "Device not found").into_response()),
        Err(error) => Err((
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("Device registry error: {error}"),
        )
            .into_response()),
    }
}

/// DELETE /api/devices/{id} — revoke a paired device and its bearer token.
pub async fn revoke_device(
    State(state): State<AppState>,
    dashboard: Option<Extension<Arc<DashboardAuth>>>,
    headers: HeaderMap,
    axum::extract::Path(device_id): axum::extract::Path<String>,
) -> impl IntoResponse {
    let (config_write_guard, _) = match revoke_operator_device(
        &state,
        &headers,
        &device_id,
        dashboard.as_ref().map(|Extension(auth)| auth.as_ref()),
    )
    .await
    {
        Ok(revoked) => revoked,
        Err(response) => return response,
    };

    if let Err(e) = super::persist_pairing_tokens_under(&state, config_write_guard).await {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("Token revoked in memory but config persist failed: {e}"),
        )
            .into_response();
    }

    Json(serde_json::json!({
        "message": "Device revoked and bearer token invalidated",
        "device_id": device_id,
    }))
    .into_response()
}

/// POST /api/devices/me/capabilities — the calling device replaces its capability list.
/// The "me" path means there's no separate device id in the URL — the bearer token in
/// Authorization identifies which row gets updated. Body: `{ "capabilities": ["..."] }`.
pub async fn update_my_capabilities(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(body): Json<serde_json::Value>,
) -> impl IntoResponse {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }

    let token = match extract_bearer_token(&headers) {
        Some(t) => t,
        None => return (StatusCode::UNAUTHORIZED, "Missing bearer token").into_response(),
    };
    let token_hash = {
        use sha2::{Digest, Sha256};
        let hash = Sha256::digest(token.as_bytes());
        hex::encode(hash)
    };

    let capabilities: Vec<String> = body
        .get("capabilities")
        .and_then(|v| v.as_array())
        .map(|arr| {
            arr.iter()
                .filter_map(|v| v.as_str().map(String::from))
                .collect()
        })
        .unwrap_or_default();

    let registry = match state.device_registry.as_ref() {
        Some(r) => r,
        None => {
            return (
                StatusCode::SERVICE_UNAVAILABLE,
                "Device registry is disabled",
            )
                .into_response();
        }
    };

    if registry.update_capabilities(&token_hash, capabilities.clone()) {
        Json(serde_json::json!({
            "message": "Capabilities updated",
            "capabilities": capabilities,
        }))
        .into_response()
    } else {
        (StatusCode::NOT_FOUND, "Device not found for this token").into_response()
    }
}

pub async fn rotate_token(
    State(state): State<AppState>,
    dashboard: Option<Extension<Arc<DashboardAuth>>>,
    headers: HeaderMap,
    axum::extract::Path(device_id): axum::extract::Path<String>,
) -> impl IntoResponse {
    let dashboard = dashboard.as_ref().map(|Extension(auth)| auth.as_ref());
    let (config_write_guard, cookie) =
        match revoke_operator_device(&state, &headers, &device_id, dashboard).await {
            Ok(revoked) => revoked,
            Err(response) => return response,
        };

    // Same persist-fail caveat as `revoke_device`: device row + in-memory
    // token are already gone; surfacing the persist error tells the caller
    // a restart could resurrect the token.
    let config_write_guard =
        match super::persist_pairing_tokens_under(&state, config_write_guard).await {
            Ok(guard) => guard,
            Err(e) => {
                return (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    format!("Token revoked in memory but config persist failed: {e}"),
                )
                    .into_response();
            }
        };

    // Time and cookie sign-out can advance during persistence even while
    // policy publication is fenced. A native device may rotate its own bearer.
    if let (Some(dashboard), Some(session)) = (dashboard, cookie)
        && let Err(denied) = dashboard
            .operator_at_write(&state, &session, &config_write_guard)
            .unwrap_or_else(|| Err(SessionRejection::Expired.body()))
    {
        return denied.into_response();
    }

    // Issue the new pairing code while the config commit is still held,
    // so a revocation of this caller queued behind it cannot land between the
    // check above and the code. The code is issued atomically against the
    // slot. If another flow holds the slot, the revoke still stands — return 200 with
    // `pairing_code: null` and a message that tells the operator what
    // happened so they do not assume rotation failed.
    match state.pairing.generate_pairing_code_if_vacant(crate::live_pairing_code_policy(&state)) {
        Ok(code) => Json(serde_json::json!({
            "device_id": device_id,
            "pairing_code": code,
            "message": "Old token revoked. Use this code to re-pair the device.",
        }))
        .into_response(),
        Err(zeroclaw_config::pairing::GeneratePairingCodeError::Pending) => {
            Json(serde_json::json!({
                "device_id": device_id,
                "pairing_code": null,
                "message": "Old token revoked. A pairing code is already pending; use it or call again after it clears.",
            }))
            .into_response()
        }
        Err(zeroclaw_config::pairing::GeneratePairingCodeError::PairingDisabled) => {
            Json(serde_json::json!({
                "device_id": device_id,
                "pairing_code": null,
                "message": "Old token revoked. Pairing is disabled; cannot issue a new code.",
            }))
            .into_response()
        }
    }
}

/// Voice choices belong to an authenticated paired device, never global agent configuration.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(default, deny_unknown_fields)]
pub struct VoicePreferences {
    pub dictation: bool,
    pub reading: bool,
    pub automatic: bool,
    pub language: String,
    pub recognition: RecognitionMode,
    pub voice: String,
    pub rate: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
#[serde(rename_all = "lowercase")]
pub enum RecognitionMode {
    #[default]
    Local,
    Browser,
}

impl Default for VoicePreferences {
    fn default() -> Self {
        Self {
            dictation: false,
            reading: false,
            automatic: false,
            language: "en-US".into(),
            recognition: RecognitionMode::Local,
            voice: String::new(),
            rate: 1.0,
        }
    }
}

/// A voice preferences write. Fields left out keep their saved value, so a
/// screen that changes one setting cannot revert another that was changed
/// elsewhere since it last loaded the record.
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VoicePreferencesUpdate {
    pub dictation: Option<bool>,
    pub reading: Option<bool>,
    pub automatic: Option<bool>,
    pub language: Option<String>,
    pub recognition: Option<RecognitionMode>,
    pub voice: Option<String>,
    pub rate: Option<f64>,
}

impl VoicePreferencesUpdate {
    /// Saved values were checked when they were written, so only the fields
    /// present in this update need checking.
    fn valid(&self) -> bool {
        self.language.as_deref().is_none_or(valid_language)
            && self.voice.as_ref().is_none_or(|voice| voice.len() <= 1024)
            && self
                .rate
                .is_none_or(|rate| rate.is_finite() && (0.5..=2.0).contains(&rate))
    }

    fn apply_to(self, stored: VoicePreferences) -> VoicePreferences {
        VoicePreferences {
            dictation: self.dictation.unwrap_or(stored.dictation),
            reading: self.reading.unwrap_or(stored.reading),
            automatic: self.automatic.unwrap_or(stored.automatic),
            language: self.language.unwrap_or(stored.language),
            recognition: self.recognition.unwrap_or(stored.recognition),
            voice: self.voice.unwrap_or(stored.voice),
            rate: self.rate.unwrap_or(stored.rate),
        }
    }
}

fn valid_language(language: &str) -> bool {
    let mut parts = language.split('-');
    let first = parts.next().unwrap_or_default();
    (2..=3).contains(&first.len())
        && first.bytes().all(|b| b.is_ascii_alphabetic())
        && language.len() <= 64
        && parts.all(|part| {
            (2..=8).contains(&part.len()) && part.bytes().all(|b| b.is_ascii_alphanumeric())
        })
}

#[derive(Serialize)]
struct DeviceVoicePreferences {
    device_id: String,
    preferences: VoicePreferences,
}

fn device_voice_preferences(
    state: &AppState,
    headers: &HeaderMap,
    preferences: Option<VoicePreferencesUpdate>,
) -> axum::response::Response {
    let Some(token) = extract_bearer_token(headers) else {
        return (
            StatusCode::FORBIDDEN,
            "Voice preferences require a paired device",
        )
            .into_response();
    };
    let hash = super::PairingGuard::token_hash(token);
    let authorize = || {
        let held = state.pairing.hold_paired_tokens();
        if held.contains_hash(&hash) {
            Ok(held)
        } else {
            Err(Box::new(
                (
                    StatusCode::FORBIDDEN,
                    "Voice preferences require a paired device",
                )
                    .into_response(),
            ))
        }
    };
    if let Err(refusal) = authorize() {
        return *refusal;
    }
    let Some(registry) = state.device_registry.as_ref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            "Device registry is disabled",
        )
            .into_response();
    };
    registry_voice_preferences_authorized(
        registry,
        VoiceDeviceKey::TokenHash(&hash),
        preferences,
        authorize,
    )
}

fn registry_voice_preferences_authorized<G>(
    registry: &DeviceRegistry,
    key: VoiceDeviceKey<'_>,
    preferences: Option<VoicePreferencesUpdate>,
    authorize: impl FnOnce() -> Result<G, Box<axum::response::Response>>,
) -> axum::response::Response {
    if let Some(preferences) = preferences {
        if !preferences.valid() {
            return (StatusCode::BAD_REQUEST, "Invalid voice preferences").into_response();
        }
        match registry.save_voice_preferences_authorized(key, preferences, authorize) {
            Ok(Err(refusal)) => return *refusal,
            Ok(Ok(true)) => {}
            Ok(Ok(false)) => {
                return (StatusCode::NOT_FOUND, "Paired device not registered").into_response();
            }
            Err(error) => {
                ::zeroclaw_log::record!(
                    ERROR,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                        .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                        .with_attrs(::serde_json::json!({"error": error.to_string()})),
                    "Failed to persist device voice preferences"
                );
                return (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    "Could not save voice preferences",
                )
                    .into_response();
            }
        }
    }
    match registry.voice_preferences(key) {
        Ok(Some(preferences)) => (
            [(axum::http::header::CACHE_CONTROL, "no-store")],
            Json(preferences),
        )
            .into_response(),
        Ok(None) => (StatusCode::NOT_FOUND, "Paired device not registered").into_response(),
        Err(error) => {
            ::zeroclaw_log::record!(
                ERROR,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                    .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                    .with_attrs(::serde_json::json!({"error": error.to_string()})),
                "Failed to read device voice preferences"
            );
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                "Could not read voice preferences",
            )
                .into_response()
        }
    }
}

pub async fn get_my_voice_preferences(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> impl IntoResponse {
    device_voice_preferences(&state, &headers, None)
}

pub async fn put_my_voice_preferences(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(preferences): Json<VoicePreferencesUpdate>,
) -> impl IntoResponse {
    device_voice_preferences(&state, &headers, Some(preferences))
}

// Device management uses the same operator admission as list/revoke. A paired
// bearer is rechecked after SQLite admits the write; an administrator cookie may manage
// registered devices without pretending to be one of them.
fn managed_voice_preferences(
    state: &AppState,
    headers: &HeaderMap,
    device_id: &str,
    preferences: Option<VoicePreferencesUpdate>,
) -> axum::response::Response {
    managed_voice_preferences_authorized(state, headers, device_id, preferences, || Ok(()))
}

fn managed_voice_preferences_authorized(
    state: &AppState,
    headers: &HeaderMap,
    device_id: &str,
    preferences: Option<VoicePreferencesUpdate>,
    authorize: impl FnOnce() -> Result<(), Box<axum::response::Response>>,
) -> axum::response::Response {
    if let Err(error) = require_auth(state, headers) {
        return error.into_response();
    }
    let caller_hash = extract_bearer_token(headers).map(super::PairingGuard::token_hash);
    let require_live_bearer = || {
        let Some(hash) = caller_hash.as_deref() else {
            return Ok(None);
        };
        let held = state.pairing.hold_paired_tokens();
        if held.contains_hash(hash) {
            Ok(Some(held))
        } else {
            Err(Box::new(
                (
                    StatusCode::FORBIDDEN,
                    "Paired operator credential is no longer live",
                )
                    .into_response(),
            ))
        }
    };
    if let Err(refusal) = require_live_bearer() {
        return *refusal;
    }
    let Some(registry) = state.device_registry.as_ref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            "Device registry is disabled",
        )
            .into_response();
    };
    registry_voice_preferences_authorized(
        registry,
        VoiceDeviceKey::DeviceId(device_id),
        preferences,
        || {
            authorize()?;
            require_live_bearer()
        },
    )
}

async fn current_operator_voice_preferences(
    state: &AppState,
    headers: &HeaderMap,
    device_id: &str,
    preferences: Option<VoicePreferencesUpdate>,
    dashboard: Option<&DashboardAuth>,
) -> axum::response::Response {
    let Some(DashboardCaller::Session(mut session)) = crate::dashboard_session::current_caller()
    else {
        return managed_voice_preferences(state, headers, device_id, preferences);
    };
    if !state.pairing.require_pairing() {
        return managed_voice_preferences(state, headers, device_id, preferences);
    }
    let Some(dashboard) = dashboard else {
        return SessionRejection::Invalid.body().into_response();
    };
    let mut commit = match state.begin_config_commit().await {
        Ok(commit) => commit,
        Err(_) => {
            return (
                StatusCode::SERVICE_UNAVAILABLE,
                "Voice preferences write not admitted",
            )
                .into_response();
        }
    };
    if dashboard
        .operator_at_write(state, &session, &commit)
        .is_none()
    {
        drop(commit);
        session = match dashboard.recheck(state, &session).await {
            DashboardCaller::Session(fresh) => fresh,
            DashboardCaller::Rejected(rejection) => return rejection.body().into_response(),
        };
        commit = match state.begin_config_commit().await {
            Ok(commit) => commit,
            Err(_) => {
                return (
                    StatusCode::SERVICE_UNAVAILABLE,
                    "Voice preferences write not admitted",
                )
                    .into_response();
            }
        };
    }
    let authorize = || {
        dashboard
            .operator_at_write(state, &session, &commit)
            .unwrap_or_else(|| Err(SessionRejection::Expired.body()))
            .map_err(|denied| Box::new(denied.into_response()))
    };
    if let Err(refusal) = authorize() {
        return *refusal;
    }
    // The callback runs again after SQLite acquires its writer. The config
    // commit fences mapping changes until the effect finishes.
    managed_voice_preferences_authorized(state, headers, device_id, preferences, authorize)
}

pub async fn get_device_voice_preferences(
    State(state): State<AppState>,
    dashboard: Option<Extension<Arc<DashboardAuth>>>,
    headers: HeaderMap,
    axum::extract::Path(device_id): axum::extract::Path<String>,
) -> impl IntoResponse {
    current_operator_voice_preferences(
        &state,
        &headers,
        &device_id,
        None,
        dashboard.as_ref().map(|Extension(auth)| auth.as_ref()),
    )
    .await
}

pub async fn put_device_voice_preferences(
    State(state): State<AppState>,
    dashboard: Option<Extension<Arc<DashboardAuth>>>,
    headers: HeaderMap,
    axum::extract::Path(device_id): axum::extract::Path<String>,
    Json(preferences): Json<VoicePreferencesUpdate>,
) -> impl IntoResponse {
    current_operator_voice_preferences(
        &state,
        &headers,
        &device_id,
        Some(preferences),
        dashboard.as_ref().map(|Extension(auth)| auth.as_ref()),
    )
    .await
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::GatewayRateLimiter;
    use crate::api::test_state;
    use crate::auth_rate_limit::{AuthRateLimiter, MAX_ATTEMPTS};
    use axum::Json;
    use http_body_util::BodyExt;
    use std::sync::Arc;
    use zeroclaw_config::pairing::PairingGuard;
    use zeroclaw_config::schema::Config;

    /// A full record as a write that sets every field, the way older dashboards save.
    impl From<VoicePreferences> for VoicePreferencesUpdate {
        fn from(full: VoicePreferences) -> Self {
            Self {
                dictation: Some(full.dictation),
                reading: Some(full.reading),
                automatic: Some(full.automatic),
                language: Some(full.language),
                recognition: Some(full.recognition),
                voice: Some(full.voice),
                rate: Some(full.rate),
            }
        }
    }

    fn update(json: serde_json::Value) -> VoicePreferencesUpdate {
        serde_json::from_value(json).unwrap()
    }

    #[tokio::test]
    async fn a_partial_voice_write_keeps_fields_another_screen_saved() {
        let (_dir, state, a, _) = voice_state();
        let (_, own) = response_json(device_voice_preferences(&state, &a, None)).await;
        let id = own["device_id"].as_str().unwrap().to_owned();
        let start = VoicePreferences {
            dictation: true,
            recognition: RecognitionMode::Browser,
            ..Default::default()
        };
        assert_eq!(
            device_voice_preferences(&state, &a, Some(start.into())).status(),
            StatusCode::OK
        );
        // An operator on another computer switches the device to on-device recognition.
        assert_eq!(
            managed_voice_preferences(
                &state,
                &a,
                &id,
                Some(update(serde_json::json!({"recognition": "local"})))
            )
            .status(),
            StatusCode::OK
        );
        // A screen that loaded the record before that change saves only the rate.
        let (status, after) = response_json(device_voice_preferences(
            &state,
            &a,
            Some(update(serde_json::json!({"rate": 1.5}))),
        ))
        .await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(after["preferences"]["rate"], 1.5);
        assert_eq!(after["preferences"]["recognition"], "local");
        assert_eq!(after["preferences"]["dictation"], true);
        // A write that names every field still replaces the whole record.
        let (_, replaced) = response_json(device_voice_preferences(
            &state,
            &a,
            Some(VoicePreferences::default().into()),
        ))
        .await;
        assert_eq!(
            replaced["preferences"],
            serde_json::to_value(VoicePreferences::default()).unwrap()
        );
    }

    #[tokio::test]
    async fn an_invalid_partial_voice_write_changes_nothing() {
        let (_dir, state, a, _) = voice_state();
        let saved = VoicePreferences {
            reading: true,
            language: "pt-BR".into(),
            ..Default::default()
        };
        assert_eq!(
            device_voice_preferences(&state, &a, Some(saved.clone().into())).status(),
            StatusCode::OK
        );
        for bad in [
            serde_json::json!({"rate": 99.0}),
            serde_json::json!({"language": "../../etc"}),
            serde_json::json!({"voice": "v".repeat(1025)}),
        ] {
            assert_eq!(
                device_voice_preferences(&state, &a, Some(update(bad))).status(),
                StatusCode::BAD_REQUEST
            );
        }
        let (_, after) = response_json(device_voice_preferences(&state, &a, None)).await;
        assert_eq!(after["preferences"], serde_json::to_value(saved).unwrap());
    }

    #[tokio::test]
    async fn selected_device_voice_settings_are_isolated_from_the_calling_device() {
        let (_dir, state, a, b) = voice_state();
        let (_, own) = response_json(device_voice_preferences(&state, &a, None)).await;
        let (_, other) = response_json(device_voice_preferences(&state, &b, None)).await;
        let own_id = own["device_id"].as_str().unwrap();
        let other_id = other["device_id"].as_str().unwrap();
        let first = VoicePreferences {
            reading: true,
            voice: "first-voice".into(),
            ..Default::default()
        };
        let second = VoicePreferences {
            reading: false,
            voice: "second-voice".into(),
            rate: 1.4,
            ..Default::default()
        };
        assert_eq!(
            managed_voice_preferences(&state, &a, own_id, Some(first.clone().into())).status(),
            StatusCode::OK
        );
        let (status, saved) = response_json(managed_voice_preferences(
            &state,
            &a,
            other_id,
            Some(second.clone().into()),
        ))
        .await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(saved["device_id"], other_id);
        let (_, still_own) = response_json(device_voice_preferences(&state, &a, None)).await;
        let (_, from_other_browser) =
            response_json(device_voice_preferences(&state, &b, None)).await;
        assert_eq!(
            still_own["preferences"],
            serde_json::to_value(first).unwrap()
        );
        assert_eq!(
            from_other_browser["preferences"],
            serde_json::to_value(second).unwrap()
        );
        let (_, inventory) =
            response_json(list_devices(State(state.clone()), a).await.into_response()).await;
        assert_eq!(inventory["current_device_id"], own_id);
        assert_eq!(inventory["count"], 2);
    }

    #[tokio::test]
    async fn managing_voice_preferences_requires_operator_auth_and_an_existing_device() {
        let (_dir, state, a, _) = voice_state();
        let (_, own) = response_json(device_voice_preferences(&state, &a, None)).await;
        let id = own["device_id"].as_str().unwrap();
        assert_eq!(
            managed_voice_preferences(&state, &HeaderMap::new(), id, None).status(),
            StatusCode::UNAUTHORIZED
        );
        assert_eq!(
            managed_voice_preferences(&state, &a, "missing-device", Some(Default::default()))
                .status(),
            StatusCode::NOT_FOUND
        );
        assert_eq!(
            managed_voice_preferences(&state, &a, "' OR 1=1 --", None).status(),
            StatusCode::NOT_FOUND
        );
        state
            .pairing
            .revoke_token_hash(&PairingGuard::token_hash("voice-test-a"));
        assert_eq!(
            managed_voice_preferences(&state, &a, id, Some(Default::default())).status(),
            StatusCode::UNAUTHORIZED
        );
    }

    #[test]
    fn device_registry_startup_returns_io_and_migration_errors() {
        let tmp = tempfile::tempdir().unwrap();
        assert!(DeviceRegistry::new(&tmp.path().join("missing/parent")).is_err());
        let db = Connection::open(tmp.path().join("devices.db")).unwrap();
        db.execute_batch("CREATE TABLE devices(token_hash TEXT PRIMARY KEY, id TEXT NOT NULL, name TEXT, device_type TEXT, paired_at TEXT NOT NULL, last_seen TEXT NOT NULL, ip_address TEXT, capabilities TEXT); PRAGMA journal_mode=WAL; BEGIN IMMEDIATE;").unwrap();
        assert!(
            DeviceRegistry::new(tmp.path()).is_err(),
            "a blocked schema write must return an error, not panic"
        );
        db.execute_batch("ROLLBACK").unwrap();
        assert!(DeviceRegistry::new(tmp.path()).is_ok());
    }

    #[test]
    fn voice_write_does_not_hold_token_set_across_sqlite_wait() {
        use std::time::{Duration, Instant};
        let (dir, state, headers, _) = voice_state();
        let blocker = Connection::open(dir.path().join("devices.db")).unwrap();
        blocker.execute_batch("BEGIN IMMEDIATE").unwrap();

        let writer_state = state.clone();
        let writer = std::thread::spawn(move || {
            device_voice_preferences(
                &writer_state,
                &headers,
                Some(VoicePreferences::default().into()),
            )
            .status()
        });
        std::thread::sleep(Duration::from_millis(300));
        let revoker_state = state.clone();
        let revoker = std::thread::spawn(move || {
            revoker_state
                .pairing
                .revoke_token_hash(&PairingGuard::token_hash("voice-test-b"));
        });
        std::thread::sleep(Duration::from_millis(300));
        let start = Instant::now();
        assert!(state.pairing.is_authenticated("voice-test-a"));
        let waited = start.elapsed();
        blocker.execute_batch("ROLLBACK").unwrap();
        revoker.join().unwrap();
        assert_eq!(writer.join().unwrap(), StatusCode::OK);
        assert!(
            waited < Duration::from_secs(1),
            "bearer check waited {waited:?}"
        );
    }

    fn voice_state() -> (tempfile::TempDir, AppState, HeaderMap, HeaderMap) {
        let dir = tempfile::tempdir().unwrap();
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &["voice-test-a".into(), "voice-test-b".into()],
            Default::default(),
        ));
        let registry = Arc::new(DeviceRegistry::new(dir.path()).unwrap());
        registry
            .reconcile_from_token_hashes(&state.pairing.tokens())
            .unwrap();
        state.device_registry = Some(registry);
        let mut a = HeaderMap::new();
        a.insert("authorization", "Bearer voice-test-a".parse().unwrap());
        let mut b = HeaderMap::new();
        b.insert("authorization", "Bearer voice-test-b".parse().unwrap());
        (dir, state, a, b)
    }

    #[tokio::test]
    async fn voice_preferences_persist_per_paired_device_and_revoke_with_it() {
        let (dir, mut state, a, b) = voice_state();
        let prefs = VoicePreferences {
            reading: true,
            language: "pt-BR".into(),
            ..Default::default()
        };
        let response = device_voice_preferences(&state, &a, Some(prefs.clone().into()));
        let (status, body) = response_json(response).await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(body["preferences"]["reading"], true);
        let id = body["device_id"].as_str().unwrap().to_owned();
        assert!(!body.to_string().contains("voice-test-a"));
        let (_, other) = response_json(device_voice_preferences(&state, &b, None)).await;
        assert_eq!(other["preferences"]["reading"], false);
        assert_ne!(body["device_id"], other["device_id"]);
        state.device_registry = Some(Arc::new(DeviceRegistry::new(dir.path()).unwrap()));
        let (_, restored) = response_json(device_voice_preferences(&state, &a, None)).await;
        assert_eq!(restored, body);
        state
            .pairing
            .revoke_token_hash(&PairingGuard::token_hash("voice-test-a"));
        assert_eq!(
            device_voice_preferences(&state, &a, None).status(),
            StatusCode::FORBIDDEN
        );
        state.device_registry.as_ref().unwrap().revoke(&id).unwrap();
        assert!(
            state
                .device_registry
                .as_ref()
                .unwrap()
                .voice_preferences(VoiceDeviceKey::TokenHash(&PairingGuard::token_hash(
                    "voice-test-a"
                )))
                .unwrap()
                .is_none()
        );
    }

    #[test]
    fn voice_preferences_reject_unpaired_identity_invalid_input_and_database_failure() {
        let (_dir, mut state, a, _) = voice_state();
        assert_eq!(
            device_voice_preferences(&state, &HeaderMap::new(), None).status(),
            StatusCode::FORBIDDEN
        );
        let bad = VoicePreferences {
            rate: 99.0,
            ..Default::default()
        };
        assert_eq!(
            device_voice_preferences(&state, &a, Some(bad.into())).status(),
            StatusCode::BAD_REQUEST
        );
        let bad = VoicePreferences {
            language: "../../etc".into(),
            ..Default::default()
        };
        assert!(!VoicePreferencesUpdate::from(bad).valid());
        assert!(
            serde_json::from_value::<VoicePreferencesUpdate>(
                serde_json::json!({"device_id":"someone-else"})
            )
            .is_err()
        );
        state.device_registry = Some(Arc::new(DeviceRegistry::with_db_path(PathBuf::from(
            "/nonexistent-voice-test/devices.db",
        ))));
        assert_eq!(
            device_voice_preferences(&state, &a, Some(Default::default())).status(),
            StatusCode::INTERNAL_SERVER_ERROR
        );
    }

    /// Build an `AppState` whose device-registry points at a non-existent
    /// path so every SQLite write fails. Pairing enabled so a freshly
    /// issued code is actually consumable.
    fn unwriteable_registry_state() -> AppState {
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.device_registry = Some(Arc::new(DeviceRegistry::with_db_path(PathBuf::from(
            "/this/path/does/not/exist/devices.db",
        ))));
        state
    }

    async fn response_json(response: axum::response::Response) -> (StatusCode, serde_json::Value) {
        let status = response.status();
        let bytes = response.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        (status, json)
    }

    #[test]
    fn device_revoke_checks_authority_while_holding_the_sqlite_writer() {
        let tmp = tempfile::tempdir().unwrap();
        let registry = DeviceRegistry::new(tmp.path()).unwrap();
        registry
            .reconcile_from_token_hashes(&["synthetic-token-hash".into()])
            .unwrap();
        let id = registry.list().unwrap().pop().unwrap().id;
        let competing_writer = registry.open_db().unwrap();
        competing_writer
            .busy_timeout(std::time::Duration::ZERO)
            .unwrap();
        for permitted in [false, true] {
            let result = registry
                .revoke_authorized(&id, || {
                    let error = competing_writer
                        .execute_batch("BEGIN IMMEDIATE")
                        .unwrap_err();
                    assert_eq!(
                        error.sqlite_error_code(),
                        Some(rusqlite::ErrorCode::DatabaseBusy)
                    );
                    permitted.then_some(()).ok_or("denied")
                })
                .unwrap();
            if permitted {
                assert_eq!(result.unwrap().as_deref(), Some("synthetic-token-hash"));
            } else {
                assert_eq!(result.unwrap_err(), "denied");
            }
            assert_eq!(registry.device_count(), usize::from(!permitted));
            assert_eq!(registry.list().unwrap().len(), usize::from(!permitted));
        }
    }

    #[tokio::test]
    async fn submit_pairing_enhanced_rolls_back_in_process_token_when_registry_register_fails() {
        let state = unwriteable_registry_state();

        // Issue a pairing code so the next `try_pair` succeeds.
        let code = state
            .pairing
            .generate_new_pairing_code(crate::live_pairing_code_policy(&state))
            .expect("pairing code must be issuable when require_pairing=true");

        let (status, body) = response_json(
            submit_pairing_enhanced(
                State(state.clone()),
                ConnectInfo("127.0.0.1:40000".parse().unwrap()),
                HeaderMap::new(),
                Json(serde_json::json!({"code": code, "device_name": "test"})),
            )
            .await
            .into_response(),
        )
        .await;

        assert_eq!(
            status,
            StatusCode::INTERNAL_SERVER_ERROR,
            "registry.register failure path must surface as 500"
        );
        assert_eq!(body["paired"], serde_json::Value::Bool(false));
        assert_eq!(body["persisted"], serde_json::Value::Bool(false));
        assert!(
            body.get("token").is_none(),
            "5xx body MUST NOT contain the plaintext bearer token; got: {body}"
        );
        assert!(
            state.pairing.tokens().is_empty(),
            "PairingGuard::paired_tokens must be empty after a failed registry.register \
             (compensating `revoke_token_hash`); instead have {:?}",
            state.pairing.tokens()
        );
    }

    #[tokio::test]
    async fn submit_pairing_enhanced_rolls_back_in_process_token_when_persist_fails() {
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        let tmp = tempfile::TempDir::new().unwrap();
        let blocker = tmp.path().join("blocker");
        std::fs::write(&blocker, b"").expect("seed blocker file");
        state.publish_test_config(|cfg| cfg.config_path = blocker.join("config.toml"));

        let code = state
            .pairing
            .generate_new_pairing_code(crate::live_pairing_code_policy(&state))
            .expect("pairing code must be issuable when require_pairing=true");

        let (status, body) = response_json(
            submit_pairing_enhanced(
                State(state.clone()),
                ConnectInfo("127.0.0.1:40001".parse().unwrap()),
                HeaderMap::new(),
                Json(serde_json::json!({"code": code})),
            )
            .await
            .into_response(),
        )
        .await;

        assert_eq!(
            status,
            StatusCode::INTERNAL_SERVER_ERROR,
            "persistence failure path must surface as 500 (legacy leaked 200 + token)"
        );
        assert_eq!(body["paired"], serde_json::Value::Bool(false));
        assert!(
            body.get("token").is_none(),
            "5xx body MUST NOT contain the plaintext bearer token; got: {body}"
        );
        assert!(
            state.pairing.tokens().is_empty(),
            "PairingGuard::paired_tokens must be empty after a failed persist; have {:?}",
            state.pairing.tokens()
        );
    }

    #[tokio::test]
    async fn submit_pairing_enhanced_keys_lockout_on_peer_not_forwarded_header() {
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        // Default config does not trust forwarded headers.
        assert!(!state.trust_forwarded_headers);

        let peer: SocketAddr = "203.0.113.7:55555".parse().unwrap();

        // Five wrong codes from one peer, each spoofing a different X-Forwarded-For.
        for i in 0..5 {
            let mut headers = HeaderMap::new();
            headers.insert("X-Forwarded-For", format!("192.0.2.{i}").parse().unwrap());
            let (status, _) = response_json(
                submit_pairing_enhanced(
                    State(state.clone()),
                    ConnectInfo(peer),
                    headers,
                    Json(serde_json::json!({"code": "wrong"})),
                )
                .await
                .into_response(),
            )
            .await;
            assert_eq!(
                status,
                StatusCode::BAD_REQUEST,
                "attempt {i} is an invalid code and must not be locked out yet"
            );
        }

        // A sixth attempt with yet another spoofed header must be locked out:
        // the real peer IP keeps every spoofed value in the same bucket.
        let mut headers = HeaderMap::new();
        headers.insert("X-Forwarded-For", "198.51.100.9".parse().unwrap());
        let (status, _) = response_json(
            submit_pairing_enhanced(
                State(state.clone()),
                ConnectInfo(peer),
                headers,
                Json(serde_json::json!({"code": "wrong"})),
            )
            .await
            .into_response(),
        )
        .await;
        assert_eq!(
            status,
            StatusCode::TOO_MANY_REQUESTS,
            "lockout must key on the peer IP so X-Forwarded-For spoofing cannot bypass it"
        );
    }

    #[tokio::test]
    async fn submit_pairing_enhanced_honors_trusted_forwarded_client_identity() {
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.trust_forwarded_headers = true;
        state.rate_limiter = Arc::new(GatewayRateLimiter::new(1, 100, 100));
        let peer: SocketAddr = "10.0.0.2:55555".parse().unwrap();

        for forwarded in ["198.51.100.10", "198.51.100.11"] {
            let mut headers = HeaderMap::new();
            headers.insert("X-Forwarded-For", forwarded.parse().unwrap());
            let (status, _) = response_json(
                submit_pairing_enhanced(
                    State(state.clone()),
                    ConnectInfo(peer),
                    headers,
                    Json(serde_json::json!({"code": "wrong"})),
                )
                .await
                .into_response(),
            )
            .await;
            assert_eq!(
                status,
                StatusCode::BAD_REQUEST,
                "trusted forwarded clients must receive independent rate buckets"
            );
        }

        let mut headers = HeaderMap::new();
        headers.insert("X-Forwarded-For", "198.51.100.10".parse().unwrap());
        let (status, body) = response_json(
            submit_pairing_enhanced(
                State(state),
                ConnectInfo(peer),
                headers,
                Json(serde_json::json!({"code": "wrong"})),
            )
            .await
            .into_response(),
        )
        .await;
        assert_eq!(status, StatusCode::TOO_MANY_REQUESTS);
        assert_eq!(
            body["error"],
            "Too many pairing requests. Please retry later."
        );
    }

    #[tokio::test]
    async fn submit_pairing_enhanced_enforces_pair_request_limiter_threshold() {
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.rate_limiter = Arc::new(GatewayRateLimiter::new(2, 100, 100));
        let peer: SocketAddr = "203.0.113.20:55555".parse().unwrap();

        for attempt in 0..2 {
            let (status, _) = response_json(
                submit_pairing_enhanced(
                    State(state.clone()),
                    ConnectInfo(peer),
                    HeaderMap::new(),
                    Json(serde_json::json!({"code": "wrong"})),
                )
                .await
                .into_response(),
            )
            .await;
            assert_eq!(status, StatusCode::BAD_REQUEST, "attempt {attempt}");
        }

        let (status, body) = response_json(
            submit_pairing_enhanced(
                State(state),
                ConnectInfo(peer),
                HeaderMap::new(),
                Json(serde_json::json!({"code": "wrong"})),
            )
            .await
            .into_response(),
        )
        .await;
        assert_eq!(status, StatusCode::TOO_MANY_REQUESTS);
        assert_eq!(
            body["error"],
            "Too many pairing requests. Please retry later."
        );
    }

    #[tokio::test]
    async fn submit_pairing_enhanced_enforces_shared_auth_limiter_threshold() {
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.rate_limiter = Arc::new(GatewayRateLimiter::new(100, 100, 100));
        state.auth_limiter = Arc::new(AuthRateLimiter::new());
        let peer: SocketAddr = "203.0.113.30:55555".parse().unwrap();
        let client_id = peer.ip().to_string();
        for _ in 0..MAX_ATTEMPTS {
            state.auth_limiter.record_attempt(&client_id);
        }

        let (status, body) = response_json(
            submit_pairing_enhanced(
                State(state),
                ConnectInfo(peer),
                HeaderMap::new(),
                Json(serde_json::json!({"code": "wrong"})),
            )
            .await
            .into_response(),
        )
        .await;
        assert_eq!(status, StatusCode::TOO_MANY_REQUESTS);
        assert!(
            body["error"]
                .as_str()
                .is_some_and(|error| error.starts_with("Too many auth attempts.")),
            "response must come from the shared authentication limiter: {body}"
        );
    }

    #[tokio::test]
    async fn submit_pairing_enhanced_invalid_code_feeds_shared_auth_limiter() {
        // The handler must *record* each invalid attempt into the shared auth
        // limiter, not merely check pre-existing state. Preload the limiter to
        // one below the threshold, then a single invalid pairing call must push
        // it to the threshold so the *next* request is locked out by the shared
        // limiter. This fails if the handler's `record_attempt` call is dropped:
        // the second request would still see `MAX_ATTEMPTS - 1` and return 400.
        // PairingGuard sees only two attempts here (< its 5-attempt lockout), so
        // it never produces the 429 — the lockout can only come from the shared
        // limiter the handler fed.
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.rate_limiter = Arc::new(GatewayRateLimiter::new(100, 100, 100));
        state.auth_limiter = Arc::new(AuthRateLimiter::new());
        let peer: SocketAddr = "203.0.113.40:55555".parse().unwrap();
        let client_id = peer.ip().to_string();

        for _ in 0..(MAX_ATTEMPTS - 1) {
            state.auth_limiter.record_attempt(&client_id);
        }

        let (status, _) = response_json(
            submit_pairing_enhanced(
                State(state.clone()),
                ConnectInfo(peer),
                HeaderMap::new(),
                Json(serde_json::json!({"code": "wrong"})),
            )
            .await
            .into_response(),
        )
        .await;
        assert_eq!(
            status,
            StatusCode::BAD_REQUEST,
            "an invalid code returns 400 and records the attempt into the shared limiter"
        );

        let (status, body) = response_json(
            submit_pairing_enhanced(
                State(state),
                ConnectInfo(peer),
                HeaderMap::new(),
                Json(serde_json::json!({"code": "wrong"})),
            )
            .await
            .into_response(),
        )
        .await;
        assert_eq!(
            status,
            StatusCode::TOO_MANY_REQUESTS,
            "the handler's own recording pushed the shared limiter to its threshold"
        );
        assert!(
            body["error"]
                .as_str()
                .is_some_and(|error| error.starts_with("Too many auth attempts.")),
            "the lockout must come from the shared auth limiter, not PairingGuard: {body}"
        );
    }

    /// Serve `submit_pairing_enhanced` on a real loopback listener with
    /// `ConnectInfo<SocketAddr>` and return the bound address plus the server
    /// task handle, so tests exercise the outer HTTP + proxy boundary rather
    /// than calling the handler directly.
    async fn serve_pairing(state: AppState) -> (std::net::SocketAddr, tokio::task::JoinHandle<()>) {
        let app = axum::Router::new()
            .route("/api/pair", axum::routing::post(submit_pairing_enhanced))
            .with_state(state);
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let handle = zeroclaw_spawn::spawn!(async move {
            let _ = axum::serve(
                listener,
                app.into_make_service_with_connect_info::<std::net::SocketAddr>(),
            )
            .await;
        });
        (addr, handle)
    }

    /// Send one wrong `POST /api/pair` over a fresh connection with the given
    /// `X-Forwarded-For`, returning the HTTP status code. A raw request keeps
    /// the test free of an HTTP-client dependency while still driving the real
    /// service (ConnectInfo + header extraction).
    async fn post_pair_status(addr: std::net::SocketAddr, forwarded_for: &str) -> u16 {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let body = r#"{"code":"wrong"}"#;
        let request = format!(
            "POST /api/pair HTTP/1.1\r\nHost: localhost\r\nX-Forwarded-For: {forwarded_for}\r\n\
             Content-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",
            body.len(),
        );
        let mut stream = tokio::net::TcpStream::connect(addr).await.unwrap();
        stream.write_all(request.as_bytes()).await.unwrap();
        let mut response = Vec::new();
        stream.read_to_end(&mut response).await.unwrap();
        let text = String::from_utf8_lossy(&response);
        let status_line = text.lines().next().expect("HTTP status line");
        status_line
            .split_whitespace()
            .nth(1)
            .and_then(|code| code.parse().ok())
            .expect("HTTP status code")
    }

    #[tokio::test]
    async fn submit_pairing_enhanced_http_boundary_rotating_forwarded_header_cannot_evade_lockout()
    {
        // Default (untrusted) forwarded headers: a single direct peer rotating
        // `X-Forwarded-For` on every request must not dodge the peer-keyed
        // lockout. After five wrong attempts the sixth is locked out (429).
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.rate_limiter = Arc::new(GatewayRateLimiter::new(100, 100, 100));
        state.auth_limiter = Arc::new(AuthRateLimiter::new());
        state.trust_forwarded_headers = false;

        let (addr, server) = serve_pairing(state).await;

        let mut statuses = Vec::new();
        for i in 0..6 {
            statuses.push(post_pair_status(addr, &format!("10.0.0.{i}")).await);
        }
        server.abort();

        assert_eq!(
            statuses,
            vec![400, 400, 400, 400, 400, 429],
            "rotating X-Forwarded-For from one direct peer must not evade the lockout"
        );
    }

    #[tokio::test]
    async fn submit_pairing_enhanced_http_boundary_trusted_proxy_separates_clients() {
        // Trusted-proxy mode: the forwarded client identity is honoured, so
        // client A's five failures lock only A. Client B keeps a fresh bucket,
        // and A's sixth request is the one that is locked out.
        let mut state = test_state(Config::default());
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.rate_limiter = Arc::new(GatewayRateLimiter::new(100, 100, 100));
        state.auth_limiter = Arc::new(AuthRateLimiter::new());
        state.trust_forwarded_headers = true;

        let (addr, server) = serve_pairing(state).await;

        let client_a = "198.51.100.7";
        let client_b = "198.51.100.8";

        let mut a_statuses = Vec::new();
        for _ in 0..5 {
            a_statuses.push(post_pair_status(addr, client_a).await);
        }
        let b_status = post_pair_status(addr, client_b).await;
        let a_sixth = post_pair_status(addr, client_a).await;
        server.abort();

        assert_eq!(
            a_statuses,
            vec![400, 400, 400, 400, 400],
            "client A's five wrong attempts"
        );
        assert_eq!(
            b_status, 400,
            "client B has an independent bucket behind the trusted proxy"
        );
        assert_eq!(a_sixth, 429, "client A is locked out on its sixth attempt");
    }
}
