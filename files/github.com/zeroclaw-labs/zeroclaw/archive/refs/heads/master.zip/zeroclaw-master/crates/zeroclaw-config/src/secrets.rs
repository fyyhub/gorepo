// Encrypted secret store — defense-in-depth for API keys and tokens.
//
// Secrets are encrypted using ChaCha20-Poly1305 AEAD with a random key stored
// in `~/.zeroclaw/.secret_key` with restrictive file permissions (0600). The
// config file stores only hex-encoded ciphertext, never plaintext keys.
//
// Each encryption generates a fresh random 12-byte nonce, prepended to the
// ciphertext. The Poly1305 authentication tag prevents tampering.
//
// This prevents:
//   - Plaintext exposure in config files
//   - Casual `grep` or `git log` leaks
//   - Accidental commit of raw API keys
//   - Known-plaintext attacks (unlike the previous XOR cipher)
//   - Ciphertext tampering (authenticated encryption)
//
// For sovereign users who prefer plaintext, `secrets.encrypt = false` disables this.
//
// Migration: values with the legacy `enc:` prefix (XOR cipher) are decrypted
// using the old algorithm for backward compatibility. New encryptions always
// produce `enc2:` (ChaCha20-Poly1305).

use anyhow::{Context, Result};
use chacha20poly1305::aead::{Aead, KeyInit, OsRng};
use chacha20poly1305::{AeadCore, ChaCha20Poly1305, Key, Nonce};
use hmac::{Hmac, Mac};
use sha2::Sha256;
use std::fmt::Debug;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

#[cfg(windows)]
mod windows_key_file;

/// Length of the random encryption key in bytes (256-bit, matches `ChaCha20`).
#[cfg(test)]
const KEY_LEN: usize = 32;

/// ChaCha20-Poly1305 nonce length in bytes.
const NONCE_LEN: usize = 12;

/// Domain prefix for [`SecretStore::keyed_digest`], so a blind-index digest
/// can never collide with another use of the install key.
const KEYED_DIGEST_DOMAIN: &[u8] = b"zeroclaw.secret-store.keyed-digest.v1\0";

/// HKDF `info` for the blind-index subkey. The install key encrypts with
/// ChaCha20-Poly1305; digests use a key derived from it, never the key itself.
const KEYED_DIGEST_SUBKEY_INFO: &[u8] = b"zeroclaw.secret-store.keyed-digest-subkey.v1";

const ONEPASSWORD_READ_TIMEOUT: Duration = Duration::from_secs(10);

/// Maps a backend to its provisioning lifecycle.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProvisioningState {
    /// Persistent key material is present locally.
    Initialized,
    /// No local material; needs `initialize()` before `with_key()`.
    NeedsInitialization,
    /// Key material is managed externally; nothing to check locally.
    ExternallyProvisioned,
}

/// Abstracts where the master encryption key is obtained.
///
/// Object-safe, single-trait design.  Only `with_key`, `backend_name`,
/// and `provisioning_state` are required; `initialize` has a default
/// error for backends that cannot create keys locally.
pub trait KeySource: Debug + Send + Sync {
    /// Run `f` with a reference to the 256-bit master key.  The
    /// reference is only valid during the call.
    fn with_key(&self, f: &mut dyn FnMut(&[u8; 32]) -> Result<()>) -> Result<()>;

    /// Human-readable label for diagnostic messages.
    fn backend_name(&self) -> &'static str;

    /// Local-only provisioning check — MUST NOT run scripts or
    /// prompt for user input.
    fn provisioning_state(&self) -> ProvisioningState;

    /// Generate fresh key material.  Default error for backends
    /// that cannot create keys locally.
    fn initialize(&self) -> Result<()> {
        anyhow::bail!(
            "The '{}' backend does not support automatic key generation. \
             Create the master key externally, then verify access with \
             `zeroclaw quickstart`.",
            self.backend_name()
        )
    }
}

/// File-system backed key source.  Reads/writes a 32-byte hex-encoded
/// key at the given path (default: `~/.zeroclaw/.secret_key`, 0600).
#[derive(Debug, Clone)]
pub struct FileKeySource {
    key_path: PathBuf,
}

impl FileKeySource {
    pub fn new(key_path: PathBuf) -> Self {
        Self { key_path }
    }
}

impl KeySource for FileKeySource {
    fn with_key(&self, f: &mut dyn FnMut(&[u8; 32]) -> Result<()>) -> Result<()> {
        let key_bytes = load_or_create_key(&self.key_path)?;
        // load_or_create_key always returns 32 bytes.
        let mut key = [0u8; 32];
        key.copy_from_slice(&key_bytes);
        let result = f(&key);
        // Best-effort zeroisation on the stack copy.
        key.fill(0);
        result
    }

    fn backend_name(&self) -> &'static str {
        "file"
    }

    fn provisioning_state(&self) -> ProvisioningState {
        // Bind the "initialized?" check to the same no-follow open the read
        // path uses: a symlink / reparse point must never count as Initialized,
        // and the check is against an opened handle rather than a second path
        // resolution.  A directory is rejected via the is_file() recheck.
        match open_no_follow(&self.key_path) {
            Ok(f) => match f.metadata() {
                Ok(m) if m.is_file() => ProvisioningState::Initialized,
                _ => ProvisioningState::NeedsInitialization,
            },
            Err(_) => ProvisioningState::NeedsInitialization,
        }
    }

    fn initialize(&self) -> Result<()> {
        let key = generate_random_key();
        write_key_file(&self.key_path, &key)
    }
}

/// Manages encrypted storage of secrets (API keys, tokens, etc.)
#[derive(Debug, Clone)]
pub struct SecretStore {
    /// Where the master key is obtained from.
    key_source: Arc<dyn KeySource>,
    /// Whether encryption is enabled
    enabled: bool,
}

impl SecretStore {
    /// Create a new secret store rooted at the given directory.
    /// Phase 1: always uses the file backend (`.secret_key`).
    pub fn new(zeroclaw_dir: &Path, enabled: bool) -> Self {
        Self {
            key_source: Arc::new(FileKeySource::new(zeroclaw_dir.join(".secret_key"))),
            enabled,
        }
    }

    /// Only for tests: construct a store from an arbitrary `KeySource`.
    #[cfg(test)]
    pub fn from_key_source(key_source: Arc<dyn KeySource>, enabled: bool) -> Self {
        Self {
            key_source,
            enabled,
        }
    }

    /// Only for tests: run a closure with a reference to the raw key.
    /// Panics if `with_key` returns an error.
    #[cfg(test)]
    pub fn with_test_key<R>(&self, f: impl FnOnce(&[u8]) -> R) -> R {
        let mut f = Some(f);
        let mut result = None;
        self.key_source
            .with_key(&mut |key| {
                result = Some(f.take().expect("callback re-entered")(key));
                Ok(())
            })
            .expect("with_key failed in test helper");
        result.expect("callback not invoked")
    }

    /// Only for tests: check whether two stores share the same
    /// `Arc<dyn KeySource>` allocation (ptr equality).
    #[cfg(test)]
    pub fn key_source_ptr_eq(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.key_source, &other.key_source)
    }

    /// Obtain the master key through the trait callback contract.
    /// Enforces exactly-once invocation — a backend that returns
    /// `Ok(())` without calling the closure, or that calls it more
    /// than once, gets an error instead of a panic.
    fn get_key<R>(&self, f: impl FnOnce(&[u8; 32]) -> Result<R>) -> Result<R> {
        let mut call_count: u32 = 0;
        let mut f = Some(f);
        let mut result: Option<Result<R>> = None;

        let backend_result = self.key_source.with_key(&mut |key| {
            call_count = call_count.saturating_add(1);
            // On the 2nd+ invocation, don't invoke the real callback
            // again — we'll detect the violation after with_key returns.
            if call_count > 1 {
                return Ok(());
            }
            // Take the callback. If it's already None (shouldn't happen
            // in single-threaded use), return Ok(()) and let the
            // post-validation produce a clear diagnostic.
            let cb = match f.take() {
                Some(cb) => cb,
                None => return Ok(()),
            };
            result = Some(cb(key));
            Ok(())
        });

        // Propagate backend errors first — the backend itself failed.
        backend_result?;

        // Then enforce exactly-once independently. The backend's return
        // value cannot mask a callback-count violation.
        let backend = self.key_source.backend_name();
        match call_count {
            0 => Err(anyhow::Error::msg(format!(
                "key source '{backend}' did not invoke the callback"
            ))),
            1 => match result {
                Some(Ok(value)) => Ok(value),
                // Propagate the original callback error without wrapping
                // so existing diagnostics (backend name, tampered
                // ciphertext, UTF-8, etc.) appear unchanged.
                Some(Err(e)) => Err(e),
                None => Err(anyhow::Error::msg(format!(
                    "key source '{backend}' invoked the callback but did not produce a result"
                ))),
            },
            n => Err(anyhow::Error::msg(format!(
                "key source '{backend}' invoked the callback {n} times (expected exactly once)"
            ))),
        }
    }

    /// Encrypt a plaintext secret. Returns hex-encoded ciphertext prefixed with `enc2:`.
    /// Format: `enc2:<hex(nonce ‖ ciphertext ‖ tag)>` (12 + N + 16 bytes).
    /// If encryption is disabled, returns the plaintext as-is.
    pub fn encrypt(&self, plaintext: &str) -> Result<String> {
        if !self.enabled || plaintext.is_empty() {
            return Ok(plaintext.to_string());
        }

        self.get_key(|key| {
            let key = Key::from_slice(key);
            let cipher = ChaCha20Poly1305::new(key);

            let nonce = ChaCha20Poly1305::generate_nonce(&mut OsRng);
            let ciphertext = cipher.encrypt(&nonce, plaintext.as_bytes()).map_err(|e| {
                ::zeroclaw_log::record!(
                    ERROR,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                        .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                        .with_attrs(::serde_json::json!({"error": format!("{}", e)})),
                    "ChaCha20-Poly1305 encryption failed"
                );
                anyhow::Error::msg(format!("Encryption failed: {e}"))
            })?;

            // Prepend nonce to ciphertext for storage
            let mut blob = Vec::with_capacity(NONCE_LEN + ciphertext.len());
            blob.extend_from_slice(&nonce);
            blob.extend_from_slice(&ciphertext);

            Ok(format!("enc2:{}", hex_encode(&blob)))
        })
    }

    /// Decrypt a secret.
    /// - `enc2:` prefix → ChaCha20-Poly1305 (current format)
    /// - `enc:` prefix → legacy XOR cipher (backward compatibility for migration)
    /// - `op://` prefix → resolved via 1Password CLI (`op read`)
    /// - No prefix → returned as-is (plaintext config)
    ///
    /// **Warning**: Legacy `enc:` values are insecure. Use `decrypt_and_migrate` to
    /// automatically upgrade them to the secure `enc2:` format.
    pub fn decrypt(&self, value: &str) -> Result<String> {
        if let Some(hex_str) = value.strip_prefix("enc2:") {
            self.decrypt_chacha20(hex_str)
        } else if let Some(hex_str) = value.strip_prefix("enc:") {
            self.decrypt_legacy_xor(hex_str)
        } else if is_onepassword_ref(value) {
            resolve_onepassword_ref(value)
        } else {
            Ok(value.to_string())
        }
    }

    /// Decrypt a secret and return a migrated `enc2:` value if the input used legacy `enc:` format.
    ///
    /// Returns `(plaintext, Some(new_enc2_value))` if migration occurred, or
    /// `(plaintext, None)` if no migration was needed.
    ///
    /// This allows callers to persist the upgraded value back to config.
    pub fn decrypt_and_migrate(&self, value: &str) -> Result<(String, Option<String>)> {
        if let Some(hex_str) = value.strip_prefix("enc2:") {
            // Already using secure format — no migration needed
            let plaintext = self.decrypt_chacha20(hex_str)?;
            Ok((plaintext, None))
        } else if let Some(hex_str) = value.strip_prefix("enc:") {
            // Legacy XOR cipher — decrypt and re-encrypt with ChaCha20-Poly1305
            ::zeroclaw_log::record!(
                WARN,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note)
                    .with_outcome(::zeroclaw_log::EventOutcome::Unknown),
                "Decrypting legacy XOR-encrypted secret (enc: prefix). \
                 This format is insecure and will be removed in a future release. \
                 The secret will be automatically migrated to enc2: (ChaCha20-Poly1305)."
            );
            let plaintext = self.decrypt_legacy_xor(hex_str)?;
            let migrated = self.encrypt(&plaintext)?;
            Ok((plaintext, Some(migrated)))
        } else if is_onepassword_ref(value) {
            let plaintext = resolve_onepassword_ref(value)?;
            Ok((plaintext, None))
        } else {
            // Plaintext — no migration needed
            Ok((value.to_string(), None))
        }
    }

    /// Check if a value uses the legacy `enc:` format that should be migrated.
    pub fn needs_migration(value: &str) -> bool {
        value.starts_with("enc:")
    }

    /// Decrypt using ChaCha20-Poly1305 (current secure format).
    fn decrypt_chacha20(&self, hex_str: &str) -> Result<String> {
        self.require_existing_key()?;
        let blob =
            hex_decode(hex_str).context("Failed to decode encrypted secret (corrupt hex)")?;
        anyhow::ensure!(
            blob.len() > NONCE_LEN,
            "Encrypted value too short (missing nonce)"
        );

        let (nonce_bytes, ciphertext) = blob.split_at(NONCE_LEN);
        let nonce = Nonce::from_slice(nonce_bytes);

        self.get_key(|key| {
            let key = Key::from_slice(key);
            let cipher = ChaCha20Poly1305::new(key);

            let plaintext_bytes = cipher.decrypt(nonce, ciphertext).map_err(|e| {
                let backend = self.key_source.backend_name();
                ::zeroclaw_log::record!(
                    ERROR,
                    ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                        .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                        .with_attrs(::serde_json::json!({
                            "backend": backend,
                            "error": format!("{e}")
                        })),
                    "enc2: decryption failed — key mismatch or missing material. \
                         Common cause: volume wipe, container migration, \
                         or backup-restore where the key material was not \
                         preserved alongside `config.toml`.  Restore the \
                         original key material from backup, or re-encrypt \
                         the affected secrets via `zeroclaw quickstart`."
                );
                anyhow::Error::msg(format!(
                    "enc2: decryption failed (wrong key for '{}' backend, or tampered ciphertext): {e}",
                    backend
                ))
            })?;

            String::from_utf8(plaintext_bytes)
                .context("Decrypted secret is not valid UTF-8 — corrupt data")
        })
    }

    /// Decrypt using legacy XOR cipher (insecure, for backward compatibility only).
    fn decrypt_legacy_xor(&self, hex_str: &str) -> Result<String> {
        self.require_existing_key()?;
        let ciphertext = hex_decode(hex_str)
            .context("Failed to decode legacy encrypted secret (corrupt hex)")?;

        self.get_key(|key| {
            let plaintext_bytes = xor_cipher(&ciphertext, key);
            String::from_utf8(plaintext_bytes)
                .context("Decrypted legacy secret is not valid UTF-8 — wrong key or corrupt data")
        })
    }

    /// Compute a domain-separated keyed digest with the existing install key.
    ///
    /// Never provisions a key: callers fail closed when none exists. Suits
    /// blind database indexes that must not be enumerable without the
    /// install secret.
    pub fn keyed_digest(&self, domain: &[u8], data: &[u8]) -> Result<[u8; 32]> {
        self.require_existing_key()?;
        self.get_key(|key| keyed_digest_with_key(key, domain, data))
    }

    /// Compute a domain-separated keyed digest, provisioning the install key
    /// when needed for a write that will persist new encrypted material.
    pub fn keyed_digest_or_create(&self, domain: &[u8], data: &[u8]) -> Result<[u8; 32]> {
        self.get_key(|key| keyed_digest_with_key(key, domain, data))
    }

    /// Refuse a read-side key use when no key has been provisioned. Reads
    /// must never mint a replacement: a new key cannot decrypt what the lost
    /// one encrypted, and creating it hides the loss.
    fn require_existing_key(&self) -> Result<()> {
        if self.key_source.provisioning_state() == ProvisioningState::NeedsInitialization {
            anyhow::bail!(
                "No existing `.secret_key` for the '{}' key source; refusing to create a \
                 replacement on a read. Restore the original key material from backup.",
                self.key_source.backend_name()
            );
        }
        Ok(())
    }

    /// Check if a value is already encrypted or externally resolved.
    pub fn is_encrypted(value: &str) -> bool {
        value.starts_with("enc2:") || value.starts_with("enc:") || is_onepassword_ref(value)
    }

    /// Check if a value is a 1Password external secret reference.
    pub fn is_onepassword_ref(value: &str) -> bool {
        is_onepassword_ref(value)
    }

    /// Check if a value uses the secure `enc2:` format.
    pub fn is_secure_encrypted(value: &str) -> bool {
        value.starts_with("enc2:")
    }
}

fn keyed_digest_with_key(key: &[u8], domain: &[u8], data: &[u8]) -> Result<[u8; 32]> {
    let subkey = keyed_digest_subkey(key)?;
    let mut mac = <Hmac<Sha256> as Mac>::new_from_slice(&subkey)
        .map_err(|_| anyhow::Error::msg("Secret key file is corrupt"))?;
    mac.update(KEYED_DIGEST_DOMAIN);
    mac.update(&(domain.len() as u64).to_be_bytes());
    mac.update(domain);
    mac.update(data);
    Ok(mac.finalize().into_bytes().into())
}

/// One-block HKDF-Expand (RFC 5869) of the install key. The key is already
/// 32 uniformly random bytes, so it serves as the pseudorandom key directly
/// and the Extract step is skipped, as RFC 5869 section 3.3 permits.
fn keyed_digest_subkey(key: &[u8]) -> Result<[u8; 32]> {
    let mut mac = <Hmac<Sha256> as Mac>::new_from_slice(key)
        .map_err(|_| anyhow::Error::msg("Secret key file is corrupt"))?;
    mac.update(KEYED_DIGEST_SUBKEY_INFO);
    mac.update(&[1]);
    Ok(mac.finalize().into_bytes().into())
}

// ── Atomic key publication ──────────────────────────────────────
//
// Key creation writes full content to a restrictive-at-creation temp file,
// then publishes it without replacing an existing target:
//   - Android: renameat2(temp, final, RENAME_NOREPLACE). SELinux denies
//     link(2) to apps, even inside their own data directory.
//   - Other Unix: hard_link(temp, final).
//   - Windows: FileRenameInfo on the same exclusive handle.
// The final path either appears with complete content, or not at all.

/// Monotonically increasing counter for unique temp file names
/// within the same process.  Combined with the PID, this guarantees
/// deterministic uniqueness across threads.
static TMP_SEQ: AtomicU64 = AtomicU64::new(0);

/// Produce a unique temp path in the same directory as `key_path`.
///
/// Format: `<key_path>.tmp.<pid>.<seq>.<random:016x>`
///
/// The counter guarantees zero collisions within a process; the PID
/// guarantees uniqueness across local processes; the random u64 hex
/// component protects against PID collisions on shared filesystems
/// (NFS/SMB where two machines may share the same PID space).  Temp
/// files live microseconds (write → fsync → hard_link → remove), so
/// PID-reuse windows are not a concern even without the random component.
fn temp_path_for(key_path: &Path) -> PathBuf {
    let seq = TMP_SEQ.fetch_add(1, Ordering::Relaxed);
    let pid = std::process::id();
    let random: u64 = rand::random();
    key_path.with_extension(format!("tmp.{pid}.{seq}.{random:016x}"))
}

/// RAII guard that removes a temp file on drop unless disarmed.
///
/// Covers every `?` early return AND panics between temp creation and
/// successful publication, so a failed initialization never leaves key
/// material behind or lets a stale PID/sequence name block a later attempt.
#[cfg(unix)]
struct TempFileGuard {
    path: Option<PathBuf>,
}

#[cfg(unix)]
impl TempFileGuard {
    fn new(path: &Path) -> Self {
        TempFileGuard {
            path: Some(path.to_path_buf()),
        }
    }

    /// Call after successful publication so drop does not remove anything:
    /// the temp name was already removed by hand.
    fn disarm(&mut self) {
        self.path = None;
    }
}

#[cfg(unix)]
impl Drop for TempFileGuard {
    fn drop(&mut self) {
        if let Some(p) = &self.path {
            let _ = std::fs::remove_file(p);
        }
    }
}

/// Windows reparse-point attribute bit (symlink / junction / mount point).
#[cfg(windows)]
const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0000_0400;

/// Whether `path` is a symlink (Unix) or reparse point (Windows), checked
/// without following it.  Used on the write path before publication.
///
/// On Windows we test the reparse-point attribute rather than
/// `FileType::is_symlink()`, which only recognises symlinks and would miss
/// junctions / mount points — matching the read-path check in `open_no_follow`
/// so both paths reject the same set of objects.
#[cfg(unix)]
fn is_symlink_like(path: &Path) -> bool {
    fs::symlink_metadata(path)
        .map(|m| m.file_type().is_symlink())
        .unwrap_or(false)
}

#[cfg(windows)]
fn is_symlink_like(path: &Path) -> bool {
    use std::os::windows::fs::MetadataExt;
    fs::symlink_metadata(path)
        .map(|m| m.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0)
        .unwrap_or(false)
}

#[cfg(not(any(unix, windows)))]
fn is_symlink_like(path: &Path) -> bool {
    fs::symlink_metadata(path)
        .map(|m| m.file_type().is_symlink())
        .unwrap_or(false)
}

/// Open `key_path` with platform no-follow / reparse-point semantics so that
/// validation and reading are bound to the *same* object — no check-then-follow
/// window.
// NOTE: do NOT add a module-level `use std::io::Read;` — production code already
// has a function-scoped `use std::io::Read;` (resolve_onepassword_ref); a second
// module-level import triggers clippy `redundant_import` under `-D warnings`.
#[cfg(unix)]
fn open_no_follow(key_path: &Path) -> std::io::Result<std::fs::File> {
    use std::os::unix::fs::OpenOptionsExt;
    // O_NOFOLLOW: if the final path component is a symlink, open() fails with
    // ELOOP.  This binds "not a symlink" to the returned fd atomically.
    std::fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NOFOLLOW)
        .open(key_path)
        .map_err(|e| {
            if e.raw_os_error() == Some(libc::ELOOP) {
                std::io::Error::new(
                    std::io::ErrorKind::InvalidInput,
                    "Key file path is a symlink — refusing to read",
                )
            } else {
                e
            }
        })
}

#[cfg(windows)]
fn open_no_follow(key_path: &Path) -> std::io::Result<std::fs::File> {
    use std::os::windows::fs::{MetadataExt, OpenOptionsExt};
    // FILE_FLAG_OPEN_REPARSE_POINT (0x0020_0000): open the reparse point itself
    // instead of following it.  FILE_FLAG_BACKUP_SEMANTICS (0x0200_0000) lets the
    // call also work if the entry is a directory reparse point.
    const FILE_FLAG_OPEN_REPARSE_POINT: u32 = 0x0020_0000;
    const FILE_FLAG_BACKUP_SEMANTICS: u32 = 0x0200_0000;

    let file = windows_key_file::open_existing_with_retry(|| {
        std::fs::OpenOptions::new()
            .read(true)
            .custom_flags(FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS)
            .open(key_path)
    })?;

    // Inspect the SAME handle we will read from.  If it carries the
    // reparse-point attribute, refuse.
    let attrs = file.metadata()?.file_attributes();
    if attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "Key file path is a reparse point — refusing to read",
        ));
    }
    Ok(file)
}

#[cfg(not(any(unix, windows)))]
fn open_no_follow(_key_path: &Path) -> std::io::Result<std::fs::File> {
    compile_error!(
        "no-follow key reads require platform symlink/reparse-point semantics \
         (O_NOFOLLOW on Unix, reparse-point attribute on Windows); unsupported target"
    );
}

/// Read the key file from a no-follow / reparse-point-verified handle.
///
/// Opening with `open_no_follow` binds the "not a symlink" check to the same
/// object we read from — there is no check-then-follow window.
fn read_key_file_no_follow(key_path: &Path) -> std::io::Result<String> {
    use std::io::Read; // function-scoped — avoids redundant module import
    let mut file = open_no_follow(key_path)?;
    let mut buf = String::new();
    file.read_to_string(&mut buf)?;
    Ok(buf)
}

/// Load the key from `key_path`, creating it if absent.
///
/// Reads go through a no-follow / reparse-point-verified handle.  Creation
/// uses atomic no-replace publication (write-to-temp then `hard_link` on Unix,
/// `renameat2(RENAME_NOREPLACE)` on Android, handle-based no-replace rename on
/// Windows) so readers never observe empty or partial key material.
fn load_or_create_key(key_path: &Path) -> Result<Vec<u8>> {
    let validate_key = |bytes: Vec<u8>| {
        anyhow::ensure!(
            bytes.len() == 32,
            "Key file must contain exactly 32 bytes (got {})",
            bytes.len()
        );
        Ok(bytes)
    };

    match read_key_file_no_follow(key_path) {
        Ok(hex) => validate_key(hex_decode(hex.trim()).context("Secret key file is corrupt")?),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
            let key = generate_random_key();
            match write_key_file_atomic_publish(key_path, &key) {
                Ok(()) => Ok(key),
                Err(write_err) => {
                    // Only recover if another process won the race.
                    // All other failures must propagate so we don't
                    // silently accept a bad key.
                    if !is_already_exists_error(&write_err) {
                        return Err(write_err);
                    }
                    // Genuine race: another process created the file first.
                    // Fall back to reading the winner's key.  Because the
                    // winner used atomic publication, the file content is
                    // guaranteed complete at this point.
                    let hex = read_key_file_no_follow(key_path)
                        .with_context(|| {
                            format!(
                                "Failed to read key file at {} (created by concurrent process); initial publication error: {write_err:#}",
                                key_path.display()
                            )
                        })?;
                    let bytes = hex_decode(hex.trim())
                        .context("Secret key file created by concurrent process is corrupt")?;
                    validate_key(bytes)
                }
            }
        }
        Err(e) => Err(e).context("Failed to read secret key file"),
    }
}

/// Check whether an error chain contains an `AlreadyExists` IO error,
/// indicating that another process won the creation race.
fn is_already_exists_error(err: &anyhow::Error) -> bool {
    err.chain().any(|e| {
        e.downcast_ref::<std::io::Error>()
            .map(|io| io.kind() == std::io::ErrorKind::AlreadyExists)
            .unwrap_or(false)
    })
}

/// Write and sync the complete key before no-replace publication.
/// Windows retains the exclusive, restrictive-at-creation handle through rename.
fn write_key_file_atomic_publish(key_path: &Path, key: &[u8]) -> Result<()> {
    write_key_file_atomic_publish_with(key_path, key, |f, bytes| {
        f.write_all(bytes)?;
        f.flush()?;
        f.sync_all()
    })
}

/// The write-stage callback lets tests fail after partial writes or before sync
/// while exercising production creation, publication, and cleanup.
fn write_key_file_atomic_publish_with<F>(key_path: &Path, key: &[u8], write_fn: F) -> Result<()>
where
    F: FnOnce(&mut std::fs::File, &[u8]) -> std::io::Result<()>,
{
    if let Some(parent) = key_path.parent() {
        fs::create_dir_all(parent)?;
    }
    if is_symlink_like(key_path) {
        anyhow::bail!("Key file path is a symlink — refusing to write");
    }
    let temp_path = temp_path_for(key_path);
    let hex_key = hex_encode(key);

    #[cfg(windows)]
    {
        windows_key_file::write_and_publish_with(&temp_path, key_path, hex_key.as_bytes(), write_fn)
    }

    #[cfg(unix)]
    {
        use std::os::unix::fs::{OpenOptionsExt, PermissionsExt};

        let mut file = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(&temp_path)
            .with_context(|| {
                format!("Failed to create temp key file at {}", temp_path.display())
            })?;
        // Arm only after creation so a collision cannot remove someone else's file.
        let mut temp_guard = TempFileGuard::new(&temp_path);
        write_fn(&mut file, hex_key.as_bytes()).context("Failed to write key data to temp file")?;
        drop(file);

        sync_parent_dir(&temp_path)?;
        let _ = fs::set_permissions(&temp_path, fs::Permissions::from_mode(0o600));

        // The rename moves the temp name away, so nothing is left to remove.
        #[cfg(target_os = "android")]
        {
            match rename_no_replace(&temp_path, key_path) {
                Ok(()) => temp_guard.disarm(),
                Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => {
                    return Err(e).context(
                        "Key file already exists — another process created it concurrently",
                    );
                }
                Err(e) => return Err(e).context("Failed to atomically publish key file"),
            }
            sync_parent_dir(key_path)?;
            Ok(())
        }

        #[cfg(not(target_os = "android"))]
        {
            match std::fs::hard_link(&temp_path, key_path) {
                Ok(()) => {}
                Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => {
                    return Err(e).context(
                        "Key file already exists — another process created it concurrently",
                    );
                }
                Err(e) => return Err(e).context("Failed to atomically publish key file"),
            }
            // Persist the final link before removing the temp inode's other name.
            sync_parent_dir(key_path)?;
            if std::fs::remove_file(&temp_path).is_ok() {
                temp_guard.disarm();
                sync_parent_dir(key_path)?;
            }
            Ok(())
        }
    }

    #[cfg(not(any(unix, windows)))]
    compile_error!("atomic key publication requires a platform no-replace mechanism");
}

/// Rename `src` to `dst`, failing with `AlreadyExists` instead of replacing an
/// existing `dst`. Calls the syscall directly because bionic has no
/// `renameat2` wrapper at every supported API level. A kernel without
/// `RENAME_NOREPLACE` fails (ENOSYS/EINVAL) rather than falling back to a
/// rename that could replace the key.
#[cfg(any(target_os = "android", all(test, target_os = "linux")))]
fn rename_no_replace(src: &Path, dst: &Path) -> std::io::Result<()> {
    use std::ffi::CString;
    use std::os::unix::ffi::OsStrExt;

    let c_path = |p: &Path| {
        CString::new(p.as_os_str().as_bytes())
            .map_err(|_| std::io::Error::new(std::io::ErrorKind::InvalidInput, "path contains NUL"))
    };
    let (src, dst) = (c_path(src)?, c_path(dst)?);
    const RENAME_NOREPLACE: libc::c_uint = 1;
    // SAFETY: both strings are NUL-terminated and outlive the call.
    let result = unsafe {
        libc::syscall(
            libc::SYS_renameat2,
            libc::AT_FDCWD,
            src.as_ptr(),
            libc::AT_FDCWD,
            dst.as_ptr(),
            RENAME_NOREPLACE,
        )
    };
    if result == 0 {
        Ok(())
    } else {
        Err(std::io::Error::last_os_error())
    }
}

/// Sync the parent directory so the new name is crash-durable.
#[cfg(unix)]
fn sync_parent_dir(file_path: &Path) -> Result<()> {
    if let Some(parent) = file_path.parent() {
        std::fs::OpenOptions::new()
            .read(true)
            .open(parent)
            .and_then(|d| d.sync_all())
            .with_context(|| {
                format!(
                    "Failed to sync parent directory '{}' after key publication",
                    parent.display()
                )
            })?;
    }
    Ok(())
}

/// Write `key` as hex to `key_path` — thin wrapper around
/// `write_key_file_atomic_publish` for the `initialize()` path.
fn write_key_file(key_path: &Path, key: &[u8]) -> Result<()> {
    write_key_file_atomic_publish(key_path, key)
}

/// XOR cipher with repeating key. Same function for encrypt and decrypt.
fn xor_cipher(data: &[u8], key: &[u8]) -> Vec<u8> {
    if key.is_empty() {
        return data.to_vec();
    }
    data.iter()
        .enumerate()
        .map(|(i, &b)| b ^ key[i % key.len()])
        .collect()
}

/// Generate a random 256-bit key using the OS CSPRNG.
///
/// Uses `OsRng` (via `getrandom`) directly, providing full 256-bit entropy
/// without the fixed version/variant bits that UUID v4 introduces.
fn generate_random_key() -> Vec<u8> {
    ChaCha20Poly1305::generate_key(&mut OsRng).to_vec()
}

/// Hex-encode bytes to a lowercase hex string.
fn hex_encode(data: &[u8]) -> String {
    let mut s = String::with_capacity(data.len() * 2);
    for b in data {
        use std::fmt::Write;
        let _ = write!(s, "{b:02x}");
    }
    s
}

/// Hex-decode a hex string to bytes.
#[allow(clippy::manual_is_multiple_of)]
fn hex_decode(hex: &str) -> Result<Vec<u8>> {
    if (hex.len() & 1) != 0 {
        anyhow::bail!("Hex string has odd length");
    }
    // Reject non-ASCII up front: valid hex is always ASCII, and this guarantees
    // every byte is a char boundary so the byte-index slicing below cannot panic
    // on a corrupt/tampered ciphertext (it returns the Err the signature promises).
    if !hex.is_ascii() {
        anyhow::bail!("Hex string contains non-ASCII characters");
    }
    (0..hex.len())
        .step_by(2)
        .map(|i| {
            u8::from_str_radix(&hex[i..i + 2], 16)
                .map_err(|e| anyhow::Error::msg(format!("Invalid hex at position {i}: {e}")))
        })
        .collect()
}

fn is_onepassword_ref(value: &str) -> bool {
    value.starts_with("op://")
}

fn validate_onepassword_ref(reference: &str) -> Result<()> {
    let path = reference.strip_prefix("op://").unwrap_or("");
    let mut segments = path.split('/');
    let has_required_segments = (0..3).all(|_| segments.next().is_some_and(|s| !s.is_empty()));
    anyhow::ensure!(
        has_required_segments && segments.all(|segment| !segment.is_empty()),
        "Invalid 1Password reference \"{reference}\". Expected format: op://vault-name/item-name/field-name"
    );
    Ok(())
}

/// Resolve a 1Password secret reference by invoking the `op` CLI.
fn resolve_onepassword_ref(reference: &str) -> Result<String> {
    use std::io::Read;
    use std::process::{Command, Stdio};

    validate_onepassword_ref(reference)?;

    let mut child = Command::new("op")
        .args(["read", reference])
        .stdin(Stdio::null())
        .stderr(Stdio::piped())
        .stdout(Stdio::piped())
        .spawn()
        .map_err(|e| {
            ::zeroclaw_log::record!(
                ERROR,
                ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail)
                    .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                    .with_attrs(::serde_json::json!({"error": e.to_string()})),
                "Failed to run 1Password CLI"
            );
            if e.kind() == std::io::ErrorKind::NotFound {
                anyhow::Error::msg(
                    "1Password CLI (`op`) not found. Install it to use op:// secret references in config."
                )
            } else {
                anyhow::Error::msg(format!("Failed to run 1Password CLI: {e}"))
            }
        })?;

    let mut stdout = child
        .stdout
        .take()
        .context("Failed to capture 1Password CLI stdout")?;
    let mut stderr = child
        .stderr
        .take()
        .context("Failed to capture 1Password CLI stderr")?;
    let stdout_handle = std::thread::spawn(move || {
        let mut output = Vec::new();
        stdout.read_to_end(&mut output).map(|_| output)
    });
    let stderr_handle = std::thread::spawn(move || {
        let mut output = Vec::new();
        stderr.read_to_end(&mut output).map(|_| output)
    });

    let deadline = Instant::now() + ONEPASSWORD_READ_TIMEOUT;
    let status = loop {
        if let Some(status) = child
            .try_wait()
            .context("Failed to poll 1Password CLI process")?
        {
            break status;
        }
        if Instant::now() >= deadline {
            let _ = child.kill();
            let _ = child.wait();
            let _ = stdout_handle.join();
            let _ = stderr_handle.join();
            anyhow::bail!(
                "1Password CLI timed out resolving \"{reference}\" after {}s",
                ONEPASSWORD_READ_TIMEOUT.as_secs()
            );
        }
        std::thread::sleep(Duration::from_millis(25));
    };

    let stdout = stdout_handle
        .join()
        .map_err(|_| anyhow::Error::msg("1Password CLI stdout reader panicked"))?
        .context("Failed to read 1Password CLI stdout")?;
    let stderr = stderr_handle
        .join()
        .map_err(|_| anyhow::Error::msg("1Password CLI stderr reader panicked"))?
        .context("Failed to read 1Password CLI stderr")?;

    if !status.success() {
        let stderr_text = String::from_utf8_lossy(&stderr);
        let hint =
            if stderr_text.contains("not signed in") || stderr_text.contains("session expired") {
                " (hint: run `op signin` first)"
            } else {
                ""
            };
        anyhow::bail!(
            "1Password CLI failed to resolve \"{reference}\": {}{hint}",
            stderr_text.trim()
        );
    }

    let secret = String::from_utf8(stdout)
        .context("1Password CLI returned non-UTF-8 output")?
        .trim_end_matches(&['\r', '\n'][..])
        .to_string();

    anyhow::ensure!(
        !secret.is_empty(),
        "1Password CLI returned empty value for \"{reference}\". Verify the vault/item/field path is correct."
    );

    Ok(secret)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[cfg(unix)]
    use std::ffi::OsString;
    use tempfile::TempDir;

    #[cfg(unix)]
    struct EnvValueGuard {
        key: &'static str,
        previous: Option<OsString>,
    }

    #[cfg(unix)]
    impl EnvValueGuard {
        fn set(key: &'static str, value: impl AsRef<std::ffi::OsStr>) -> Self {
            let previous = std::env::var_os(key);
            // SAFETY: tests that mutate env vars serialize on env_test_lock().
            unsafe { std::env::set_var(key, value) };
            Self { key, previous }
        }
    }

    #[cfg(unix)]
    impl Drop for EnvValueGuard {
        fn drop(&mut self) {
            // SAFETY: tests that mutate env vars serialize on env_test_lock().
            unsafe {
                if let Some(previous) = &self.previous {
                    std::env::set_var(self.key, previous);
                } else {
                    std::env::remove_var(self.key);
                }
            }
        }
    }

    #[cfg(unix)]
    fn write_fake_op(bin_dir: &Path, script: &str) {
        use std::os::unix::fs::PermissionsExt;

        let op_path = bin_dir.join("op");
        fs::write(&op_path, script).expect("write fake op");
        let mut perms = fs::metadata(&op_path).unwrap().permissions();
        perms.set_mode(0o755);
        fs::set_permissions(&op_path, perms).unwrap();
    }

    // ── SecretStore basics ─────────────────────────────────────

    #[test]
    fn decrypt_with_missing_key_fails_without_creating_a_replacement() {
        let source = TempDir::new().unwrap();
        let missing = TempDir::new().unwrap();
        let encrypted = SecretStore::new(source.path(), true)
            .encrypt("preserve-recovery-path")
            .unwrap();
        let store = SecretStore::new(missing.path(), true);

        let error = store
            .decrypt(&encrypted)
            .expect_err("missing install key must fail closed");
        assert!(error.to_string().contains(".secret_key"), "{error}");
        assert!(
            !missing.path().join(".secret_key").exists(),
            "a read failure must not create a replacement key"
        );
    }

    #[test]
    fn keyed_digests_are_stable_domain_separated_and_read_only_by_default() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        assert!(store.keyed_digest(b"owner", b"same").is_err());
        assert!(!tmp.path().join(".secret_key").exists());

        let first = store.keyed_digest_or_create(b"owner", b"same").unwrap();
        assert_eq!(store.keyed_digest(b"owner", b"same").unwrap(), first);
        assert_ne!(store.keyed_digest(b"row", b"same").unwrap(), first);
        assert_ne!(store.keyed_digest(b"owner", b"other").unwrap(), first);
        assert_eq!(
            SecretStore::new(tmp.path(), false)
                .keyed_digest(b"owner", b"same")
                .unwrap(),
            first,
            "blind-index derivation is independent of the plaintext preference"
        );
    }

    #[test]
    fn keyed_digests_use_a_derived_subkey_not_the_install_key() {
        let key = [7_u8; 32];
        let digest = keyed_digest_with_key(&key, b"owner", b"value").unwrap();
        let mut raw = <Hmac<Sha256> as Mac>::new_from_slice(&key).unwrap();
        raw.update(KEYED_DIGEST_DOMAIN);
        raw.update(&5_u64.to_be_bytes());
        raw.update(b"owner");
        raw.update(b"value");
        let raw: [u8; 32] = raw.finalize().into_bytes().into();
        assert_ne!(digest, raw, "the AEAD key must not also key the HMAC");
        assert_ne!(keyed_digest_subkey(&key).unwrap(), key);
    }

    #[test]
    fn wrong_length_secret_key_is_rejected_without_panicking() {
        let tmp = TempDir::new().unwrap();
        fs::write(tmp.path().join(".secret_key"), "00").unwrap();
        let store = SecretStore::new(tmp.path(), true);
        assert!(store.keyed_digest(b"owner", b"value").is_err());
        assert!(store.encrypt("value").is_err());
    }

    #[test]
    fn encrypt_decrypt_roundtrip() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        let secret = "sk-my-secret-api-key-12345";

        let encrypted = store.encrypt(secret).unwrap();
        assert!(encrypted.starts_with("enc2:"), "Should have enc2: prefix");
        assert_ne!(encrypted, secret, "Should not be plaintext");

        let decrypted = store.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, secret, "Roundtrip must preserve original");
    }

    #[test]
    fn encrypt_empty_returns_empty() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        let result = store.encrypt("").unwrap();
        assert_eq!(result, "");
    }

    #[test]
    fn decrypt_plaintext_passthrough() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        // Values without "enc:"/"enc2:" prefix are returned as-is (backward compat)
        let result = store.decrypt("sk-plaintext-key").unwrap();
        assert_eq!(result, "sk-plaintext-key");
    }

    #[test]
    fn disabled_store_returns_plaintext() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), false);
        let result = store.encrypt("sk-secret").unwrap();
        assert_eq!(result, "sk-secret", "Disabled store should not encrypt");
    }

    #[test]
    fn is_encrypted_detects_prefix() {
        assert!(SecretStore::is_encrypted("enc2:aabbcc"));
        assert!(SecretStore::is_encrypted("enc:aabbcc")); // legacy
        assert!(SecretStore::is_encrypted("op://vault/item/field"));
        assert!(!SecretStore::is_encrypted("sk-plaintext"));
        assert!(!SecretStore::is_encrypted(""));
    }

    #[test]
    fn op_reference_invalid_format_fails_before_plaintext_passthrough() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let err = store.decrypt("op://vault-only").unwrap_err().to_string();

        assert!(err.contains("Invalid 1Password reference"));
    }

    #[test]
    fn op_reference_decrypt_and_migrate_does_not_migrate_or_pass_through() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let err = store
            .decrypt_and_migrate("op://vault-only")
            .unwrap_err()
            .to_string();

        assert!(err.contains("Invalid 1Password reference"));
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn op_reference_drains_stderr_while_waiting() {
        let _guard = crate::env_overrides::env_test_lock().await;
        let tmp = TempDir::new().unwrap();
        let bin_dir = tmp.path().join("bin");
        fs::create_dir_all(&bin_dir).unwrap();
        write_fake_op(
            &bin_dir,
            r#"#!/bin/sh
if [ "$1" = "read" ] && [ "$2" = "op://vault/item/field" ]; then
  yes diagnostic-line >&2 &
  spam_pid=$!
  sleep 1
  kill "$spam_pid"
  wait "$spam_pid" 2>/dev/null
  printf '%s\n' 'secret-from-op'
  exit 0
fi
exit 65
"#,
        );
        let path = match std::env::var_os("PATH") {
            Some(existing) if !existing.is_empty() => {
                format!("{}:{}", bin_dir.display(), existing.to_string_lossy())
            }
            _ => bin_dir.display().to_string(),
        };
        let _path_guard = EnvValueGuard::set("PATH", path);
        let store = SecretStore::new(tmp.path(), true);

        let secret = store.decrypt("op://vault/item/field").unwrap();

        assert_eq!(secret, "secret-from-op");
    }

    #[tokio::test]
    async fn key_file_created_on_first_encrypt() {
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        assert!(!key_path.exists());

        let store = SecretStore::new(tmp.path(), true);
        store.encrypt("test").unwrap();
        assert!(
            key_path.exists(),
            "Key file should be created via SecretStore::encrypt"
        );

        let key_hex = tokio::fs::read_to_string(&key_path).await.unwrap();
        assert_eq!(
            key_hex.len(),
            KEY_LEN * 2,
            "Key should be {} bytes hex-encoded",
            KEY_LEN
        );
    }

    #[test]
    fn encrypting_same_value_produces_different_ciphertext() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let e1 = store.encrypt("secret").unwrap();
        let e2 = store.encrypt("secret").unwrap();
        assert_ne!(
            e1, e2,
            "AEAD with random nonce should produce different ciphertext each time"
        );

        // Both should still decrypt to the same value
        assert_eq!(store.decrypt(&e1).unwrap(), "secret");
        assert_eq!(store.decrypt(&e2).unwrap(), "secret");
    }

    #[test]
    fn different_stores_same_dir_interop() {
        let tmp = TempDir::new().unwrap();
        let store1 = SecretStore::new(tmp.path(), true);
        let store2 = SecretStore::new(tmp.path(), true);

        let encrypted = store1.encrypt("cross-store-secret").unwrap();
        let decrypted = store2.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, "cross-store-secret");
    }

    #[test]
    fn unicode_secret_roundtrip() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        let secret = "sk-日本語テスト-émojis-🦀";

        let encrypted = store.encrypt(secret).unwrap();
        let decrypted = store.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, secret);
    }

    #[test]
    fn long_secret_roundtrip() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        let secret = "a".repeat(10_000);

        let encrypted = store.encrypt(&secret).unwrap();
        let decrypted = store.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, secret);
    }

    #[test]
    fn corrupt_hex_returns_error() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        let result = store.decrypt("enc2:not-valid-hex!!");
        assert!(result.is_err());
    }

    #[test]
    fn tampered_ciphertext_detected() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        let encrypted = store.encrypt("sensitive-data").unwrap();

        // Flip a bit in the ciphertext (after the "enc2:" prefix)
        let hex_str = &encrypted[5..];
        let mut blob = hex_decode(hex_str).unwrap();
        // Modify a byte in the ciphertext portion (after the 12-byte nonce)
        if blob.len() > NONCE_LEN {
            blob[NONCE_LEN] ^= 0xff;
        }
        let tampered = format!("enc2:{}", hex_encode(&blob));

        let result = store.decrypt(&tampered);
        assert!(result.is_err(), "Tampered ciphertext must be rejected");
    }

    #[test]
    fn wrong_key_detected() {
        let tmp1 = TempDir::new().unwrap();
        let tmp2 = TempDir::new().unwrap();
        let store1 = SecretStore::new(tmp1.path(), true);
        let store2 = SecretStore::new(tmp2.path(), true);

        let encrypted = store1.encrypt("secret-for-store1").unwrap();
        let result = store2.decrypt(&encrypted);
        assert!(result.is_err(), "Decrypting with a different key must fail");
    }

    #[test]
    fn decrypt_error_message_mentions_backend() {
        // Operators hitting a missing or mismatched key (volume wipe, container
        // migration, backup-restore) need the error message to point at the
        // root cause — the active key-source backend.
        let tmp1 = TempDir::new().unwrap();
        let tmp2 = TempDir::new().unwrap();
        let store1 = SecretStore::new(tmp1.path(), true);
        let store2 = SecretStore::new(tmp2.path(), true);

        let encrypted = store1.encrypt("secret-for-store1").unwrap();
        let err = store2.decrypt(&encrypted).expect_err("wrong key must fail");
        let msg = err.to_string();
        assert!(
            msg.contains("'file'"),
            "decrypt error must mention the active backend name so operators \
             can diagnose missing/mismatched keys: got {msg:?}"
        );
    }

    #[test]
    fn truncated_ciphertext_returns_error() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        // Only a few bytes — shorter than nonce
        let result = store.decrypt("enc2:aabbccdd");
        assert!(result.is_err(), "Too-short ciphertext must be rejected");
    }

    // ── Legacy XOR backward compatibility ───────────────────────

    #[test]
    fn legacy_xor_decrypt_still_works() {
        let tmp = TempDir::new().unwrap();
        let fs = FileKeySource::new(tmp.path().join(".secret_key"));
        // Trigger key creation
        fs.with_key(&mut |_| Ok(())).unwrap();
        // Read the raw key to manually build a legacy ciphertext
        let key_bytes: Vec<u8> = {
            let mut k = Vec::new();
            fs.with_key(&mut |key| {
                k = key.to_vec();
                Ok(())
            })
            .unwrap();
            k
        };
        let store = SecretStore::from_key_source(Arc::new(fs), true);

        // Manually produce a legacy XOR-encrypted value
        let plaintext = "sk-legacy-api-key";
        let ciphertext = xor_cipher(plaintext.as_bytes(), &key_bytes);
        let legacy_value = format!("enc:{}", hex_encode(&ciphertext));

        // Store should still be able to decrypt legacy values
        let decrypted = store.decrypt(&legacy_value).unwrap();
        assert_eq!(decrypted, plaintext, "Legacy XOR values must still decrypt");
    }

    // ── Migration tests ─────────────────────────────────────────

    #[test]
    fn needs_migration_detects_legacy_prefix() {
        assert!(SecretStore::needs_migration("enc:aabbcc"));
        assert!(!SecretStore::needs_migration("enc2:aabbcc"));
        assert!(!SecretStore::needs_migration("sk-plaintext"));
        assert!(!SecretStore::needs_migration(""));
    }

    #[test]
    fn is_secure_encrypted_detects_enc2_only() {
        assert!(SecretStore::is_secure_encrypted("enc2:aabbcc"));
        assert!(!SecretStore::is_secure_encrypted("enc:aabbcc"));
        assert!(!SecretStore::is_secure_encrypted("sk-plaintext"));
        assert!(!SecretStore::is_secure_encrypted(""));
    }

    #[test]
    fn decrypt_and_migrate_returns_none_for_enc2() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let encrypted = store.encrypt("my-secret").unwrap();
        assert!(encrypted.starts_with("enc2:"));

        let (plaintext, migrated) = store.decrypt_and_migrate(&encrypted).unwrap();
        assert_eq!(plaintext, "my-secret");
        assert!(
            migrated.is_none(),
            "enc2: values should not trigger migration"
        );
    }

    #[test]
    fn decrypt_and_migrate_returns_none_for_plaintext() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let (plaintext, migrated) = store.decrypt_and_migrate("sk-plaintext-key").unwrap();
        assert_eq!(plaintext, "sk-plaintext-key");
        assert!(
            migrated.is_none(),
            "Plaintext values should not trigger migration"
        );
    }

    #[test]
    fn decrypt_and_migrate_upgrades_legacy_xor() {
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        let fs = FileKeySource::new(key_path);
        // Ensure key material exists (auto-create via with_key).
        let raw_key: Vec<u8> = {
            let mut k = Vec::new();
            fs.with_key(&mut |key| {
                k = key.to_vec();
                Ok(())
            })
            .unwrap();
            k
        };
        let store = SecretStore::from_key_source(Arc::new(fs), true);
        let key = raw_key;

        // Manually create a legacy XOR-encrypted value
        let plaintext = "sk-legacy-secret-to-migrate";
        let ciphertext = xor_cipher(plaintext.as_bytes(), &key);
        let legacy_value = format!("enc:{}", hex_encode(&ciphertext));

        // Verify it needs migration
        assert!(SecretStore::needs_migration(&legacy_value));

        // Decrypt and migrate
        let (decrypted, migrated) = store.decrypt_and_migrate(&legacy_value).unwrap();
        assert_eq!(decrypted, plaintext, "Plaintext must match original");
        assert!(migrated.is_some(), "Legacy value should trigger migration");

        let new_value = migrated.unwrap();
        assert!(
            new_value.starts_with("enc2:"),
            "Migrated value must use enc2: prefix"
        );
        assert!(
            !SecretStore::needs_migration(&new_value),
            "Migrated value should not need migration"
        );

        // Verify the migrated value decrypts correctly
        let (decrypted2, migrated2) = store.decrypt_and_migrate(&new_value).unwrap();
        assert_eq!(
            decrypted2, plaintext,
            "Migrated value must decrypt to same plaintext"
        );
        assert!(
            migrated2.is_none(),
            "Migrated value should not trigger another migration"
        );
    }

    #[test]
    fn decrypt_and_migrate_handles_unicode() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let _ = store.encrypt("setup").unwrap();
        let key = store.with_test_key(|k| k.to_vec());

        let plaintext = "sk-日本語-émojis-🦀-тест";
        let ciphertext = xor_cipher(plaintext.as_bytes(), &key);
        let legacy_value = format!("enc:{}", hex_encode(&ciphertext));

        let (decrypted, migrated) = store.decrypt_and_migrate(&legacy_value).unwrap();
        assert_eq!(decrypted, plaintext);
        assert!(migrated.is_some());

        // Verify migrated value works
        let new_value = migrated.unwrap();
        let (decrypted2, _) = store.decrypt_and_migrate(&new_value).unwrap();
        assert_eq!(decrypted2, plaintext);
    }

    #[test]
    fn decrypt_and_migrate_handles_empty_secret() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let _ = store.encrypt("setup").unwrap();
        let key = store.with_test_key(|k| k.to_vec());

        // Empty plaintext XOR-encrypted
        let plaintext = "";
        let ciphertext = xor_cipher(plaintext.as_bytes(), &key);
        let legacy_value = format!("enc:{}", hex_encode(&ciphertext));

        let (decrypted, migrated) = store.decrypt_and_migrate(&legacy_value).unwrap();
        assert_eq!(decrypted, plaintext);
        // Empty string encryption returns empty string (not enc2:)
        assert!(migrated.is_some());
        assert_eq!(migrated.unwrap(), "");
    }

    #[test]
    fn decrypt_and_migrate_handles_long_secret() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let _ = store.encrypt("setup").unwrap();
        let key = store.with_test_key(|k| k.to_vec());

        let plaintext = "a".repeat(10_000);
        let ciphertext = xor_cipher(plaintext.as_bytes(), &key);
        let legacy_value = format!("enc:{}", hex_encode(&ciphertext));

        let (decrypted, migrated) = store.decrypt_and_migrate(&legacy_value).unwrap();
        assert_eq!(decrypted, plaintext);
        assert!(migrated.is_some());

        let new_value = migrated.unwrap();
        let (decrypted2, _) = store.decrypt_and_migrate(&new_value).unwrap();
        assert_eq!(decrypted2, plaintext);
    }

    #[test]
    fn decrypt_and_migrate_fails_on_corrupt_legacy_hex() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        let _ = store.encrypt("setup").unwrap();

        let result = store.decrypt_and_migrate("enc:not-valid-hex!!");
        assert!(result.is_err(), "Corrupt hex should fail");
    }

    #[test]
    fn decrypt_and_migrate_wrong_key_produces_garbage_or_fails() {
        let tmp1 = TempDir::new().unwrap();
        let tmp2 = TempDir::new().unwrap();
        let store1 = SecretStore::new(tmp1.path(), true);
        let store2 = SecretStore::new(tmp2.path(), true);

        // Create keys for both stores
        let _ = store1.encrypt("setup").unwrap();
        let _ = store2.encrypt("setup").unwrap();
        let key1 = store1.with_test_key(|k| k.to_vec());

        // Encrypt with store1's key
        let plaintext = "secret-for-store1";
        let ciphertext = xor_cipher(plaintext.as_bytes(), &key1);
        let legacy_value = format!("enc:{}", hex_encode(&ciphertext));

        // Decrypt with store2 — XOR will produce garbage bytes
        // This may fail with UTF-8 error or succeed with garbage plaintext
        match store2.decrypt_and_migrate(&legacy_value) {
            Ok((decrypted, _)) => {
                // If it succeeds, the plaintext should be garbage (not the original)
                assert_ne!(
                    decrypted, plaintext,
                    "Wrong key should produce garbage plaintext"
                );
            }
            Err(e) => {
                // Expected: UTF-8 decoding failure from garbage bytes
                assert!(
                    e.to_string().contains("UTF-8"),
                    "Error should be UTF-8 related: {e}"
                );
            }
        }
    }

    #[test]
    fn migration_produces_different_ciphertext_each_time() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let _ = store.encrypt("setup").unwrap();
        let key = store.with_test_key(|k| k.to_vec());

        let plaintext = "sk-same-secret";
        let ciphertext = xor_cipher(plaintext.as_bytes(), &key);
        let legacy_value = format!("enc:{}", hex_encode(&ciphertext));

        let (_, migrated1) = store.decrypt_and_migrate(&legacy_value).unwrap();
        let (_, migrated2) = store.decrypt_and_migrate(&legacy_value).unwrap();

        assert!(migrated1.is_some());
        assert!(migrated2.is_some());
        assert_ne!(
            migrated1.unwrap(),
            migrated2.unwrap(),
            "Each migration should produce different ciphertext (random nonce)"
        );
    }

    #[test]
    fn migrated_value_is_tamper_resistant() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);

        let _ = store.encrypt("setup").unwrap();
        let key = store.with_test_key(|k| k.to_vec());

        let plaintext = "sk-sensitive-data";
        let ciphertext = xor_cipher(plaintext.as_bytes(), &key);
        let legacy_value = format!("enc:{}", hex_encode(&ciphertext));

        let (_, migrated) = store.decrypt_and_migrate(&legacy_value).unwrap();
        let new_value = migrated.unwrap();

        // Tamper with the migrated value
        let hex_str = &new_value[5..];
        let mut blob = hex_decode(hex_str).unwrap();
        if blob.len() > NONCE_LEN {
            blob[NONCE_LEN] ^= 0xff;
        }
        let tampered = format!("enc2:{}", hex_encode(&blob));

        let result = store.decrypt_and_migrate(&tampered);
        assert!(result.is_err(), "Tampered migrated value must be rejected");
    }

    // ── Low-level helpers ───────────────────────────────────────

    #[test]
    fn xor_cipher_roundtrip() {
        let key = b"testkey123";
        let data = b"hello world";
        let encrypted = xor_cipher(data, key);
        let decrypted = xor_cipher(&encrypted, key);
        assert_eq!(decrypted, data);
    }

    #[test]
    fn xor_cipher_empty_key() {
        let data = b"passthrough";
        let result = xor_cipher(data, &[]);
        assert_eq!(result, data);
    }

    #[test]
    fn hex_roundtrip() {
        let data = vec![0x00, 0x01, 0xfe, 0xff, 0xab, 0xcd];
        let encoded = hex_encode(&data);
        assert_eq!(encoded, "0001feffabcd");
        let decoded = hex_decode(&encoded).unwrap();
        assert_eq!(decoded, data);
    }

    #[test]
    fn hex_decode_odd_length_fails() {
        assert!(hex_decode("abc").is_err());
    }

    #[test]
    fn hex_decode_invalid_chars_fails() {
        assert!(hex_decode("zzzz").is_err());
    }

    #[test]
    fn hex_decode_non_ascii_returns_error() {
        // A corrupt/tampered ciphertext with even *byte* length made of
        // non-ASCII chars previously slipped past the odd-length check and
        // panicked on mid-UTF-8-char byte slicing. It must now return Err
        // gracefully (the signature's promise). "€€" is 6 bytes.
        assert!(hex_decode("€€").is_err());
        // Non-ASCII that is a whole 2-byte char also errors, not panics.
        assert!(hex_decode("ÿÿ").is_err());
    }

    #[test]
    fn generate_random_key_correct_length() {
        let key = generate_random_key();
        assert_eq!(key.len(), KEY_LEN);
    }

    #[test]
    fn generate_random_key_not_all_zeros() {
        let key = generate_random_key();
        assert!(key.iter().any(|&b| b != 0), "Key should not be all zeros");
    }

    #[test]
    fn two_random_keys_differ() {
        let k1 = generate_random_key();
        let k2 = generate_random_key();
        assert_ne!(k1, k2, "Two random keys should differ");
    }

    #[test]
    fn generate_random_key_has_no_uuid_fixed_bits() {
        // UUID v4 has fixed bits at positions 6 (version = 0b0100xxxx) and
        // 8 (variant = 0b10xxxxxx). A direct CSPRNG key should not consistently
        // have these patterns across multiple samples.
        let mut version_match = 0;
        let mut variant_match = 0;
        let samples = 100;
        for _ in 0..samples {
            let key = generate_random_key();
            // In UUID v4, byte 6 always has top nibble = 0x4
            if key[6] & 0xf0 == 0x40 {
                version_match += 1;
            }
            // In UUID v4, byte 8 always has top 2 bits = 0b10
            if key[8] & 0xc0 == 0x80 {
                variant_match += 1;
            }
        }
        // With true randomness, each pattern should appear ~1/16 and ~1/4 of
        // the time. UUID would hit 100/100 on both. Allow generous margin.
        assert!(
            version_match < 30,
            "byte[6] matched UUID v4 version nibble {version_match}/100 times — \
             likely still using UUID-based key generation"
        );
        assert!(
            variant_match < 50,
            "byte[8] matched UUID v4 variant bits {variant_match}/100 times — \
             likely still using UUID-based key generation"
        );
    }

    #[cfg(unix)]
    #[test]
    fn key_file_has_restricted_permissions() {
        use std::os::unix::fs::PermissionsExt;
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        let fs = FileKeySource::new(key_path.clone());
        // Trigger key creation via with_key (auto-create).
        fs.with_key(&mut |_| Ok(())).unwrap();

        let perms = fs::metadata(&key_path).unwrap().permissions();
        assert_eq!(
            perms.mode() & 0o777,
            0o600,
            "Key file must be owner-only (0600)"
        );
    }

    // ── Atomic initialization ─────────────────────────────────

    #[test]
    fn initialize_refuses_existing_file() {
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        fs::write(&key_path, b"existing").unwrap();

        let fs = FileKeySource::new(key_path);
        let err = fs.initialize().unwrap_err().to_string();
        assert!(
            err.contains("already exists"),
            "initialize must refuse to overwrite existing key file: {err}"
        );
    }

    #[cfg(unix)]
    #[test]
    fn initialize_refuses_symlink() {
        use std::os::unix::fs as unix_fs;
        let tmp = TempDir::new().unwrap();
        let target = tmp.path().join("real-key");
        let link = tmp.path().join(".secret_key");
        fs::write(&target, b"real-key-data").unwrap();
        unix_fs::symlink(&target, &link).unwrap();

        let fs = FileKeySource::new(link);
        let err = fs.initialize().unwrap_err().to_string();
        assert!(
            err.contains("symlink"),
            "initialize must refuse symlink paths: {err}"
        );
    }

    #[test]
    fn provisioning_state_initialized_when_key_file_present() {
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        let fs = FileKeySource::new(key_path.clone());
        assert_eq!(
            fs.provisioning_state(),
            ProvisioningState::NeedsInitialization,
            "No key file yet"
        );
        // Create the key file via initialize.
        fs.initialize().unwrap();
        assert_eq!(
            fs.provisioning_state(),
            ProvisioningState::Initialized,
            "Key file now exists"
        );
    }

    #[test]
    fn provisioning_state_default_is_needs_initialization() {
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join("nonexistent").join(".secret_key");
        let fs = FileKeySource::new(key_path);
        assert_eq!(
            fs.provisioning_state(),
            ProvisioningState::NeedsInitialization
        );
    }

    #[test]
    fn key_file_wrong_length_rejected() {
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        // Write only 16 bytes (half the required 32).
        fs::write(&key_path, hex_encode(&[0u8; 16])).unwrap();
        let err = load_or_create_key(&key_path).unwrap_err().to_string();
        assert!(
            err.contains("must contain exactly 32 bytes"),
            "Wrong-length key file must be rejected: {err}"
        );
    }

    #[test]
    fn key_file_too_long_rejected() {
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        // Write 64 bytes (twice the required 32).
        fs::write(&key_path, hex_encode(&[0u8; 64])).unwrap();
        let err = load_or_create_key(&key_path).unwrap_err().to_string();
        assert!(
            err.contains("must contain exactly 32 bytes"),
            "Too-long key file must be rejected: {err}"
        );
    }

    #[test]
    fn load_or_create_detects_genuine_race() {
        // When the key file is created by another process between our
        // NotFound check and our O_EXCL attempt, we must fall back to
        // reading the winner's key — not fail.
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");

        // Pre-create the key file (simulating another process winning the race).
        let winner_key = generate_random_key();
        fs::write(&key_path, hex_encode(&winner_key)).unwrap();

        // load_or_create_key should detect the race and read the winner's key.
        let loaded = load_or_create_key(&key_path).unwrap();
        assert_eq!(loaded, winner_key);
    }

    #[test]
    fn load_or_create_key_fails_on_non_race_write_error() {
        // A non-race write failure (e.g., permission denied on parent dir)
        // must fail-closed, not fall through to reading the key file.
        let tmp = TempDir::new().unwrap();
        // Point at a path whose parent is a regular file, not a directory.
        // create_dir_all will fail because "parent" is a file.
        let parent_file = tmp.path().join("not-a-directory");
        fs::write(&parent_file, b"block").unwrap();
        let key_path = parent_file.join(".secret_key");

        let result = load_or_create_key(&key_path);
        assert!(
            result.is_err(),
            "Non-race write errors must fail-closed, got: {result:?}"
        );
    }

    #[cfg(unix)]
    #[test]
    fn load_or_create_refuses_symlink_on_race_fallback() {
        // When the key file is a symlink (and the target does not exist),
        // fs::read_to_string returns NotFound, write_key_file detects the
        // symlink and refuses. load_or_create_key must propagate that
        // refusal — not fall through to read.
        use std::os::unix::fs as unix_fs;
        let tmp = TempDir::new().unwrap();
        let target = tmp.path().join("nonexistent-target");
        let link = tmp.path().join(".secret_key");
        // Symlink to a non-existent target → read_to_string → NotFound.
        unix_fs::symlink(&target, &link).unwrap();

        let result = load_or_create_key(&link);
        assert!(
            result.is_err(),
            "Symlink refusal must not fall through to read path: {result:?}"
        );
    }

    #[cfg(unix)]
    #[test]
    fn write_key_file_creates_with_restrictive_mode_at_birth() {
        // On Unix, the file must have 0o600 from the moment of creation,
        // before set_permissions runs as hardening.
        use std::os::unix::fs::PermissionsExt;
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");

        // Use a fresh file — no race.
        let key = generate_random_key();
        write_key_file(&key_path, &key).unwrap();

        let perms = fs::metadata(&key_path).unwrap().permissions();
        assert_eq!(
            perms.mode() & 0o777,
            0o600,
            "Key file must be 0o600 immediately after write_key_file returns"
        );
    }

    // Smoke-test: sync_parent_dir on a live key file must not error.
    #[test]
    #[cfg(unix)]
    fn sync_parent_dir_smoke() {
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        let key = generate_random_key();
        write_key_file(&key_path, &key).unwrap();
        // Already called during publication; exercise helper directly.
        sync_parent_dir(&key_path).unwrap();
    }

    // Android publishes the key with this rename; Linux runs the same syscall.
    #[test]
    #[cfg(target_os = "linux")]
    fn rename_no_replace_publishes_once_and_never_replaces() {
        let tmp = TempDir::new().unwrap();
        let (first, second, key_path) = (
            tmp.path().join("first"),
            tmp.path().join("second"),
            tmp.path().join(".secret_key"),
        );
        fs::write(&first, "winner").unwrap();
        fs::write(&second, "loser").unwrap();

        rename_no_replace(&first, &key_path).unwrap();
        let err = rename_no_replace(&second, &key_path).unwrap_err();

        assert_eq!(err.kind(), std::io::ErrorKind::AlreadyExists);
        assert_eq!(fs::read_to_string(&key_path).unwrap(), "winner");
        assert!(!first.exists());
        assert!(second.exists());
    }

    // ── Symlink rejection on read paths ──────────────────────

    #[cfg(unix)]
    #[test]
    fn read_key_file_rejects_valid_symlink() {
        // A valid symlink pointing to a legitimate key file must still
        // be rejected — the no-symlink invariant applies to every
        // code path that accepts key bytes.
        use std::os::unix::fs as unix_fs;
        let tmp = TempDir::new().unwrap();
        let target = tmp.path().join("real-key");
        let link = tmp.path().join(".secret_key");
        // Create a valid key file at the target.
        let key = generate_random_key();
        fs::write(&target, hex_encode(&key)).unwrap();
        unix_fs::symlink(&target, &link).unwrap();

        // Reading through the symlink must fail.
        let result = load_or_create_key(&link);
        assert!(
            result.is_err(),
            "Valid symlink on read path must be rejected: {result:?}"
        );
    }

    #[cfg(unix)]
    #[test]
    fn provisioning_state_rejects_symlink() {
        // provisioning_state must not report a symlink as Initialized.
        use std::os::unix::fs as unix_fs;
        let tmp = TempDir::new().unwrap();
        let target = tmp.path().join("real-key");
        let link = tmp.path().join(".secret_key");
        fs::write(&target, hex_encode(&generate_random_key())).unwrap();
        unix_fs::symlink(&target, &link).unwrap();

        let fs = FileKeySource::new(link);
        assert_eq!(
            fs.provisioning_state(),
            ProvisioningState::NeedsInitialization,
            "Symlink must not be reported as Initialized"
        );
    }

    // ── Temp-file guard cleanup & no-follow open boundary ──

    /// True iff no `.tmp.` entry remains in `dir`.
    #[cfg(test)]
    pub(super) fn no_temp_residue(dir: &Path) -> bool {
        fs::read_dir(dir)
            .unwrap()
            .filter_map(|e| e.ok())
            .all(|e| !e.file_name().to_string_lossy().contains(".tmp."))
    }

    #[test]
    fn temp_file_removed_on_write_failure() {
        // Exercise the production temp-file owner and cleanup on each platform.
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        let err =
            write_key_file_atomic_publish_with(&key_path, &generate_random_key(), |_f, _b| {
                Err(std::io::Error::other("injected write failure"))
            })
            .unwrap_err();
        assert!(
            err.to_string()
                .contains("Failed to write key data to temp file"),
            "write failure must propagate with context: {err:?}"
        );
        assert!(
            no_temp_residue(tmp.path()),
            "temp key file leaked after write failure"
        );
        assert!(
            !key_path.exists(),
            "final key must not exist on write failure"
        );
    }

    #[test]
    fn temp_file_removed_after_partial_write_or_sync_failure() {
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        let key = generate_random_key();

        // Case A — fail after a partial write (泄漏点 1: partial hex residue).
        let err = write_key_file_atomic_publish_with(&key_path, &key, |f, bytes| {
            use std::io::Write;
            let half = bytes.len() / 2;
            f.write_all(&bytes[..half])?;
            Err(std::io::Error::other("injected partial-write failure"))
        })
        .unwrap_err();
        assert!(
            err.to_string()
                .contains("Failed to write key data to temp file")
        );
        assert!(
            no_temp_residue(tmp.path()),
            "temp leaked after partial write"
        );
        assert!(!key_path.exists());

        // Case B — fail after a full write + flush (泄漏点 2/3: sync failure).
        let err = write_key_file_atomic_publish_with(&key_path, &key, |f, bytes| {
            use std::io::Write;
            f.write_all(bytes)?;
            f.flush()?;
            Err(std::io::Error::other("injected sync failure"))
        })
        .unwrap_err();
        assert!(
            err.to_string()
                .contains("Failed to write key data to temp file")
        );
        assert!(
            no_temp_residue(tmp.path()),
            "temp leaked after sync failure"
        );
        assert!(!key_path.exists());
    }

    #[test]
    fn temp_file_disarmed_on_success() {
        // Happy path: real write stage succeeds, publication happens, and no
        // `.tmp.*` residue remains.
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        write_key_file_atomic_publish(&key_path, &generate_random_key()).unwrap();
        assert!(key_path.exists(), "final key must be published on success");
        assert!(no_temp_residue(tmp.path()), "temp not cleaned on success");
    }

    #[cfg(unix)]
    #[test]
    fn open_no_follow_rejects_symlink_deterministically() {
        // O_NOFOLLOW must reject at open() — deterministic, no race needed.
        use std::os::unix::fs as unix_fs;
        let tmp = TempDir::new().unwrap();
        let target = tmp.path().join("real-key");
        let link = tmp.path().join(".secret_key");
        fs::write(&target, hex_encode(&generate_random_key())).unwrap();
        unix_fs::symlink(&target, &link).unwrap();

        let err = read_key_file_no_follow(&link).unwrap_err();
        assert_eq!(err.kind(), std::io::ErrorKind::InvalidInput);
        // A regular file must still read fine (no false positive).
        assert!(read_key_file_no_follow(&target).is_ok());
    }

    #[cfg(unix)]
    #[test]
    fn no_follow_open_binds_check_and_read() {
        // Worst case: the path is already a symlink at open time.  A
        // check-then-follow implementation could still read the target; a
        // no-follow open cannot.
        use std::os::unix::fs as unix_fs;
        let tmp = TempDir::new().unwrap();
        let attacker = tmp.path().join("attacker-key");
        fs::write(&attacker, hex_encode(&generate_random_key())).unwrap();
        let path = tmp.path().join(".secret_key");
        unix_fs::symlink(&attacker, &path).unwrap();

        let result = load_or_create_key(&path);
        assert!(
            result.is_err(),
            "no-follow open must refuse the symlink, never read the attacker target: {result:?}"
        );
    }

    // ── Concurrent key creation safety ────────────────────────

    #[test]
    fn concurrent_load_or_create_never_observes_partial_key() {
        // Multiple threads racing on first key creation must all
        // receive the same complete key.  No thread may observe
        // empty or partial key material.
        use std::sync::Barrier;
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");

        // Ensure the file does not exist before the race.
        assert!(!key_path.exists());

        let barrier = Arc::new(Barrier::new(4));
        let mut handles = Vec::new();

        for _ in 0..4 {
            let kp = key_path.clone();
            let b = Arc::clone(&barrier);
            handles.push(std::thread::spawn(move || {
                // Synchronise so all threads enter load_or_create_key
                // at roughly the same time.
                b.wait();
                load_or_create_key(&kp).unwrap()
            }));
        }

        let keys: Vec<Vec<u8>> = handles.into_iter().map(|h| h.join().unwrap()).collect();

        // All threads must receive the same key.
        let first = &keys[0];
        for (i, k) in keys.iter().enumerate().skip(1) {
            assert_eq!(
                k, first,
                "Thread {i} got a different key — race produced divergent key material"
            );
        }
        assert_eq!(first.len(), 32, "Key must be exactly 32 bytes");
    }

    #[test]
    fn concurrent_load_or_create_with_existing_file() {
        // Same as above but the file already exists — all threads
        // must read the same existing key without corruption.
        use std::sync::Barrier;
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");

        // Pre-create with a known key.
        let existing_key = generate_random_key();
        fs::write(&key_path, hex_encode(&existing_key)).unwrap();

        let barrier = Arc::new(Barrier::new(4));
        let mut handles = Vec::new();

        for _ in 0..4 {
            let kp = key_path.clone();
            let b = Arc::clone(&barrier);
            handles.push(std::thread::spawn(move || {
                b.wait();
                load_or_create_key(&kp).unwrap()
            }));
        }

        let keys: Vec<Vec<u8>> = handles.into_iter().map(|h| h.join().unwrap()).collect();

        for k in &keys {
            assert_eq!(
                *k, existing_key,
                "All threads must read the same existing key"
            );
        }
    }

    // ── Clone-sharing ────────────────────────────────────────

    #[test]
    fn cloned_store_shares_key_source() {
        let tmp = TempDir::new().unwrap();
        let store1 = SecretStore::new(tmp.path(), true);
        let store2 = store1.clone();

        // Arc::ptr_eq proves the clone shares the SAME allocation,
        // not just that two independent FileKeySource instances
        // happen to read the same file. This matters for future
        // stateful backends (HSM sessions, KMS connection pools).
        assert!(
            store1.key_source_ptr_eq(&store2),
            "Cloned stores must share the same Arc<dyn KeySource> instance"
        );
    }

    #[test]
    fn independent_stores_have_distinct_key_sources() {
        let tmp = TempDir::new().unwrap();
        let store1 = SecretStore::new(tmp.path(), true);
        let store2 = SecretStore::new(tmp.path(), true);

        // Even though they read the same file, the Arc instances are distinct.
        assert!(
            !store1.key_source_ptr_eq(&store2),
            "Independently created stores must have distinct Arc instances"
        );
    }

    // ── Error diagnosis ──────────────────────────────────────

    #[test]
    fn decrypt_error_message_mentions_tampered_ciphertext() {
        let tmp1 = TempDir::new().unwrap();
        let tmp2 = TempDir::new().unwrap();
        let store1 = SecretStore::new(tmp1.path(), true);
        let store2 = SecretStore::new(tmp2.path(), true);
        // Give store2 its own key: a missing key fails earlier, as a missing
        // key rather than as a wrong one.
        store2.encrypt("provision-store2-key").unwrap();

        let encrypted = store1.encrypt("secret-for-store1").unwrap();
        let err = store2.decrypt(&encrypted).expect_err("wrong key must fail");
        let msg = err.to_string();
        assert!(
            msg.contains("tampered ciphertext"),
            "decrypt error must mention tampered ciphertext as possible cause: {msg}"
        );
    }

    // ── get_key callback contract enforcement ────────────────

    /// A test-only KeySource that never calls the callback.
    #[derive(Debug)]
    struct ZeroCallKeySource;

    impl KeySource for ZeroCallKeySource {
        fn with_key(&self, _f: &mut dyn FnMut(&[u8; 32]) -> Result<()>) -> Result<()> {
            // Never calls the callback — violates exactly-once contract.
            Ok(())
        }
        fn backend_name(&self) -> &'static str {
            "zero-call-test"
        }
        fn provisioning_state(&self) -> ProvisioningState {
            ProvisioningState::ExternallyProvisioned
        }
    }

    /// A test-only KeySource that calls the callback twice and
    /// ignores the second call's error.
    #[derive(Debug)]
    struct DoubleCallKeySource {
        key: [u8; 32],
    }

    impl KeySource for DoubleCallKeySource {
        fn with_key(&self, f: &mut dyn FnMut(&[u8; 32]) -> Result<()>) -> Result<()> {
            // First call — legitimate.
            f(&self.key)?;
            // Second call — contract violation. Ignore the result.
            let _ = f(&self.key);
            Ok(())
        }
        fn backend_name(&self) -> &'static str {
            "double-call-test"
        }
        fn provisioning_state(&self) -> ProvisioningState {
            ProvisioningState::ExternallyProvisioned
        }
    }

    /// A test-only KeySource whose callback returns an error.
    #[derive(Debug)]
    struct CallbackErrorSource {
        key: [u8; 32],
    }

    impl KeySource for CallbackErrorSource {
        fn with_key(&self, f: &mut dyn FnMut(&[u8; 32]) -> Result<()>) -> Result<()> {
            // Invoke the callback as required.
            f(&self.key)
        }
        fn backend_name(&self) -> &'static str {
            "callback-error-test"
        }
        fn provisioning_state(&self) -> ProvisioningState {
            ProvisioningState::ExternallyProvisioned
        }
    }

    /// A test-only KeySource that calls the callback once, then returns
    /// an error — simulating a KMS/HSM connection failure.
    #[derive(Debug)]
    struct BackendErrorSource {
        key: [u8; 32],
    }

    impl KeySource for BackendErrorSource {
        fn with_key(&self, f: &mut dyn FnMut(&[u8; 32]) -> Result<()>) -> Result<()> {
            // One compliant callback invocation, then the backend itself fails.
            f(&self.key)?;
            Err(anyhow::Error::msg("backend-connection-failed"))
        }
        fn backend_name(&self) -> &'static str {
            "backend-error-test"
        }
        fn provisioning_state(&self) -> ProvisioningState {
            ProvisioningState::ExternallyProvisioned
        }
    }

    #[test]
    fn get_key_detects_zero_calls() {
        let store = SecretStore::from_key_source(Arc::new(ZeroCallKeySource), true);
        let err = store
            .get_key(|_| Ok("should not reach"))
            .unwrap_err()
            .to_string();
        assert!(
            err.contains("did not invoke the callback"),
            "Zero-call backend must be detected: {err}"
        );
        assert!(
            err.contains("zero-call-test"),
            "Error must name the backend: {err}"
        );
    }

    #[test]
    fn get_key_detects_double_call_that_ignores_callback_error() {
        let key = generate_random_key();
        let mut key_arr = [0u8; 32];
        key_arr.copy_from_slice(&key);
        let store =
            SecretStore::from_key_source(Arc::new(DoubleCallKeySource { key: key_arr }), true);
        // If the backend calls twice but ignores the second callback error,
        // get_key must still detect the violation.
        let err = store
            .get_key(|_k| Ok("legitimate-result"))
            .unwrap_err()
            .to_string();
        assert!(
            err.contains("invoked the callback 2 times"),
            "Double-call must be detected even when backend ignores callback error: {err}"
        );
    }

    #[test]
    fn get_key_propagates_callback_error() {
        let key = generate_random_key();
        let mut key_arr = [0u8; 32];
        key_arr.copy_from_slice(&key);
        let store =
            SecretStore::from_key_source(Arc::new(CallbackErrorSource { key: key_arr }), true);
        let err = store
            .get_key(|_k| Err::<(), _>(anyhow::Error::msg("test-callback-failure-reason")))
            .unwrap_err()
            .to_string();
        // The original callback error must propagate unchanged.
        assert!(
            err.contains("test-callback-failure-reason"),
            "Callback error must propagate unchanged: {err}"
        );
    }

    #[test]
    fn get_key_callback_returns_value_normally() {
        // Happy path: exactly one callback invocation, callback succeeds.
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        let result = store
            .get_key(|k| {
                assert_eq!(k.len(), 32);
                Ok::<_, anyhow::Error>(42u32)
            })
            .unwrap();
        assert_eq!(result, 42);
    }

    #[test]
    fn get_key_propagates_backend_error() {
        // When the backend itself returns Err (e.g., KMS connection failure),
        // get_key must propagate that error — not the callback result.
        let key = generate_random_key();
        let mut key_arr = [0u8; 32];
        key_arr.copy_from_slice(&key);
        let store =
            SecretStore::from_key_source(Arc::new(BackendErrorSource { key: key_arr }), true);
        let err = store
            .get_key(|_k| Ok("callback-succeeded-but-backend-failed"))
            .unwrap_err()
            .to_string();
        assert!(
            err.contains("backend-connection-failed"),
            "Backend error must propagate, got: {err}"
        );
    }

    // ── Backward compatibility (frozen fixture) ──────────────

    /// Pre-computed hex encoding of the frozen test key.
    /// This is a literal artifact — it must never be regenerated at
    /// test runtime.  A change to hex_encode must break this test
    /// (or the frozen fixture test) rather than silently updating
    /// both sides of the proof.
    const FROZEN_KEY_HEX: &str = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f";

    /// Roundtrip test: current encrypt → current decrypt.
    /// Proves the live encryption/decryption paths are consistent.
    #[test]
    fn encrypt_decrypt_roundtrip_consistent() {
        let tmp = TempDir::new().unwrap();
        let store = SecretStore::new(tmp.path(), true);
        let plaintext = "roundtrip-consistency-check";
        let encrypted = store.encrypt(plaintext).unwrap();
        let decrypted = store.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    /// Frozen compatibility fixture: decrypt a pre-computed enc2:
    /// ciphertext using a literal pre-refactor key file.
    ///
    /// This test does NOT generate or format the fixture at runtime.
    /// The key hex and ciphertext are literal constants.  A change to
    /// the encryption library, hex encoding, or wire format must break
    /// this test rather than silently updating both sides.
    #[test]
    fn frozen_pre_refactor_ciphertext_decrypts() {
        // Pre-computed ciphertext: ChaCha20-Poly1305 with the frozen key
        // above, all-zero nonce, plaintext "frozen-backward-compat-test".
        const FROZEN_ENC2_CIPHERTEXT: &str = "enc2:0000000000000000000000007eca2d4bc8888bb372023716ce312a0a9bde9e8580d97628898b8882bba56517740f7ddee9dd6324f1b35f";

        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        fs::write(&key_path, FROZEN_KEY_HEX).unwrap();

        let fs = FileKeySource::new(key_path);
        let store = SecretStore::from_key_source(Arc::new(fs), true);
        let decrypted = store.decrypt(FROZEN_ENC2_CIPHERTEXT).unwrap();
        assert_eq!(
            decrypted, "frozen-backward-compat-test",
            "Frozen fixture: pre-refactor ciphertext must decrypt correctly"
        );
    }

    #[test]
    fn frozen_fixture_tampered_ciphertext_rejected() {
        // Tampering with the frozen test vector must still be detected.
        let tmp = TempDir::new().unwrap();
        let key_path = tmp.path().join(".secret_key");
        fs::write(&key_path, FROZEN_KEY_HEX).unwrap();

        let fs = FileKeySource::new(key_path);
        let store = SecretStore::from_key_source(Arc::new(fs), true);

        // Flip the first byte of the ciphertext portion of a valid enc2: value.
        let tampered = "enc2:000000000000000000000000\
            f1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6\
            c7d8e9f0a1b2c3d4e5f6a7b8c9d0";

        let result = store.decrypt(tampered);
        assert!(result.is_err(), "Tampered frozen fixture must be rejected");
    }
}
