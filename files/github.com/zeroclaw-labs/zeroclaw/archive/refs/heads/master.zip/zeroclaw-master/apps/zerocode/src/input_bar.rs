//! Reusable input bar widget with text editing, file attachments,
//! file explorer, and clipboard paste support.

use std::collections::VecDeque;
use std::path::PathBuf;
use std::time::{Duration, Instant};

use directories::UserDirs;

use crossterm::event::{KeyCode, KeyEvent, KeyModifiers, MouseButton, MouseEvent, MouseEventKind};
use ratatui::{
    Frame,
    layout::{Constraint, Direction, Layout, Rect},
    style::{Modifier, Style},
    text::{Line, Span},
    widgets::{Block, Borders, Clear, List, ListItem, Paragraph},
};

use crate::attachment::{CleanupReport, PendingAttachment, remove_clipboard_temp};
use crate::clipboard;
use crate::file_explorer::{ExplorerAction, FileExplorerState};
use crate::mouse;
use crate::theme;
use crate::turn_status::TurnStatus;

// ── Constants ────────────────────────────────────────────────────

/// Maximum number of visible content rows before the input bar scrolls.
const MAX_INPUT_ROWS: u16 = 5;

const MAX_EDIT_HISTORY: usize = 100;

/// Spaces stay in a typing run; pausing to think starts a fresh undo group.
const TYPING_GROUP_IDLE: Duration = Duration::from_secs(2);

/// Maximum number of attachment rows visible in the manager before it scrolls.
const MAX_ATTACHMENT_MANAGER_ROWS: usize = 8;

const ATTACHMENT_REMOVE_LABEL: &str = "[×]";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SlashCommandId {
    Attach,
    ListAttachments,
    Detach,
    ChangeDirectory,
    ClearQueue,
    Browse,
    Help,
    LoadSession,
    Model,
    ModelProvider,
    RestartSession,
    ToggleThinking,
}

#[derive(Debug, Clone, Copy)]
struct LocalCommandDescriptor {
    id: SlashCommandId,
    name: &'static str,
    aliases: &'static [&'static str],
}

/// Commands whose identity and execution are owned entirely by ZeroCode.
/// Shared command names and aliases are intentionally absent: the daemon
/// supplies those from `zeroclaw-commands` during the RPC handshake.
const LOCAL_COMMANDS: &[LocalCommandDescriptor] = &[
    LocalCommandDescriptor {
        id: SlashCommandId::Attach,
        name: "attach",
        aliases: &[],
    },
    LocalCommandDescriptor {
        id: SlashCommandId::ListAttachments,
        name: "attachments",
        aliases: &[],
    },
    LocalCommandDescriptor {
        id: SlashCommandId::Browse,
        name: "browse",
        aliases: &[],
    },
    LocalCommandDescriptor {
        id: SlashCommandId::ChangeDirectory,
        name: "change-directory",
        aliases: &[],
    },
    LocalCommandDescriptor {
        id: SlashCommandId::ClearQueue,
        name: "clear-queue",
        aliases: &[],
    },
    LocalCommandDescriptor {
        id: SlashCommandId::Detach,
        name: "detach",
        aliases: &[],
    },
    LocalCommandDescriptor {
        id: SlashCommandId::LoadSession,
        name: "load-session",
        aliases: &[],
    },
    LocalCommandDescriptor {
        id: SlashCommandId::ModelProvider,
        name: "model-provider",
        aliases: &[],
    },
    LocalCommandDescriptor {
        id: SlashCommandId::RestartSession,
        name: "restart-session",
        aliases: &[],
    },
    LocalCommandDescriptor {
        id: SlashCommandId::ToggleThinking,
        name: "toggle-thinking",
        aliases: &[],
    },
];

#[derive(Debug, Clone)]
struct CommandToken {
    id: SlashCommandId,
    token: String,
}

#[derive(Debug, Clone)]
struct SlashCommandRegistry {
    tokens: Vec<CommandToken>,
}

impl SlashCommandRegistry {
    fn new(shared: &[crate::wire::CommandDescriptor]) -> Self {
        let mut tokens = std::collections::BTreeMap::new();

        for descriptor in shared {
            let Some(id) = shared_command_id(&descriptor.id) else {
                continue;
            };
            for name in std::iter::once(descriptor.name.as_str())
                .chain(descriptor.aliases.iter().map(String::as_str))
            {
                tokens.insert(format!("/{name}"), id);
            }
        }

        // Local commands own their tokens if a future shared descriptor
        // collides with one of them.
        for descriptor in LOCAL_COMMANDS {
            for name in std::iter::once(descriptor.name).chain(descriptor.aliases.iter().copied()) {
                tokens.insert(format!("/{name}"), descriptor.id);
            }
        }

        Self {
            tokens: tokens
                .into_iter()
                .map(|(token, id)| CommandToken { id, token })
                .collect(),
        }
    }

    fn command_names(&self) -> impl Iterator<Item = &str> {
        self.tokens.iter().map(|entry| entry.token.as_str())
    }

    fn parse<'a>(&self, input: &'a str) -> SlashCommand<'a> {
        let trimmed = input.trim();
        let (head, argument) = trimmed
            .split_once(' ')
            .map_or((trimmed, None), |(head, rest)| (head, Some(rest.trim())));
        let Some(id) = self
            .tokens
            .iter()
            .find(|entry| entry.token == head)
            .map(|entry| entry.id)
        else {
            return SlashCommand::NotACommand;
        };

        match (id, argument) {
            (SlashCommandId::Attach, argument) => {
                SlashCommand::Attach(argument.unwrap_or_default())
            }
            (SlashCommandId::Detach, None) => SlashCommand::Detach(None),
            (SlashCommandId::Detach, Some(argument)) => SlashCommand::Detach(argument.parse().ok()),
            (SlashCommandId::ListAttachments, None) => SlashCommand::ListAttachments,
            (SlashCommandId::ClearQueue, None) => SlashCommand::ClearQueue(None),
            (SlashCommandId::ClearQueue, Some(argument)) => {
                // Malformed index -> Some(0): an invalid index, never a
                // clear-all, so a typo cannot wipe the whole queue.
                SlashCommand::ClearQueue(Some(argument.parse().unwrap_or(0)))
            }
            (SlashCommandId::ChangeDirectory, None) => SlashCommand::ChangeDirectory,
            // The new root is always chosen in the picker, so a path argument
            // would be a second, conflicting source of truth. Reject it as a
            // non-command instead of silently ignoring the text the user typed.
            (SlashCommandId::ChangeDirectory, Some(_)) => SlashCommand::NotACommand,
            (SlashCommandId::RestartSession, None) => SlashCommand::RestartSession,
            (SlashCommandId::ToggleThinking, None) => SlashCommand::ToggleThinking,
            (SlashCommandId::Browse, None) => SlashCommand::EnterBrowseMode,
            (SlashCommandId::Help, None) => SlashCommand::OpenHelp,
            (SlashCommandId::ModelProvider, None | Some("")) => SlashCommand::ModelProviderPicker,
            (SlashCommandId::ModelProvider, Some(name)) => SlashCommand::ModelProvider(name),
            (SlashCommandId::Model, None | Some("")) => SlashCommand::ModelPicker,
            (SlashCommandId::Model, Some(name)) => SlashCommand::Model(name),
            (SlashCommandId::LoadSession, None | Some("")) => SlashCommand::LoadSessionPicker,
            (SlashCommandId::LoadSession, Some(query)) => SlashCommand::LoadSession(query),
            _ => SlashCommand::NotACommand,
        }
    }
}

/// Commands whose completion fills `"<command> "` and waits for an argument
/// instead of submitting.
fn command_takes_argument(choice: &str) -> bool {
    matches!(choice, "/model" | "/model-provider" | "/load-session")
}

fn shared_command_id(id: &str) -> Option<SlashCommandId> {
    match id {
        "help" => Some(SlashCommandId::Help),
        "model" => Some(SlashCommandId::Model),
        "new" => Some(SlashCommandId::RestartSession),
        _ => None,
    }
}

// ── Action type ──────────────────────────────────────────────────

/// Action returned from input bar key/paste handling.
pub(crate) enum InputBarAction {
    /// Key consumed, no further action for parent.
    Consumed,
    /// User submitted a message (Enter with text and/or attachments).
    Submit {
        text: Option<String>,
        attachments: Vec<PendingAttachment>,
    },
    /// User requested immediate injection (platform-primary Enter) — skip the queue.
    Inject {
        text: Option<String>,
        attachments: Vec<PendingAttachment>,
    },
    /// Empty Enter (no text, no attachments). Carries no payload but is still
    /// a deliberate keystroke — the parent uses it to resume a paused queue so
    /// a silent pause can never trap the user.
    ResumeQueue,
    /// User typed `/restart-session`, `/new-session`, or `/new` — parent should close
    /// the current session and open a fresh one for the same agent/workspace.
    RestartSession,
    /// User typed `/change-directory` — parent should open a directory picker
    /// and start a new session in the selected directory. Takes no argument:
    /// the root is always chosen interactively.
    ChangeDirectory,
    /// `/load-session` with no argument — open the pane's session picker.
    OpenSessionPicker,
    /// `/load-session <query>` — resolve and resume a saved session.
    LoadSession(String),
    /// User typed `/clear-queue [N]`. The input bar doesn't own the queue, so
    /// it hands removal up to the parent. None = clear all; Some(N) = the
    /// 1-based queue position (Some(0) is an invalid-index sentinel).
    ClearQueue(Option<usize>),
    /// Status message to show in conversation (e.g. "Attached: photo.png").
    StatusMessage(String),
    /// User typed `/toggle-thinking` — parent should toggle thought visibility.
    ToggleThinking,
    /// User typed `/browse` — parent should enter transcript browse mode.
    EnterBrowseMode,
    /// User typed `/help` — parent should open the app-level Help overlay.
    OpenHelp,
    /// User chose a model directly (`/model <name>`) — parent applies it via
    /// `session/configure`.
    SetModel(String),
    /// User chose a model_provider directly (`/model-provider <name>`) — parent
    /// applies it via `session/configure`.
    SetModelProvider(String),
    /// User typed `/model` with no argument — parent opens the model picker
    /// modal over the cached model catalog.
    OpenModelPicker,
    /// User typed `/model-provider` with no argument — parent opens the
    /// two-stage model_provider picker modal.
    OpenModelProviderPicker,
    /// Key was not handled by the input bar — parent should handle it.
    NotHandled,
}

// ── Slash commands ───────────────────────────────────────────────

enum SlashCommand<'a> {
    Attach(&'a str),
    Detach(Option<usize>),
    ListAttachments,
    /// `/clear-queue` (None = clear all) or `/clear-queue N` (Some(N), 1-based).
    /// A malformed index parses to `Some(0)` so the handler can reject it
    /// rather than silently clearing the whole queue.
    ClearQueue(Option<usize>),
    ToggleThinking,
    /// `/model <name>` — switch model directly.
    Model(&'a str),
    /// `/model` (no arg) — open the model picker modal.
    ModelPicker,
    /// `/model-provider <name>` — switch model_provider directly.
    ModelProvider(&'a str),
    /// `/model-provider` (no arg) — open the two-stage model_provider picker.
    ModelProviderPicker,
    RestartSession,
    /// `/change-directory` — open the directory picker for a new session.
    ChangeDirectory,
    EnterBrowseMode,
    OpenHelp,
    /// `/load-session <query>` — resume a saved session by name or id.
    LoadSession(&'a str),
    /// `/load-session` (no arg) — open the session picker.
    LoadSessionPicker,
    NotACommand,
}

// ── Wrap geometry helpers ────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct VisualLine {
    pub(crate) start: usize,
    pub(crate) end: usize,
    width: u16,
}

fn str_cell_width(text: &str) -> u16 {
    crate::display_width::display_width(text)
        .try_into()
        .unwrap_or(u16::MAX)
}

fn grapheme_is_whitespace(grapheme: &str) -> bool {
    grapheme == "\u{200b}" || (grapheme != "\u{00a0}" && grapheme.chars().all(char::is_whitespace))
}

fn push_hard_wrapped(
    lines: &mut Vec<VisualLine>,
    text: &str,
    start: usize,
    end: usize,
    width: u16,
) {
    let mut line_start = start;
    let mut line_width = 0;

    // Advance by grapheme so presentation sequences (e.g. ⚠️) stay one unit.
    for (offset, grapheme, g_width_usize) in
        crate::display_width::grapheme_widths(&text[start..end])
    {
        let byte_idx = start + offset;
        let g_width = u16::try_from(g_width_usize).unwrap_or(u16::MAX);
        if g_width > width {
            continue;
        }
        if line_width > 0 && line_width + g_width > width {
            lines.push(VisualLine {
                start: line_start,
                end: byte_idx,
                width: line_width,
            });
            line_start = byte_idx;
            line_width = 0;
        }
        // Silence unused-binding lint if grapheme is only needed for width.
        let _ = grapheme;
        line_width = line_width.saturating_add(g_width);
    }

    if line_start < end || line_width > 0 {
        lines.push(VisualLine {
            start: line_start,
            end,
            width: line_width,
        });
    }
}

fn push_wrapped_physical_line(
    lines: &mut Vec<VisualLine>,
    text: &str,
    start: usize,
    end: usize,
    width: u16,
) {
    if start == end {
        lines.push(VisualLine {
            start,
            end,
            width: 0,
        });
        return;
    }

    let mut line_start = start;
    let mut line_end = start;
    let mut line_width = 0u16;
    let mut pending_ws_start: Option<usize> = None;
    let mut pending_ws_end = start;
    let mut pending_ws_width = 0u16;
    let mut idx = start;

    while idx < end {
        let Some((_, first_grapheme, _)) =
            crate::display_width::grapheme_widths(&text[idx..end]).next()
        else {
            break;
        };

        if grapheme_is_whitespace(first_grapheme) {
            let ws_start = idx;
            let mut ws_end = idx;
            let mut ws_width = 0u16;
            for (off, g, w) in crate::display_width::grapheme_widths(&text[idx..end]) {
                if !grapheme_is_whitespace(g) {
                    break;
                }
                ws_width = ws_width.saturating_add(u16::try_from(w).unwrap_or(u16::MAX));
                ws_end = idx + off + g.len();
            }
            pending_ws_start = Some(ws_start);
            pending_ws_end = ws_end;
            pending_ws_width = ws_width;
            idx = ws_end;
            continue;
        }

        let word_start = idx;
        let mut word_end = idx;
        let mut word_width = 0u16;
        for (off, g, w) in crate::display_width::grapheme_widths(&text[idx..end]) {
            if grapheme_is_whitespace(g) {
                break;
            }
            word_width = word_width.saturating_add(u16::try_from(w).unwrap_or(u16::MAX));
            word_end = idx + off + g.len();
        }

        if word_width > width {
            if line_end > line_start {
                lines.push(VisualLine {
                    start: line_start,
                    end: line_end,
                    width: line_width,
                });
            }
            push_hard_wrapped(lines, text, word_start, word_end, width);
            line_start = word_end;
            line_end = word_end;
            line_width = 0;
            pending_ws_start = None;
            pending_ws_width = 0;
            idx = word_end;
            continue;
        }

        if line_end == line_start {
            if let Some(ws_start) = pending_ws_start {
                let combined_width = pending_ws_width + word_width;
                if combined_width <= width {
                    line_start = ws_start;
                    line_end = word_end;
                    line_width = combined_width;
                } else {
                    line_start = word_start;
                    line_end = word_end;
                    line_width = word_width;
                }
            } else {
                line_start = word_start;
                line_end = word_end;
                line_width = word_width;
            }
        } else if line_width + pending_ws_width + word_width <= width {
            line_end = word_end;
            line_width = line_width
                .saturating_add(pending_ws_width)
                .saturating_add(word_width);
        } else {
            lines.push(VisualLine {
                start: line_start,
                end: line_end,
                width: line_width,
            });
            line_start = word_start;
            line_end = word_end;
            line_width = word_width;
        }

        pending_ws_start = None;
        pending_ws_width = 0;
        idx = word_end;
    }

    if let Some(ws_start) = pending_ws_start {
        if line_end == line_start {
            push_hard_wrapped(lines, text, ws_start, pending_ws_end, width);
            return;
        }
        if line_width + pending_ws_width <= width {
            line_end = pending_ws_end;
            line_width += pending_ws_width;
        }
    }

    if line_end > line_start {
        lines.push(VisualLine {
            start: line_start,
            end: line_end,
            width: line_width,
        });
    }
}

pub(crate) fn wrap_visual_lines(text: &str, width: u16) -> Vec<VisualLine> {
    if width == 0 {
        return vec![VisualLine {
            start: 0,
            end: 0,
            width: 0,
        }];
    }

    let mut lines = Vec::new();
    let mut start = 0;
    for segment in text.split_inclusive('\n') {
        let has_newline = segment.ends_with('\n');
        let content_end = start + segment.len() - usize::from(has_newline);
        push_wrapped_physical_line(&mut lines, text, start, content_end, width);
        start += segment.len();
    }

    if text.is_empty() || text.ends_with('\n') {
        lines.push(VisualLine {
            start: text.len(),
            end: text.len(),
            width: 0,
        });
    }

    lines
}

/// Count the number of visual rows `text` occupies when soft-wrapped at `width` columns.
/// Each `\n` starts a new visual line. Empty input returns 1 (cursor needs a row).
fn wrapped_line_count(text: &str, width: u16) -> u16 {
    wrap_visual_lines(text, width)
        .len()
        .try_into()
        .unwrap_or(u16::MAX)
}

/// Decide which overflow arrows to show for `(up, down)` given the total
/// content rows, the visible window, and the current scroll offset. Arrows
/// only appear when content exceeds the window.
fn overflow_arrows(content_rows: u16, visible_rows: u16, scroll_offset: u16) -> (bool, bool) {
    if content_rows <= visible_rows {
        return (false, false);
    }
    let max_scroll = content_rows.saturating_sub(visible_rows);
    (scroll_offset > 0, scroll_offset < max_scroll)
}

/// Map a byte offset within `text` to `(row, col)` in wrapped coordinates.
/// `width` is the inner area width (excluding borders).
fn cursor_to_visual(text: &str, cursor: usize, width: u16) -> (u16, u16) {
    if width == 0 {
        return (0, 0);
    }
    let lines = wrap_visual_lines(text, width);
    for (row, line) in lines.iter().enumerate() {
        if cursor >= line.start && cursor <= line.end {
            if cursor == line.end && lines.get(row + 1).is_some_and(|next| next.start == cursor) {
                return ((row + 1).try_into().unwrap_or(u16::MAX), 0);
            }
            let col = if cursor == line.end {
                line.width
            } else {
                str_cell_width(&text[line.start..cursor])
            };
            return (row.try_into().unwrap_or(u16::MAX), col.min(width));
        }
        if cursor < line.start {
            return (row.try_into().unwrap_or(u16::MAX), 0);
        }
    }
    let row = lines.len().saturating_sub(1).try_into().unwrap_or(u16::MAX);
    let col = lines.last().map_or(0, |line| line.width);
    (row, col.min(width))
}

/// Map a visual `(row, col)` position back to a byte offset in `text`.
/// Clamps to valid positions. Returns `text.len()` if past end.
fn visual_to_cursor(text: &str, target_row: u16, target_col: u16, width: u16) -> usize {
    if width == 0 {
        return 0;
    }
    let lines = wrap_visual_lines(text, width);
    let Some(line) = lines.get(target_row as usize) else {
        return text.len();
    };

    let mut col = 0u16;
    for (offset, _grapheme, g_width_usize) in
        crate::display_width::grapheme_widths(&text[line.start..line.end])
    {
        if col >= target_col {
            return line.start + offset;
        }
        let g_width = u16::try_from(g_width_usize).unwrap_or(u16::MAX);
        col = col.saturating_add(g_width);
        if col > target_col {
            return line.start + offset;
        }
    }
    if target_col >= line.width {
        line.end
    } else {
        line.start
    }
}

fn attachment_row_at(
    area: Option<Rect>,
    first_index: usize,
    column: u16,
    row: u16,
) -> Option<usize> {
    let area = area?;
    if !mouse::in_rect(column, row, area) {
        return None;
    }
    Some(first_index + usize::from(row - area.y))
}

fn attachment_remove_at(
    area: Option<Rect>,
    first_index: usize,
    attachments: &[PendingAttachment],
    column: u16,
    row: u16,
) -> Option<usize> {
    let area = area?;
    let index = attachment_row_at(Some(area), first_index, column, row)?;
    let attachment = attachments.get(index)?;
    let (_, remove_col) = attachment_line(index, &attachment.label(), area.width);
    let remove_col = remove_col?;
    let remove_width = crate::display_width::display_width(ATTACHMENT_REMOVE_LABEL) as u16;
    let relative_col = column - area.x;
    if relative_col < remove_col || relative_col >= remove_col + remove_width {
        return None;
    }
    Some(index)
}

fn attachment_line(index: usize, label: &str, width: u16) -> (String, Option<u16>) {
    let remove_width = crate::display_width::display_width(ATTACHMENT_REMOVE_LABEL) as u16;
    if width < remove_width {
        return (truncate_to_cells(label, width as usize), None);
    }

    let main_width = width - remove_width;
    if main_width == 0 {
        return (String::new(), Some(0));
    }

    let raw = format!(" [{index}] {label}");
    let mut main = truncate_to_cells(&raw, main_width.saturating_sub(1) as usize);
    main.push(' ');
    let remove_col = crate::display_width::display_width(&main) as u16;
    (main, Some(remove_col))
}

fn truncate_to_cells(text: &str, max_width: usize) -> String {
    if crate::display_width::display_width(text) <= max_width {
        return text.to_string();
    }
    if max_width == 0 {
        return String::new();
    }

    let mut out = String::new();
    let budget = max_width - 1;
    let mut used = 0;
    for (_, grapheme, width) in crate::display_width::grapheme_widths(text) {
        if used + width > budget {
            break;
        }
        out.push_str(grapheme);
        used += width;
    }
    out.push('…');
    out
}

fn attachment_manager_key_labels() -> (Vec<String>, Vec<String>, Vec<String>) {
    use crate::keymap::{InputBarAction as Ib, ModalAction as M, action_key_labels};

    let mut navigate = action_key_labels(M::Up);
    navigate.extend(action_key_labels(M::Down));
    let mut remove = action_key_labels(Ib::Backspace);
    remove.push("Del".to_string());
    let close = action_key_labels(M::Cancel);
    (navigate, remove, close)
}

// ── State ────────────────────────────────────────────────────────

/// Historical text only: attachments and their temporary files keep their
/// existing owner and are never restored by undo.
#[derive(Debug)]
struct EditSnapshot {
    input: String,
    cursor: usize,
    selection: Option<(usize, usize)>,
    selection_anchor: Option<usize>,
}

/// Input bar state. Each pane (Chat, ACP) owns its own instance.
#[derive(Debug)]
pub(crate) struct InputBarState {
    command_registry: SlashCommandRegistry,
    input: String,
    /// Byte offset of the editing cursor within `input`.
    /// Kept on a grapheme boundary after each completed edit operation.
    cursor: usize,
    undo: VecDeque<EditSnapshot>,
    redo: Vec<EditSnapshot>,
    /// Only consecutive typing may extend the latest undo transaction.
    last_typing_at: Option<Instant>,
    pending_attachments: Vec<PendingAttachment>,
    attachment_manager: Option<AttachmentManagerState>,
    /// Latest composer and modal list geometry for mouse hit-testing.
    last_attachment_area: Option<Rect>,
    last_attachment_manager_area: Option<Rect>,
    file_explorer: Option<FileExplorerState>,
    clipboard_temps: Vec<PathBuf>,
    cleanup_report: CleanupReport,

    // Phase 1: Soft-wrap / dynamic height
    /// Vertical scroll offset within the input bar (0-based row index of first visible line).
    scroll_offset: u16,
    /// Cached Rect of the last rendered input area (for mouse hit-testing).
    last_input_area: Rect,
    /// Cached inner width from the most recent render.
    last_inner_width: u16,
    /// Rect of the autocomplete popup from the most recent render, for
    /// mouse hit-testing. `None` when the popup was not drawn.
    last_autocomplete_area: Option<Rect>,
    /// Index of the first match drawn in the popup. The popup can be shorter
    /// than the match list; render scrolls this to keep the highlight visible.
    autocomplete_scroll: usize,

    // Phase 4: Text selection
    /// Text selection range as byte offsets (start, end) where start <= end.
    selection: Option<(usize, usize)>,
    /// Anchor point of the selection (byte offset where drag started).
    selection_anchor: Option<usize>,

    // Phase 6: Auto-complete
    /// Filtered list of matching slash commands.
    /// Candidate completions for the popup. Command names (`/model`) and
    /// argument values (model / model_provider names) both land here as owned
    /// strings.
    autocomplete_matches: Vec<String>,
    /// What the current popup is completing — drives whether Tab replaces the
    /// whole input or only the trailing argument token.
    autocomplete_target: AutocompleteTarget,
    /// Index of the currently highlighted match in the popup.
    autocomplete_index: Option<usize>,
    /// Whether the autocomplete popup is visible.
    autocomplete_active: bool,

    /// Cached model catalog for the active model_provider, pushed in by the app
    /// layer (the input bar is synchronous and cannot fetch). Filtered for
    /// `/model <partial>` argument autocomplete.
    model_catalog: Vec<String>,
    /// Which model_provider `model_catalog` was fetched for; lets the app layer
    /// decide whether a refetch is needed on provider change.
    model_catalog_provider: Option<String>,
    /// Cached model_provider names for `/model-provider <partial>` autocomplete.
    provider_catalog: Vec<String>,
}

/// What the autocomplete popup is currently offering, so Tab-completion knows
/// how much of the input to rewrite.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum AutocompleteTarget {
    /// Completing a slash-command name (replaces the whole input).
    Command,
    /// Completing the `/model <arg>` value (replaces only the argument).
    ModelArg,
    /// Completing the `/model-provider <arg>` value (replaces only the argument).
    ModelProviderArg,
}

#[derive(Debug, Clone, Copy)]
struct AttachmentManagerState {
    selected: usize,
    scroll: usize,
}

impl InputBarState {
    pub fn with_shared_commands(shared: &[crate::wire::CommandDescriptor]) -> Self {
        Self {
            command_registry: SlashCommandRegistry::new(shared),
            input: String::new(),
            cursor: 0,
            undo: VecDeque::new(),
            redo: Vec::new(),
            last_typing_at: None,
            pending_attachments: Vec::new(),
            attachment_manager: None,
            last_attachment_area: None,
            last_attachment_manager_area: None,
            file_explorer: None,
            clipboard_temps: Vec::new(),
            cleanup_report: CleanupReport::default(),
            scroll_offset: 0,
            last_input_area: Rect::default(),
            last_inner_width: 0,
            last_autocomplete_area: None,
            autocomplete_scroll: 0,
            selection: None,
            selection_anchor: None,
            autocomplete_matches: Vec::new(),
            autocomplete_target: AutocompleteTarget::Command,
            autocomplete_index: None,
            autocomplete_active: false,
            model_catalog: Vec::new(),
            model_catalog_provider: None,
            provider_catalog: Vec::new(),
        }
    }

    // ── Accessors ────────────────────────────────────────────

    pub fn input(&self) -> &str {
        &self.input
    }

    pub fn has_pending_attachments(&self) -> bool {
        !self.pending_attachments.is_empty()
    }

    #[cfg(test)]
    pub fn cursor(&self) -> usize {
        self.cursor
    }

    #[cfg(test)]
    pub fn pending_attachments(&self) -> &[PendingAttachment] {
        &self.pending_attachments
    }

    /// Copy only durable, user-selected attachments for a reconnect snapshot.
    /// Clipboard attachments point at temporary files owned by this input bar
    /// and must never cross a transport rebuild.
    pub(crate) fn reconnect_file_attachments(&self) -> Vec<PendingAttachment> {
        self.pending_attachments
            .iter()
            .filter(|attachment| attachment.source == crate::attachment::AttachmentSource::File)
            .cloned()
            .collect()
    }

    #[cfg(test)]
    pub fn clipboard_temps(&self) -> &[PathBuf] {
        &self.clipboard_temps
    }

    #[cfg(test)]
    pub fn attachment_area(&self) -> Option<Rect> {
        self.last_attachment_area
    }

    pub fn has_file_explorer(&self) -> bool {
        self.file_explorer.is_some()
    }

    pub fn has_attachment_manager(&self) -> bool {
        self.attachment_manager.is_some()
    }

    /// Open an explorer with one selected path for parent-level key-routing
    /// tests, so the test can exercise a real explorer confirmation result.
    #[cfg(test)]
    pub(crate) fn open_file_explorer_for_test(&mut self, path: PathBuf) {
        let start_dir = path
            .parent()
            .map(PathBuf::from)
            .unwrap_or_else(std::env::temp_dir);
        let mut explorer = FileExplorerState::new(start_dir);
        explorer.select_path_for_test(path);
        self.file_explorer = Some(explorer);
    }

    /// Whether the input bar is in text-input mode (input non-empty or an
    /// input-owned modal open). Used to suppress single-char keybindings.
    pub fn wants_text_input(&self) -> bool {
        !self.input.is_empty() || self.file_explorer.is_some() || self.attachment_manager.is_some()
    }

    // ── Selection helpers ────────────────────────────────────

    pub(crate) fn has_selection(&self) -> bool {
        self.selection.is_some_and(|(start, end)| start < end)
    }

    /// Purely local clipboard output; safe without a daemon connection.
    pub(crate) fn copy_selection(&self) -> Option<std::io::Result<clipboard::CopyOutcome>> {
        let (start, end) = self.selection.filter(|(start, end)| start < end)?;
        Some(clipboard::copy_text(&self.input[start..end]))
    }

    /// Resolve ownership through the same configured action table as dispatch.
    pub(crate) fn claims_edit_key(&self, key: &KeyEvent) -> bool {
        use crate::keymap::InputBarAction as A;
        match A::from_chord(key) {
            Some(A::CopySelection | A::Cut) => self.has_selection(),
            Some(A::HistoryPrev | A::HistoryNext) => !self.input.is_empty(),
            // Tab and Esc are completion keys while the popup is open. Esc is
            // also a chat browse chord, and non-character chords otherwise
            // bypass the composer.
            Some(A::AutocompleteAccept | A::AutocompleteCancel) => self.autocomplete_active,
            Some(
                A::Undo
                | A::Redo
                | A::SelectAll
                | A::SelectLeft
                | A::SelectRight
                | A::SelectUp
                | A::SelectDown
                | A::SelectStart
                | A::SelectEnd
                | A::SelectWordLeft
                | A::SelectWordRight
                | A::DeleteNextWord,
            ) => true,
            _ => false,
        }
    }

    fn select_to(&mut self, cursor: usize) {
        self.last_typing_at = None;
        let anchor = *self.selection_anchor.get_or_insert(self.cursor);
        self.cursor = cursor;
        self.selection = (anchor != cursor).then_some((anchor.min(cursor), anchor.max(cursor)));
    }

    fn select_vertical(&mut self, delta: i32) {
        self.last_typing_at = None;
        let width = self.last_inner_width;
        if width > 0 {
            let (row, col) = cursor_to_visual(&self.input, self.cursor, width);
            let last = wrapped_line_count(&self.input, width).saturating_sub(1);
            let row = (i32::from(row) + delta).clamp(0, i32::from(last)) as u16;
            self.select_to(visual_to_cursor(&self.input, row, col, width));
        }
    }

    fn line_edge(&self, end: bool) -> usize {
        let width = self.last_inner_width;
        if width == 0 {
            return if end { self.input.len() } else { 0 };
        }
        let (row, _) = cursor_to_visual(&self.input, self.cursor, width);
        visual_to_cursor(&self.input, row, if end { width } else { 0 }, width)
    }

    fn clear_selection(&mut self) {
        self.last_typing_at = None;
        self.selection = None;
        self.selection_anchor = None;
    }

    /// Delete the selected range and return the deleted text.
    /// Moves cursor to the start of the selection.
    fn delete_selection(&mut self) -> Option<String> {
        if let Some((start, end)) = self.selection.take() {
            let deleted = self.input[start..end].to_string();
            self.input.replace_range(start..end, "");
            self.cursor = start;
            self.selection_anchor = None;
            Some(deleted)
        } else {
            None
        }
    }

    // ── Auto-complete helpers ────────────────────────────────

    fn update_autocomplete(&mut self) {
        // Own the trimmed input so subsequent `&mut self` calls don't conflict
        // with a borrow of `self.input`.
        let text = self.input.trim_start().to_string();

        // Command-name completion: a single `/token` with no space yet.
        if text.starts_with('/') && !text.contains(' ') {
            let prefix = text.as_str();
            self.autocomplete_target = AutocompleteTarget::Command;
            self.autocomplete_matches = self
                .command_registry
                .command_names()
                .filter(|cmd| cmd.starts_with(prefix) && *cmd != prefix)
                .map(str::to_string)
                .collect();
            self.finalize_autocomplete();
            return;
        }

        // Argument completion: `/model <partial>` or `/model-provider <partial>`.
        // model_provider is checked first — its prefix is longer and `/model `
        // would otherwise swallow it.
        if let Some(partial) = text.strip_prefix("/model-provider ") {
            let partial = partial.trim_start().to_string();
            self.set_arg_matches(AutocompleteTarget::ModelProviderArg, &partial);
            return;
        }
        if let Some(partial) = text.strip_prefix("/model ") {
            let partial = partial.trim_start().to_string();
            self.set_arg_matches(AutocompleteTarget::ModelArg, &partial);
            return;
        }

        self.autocomplete_active = false;
        self.autocomplete_matches.clear();
        self.autocomplete_index = None;
    }

    /// Filter the relevant cached catalog by `partial` (case-insensitive
    /// substring) and populate the popup. Empty `partial` lists the whole
    /// catalog so the user sees options immediately after the space.
    fn set_arg_matches(&mut self, target: AutocompleteTarget, partial: &str) {
        let catalog = match target {
            AutocompleteTarget::ModelArg => &self.model_catalog,
            AutocompleteTarget::ModelProviderArg => &self.provider_catalog,
            AutocompleteTarget::Command => return,
        };
        let needle = partial.to_ascii_lowercase();
        self.autocomplete_target = target;
        self.autocomplete_matches = catalog
            .iter()
            .filter(|c| needle.is_empty() || c.to_ascii_lowercase().contains(&needle))
            .filter(|c| c.as_str() != partial)
            .cloned()
            .collect();
        self.finalize_autocomplete();
    }

    /// Shared tail of the autocomplete update: toggle visibility and clamp the
    /// highlighted index.
    fn finalize_autocomplete(&mut self) {
        self.autocomplete_active = !self.autocomplete_matches.is_empty();
        if self.autocomplete_active && self.autocomplete_index.is_none() {
            self.autocomplete_index = Some(0);
        }
        if let Some(idx) = self.autocomplete_index
            && idx >= self.autocomplete_matches.len()
        {
            self.autocomplete_index = Some(self.autocomplete_matches.len().saturating_sub(1));
        }
    }

    /// Replace the input's catalog cache for argument autocomplete. Called by
    /// the app layer after an async `catalog_models` / model_provider fetch.
    pub fn set_model_catalog(&mut self, model_provider: String, models: Vec<String>) {
        self.model_catalog = models;
        self.model_catalog_provider = Some(model_provider);
    }

    /// The model_provider the cached model catalog was fetched for, if any.
    pub fn model_catalog_provider(&self) -> Option<&str> {
        self.model_catalog_provider.as_deref()
    }

    /// The cached model catalog (for the model_provider in
    /// [`Self::model_catalog_provider`]).
    pub fn model_catalog(&self) -> &[String] {
        &self.model_catalog
    }

    /// Replace the cached model_provider list for `/model-provider` autocomplete.
    pub fn set_provider_catalog(&mut self, providers: Vec<String>) {
        self.provider_catalog = providers;
    }

    /// Popup state for tests outside this module: (entry count, highlighted
    /// index, open).
    #[cfg(test)]
    pub(crate) fn autocomplete_snapshot(&self) -> (usize, Option<usize>, bool) {
        (
            self.autocomplete_matches.len(),
            self.autocomplete_index,
            self.autocomplete_active,
        )
    }

    fn dismiss_autocomplete(&mut self) {
        self.autocomplete_scroll = 0;
        self.autocomplete_active = false;
        self.autocomplete_matches.clear();
        self.autocomplete_index = None;
    }

    /// Apply a chosen popup entry to the input. A command choice replaces the
    /// whole line (and, for commands that take an argument, appends a space so
    /// argument autocomplete, where the command has any, kicks in immediately).
    /// An argument choice rewrites only the value after the command prefix.
    fn apply_autocomplete_choice(&mut self, choice: &str) {
        self.edit(|state| {
            match state.autocomplete_target {
                AutocompleteTarget::Command => {
                    let takes_arg = command_takes_argument(choice);
                    state.input = if takes_arg {
                        format!("{choice} ")
                    } else {
                        choice.to_string()
                    };
                }
                AutocompleteTarget::ModelArg => {
                    state.input = format!("/model {choice}");
                }
                AutocompleteTarget::ModelProviderArg => {
                    state.input = format!("/model-provider {choice}");
                }
            }
            state.cursor = state.input.len();
        });
    }

    /// Mouse over the completion popup: a left click on a row fills the
    /// input with that entry (like Tab), the wheel moves the highlight, and
    /// anything else inside the popup is swallowed so it can't reach the
    /// transcript underneath. Returns false when the event is outside it.
    fn handle_autocomplete_mouse(&mut self, mouse: MouseEvent) -> bool {
        if !self.autocomplete_active {
            return false;
        }
        let Some(area) = self.last_autocomplete_area else {
            return false;
        };
        if !mouse::in_rect(mouse.column, mouse.row, area) {
            return false;
        }
        match mouse.kind {
            MouseEventKind::Down(MouseButton::Left) => {
                // Row 0 and the last row are the borders.
                let inner_top = area.y + 1;
                let inner_bottom = area.y + area.height.saturating_sub(1);
                if mouse.row >= inner_top && mouse.row < inner_bottom {
                    let index = self.autocomplete_scroll + usize::from(mouse.row - inner_top);
                    if let Some(choice) = self.autocomplete_matches.get(index).cloned() {
                        self.autocomplete_index = Some(index);
                        self.apply_autocomplete_choice(&choice);
                        self.dismiss_autocomplete();
                    }
                }
            }
            MouseEventKind::ScrollUp => {
                if let Some(idx) = self.autocomplete_index {
                    self.autocomplete_index = Some(idx.saturating_sub(1));
                }
            }
            MouseEventKind::ScrollDown => {
                if let Some(idx) = self.autocomplete_index {
                    let max = self.autocomplete_matches.len().saturating_sub(1);
                    self.autocomplete_index = Some((idx + 1).min(max));
                }
            }
            _ => {}
        }
        true
    }

    fn accept_completion_on_submit(&mut self) -> InputBarAction {
        let Some(idx) = self.autocomplete_index else {
            return self.handle_enter();
        };
        let Some(choice) = self.autocomplete_matches.get(idx).cloned() else {
            return self.handle_enter();
        };
        let target = self.autocomplete_target;
        self.apply_autocomplete_choice(&choice);
        self.dismiss_autocomplete();
        let fills_only = target == AutocompleteTarget::Command && command_takes_argument(&choice);
        if fills_only {
            return InputBarAction::Consumed;
        }
        self.handle_enter()
    }

    // ── Text editing ─────────────────────────────────────────

    fn snapshot(&self) -> EditSnapshot {
        EditSnapshot {
            input: self.input.clone(),
            cursor: self.cursor,
            selection: self.selection,
            selection_anchor: self.selection_anchor,
        }
    }

    /// Every semantic text mutation enters here, including non-key callers.
    /// A replacement's deletion and insertion are one undo transaction.
    fn edit(&mut self, change: impl FnOnce(&mut Self)) {
        self.edit_grouped(false, change);
    }

    fn edit_grouped(&mut self, extend_typing: bool, change: impl FnOnce(&mut Self)) -> bool {
        // Only a plain character insertion can extend typing. It always changes
        // text, and the group's initial snapshot already owns its undo point.
        let before = (!extend_typing).then(|| self.snapshot());
        let replaced_selection = self.has_selection();
        change(self);
        self.cursor = crate::text_navigation::normalize_grapheme_cursor(&self.input, self.cursor);
        self.clear_selection();
        self.update_autocomplete();
        let changed = before
            .as_ref()
            .is_none_or(|before| before.input != self.input);
        if changed || replaced_selection {
            self.redo.clear();
        }
        if changed && let Some(before) = before {
            self.undo.push_back(before);
            if self.undo.len() > MAX_EDIT_HISTORY {
                self.undo.pop_front();
            }
        }
        changed
    }

    fn restore(&mut self, snapshot: EditSnapshot) {
        self.input = snapshot.input;
        self.cursor = snapshot.cursor;
        self.selection = snapshot.selection;
        self.selection_anchor = snapshot.selection_anchor;
        self.scroll_offset = 0;
        self.update_autocomplete();
    }

    fn undo(&mut self) {
        self.last_typing_at = None;
        if let Some(previous) = self.undo.pop_back() {
            self.redo.push(self.snapshot());
            self.restore(previous);
        }
    }

    fn redo(&mut self) {
        self.last_typing_at = None;
        if let Some(next) = self.redo.pop() {
            self.undo.push_back(self.snapshot());
            self.restore(next);
        }
    }

    fn reset_edit_history(&mut self) {
        self.last_typing_at = None;
        self.undo.clear();
        self.redo.clear();
    }

    /// Insert `c` at the cursor position and advance the cursor.
    pub fn push_input_char(&mut self, c: char) {
        let now = Instant::now();
        let typing = c != '\n';
        let extend_typing = typing
            && !self.has_selection()
            && self
                .last_typing_at
                .is_some_and(|previous| now.duration_since(previous) < TYPING_GROUP_IDLE);
        let changed = self.edit_grouped(extend_typing, |state| {
            state.delete_selection();
            state.input.insert(state.cursor, c);
            state.cursor += c.len_utf8();
        });
        // No-op replacement must not make later typing reuse an older entry.
        if typing && changed {
            self.last_typing_at = Some(now);
        }
    }

    /// Delete the grapheme cluster immediately before the cursor (backspace).
    pub fn pop_input_char(&mut self) {
        self.last_typing_at = None;
        if self.cursor == 0 && !self.has_selection() {
            return;
        }
        self.edit(|state| {
            if state.delete_selection().is_none() && state.cursor > 0 {
                let prev_start =
                    crate::text_navigation::previous_grapheme_boundary(&state.input, state.cursor);
                state.input.replace_range(prev_start..state.cursor, "");
                state.cursor = prev_start;
            }
        });
    }

    /// Delete the grapheme cluster immediately after the cursor (forward
    /// delete). A selection deletes the whole range instead; at the end of the
    /// input there is nothing after the cursor, so it is a no-op rather than a
    /// cursor move.
    pub fn delete_next_char(&mut self) {
        self.last_typing_at = None;
        if self.cursor == self.input.len() && !self.has_selection() {
            return;
        }
        self.edit(|state| {
            if state.delete_selection().is_none() && state.cursor < state.input.len() {
                let next_end =
                    crate::text_navigation::next_grapheme_boundary(&state.input, state.cursor);
                state.input.replace_range(state.cursor..next_end, "");
            }
        });
    }

    pub fn delete_previous_word(&mut self) {
        self.last_typing_at = None;
        if self.cursor == 0 && !self.has_selection() {
            return;
        }
        self.edit(|state| {
            if state.delete_selection().is_none() {
                let start =
                    crate::text_navigation::previous_word_boundary(&state.input, state.cursor);
                state.input.replace_range(start..state.cursor, "");
                state.cursor = start;
            }
        });
    }

    fn delete_next_word(&mut self) {
        self.last_typing_at = None;
        if self.cursor == self.input.len() && !self.has_selection() {
            return;
        }
        self.edit(|state| {
            if state.delete_selection().is_none() {
                let end = crate::text_navigation::next_word_boundary(&state.input, state.cursor);
                state.input.replace_range(state.cursor..end, "");
            }
        });
    }

    pub fn move_cursor_left(&mut self) {
        self.clear_selection();
        self.cursor = crate::text_navigation::previous_grapheme_boundary(&self.input, self.cursor);
    }

    pub fn move_cursor_right(&mut self) {
        self.clear_selection();
        self.cursor = crate::text_navigation::next_grapheme_boundary(&self.input, self.cursor);
    }

    pub fn move_cursor_word_left(&mut self) {
        self.clear_selection();
        self.cursor = crate::text_navigation::previous_word_boundary(&self.input, self.cursor);
    }

    pub fn move_cursor_word_right(&mut self) {
        self.clear_selection();
        self.cursor = crate::text_navigation::next_word_boundary(&self.input, self.cursor);
    }

    /// Move cursor up one visual row. Returns false if already on row 0.
    fn move_cursor_up(&mut self) -> bool {
        self.clear_selection();
        let width = self.last_inner_width;
        if width == 0 {
            return false;
        }
        let (row, col) = cursor_to_visual(&self.input, self.cursor, width);
        if row == 0 {
            return false;
        }
        self.cursor = visual_to_cursor(&self.input, row - 1, col, width);
        true
    }

    /// Move cursor down one visual row. Returns false if already on last row.
    fn move_cursor_down(&mut self) -> bool {
        self.clear_selection();
        let width = self.last_inner_width;
        if width == 0 {
            return false;
        }
        let (row, col) = cursor_to_visual(&self.input, self.cursor, width);
        let total = wrapped_line_count(&self.input, width);
        if row + 1 >= total {
            return false;
        }
        self.cursor = visual_to_cursor(&self.input, row + 1, col, width);
        true
    }

    /// Extract the input text and reset the cursor.
    pub fn take_input(&mut self) -> String {
        self.reset_edit_history();
        self.cursor = 0;
        self.scroll_offset = 0;
        self.clear_selection();
        self.dismiss_autocomplete();
        std::mem::take(&mut self.input)
    }

    /// Insert a string at the cursor position (bulk paste).
    pub fn insert_text(&mut self, text: &str) {
        self.edit(|state| {
            state.delete_selection();
            state.input.insert_str(state.cursor, text);
            state.cursor += text.len();
        });
    }

    /// Append text to the composer without replacing or inserting into the
    /// user's current draft selection. This is used for transcript context,
    /// which must preserve the draft and leave the cursor at the end.
    pub(crate) fn append_text_at_end(&mut self, text: &str) -> bool {
        if text.is_empty() {
            return false;
        }
        self.edit(|state| {
            if !state.input.is_empty() {
                state.input.push_str("\n\n");
            }
            state.input.push_str(text);
            state.cursor = state.input.len();
        });
        self.dismiss_autocomplete();
        true
    }

    pub fn claims_pane_navigation(&self, key: &KeyEvent) -> bool {
        self.file_explorer.is_none()
            && !self.input.is_empty()
            && crate::keymap::input_bar_claims_pane_navigation(key)
    }

    // ── Attachment management ────────────────────────────────

    pub fn add_attachment(&mut self, att: PendingAttachment) {
        self.pending_attachments.push(att);
    }

    pub fn load_for_edit(&mut self, text: String, attachments: Vec<PendingAttachment>) {
        self.reset_edit_history();
        self.input = text;
        self.cursor = self.input.len();
        self.scroll_offset = 0;
        self.attachment_manager = None;
        self.clear_selection();
        self.dismiss_autocomplete();
        for att in &attachments {
            if att.source == crate::attachment::AttachmentSource::Clipboard
                && !self.clipboard_temps.contains(&att.path)
            {
                self.clipboard_temps.push(att.path.clone());
            }
        }
        self.pending_attachments = attachments;
    }

    pub fn remove_attachment(&mut self, index: usize) {
        if index >= self.pending_attachments.len() {
            return;
        }

        let removed = self.pending_attachments.remove(index);
        if removed.source == crate::attachment::AttachmentSource::Clipboard {
            self.clipboard_temps.retain(|path| path != &removed.path);
            self.cleanup_report
                .merge(remove_clipboard_temp(&removed.path));
        }

        if self.pending_attachments.is_empty() {
            self.attachment_manager = None;
        } else if let Some(manager) = &mut self.attachment_manager {
            manager.selected = manager.selected.min(self.pending_attachments.len() - 1);
            manager.scroll = manager.scroll.min(manager.selected);
        }
    }

    fn open_attachment_manager(&mut self) {
        if self.pending_attachments.is_empty() {
            return;
        }
        self.dismiss_autocomplete();
        self.attachment_manager = Some(AttachmentManagerState {
            selected: 0,
            scroll: 0,
        });
    }

    pub fn take_attachments(&mut self) -> Vec<PendingAttachment> {
        self.attachment_manager = None;
        let taken = std::mem::take(&mut self.pending_attachments);
        for att in &taken {
            if att.source == crate::attachment::AttachmentSource::Clipboard {
                self.clipboard_temps.retain(|p| p != &att.path);
            }
        }
        taken
    }

    // ── Lifecycle ────────────────────────────────────────────

    /// Reset all input state (called when switching sessions).
    pub fn reset(&mut self) {
        self.reset_edit_history();
        self.input.clear();
        self.cursor = 0;
        self.scroll_offset = 0;
        self.pending_attachments.clear();
        self.attachment_manager = None;
        self.last_attachment_area = None;
        self.last_attachment_manager_area = None;
        self.file_explorer = None;
        self.clear_selection();
        self.dismiss_autocomplete();
        self.cleanup_temps();
    }

    /// Clear text as one undoable edit without disturbing pending attachments
    /// or clipboard temps. Bound to the ClearInput action.
    pub fn clear_input(&mut self) {
        self.edit(|state| {
            state.input.clear();
            state.cursor = 0;
            state.scroll_offset = 0;
        });
    }

    /// Remove clipboard temp files (called after turn completes).
    pub fn cleanup_temps(&mut self) {
        for path in self.clipboard_temps.drain(..) {
            self.cleanup_report.merge(remove_clipboard_temp(&path));
        }
    }

    /// Take cleanup failures accumulated by attachment removal or lifecycle
    /// cleanup. The caller surfaces the bounded report through the info bar.
    pub(crate) fn take_cleanup_report(&mut self) -> CleanupReport {
        std::mem::take(&mut self.cleanup_report)
    }

    // ── Key handling ─────────────────────────────────────────

    /// Process a key event. Returns an action for the parent pane.
    pub fn handle_key(&mut self, key: KeyEvent) -> InputBarAction {
        use crate::keymap::{GlobalAction, InputBarAction as IbWidgetAction};
        let action = IbWidgetAction::from_chord(&key);

        // Even a consumed/no-op command ends typing (for example Left at the
        // start or a completion-popup navigation key).
        if !matches!(key.code, KeyCode::Char(_))
            || key
                .modifiers
                .intersects(KeyModifiers::CONTROL | KeyModifiers::SUPER)
            || action.is_some()
            || self.file_explorer.is_some()
            || self.attachment_manager.is_some()
        {
            self.last_typing_at = None;
        }
        // File explorer overlay intercepts all keys when open.
        if let Some(explorer) = &mut self.file_explorer {
            match explorer.handle_key(key) {
                ExplorerAction::Confirm(paths) => {
                    match PendingAttachment::from_explorer_paths(&paths) {
                        Ok(atts) => {
                            let labels: Vec<String> = atts.iter().map(|a| a.label()).collect();
                            for att in atts {
                                self.pending_attachments.push(att);
                            }
                            self.file_explorer = None;
                            return InputBarAction::StatusMessage(crate::i18n::t_args(
                                "zc-input-attached",
                                &[("label", &labels.join(", "))],
                            ));
                        }
                        Err(e) => {
                            self.file_explorer = None;
                            return InputBarAction::StatusMessage(crate::i18n::t_args(
                                "zc-input-attach-error",
                                &[("error", &e.to_string())],
                            ));
                        }
                    }
                }
                ExplorerAction::Cancel => {
                    self.file_explorer = None;
                }
                ExplorerAction::ConfirmDir(_) => {
                    self.file_explorer = None;
                }
                ExplorerAction::None => {}
            }
            return InputBarAction::Consumed;
        }

        if self.attachment_manager.is_some() {
            return self.handle_attachment_manager_key(key);
        }

        if GlobalAction::from_chord(&key) == Some(GlobalAction::Quit) && !self.claims_edit_key(&key)
        {
            return InputBarAction::NotHandled;
        }

        match action {
            Some(IbWidgetAction::Undo) => {
                self.undo();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::Redo) => {
                self.redo();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::CopySelection | IbWidgetAction::Cut) => {
                return match self.copy_selection() {
                    Some(Ok(outcome)) => {
                        if action == Some(IbWidgetAction::Cut) {
                            self.edit(|state| {
                                state.delete_selection();
                            });
                        }
                        InputBarAction::StatusMessage(outcome.notice())
                    }
                    Some(Err(error)) => {
                        InputBarAction::StatusMessage(clipboard::copy_failure_notice(&error))
                    }
                    None => InputBarAction::NotHandled,
                };
            }
            Some(IbWidgetAction::SelectAll) => {
                self.selection_anchor = Some(0);
                self.select_to(self.input.len());
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::SelectLeft) => {
                self.select_to(crate::text_navigation::previous_grapheme_boundary(
                    &self.input,
                    self.cursor,
                ));
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::SelectRight) => {
                self.select_to(crate::text_navigation::next_grapheme_boundary(
                    &self.input,
                    self.cursor,
                ));
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::SelectWordLeft) => {
                self.select_to(crate::text_navigation::previous_word_boundary(
                    &self.input,
                    self.cursor,
                ));
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::SelectWordRight) => {
                self.select_to(crate::text_navigation::next_word_boundary(
                    &self.input,
                    self.cursor,
                ));
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::SelectUp | IbWidgetAction::SelectDown) => {
                self.select_vertical(if action == Some(IbWidgetAction::SelectUp) {
                    -1
                } else {
                    1
                });
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::SelectStart | IbWidgetAction::SelectEnd) => {
                self.select_to(self.line_edge(action == Some(IbWidgetAction::SelectEnd)));
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::DeleteNextWord) => {
                self.delete_next_word();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::Paste) => {
                return self.handle_clipboard_image();
            }
            Some(IbWidgetAction::AutocompleteCancel) if self.autocomplete_active => {
                self.dismiss_autocomplete();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::AutocompleteAccept) if self.autocomplete_active => {
                if let Some(idx) = self.autocomplete_index
                    && idx < self.autocomplete_matches.len()
                {
                    let choice = self.autocomplete_matches[idx].clone();
                    self.apply_autocomplete_choice(&choice);
                    self.dismiss_autocomplete();
                }
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::HistoryPrev) if self.autocomplete_active => {
                if let Some(idx) = self.autocomplete_index {
                    self.autocomplete_index = Some(idx.saturating_sub(1));
                }
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::HistoryNext) if self.autocomplete_active => {
                if let Some(idx) = self.autocomplete_index {
                    let max = self.autocomplete_matches.len().saturating_sub(1);
                    self.autocomplete_index = Some((idx + 1).min(max));
                }
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::Submit) if self.autocomplete_active => {
                return self.accept_completion_on_submit();
            }
            Some(IbWidgetAction::NewLine) => {
                self.push_input_char('\n');
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::Submit) => {
                return self.handle_enter();
            }
            Some(IbWidgetAction::Inject) => {
                return self.handle_inject();
            }
            Some(IbWidgetAction::HistoryPrev) => {
                self.move_cursor_up();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::HistoryNext) => {
                self.move_cursor_down();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::OpenFileBrowser) => {
                let start = UserDirs::new()
                    .map(|u| u.home_dir().to_path_buf())
                    .unwrap_or_else(|| {
                        if cfg!(windows) {
                            PathBuf::from("C:\\")
                        } else {
                            PathBuf::from("/")
                        }
                    });
                self.file_explorer = Some(FileExplorerState::new(start));
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::CursorStart) => {
                self.cursor = self.line_edge(false);
                self.clear_selection();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::CursorEnd) => {
                self.cursor = self.line_edge(true);
                self.clear_selection();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::CursorLeft) => {
                self.move_cursor_left();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::CursorRight) => {
                self.move_cursor_right();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::CursorWordLeft) => {
                self.move_cursor_word_left();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::CursorWordRight) => {
                self.move_cursor_word_right();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::Backspace) => {
                self.pop_input_char();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::DeletePreviousWord) => {
                self.delete_previous_word();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::DeleteForward) => {
                self.delete_next_char();
                return InputBarAction::Consumed;
            }
            Some(IbWidgetAction::ClearInput) => {
                self.clear_input();
                return InputBarAction::Consumed;
            }
            _ => {}
        }

        if let KeyCode::Char(c) = key.code
            && !key
                .modifiers
                .intersects(KeyModifiers::CONTROL | KeyModifiers::SUPER)
        {
            self.push_input_char(c);
            return InputBarAction::Consumed;
        }

        InputBarAction::NotHandled
    }

    /// Handle bracketed paste event.
    pub fn handle_paste(&mut self, text: &str) -> InputBarAction {
        self.last_typing_at = None;
        let trimmed = text.trim();
        if clipboard::looks_like_file_path(trimmed)
            && let Ok(att) = PendingAttachment::from_path(trimmed)
        {
            let label = att.label();
            self.add_attachment(att);
            return InputBarAction::StatusMessage(crate::i18n::t_args(
                "zc-input-attached",
                &[("label", &label)],
            ));
        }
        self.insert_text(text);
        InputBarAction::Consumed
    }

    /// Handle mouse events for the input bar.
    /// Returns `true` if the event was consumed.
    pub fn handle_mouse(&mut self, mouse: MouseEvent) -> bool {
        if matches!(
            mouse.kind,
            MouseEventKind::Down(_) | MouseEventKind::Drag(_)
        ) {
            self.last_typing_at = None;
        }
        // File explorer overlay takes priority.
        if let Some(explorer) = &mut self.file_explorer {
            let action = explorer.handle_mouse(mouse);
            match action {
                ExplorerAction::Confirm(paths) => {
                    for p in paths {
                        if let Ok(att) = PendingAttachment::from_path(&p.to_string_lossy()) {
                            self.add_attachment(att);
                        }
                    }
                    self.file_explorer = None;
                }
                ExplorerAction::Cancel => {
                    self.file_explorer = None;
                }
                ExplorerAction::ConfirmDir(_) => {
                    self.file_explorer = None;
                }
                ExplorerAction::None => {}
            }
            return true;
        }

        if self.attachment_manager.is_some() {
            let first_index = self
                .attachment_manager
                .map(|manager| manager.scroll)
                .unwrap_or(0);
            match mouse.kind {
                MouseEventKind::Down(MouseButton::Left) => {
                    if let Some(index) = attachment_remove_at(
                        self.last_attachment_manager_area,
                        first_index,
                        &self.pending_attachments,
                        mouse.column,
                        mouse.row,
                    ) {
                        self.remove_attachment(index);
                    } else if let Some(index) = attachment_row_at(
                        self.last_attachment_manager_area,
                        first_index,
                        mouse.column,
                        mouse.row,
                    ) && let Some(manager) = &mut self.attachment_manager
                    {
                        manager.selected = index;
                    } else {
                        self.attachment_manager = None;
                    }
                }
                MouseEventKind::ScrollUp => self.move_attachment_selection(-1),
                MouseEventKind::ScrollDown => self.move_attachment_selection(1),
                _ => {}
            }
            return true;
        }

        if matches!(mouse.kind, MouseEventKind::Down(MouseButton::Left))
            && let Some(index) = attachment_remove_at(
                self.last_attachment_area,
                0,
                &self.pending_attachments,
                mouse.column,
                mouse.row,
            )
        {
            self.remove_attachment(index);
            return true;
        }

        if self.handle_autocomplete_mouse(mouse) {
            return true;
        }

        // Input bar interactions.
        if !mouse::in_rect(mouse.column, mouse.row, self.last_input_area) {
            return false;
        }

        let inner_x = mouse.column.saturating_sub(self.last_input_area.x + 1);
        let inner_y = mouse.row.saturating_sub(self.last_input_area.y + 1);
        let width = self.last_inner_width;

        match mouse.kind {
            MouseEventKind::Down(MouseButton::Left) => {
                if width > 0 {
                    let target_row = self.scroll_offset + inner_y;
                    self.cursor = visual_to_cursor(&self.input, target_row, inner_x, width);
                    self.selection_anchor = Some(self.cursor);
                    self.selection = None;
                }
                true
            }
            MouseEventKind::Drag(MouseButton::Left) => {
                if let Some(anchor) = self.selection_anchor
                    && width > 0
                {
                    let target_row = self.scroll_offset + inner_y;
                    let target = visual_to_cursor(&self.input, target_row, inner_x, width);
                    self.cursor = target;
                    let (start, end) = if anchor <= target {
                        (anchor, target)
                    } else {
                        (target, anchor)
                    };
                    self.selection = if start == end {
                        None
                    } else {
                        Some((start, end))
                    };
                }
                true
            }
            MouseEventKind::Up(MouseButton::Left) => {
                // Selection finalized — keep selection as-is.
                true
            }
            MouseEventKind::ScrollUp => {
                self.move_cursor_up();
                true
            }
            MouseEventKind::ScrollDown => {
                self.move_cursor_down();
                true
            }
            _ => false,
        }
    }

    // ── Private helpers ──────────────────────────────────────

    fn handle_enter(&mut self) -> InputBarAction {
        let msg = self.take_input();
        if !msg.is_empty() {
            match self.command_registry.parse(&msg) {
                SlashCommand::Attach(path) => {
                    if path.is_empty() {
                        let start = UserDirs::new()
                            .map(|u| u.home_dir().to_path_buf())
                            .unwrap_or_else(|| {
                                if cfg!(windows) {
                                    PathBuf::from("C:\\")
                                } else {
                                    PathBuf::from("/")
                                }
                            });
                        self.file_explorer = Some(FileExplorerState::new(start));
                        InputBarAction::Consumed
                    } else {
                        match PendingAttachment::from_path(path) {
                            Ok(att) => {
                                let label = att.label();
                                self.add_attachment(att);
                                InputBarAction::StatusMessage(crate::i18n::t_args(
                                    "zc-input-attached",
                                    &[("label", &label)],
                                ))
                            }
                            Err(e) => InputBarAction::StatusMessage(crate::i18n::t_args(
                                "zc-input-attach-error",
                                &[("error", &e.to_string())],
                            )),
                        }
                    }
                }
                SlashCommand::Detach(idx) => {
                    let atts = &self.pending_attachments;
                    if atts.is_empty() {
                        InputBarAction::StatusMessage(crate::i18n::t(
                            "zc-input-no-pending-attachments",
                        ))
                    } else {
                        let i = idx.unwrap_or(atts.len() - 1);
                        if i < atts.len() {
                            let name = atts[i].filename.clone();
                            self.remove_attachment(i);
                            InputBarAction::StatusMessage(crate::i18n::t_args(
                                "zc-input-detached",
                                &[("name", &name)],
                            ))
                        } else {
                            InputBarAction::StatusMessage(crate::i18n::t_args(
                                "zc-input-invalid-index",
                                &[("index", &i.to_string())],
                            ))
                        }
                    }
                }
                SlashCommand::ListAttachments => {
                    if self.pending_attachments.is_empty() {
                        InputBarAction::StatusMessage(crate::i18n::t(
                            "zc-input-no-pending-attachments",
                        ))
                    } else {
                        self.open_attachment_manager();
                        InputBarAction::Consumed
                    }
                }
                SlashCommand::ClearQueue(idx) => InputBarAction::ClearQueue(idx),
                SlashCommand::RestartSession => InputBarAction::RestartSession,
                SlashCommand::ChangeDirectory => InputBarAction::ChangeDirectory,
                SlashCommand::LoadSession(query) => InputBarAction::LoadSession(query.to_string()),
                SlashCommand::LoadSessionPicker => InputBarAction::OpenSessionPicker,
                SlashCommand::ToggleThinking => InputBarAction::ToggleThinking,
                SlashCommand::EnterBrowseMode => InputBarAction::EnterBrowseMode,
                SlashCommand::OpenHelp => InputBarAction::OpenHelp,
                SlashCommand::Model(name) => InputBarAction::SetModel(name.to_string()),
                SlashCommand::ModelPicker => InputBarAction::OpenModelPicker,
                SlashCommand::ModelProvider(name) => {
                    InputBarAction::SetModelProvider(name.to_string())
                }
                SlashCommand::ModelProviderPicker => InputBarAction::OpenModelProviderPicker,
                SlashCommand::NotACommand => {
                    let attachments = self.take_attachments();
                    InputBarAction::Submit {
                        text: Some(msg),
                        attachments,
                    }
                }
            }
        } else if !self.pending_attachments.is_empty() {
            // Empty text but has attachments: send attachments only.
            let attachments = self.take_attachments();
            InputBarAction::Submit {
                text: None,
                attachments,
            }
        } else {
            InputBarAction::ResumeQueue
        }
    }

    #[cfg(test)]
    pub(crate) fn submit_current_input_for_test(&mut self) -> InputBarAction {
        self.handle_enter()
    }

    fn handle_inject(&mut self) -> InputBarAction {
        let msg = self.take_input();
        if !msg.is_empty() {
            if matches!(self.command_registry.parse(&msg), SlashCommand::NotACommand) {
                let attachments = self.take_attachments();
                InputBarAction::Inject {
                    text: Some(msg),
                    attachments,
                }
            } else {
                self.insert_text(&msg);
                self.handle_enter()
            }
        } else if !self.pending_attachments.is_empty() {
            let attachments = self.take_attachments();
            InputBarAction::Inject {
                text: None,
                attachments,
            }
        } else {
            InputBarAction::Consumed
        }
    }

    fn handle_clipboard_image(&mut self) -> InputBarAction {
        match clipboard::read_clipboard_image() {
            Some((bytes, mime)) => {
                let ext = mime.rsplit('/').next().unwrap_or("png");
                let tmp_path = clipboard::clipboard_temp_path(ext);
                if let Err(e) = std::fs::write(&tmp_path, &bytes) {
                    return InputBarAction::StatusMessage(crate::i18n::t_args(
                        "zc-input-clipboard-error",
                        &[("error", &e.to_string())],
                    ));
                }
                match PendingAttachment::from_path(tmp_path.to_str().unwrap_or("")) {
                    Ok(mut att) => {
                        att.source = crate::attachment::AttachmentSource::Clipboard;
                        let label = att.label();
                        self.clipboard_temps.push(tmp_path);
                        self.add_attachment(att);
                        InputBarAction::StatusMessage(crate::i18n::t_args(
                            "zc-input-attached",
                            &[("label", &label)],
                        ))
                    }
                    Err(e) => {
                        self.cleanup_report.merge(remove_clipboard_temp(&tmp_path));
                        InputBarAction::StatusMessage(crate::i18n::t_args(
                            "zc-input-clipboard-error",
                            &[("error", &e.to_string())],
                        ))
                    }
                }
            }
            None => self.paste_clipboard_text(),
        }
    }

    fn handle_attachment_manager_key(&mut self, key: KeyEvent) -> InputBarAction {
        use crate::keymap::{InputBarAction as Ib, ModalAction};

        match ModalAction::from_chord(&key) {
            Some(ModalAction::Up) => self.move_attachment_selection(-1),
            Some(ModalAction::Down) => self.move_attachment_selection(1),
            Some(ModalAction::Cancel) => self.attachment_manager = None,
            _ if Ib::from_chord(&key) == Some(Ib::Backspace) || key.code == KeyCode::Delete => {
                if let Some(index) = self.attachment_manager.map(|manager| manager.selected) {
                    self.remove_attachment(index);
                }
            }
            _ => match key.code {
                KeyCode::Home => {
                    if let Some(manager) = &mut self.attachment_manager {
                        manager.selected = 0;
                        manager.scroll = 0;
                    }
                }
                KeyCode::End => {
                    if let Some(manager) = &mut self.attachment_manager {
                        manager.selected = self.pending_attachments.len().saturating_sub(1);
                    }
                }
                _ => {}
            },
        };
        InputBarAction::Consumed
    }

    fn move_attachment_selection(&mut self, delta: isize) {
        let Some(manager) = &mut self.attachment_manager else {
            return;
        };
        let last = self.pending_attachments.len().saturating_sub(1);
        manager.selected = if delta < 0 {
            manager.selected.saturating_sub(delta.unsigned_abs())
        } else {
            manager.selected.saturating_add(delta as usize).min(last)
        };
    }

    fn paste_clipboard_text(&mut self) -> InputBarAction {
        match clipboard::read_clipboard_text() {
            Some(text) => {
                // Get-Clipboard -Raw and some tools append a trailing newline.
                // Strip one trailing CRLF/LF so a one-line paste stays one
                // line; interior newlines (genuine multi-line paste) are kept.
                let text = text.strip_suffix('\n').unwrap_or(&text);
                let text = text.strip_suffix('\r').unwrap_or(text);
                self.handle_paste(text)
            }
            None => InputBarAction::StatusMessage(crate::i18n::t("zc-input-no-clipboard-image")),
        }
    }

    // ── Selection rendering helper ───────────────────────────

    fn build_input_lines(&self, width: u16) -> Vec<Line<'_>> {
        let sel_style = Style::default()
            .bg(theme::selection_bg())
            .fg(theme::fg_primary());
        let input_style = theme::input_style();

        let visual = wrap_visual_lines(&self.input, width);

        let mut lines: Vec<Line<'_>> = Vec::with_capacity(visual.len());

        for vl in &visual {
            let seg_start = vl.start;
            let seg_end = vl.end;

            let mut spans: Vec<Span<'_>> = Vec::new();

            if let Some((sel_start, sel_end)) = self.selection {
                let overlap_start = sel_start.max(seg_start);
                let overlap_end = sel_end.min(seg_end);

                if overlap_start < overlap_end {
                    if overlap_start > seg_start {
                        spans.push(Span::styled(
                            &self.input[seg_start..overlap_start],
                            input_style,
                        ));
                    }
                    spans.push(Span::styled(
                        &self.input[overlap_start..overlap_end],
                        sel_style,
                    ));
                    if overlap_end < seg_end {
                        spans.push(Span::styled(&self.input[overlap_end..seg_end], input_style));
                    }
                } else {
                    spans.push(Span::styled(&self.input[seg_start..seg_end], input_style));
                }
            } else {
                spans.push(Span::styled(&self.input[seg_start..seg_end], input_style));
            }

            lines.push(Line::from(spans));
        }

        if lines.is_empty() {
            lines.push(Line::from(""));
        }

        lines
    }

    // ── Rendering ────────────────────────────────────────────

    pub fn render(
        &mut self,
        f: &mut Frame,
        area: Rect,
        turn_in_flight: bool,
        show_cursor: bool,
        turn_status: &TurnStatus,
        turn_started_at: Instant,
        queue_paused_hint: Option<&str>,
    ) -> Rect {
        let has_attachments = !self.pending_attachments.is_empty();
        self.last_attachment_area = None;
        self.last_attachment_manager_area = None;

        // Compute dynamic input height.
        let inner_width = area.width.saturating_sub(2);
        self.last_inner_width = inner_width;
        let content_rows = if self.input.is_empty() {
            1
        } else {
            wrapped_line_count(&self.input, inner_width)
        };
        let visible_rows = content_rows.min(MAX_INPUT_ROWS);
        let input_height = visible_rows + 2; // +2 for top/bottom border

        // Clamp scroll to the valid range unconditionally so the paragraph
        // offset and the overflow arrows always reflect the same true state,
        // even on frames where the cursor-follow block below does not run
        // (e.g. an approval overlay suppresses the cursor).
        let max_scroll = content_rows.saturating_sub(visible_rows);
        self.scroll_offset = self.scroll_offset.min(max_scroll);

        let mut constraints = vec![Constraint::Min(3)];
        if has_attachments {
            let available = area.height.saturating_sub(input_height + 3).max(1);
            constraints.push(Constraint::Length(
                u16::try_from(self.pending_attachments.len())
                    .unwrap_or(u16::MAX)
                    .min(available),
            ));
        }
        constraints.push(Constraint::Length(input_height));
        let chunks = Layout::default()
            .direction(Direction::Vertical)
            .constraints(constraints)
            .split(area);

        let (conv_area, att_area, input_area) = if has_attachments {
            (chunks[0], Some(chunks[1]), chunks[2])
        } else {
            (chunks[0], None, chunks[1])
        };

        self.last_input_area = input_area;

        // Attachment bar.
        if let Some(att_rect) = att_area {
            self.last_attachment_area = Some(att_rect);
            for (row, (index, attachment)) in self
                .pending_attachments
                .iter()
                .enumerate()
                .take(att_rect.height as usize)
                .enumerate()
            {
                let row_rect = Rect::new(att_rect.x, att_rect.y + row as u16, att_rect.width, 1);
                let (main, remove_col) =
                    attachment_line(index, &attachment.label(), row_rect.width);
                let mut spans = vec![Span::styled(
                    main,
                    theme::accent_style().add_modifier(Modifier::ITALIC),
                )];
                if remove_col.is_some() {
                    spans.push(Span::styled(ATTACHMENT_REMOVE_LABEL, theme::warn_style()));
                }
                let line = Line::from(spans);
                f.render_widget(Paragraph::new(line), row_rect);
            }
        }

        let label_owned = turn_status.label(turn_started_at);
        let label: &str = &label_owned;
        let block = Block::default()
            .borders(Borders::ALL)
            .border_style(theme::dim_style())
            .title(Span::styled(label, theme::title_style()))
            .title_bottom(Span::styled("?=help", theme::dim_style()));

        if self.input.is_empty() && !turn_in_flight {
            // A paused queue takes the empty input line as ghost text in the
            // action colour, so the paused state and how to clear it are shown
            // exactly where the user would act on it.
            let (text, style) = if let Some(hint) = queue_paused_hint {
                (hint.to_string(), theme::accent_style())
            } else if self.file_explorer.is_some() {
                (String::new(), theme::dim_style())
            } else {
                (
                    crate::i18n::t("zc-input-placeholder-chat"),
                    theme::dim_style(),
                )
            };
            let p = Paragraph::new(Span::styled(text, style)).block(block);
            f.render_widget(p, input_area);
        } else {
            // Wrapped input content with optional selection highlighting.
            // Lines are pre-broken by wrap_visual_lines() — the same logic
            // that cursor_to_visual uses — so no Paragraph::wrap() is needed.
            let input_lines = self.build_input_lines(inner_width);
            let p = Paragraph::new(input_lines)
                .block(block)
                .scroll((self.scroll_offset, 0));
            f.render_widget(p, input_area);
        }

        if show_cursor
            && inner_width > 0
            && self.file_explorer.is_none()
            && self.attachment_manager.is_none()
        {
            let (cursor_row, cursor_col) = cursor_to_visual(&self.input, self.cursor, inner_width);

            if cursor_row < self.scroll_offset {
                self.scroll_offset = cursor_row;
            }
            if cursor_row >= self.scroll_offset + visible_rows {
                self.scroll_offset = cursor_row - visible_rows + 1;
            }

            let screen_row = cursor_row - self.scroll_offset;
            let cx = input_area.x + 1 + cursor_col;
            let cy = input_area.y + 1 + screen_row;
            f.set_cursor_position((cx, cy));
        }

        // Scroll indicators on the right border when content overflows.
        let (show_up, show_down) = overflow_arrows(content_rows, visible_rows, self.scroll_offset);
        if (show_up || show_down) && input_area.width > 2 {
            let indicator_x = input_area.x + input_area.width - 1;
            let indicator_style = theme::accent_style();

            if show_up {
                // Content above — show up arrow on top border.
                let buf = f.buffer_mut();
                buf[(indicator_x, input_area.y)]
                    .set_char('\u{25b2}')
                    .set_style(indicator_style);
            }
            if show_down {
                // Content below — show down arrow on bottom border.
                let buf = f.buffer_mut();
                buf[(indicator_x, input_area.y + input_area.height - 1)]
                    .set_char('\u{25bc}')
                    .set_style(indicator_style);
            }
        }

        conv_area
    }

    pub fn render_attachment_manager(&mut self, f: &mut Frame, area: Rect) {
        self.last_attachment_manager_area = None;
        let Some(manager) = &mut self.attachment_manager else {
            return;
        };
        if self.pending_attachments.is_empty() || area.width < 8 || area.height < 3 {
            return;
        }

        let visible_rows = self
            .pending_attachments
            .len()
            .min(MAX_ATTACHMENT_MANAGER_ROWS)
            .min(area.height.saturating_sub(2) as usize)
            .max(1);
        if manager.selected < manager.scroll {
            manager.scroll = manager.selected;
        } else if manager.selected >= manager.scroll + visible_rows {
            manager.scroll = manager.selected + 1 - visible_rows;
        }

        let title = crate::i18n::t_args(
            "zc-input-attachment-manager-title",
            &[("count", &self.pending_attachments.len().to_string())],
        );
        let (navigate_keys, remove_keys, close_keys) = attachment_manager_key_labels();
        let hint = crate::i18n::t_args(
            "zc-input-attachment-manager-hint",
            &[
                ("navigate", &navigate_keys.join("/")),
                ("remove", &remove_keys.join("/")),
                ("close", &close_keys.join("/")),
            ],
        );
        let labels = self
            .pending_attachments
            .iter()
            .map(PendingAttachment::label)
            .collect::<Vec<_>>();
        let desired_width = labels
            .iter()
            .enumerate()
            .map(|(index, label)| {
                crate::display_width::display_width(label) + index.to_string().len() + 10
            })
            .chain([
                crate::display_width::display_width(&title) + 4,
                crate::display_width::display_width(&hint) + 4,
            ])
            .max()
            .unwrap_or(24);
        let box_width = u16::try_from(desired_width)
            .unwrap_or(u16::MAX)
            .clamp(24.min(area.width), area.width);
        let box_height = visible_rows as u16 + 2;
        let modal = Rect::new(
            area.x + area.width.saturating_sub(box_width) / 2,
            area.y + area.height.saturating_sub(box_height) / 2,
            box_width,
            box_height,
        );
        let inner_width = modal.width.saturating_sub(2);

        let items = labels
            .iter()
            .enumerate()
            .skip(manager.scroll)
            .take(visible_rows)
            .map(|(index, label)| {
                let (main, remove_col) = attachment_line(index, label, inner_width);
                let style = if index == manager.selected {
                    theme::selected_style()
                } else {
                    theme::body_style()
                };
                let mut spans = vec![Span::styled(main, style)];
                if remove_col.is_some() {
                    spans.push(Span::styled(ATTACHMENT_REMOVE_LABEL, theme::warn_style()));
                }
                ListItem::new(Line::from(spans))
            })
            .collect::<Vec<_>>();

        let block = Block::default()
            .borders(Borders::ALL)
            .border_style(theme::overlay_border_style())
            .style(theme::fill_style())
            .title(Span::styled(format!(" {title} "), theme::heading_style()))
            .title_bottom(Span::styled(format!(" {hint} "), theme::dim_style()));
        f.render_widget(Clear, modal);
        f.render_widget(List::new(items).block(block), modal);
        self.last_attachment_manager_area = Some(Rect::new(
            modal.x + 1,
            modal.y + 1,
            inner_width,
            visible_rows as u16,
        ));

        let buf = f.buffer_mut();
        if manager.scroll > 0 {
            buf[(modal.x + modal.width - 1, modal.y)]
                .set_char('▲')
                .set_style(theme::accent_style());
        }
        if manager.scroll + visible_rows < self.pending_attachments.len() {
            buf[(modal.x + modal.width - 1, modal.y + modal.height - 1)]
                .set_char('▼')
                .set_style(theme::accent_style());
        }
    }

    /// Render the auto-complete popup above the input bar if active.
    pub fn render_autocomplete_popup(&mut self, f: &mut Frame) {
        self.last_autocomplete_area = None;
        if !self.autocomplete_active || self.autocomplete_matches.is_empty() {
            return;
        }

        let popup_height = self.autocomplete_matches.len() as u16 + 2; // +2 borders
        let popup_width = self
            .autocomplete_matches
            .iter()
            .map(|s| s.len())
            .max()
            .unwrap_or(10) as u16
            + 4; // padding

        let popup_y = self.last_input_area.y.saturating_sub(popup_height);
        let popup_x = self.last_input_area.x + 1;

        let popup_rect = Rect::new(
            popup_x,
            popup_y,
            popup_width.min(self.last_input_area.width),
            popup_height.min(self.last_input_area.y),
        );

        if popup_rect.width == 0 || popup_rect.height == 0 {
            return;
        }

        f.render_widget(Clear, popup_rect);
        self.last_autocomplete_area = Some(popup_rect);

        // A short terminal clips the popup. Scroll so the highlighted entry
        // stays in view, and draw only the visible slice.
        let visible = usize::from(popup_rect.height.saturating_sub(2)).max(1);
        let max_scroll = self.autocomplete_matches.len().saturating_sub(visible);
        if let Some(idx) = self.autocomplete_index {
            if idx < self.autocomplete_scroll {
                self.autocomplete_scroll = idx;
            } else if idx >= self.autocomplete_scroll + visible {
                self.autocomplete_scroll = idx + 1 - visible;
            }
        }
        self.autocomplete_scroll = self.autocomplete_scroll.min(max_scroll);

        let items: Vec<ListItem> = self
            .autocomplete_matches
            .iter()
            .enumerate()
            .skip(self.autocomplete_scroll)
            .take(visible)
            .map(|(i, cmd)| {
                let style = if Some(i) == self.autocomplete_index {
                    theme::selected_style()
                } else {
                    theme::body_style()
                };
                ListItem::new(Span::styled(cmd.clone(), style))
            })
            .collect();

        let fill = theme::fill_style();
        let list = List::new(items).style(fill).block(
            Block::default()
                .borders(Borders::ALL)
                .border_style(theme::dim_style())
                .style(fill)
                .title(Span::styled(" Commands ", theme::heading_style())),
        );
        f.render_widget(list, popup_rect);
    }

    /// Render the file explorer overlay on top of everything.
    pub fn render_explorer_overlay(&mut self, f: &mut Frame, area: Rect) {
        if let Some(explorer) = &mut self.file_explorer {
            explorer.render(f, area);
        }
    }
}

impl crate::widgets::HelpContext for InputBarState {
    fn help_context(&self) -> crate::widgets::HelpNode {
        use crate::widgets::{HelpEntry as E, HelpNode};
        if let Some(explorer) = &self.file_explorer {
            return explorer.help_context();
        }
        if self.attachment_manager.is_some() {
            let (navigate, remove, close) = attachment_manager_key_labels();
            return HelpNode::entries(vec![
                E::new(navigate, crate::i18n::t("zc-chat-help-navigate")),
                E::new(remove, crate::i18n::t("zc-input-help-attachment-remove")),
                E::new(close, crate::i18n::t("zc-chat-help-close")),
                E::new(
                    vec!["/detach N"],
                    crate::i18n::t("zc-input-help-attachment-detach"),
                ),
            ]);
        }
        if self.autocomplete_active {
            use crate::keymap::{InputBarAction as Ib, action_key_labels};
            // Both Enter (Submit, contextual) and the dedicated accept
            // chord (Tab by default) accept the highlighted completion —
            // advertise whatever the live registry has them bound to.
            let mut accept_keys = action_key_labels(Ib::Submit);
            accept_keys.extend(action_key_labels(Ib::AutocompleteAccept));
            return HelpNode::entries(vec![
                E::new(
                    vec!["↑", "↓"],
                    crate::i18n::t("zc-input-help-completions-navigate"),
                ),
                E::new(
                    accept_keys,
                    crate::i18n::t("zc-input-help-completions-accept"),
                ),
                E::new(
                    action_key_labels(Ib::AutocompleteCancel),
                    crate::i18n::t("zc-input-help-completions-dismiss"),
                ),
            ]);
        }
        HelpNode::entries(crate::help::help_entries::<crate::keymap::InputBarAction>())
    }
}

// ── Tests ────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use ratatui::{Terminal, backend::TestBackend};

    fn test_attachment(name: &str) -> PendingAttachment {
        PendingAttachment {
            path: PathBuf::from(name),
            mime_type: "image/png".into(),
            filename: name.into(),
            size_bytes: 1,
            source: crate::attachment::AttachmentSource::File,
        }
    }

    fn render_input_bar(bar: &mut InputBarState, width: u16, height: u16) {
        let backend = TestBackend::new(width, height);
        let mut terminal = Terminal::new(backend).expect("test terminal");
        terminal
            .draw(|frame| {
                let area = frame.area();
                bar.render(
                    frame,
                    area,
                    false,
                    false,
                    &TurnStatus::Idle,
                    Instant::now(),
                    None,
                );
                bar.render_attachment_manager(frame, area);
            })
            .expect("draw input bar");
    }

    #[test]
    fn attachment_line_preserves_visible_remove_control_when_truncated() {
        let (main, remove_col) = attachment_line(12, "a-very-long-filename.png", 20);

        assert_eq!(remove_col, Some(17));
        assert_eq!(crate::display_width::display_width(&main), 17);
        assert!(main.trim_end().ends_with('…'));
    }

    #[test]
    fn attachment_line_places_remove_control_next_to_short_label() {
        let (main, remove_col) = attachment_line(0, "one.png", 40);

        assert_eq!(main, " [0] one.png ");
        assert_eq!(remove_col, Some(13));
    }

    fn shared_commands() -> Vec<crate::wire::CommandDescriptor> {
        vec![
            crate::wire::CommandDescriptor {
                id: "help".into(),
                name: "help".into(),
                aliases: vec![],
            },
            crate::wire::CommandDescriptor {
                id: "new".into(),
                name: "new".into(),
                aliases: vec!["new-session".into()],
            },
            crate::wire::CommandDescriptor {
                id: "model".into(),
                name: "model".into(),
                aliases: vec![],
            },
        ]
    }

    fn command_registry() -> SlashCommandRegistry {
        SlashCommandRegistry::new(&shared_commands())
    }

    fn parse_slash_command(input: &str) -> SlashCommand<'_> {
        command_registry().parse(input)
    }

    fn input_bar_with_shared_commands() -> InputBarState {
        InputBarState::with_shared_commands(&shared_commands())
    }

    #[test]
    fn replacement_undo_restores_graphemes_cursor_and_selection() {
        let mut bar = input_bar_with_shared_commands();
        let original = "a e\u{301}👩‍💻 z";
        bar.load_for_edit(original.into(), vec![test_attachment("image.png")]);
        bar.cursor = 2;
        bar.select_to(original.len() - 2);
        let selection = bar.selection;
        let cursor = bar.cursor;
        bar.handle_paste("replacement");
        assert_eq!(bar.input(), "a replacement z");
        bar.undo();
        assert_eq!(bar.input(), original);
        assert_eq!(bar.selection, selection);
        assert_eq!(bar.selection_anchor, Some(2));
        assert_eq!(bar.cursor, cursor);
        bar.redo();
        assert_eq!(bar.input(), "a replacement z");
        assert_eq!(bar.selection, None);
        assert_eq!(bar.pending_attachments().len(), 1);
        bar.undo();
        bar.clear_input();
        bar.undo();
        assert_eq!(bar.input(), original);
        assert_eq!(bar.pending_attachments().len(), 1);
    }

    #[test]
    fn typing_groups_keep_prior_text_and_break_after_idle() {
        let _guard = crate::keymap::overrides::TEST_GUARD
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        crate::keymap::overrides::reset();
        let mut bar = input_bar_with_shared_commands();
        bar.load_for_edit("existing ".into(), Vec::new());
        for c in "several new words e\u{301}👩‍💻".chars() {
            bar.handle_key(KeyEvent::new(KeyCode::Char(c), KeyModifiers::NONE));
        }
        let typed = bar.input().to_owned();
        bar.handle_key(KeyEvent::new(KeyCode::Char('z'), KeyModifiers::CONTROL));
        assert_eq!(bar.input(), "existing ");
        bar.redo();
        assert_eq!(bar.input(), typed);

        bar.push_input_char('!');
        bar.last_typing_at = Some(Instant::now() - TYPING_GROUP_IDLE);
        bar.push_input_char('?');
        bar.undo();
        assert_eq!(bar.input(), format!("{typed}!"));
        bar.undo();
        assert_eq!(bar.input(), typed, "typing after redo starts a new group");
    }

    #[test]
    fn typing_groups_end_on_navigation_and_atomic_edits() {
        let mut bar = input_bar_with_shared_commands();
        bar.load_for_edit("original ".into(), Vec::new());
        for c in "first run".chars() {
            bar.push_input_char(c);
        }
        bar.move_cursor_left();
        bar.move_cursor_right();
        for c in " second run".chars() {
            bar.push_input_char(c);
        }
        bar.undo();
        assert_eq!(bar.input(), "original first run");
        bar.push_input_char('!');
        bar.redo();
        assert_eq!(bar.input(), "original first run!");
        bar.undo();
        assert_eq!(bar.input(), "original first run");

        bar.insert_text(" pasted");
        bar.push_input_char('x');
        bar.pop_input_char();
        bar.push_input_char('y');
        bar.undo();
        assert_eq!(bar.input(), "original first run pasted");
        bar.undo();
        assert_eq!(bar.input(), "original first run pastedx");
        bar.undo();
        assert_eq!(bar.input(), "original first run pasted");
        bar.undo();
        assert_eq!(bar.input(), "original first run");
        bar.undo();
        assert_eq!(bar.input(), "original ");
    }

    #[test]
    fn typed_replacement_groups_restore_selection_without_reusing_noop_history() {
        let mut bar = input_bar_with_shared_commands();
        bar.load_for_edit("old e\u{301}👩‍💻".into(), Vec::new());
        bar.select_to(0);
        let original_selection = bar.selection;
        for c in "new words".chars() {
            bar.push_input_char(c);
        }
        bar.undo();
        assert_eq!(bar.input(), "old e\u{301}👩‍💻");
        assert_eq!(bar.selection, original_selection);
        bar.redo();
        assert_eq!(bar.input(), "new words");

        bar.select_to(bar.input.len() - 1);
        bar.push_input_char('s'); // Same text, but the selection is consumed.
        bar.push_input_char('!');
        bar.undo();
        assert_eq!(
            bar.input(),
            "new words",
            "do not undo the older replacement"
        );
        bar.select_to(bar.input.len() - 1);
        bar.push_input_char('s');
        bar.redo();
        assert_eq!(
            bar.input(),
            "new words",
            "same-text replacement discards redo"
        );
    }

    #[test]
    fn mouse_click_at_cursor_ends_typing_group() {
        let mut bar = input_bar_with_shared_commands();
        bar.load_for_edit("old ".into(), Vec::new());
        bar.push_input_char('x');
        render_input_bar(&mut bar, 40, 12);
        let area = bar.last_input_area;
        assert!(bar.handle_mouse(MouseEvent {
            kind: MouseEventKind::Down(MouseButton::Left),
            column: area.x + 1 + bar.cursor() as u16,
            row: area.y + 1,
            modifiers: KeyModifiers::NONE,
        }));
        bar.push_input_char('y');
        bar.undo();
        assert_eq!(bar.input(), "old x");
        bar.undo();
        assert_eq!(bar.input(), "old ");
    }

    #[test]
    fn history_is_bounded_and_movement_does_not_invalidate_redo() {
        let mut bar = input_bar_with_shared_commands();
        for _ in 0..MAX_EDIT_HISTORY + 1 {
            bar.insert_text("x");
        }
        for _ in 0..MAX_EDIT_HISTORY + 1 {
            bar.undo();
        }
        assert_eq!(bar.input(), "x", "evict only complete oldest edits");
        bar.move_cursor_left();
        bar.redo();
        assert_eq!(bar.input(), "xx");
        bar.undo();
        bar.push_input_char('y');
        let edited = bar.input().to_owned();
        bar.redo();
        assert_eq!(
            bar.input(),
            edited,
            "a new edit discards the old redo branch"
        );
        assert_eq!(bar.undo.len() + bar.redo.len(), 1);
    }

    #[test]
    fn draft_boundaries_do_not_resurrect_previous_text() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("submitted");
        assert_eq!(bar.take_input(), "submitted");
        bar.undo();
        assert!(bar.input().is_empty());
        bar.insert_text("discarded");
        bar.reset();
        bar.undo();
        assert!(bar.input().is_empty());
        bar.insert_text("previous draft");
        bar.undo();
        bar.load_for_edit("queued draft".into(), Vec::new());
        bar.undo();
        bar.redo();
        assert_eq!(bar.input(), "queued draft");
    }

    #[test]
    fn completion_is_atomic_but_submitting_completion_resets_history() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/mod");
        assert!(matches!(
            bar.accept_completion_on_submit(),
            InputBarAction::Consumed
        ));
        assert_eq!(bar.input(), "/model ");
        bar.undo();
        assert_eq!(bar.input(), "/mod");
        assert!(bar.autocomplete_active);
        bar.redo();
        assert_eq!(bar.input(), "/model ");
        bar.load_for_edit("/hel".into(), Vec::new());
        bar.update_autocomplete();
        assert!(matches!(
            bar.accept_completion_on_submit(),
            InputBarAction::OpenHelp
        ));
        bar.undo();
        assert!(bar.input().is_empty());
    }

    #[test]
    fn failed_copy_and_cut_preserve_selected_draft_and_consume_keys() {
        let _guard = crate::keymap::overrides::TEST_GUARD
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        crate::keymap::overrides::reset();
        for key in ['c', 'x'] {
            let mut bar = input_bar_with_shared_commands();
            bar.load_for_edit("selected draft".into(), Vec::new());
            bar.selection = Some((0, bar.input.len()));
            bar.selection_anchor = Some(0);
            let error = std::io::Error::new(std::io::ErrorKind::BrokenPipe, "writer rejected copy");
            let expected = clipboard::copy_failure_notice(&error);
            let action = clipboard::with_copy_result(Err(error), || {
                bar.handle_key(KeyEvent::new(KeyCode::Char(key), KeyModifiers::CONTROL))
            });
            assert!(
                matches!(action, InputBarAction::StatusMessage(message) if message == expected)
            );
            assert_eq!(bar.input(), "selected draft");
            assert_eq!(bar.selection, Some((0, bar.input.len())));
            assert_eq!(bar.selection_anchor, Some(0));
        }
    }

    #[test]
    fn terminal_requested_cut_reports_delivery_and_remains_undoable() {
        let _guard = crate::keymap::overrides::TEST_GUARD
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        crate::keymap::overrides::reset();
        let mut bar = input_bar_with_shared_commands();
        bar.load_for_edit("selected draft".into(), Vec::new());
        bar.selection = Some((0, bar.input.len()));
        bar.selection_anchor = Some(0);
        let outcome = clipboard::CopyOutcome::TerminalRequested;
        let action = clipboard::with_copy_result(Ok(outcome), || {
            bar.handle_key(KeyEvent::new(KeyCode::Char('x'), KeyModifiers::CONTROL))
        });
        assert!(
            matches!(action, InputBarAction::StatusMessage(message) if message == outcome.notice())
        );
        assert!(bar.input().is_empty());
        bar.undo();
        assert_eq!(bar.input(), "selected draft");
        assert_eq!(bar.selection, Some((0, bar.input.len())));
    }

    #[test]
    fn keyboard_selection_cut_and_undo_use_resolved_actions() {
        let _guard = crate::keymap::overrides::TEST_GUARD
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        crate::keymap::overrides::reset();
        let mut bar = input_bar_with_shared_commands();
        bar.load_for_edit("e\u{301}👩‍💻".into(), Vec::new());
        bar.handle_key(KeyEvent::new(KeyCode::Left, KeyModifiers::SHIFT));
        assert_eq!(bar.selection, Some((3, bar.input.len())));
        bar.handle_key(KeyEvent::new(KeyCode::Right, KeyModifiers::SHIFT));
        assert!(!bar.has_selection());
        bar.handle_key(KeyEvent::new(KeyCode::Char('a'), KeyModifiers::CONTROL));
        assert_eq!(bar.selection, Some((0, bar.input.len())));
        assert!(!bar.has_file_explorer());
        bar.handle_key(KeyEvent::new(KeyCode::Char('x'), KeyModifiers::CONTROL));
        assert_eq!(bar.input(), "");
        bar.handle_key(KeyEvent::new(KeyCode::Char('z'), KeyModifiers::CONTROL));
        assert_eq!(bar.input(), "e\u{301}👩‍💻");
        assert!(bar.has_selection());
        bar.handle_key(KeyEvent::new(
            KeyCode::Char('Z'),
            KeyModifiers::CONTROL | KeyModifiers::SHIFT,
        ));
        assert_eq!(bar.input(), "");
        bar.undo();
        bar.handle_key(KeyEvent::new(
            KeyCode::Char('z'),
            crate::keymap::Chord::primary('z').effective_modifiers() | KeyModifiers::SHIFT,
        ));
        assert_eq!(
            bar.input(),
            "",
            "enhanced lowercase shifted events also redo"
        );
    }

    #[test]
    fn explicit_input_binding_replaces_selection_default_and_claim() {
        use crate::keymap::{Chord, InputBarAction as KeymapInputBarAction, overrides};

        let _guard = overrides::TEST_GUARD
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        overrides::reset();
        let key = KeyEvent::new(KeyCode::Left, KeyModifiers::SHIFT);
        overrides::set_row(
            KeymapInputBarAction::TAG,
            "cursor_left",
            vec![Chord::shift(KeyCode::Left)],
        );
        let mut bar = InputBarState::with_shared_commands(&[]);
        bar.insert_text("draft");
        assert_eq!(
            KeymapInputBarAction::from_chord(&key),
            Some(KeymapInputBarAction::CursorLeft)
        );
        assert!(!bar.claims_edit_key(&key));

        overrides::reset();
        overrides::set_row(KeymapInputBarAction::TAG, "copy_selection", Vec::new());
        let mut bar = InputBarState::with_shared_commands(&[]);
        bar.insert_text("draft");
        bar.handle_key(KeyEvent::new(KeyCode::Char('a'), KeyModifiers::CONTROL));
        assert!(bar.has_selection());
        let copy = KeyEvent::new(KeyCode::Char('c'), KeyModifiers::CONTROL);
        assert!(!bar.claims_edit_key(&copy));
        assert!(matches!(bar.handle_key(copy), InputBarAction::NotHandled));
        overrides::reset();
    }

    #[test]
    fn keyboard_selection_uses_visual_rows_and_word_boundaries() {
        let _guard = crate::keymap::overrides::TEST_GUARD
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        crate::keymap::overrides::reset();
        let mut bar = input_bar_with_shared_commands();
        bar.load_for_edit("hello world\nnext".into(), Vec::new());
        bar.last_inner_width = 20;
        bar.handle_key(KeyEvent::new(KeyCode::Home, KeyModifiers::SHIFT));
        assert_eq!(bar.selection, Some((12, 16)));
        bar.handle_key(KeyEvent::new(KeyCode::Up, KeyModifiers::SHIFT));
        assert_eq!(bar.selection, Some((0, 16)));
        bar.handle_key(KeyEvent::new(KeyCode::Down, KeyModifiers::SHIFT));
        assert_eq!(bar.selection, Some((12, 16)));
        bar.handle_key(KeyEvent::new(KeyCode::End, KeyModifiers::SHIFT));
        assert!(!bar.has_selection());
        bar.move_cursor_word_left();
        bar.handle_key(KeyEvent::new(
            KeyCode::Left,
            KeyModifiers::ALT | KeyModifiers::SHIFT,
        ));
        assert_eq!(
            &bar.input[bar.selection.unwrap().0..bar.selection.unwrap().1],
            "world\n"
        );
        bar.move_cursor_left();
        let original = bar.input.clone();
        bar.handle_key(KeyEvent::new(KeyCode::Delete, KeyModifiers::ALT));
        assert_ne!(bar.input(), original);
        bar.undo();
        assert_eq!(bar.input(), original);
    }

    #[test]
    fn input_append_and_take() {
        let mut bar = input_bar_with_shared_commands();
        bar.push_input_char('h');
        bar.push_input_char('i');
        assert_eq!(bar.input(), "hi");
        let taken = bar.take_input();
        assert_eq!(taken, "hi");
        assert_eq!(bar.input(), "");
        assert_eq!(bar.cursor(), 0);
    }

    #[test]
    fn clear_input_empties_text_and_resets_cursor() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");
        assert_eq!(bar.cursor(), 11);
        bar.clear_input();
        assert_eq!(bar.input(), "");
        assert_eq!(bar.cursor(), 0);
    }

    #[test]
    fn primary_u_clears_input() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("scratch this");
        let act = bar.handle_key(KeyEvent::new(
            KeyCode::Char('u'),
            crate::keymap::Chord::primary('u').effective_modifiers(),
        ));
        assert!(matches!(act, InputBarAction::Consumed));
        assert_eq!(bar.input(), "");
    }

    #[test]
    fn unbound_super_modified_character_falls_through_without_typing() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();

        let action = bar.handle_key(KeyEvent::new(KeyCode::Char('p'), KeyModifiers::SUPER));

        assert!(matches!(action, InputBarAction::NotHandled));
        assert_eq!(bar.input(), "");
    }

    #[test]
    fn primary_w_deletes_previous_word() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");
        let action = bar.handle_key(KeyEvent::new(
            KeyCode::Char('w'),
            crate::keymap::Chord::primary('w').effective_modifiers(),
        ));
        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "hello ");
        assert_eq!(bar.cursor(), 6);
    }

    #[test]
    fn alt_backspace_deletes_previous_word() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");

        let action = bar.handle_key(KeyEvent::new(KeyCode::Backspace, KeyModifiers::ALT));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "hello ");
        assert_eq!(bar.cursor(), 6);
    }

    #[test]
    fn plain_backspace_still_deletes_one_grapheme() {
        // The word-delete chord differs from Backspace only by ALT, so an
        // over-permissive match would silently turn every Backspace into a
        // word delete.
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");

        let action = bar.handle_key(KeyEvent::new(KeyCode::Backspace, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "hello worl");
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn plain_delete_removes_the_grapheme_after_the_cursor() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");
        bar.move_cursor_left();
        bar.move_cursor_left();

        let action = bar.handle_key(KeyEvent::new(KeyCode::Delete, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        // Cursor sits between the two `l`s after two steps back from the end.
        assert_eq!(bar.input(), "hello word");
        assert_eq!(bar.cursor(), "hello wor".len());
    }

    #[test]
    fn plain_delete_at_the_end_of_the_input_is_a_no_op() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello");

        let action = bar.handle_key(KeyEvent::new(KeyCode::Delete, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "hello");
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn plain_delete_removes_the_selection_when_one_is_active() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");
        bar.selection = Some((6, 11));

        let action = bar.handle_key(KeyEvent::new(KeyCode::Delete, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "hello ");
        assert!(bar.selection.is_none());
        assert_eq!(bar.cursor(), "hello ".len());
    }

    #[test]
    fn plain_delete_removes_whole_grapheme_clusters() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("🇺x🇸");
        bar.cursor = "🇺".len();

        let action = bar.handle_key(KeyEvent::new(KeyCode::Delete, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        // The two regional indicators rejoin into one cluster, so the cursor
        // has to be renormalized onto the new boundary.
        assert_eq!(bar.input(), "🇺🇸");
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn alt_backspace_deletes_the_selection_when_one_is_active() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");
        bar.selection = Some((6, 11));

        let action = bar.handle_key(KeyEvent::new(KeyCode::Backspace, KeyModifiers::ALT));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "hello ");
        assert!(bar.selection.is_none());
    }

    #[test]
    fn alt_backspace_normalizes_cursor_after_joining_emoji_graphemes() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("🇺x🇸");
        bar.move_cursor_left();

        let action = bar.handle_key(KeyEvent::new(KeyCode::Backspace, KeyModifiers::ALT));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "🇺🇸");
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn alt_arrows_move_by_word_without_changing_input() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("alpha  beta");

        assert!(matches!(
            bar.handle_key(KeyEvent::new(KeyCode::Left, KeyModifiers::ALT)),
            InputBarAction::Consumed
        ));
        assert_eq!(bar.input(), "alpha  beta");
        assert_eq!(bar.cursor(), 7);

        assert!(matches!(
            bar.handle_key(KeyEvent::new(KeyCode::Right, KeyModifiers::ALT)),
            InputBarAction::Consumed
        ));
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn alt_b_and_f_move_by_unicode_word() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello 世界");

        bar.handle_key(KeyEvent::new(KeyCode::Char('b'), KeyModifiers::ALT));
        assert_eq!(bar.cursor(), "hello ".len());
        bar.handle_key(KeyEvent::new(KeyCode::Char('f'), KeyModifiers::ALT));
        assert_eq!(bar.cursor(), bar.input().len());
        assert_eq!(bar.input(), "hello 世界");
    }

    #[test]
    fn insertion_normalizes_cursor_after_joining_emoji_graphemes() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("👩👩");
        bar.move_cursor_left();
        bar.push_input_char('\u{200d}');

        assert_eq!(bar.input(), "👩\u{200d}👩");
        assert_eq!(bar.cursor(), bar.input().len());
        bar.pop_input_char();
        assert_eq!(bar.input(), "");
        assert_eq!(bar.cursor(), 0);
    }

    #[test]
    fn backspace_normalizes_cursor_after_joining_emoji_graphemes() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("🇺x🇸");
        bar.move_cursor_left();

        let action = bar.handle_key(KeyEvent::new(KeyCode::Backspace, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "🇺🇸");
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn delete_previous_word_normalizes_cursor_after_joining_emoji_graphemes() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("🇺x🇸");
        bar.move_cursor_left();

        let action = bar.handle_key(KeyEvent::new(
            KeyCode::Char('w'),
            crate::keymap::Chord::primary('w').effective_modifiers(),
        ));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "🇺🇸");
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn backspace_normalizes_cursor_after_joining_emoji_graphemes_with_selection() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("🇺x🇸");
        let selection_start = "🇺".len();
        bar.selection = Some((selection_start, selection_start + 1));

        let action = bar.handle_key(KeyEvent::new(KeyCode::Backspace, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "🇺🇸");
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn delete_previous_word_normalizes_cursor_after_joining_emoji_graphemes_with_selection() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("🇺x🇸");
        let selection_start = "🇺".len();
        bar.selection = Some((selection_start, selection_start + 1));

        let action = bar.handle_key(KeyEvent::new(
            KeyCode::Char('w'),
            crate::keymap::Chord::primary('w').effective_modifiers(),
        ));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "🇺🇸");
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn file_explorer_does_not_claim_word_navigation_chords() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("alpha beta");
        let word_left = KeyEvent::new(KeyCode::Left, KeyModifiers::ALT);
        assert!(bar.claims_pane_navigation(&word_left));

        bar.file_explorer = Some(FileExplorerState::new(std::path::PathBuf::from("/tmp")));
        assert!(!bar.claims_pane_navigation(&word_left));
    }

    #[test]
    fn primary_w_deletes_trailing_space_and_word() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world   ");
        bar.handle_key(KeyEvent::new(
            KeyCode::Char('w'),
            crate::keymap::Chord::primary('w').effective_modifiers(),
        ));
        assert_eq!(bar.input(), "hello ");
        assert_eq!(bar.cursor(), 6);
    }

    #[test]
    fn primary_w_deletes_word_before_cursor() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello brave world");
        for _ in 0..5 {
            bar.move_cursor_left();
        }
        bar.handle_key(KeyEvent::new(
            KeyCode::Char('w'),
            crate::keymap::Chord::primary('w').effective_modifiers(),
        ));
        assert_eq!(bar.input(), "hello world");
        assert_eq!(bar.cursor(), 6);
    }

    #[test]
    fn primary_w_deletes_selection() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");
        bar.selection = Some((6, 11));
        bar.handle_key(KeyEvent::new(
            KeyCode::Char('w'),
            crate::keymap::Chord::primary('w').effective_modifiers(),
        ));
        assert_eq!(bar.input(), "hello ");
        assert_eq!(bar.cursor(), 6);
    }

    #[test]
    fn primary_w_deletes_punctuation_run_like_vim() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world...");
        bar.handle_key(KeyEvent::new(
            KeyCode::Char('w'),
            crate::keymap::Chord::primary('w').effective_modifiers(),
        ));
        assert_eq!(bar.input(), "hello world");
        assert_eq!(bar.cursor(), 11);
    }

    #[test]
    fn primary_w_deletes_word_after_punctuation_like_vim() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello-world");
        bar.handle_key(KeyEvent::new(
            KeyCode::Char('w'),
            crate::keymap::Chord::primary('w').effective_modifiers(),
        ));
        assert_eq!(bar.input(), "hello-");
        assert_eq!(bar.cursor(), 6);
    }

    #[test]
    fn primary_w_deletes_only_whitespace_before_cursor() {
        use crossterm::event::{KeyCode, KeyEvent};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("   ");
        bar.handle_key(KeyEvent::new(
            KeyCode::Char('w'),
            crate::keymap::Chord::primary('w').effective_modifiers(),
        ));
        assert_eq!(bar.input(), "");
        assert_eq!(bar.cursor(), 0);
    }

    #[test]
    fn backspace_at_start_is_noop() {
        let mut bar = input_bar_with_shared_commands();
        bar.pop_input_char();
        assert_eq!(bar.input(), "");
    }

    #[test]
    fn cursor_movement() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("abc");
        assert_eq!(bar.cursor(), 3);
        bar.move_cursor_left();
        assert_eq!(bar.cursor(), 2);
        bar.move_cursor_left();
        assert_eq!(bar.cursor(), 1);
        bar.move_cursor_right();
        assert_eq!(bar.cursor(), 2);
    }

    #[test]
    fn insert_text_at_cursor() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello");
        bar.move_cursor_left();
        bar.move_cursor_left();
        bar.insert_text("XX");
        assert_eq!(bar.input(), "helXXlo");
    }

    #[test]
    fn append_text_at_end_populates_empty_draft_without_separator() {
        let mut bar = input_bar_with_shared_commands();

        assert!(bar.append_text_at_end("> selected"));
        assert_eq!(bar.input(), "> selected");
        assert_eq!(bar.cursor(), bar.input().len());
    }

    #[test]
    fn append_text_at_end_preserves_draft_selection_attachments_and_unicode_cursor() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("draft 世界");
        bar.move_cursor_left();
        bar.selection = Some((0, "draft".len()));
        bar.add_attachment(PendingAttachment {
            path: PathBuf::from("keep.png"),
            mime_type: "image/png".to_string(),
            filename: "keep.png".to_string(),
            size_bytes: 4,
            source: crate::attachment::AttachmentSource::File,
        });

        assert!(bar.append_text_at_end("> 引用\n> \n> é"));
        assert_eq!(bar.input(), "draft 世界\n\n> 引用\n> \n> é");
        assert_eq!(bar.cursor(), bar.input().len());
        assert!(bar.selection.is_none());
        assert_eq!(bar.pending_attachments().len(), 1);
        assert_eq!(bar.pending_attachments()[0].filename, "keep.png");
    }

    #[test]
    fn append_text_at_end_is_separate_from_typing_in_undo_history() {
        let mut bar = input_bar_with_shared_commands();
        bar.load_for_edit("saved ".into(), Vec::new());
        for c in "draft".chars() {
            bar.push_input_char(c);
        }

        assert!(bar.append_text_at_end("> selected"));
        bar.push_input_char('!');
        bar.undo();
        assert_eq!(bar.input(), "saved draft\n\n> selected");
        bar.undo();
        assert_eq!(bar.input(), "saved draft");
        bar.redo();
        assert_eq!(bar.input(), "saved draft\n\n> selected");
        bar.undo();
        bar.undo();
        assert_eq!(bar.input(), "saved ");
    }

    #[test]
    fn append_text_at_end_invalidates_stale_redo() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("draft");
        bar.insert_text(" abandoned");
        bar.undo();
        assert_eq!(bar.input(), "draft");

        assert!(bar.append_text_at_end("> selected"));
        bar.redo();
        assert_eq!(bar.input(), "draft\n\n> selected");
        bar.undo();
        assert_eq!(bar.input(), "draft");
        bar.redo();
        assert_eq!(bar.input(), "draft\n\n> selected");
    }

    #[test]
    fn wants_text_input_when_typing() {
        let mut bar = input_bar_with_shared_commands();
        assert!(!bar.wants_text_input());
        bar.push_input_char('a');
        assert!(bar.wants_text_input());
    }

    #[test]
    fn reset_clears_everything() {
        let mut bar = input_bar_with_shared_commands();
        bar.push_input_char('x');
        bar.reset();
        assert_eq!(bar.input(), "");
        assert_eq!(bar.cursor(), 0);
        assert!(bar.pending_attachments().is_empty());
        assert!(!bar.has_file_explorer());
    }

    #[test]
    fn taking_attachments_releases_clipboard_temp_ownership() {
        let mut bar = input_bar_with_shared_commands();
        let tmp = std::env::temp_dir().join("zc_test_clip_release.png");
        std::fs::write(&tmp, b"x").unwrap();
        bar.clipboard_temps.push(tmp.clone());
        bar.add_attachment(PendingAttachment {
            path: tmp.clone(),
            mime_type: "image/png".into(),
            filename: "clip.png".into(),
            size_bytes: 1,
            source: crate::attachment::AttachmentSource::Clipboard,
        });

        let taken = bar.take_attachments();
        assert_eq!(taken.len(), 1);
        assert!(bar.clipboard_temps().is_empty());

        bar.cleanup_temps();
        assert!(tmp.exists(), "queued clipboard temp must survive cleanup");
        std::fs::remove_file(&tmp).ok();
    }

    #[test]
    fn removing_clipboard_attachment_deletes_owned_temp() {
        let mut bar = input_bar_with_shared_commands();
        let tmp = std::env::temp_dir().join("zc_test_clip_remove.png");
        std::fs::write(&tmp, b"x").unwrap();
        bar.clipboard_temps.push(tmp.clone());
        bar.add_attachment(PendingAttachment {
            path: tmp.clone(),
            mime_type: "image/png".into(),
            filename: "clip.png".into(),
            size_bytes: 1,
            source: crate::attachment::AttachmentSource::Clipboard,
        });

        bar.remove_attachment(0);

        assert!(bar.pending_attachments().is_empty());
        assert!(bar.clipboard_temps().is_empty());
        assert!(!tmp.exists());
    }

    #[test]
    fn removing_clipboard_attachment_surfaces_failed_cleanup() {
        let dir = tempfile::tempdir().expect("temp dir");
        let mut bar = input_bar_with_shared_commands();
        bar.clipboard_temps.push(dir.path().to_path_buf());
        bar.add_attachment(PendingAttachment {
            path: dir.path().to_path_buf(),
            mime_type: "image/png".into(),
            filename: "clip.png".into(),
            size_bytes: 0,
            source: crate::attachment::AttachmentSource::Clipboard,
        });

        bar.remove_attachment(0);

        assert!(bar.pending_attachments().is_empty());
        assert!(bar.clipboard_temps().is_empty());
        assert_eq!(bar.take_cleanup_report().failed_count(), 1);
        assert!(
            dir.path().exists(),
            "failed cleanup must leave the path visible"
        );
    }

    #[test]
    fn removing_file_attachment_preserves_user_file() {
        let dir = tempfile::tempdir().expect("temp dir");
        let path = dir.path().join("user-file.png");
        std::fs::write(&path, b"x").expect("write user file");
        let mut bar = input_bar_with_shared_commands();
        bar.add_attachment(PendingAttachment {
            path: path.clone(),
            mime_type: "image/png".into(),
            filename: "user-file.png".into(),
            size_bytes: 1,
            source: crate::attachment::AttachmentSource::File,
        });

        bar.remove_attachment(0);

        assert!(bar.pending_attachments().is_empty());
        assert!(
            path.exists(),
            "removal must not delete a user-selected file"
        );
    }

    #[test]
    fn slash_attachments_opens_indexed_manager() {
        let mut bar = input_bar_with_shared_commands();
        bar.add_attachment(test_attachment("one.png"));
        bar.add_attachment(test_attachment("two.png"));
        bar.insert_text("/attachments");

        let action = bar.handle_enter();

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "");
        assert_eq!(bar.attachment_manager.as_ref().map(|m| m.selected), Some(0));
    }

    #[test]
    fn attachment_manager_delete_removes_selected_item() {
        let mut bar = input_bar_with_shared_commands();
        bar.add_attachment(test_attachment("one.png"));
        bar.add_attachment(test_attachment("two.png"));
        bar.open_attachment_manager();

        bar.handle_key(KeyEvent::new(KeyCode::Down, KeyModifiers::NONE));
        let action = bar.handle_key(KeyEvent::new(KeyCode::Delete, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.pending_attachments().len(), 1);
        assert_eq!(bar.pending_attachments()[0].filename, "one.png");
        assert_eq!(bar.attachment_manager.as_ref().map(|m| m.selected), Some(0));
    }

    #[test]
    fn attachment_manager_backspace_removes_last_item_and_closes() {
        let mut bar = input_bar_with_shared_commands();
        bar.add_attachment(test_attachment("one.png"));
        bar.open_attachment_manager();

        let action = bar.handle_key(KeyEvent::new(KeyCode::Backspace, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        assert!(bar.pending_attachments().is_empty());
        assert!(bar.attachment_manager.is_none());
    }

    #[test]
    fn attachment_manager_escape_closes_without_removing() {
        let mut bar = input_bar_with_shared_commands();
        bar.add_attachment(test_attachment("one.png"));
        bar.open_attachment_manager();

        let action = bar.handle_key(KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.pending_attachments().len(), 1);
        assert!(bar.attachment_manager.is_none());
    }

    #[test]
    fn attachment_manager_claims_text_input() {
        let mut bar = input_bar_with_shared_commands();
        bar.add_attachment(test_attachment("one.png"));
        bar.open_attachment_manager();

        assert!(bar.wants_text_input());
    }

    #[test]
    fn attachment_remove_control_click_removes_target_item() {
        let mut bar = input_bar_with_shared_commands();
        bar.add_attachment(test_attachment("one.png"));
        bar.add_attachment(test_attachment("two.png"));
        render_input_bar(&mut bar, 40, 12);
        let area = bar.last_attachment_area.expect("attachment rows rendered");

        let consumed = bar.handle_mouse(MouseEvent {
            kind: MouseEventKind::Down(MouseButton::Left),
            column: area.x + area.width - 2,
            row: area.y + 1,
            modifiers: KeyModifiers::NONE,
        });

        assert!(!consumed);
        assert_eq!(bar.pending_attachments().len(), 2);

        let (_, remove_col) = attachment_line(1, &bar.pending_attachments()[1].label(), area.width);

        let consumed = bar.handle_mouse(MouseEvent {
            kind: MouseEventKind::Down(MouseButton::Left),
            column: area.x + remove_col.expect("remove control rendered"),
            row: area.y + 1,
            modifiers: KeyModifiers::NONE,
        });

        assert!(consumed);
        assert_eq!(bar.pending_attachments().len(), 1);
        assert_eq!(bar.pending_attachments()[0].filename, "one.png");
    }

    #[test]
    fn attachment_manager_scrolled_remove_control_removes_visible_item() {
        let mut bar = input_bar_with_shared_commands();
        for index in 0..10 {
            bar.add_attachment(test_attachment(&format!("item-{index}.png")));
        }
        bar.open_attachment_manager();
        for _ in 0..9 {
            bar.handle_key(KeyEvent::new(KeyCode::Down, KeyModifiers::NONE));
        }
        render_input_bar(&mut bar, 60, 16);

        let manager = bar.attachment_manager.as_ref().expect("manager open");
        assert_eq!(manager.selected, 9);
        assert_eq!(manager.scroll, 2);
        let area = bar
            .last_attachment_manager_area
            .expect("attachment manager rendered");
        let (_, remove_col) = attachment_line(9, &bar.pending_attachments()[9].label(), area.width);

        let consumed = bar.handle_mouse(MouseEvent {
            kind: MouseEventKind::Down(MouseButton::Left),
            column: area.x + remove_col.expect("remove control rendered"),
            row: area.y + 7,
            modifiers: KeyModifiers::NONE,
        });

        assert!(consumed);
        assert_eq!(bar.pending_attachments().len(), 9);
        assert!(
            bar.pending_attachments()
                .iter()
                .all(|attachment| attachment.filename != "item-9.png")
        );
    }

    #[test]
    fn loading_for_edit_retakes_clipboard_temp_ownership() {
        let mut bar = input_bar_with_shared_commands();
        let tmp = std::env::temp_dir().join("zc_test_clip_retake.png");
        let att = PendingAttachment {
            path: tmp.clone(),
            mime_type: "image/png".into(),
            filename: "clip.png".into(),
            size_bytes: 1,
            source: crate::attachment::AttachmentSource::Clipboard,
        };
        bar.load_for_edit("edit".into(), vec![att]);
        assert!(bar.clipboard_temps().contains(&tmp));
    }

    #[test]
    fn slash_attach_empty_opens_explorer() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/attach");
        let action = bar.handle_enter();
        assert!(bar.has_file_explorer());
        assert!(matches!(action, InputBarAction::Consumed));
    }

    #[test]
    fn slash_detach_no_attachments() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/detach");
        let action = bar.handle_enter();
        let expected = crate::i18n::t("zc-input-no-pending-attachments");
        assert!(matches!(action, InputBarAction::StatusMessage(ref m) if *m == expected));
    }

    #[test]
    fn empty_enter_resumes_queue() {
        let mut bar = input_bar_with_shared_commands();
        // Empty input, no attachments -> ResumeQueue: a deliberate Enter must
        // never be silently swallowed; the parent uses it to unpause.
        assert!(matches!(bar.handle_enter(), InputBarAction::ResumeQueue));
    }

    #[test]
    fn submit_with_text() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");
        let action = bar.handle_enter();
        match action {
            InputBarAction::Submit { text, attachments } => {
                assert_eq!(text, Some("hello world".to_string()));
                assert!(attachments.is_empty());
            }
            _ => panic!("expected Submit"),
        }
    }

    #[test]
    fn parse_slash_commands() {
        assert!(matches!(
            parse_slash_command("/attach"),
            SlashCommand::Attach("")
        ));
        assert!(matches!(
            parse_slash_command("/attach /tmp/x.png"),
            SlashCommand::Attach("/tmp/x.png")
        ));
        assert!(matches!(
            parse_slash_command("/detach"),
            SlashCommand::Detach(None)
        ));
        assert!(matches!(
            parse_slash_command("/detach 2"),
            SlashCommand::Detach(Some(2))
        ));
        assert!(matches!(
            parse_slash_command("/attachments"),
            SlashCommand::ListAttachments
        ));
        assert!(matches!(
            parse_slash_command("/clear-queue"),
            SlashCommand::ClearQueue(None)
        ));
        assert!(matches!(
            parse_slash_command("/clear-queue 2"),
            SlashCommand::ClearQueue(Some(2))
        ));
        assert!(matches!(
            parse_slash_command("/clear-queue xyz"),
            SlashCommand::ClearQueue(Some(0))
        ));
        assert!(matches!(
            parse_slash_command("/restart-session"),
            SlashCommand::RestartSession
        ));
        assert!(matches!(
            parse_slash_command("/new-session"),
            SlashCommand::RestartSession
        ));
        assert!(matches!(
            parse_slash_command("/new"),
            SlashCommand::RestartSession
        ));
        assert!(matches!(
            parse_slash_command("/change-directory"),
            SlashCommand::ChangeDirectory
        ));
        assert!(matches!(
            parse_slash_command("/change-directory /tmp/project"),
            SlashCommand::NotACommand
        ));
        assert!(matches!(
            parse_slash_command("/toggle-thinking"),
            SlashCommand::ToggleThinking
        ));
        assert!(matches!(
            parse_slash_command("/browse"),
            SlashCommand::EnterBrowseMode
        ));
        assert!(matches!(
            parse_slash_command("/help"),
            SlashCommand::OpenHelp
        ));
        assert!(matches!(
            parse_slash_command("hello"),
            SlashCommand::NotACommand
        ));
    }

    #[test]
    fn parse_model_commands() {
        assert!(matches!(
            parse_slash_command("/model"),
            SlashCommand::ModelPicker
        ));
        assert!(matches!(
            parse_slash_command("/model "),
            SlashCommand::ModelPicker
        ));
        assert!(matches!(
            parse_slash_command("/model gpt-4o"),
            SlashCommand::Model("gpt-4o")
        ));
        assert!(matches!(
            parse_slash_command("/model-provider"),
            SlashCommand::ModelProviderPicker
        ));
        assert!(matches!(
            parse_slash_command("/model-provider anthropic.default"),
            SlashCommand::ModelProvider("anthropic.default")
        ));
        // `/model-provider` must NOT be parsed as `/model` with arg "-provider".
        assert!(!matches!(
            parse_slash_command("/model-provider"),
            SlashCommand::Model(_)
        ));
    }

    #[test]
    fn derived_slash_command_set_matches_expected_entries() {
        let expected: Vec<&str> = vec![
            "/attach",
            "/attachments",
            "/browse",
            "/change-directory",
            "/clear-queue",
            "/detach",
            "/help",
            "/load-session",
            "/model",
            "/model-provider",
            "/new",
            "/new-session",
            "/restart-session",
            "/toggle-thinking",
        ];
        let registry = command_registry();
        let derived: Vec<&str> = registry.command_names().collect();
        assert_eq!(derived, expected);
    }

    /// Parity guard: every command the derived descriptor set advertises
    /// must be recognized by `parse_slash_command` (advertise ⊆ recognize).
    #[test]
    fn every_advertised_command_is_recognized_by_parser() {
        let registry = command_registry();
        for command in registry.command_names() {
            assert!(
                !matches!(registry.parse(command), SlashCommand::NotACommand),
                "{command} is advertised but not recognized by parse_slash_command"
            );
        }
    }

    /// Parity guard: unknown leading tokens are rejected (recognize ⊆
    /// advertise), and each real token maps to its specific expected
    /// variant — a silently dropped descriptor entry breaks this test.
    #[test]
    fn parser_rejects_unknown_tokens_and_matches_specific_variants() {
        assert!(matches!(
            parse_slash_command("/definitely-not-a-command"),
            SlashCommand::NotACommand
        ));
        assert!(matches!(
            parse_slash_command("/helper"),
            SlashCommand::NotACommand
        ));
        assert!(matches!(
            parse_slash_command("/attach"),
            SlashCommand::Attach("")
        ));
        assert!(matches!(
            parse_slash_command("/attachments"),
            SlashCommand::ListAttachments
        ));
        assert!(matches!(
            parse_slash_command("/browse"),
            SlashCommand::EnterBrowseMode
        ));
        assert!(matches!(
            parse_slash_command("/clear-queue"),
            SlashCommand::ClearQueue(None)
        ));
        assert!(matches!(
            parse_slash_command("/detach"),
            SlashCommand::Detach(None)
        ));
        assert!(matches!(
            parse_slash_command("/help"),
            SlashCommand::OpenHelp
        ));
        assert!(matches!(
            parse_slash_command("/model"),
            SlashCommand::ModelPicker
        ));
        assert!(matches!(
            parse_slash_command("/model-provider"),
            SlashCommand::ModelProviderPicker
        ));
        assert!(matches!(
            parse_slash_command("/new"),
            SlashCommand::RestartSession
        ));
        assert!(matches!(
            parse_slash_command("/new-session"),
            SlashCommand::RestartSession
        ));
        assert!(matches!(
            parse_slash_command("/restart-session"),
            SlashCommand::RestartSession
        ));
        assert!(matches!(
            parse_slash_command("/toggle-thinking"),
            SlashCommand::ToggleThinking
        ));
    }

    #[test]
    fn autocomplete_for_bare_slash_returns_exactly_the_derived_set() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/");
        assert!(bar.autocomplete_active);
        let mut matches = bar.autocomplete_matches.clone();
        matches.sort();
        let expected: Vec<String> = command_registry()
            .command_names()
            .map(str::to_string)
            .collect();
        assert_eq!(matches, expected);
    }

    #[test]
    fn model_arg_autocomplete_filters_cached_catalog() {
        let mut bar = input_bar_with_shared_commands();
        bar.set_model_catalog(
            "anthropic.default".into(),
            vec![
                "claude-sonnet-4-6".into(),
                "claude-opus-4".into(),
                "gpt-4o".into(),
            ],
        );
        bar.insert_text("/model claude");
        assert!(bar.autocomplete_active);
        assert_eq!(bar.autocomplete_target, AutocompleteTarget::ModelArg);
        assert!(
            bar.autocomplete_matches
                .iter()
                .any(|s| s == "claude-opus-4")
        );
        assert!(!bar.autocomplete_matches.iter().any(|s| s == "gpt-4o"));
    }

    #[test]
    fn model_arg_empty_lists_whole_catalog() {
        let mut bar = input_bar_with_shared_commands();
        bar.set_model_catalog("anthropic.default".into(), vec!["a".into(), "b".into()]);
        bar.insert_text("/model ");
        assert!(bar.autocomplete_active);
        assert_eq!(bar.autocomplete_matches.len(), 2);
    }

    #[test]
    fn provider_arg_autocomplete_filters_cached_catalog() {
        let mut bar = input_bar_with_shared_commands();
        bar.set_provider_catalog(vec![
            "anthropic".into(),
            "openai".into(),
            "openrouter".into(),
        ]);
        bar.insert_text("/model-provider open");
        assert!(bar.autocomplete_active);
        assert_eq!(
            bar.autocomplete_target,
            AutocompleteTarget::ModelProviderArg
        );
        assert!(bar.autocomplete_matches.iter().any(|s| s == "openai"));
        assert!(bar.autocomplete_matches.iter().any(|s| s == "openrouter"));
        assert!(!bar.autocomplete_matches.iter().any(|s| s == "anthropic"));
    }

    #[test]
    fn model_command_autocomplete_appends_space() {
        let mut bar = input_bar_with_shared_commands();
        bar.apply_autocomplete_choice("/model");
        assert_eq!(bar.input(), "/model ");
    }

    #[test]
    fn model_arg_autocomplete_rewrites_only_arg() {
        let mut bar = input_bar_with_shared_commands();
        bar.autocomplete_target = AutocompleteTarget::ModelArg;
        bar.apply_autocomplete_choice("claude-opus-4");
        assert_eq!(bar.input(), "/model claude-opus-4");
    }

    #[test]
    fn model_picker_command_returns_open_action() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/model");
        assert!(matches!(
            bar.handle_enter(),
            InputBarAction::OpenModelPicker
        ));
    }

    #[test]
    fn enter_accepts_highlighted_model_arg_and_submits() {
        let mut bar = input_bar_with_shared_commands();
        bar.set_model_catalog(
            "anthropic.default".into(),
            vec!["claude-opus-4-8".into(), "claude-sonnet-4-6".into()],
        );
        bar.insert_text("/model ");
        assert!(bar.autocomplete_active);
        let action = bar.handle_key(KeyEvent::from(KeyCode::Enter));
        // First catalog entry is accepted and the line is submitted in one
        // keystroke — no picker modal.
        assert!(matches!(action, InputBarAction::SetModel(m) if m == "claude-opus-4-8"));
        assert!(!bar.autocomplete_active);
    }

    #[test]
    fn enter_on_model_command_completion_fills_without_submitting() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/mod");
        assert!(bar.autocomplete_active);
        let action = bar.handle_key(KeyEvent::from(KeyCode::Enter));
        // `/model` still needs an argument: accept-and-fill, do not open the
        // picker or submit.
        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "/model ");
    }

    #[test]
    fn parse_load_session_with_and_without_argument() {
        assert!(matches!(
            parse_slash_command("/load-session"),
            SlashCommand::LoadSessionPicker
        ));
        assert!(matches!(
            parse_slash_command("/load-session   "),
            SlashCommand::LoadSessionPicker
        ));
        assert!(matches!(
            parse_slash_command("/load-session 9f3a"),
            SlashCommand::LoadSession("9f3a")
        ));
        assert!(matches!(
            parse_slash_command("/load-session   my  session  "),
            SlashCommand::LoadSession("my  session")
        ));
    }

    #[test]
    fn load_session_submit_maps_to_actions() {
        let mut bar = input_bar_with_shared_commands();
        bar.load_for_edit("/load-session release notes".into(), Vec::new());
        bar.dismiss_autocomplete();
        let action = bar.handle_key(KeyEvent::from(KeyCode::Enter));
        assert!(matches!(action, InputBarAction::LoadSession(q) if q == "release notes"));

        bar.load_for_edit("/load-session".into(), Vec::new());
        bar.dismiss_autocomplete();
        let action = bar.handle_key(KeyEvent::from(KeyCode::Enter));
        assert!(matches!(action, InputBarAction::OpenSessionPicker));
    }

    #[test]
    fn enter_on_load_session_completion_fills_without_submitting() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/load-s");
        assert!(bar.autocomplete_active);
        let action = bar.handle_key(KeyEvent::from(KeyCode::Enter));
        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "/load-session ");
        assert!(
            !bar.autocomplete_active,
            "/load-session has no argument completion"
        );
    }

    #[test]
    fn second_enter_after_load_session_completion_opens_the_picker() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/load-s");
        assert!(matches!(
            bar.handle_key(KeyEvent::from(KeyCode::Enter)),
            InputBarAction::Consumed
        ));
        assert_eq!(bar.input(), "/load-session ");
        assert!(matches!(
            bar.handle_key(KeyEvent::from(KeyCode::Enter)),
            InputBarAction::OpenSessionPicker
        ));
    }

    #[test]
    fn enter_accepts_highlighted_provider_arg_and_submits() {
        let mut bar = input_bar_with_shared_commands();
        bar.set_provider_catalog(vec!["openai".into(), "openrouter".into()]);
        bar.insert_text("/model-provider open");
        assert!(bar.autocomplete_active);
        let action = bar.handle_key(KeyEvent::from(KeyCode::Enter));
        assert!(matches!(action, InputBarAction::SetModelProvider(p) if p == "openai"));
        assert!(!bar.autocomplete_active);
    }

    #[test]
    fn completion_help_keys_come_from_keymap_registry() {
        use crate::keymap::{Chord, InputBarAction as Ib, action_key_labels};
        use crate::widgets::HelpContext;
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/mod");
        assert!(bar.autocomplete_active);
        let node = bar.help_context();
        let accept = node
            .entries
            .iter()
            .find(|e| e.action == crate::i18n::t("zc-input-help-completions-accept"))
            .expect("accept entry present");
        // Labels track the live bindings for Submit + AutocompleteAccept,
        // not hardcoded literals.
        assert!(accept.keys.contains(&Chord::key(KeyCode::Tab).display()));
        let mut expected = action_key_labels(Ib::Submit);
        expected.extend(action_key_labels(Ib::AutocompleteAccept));
        assert_eq!(accept.keys, expected);
    }

    #[test]
    fn help_context_keeps_slash_commands_out_of_general_help() {
        use crate::widgets::HelpContext;
        let bar = input_bar_with_shared_commands();
        let node = bar.help_context();
        let listed = node
            .entries
            .iter()
            .chain(node.children.iter().flat_map(|child| child.entries.iter()))
            .map(|entry| entry.key_str())
            .collect::<Vec<_>>();
        for command in bar.command_registry.command_names() {
            assert!(
                !listed.iter().any(|key| key == command),
                "{command} stays in autocomplete, not the general Help modal"
            );
        }
    }

    #[test]
    fn model_provider_picker_command_returns_open_action() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/model-provider");
        assert!(matches!(
            bar.handle_enter(),
            InputBarAction::OpenModelProviderPicker
        ));
    }

    #[test]
    fn browse_command_returns_enter_browse_action() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/browse");
        assert!(matches!(
            bar.handle_enter(),
            InputBarAction::EnterBrowseMode
        ));
    }

    #[test]
    fn help_command_returns_open_help_action() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/help");
        assert!(matches!(bar.handle_enter(), InputBarAction::OpenHelp));
    }

    #[test]
    fn model_command_with_arg_returns_set_action() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/model gpt-4o");
        match bar.handle_enter() {
            InputBarAction::SetModel(m) => assert_eq!(m, "gpt-4o"),
            _ => panic!("expected SetModel"),
        }
    }

    #[test]
    fn paste_text_inserts() {
        let mut bar = input_bar_with_shared_commands();
        let action = bar.handle_paste("some pasted text");
        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "some pasted text");
    }

    // ── Wrap geometry tests ──────────────────────────────────

    #[test]
    fn overflow_arrows_none_when_fits() {
        assert_eq!(overflow_arrows(3, 5, 0), (false, false));
        assert_eq!(overflow_arrows(5, 5, 0), (false, false));
    }

    #[test]
    fn overflow_arrows_down_only_at_top() {
        // 10 rows, window 5, scrolled to top: more below, none above.
        assert_eq!(overflow_arrows(10, 5, 0), (false, true));
    }

    #[test]
    fn overflow_arrows_both_in_middle() {
        assert_eq!(overflow_arrows(10, 5, 2), (true, true));
    }

    #[test]
    fn overflow_arrows_up_only_at_bottom() {
        // max_scroll = 10 - 5 = 5; at offset 5 nothing remains below.
        assert_eq!(overflow_arrows(10, 5, 5), (true, false));
    }

    #[test]
    fn wrapped_line_count_empty() {
        assert_eq!(wrapped_line_count("", 20), 1);
    }

    #[test]
    fn wrapped_line_count_short() {
        assert_eq!(wrapped_line_count("hello", 20), 1);
    }

    #[test]
    fn wrapped_line_count_exact_width() {
        assert_eq!(wrapped_line_count("12345", 5), 1);
    }

    #[test]
    fn wrapped_line_count_overflow() {
        assert_eq!(wrapped_line_count("123456", 5), 2);
        assert_eq!(wrapped_line_count("1234567890", 5), 2);
        assert_eq!(wrapped_line_count("12345678901", 5), 3);
    }

    #[test]
    fn wrapped_line_count_with_newlines() {
        assert_eq!(wrapped_line_count("abc\ndef", 20), 2);
        assert_eq!(wrapped_line_count("abc\n\ndef", 20), 3);
        assert_eq!(wrapped_line_count("12345\n678901", 5), 3); // 1 + 2
    }

    #[test]
    fn wrapped_line_count_word_wraps_like_paragraph() {
        assert_eq!(wrapped_line_count("hello world", 10), 2);
    }

    #[test]
    fn copy_wrapping_whitespace_matches_ratatui_for_nbsp_and_zwsp() {
        assert!(!grapheme_is_whitespace("\u{00a0}"));
        assert!(grapheme_is_whitespace("\u{200b}"));
    }

    #[test]
    fn wrapped_line_count_zero_width() {
        assert_eq!(wrapped_line_count("hello", 0), 1);
    }

    #[test]
    fn cursor_to_visual_basic() {
        // "hello" with width 10 — cursor at end is (0, 5).
        assert_eq!(cursor_to_visual("hello", 5, 10), (0, 5));
        // Cursor at start.
        assert_eq!(cursor_to_visual("hello", 0, 10), (0, 0));
        // Cursor in middle.
        assert_eq!(cursor_to_visual("hello", 3, 10), (0, 3));
    }

    #[test]
    fn cursor_to_visual_wrap() {
        // "1234567890" with width 5 — wraps at col 5.
        // Cursor at byte 5 (char '6') should be row 1, col 0.
        assert_eq!(cursor_to_visual("1234567890", 5, 5), (1, 0));
        // Cursor at byte 7 should be row 1, col 2.
        assert_eq!(cursor_to_visual("1234567890", 7, 5), (1, 2));
    }

    #[test]
    fn cursor_to_visual_word_wrap() {
        assert_eq!(
            cursor_to_visual("hello world", "hello world".len(), 10),
            (1, 5)
        );
    }

    #[test]
    fn cursor_to_visual_uses_terminal_cell_width() {
        let text = "abcd界";
        assert_eq!(cursor_to_visual(text, text.len(), 5), (1, 2));
    }

    #[test]
    fn cursor_to_visual_emoji_presentation_is_two_cells() {
        // 🏔️ is U+1F3D4 + U+FE0F. unicode-width string width is 2; char-wise
        // sum of the base alone is 1 and leaves the cursor one cell short.
        let emoji = "\u{1F3D4}\u{FE0F}";
        let text = format!("{emoji}x");
        assert_eq!(cursor_to_visual(&text, text.len(), 10), (0, 3));
        assert_eq!(str_cell_width(emoji), 2);
        assert_eq!(str_cell_width(&format!("{emoji} ")), 3);
    }

    #[test]
    fn cursor_to_visual_text_default_presentation_sequence_is_two_cells() {
        // ⚠️ is text-default ⚠ + VS16. Scalar loops that cannot see FE0F would
        // count base width 1 + selector 0 and leave the cursor short.
        let emoji = "\u{26A0}\u{FE0F}";
        let text = format!("{emoji}x");
        assert_eq!(str_cell_width(emoji), 2);
        assert_eq!(cursor_to_visual(&text, text.len(), 10), (0, 3));
        // Bare text form stays width 1.
        let bare = "\u{26A0}x";
        assert_eq!(str_cell_width("\u{26A0}"), 1);
        assert_eq!(cursor_to_visual(bare, bare.len(), 10), (0, 2));
    }

    #[test]
    fn hard_wrap_keeps_text_default_presentation_sequence_together() {
        // Width 2 must not split ⚠️ across lines; the sequence is one unit.
        let emoji = "\u{26A0}\u{FE0F}";
        let text = format!("ab{emoji}cd");
        let lines = wrap_visual_lines(&text, 2);
        assert_eq!(lines.len(), 3);
        assert_eq!(&text[lines[0].start..lines[0].end], "ab");
        assert_eq!(&text[lines[1].start..lines[1].end], emoji);
        assert_eq!(&text[lines[2].start..lines[2].end], "cd");
        assert_eq!(lines[1].width, 2);
    }

    #[test]
    fn visual_to_cursor_text_default_presentation_sequence() {
        // Reverse mapping must land on grapheme boundaries for ⚠️.
        let emoji = "\u{26A0}\u{FE0F}";
        let text = format!("a{emoji}b");
        // col 0 -> 'a', col 1/2 -> start of ⚠️, col 3 -> 'b'
        assert_eq!(visual_to_cursor(&text, 0, 0, 10), 0);
        assert_eq!(visual_to_cursor(&text, 0, 1, 10), 1);
        assert_eq!(visual_to_cursor(&text, 0, 2, 10), 1);
        assert_eq!(visual_to_cursor(&text, 0, 3, 10), text.len() - 1);
        assert_eq!(cursor_to_visual(&text, text.len(), 10), (0, 4));
    }

    #[test]
    fn cursor_to_visual_newline() {
        // "abc\ndef" — cursor after \n (byte 4, char 'd') is (1, 0).
        assert_eq!(cursor_to_visual("abc\ndef", 4, 20), (1, 0));
        // Cursor at 'f' (byte 6) is (1, 2).
        assert_eq!(cursor_to_visual("abc\ndef", 6, 20), (1, 2));
    }

    #[test]
    fn visual_to_cursor_basic() {
        assert_eq!(visual_to_cursor("hello", 0, 0, 10), 0);
        assert_eq!(visual_to_cursor("hello", 0, 3, 10), 3);
        assert_eq!(visual_to_cursor("hello", 0, 5, 10), 5);
    }

    #[test]
    fn visual_to_cursor_wrap() {
        // "1234567890" width 5 — row 1, col 0 = byte 5.
        assert_eq!(visual_to_cursor("1234567890", 1, 0, 5), 5);
        assert_eq!(visual_to_cursor("1234567890", 1, 2, 5), 7);
    }

    #[test]
    fn visual_to_cursor_word_wrap() {
        assert_eq!(
            visual_to_cursor("hello world", 1, 5, 10),
            "hello world".len()
        );
    }

    #[test]
    fn visual_to_cursor_newline() {
        // "abc\ndef" — row 1, col 0 = byte 4 ('d').
        assert_eq!(visual_to_cursor("abc\ndef", 1, 0, 20), 4);
        assert_eq!(visual_to_cursor("abc\ndef", 1, 2, 20), 6);
    }

    #[test]
    fn cursor_visual_round_trip() {
        let text = "hello world this is a test";
        let width: u16 = 10;
        for cursor in 0..=text.len() {
            if !text.is_char_boundary(cursor) {
                continue;
            }
            let (row, col) = cursor_to_visual(text, cursor, width);
            let recovered = visual_to_cursor(text, row, col, width);
            assert_eq!(
                recovered, cursor,
                "round-trip failed for cursor={cursor} -> ({row},{col}) -> {recovered}"
            );
        }
    }

    #[test]
    fn cursor_visual_round_trip_with_newlines() {
        let text = "abc\ndefgh\nij";
        let width: u16 = 4;
        for cursor in 0..=text.len() {
            if !text.is_char_boundary(cursor) {
                continue;
            }
            let (row, col) = cursor_to_visual(text, cursor, width);
            let recovered = visual_to_cursor(text, row, col, width);
            assert_eq!(
                recovered, cursor,
                "round-trip failed for cursor={cursor} -> ({row},{col}) -> {recovered}"
            );
        }
    }

    // ── Auto-complete tests ──────────────────────────────────

    /// Draw the bar in the lower rows of a terminal and the completion popup
    /// above it, the way the chat pane does.
    fn render_bar_with_popup(bar: &mut InputBarState) {
        let backend = TestBackend::new(60, 20);
        let mut terminal = Terminal::new(backend).expect("test terminal");
        terminal
            .draw(|frame| {
                let area = Rect::new(0, 16, 60, 4);
                bar.render(
                    frame,
                    area,
                    false,
                    false,
                    &TurnStatus::Idle,
                    Instant::now(),
                    None,
                );
                bar.render_autocomplete_popup(frame);
            })
            .expect("draw input bar");
    }

    fn left_click(column: u16, row: u16) -> MouseEvent {
        MouseEvent {
            kind: MouseEventKind::Down(MouseButton::Left),
            column,
            row,
            modifiers: KeyModifiers::NONE,
        }
    }

    #[test]
    fn composer_claims_completion_keys_only_while_the_popup_is_open() {
        let mut bar = input_bar_with_shared_commands();
        let tab = KeyEvent::new(KeyCode::Tab, KeyModifiers::NONE);
        let esc = KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE);

        bar.insert_text("hello");
        assert!(!bar.autocomplete_active);
        assert!(!bar.claims_edit_key(&tab));
        assert!(!bar.claims_edit_key(&esc));

        bar.clear_input();
        bar.insert_text("/");
        assert!(bar.autocomplete_active);
        assert!(bar.claims_edit_key(&tab));
        assert!(bar.claims_edit_key(&esc));
    }

    #[test]
    fn clicking_an_autocomplete_row_fills_that_command() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/");
        assert!(bar.autocomplete_matches.len() >= 2);
        let second = bar.autocomplete_matches[1].clone();
        render_bar_with_popup(&mut bar);
        let area = bar.last_autocomplete_area.expect("popup rendered");

        // Row 0 is the top border; row 2 is the second entry.
        assert!(bar.handle_mouse(left_click(area.x + 2, area.y + 2)));

        assert_eq!(bar.input(), second);
        assert!(!bar.autocomplete_active);
    }

    #[test]
    fn clicking_the_autocomplete_border_keeps_the_popup_open() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/");
        render_bar_with_popup(&mut bar);
        let area = bar.last_autocomplete_area.expect("popup rendered");

        assert!(bar.handle_mouse(left_click(area.x + 2, area.y)));

        assert_eq!(bar.input(), "/");
        assert!(bar.autocomplete_active);
    }

    #[test]
    fn scrolling_over_autocomplete_moves_the_highlight() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/");
        render_bar_with_popup(&mut bar);
        let area = bar.last_autocomplete_area.expect("popup rendered");
        let scroll = |kind| MouseEvent {
            kind,
            column: area.x + 2,
            row: area.y + 1,
            modifiers: KeyModifiers::NONE,
        };

        assert!(bar.handle_mouse(scroll(MouseEventKind::ScrollDown)));
        assert_eq!(bar.autocomplete_index, Some(1));
        assert!(bar.handle_mouse(scroll(MouseEventKind::ScrollUp)));
        assert_eq!(bar.autocomplete_index, Some(0));
    }

    /// Draw the bar at the bottom of a short terminal, so the popup is
    /// clipped to fewer rows than there are matches, and return the buffer.
    fn render_short_popup(bar: &mut InputBarState) -> ratatui::buffer::Buffer {
        let backend = TestBackend::new(60, 8);
        let mut terminal = Terminal::new(backend).expect("test terminal");
        terminal
            .draw(|frame| {
                bar.render(
                    frame,
                    Rect::new(0, 4, 60, 4),
                    false,
                    false,
                    &TurnStatus::Idle,
                    Instant::now(),
                    None,
                );
                bar.render_autocomplete_popup(frame);
            })
            .expect("draw input bar");
        terminal.backend().buffer().clone()
    }

    fn row_text(buffer: &ratatui::buffer::Buffer, area: Rect, row: u16) -> String {
        (area.x..area.right())
            .map(|x| buffer[(x, row)].symbol().to_string())
            .collect()
    }

    #[test]
    fn clipped_autocomplete_scrolls_to_keep_the_highlight_visible() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/");
        let count = bar.autocomplete_matches.len();
        render_short_popup(&mut bar);
        let area = bar.last_autocomplete_area.expect("popup rendered");
        let visible = usize::from(area.height - 2);
        assert!(
            visible >= 2 && count > visible + 1,
            "need a clipped popup: {visible} rows for {count} matches"
        );

        // Move the highlight one past the last row the popup can show.
        let target = visible;
        let down = KeyEvent::new(KeyCode::Down, KeyModifiers::NONE);
        for _ in 0..target {
            bar.handle_key(down);
        }
        assert_eq!(bar.autocomplete_index, Some(target));
        let buffer = render_short_popup(&mut bar);
        let selected = bar.autocomplete_matches[target].clone();
        let last_row = area.y + area.height - 2;
        let shown = row_text(&buffer, area, last_row);
        assert!(
            shown.contains(&format!("{selected} ")) || shown.trim_end().ends_with(&selected),
            "highlighted {selected:?} must be on the last visible row, got {shown:?}"
        );

        // A click on the first visible row picks the scrolled-to entry,
        // not the first match.
        let first_visible = bar.autocomplete_matches[1].clone();
        assert!(bar.handle_mouse(left_click(area.x + 2, area.y + 1)));
        assert_eq!(bar.input(), first_visible);
    }

    #[test]
    fn closed_autocomplete_does_not_capture_clicks() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/");
        render_bar_with_popup(&mut bar);
        let area = bar.last_autocomplete_area.expect("popup rendered");
        bar.insert_text(" ");
        assert!(!bar.autocomplete_active);
        render_bar_with_popup(&mut bar);
        assert_eq!(bar.last_autocomplete_area, None);

        assert!(!bar.handle_mouse(left_click(area.x + 2, area.y + 2)));
        assert_eq!(bar.input(), "/ ");
    }

    #[test]
    fn autocomplete_triggers_on_slash() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/a");
        assert!(bar.autocomplete_active);
        assert!(!bar.autocomplete_matches.is_empty());
    }

    #[test]
    fn autocomplete_partial_prefix_matches() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/attach");
        // "/attach" is a prefix of "/attachments", so popup shows.
        assert!(bar.autocomplete_active);
        assert!(bar.autocomplete_matches.iter().any(|s| s == "/attachments"));
        // "/attach" itself is excluded (exact match).
        assert!(!bar.autocomplete_matches.iter().any(|s| s == "/attach"));
    }

    #[test]
    fn autocomplete_exact_no_popup() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/attachments");
        // Exact match with no further completions — no popup.
        assert!(!bar.autocomplete_active);
    }

    #[test]
    fn autocomplete_off_with_space() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/attach foo");
        // Space present — autocomplete disabled.
        assert!(!bar.autocomplete_active);
    }

    #[test]
    fn autocomplete_off_for_non_slash() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello");
        assert!(!bar.autocomplete_active);
    }

    #[test]
    fn autocomplete_toggle_thinking_prefix() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/toggle");
        assert!(bar.autocomplete_active);
        assert!(
            bar.autocomplete_matches
                .iter()
                .any(|s| s == "/toggle-thinking")
        );
    }

    #[test]
    fn autocomplete_restart_session_prefix() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/restart");
        assert!(bar.autocomplete_active);
        assert!(
            bar.autocomplete_matches
                .iter()
                .any(|s| s == "/restart-session")
        );
    }

    #[test]
    fn autocomplete_new_session_alias() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/ne");
        assert!(bar.autocomplete_active);
        assert!(bar.autocomplete_matches.iter().any(|s| s == "/new"));
        assert!(bar.autocomplete_matches.iter().any(|s| s == "/new-session"));
    }

    #[test]
    fn slash_toggle_thinking_returns_action() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/toggle-thinking");
        let action = bar.handle_enter();
        assert!(matches!(action, InputBarAction::ToggleThinking));
        // Input should be cleared after submission.
        assert_eq!(bar.input(), "");
    }

    #[test]
    fn slash_restart_session_returns_action() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/restart-session");
        let action = bar.handle_enter();
        assert!(matches!(action, InputBarAction::RestartSession));
        assert_eq!(bar.input(), "");
    }

    #[test]
    fn slash_change_directory_returns_action() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/change-directory");
        assert!(matches!(
            bar.handle_enter(),
            InputBarAction::ChangeDirectory
        ));
        assert_eq!(bar.input(), "");
    }

    #[test]
    fn slash_new_alias_returns_restart_session_action() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("/new");
        let action = bar.handle_enter();
        assert!(matches!(action, InputBarAction::RestartSession));
        assert_eq!(bar.input(), "");
    }

    // ── Selection tests ──────────────────────────────────────

    #[test]
    fn build_input_lines_no_selection() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello");
        let lines = bar.build_input_lines(80);
        assert_eq!(lines.len(), 1);
    }

    #[test]
    fn build_input_lines_with_newlines() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello\nworld\nfoo");
        let lines = bar.build_input_lines(80);
        assert_eq!(lines.len(), 3);
    }

    #[test]
    fn build_input_lines_with_selection() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");
        bar.selection = Some((2, 7));
        let lines = bar.build_input_lines(80);
        // Single line, 3 spans: "he" + "llo w" (selected) + "orld"
        assert_eq!(lines.len(), 1);
        assert_eq!(lines[0].spans.len(), 3);
    }

    #[test]
    fn delete_selection_removes_range() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello world");
        bar.selection = Some((2, 7));
        bar.delete_selection();
        assert_eq!(bar.input(), "heorld");
        assert_eq!(bar.cursor(), 2);
    }

    #[test]
    fn backspace_with_selection_deletes_selection() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello");
        bar.selection = Some((1, 4));
        bar.pop_input_char();
        assert_eq!(bar.input(), "ho");
        assert_eq!(bar.cursor(), 1);
    }

    #[test]
    fn typing_with_selection_replaces() {
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("hello");
        bar.selection = Some((1, 4));
        bar.push_input_char('X');
        assert_eq!(bar.input(), "hXo");
        assert_eq!(bar.cursor(), 2);
    }

    #[test]
    fn typing_over_unicode_selection_preserves_replacement_position() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        let mut bar = input_bar_with_shared_commands();
        bar.insert_text("🇺x🇸");
        let selection_start = "🇺".len();
        bar.selection = Some((selection_start, selection_start + 1));

        let action = bar.handle_key(KeyEvent::new(KeyCode::Char('y'), KeyModifiers::NONE));

        assert!(matches!(action, InputBarAction::Consumed));
        assert_eq!(bar.input(), "🇺y🇸");
        assert_eq!(bar.cursor(), selection_start + 1);
    }

    // ── Dynamic height tests ─────────────────────────────────

    #[test]
    fn dynamic_height_single_line() {
        let content_rows = wrapped_line_count("hello", 40);
        let visible = content_rows.min(MAX_INPUT_ROWS);
        assert_eq!(visible + 2, 3); // 1 content row + 2 borders
    }

    #[test]
    fn dynamic_height_capped() {
        // 100 chars at width 10 = 10 rows, capped to MAX_INPUT_ROWS.
        let text = "a".repeat(100);
        let content_rows = wrapped_line_count(&text, 10);
        assert_eq!(content_rows, 10);
        let visible = content_rows.min(MAX_INPUT_ROWS);
        assert_eq!(visible + 2, 7); // 5 content rows + 2 borders
    }
}
