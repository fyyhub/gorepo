zc-pane-dashboard = Dashboard
zc-pane-config = Config
zc-pane-doctor = Doctor
zc-pane-code = Code
zc-pane-chat = Chat
zc-pane-logs = Logs
zc-pane-quickstart = Quickstart
zc-pane-sop = SOPs
zc-sop-empty-read-only = (no nodes)
zc-sop-runs-stale = SOP run status is stale. Retrying…
zc-chrome-summary-sessions = sessions
zc-chrome-summary-ram = ram
zc-chrome-summary-cpu = cpu
zc-chrome-summary-loading = loading

zc-app-help-cycle-mode = Cycle mode
zc-app-help-help = Help
zc-app-help-reload = Reload daemon
zc-app-help-toggle-sidebar = Toggle agent sidebar
zc-app-help-quit = Quit

zc-sidebar-title = Agents
zc-dock-header = Dock { $side }
zc-dock-side-left = left
zc-dock-side-right = right
zc-dock-switch-side = [↔]
zc-dock-setting-sessions = Sessions visibility
zc-dock-setting-side = Dock side
zc-dock-setting-width = Dock width
zc-dock-setting-split = Dock section split
zc-dock-save-env-shadow = { $setting } changed, but an environment override will take effect after relaunch.
zc-dock-save-failed = { $setting } changed for this run, but could not be saved: { $error }
zc-dock-toggle-sessions = Sessions
zc-dock-toggle-queue = Queue
zc-dock-toggle-plan = Plan
zc-todo-plan-title = Plan ({ $total }) — { $done }/{ $total } done
zc-todo-plan-empty = No active plan
zc-sidebar-empty = No active agents
zc-sidebar-picker-title = Add agent
zc-sidebar-picker-loading = Loading agents…
zc-sidebar-picker-empty = No configured agents
zc-sidebar-picker-error = Failed to load agents ({ $error })
zc-sidebar-picker-disconnected = agent lookup stopped before returning a result
zc-sidebar-picker-open-suffix = (open)
zc-app-keybindings-title = Keybindings
zc-app-help-filter-label = Filter
zc-app-help-filter-placeholder = type a key or action…
zc-app-help-no-matches = No matching keybindings
zc-config-filter-sections = Filter sections
zc-config-refused = This account can't read the daemon's config: { $reason }
zc-config-filter-list = Filter list
zc-config-filter-options = Filter options
zc-config-filter-no-matches = No matches
zc-app-help-controls = { $cancel } clear/close · { $up }/{ $down } scroll · Type to filter

zc-app-reload-line-1 = The daemon process stays running (same PID), but every
zc-app-reload-line-2 = subsystem tears down and re-initializes from the on-disk
zc-app-reload-line-3 = config:
zc-app-reload-bullet-gateway = { "  " }• Gateway listener stops and rebinds
zc-app-reload-bullet-channels = { "  " }• Channel listeners (Matrix, Slack, etc.) respawn
zc-app-reload-bullet-mcp = { "  " }• MCP servers, scheduler, heartbeat re-init
zc-app-reload-bullet-provider = { "  " }• Provider clients pick up new API keys / model defaults
zc-app-reload-socket-note = The RPC socket will briefly drop. The TUI will reconnect.
zc-app-quit-prompt = Quit zerocode?
zc-app-quit-explainer = The TUI closes. The daemon keeps running; reconnect anytime.
zc-app-reload-status-signalled = Daemon reload signalled — reconnecting…
zc-app-reload-confirm-row = { $confirm_chord } = reload   { $cancel_chord } = cancel
zc-error-daemon-version-mismatch = Version mismatch: zerocode is { $client_version } but the daemon is { $server_version }. Rebuild and restart the daemon from the same checkout as zerocode.
zc-error-daemon-initialize-timeout = zerocode connected to the daemon, but initialization did not finish within { $seconds }s. Restart the daemon and try again.
zc-error-spawned-daemon-startup = zerocode started an ephemeral daemon, but it failed to become ready: { $details }
zc-daemon-wait-notice = zerocode: waiting for daemon at { $path } (up to { $seconds }s)…
zc-error-daemon-not-ready-timeout = daemon did not become ready within { $seconds }s (socket: { $path }); if the socket path is long, set ZEROCLAW_SOCKET to a shorter path or use a shorter --config-dir

zc-zerocode-tab-theme = Theme
zc-zerocode-tab-agent-theme = Agent Themes
zc-zerocode-tab-presets = Presets
zc-zerocode-tab-bindings = Keybindings
zc-zerocode-tab-locale = Locale
zc-zerocode-tab-connection = Connection
zc-zerocode-tab-todo-tracker = Todo tracker
zc-zerocode-conn-title = Connection ([wss] — Enter to edit)
zc-zerocode-conn-uri = WSS URI
zc-zerocode-conn-skip-verify = TLS skip verify
zc-zerocode-conn-skip-verify-routes = Skip-verify routes
zc-zerocode-conn-unset = unset
zc-zerocode-conn-no-routes = none
zc-zerocode-conn-saved = Saved
zc-zerocode-conn-edit-text = { $save } or { $confirm } to save, { $cancel } to cancel.
zc-zerocode-conn-edit-bool = Enter toggles; this field saves on toggle.
zc-zerocode-conn-edit-routes = One route per line. { $confirm } for a new line, { $save } to save, { $cancel } to cancel.

zc-config-draft-pending = Pending edits
zc-config-draft-unchanged = No pending edits
zc-config-discard-title = Discard pending edits?
zc-config-discard-explanation = This action replaces your draft. Stay to keep editing or discard the pending edits and continue.
zc-config-action-stay = Stay
zc-config-action-discard = Discard
zc-config-external-editor-title = Open external editor?
zc-config-external-editor-explanation = After the external editor exits successfully, changed content is imported and saved. Cancel now to keep using the inline editor.
zc-config-action-launch-editor = Open editor
zc-zerocode-tracker-title = Todo tracker ([todotracker] — Enter to edit)
zc-zerocode-tracker-enabled = Enabled
zc-zerocode-tracker-enabled-at-start = Visible at start
zc-zerocode-tracker-location = Location
zc-zerocode-tracker-width = Side panel width
zc-zerocode-tracker-max-height = Bottom max height
zc-zerocode-tracker-saved = Saved. New Code sessions will use this.
zc-zerocode-tracker-saved-env-override = Saved to disk, but a ZEROCODE_todotracker__* environment override is active, so new sessions will use the override value until it is unset.
zc-zerocode-tracker-saved-resolve-error = Saved to disk, but resolving the effective settings failed (check ZEROCODE_todotracker__* overrides); new sessions may not use this value until it is fixed.
zc-zerocode-tracker-load-error = [todotracker] unreadable: { $error } — fix or delete the section in zerocode-config.toml by hand, then reopen this pane.
zc-zerocode-tracker-saved-still-invalid = Saved, but [todotracker] is still invalid — the other dimension must be greater than zero too.
zc-zerocode-tracker-edit-refused = Edit refused — repair [todotracker] first (see above).
zc-zerocode-tracker-edit-number = Enter to save, Esc to cancel.
zc-zerocode-tracker-edit-bool = Enter toggles; this field saves on toggle.
zc-zerocode-tracker-edit-location = Enter cycles bottom / left / right.
zc-zerocode-config-invalid-number = Enter a valid positive whole number.
zc-zerocode-config-positive-required = Numeric values must be greater than zero.
zc-zerocode-config-save-failed = Save failed: { $error }
zc-zerocode-config-save-mismatch = Saved values differ from what new sessions will use.
zc-zerocode-help-todo-tracker = edit todo tracker field
zc-zerocode-locale-loading = loading locales…
zc-zerocode-locale-download = ⬇ Download selected locale file
zc-zerocode-locale-set = Locale set to { $locale }. Download its locale file if needed, then restart to apply.
zc-zerocode-locale-fetching = Downloading locale files for { $locale }…
zc-zerocode-locale-downloaded = Downloaded { $written } for { $locale }. Skipped: { $skipped }
zc-zerocode-locale-fetch-failed = Locale download failed for { $locale }: { $err }
zc-zerocode-locale-list-failed = Failed to load locale list: { $err }
zc-zerocode-locale-pick-first = Select a locale row first, then download its locale file.
zc-zerocode-help-locale = select / download locale
zc-zerocode-help-conn = edit connection field

zc-zerocode-capture-prompt = Press a key combination…
zc-zerocode-capture-modal-title = Assign Key
zc-zerocode-hint-cancel = { $keys } to cancel

zc-zerocode-capture-assign = Assign as the new binding
zc-zerocode-capture-cancel = Cancel capture

zc-zerocode-help-switch-pane = Switch pane (Theme/Presets/Keybindings)
zc-zerocode-help-navigate = Navigate
zc-zerocode-help-apply-theme = Apply theme (live + saved)
zc-zerocode-help-assign-agent-theme = Assign theme to the selected agent
zc-zerocode-help-pick-agent = Choose theme for this agent
zc-zerocode-help-clear-agent-theme = Clear the agent's override
zc-zerocode-help-apply-preset = Apply preset (overwrites keybindings)
zc-zerocode-help-rebind = Rebind selected action
zc-zerocode-help-reset-default = Reset action to default
zc-zerocode-help-mouse-label = Mouse
zc-zerocode-help-mouse-desc = Click pane / row, scroll, click section tab
zc-zerocode-help-choose-section = Choose section
zc-zerocode-help-open-section = Open section
zc-zerocode-help-navigate-rows = Navigate rows
zc-zerocode-help-back-to-sections = Back to sections

zc-zerocode-agent-modal-title = Select Agent
zc-zerocode-agent-modal-pick = Pick agent, then choose a theme
zc-zerocode-agent-theme-loading = Loading agents…
zc-zerocode-agent-theme-no-agents = No agents configured
zc-zerocode-agent-theme-none = No override on this agent
zc-zerocode-agent-theme-set = Override set: { $agent } → { $theme }
zc-zerocode-agent-theme-cleared = Override cleared for { $agent }
zc-zerocode-agent-theme-hint = { $assign } assign theme   ·   { $clear } clear override

zc-input-no-pending-attachments = No pending attachments.
zc-input-no-clipboard-image = Clipboard is empty.
zc-input-placeholder-chat = Type to chat

zc-input-help-completions-navigate = Navigate completions
zc-input-help-completions-accept = Accept
zc-input-help-completions-dismiss = Dismiss


zc-input-attached = Attached: { $label }
zc-input-attach-error = Attach error: { $error }
zc-input-detached = Detached: { $name }
zc-input-invalid-index = Invalid index: { $index }
zc-input-pending-attachments-header = Pending attachments:
zc-input-attachment-manager-title = Pending attachments ({ $count })
zc-input-attachment-manager-hint = { $navigate } select · { $remove } remove · { $close } close · /detach N
zc-input-help-attachment-remove = Remove attachment
zc-input-help-attachment-detach = Remove by index
zc-input-clipboard-error = Clipboard error: { $error }
zc-input-clipboard-cleanup-error = Clipboard cleanup warning: { $count } temporary file(s) could not be removed and remain on disk.

zc-queue-empty = Nothing to send.
zc-cancel-timed-out = Cancel timed out; turn settled locally.
zc-turn-no-output = Turn completed with no output.
zc-queue-full = Queue is full ({ $cap } max). Wait for messages to send.
zc-queue-title = Queue ({ $count })
zc-queue-empty-list = No queued messages.
zc-queue-paused-ghost = Queue paused — press { $send } or { $key } to resume, or send a message
zc-queue-missing-completion-ghost = Completion unconfirmed. { $send } or send to resume.
zc-queue-paused-single-key-ghost = Queue paused — press { $key } to resume.
zc-queue-missing-completion-single-key-ghost = Completion unconfirmed. { $key } to resume.
zc-queue-paused-no-key-ghost = Queue paused. Set a send or resume key.
zc-queue-item-injected = (inject)
zc-queue-resumed = Queue resumed.
zc-queue-clear-empty = Queue is already empty.
zc-queue-cleared-all = Cleared { $count } queued message(s).
zc-queue-cleared-one = Cleared queued message { $index }.
zc-queue-clear-invalid = No queued message at index { $index } (queue has { $count }).
zc-queue-help-resume = Pause/resume queue
zc-queue-help-nav = Select queued
zc-queue-help-delete = Delete queued
zc-queue-help-clear = Clear queue ([N] = position)
zc-queue-help-edit = Edit queued
zc-queue-help-enqueue = Queue message
zc-queue-help-inject = Send now (skip queue)
zc-queue-edit-busy = Finish or clear the current message before editing a queued one.
zc-queue-dispatch-failed = Could not send queued message: { $error }
zc-queue-dispatch-requeued = Session busy; your message is back in the queue (paused): { $error }

zc-logs-label-timestamp = Timestamp
zc-logs-label-severity = Severity
zc-logs-label-category = Category
zc-logs-label-action = Action
zc-logs-label-outcome = Outcome
zc-logs-label-duration = Duration
zc-logs-section-message = Message
zc-logs-section-trace = Trace
zc-logs-section-attribution = Attribution
zc-logs-section-attributes = Attributes
zc-logs-preview-only = Full payload unavailable — showing preview fields only.
zc-logs-persisted-path = Persisted log: { $path }
zc-logs-no-event-selected = No event selected
zc-logs-loading = Loading…
zc-logs-refused = This account can't read the daemon's log: { $reason }
zc-logs-search-action-apply = apply
zc-logs-search-action-cancel = cancel
zc-logs-run-filter-label = run
zc-logs-run-filter-clear = R:clear

zc-logs-help-mouse-label = Mouse
zc-logs-help-mouse-desc = Click rows, drag to select text, scroll wheel, double-click detail
zc-logs-copy = Copy
zc-logs-copied = [Copied]
zc-logs-status-partial = [partial]

zc-doctor-title = Doctor
zc-doctor-loading = Loading diagnostics...
zc-doctor-error = Doctor failed: { $error }
zc-doctor-error-unsupported-daemon = Doctor RPC is not available on this daemon yet. Restart the daemon with a build that includes doctor/run.
zc-doctor-no-results = No diagnostics yet
zc-doctor-summary = { $ok } ok  { $warnings } warnings  { $errors } errors
zc-doctor-filter-status = filter: { $filter }
zc-doctor-filter-all = All
zc-doctor-filter-problems = Problems
zc-doctor-filter-errors = Errors
zc-doctor-list-title = Diagnostics ({ $filter })
zc-doctor-detail-title = Detail
zc-doctor-no-selection = No diagnostic selected
zc-doctor-label-message = Message
zc-doctor-help-mouse = Mouse: click filter/select, scroll wheel
zc-doctor-error-daemon-timeout = The doctor check timed out. The daemon may be busy, unreachable, or processing a long-running request. Try again or check daemon connectivity.
zc-doctor-partial-banner = ⚠ Partial results — model probing timed out
zc-doctor-partial-hint = Some provider catalogs could not be reached. Results from config, workspace, and daemon checks are shown below. Press the refresh key to retry.

zc-dashboard-tab-overview = Overview
zc-dashboard-tab-sessions = Sessions
zc-dashboard-tab-agents = Agents
zc-dashboard-tab-memories = Memories
zc-dashboard-tab-health = Health
zc-dashboard-tab-cost = Cost
zc-dashboard-tab-cron = Cron

zc-dashboard-memory-not-configured = Memory is not configured yet. Use Quickstart or Config to add a memory backend, or ignore this tab until you need persistent memory.
zc-dashboard-search-action-apply = apply
zc-dashboard-search-action-cancel = cancel
zc-dashboard-search-prefix = search:
zc-dashboard-agent-rename-action-apply = rename
zc-dashboard-agent-rename-action-cancel = cancel
zc-dashboard-agent-rename-hint = rename
zc-dashboard-agent-rename-prefix = rename:
zc-dashboard-agent-rename-empty = Agent name cannot be empty
zc-dashboard-agent-rename-unchanged = Agent name unchanged
zc-dashboard-agent-rename-success = Renamed { $from } to { $to }
zc-dashboard-agent-rename-success-warnings = Renamed { $from } to { $to } with warnings: { $warnings }
zc-dashboard-agent-rename-failed = Rename failed: { $error }

zc-dashboard-label-connected = Connected
zc-dashboard-label-daemon = Daemon
zc-dashboard-label-socket = Socket
zc-dashboard-label-server = Server
zc-dashboard-label-client = Client
zc-dashboard-label-protocol = RPC API
zc-dashboard-label-sessions = Sessions
zc-dashboard-label-config = Config
zc-dashboard-label-config-file = File
zc-dashboard-label-endpoint = Endpoint
zc-dashboard-label-workspace = Workspace
zc-dashboard-label-code-cwd = Code CWD
zc-dashboard-label-chat-cwd = Chat CWD
zc-dashboard-label-context = Code + Chat Context
zc-dashboard-label-code-context = Code Context
zc-dashboard-label-chat-context = Chat Context
zc-dashboard-context-idle = idle
zc-dashboard-context-working = working
zc-dashboard-context-blocked = blocked
zc-dashboard-context-done = done
zc-dashboard-context-client-queue = client queue: { $count }
zc-dashboard-context-client-queue-paused = client queue: { $count } (paused)
zc-dashboard-session-state-count = { $count } { $state }
zc-dashboard-session-agent = { $agent }: { $states }
zc-dashboard-label-daemon-memory = Daemon Memory
zc-dashboard-label-daemon-cpu = Daemon CPU
zc-dashboard-label-health = Health
zc-dashboard-runtime-profile = Configured runtime profile: { $profile }
zc-dashboard-profile-unavailable = unavailable
zc-dashboard-health-unavailable = Health data unavailable.
zc-dashboard-health-error = Health check failed: { $error }
zc-dashboard-health-summary = { $healthy } healthy, { $unhealthy } unhealthy, { $unconfirmed } unconfirmed.
zc-dashboard-health-details = See the Health tab for component details.
zc-dashboard-label-insecure-tls = ⚠ unverified TLS — certificate not checked
zc-dashboard-label-uptime = Uptime
zc-dashboard-label-pid = PID
zc-dashboard-config-kind-default = default
zc-dashboard-config-kind-custom = custom
zc-dashboard-config-kind-temporary = temporary
zc-dashboard-daemon-local = local
zc-dashboard-daemon-remote = remote
zc-dashboard-cpu-with-cores = { $cpu } ({ $cores } cores)

zc-dashboard-no-tuis = No TUIs connected
zc-dashboard-no-session = No session selected
zc-dashboard-no-agent = No agent selected
zc-dashboard-no-entry = No entry selected
zc-dashboard-no-job = No job selected

zc-dashboard-detail-key = Key
zc-dashboard-detail-agent = Agent
zc-dashboard-detail-channel = Channel
zc-dashboard-detail-name = Name
zc-dashboard-detail-messages = Messages
zc-dashboard-detail-created = Created
zc-dashboard-detail-activity = Activity
zc-dashboard-detail-alias = Alias
zc-dashboard-detail-enabled = Enabled
zc-dashboard-detail-category = Category
zc-dashboard-detail-namespace = Namespace
zc-dashboard-detail-timestamp = Timestamp
zc-dashboard-detail-score = Score
zc-dashboard-detail-importance = Importance
zc-dashboard-detail-session = Session
zc-dashboard-detail-daily = Daily
zc-dashboard-detail-monthly = Monthly
zc-dashboard-detail-tokens = Tokens
zc-dashboard-detail-requests = Requests
zc-dashboard-detail-schedule = Schedule
zc-dashboard-detail-next-run = Next Run
zc-dashboard-detail-last-run = Last Run
zc-dashboard-detail-last-status = Last Status
zc-dashboard-detail-sessions = Sessions
zc-dashboard-detail-persisted-sessions = Persisted Sessions
zc-dashboard-cost-not-available = Cost tracking is not available. Configure a cost backend to see usage data.
zc-dashboard-cost-org-error = Organization billing snapshot is present but could not be read. Check the org_cost.json sync.

zc-dashboard-message-history = Message History ({ $count })
zc-dashboard-loading-messages = Loading messages…
zc-dashboard-loading = Loading…

zc-dashboard-section-channels = Channels
zc-dashboard-section-content = Content
zc-dashboard-section-process = Process
zc-dashboard-section-components = Components
zc-dashboard-section-details = Details
zc-dashboard-section-summary = Summary (UTC)
zc-dashboard-section-by-period = By Period (your account, UTC)
zc-dashboard-section-org = Organization (billed)
zc-dashboard-period-today = Today
zc-dashboard-period-month = Month
zc-dashboard-period-quarter-prefix = Q
zc-dashboard-period-ytd = YTD
zc-dashboard-col-period = period
zc-dashboard-col-cost = cost($)
zc-dashboard-col-paid-tok = paid tok
zc-dashboard-col-free-tok = free tok
zc-dashboard-col-reqs = reqs
zc-dashboard-org-tok = tok
zc-dashboard-org-projyr = proj/yr
zc-dashboard-org-name = Organization
zc-dashboard-org-personal = You (billed)
zc-dashboard-org-fy-prefix = FY
zc-dashboard-org-asof = as of
zc-dashboard-section-by-model = By Model
zc-dashboard-section-by-agent = By Agent
zc-dashboard-section-command = Command
zc-dashboard-section-prompt = Prompt
zc-dashboard-section-last-output = Last Output
zc-dashboard-section-manual-run = Manual Run
zc-dashboard-section-recent-runs = Recent Runs
zc-dashboard-actions = Actions
zc-dashboard-cron-action-hint = { $run } run now · { $refresh } refresh
zc-dashboard-loading-runs = Loading runs…
zc-dashboard-runs-error = Failed to load runs
zc-dashboard-no-runs = No runs recorded yet
zc-dashboard-run-succeeded = Run succeeded
zc-dashboard-run-failed = Run failed
zc-dashboard-run-running = Run started: { $id }
zc-dashboard-run-already-running = Run already in progress: { $id }
zc-dashboard-run-pending-status = running
zc-dashboard-run-pending-window = starting now
zc-dashboard-run-pending-output = Manual trigger in progress…

zc-dashboard-yes = yes
zc-dashboard-no = no
zc-dashboard-enabled = enabled
zc-dashboard-disabled = disabled

zc-quickstart-title = Quickstart
zc-quickstart-selector-model-provider = Model provider
zc-quickstart-selector-risk-profile = Risk profile
zc-quickstart-selector-runtime-profile = Runtime profile
zc-quickstart-selector-memory = Memory
zc-quickstart-selector-channels = Channels (optional)
zc-quickstart-selector-peer-groups = Peer groups (optional)
zc-quickstart-selector-agent = Agent
zc-quickstart-selector-submit = Submit

zc-quickstart-reuse-alias-help = Reuse this alias instead of creating a new one.
zc-quickstart-existing-providers-heading = Existing providers
zc-quickstart-existing-providers-show-more = [+ Show { $count } more existing providers]
zc-quickstart-existing-providers-show-fewer = [- Show fewer existing providers]
zc-quickstart-new-provider-heading = Create new provider
zc-quickstart-provider-alias-exists = Alias `{ $alias }` already exists. Pick another alias or use the existing provider.

zc-quickstart-risk-locked-down = Locked Down
zc-quickstart-risk-locked-down-desc = Tight defaults. Workspace-only fs, approval on med/high risk.
zc-quickstart-risk-balanced = Balanced
zc-quickstart-risk-balanced-desc = Day-to-day defaults. Approval on risky ops. Recommended.
zc-quickstart-risk-yolo = YOLO
zc-quickstart-risk-yolo-desc = Full autonomy. No approval gates. Use on disposable machines only.

zc-quickstart-runtime-tight = Tight
zc-quickstart-runtime-tight-desc = Low ceilings on iterations and tokens.
zc-quickstart-runtime-local-small = Local Small
zc-quickstart-runtime-local-small-desc = Compact limits for smaller local models with structured tool calls.
zc-quickstart-runtime-balanced = Balanced
zc-quickstart-runtime-balanced-desc = Sensible ceilings. Recommended.
zc-quickstart-runtime-unbounded = Unbounded
zc-quickstart-runtime-unbounded-desc = No artificial caps.

zc-quickstart-provider-local = Local. No credential required.
zc-quickstart-provider-cloud = Cloud. Provide an API key when prompted.

zc-quickstart-submit-create = Create the agent


zc-quickstart-modal-action-move = move
zc-quickstart-modal-action-pick = pick
zc-quickstart-modal-action-cancel = cancel
zc-quickstart-modal-action-accept = accept
zc-quickstart-modal-action-pick-on-enum = pick on ‹enum›
zc-quickstart-modal-action-activate = activate
zc-quickstart-modal-action-delete = delete
zc-quickstart-modal-action-close = close
zc-quickstart-modal-action-edit-name = type to edit name
zc-quickstart-modal-action-on-file-rows = on file rows
zc-quickstart-modal-action-save = save
zc-quickstart-modal-type-prefix = Type:
zc-quickstart-field-label-alias = Alias
zc-quickstart-field-help-alias = Unique identifier for this provider instance. Change from "default" if your config already has one with that alias.
zc-quickstart-model-loading = Loading models for { $provider }...
zc-quickstart-model-retrying = Retrying model catalog for { $provider }...
zc-quickstart-model-catalog-empty = catalog unavailable - type a model name
zc-quickstart-action-done = Done
zc-quickstart-no-peer-groups = No peer groups configured. Optional — agents can still send messages to channels.

zc-quickstart-help-external-peers = Comma- or newline-separated. Blank = no external peers.

zc-quickstart-status-submitting = Submitting…
zc-quickstart-status-created = Created `{ $alias }`. Reloading daemon — Chat will open when reconnected…
zc-quickstart-status-errors = { $count } error(s) — fix selectors and resubmit
zc-quickstart-status-first-error = { $where }{ $field }: { $message }{ $more }
zc-quickstart-status-more-errors = { " " }(+{ $count } more)
zc-quickstart-status-can-create = All required selectors ✓. Press `{ $chord }` to Create.
zc-quickstart-status-hint = ↑/↓ to move, Enter to open. `{ $chord }` enables when all required selectors are ✓.
zc-quickstart-missing-model-provider = Choose a model provider before creating.
zc-quickstart-missing-risk-profile = Choose a risk profile before creating.
zc-quickstart-missing-runtime-profile = Choose a runtime profile before creating.
zc-quickstart-missing-memory = Choose a memory backend before creating.
zc-quickstart-missing-agent = Name the agent before creating.

zc-quickstart-channels-empty = No channels configured. An agent without channels still works via `zeroclaw agent <name>` from the CLI.
zc-quickstart-channels-add = + Add channel
zc-quickstart-peers-add = + Add peer group
zc-quickstart-block-channels = Channels
zc-quickstart-block-peers = Peer groups
zc-quickstart-block-agent = Agent
zc-quickstart-personality-help = Personality files (e=edit, t=use template, c=clear)
zc-quickstart-save-and-close = Save & close
zc-quickstart-no-template = No template is available for `{ $filename }`
zc-quickstart-agent-name-field = name
zc-quickstart-file-bytes = { $bytes } bytes

zc-chat-pane-chat = Chat
zc-chat-pane-acp = ACP

zc-chat-no-agents = No enabled agents yet. Open Quickstart to create one, or use Config to add and enable an agent.
zc-chat-error-fetch-agents = Failed to fetch agents: { $error }
zc-chat-history-trimmed-turns = Earlier conversation history was trimmed: { $reason } ({ $dropped } older { $dropped-kind ->
    [one] turn
   *[other] turns
} dropped; { $kept } { $kept-kind ->
    [one] turn
   *[other] turns
} kept).
zc-chat-history-trimmed = Earlier conversation history was trimmed: { $reason } ({ $dropped } messages dropped; { $kept } turns kept).
zc-chat-history-trimmed-tokens = Earlier conversation history was trimmed from approximately { $before } to { $after } tokens: { $reason }; { $dropped } messages dropped and { $kept } turns kept.
zc-chat-history-trimmed-tokens-turns = Earlier conversation history was trimmed from approximately { $before } to { $after } tokens: { $reason }; { $dropped } older { $dropped-kind ->
    [one] turn
   *[other] turns
} dropped and { $kept } { $kept-kind ->
    [one] turn
   *[other] turns
} kept.
zc-chat-history-trimmed-floor = The conversation history could not be trimmed below the configured token budget: { $reason }; the most recent turn still needs approximately { $after } tokens (configured budget: { $budget }).
zc-chat-budget-warning-day = Cost warning: ${ $spent } of the ${ $limit } daily limit spent ({ $percent }%). Turns stop at the limit.
zc-chat-budget-warning-month = Cost warning: ${ $spent } of the ${ $limit } monthly limit spent ({ $percent }%). Turns stop at the limit.
zc-chat-history-trimmed-token-budget-clause = (configured token budget: { $budget })
zc-chat-history-trimmed-token-source-provider = provider-reported
zc-chat-history-trimmed-token-source-estimate = estimated
zc-chat-history-trimmed-token-source-calibrated = provider + estimate
zc-chat-history-trimmed-token-sources = ({ $before } before; { $after } after)
zc-chat-error-create-session = Failed to create session: { $error }
zc-chat-error-resume-history = The session reattached, but its durable transcript could not be loaded: { $error }
zc-chat-session-switch-error = Failed to switch session: { $error }
zc-chat-status-working = working
zc-chat-status-thinking = thinking
zc-chat-status-responding = responding
zc-chat-status-calling-tool = calling tool { $tool }
zc-chat-status-awaiting-approval = awaiting approval
zc-chat-status-awaiting-input = awaiting input
zc-chat-status-cancelling = cancelling
zc-chat-session-close-error = Failed to close session: { $error }
zc-chat-elicitation-dropped = A prompt from the agent was dropped before it could be shown (the client fell behind). The agent's question may be waiting; try again.
zc-chat-elicitation-answered = You answered: { $answer }
zc-chat-elicitation-cancelled = You dismissed the question without answering.
zc-chat-elicitation-withdrawn = The question closed before you answered (the view reloaded). The agent was told it was cancelled.
zc-chat-elicitation-expired = The agent stopped waiting for an answer to its question.
zc-chat-elicitation-outcome-note = { $outcome } (Question: { $question })
zc-chat-session-restarted = New session started.
zc-chat-session-cap = Session limit for this pane reached ({ $max }). Close a session from the sidebar first.
zc-chat-load-session-not-found = No saved session matches "{ $query }".
zc-chat-load-session-list-error = Failed to list saved sessions: { $error }
zc-chat-load-session-already-active = That session is already open in this pane.
zc-chat-resume-dropped = { $count } prior session(s) could not be re-attached and were retained for retry.
zc-chat-reconnect-interrupted = The connection was rebuilt and queued messages were preserved. Waiting for the prior turn to stop before reloading the durable transcript.
zc-chat-resyncing = Some live updates were missed. Reloading this session before sending queued messages…
zc-chat-resynced = Live updates were missed, so the durable transcript was reloaded. Any in-progress approval or question was cancelled.
zc-chat-refresh-started = Refreshing this session...
zc-chat-refresh-busy = This session is busy. Nothing was cancelled. Refresh again when the turn finishes.
zc-chat-refresh-recovery-required = This session needs recovery before it can be refreshed. Your view was kept.
zc-chat-refresh-stale = Session activity changed during refresh. Your view was kept; refresh again.
zc-chat-refresh-failed = Session refresh failed: { $error }. Your view was kept; refresh again to retry.
zc-chat-refresh-timeout = the session read timed out
zc-chat-refresh-incomplete = the daemon returned an incomplete transcript
zc-chat-refresh-anchor = the selected content or reading position is no longer in the durable transcript
zc-chat-refreshed = Session refreshed. Local draft and queued messages were kept.
zc-chat-help-refresh-session = Refresh this session without cancelling a turn
zc-chat-resynced-turn-running = Live updates were missed. The in-progress turn is still running; output shown above was kept, and the durable transcript will be reloaded when the turn finishes.
zc-chat-resynced-turn-finished = The in-progress turn finished, so the durable transcript was reloaded once more.
zc-chat-resync-failed = Live updates were missed and the session could not be reloaded: { $error }
zc-chat-session-restart-error = Failed to start a new session: { $error }
zc-chat-code-cwd-not-utf8 = The selected directory is not valid UTF-8 ({ $path }), so the Code session was not created. Pick a directory whose path is valid UTF-8.
zc-chat-code-cwd-not-absolute = The selected directory is not an absolute path ({ $path }), so the new Code session was not created. Pick a directory from the root of the filesystem the session runs on.
zc-chat-launch-cwd-unavailable = Cannot determine the directory zerocode was launched from: { $error }. A local session must start in that project, so it was not created.
zc-chat-launch-cwd-not-utf8 = The directory zerocode was launched from is not valid UTF-8 ({ $path }), so a local session cannot start there. Relaunch zerocode from a UTF-8 path.
zc-chat-change-directory-error = Failed to start a session in the selected directory: { $error }
zc-chat-change-directory-chat-only = Chat sessions keep the directory they started in, so there is no directory to choose here. Use the Code pane to start a session in a different directory.

zc-chat-thinking-visible = Thinking output: visible
zc-chat-thinking-hidden = Thinking output: hidden

# Model picker slash commands
zc-model-picker-hint = Type a model name after /model, or Tab to autocomplete.
zc-model-provider-picker-hint = Type a model_provider after /model-provider, then pick a model with /model.
zc-model-picker-title = Select model
zc-model-provider-picker-title = Select model_provider
zc-model-switch-applying = Applying model change…
zc-model-switch-model-ok = Model switched to { $model }.
zc-model-switch-provider-ok = model_provider switched to { $provider } (model: { $model }).
zc-model-switch-failed = Model switch failed: { $error }
zc-model-catalog-no-provider = Could not resolve this agent's model_provider from config.
zc-model-catalog-empty = No models available for the active model_provider.
zc-model-catalog-failed = Could not load models for the active model_provider: { $error }
zc-model-catalog-loading = Loading models…
zc-model-provider-catalog-failed = Could not load model_providers: { $error }

zc-chat-label-you = You:
zc-chat-label-agent = Agent:

zc-chat-loading-agents = Loading agents…
zc-chat-loading-agents-msg = Loading agents...
zc-chat-picker-header = Select an agent
zc-chat-picker-header-hint = ({ $keys })

zc-chat-help-navigate = Navigate
zc-chat-help-select-agent = Select agent
zc-chat-help-quit = Quit
zc-chat-help-switch-session = Switch session
zc-chat-help-load-session = /load-session [name|id] — resume a saved session
zc-keybinding-focus-session = Focus session { $n }
zc-chat-help-close = Close
zc-chat-help-cancel = Cancel
zc-chat-help-approve = Approve
zc-chat-help-always-approve = Always approve
zc-chat-help-deny = Deny
zc-chat-help-cancel-turn = Cancel turn
zc-chat-help-move-up = Move cursor up
zc-chat-help-move-down = Move cursor down
zc-chat-help-extend-selection = Extend selection
zc-chat-help-yank-selection = Yank selection
zc-chat-help-return-to-input = Return to input
zc-chat-help-browse-mode = Browse mode
zc-chat-help-scroll-conversation = Scroll conversation
zc-chat-help-open-link = Click a link to open it; drag from elsewhere to select text
zc-chat-help-toggle-thoughts = Toggle thoughts
zc-chat-help-new-session = New session
zc-chat-help-change-directory = Choose a directory and start a new Code session
zc-chat-help-acp-memory = History saved & resumable; persistent memory isolated
zc-chat-session-list-resume-title = Saved sessions (Enter=resume, Esc=new)
zc-chat-session-list-resume-note = Session history saved & resumable · Persistent memory isolated
zc-chat-agent-picker-acp-memory-note = Session history saved & resumable · Persistent memory isolated
zc-chat-session-list-switch-title = Sessions (Enter=switch, Esc=close)
zc-elicit-help-toggle = Toggle choice
zc-elicit-help-confirm = Confirm choice
zc-elicit-help-cancel = Cancel

zc-chat-approval-title = Approve tool call: { $tool }  [{ $secs }s]
zc-chat-approval-action-allow = Allow
zc-chat-approval-action-always = Always
zc-chat-approval-action-reject = Reject
zc-chat-approval-action-edit = Edit


zc-chat-clipboard-you = You: { $text }
zc-chat-clipboard-agent = Agent: { $text }
zc-chat-copied-clipboard = Copied to clipboard
zc-clipboard-requested = Copy requested through terminal; delivery is unconfirmed
zc-clipboard-requested-label = [Requested]
zc-clipboard-copy-failed = Could not copy: { $error }
zc-chat-copy-message = [Copy]
zc-chat-copy-message-copied = [Copied]
zc-chat-context-menu-copy = Copy
zc-chat-context-menu-copy-selection = Copy selection
zc-chat-context-menu-open-link = Open link
zc-chat-context-menu-copy-link = Copy link
zc-chat-open-link-failed = Could not open link: { $error }
zc-chat-context-menu-add-to-chat = Add to Chat
zc-chat-context-menu-send-now = Send now
zc-chat-context-menu-edit = Edit
zc-chat-context-menu-delete = Delete
zc-chat-tool-show-all = [Show all · { $count } more lines]
zc-chat-tool-show-less = [Show less]
zc-chat-tool-display-limited = [Display limited; copy for full content]
zc-chat-tool-encoded-size = { $count } encoded characters
zc-chat-tool-subagent = Subagent
zc-chat-tool-delegation = Delegation
zc-chat-tool-task = Task
zc-chat-tool-target = Target
zc-chat-tool-response = Response
zc-chat-tool-details = Details
zc-chat-tool-result-not-recorded = Result not recorded

zc-config-breadcrumb-root = Config
zc-config-section-detail-hint = { $open } or { $into } to open this section
zc-config-breadcrumb-new = New

zc-config-personality-over-limit = Over { $limit } char limit — cannot save
zc-config-alias-create-hint = Enter a name for the new alias
zc-config-personality-help-blurb = Personality files shape your agent's voice and context.
zc-config-skills-help-blurb = Skills in this bundle. { $enter_chord } to edit SKILL.md, { $archive_chord } to archive.

zc-config-field-type-prefix = Type:
zc-config-field-type-secret-suffix = (secret — input hidden)
zc-config-field-type-string-array-suffix = (one entry per line; { $newline_chord }=new line, { $save_chord }=save)

# Secret key/value maps (MCP env/headers, provider extra_headers, …)
zc-config-secret-map-add = [+ Add entry]
zc-config-secret-map-key-prompt = New entry name (e.g. API_TOKEN), then Enter
zc-config-secret-map-value-prompt = Value for { $key } (secret — input hidden), then Enter
zc-config-secret-map-key-empty = Entry name cannot be empty
zc-config-secret-map-key-invalid = Entry name cannot contain spaces, control characters, or "="
zc-config-secret-map-value-empty = Value cannot be empty — to remove an entry, select its row and delete it
zc-config-secret-map-delete-hint = Select an entry row below to delete it; this row only adds entries

zc-config-help-navigate = Navigate
zc-config-help-switch-section = Switch config section
zc-config-help-open-section = Open section
zc-config-help-clear-filter = Clear filter
zc-config-help-this-help = This help
zc-config-help-filter = Filter
zc-config-help-quit = Quit
zc-config-help-mouse-label = Mouse
zc-config-help-mouse-open = Click, scroll, double-click to open
zc-config-help-mouse-tabs-edit = Click, scroll, click tabs, double-click to edit
zc-config-help-mouse-edit = Click, scroll, double-click to edit
zc-config-help-mouse-save = Click, scroll, double-click to save
zc-config-help-mouse-tabs = Click, scroll, click tabs
zc-config-help-open-type = Open type
zc-config-help-back = Back
zc-config-help-open-alias = Open alias
zc-config-help-delete-alias = Delete alias
zc-config-help-rename-alias = Rename provider alias
zc-config-help-review-rename = Review rename
zc-config-help-confirm-rename = Confirm rename
zc-config-help-create-alias = Create alias
zc-config-help-cancel = Cancel
zc-config-help-edit-field = Edit field
zc-config-help-save = Save
zc-config-help-back-to-files = Back to files
zc-config-help-switch-tabs = Switch tabs
zc-config-help-edit-file = Edit file
zc-config-help-fill-from-template = Fill from template
zc-config-help-edit-skill = Edit skill
zc-config-help-archive-skill = Archive skill
zc-config-help-back-to-skills = Back to skills
zc-config-help-save-selection = Save selection
zc-config-help-new-line-entry = New line (new entry)
zc-config-help-save-array = Save array
zc-config-help-save-value = Save value
zc-config-help-reset-default = Reset to default

zc-config-status-alias-empty = Alias name cannot be empty
zc-config-status-alias-rename-unchanged = Alias name is unchanged
zc-config-status-alias-renamed = Renamed { $from } to { $to }
zc-config-status-alias-rename-failed = Rename failed: { $err }
zc-config-status-alias-rename-unknown = Rename outcome is unknown: { $err }. Aliases were reloaded. Check their current names before renaming again.
zc-config-status-alias-rename-unknown-refresh-failed = Rename outcome is unknown: { $err }. Reloading aliases also failed: { $refresh_err }. Reopen the section to check the saved names before renaming again.
zc-keybinding-config-tab-rename-alias = Rename provider alias
zc-config-status-alias-rename-not-applied = The daemon did not rename the alias. Edit the name and try again.
zc-config-status-alias-renamed-refresh-failed = Renamed { $from } to { $to }, but refreshing aliases failed: { $err }. Reopen the section to reload.
zc-config-status-alias-rename-warnings = Warnings: { $warnings }
zc-config-breadcrumb-rename = Rename
zc-config-alias-rename-input-hint = Enter a new alias name. The next step asks you to confirm.
zc-config-alias-rename-input-title = New alias name
zc-config-alias-rename-confirm-hint = Confirm this rename. The daemon updates existing references to the alias.
zc-config-alias-rename-confirm-title = Confirm provider alias rename
zc-config-alias-rename-confirm-target = { $path }: { $from } → { $to }
zc-config-status-alias-deleted = Deleted { $alias }
zc-config-status-alias-create-failed = Create failed: { $err }
zc-config-status-delete-failed = Delete failed: { $err }
zc-config-status-field-reset = Reset { $prop }
zc-config-status-load-failed = Load failed: { $err }
zc-config-status-save-failed = Save failed: { $err }
zc-config-status-personality-loading-file = Loading { $filename }...
zc-config-status-personality-saving-file = Saving { $filename }...
zc-config-status-personality-saved-file = Saved { $filename }
zc-config-status-template-loaded = Template loaded for { $filename }
zc-config-status-template-missing = No template available for { $filename }
zc-config-status-template-fetch-failed = Template fetch failed: { $err }
zc-config-status-skill-loading = Loading { $name }...
zc-config-status-skill-saving = Saving { $name }...
zc-config-status-skill-saved = Saved { $name }
zc-config-status-skill-deleting = Deleting { $name }...
zc-config-status-skill-archived = Archived { $name }
zc-config-status-fetching-models = Fetching models for { $family }...
zc-config-status-invalid-float = Invalid value for { $prop }: expected a number
zc-config-status-invalid-integer = Invalid value for { $prop }: expected an integer
zc-config-status-set-failed = Set failed: { $err }
zc-config-status-loading-personality = Loading personality files...
zc-config-status-loading-skills = Loading skills...
zc-config-status-fetching-templates = Fetching templates...
zc-config-status-unsaved-discarded = Unsaved changes discarded
zc-config-status-no-models = No models returned — enter manually
zc-config-status-model-fetch-failed = Model fetch failed — enter manually
zc-config-status-loading-aliases = Loading options...
zc-config-status-no-aliases = None configured yet. Enter manually.
zc-config-status-alias-fetch-failed = Options fetch failed. Enter manually.

zc-config-footer-action-create = create
zc-config-footer-action-add = add
zc-config-footer-action-rename = rename
zc-config-footer-action-review-rename = review rename
zc-config-footer-action-cancel = cancel
zc-config-footer-action-save = save
zc-config-footer-action-edit = edit
zc-config-footer-action-reset = reset
zc-config-footer-action-clear-filter = clear filter
zc-config-footer-action-back-to-files = back to files
zc-config-footer-action-back-to-skills = back to skills
zc-config-footer-action-help = help
zc-config-footer-action-new-line = new line

## Inline hint shown on the selected config field row. The { $keys } placeholder
## is resolved from the current keybinding for ConfigTabAction::Enter.
zc-config-field-edit-hint = { $keys } → press to edit

zc-doctor-log-path = log: { $path }

zc-oidc-enroll-visit = To sign in, visit { $uri } and enter code { $code }
zc-oidc-enroll-waiting = Waiting for identity-provider approval (the code expires in { $seconds } seconds)...
zc-oidc-enroll-missing-url = auth_provider { $provider } is set with no auth_token. Set [connection.wss] enroll_url to the gateway's HTTP origin to sign in interactively, or export ZEROCLAW_AUTH_TOKEN (see: zeroclaw oidc login).
zc-oidc-enroll-done = Signed in. The token is held for this session only; export ZEROCLAW_AUTH_TOKEN to skip enrollment next time.

## Config registry metadata. Stable identifiers are used for lookup while the
## RPC-provided English display strings remain compatibility fallbacks.
zc-config-group-foundation = Foundation
zc-config-group-agent = Agent
zc-config-group-multi-agent = Multi-agent
zc-config-group-tools = Tools
zc-config-group-integrations = Integrations
zc-config-group-network = Network
zc-config-group-storage = Storage
zc-config-group-operations = Operations
zc-config-group-other = Other

zc-config-section-providers-models-label = Model providers
zc-config-section-model-routes-label = Model routes
zc-config-section-embedding-routes-label = Embedding routes
zc-config-section-risk-profiles-label = Risk profiles
zc-config-section-runtime-profiles-label = Runtime profiles
zc-config-section-storage-label = Storage
zc-config-section-memory-label = Memory
zc-config-section-skills-label = Skills
zc-config-section-skill-bundles-label = Skill bundles
zc-config-section-mcp-label = MCP
zc-config-section-mcp-servers-label = MCP servers
zc-config-section-mcp-bundles-label = MCP bundles
zc-config-section-knowledge-bundles-label = Knowledge bundles
zc-config-section-providers-tts-label = TTS providers
zc-config-section-providers-transcription-label = Transcription providers
zc-config-section-channels-label = Channels
zc-config-section-hardware-label = Hardware
zc-config-section-agents-label = Agents
zc-config-section-peer-groups-label = Peer groups
zc-config-section-cron-label = Cron
zc-config-section-tunnel-label = Tunnel
zc-config-section-onboard-state-label = Quickstart state
zc-config-section-heartbeat-label = Heartbeat
zc-config-section-hooks-label = Hooks
zc-config-section-pacing-label = Pacing
zc-config-section-pipeline-label = Pipeline
zc-config-section-query-classification-label = Query classification
zc-config-section-reliability-label = Reliability
zc-config-section-runtime-label = Runtime
zc-config-section-scheduler-label = Scheduler
zc-config-section-sop-label = SOP
zc-config-section-verifiable-intent-label = Verifiable intent
zc-config-section-delegate-label = Delegate
zc-config-section-browser-label = Browser
zc-config-section-browser-delegate-label = Browser delegate
zc-config-section-http-request-label = HTTP request
zc-config-section-image-gen-label = Image generation
zc-config-section-knowledge-label = Knowledge
zc-config-section-link-enricher-label = Link enricher
zc-config-section-media-pipeline-label = Media pipeline
zc-config-section-multimodal-label = Multimodal

zc-config-section-providers-models-help = Pick a model provider to configure (Anthropic, OpenAI, OpenRouter, Ollama, custom OpenAI-compatible gateways, etc.). Multiple aliases per provider are supported.
zc-config-section-model-routes-help = Named model routing hints (for example, reasoning, fast, or code). Each route maps a hint to a provider and model.
zc-config-section-embedding-routes-help = Named embedding routing hints. Each route maps a hint to an embedding-capable provider and model.
zc-config-section-risk-profiles-help = Named risk profiles that bind allowlists, denylists, and approval thresholds.
zc-config-section-runtime-profiles-help = Named runtime tuning profiles for token limits, retry policy, and timeouts.
zc-config-section-storage-help = Configure storage backends such as SQLite, Postgres, Qdrant, Markdown, or Lucid.
zc-config-section-memory-help = Persistent memory backend. SQLite is the default; choose `none` to disable long-term recall.
zc-config-section-skills-help = Configure where skill files live and how the skills loader handles community repositories.
zc-config-section-skill-bundles-help = Named bundles of skill files that agents can load at startup.
zc-config-section-mcp-help = Model Context Protocol settings, including whether servers load eagerly or on demand.
zc-config-section-mcp-servers-help = Individual Model Context Protocol servers and their transport, command or URL, headers, and timeout.
zc-config-section-mcp-bundles-help = Named bundles of MCP servers granted to agents.
zc-config-section-knowledge-bundles-help = Named bundles of knowledge sources such as RAG indexes and document folders.
zc-config-section-providers-tts-help = Text-to-speech providers for agent voices and languages.
zc-config-section-providers-transcription-help = Speech-to-text providers for audio transcription pipelines.
zc-config-section-channels-help = Configure the chat platforms that ZeroClaw listens on.
zc-config-section-hardware-help = Optional hardware peripherals such as Arduino, STM32, and GPIO.
zc-config-section-agents-help = Configure agents that bind providers, profiles, bundles, and channels.
zc-config-section-peer-groups-help = Named groups that bind a channel, member agents, and external peers.
zc-config-section-cron-help = Scheduled tasks that bind a schedule to a prompt, channel, and target.
zc-config-section-tunnel-help = Optionally expose the gateway through Cloudflare or ngrok, or keep it local only.
zc-config-section-onboard-state-help = Quickstart lifecycle state and its legacy per-section completion ledger.

zc-config-application-title = Config change log
zc-config-application-view = change log
zc-config-application-saved = Saved { $label }.
zc-config-application-details-hint = Press { $key } to view the log.
zc-config-application-state-applied = The change has already been applied.
zc-config-application-state-pending = Applying the change…
zc-config-application-state-rejected = A running session rejected the change.
zc-config-application-state-reload = Please reload the daemon ({ $key }) to apply this change.
zc-config-application-state-reload-partial = Open sessions already use it; please reload the daemon ({ $key }) to apply it everywhere.
zc-config-application-state-sessions-only = Open sessions already use it; ZeroCode can't confirm the daemon has it.
zc-config-application-state-unknown = ZeroCode can't confirm whether the change has been applied.
zc-config-application-observed = Recent config changes on this daemon, from any client.
zc-config-application-observed-hint = Press { $key } to view the log of recent config changes.
zc-config-application-none-since-start = No config changes since the daemon started. Save a setting and its status shows here.
zc-config-application-help = { $up }/{ $down } scroll, { $pageup }/{ $pagedown } page, { $back } or { $details } close.
zc-config-application-receipt = Saved revision: { $revision }
zc-config-application-published = Latest published revision: { $revision }
zc-config-application-coverage = Recent changes only, not a complete subsystem inventory. Record limit: { $limit }. Missing records are unavailable.
zc-config-application-truncated = The ledger has evicted records; coverage is incomplete.
zc-config-application-applied = Applied live
zc-config-application-pending = Pending
zc-config-application-rejected = Rejected
zc-config-application-reload = Reload required
zc-config-application-unavailable = Application status unavailable
zc-config-application-daemon = Daemon
zc-config-application-session = Session { $id }, generation { $generation }
zc-config-application-target-unknown = Unknown target
zc-config-application-daemon-unavailable = Daemon: application status unavailable for this revision
zc-config-application-awaiting = Awaiting acknowledgement
zc-config-application-scope-unavailable = Change scope unavailable
zc-config-application-retired = Target retired
zc-config-application-whole-config = Whole configuration; individual changed paths are unavailable

# Config setup guidance. Requirements arrive from the daemon's typed schema.
zc-config-setup-model-providers = A model profile stores connection and model settings. Authentication may use an API key, an external login, or a local server.
zc-config-setup-tts-providers = Text-to-speech is optional. Add an alias to use spoken output. Cloud backends require credentials; local backends need their executable or server.
zc-config-setup-routes = Routes are optional. Add a named hint to select a configured provider and a model for that hint.
zc-config-setup-empty = No aliases are configured in this list.
zc-config-setup-add = Select [+ Add] and press { $keys } to create an entry.
zc-config-setup-create = Enter a name. { $confirm } saves it and opens fields. { $cancel } cancels without saving. Fill required fields marked [missing] and check their descriptions. Leaving those fields keeps the saved entry.
zc-config-setup-required = required
zc-config-setup-required-missing = missing
zc-config-setup-no-filter-matches = No matches. Clear filter.

zc-chat-tool-question = question

# URL-scoped remote OIDC login
zc-login-invalid-target = Expected a WSS URL without credentials, query, or fragment, or a hostname (default port 9781).
zc-login-invalid-provider = Expected an OIDC alias of 1–64 letters, digits, underscores or hyphens, starting with a letter or digit.
zc-login-tls-aborted = Login aborted: unverified TLS was not accepted. No login was saved.
zc-login-connect-timeout = The remote connection did not complete within 30 seconds.
zc-login-untrusted = Certificate verification failed for { $url }. Provide --tls-ca-cert to verify it, or explicitly accept an unverified connection below.
zc-login-rejected = The daemon did not accept this OIDC login; the previous saved login was not replaced.
zc-login-saved = Signed in to { $url }. Saved the login in { $path }. Run zerocode to connect; no auth token flags are needed.
zc-login-env-shadow = ZEROCLAW_AUTH_TOKEN is set and will override this saved login. Unset it to use the saved token.
zc-login-expired = Your saved OIDC login needs renewal. Sign in again to continue; the replacement credentials will be saved automatically.
zc-login-conflicting-route = Login takes its destination as a positional URL; do not combine it with --connect or --relay.
zc-login-device-bootstrap-failed = OIDC device bootstrap failed
zc-login-invalid-certificate-bootstrap-response = invalid certificate bootstrap response
zc-login-pkce-randomness-unavailable = system randomness unavailable for PKCE

zc-login-no-pairing-endpoint = OIDC login bootstraps the device through the gateway after sign-in; --enroll-host and --enroll-port are not used. No pairing code or SAS is needed.

zc-login-stage-credentials = Could not stage replacement device credentials; the previous saved login was not replaced.

# apps/zerocode/src/config/mod.rs. Shared by login, startup renewal, and every other config save.
zc-config-save-lock-timeout = Another process is saving { $config } and still holds { $lock } after { $seconds }s. Let the other zerocode finish saving, then try again.
zc-config-invalid-saved-login = Saved login configuration is invalid. Zerocode will not use a different login's credentials.
zc-config-migration-lock-skipped = Could not lock { $path } to update saved keybindings ({ $error }). The loaded configuration was kept and the file was not changed. Zerocode will try the update again the next time it can lock the file.
zc-config-lock-not-regular = { $path } is not a regular file, so it cannot be used as the config lock.
