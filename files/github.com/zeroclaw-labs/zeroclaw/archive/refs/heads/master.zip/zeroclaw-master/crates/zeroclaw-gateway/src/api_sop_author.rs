//! SOP authoring surface for the web node editor.
//!
//! HTTP twin of the daemon's `sops/*` RPC methods, backed by the same
//! `zeroclaw_runtime::sop` authoring core (load/save/delete, graph
//! projection, wire edits, trigger registry). All routes require gateway
//! auth. Draft endpoints (`wire-draft`, `graph-draft`) are pure: they
//! transform the submitted SOP and never touch disk.

use std::net::SocketAddr;

use axum::Json;
use axum::body::Bytes;
use axum::extract::{ConnectInfo, Path, Query, State};
use axum::http::{HeaderMap, StatusCode};
use axum::response::{IntoResponse, Response};

use super::AppState;
use super::api::require_auth;
use zeroclaw_runtime::sop::SopGraphExt;

#[derive(Debug, Default, serde::Deserialize)]
pub struct RunsQuery {
    #[serde(default)]
    pub sop: Option<String>,
}

fn sops_dir_and_mode(
    state: &AppState,
) -> (std::path::PathBuf, zeroclaw_runtime::sop::SopExecutionMode) {
    let config = state.config.read();
    let install_root = config.install_root_dir();
    let dir =
        zeroclaw_runtime::sop::resolve_sops_dir(&install_root, config.sop.sops_dir.as_deref());
    let mode = zeroclaw_runtime::sop::parse_execution_mode(&config.sop.default_execution_mode);
    (dir, mode)
}

fn sop_tool_specs(state: &AppState) -> zeroclaw_runtime::sop::ToolSpecs {
    let config = state.config.read();
    let agent = config.agents.keys().min().cloned().unwrap_or_default();
    zeroclaw_runtime::sop::tool_specs_from_config(&config, &agent)
}

pub async fn handle_sops_list(State(state): State<AppState>, headers: HeaderMap) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let (dir, mode) = sops_dir_and_mode(&state);
    let sops = zeroclaw_runtime::sop::load_sops_from_directory(&dir, mode);
    Json(serde_json::json!({ "sops": sops })).into_response()
}

pub async fn handle_sop_trigger_sources(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let registry = {
        let config = state.config.read();
        zeroclaw_runtime::sop::registry_from_config(&config)
    };
    Json(registry).into_response()
}

/// `GET /api/sops/decision-models`: the `[decision_models]` aliases an SOP's
/// `[decision] model` can select, sorted by alias. Never includes the API key.
pub async fn handle_sop_decision_models(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let mut models: Vec<_> = {
        let config = state.config.read();
        config
            .decision_models
            .iter()
            .filter_map(|(alias, m)| {
                let (base_url, model) = m.endpoint()?;
                Some(serde_json::json!({
                    "alias": alias,
                    "provider": m.provider,
                    "model": model,
                    "base_url": base_url,
                }))
            })
            .collect()
    };
    models.sort_by(|a, b| a["alias"].as_str().cmp(&b["alias"].as_str()));
    Json(serde_json::json!({ "models": models })).into_response()
}

/// Body for `POST /api/tools/param-options`: resolve selectable values
/// for a domain-typed tool parameter. `args` carries sibling arguments
/// already chosen so cascading domains (e.g. peer targets narrowing on
/// a channel) can filter.
#[derive(serde::Deserialize)]
pub struct ParamOptionsBody {
    pub domain: zeroclaw_api::tool::OptionDomain,
    #[serde(default)]
    pub agent: Option<String>,
    #[serde(default)]
    pub args: serde_json::Value,
}

pub async fn handle_tools_param_options(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(body): Json<ParamOptionsBody>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let config = state.config.read();
    let agent_alias = body
        .agent
        .as_deref()
        .map(str::trim)
        .filter(|a| !a.is_empty())
        .map(str::to_string)
        .or_else(|| config.agents.keys().min().cloned())
        .unwrap_or_default();

    let entries = if body.domain == zeroclaw_api::tool::OptionDomain::ToolNames {
        let security = std::sync::Arc::new(
            zeroclaw_config::policy::SecurityPolicy::for_agent(&config, &agent_alias)
                .unwrap_or_default(),
        );
        let tools = zeroclaw_runtime::tools::default_tools(security);
        let refs: Vec<&dyn zeroclaw_api::tool::Tool> =
            tools.iter().map(std::convert::AsRef::as_ref).collect();
        zeroclaw_runtime::tools::param_options::resolve_options(
            body.domain,
            &config,
            &agent_alias,
            &body.args,
            &refs,
        )
    } else {
        zeroclaw_runtime::tools::param_options::resolve_options(
            body.domain,
            &config,
            &agent_alias,
            &body.args,
            &[],
        )
    };
    Json(serde_json::json!({ "options": entries })).into_response()
}

pub async fn handle_sop_graph(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(name): Path<String>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let (dir, mode) = sops_dir_and_mode(&state);
    match zeroclaw_runtime::sop::load_sop_by_name(&dir, &name, mode) {
        Ok(sop) => {
            let graph =
                zeroclaw_runtime::sop::SopGraph::from_sop_with_specs(&sop, &sop_tool_specs(&state));
            Json(graph).into_response()
        }
        Err(e) => (
            StatusCode::NOT_FOUND,
            Json(serde_json::json!({ "error": format!("SOP '{name}': {e}") })),
        )
            .into_response(),
    }
}

/// Body for `POST /api/sops/{name}/run`: fire a Manual trigger. `payload` is
/// an optional JSON string handed to the run as the step-1 input. Deserializes
/// from the shared `SopRunRequest` shape (minus `name`, which comes from the
/// path).
#[derive(serde::Deserialize)]
pub struct SopRunBody {
    #[serde(default)]
    pub payload: Option<String>,
    /// Optional semantic work-item key shared with another producer, such as a
    /// Git-channel event. Matching keys coalesce only while the first run is active.
    #[serde(default)]
    pub dedup_key: Option<String>,
}

/// Fire a Manual run for the named SOP and return its `run_id`.
///
/// Thin exposure of the engine dispatch path the `sop_execute` tool uses:
/// builds a Manual `SopEvent` and calls `dispatch_sop_event_to`, which still
/// requires the SOP to declare a matching Manual trigger. The returned
/// `run_id` feeds straight into `sops/{name}/runs/{run_id}/overlay`.
pub async fn handle_sop_run(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(name): Path<String>,
    Json(body): Json<SopRunBody>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }

    if let Some(payload) = body.payload.as_deref()
        && !payload.trim().is_empty()
        && serde_json::from_str::<serde_json::Value>(payload).is_err()
    {
        return (
            StatusCode::BAD_REQUEST,
            Json(serde_json::json!({ "error": "payload is not valid JSON" })),
        )
            .into_response();
    }

    let Some(engine) = state.sop_engine.as_ref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({ "error": "SOP subsystem not enabled" })),
        )
            .into_response();
    };
    let Some(audit) = state.sop_audit.as_ref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({ "error": "SOP subsystem not enabled" })),
        )
            .into_response();
    };

    // A dashboard run emits a Manual event but has no agent turn behind it: the
    // driver below executes the step, so an unowned procedure would start, burn
    // a run id, and fail its first step. Refuse before dispatch, on the same
    // ownership rule the driver and the authoring gate apply.
    let ownership_refusal = match engine.lock() {
        Ok(guard) => guard
            .get_sop(&name)
            .and_then(zeroclaw_runtime::sop::headless_ownership_refusal),
        Err(_) => {
            return (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({ "error": "SOP engine lock poisoned" })),
            )
                .into_response();
        }
    };
    if let Some(refusal) = ownership_refusal {
        return (
            StatusCode::UNPROCESSABLE_ENTITY,
            Json(serde_json::json!({ "error": refusal })),
        )
            .into_response();
    }

    let payload = body
        .payload
        .as_deref()
        .map(str::trim)
        .filter(|p| !p.is_empty())
        .map(str::to_string);
    let dedup_key = body
        .dedup_key
        .as_deref()
        .map(str::trim)
        .filter(|key| !key.is_empty());
    if dedup_key
        .is_some_and(|key| key.len() > zeroclaw_runtime::sop::dispatch::MAX_ACTIVE_DEDUP_KEY_BYTES)
    {
        return (
            StatusCode::BAD_REQUEST,
            Json(serde_json::json!({
                "error": format!(
                    "dedup_key exceeds {} bytes",
                    zeroclaw_runtime::sop::dispatch::MAX_ACTIVE_DEDUP_KEY_BYTES
                )
            })),
        )
            .into_response();
    }

    let event = zeroclaw_runtime::sop::SopEvent {
        source: zeroclaw_runtime::sop::SopTriggerSource::Manual,
        topic: None,
        payload,
        timestamp: zeroclaw_runtime::sop::engine::now_iso8601(),
    };

    let results = if let Some(dedup_key) = dedup_key {
        zeroclaw_runtime::sop::dispatch::dispatch_sop_event_to_deduplicated(
            engine, audit, event, &name, dedup_key,
        )
        .await
    } else {
        zeroclaw_runtime::sop::dispatch::dispatch_sop_event_to(engine, audit, event, &name).await
    };
    zeroclaw_runtime::sop::dispatch::process_headless_results(&results);

    for result in &results {
        match result {
            zeroclaw_runtime::sop::dispatch::DispatchResult::Started { run_id, action, .. } => {
                let needs_driver = matches!(
                    action.as_ref(),
                    zeroclaw_runtime::sop::SopRunAction::ExecuteStep { .. }
                        | zeroclaw_runtime::sop::SopRunAction::DeterministicStep { .. }
                );
                if needs_driver {
                    let config = state.config.read().clone();
                    // A dashboard run outlives the request that started it, but
                    // it does not outlive the daemon generation whose config and
                    // engine it captured: it is admitted into that generation's
                    // set like every other surface, so one reload drains all of
                    // them, and a generation that has already drained refuses it
                    // before it starts. Only a caller with no generation to
                    // belong to (a standalone gateway) detaches.
                    match state.sop_driver_handles.as_ref() {
                        Some(handles) => {
                            zeroclaw_runtime::sop::spawn_and_register_sop_driver_with_capability(
                                handles,
                                config,
                                std::sync::Arc::clone(engine),
                                Some(std::sync::Arc::clone(audit)),
                                action.as_ref().clone(),
                                Some(
                                    zeroclaw_runtime::live_config_authority::AgentExecutionCapability::from_parts(
                                        state.config.clone(),
                                        state.agent_lifecycle.clone(),
                                    ),
                                ),
                            );
                        }
                        None => {
                            zeroclaw_runtime::sop::spawn_headless_run_driver_with_capability(
                                config,
                                std::sync::Arc::clone(engine),
                                Some(std::sync::Arc::clone(audit)),
                                action.as_ref().clone(),
                                Some(
                                    zeroclaw_runtime::live_config_authority::AgentExecutionCapability::from_parts(
                                        state.config.clone(),
                                        state.agent_lifecycle.clone(),
                                    ),
                                ),
                            );
                        }
                    }
                }
                return Json(serde_json::json!({ "run_id": run_id })).into_response();
            }
            zeroclaw_runtime::sop::dispatch::DispatchResult::Skipped { reason, .. } => {
                return (
                    StatusCode::CONFLICT,
                    Json(serde_json::json!({ "error": reason })),
                )
                    .into_response();
            }
            zeroclaw_runtime::sop::dispatch::DispatchResult::BlockedUnsafe { reason, .. } => {
                return (
                    StatusCode::UNPROCESSABLE_ENTITY,
                    Json(serde_json::json!({ "error": reason })),
                )
                    .into_response();
            }
            zeroclaw_runtime::sop::dispatch::DispatchResult::Deferred { reason, .. } => {
                return (
                    StatusCode::SERVICE_UNAVAILABLE,
                    Json(serde_json::json!({ "error": reason })),
                )
                    .into_response();
            }
            zeroclaw_runtime::sop::dispatch::DispatchResult::Coalesced {
                existing_run_id, ..
            } => {
                return Json(serde_json::json!({ "run_id": existing_run_id })).into_response();
            }
            zeroclaw_runtime::sop::dispatch::DispatchResult::NoMatch => {}
        }
    }

    (
        StatusCode::NOT_FOUND,
        Json(serde_json::json!({
            "error": format!("SOP '{name}' has no matching manual trigger")
        })),
    )
        .into_response()
}

pub async fn handle_sop_runs(
    State(state): State<AppState>,
    headers: HeaderMap,
    Query(query): Query<RunsQuery>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let Some(engine) = state.sop_engine.as_ref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({ "error": "SOP subsystem not enabled" })),
        )
            .into_response();
    };
    match zeroclaw_runtime::sop::run_summaries_for(engine, query.sop.as_deref()) {
        Ok(runs) => Json(serde_json::json!({ "runs": runs })).into_response(),
        Err(e) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(serde_json::json!({ "error": e.to_string() })),
        )
            .into_response(),
    }
}

pub async fn handle_sop_run_overlay(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path((name, run_id)): Path<(String, String)>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let (dir, mode) = sops_dir_and_mode(&state);
    let sop = match zeroclaw_runtime::sop::load_sop_by_name(&dir, &name, mode) {
        Ok(sop) => sop,
        Err(e) => {
            return (
                StatusCode::NOT_FOUND,
                Json(serde_json::json!({ "error": format!("SOP '{name}': {e}") })),
            )
                .into_response();
        }
    };
    let Some(engine) = state.sop_engine.as_ref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({ "error": "SOP subsystem not enabled" })),
        )
            .into_response();
    };
    match zeroclaw_runtime::sop::run_overlay_for(&sop, engine, &run_id) {
        Ok(overlay) => Json(overlay).into_response(),
        Err(e) => {
            let msg = e.to_string();
            let code = if msg.contains("not found") {
                StatusCode::NOT_FOUND
            } else {
                StatusCode::INTERNAL_SERVER_ERROR
            };
            (code, Json(serde_json::json!({ "error": msg }))).into_response()
        }
    }
}

/// Resolve a gated live run. Body carries the raw `ApprovalDecision` wire
/// value. Waiting approvals and deterministic checkpoints both resolve through
/// the broker-backed chokepoint with an HTTP principal, so named approval
/// policies, membership, and quorum are enforced before a gate or checkpoint can
/// clear. Returns the refreshed overlay.
pub async fn handle_sop_decide(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path((name, run_id)): Path<(String, String)>,
    Json(decision_value): Json<serde_json::Value>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    // Derive the transport-authenticated approval subject (the paired-token hash)
    // from the validated bearer, mirroring the /admin/sop approval route's
    // `authorize`, so the broker can enforce a required-group / quorum policy on this
    // authoring surface instead of resolving an anonymous `http(None)` past it. Gated
    // on `require_pairing`: when pairing is OFF every token is a no-op pass-through, so
    // deriving an identity from an unauthenticated header would let any caller fabricate
    // an approval subject - fall back to `http(None)` (which fails a required-group
    // policy closed) in that mode, matching `authorize`.
    let subject = state
        .pairing
        .require_pairing()
        .then(|| crate::api::extract_bearer_token(&headers))
        .flatten()
        .and_then(|t| state.pairing.authenticate_and_hash(t));
    let principal = zeroclaw_runtime::sop::approval::ApprovalPrincipal::http(subject);
    let decision: zeroclaw_runtime::sop::approval::ApprovalDecision =
        match serde_json::from_value(decision_value) {
            Ok(d) => d,
            Err(e) => {
                return (
                    StatusCode::BAD_REQUEST,
                    Json(serde_json::json!({
                        "error": format!("decision is not a valid approval decision: {e}")
                    })),
                )
                    .into_response();
            }
        };
    let (dir, mode) = sops_dir_and_mode(&state);
    let sop = match zeroclaw_runtime::sop::load_sop_by_name(&dir, &name, mode) {
        Ok(sop) => sop,
        Err(e) => {
            return (
                StatusCode::NOT_FOUND,
                Json(serde_json::json!({ "error": format!("SOP '{name}': {e}") })),
            )
                .into_response();
        }
    };
    let Some(engine) = state.sop_engine.as_ref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({ "error": "SOP subsystem not enabled" })),
        )
            .into_response();
    };

    let agent_alias = sop.agent.clone().unwrap_or_default();
    let span = ::zeroclaw_log::info_span!(
        target: "zeroclaw_log_internal_scope",
        "zeroclaw_scope",
        session_key = %run_id,
        agent_alias = %agent_alias,
        channel = "gateway",
    );
    let _guard = span.enter();

    let mut resolved_outcome = None;
    let mut pending_quorum = false;
    {
        let mut guard = match engine.lock() {
            Ok(g) => g,
            Err(_) => {
                return (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    Json(serde_json::json!({ "error": "SOP engine lock poisoned" })),
                )
                    .into_response();
            }
        };
        let run_sop_name = match guard.get_run(&run_id).map(|run| run.sop_name.clone()) {
            Some(name) => name,
            None => {
                return (
                    StatusCode::NOT_FOUND,
                    Json(serde_json::json!({
                        "error": format!("Run {run_id} not found")
                    })),
                )
                    .into_response();
            }
        };
        if run_sop_name != name {
            return (
                StatusCode::BAD_REQUEST,
                Json(serde_json::json!({
                    "error": format!("run '{run_id}' belongs to SOP '{run_sop_name}', not '{name}'")
                })),
            )
                .into_response();
        }
        let status = guard.get_run(&run_id).map(|r| r.status);
        match status {
            Some(
                zeroclaw_runtime::sop::types::SopRunStatus::WaitingApproval
                | zeroclaw_runtime::sop::types::SopRunStatus::PausedCheckpoint,
            ) => {
                use zeroclaw_runtime::sop::approval::{BrokerOutcome, ResolveOutcome};
                // Route through the broker (membership + quorum), not `resolve_gate`
                // directly, otherwise this authoring surface would
                // clear a policied approval gate without enforcing group membership or
                // quorum. With no `[sop.approval]` policy this is exactly `resolve_gate`.
                match guard.resolve_via_broker_deferred(&run_id, decision, principal) {
                    Ok(outcome @ BrokerOutcome::Resolved(ResolveOutcome::Resumed(_))) => {
                        resolved_outcome = Some(outcome);
                    }
                    Ok(BrokerOutcome::Resolved(
                        ResolveOutcome::Denied
                        | ResolveOutcome::AlreadyResolved
                        | ResolveOutcome::Revised,
                    )) => {}
                    Ok(
                        BrokerOutcome::Resolved(ResolveOutcome::NotWaiting)
                        | BrokerOutcome::NotWaiting,
                    ) => {
                        return (
                            StatusCode::CONFLICT,
                            Json(serde_json::json!({
                                "error": format!("Run {run_id} is not waiting for approval")
                            })),
                        )
                            .into_response();
                    }
                    Ok(BrokerOutcome::Resolved(ResolveOutcome::RejectedSelfApproval)) => {
                        return (
                            StatusCode::FORBIDDEN,
                            Json(serde_json::json!({
                                "error": "approval_mode forbids this principal from clearing the gate"
                            })),
                        )
                            .into_response();
                    }
                    Ok(BrokerOutcome::Resolved(ResolveOutcome::DeferredAtCapacity)) => {
                        return (
                            StatusCode::SERVICE_UNAVAILABLE,
                            Json(serde_json::json!({
                                "outcome": "deferred_at_capacity",
                                "run_id": run_id,
                            })),
                        )
                            .into_response();
                    }
                    Ok(BrokerOutcome::NotAuthorized { required_group }) => {
                        return (
                            StatusCode::FORBIDDEN,
                            Json(serde_json::json!({
                                "error": format!("not authorized: requires group '{required_group}'")
                            })),
                        )
                            .into_response();
                    }
                    // A step naming an absent policy is a server-side config defect:
                    // fail closed (gate left waiting), never a silent clear.
                    Ok(BrokerOutcome::PolicyMissing { name }) => {
                        return (
                            StatusCode::INTERNAL_SERVER_ERROR,
                            Json(serde_json::json!({
                                "error": format!("approval policy '{name}' is not configured (gate left waiting)")
                            })),
                        )
                            .into_response();
                    }
                    Ok(BrokerOutcome::PolicyUnavailable { reason }) => {
                        return (
                            StatusCode::INTERNAL_SERVER_ERROR,
                            Json(serde_json::json!({
                                "error": "policy_unavailable",
                                "reason": reason,
                            })),
                        )
                            .into_response();
                    }
                    // The vote counted but quorum is not yet met: the gate stays
                    // waiting for the remaining approvers.
                    Ok(BrokerOutcome::PendingQuorum { .. }) => {
                        pending_quorum = true;
                    }
                    Err(e) => {
                        return (
                            StatusCode::INTERNAL_SERVER_ERROR,
                            Json(serde_json::json!({ "error": e.to_string() })),
                        )
                            .into_response();
                    }
                }
            }
            _ => {
                return (
                    StatusCode::BAD_REQUEST,
                    Json(serde_json::json!({
                        "error": format!(
                            "Run {run_id} is not waiting for approval or paused at a checkpoint"
                        )
                    })),
                )
                    .into_response();
            }
        }
    }

    if pending_quorum {
        return match zeroclaw_runtime::sop::run_overlay_for(&sop, engine, &run_id) {
            Ok(overlay) => (StatusCode::ACCEPTED, Json(overlay)).into_response(),
            Err(e) => {
                let msg = e.to_string();
                let code = if msg.contains("not found") {
                    StatusCode::NOT_FOUND
                } else {
                    StatusCode::INTERNAL_SERVER_ERROR
                };
                (code, Json(serde_json::json!({ "error": msg }))).into_response()
            }
        };
    }

    if let Some(outcome) = resolved_outcome {
        let config = state.config.read().clone();
        zeroclaw_runtime::sop::drive_resumed_broker_action_with_capability(
            &config,
            std::sync::Arc::clone(engine),
            state.sop_audit.clone(),
            state.sop_driver_handles.as_ref(),
            &outcome,
            Some(
                zeroclaw_runtime::live_config_authority::AgentExecutionCapability::from_parts(
                    state.config.clone(),
                    state.agent_lifecycle.clone(),
                ),
            ),
        );
    }

    match zeroclaw_runtime::sop::run_overlay_for(&sop, engine, &run_id) {
        Ok(overlay) => Json(overlay).into_response(),
        Err(e) => {
            let msg = e.to_string();
            let code = if msg.contains("not found") {
                StatusCode::NOT_FOUND
            } else {
                StatusCode::INTERNAL_SERVER_ERROR
            };
            (code, Json(serde_json::json!({ "error": msg }))).into_response()
        }
    }
}

#[derive(Debug, Default, serde::Deserialize)]
pub struct SopCancelBody {
    #[serde(default)]
    pub reason: Option<String>,
}

#[derive(Debug, serde::Serialize)]
struct SopCancelResponse {
    run_id: String,
    sop_name: String,
    status: zeroclaw_runtime::sop::types::SopRunStatus,
    already_terminal: bool,
    run: zeroclaw_runtime::sop::types::SopRunSummary,
}

fn authorize_sop_cancel(
    state: &AppState,
    peer: &SocketAddr,
    headers: &HeaderMap,
) -> Result<zeroclaw_runtime::sop::approval::ApprovalPrincipal, Box<Response>> {
    if state.pairing.require_pairing() {
        require_auth(state, headers).map_err(|error| Box::new(error.into_response()))?;
        let subject = super::api::extract_bearer_token(headers)
            .and_then(|token| state.pairing.authenticate_and_hash(token));
        return Ok(zeroclaw_runtime::sop::approval::ApprovalPrincipal::http(
            subject,
        ));
    }
    // Same locality rule as the rate-limit key: a forwarded loopback address
    // is never local, even when the peer itself is loopback.
    if super::request_is_local(Some(*peer), headers, state.trust_forwarded_headers) {
        return Ok(zeroclaw_runtime::sop::approval::ApprovalPrincipal::cli(
            None,
        ));
    }
    Err(Box::new(
        (
            StatusCode::FORBIDDEN,
            Json(serde_json::json!({
                "error": "Remote SOP cancellation requires gateway pairing. Enable \
                          gateway.require_pairing and pair first, or call from localhost."
            })),
        )
            .into_response(),
    ))
}

/// POST /api/sops/{name}/runs/{run_id}/cancel - operator cancellation for a
/// running SOP. This is a SAFE cancel: the in-flight step keeps running to
/// its own completion and the run stops at the next step boundary, not
/// mid-step. Idempotent and race-safe against normal completion - a run that
/// is already terminal (previously cancelled, or it finished or failed
/// first) is reported as-is with `already_terminal: true`, never a second
/// cancellation or an error.
pub async fn handle_sop_cancel(
    State(state): State<AppState>,
    ConnectInfo(peer): ConnectInfo<SocketAddr>,
    headers: HeaderMap,
    Path((name, run_id)): Path<(String, String)>,
    body: Bytes,
) -> Response {
    let principal = match authorize_sop_cancel(&state, &peer, &headers) {
        Ok(principal) => principal,
        Err(response) => return *response,
    };
    // The body is optional (`{ "reason": ... }` or nothing at all), unlike
    // `handle_sop_decide`'s required decision payload, so an empty body is a
    // valid no-reason request rather than a parse error.
    let reason = if body.is_empty() {
        None
    } else {
        match serde_json::from_slice::<SopCancelBody>(&body) {
            Ok(b) => b.reason,
            Err(e) => {
                return (
                    StatusCode::BAD_REQUEST,
                    Json(serde_json::json!({
                        "error": format!("invalid cancel request body: {e}")
                    })),
                )
                    .into_response();
            }
        }
    };

    let Some(engine) = state.sop_engine.as_ref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({ "error": "SOP subsystem not enabled" })),
        )
            .into_response();
    };

    let mut guard = match engine.lock() {
        Ok(g) => g,
        Err(_) => {
            return (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({ "error": "SOP engine lock poisoned" })),
            )
                .into_response();
        }
    };

    // Resolve, classify, and act under this single lock hold so a normal
    // completion racing the operator's cancel request cannot land between a
    // check and a later re-lock.
    let run_sop_name = match guard.get_run(&run_id).map(|run| run.sop_name.clone()) {
        Some(name) => name,
        None => {
            return (
                StatusCode::NOT_FOUND,
                Json(serde_json::json!({ "error": format!("Run {run_id} not found") })),
            )
                .into_response();
        }
    };
    if run_sop_name != name {
        return (
            StatusCode::BAD_REQUEST,
            Json(serde_json::json!({
                "error": format!("run '{run_id}' belongs to SOP '{run_sop_name}', not '{name}'")
            })),
        )
            .into_response();
    }

    use zeroclaw_runtime::sop::{CancelOutcome, err_is_cancellation_persistence_retained};
    let outcome = guard.cancel_run_idempotent(&run_id, reason, Some(principal.voter_key()));
    match outcome {
        Ok(Some(outcome)) => {
            let (code, already_terminal) = match outcome {
                CancelOutcome::Requested | CancelOutcome::AlreadyRequested => {
                    (StatusCode::ACCEPTED, false)
                }
                CancelOutcome::Cancelled => (StatusCode::OK, false),
                CancelOutcome::AlreadyTerminal(_) => (StatusCode::OK, true),
            };
            let Some(run) = guard.get_run(&run_id) else {
                return (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    Json(serde_json::json!({
                        "error": "run disappeared after cancellation transition"
                    })),
                )
                    .into_response();
            };
            let summary = zeroclaw_runtime::sop::types::SopRunSummary::from_run(
                run,
                guard.active_runs().contains_key(&run_id),
            );
            (
                code,
                Json(SopCancelResponse {
                    run_id,
                    sop_name: run_sop_name,
                    status: summary.status,
                    already_terminal,
                    run: summary,
                }),
            )
                .into_response()
        }
        Ok(None) => (
            StatusCode::NOT_FOUND,
            Json(serde_json::json!({ "error": format!("Run {run_id} not found") })),
        )
            .into_response(),
        Err(e) if err_is_cancellation_persistence_retained(&e) => (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({
                "error": "cancellation could not be durably persisted; the run remains active - retry"
            })),
        )
            .into_response(),
        Err(e) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(serde_json::json!({ "error": e.to_string() })),
        )
            .into_response(),
    }
}

pub async fn handle_sop_full(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(name): Path<String>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let (dir, mode) = sops_dir_and_mode(&state);
    match zeroclaw_runtime::sop::load_sop_by_name(&dir, &name, mode) {
        Ok(sop) => Json(sop).into_response(),
        Err(e) => (
            StatusCode::NOT_FOUND,
            Json(serde_json::json!({ "error": format!("SOP '{name}': {e}") })),
        )
            .into_response(),
    }
}

pub async fn handle_sop_create(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(sop): Json<zeroclaw_runtime::sop::Sop>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let (dir, _mode) = sops_dir_and_mode(&state);
    match zeroclaw_runtime::sop::create_sop_typed(&dir, &sop) {
        Ok(()) => Json(serde_json::json!({ "created": sop.name })).into_response(),
        Err(e) => {
            let code = match e {
                zeroclaw_runtime::sop::SopAuthorError::AlreadyExists(_) => StatusCode::CONFLICT,
                _ => StatusCode::BAD_REQUEST,
            };
            (code, Json(serde_json::json!({ "error": e.to_string() }))).into_response()
        }
    }
}

pub async fn handle_sop_save(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(name): Path<String>,
    Json(mut sop): Json<zeroclaw_runtime::sop::Sop>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    if !sop.name.is_empty() && sop.name != name {
        return (
            StatusCode::BAD_REQUEST,
            Json(serde_json::json!({
                "error": format!(
                    "body name '{}' does not match URL name '{name}'",
                    sop.name
                )
            })),
        )
            .into_response();
    }
    sop.name = name;
    let (dir, _mode) = sops_dir_and_mode(&state);
    // `PUT` edits the SOP named in its URL. If that SOP has been renamed or
    // deleted since the client loaded it, refuse instead of recreating it
    // under the retired name; creating a SOP is `POST /api/sops`.
    match zeroclaw_runtime::sop::save_existing_sop_typed(&dir, &sop) {
        Ok(()) => Json(serde_json::json!({ "saved": sop.name })).into_response(),
        Err(e) => {
            let code = match e {
                zeroclaw_runtime::sop::SopAuthorError::NotFound(_) => StatusCode::NOT_FOUND,
                zeroclaw_runtime::sop::SopAuthorError::Io(_) => StatusCode::INTERNAL_SERVER_ERROR,
                _ => StatusCode::BAD_REQUEST,
            };
            (code, Json(serde_json::json!({ "error": e.to_string() }))).into_response()
        }
    }
}

/// Body for `POST /api/sops/{name}/rename`: the name to move the SOP to.
#[derive(serde::Deserialize)]
pub struct SopRenameBody {
    pub to: String,
}

/// Move a SOP to a new name. `PUT /api/sops/{name}` can only ever overwrite
/// the SOP named in its own URL, so a name change is its own collision-checked
/// operation rather than a save with a different name in the body.
pub async fn handle_sop_rename(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(name): Path<String>,
    Json(body): Json<SopRenameBody>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let (dir, mode) = sops_dir_and_mode(&state);
    match zeroclaw_runtime::sop::rename_sop_typed(&dir, &name, &body.to, mode) {
        Ok(()) => Json(serde_json::json!({ "renamed": body.to, "from": name })).into_response(),
        Err(e) => {
            let code = match e {
                zeroclaw_runtime::sop::SopAuthorError::NotFound(_) => StatusCode::NOT_FOUND,
                zeroclaw_runtime::sop::SopAuthorError::AlreadyExists(_) => StatusCode::CONFLICT,
                zeroclaw_runtime::sop::SopAuthorError::Io(_) => StatusCode::INTERNAL_SERVER_ERROR,
                zeroclaw_runtime::sop::SopAuthorError::Other(_) => StatusCode::BAD_REQUEST,
            };
            (code, Json(serde_json::json!({ "error": e.to_string() }))).into_response()
        }
    }
}

pub async fn handle_sop_delete(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(name): Path<String>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let (dir, _mode) = sops_dir_and_mode(&state);
    match zeroclaw_runtime::sop::delete_sop_typed(&dir, &name) {
        Ok(()) => Json(serde_json::json!({ "deleted": name })).into_response(),
        Err(e) => {
            let code = match e {
                zeroclaw_runtime::sop::SopAuthorError::NotFound(_) => StatusCode::NOT_FOUND,
                _ => StatusCode::INTERNAL_SERVER_ERROR,
            };
            (code, Json(serde_json::json!({ "error": e.to_string() }))).into_response()
        }
    }
}

/// Body for `wire-draft`: a full draft SOP plus one edit to apply.
#[derive(serde::Deserialize)]
pub struct WireDraftRequest {
    pub sop: zeroclaw_runtime::sop::Sop,
    pub edit: zeroclaw_runtime::sop::WireEdit,
}

pub async fn handle_sop_wire_draft(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<WireDraftRequest>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let mut sop = req.sop;
    if let Err(e) = zeroclaw_runtime::sop::apply_wire(&mut sop, &req.edit) {
        return (
            StatusCode::BAD_REQUEST,
            Json(serde_json::json!({ "error": e.to_string() })),
        )
            .into_response();
    }
    let graph = zeroclaw_runtime::sop::SopGraph::from_sop_with_specs(&sop, &sop_tool_specs(&state));
    Json(serde_json::json!({ "sop": sop, "graph": graph })).into_response()
}

/// Body for `graph-draft`: a full draft SOP to project without saving.
#[derive(serde::Deserialize)]
pub struct GraphDraftRequest {
    pub sop: zeroclaw_runtime::sop::Sop,
}

pub async fn handle_sop_graph_draft(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<GraphDraftRequest>,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    let graph =
        zeroclaw_runtime::sop::SopGraph::from_sop_with_specs(&req.sop, &sop_tool_specs(&state));
    Json(graph).into_response()
}

pub async fn handle_sop_graph_legend(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Response {
    if let Err(e) = require_auth(&state, &headers) {
        return e.into_response();
    }
    Json(zeroclaw_runtime::sop::GraphLegend::canonical()).into_response()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;
    use std::sync::{Arc, Mutex};

    use axum::extract::{Path, State};
    use axum::http::{HeaderValue, header};
    use http_body_util::BodyExt;
    use zeroclaw_config::schema::{
        ApprovalGroupConfig, ApprovalPolicyConfig, SopApprovalConfig, SopConfig,
    };
    use zeroclaw_runtime::security::pairing::PairingGuard;
    use zeroclaw_runtime::sop::approval::ApprovalBroker;
    use zeroclaw_runtime::sop::engine::{SopEngine, now_iso8601};
    use zeroclaw_runtime::sop::types::{
        Sop, SopAdmissionPolicy, SopEvent, SopExecutionMode, SopPriority, SopRunAction,
        SopRunStatus, SopStep, SopStepKind, SopTrigger, SopTriggerSource,
    };

    fn bearer(token: &str) -> HeaderMap {
        let mut headers = HeaderMap::new();
        headers.insert(
            header::AUTHORIZATION,
            HeaderValue::from_str(&format!("Bearer {token}")).unwrap(),
        );
        headers
    }

    fn loopback_peer() -> ConnectInfo<SocketAddr> {
        ConnectInfo(SocketAddr::from(([127, 0, 0, 1], 42_000)))
    }

    fn remote_peer() -> ConnectInfo<SocketAddr> {
        ConnectInfo(SocketAddr::from(([203, 0, 113, 7], 42_000)))
    }

    fn authoring_policy_sop() -> Sop {
        Sop {
            name: "deploy".into(),
            description: "t".into(),
            version: "1.0.0".into(),
            priority: SopPriority::Normal,
            execution_mode: SopExecutionMode::Supervised,
            triggers: vec![SopTrigger::Manual],
            steps: vec![SopStep {
                number: 1,
                title: "gate".into(),
                requires_confirmation: true,
                kind: SopStepKind::Execute,
                policy: Some("prod".into()),
                ..SopStep::default()
            }],
            cooldown_secs: 0,
            max_concurrent: 1,
            location: None,
            deterministic: false,
            agent: None,
            admission_policy: SopAdmissionPolicy::Parallel,
            max_pending_approvals: 0,
            decision: None,
        }
    }

    /// A Manual SOP whose one `execute` step resolves an owner only when
    /// `owner` is set. `sop_execute` would run it under the calling agent; the
    /// dashboard has no such agent.
    fn manual_execute_sop(owner: Option<&str>) -> Sop {
        Sop {
            name: "nightly".into(),
            description: "t".into(),
            version: "1.0.0".into(),
            priority: SopPriority::Normal,
            execution_mode: SopExecutionMode::Auto,
            triggers: vec![SopTrigger::Manual],
            steps: vec![SopStep {
                number: 1,
                title: "collect".into(),
                kind: SopStepKind::Execute,
                ..SopStep::default()
            }],
            cooldown_secs: 0,
            max_concurrent: 1,
            location: None,
            deterministic: false,
            agent: owner.map(str::to_string),
            admission_policy: SopAdmissionPolicy::Parallel,
            max_pending_approvals: 0,
            decision: None,
        }
    }

    fn manual_run_state(sop: Sop) -> (tempfile::TempDir, AppState) {
        let tmp = tempfile::tempdir().unwrap();
        let sops_dir = tmp.path().join("sops");
        zeroclaw_runtime::sop::save_sop(&sops_dir, &sop).unwrap();

        let mut engine = SopEngine::new(SopConfig::default());
        engine.set_sops_for_test(vec![sop]);

        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        config.sop.sops_dir = Some(sops_dir.to_string_lossy().into_owned());
        let mut state = crate::api::test_state(config);
        state.sop_engine = Some(Arc::new(Mutex::new(engine)));
        state.sop_audit = Some(Arc::new(zeroclaw_runtime::sop::SopAuditLogger::new(
            Arc::new(zeroclaw_memory::NoneMemory::new("none")),
        )));
        (tmp, state)
    }

    /// A dashboard run drives the SOP through the headless driver, which has no
    /// agent turn to inherit an owner from. Starting an unowned procedure here
    /// would burn a run id and fail its first step, so the surface refuses it up
    /// front — the authoring gate lets the SOP save because `sop_execute` can
    /// still run it under the calling agent.
    #[tokio::test]
    async fn manual_run_refuses_an_unowned_procedure_before_starting_it() {
        let (_tmp, state) = manual_run_state(manual_execute_sop(None));

        let resp = handle_sop_run(
            State(state.clone()),
            HeaderMap::new(),
            Path("nightly".to_string()),
            Json(SopRunBody {
                payload: None,
                dedup_key: None,
            }),
        )
        .await;

        assert_eq!(
            resp.status(),
            StatusCode::UNPROCESSABLE_ENTITY,
            "a dashboard-started run with no owning agent must be refused"
        );
        assert!(
            state
                .sop_engine
                .as_ref()
                .unwrap()
                .lock()
                .unwrap()
                .active_runs()
                .is_empty(),
            "the refusal must land before a run is started"
        );
    }

    #[tokio::test]
    async fn manual_run_starts_an_owned_procedure() {
        let (_tmp, state) = manual_run_state(manual_execute_sop(Some("ops")));

        let resp = handle_sop_run(
            State(state.clone()),
            HeaderMap::new(),
            Path("nightly".to_string()),
            Json(SopRunBody {
                payload: None,
                dedup_key: None,
            }),
        )
        .await;

        assert_eq!(
            resp.status(),
            StatusCode::OK,
            "an owned procedure must still start from the dashboard"
        );
    }

    /// A dashboard run outlives the request that started it, but not the daemon
    /// generation whose config and engine its driver captured. Detaching the
    /// handle — the earlier behaviour — left that driver working across a reload
    /// that superseded its configuration, with nothing left to drain or observe
    /// it. It registers with the generation's set like every other surface.
    #[tokio::test]
    async fn manual_run_registers_its_driver_with_the_generation_set() {
        let (_tmp, mut state) = manual_run_state(manual_execute_sop(Some("ops")));
        let handles = zeroclaw_runtime::sop::SopDriverHandles::default();
        state.sop_driver_handles = Some(Arc::clone(&handles));

        let resp = handle_sop_run(
            State(state.clone()),
            HeaderMap::new(),
            Path("nightly".to_string()),
            Json(SopRunBody {
                payload: None,
                dedup_key: None,
            }),
        )
        .await;

        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            handles.lock().unwrap().len(),
            1,
            "the dashboard-started driver must join the generation-owned set rather than detach"
        );
    }

    fn authoring_checkpoint_sop(name: &str) -> Sop {
        Sop {
            name: name.into(),
            description: format!("{name} checkpoint"),
            version: "1.0.0".into(),
            priority: SopPriority::Normal,
            execution_mode: SopExecutionMode::Deterministic,
            triggers: vec![SopTrigger::Manual],
            steps: vec![SopStep {
                number: 1,
                title: "gate".into(),
                kind: SopStepKind::Checkpoint,
                ..SopStep::default()
            }],
            cooldown_secs: 0,
            max_concurrent: 1,
            location: None,
            deterministic: true,
            agent: None,
            admission_policy: SopAdmissionPolicy::Parallel,
            max_pending_approvals: 0,
            decision: None,
        }
    }

    fn authoring_rename_state(
        token: &str,
        names: &[&str],
    ) -> (tempfile::TempDir, std::path::PathBuf, AppState) {
        let tmp = tempfile::tempdir().unwrap();
        let sops_dir = tmp.path().join("sops");
        for name in names {
            zeroclaw_runtime::sop::save_sop(&sops_dir, &authoring_checkpoint_sop(name)).unwrap();
        }
        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        config.sop.sops_dir = Some(sops_dir.to_string_lossy().into_owned());
        let mut state = crate::api::test_state(config);
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[token.to_string()],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        (tmp, sops_dir, state)
    }

    #[tokio::test]
    async fn authoring_rename_moves_the_sop_and_maps_failures_to_status_codes() {
        let token = "author-token";
        let (_tmp, sops_dir, state) =
            authoring_rename_state(token, &["deploy-old", "deploy-taken"]);

        let resp = handle_sop_rename(
            State(state.clone()),
            bearer(token),
            Path("deploy-old".to_string()),
            Json(SopRenameBody {
                to: "deploy-new".to_string(),
            }),
        )
        .await;
        assert_eq!(resp.status(), StatusCode::OK);
        assert!(
            !sops_dir.join("deploy-old").exists(),
            "the SOP moves rather than being copied"
        );
        assert!(sops_dir.join("deploy-new").exists());

        let resp = handle_sop_rename(
            State(state.clone()),
            bearer(token),
            Path("deploy-new".to_string()),
            Json(SopRenameBody {
                to: "deploy-taken".to_string(),
            }),
        )
        .await;
        assert_eq!(
            resp.status(),
            StatusCode::CONFLICT,
            "a name another SOP owns is a conflict, not a merge"
        );
        assert!(sops_dir.join("deploy-new").exists());
        assert!(sops_dir.join("deploy-taken").exists());

        let resp = handle_sop_rename(
            State(state.clone()),
            bearer(token),
            Path("deploy-missing".to_string()),
            Json(SopRenameBody {
                to: "deploy-anything".to_string(),
            }),
        )
        .await;
        assert_eq!(resp.status(), StatusCode::NOT_FOUND);

        let resp = handle_sop_rename(
            State(state),
            bearer(token),
            Path("deploy-new".to_string()),
            Json(SopRenameBody {
                to: "../escaped".to_string(),
            }),
        )
        .await;
        assert_eq!(
            resp.status(),
            StatusCode::BAD_REQUEST,
            "a rename target that escapes the SOP root is rejected"
        );
        assert!(!sops_dir.parent().unwrap().join("escaped").exists());
    }

    /// `PUT /api/sops/{name}` edits the SOP named in its URL. After a rename,
    /// a client still holding the old name must get a not-found, and the
    /// retired name must not be recreated.
    #[tokio::test]
    async fn authoring_save_after_rename_does_not_recreate_the_retired_sop() {
        let token = "author-token";
        let (_tmp, sops_dir, state) = authoring_rename_state(token, &["deploy-before"]);

        let resp = handle_sop_rename(
            State(state.clone()),
            bearer(token),
            Path("deploy-before".to_string()),
            Json(SopRenameBody {
                to: "deploy-after".to_string(),
            }),
        )
        .await;
        assert_eq!(resp.status(), StatusCode::OK);

        let resp = handle_sop_save(
            State(state),
            bearer(token),
            Path("deploy-before".to_string()),
            Json(authoring_checkpoint_sop("deploy-before")),
        )
        .await;
        assert_eq!(
            resp.status(),
            StatusCode::NOT_FOUND,
            "a stale edit of a renamed SOP is not found, not a silent re-create"
        );
        assert!(!sops_dir.join("deploy-before").exists());
        assert!(sops_dir.join("deploy-after").exists());
    }

    #[tokio::test]
    async fn authoring_rename_requires_auth() {
        let (_tmp, sops_dir, state) = authoring_rename_state("author-token", &["deploy-old"]);

        let resp = handle_sop_rename(
            State(state),
            HeaderMap::new(),
            Path("deploy-old".to_string()),
            Json(SopRenameBody {
                to: "deploy-new".to_string(),
            }),
        )
        .await;
        assert_ne!(resp.status(), StatusCode::OK);
        assert!(
            sops_dir.join("deploy-old").exists(),
            "an unauthenticated rename must not touch the SOP root"
        );
        assert!(!sops_dir.join("deploy-new").exists());
    }

    fn authoring_state_with_policied_gate(
        member_token: &str,
        other_token: &str,
    ) -> (tempfile::TempDir, AppState, String) {
        let tmp = tempfile::tempdir().unwrap();
        let sops_dir = tmp.path().join("sops");
        let member_hash = PairingGuard::token_hash(member_token);

        let mut groups = HashMap::new();
        groups.insert(
            "release".to_string(),
            ApprovalGroupConfig {
                members: vec![member_hash],
            },
        );
        let mut policies = HashMap::new();
        policies.insert(
            "prod".to_string(),
            ApprovalPolicyConfig {
                required_group: Some("release".into()),
                quorum: 1,
                request_route: None,
                escalation_route: None,
            },
        );
        let approval = SopApprovalConfig { groups, policies };
        let sop = authoring_policy_sop();
        zeroclaw_runtime::sop::save_sop(&sops_dir, &sop).unwrap();

        let mut engine = SopEngine::new(SopConfig {
            approval,
            ..SopConfig::default()
        })
        .with_approval_broker(Arc::new(ApprovalBroker::disabled()));
        engine.set_sops_for_test(vec![sop]);
        let action = engine
            .start_run(
                "deploy",
                SopEvent {
                    source: SopTriggerSource::Manual,
                    topic: None,
                    payload: None,
                    timestamp: now_iso8601(),
                },
            )
            .unwrap();
        let run_id = match action {
            SopRunAction::WaitApproval { run_id, .. } => run_id,
            other => panic!("expected WaitApproval, got {other:?}"),
        };

        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        config.sop.sops_dir = Some(sops_dir.to_string_lossy().into_owned());
        let mut state = crate::api::test_state(config);
        state.sop_engine = Some(Arc::new(Mutex::new(engine)));
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[member_token.to_string(), other_token.to_string()],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        (tmp, state, run_id)
    }

    #[tokio::test]
    async fn authoring_decide_enforces_broker_policy_membership() {
        let member = "member-token";
        let outsider = "outsider-token";
        let (_tmp, state, run_id) = authoring_state_with_policied_gate(member, outsider);

        let resp = handle_sop_decide(
            State(state.clone()),
            bearer(outsider),
            Path(("deploy".to_string(), run_id.clone())),
            Json(serde_json::json!("approve")),
        )
        .await;

        assert_eq!(
            resp.status(),
            StatusCode::FORBIDDEN,
            "a paired non-member must not clear a policied authoring gate"
        );
        let status = state
            .sop_engine
            .as_ref()
            .unwrap()
            .lock()
            .unwrap()
            .get_run(&run_id)
            .map(|r| r.status);
        assert_eq!(
            status,
            Some(SopRunStatus::WaitingApproval),
            "the gate stays waiting after a broker-rejected authoring decision"
        );
    }

    #[tokio::test]
    async fn authoring_decide_pending_quorum_returns_overlay_shape() {
        let first_member = "member-token-1";
        let second_member = "member-token-2";
        let tmp = tempfile::tempdir().unwrap();
        let sops_dir = tmp.path().join("sops");
        let first_hash = PairingGuard::token_hash(first_member);
        let second_hash = PairingGuard::token_hash(second_member);

        let mut groups = HashMap::new();
        groups.insert(
            "release".to_string(),
            ApprovalGroupConfig {
                members: vec![first_hash, second_hash],
            },
        );
        let mut policies = HashMap::new();
        policies.insert(
            "prod".to_string(),
            ApprovalPolicyConfig {
                required_group: Some("release".into()),
                quorum: 2,
                request_route: None,
                escalation_route: None,
            },
        );
        let approval = SopApprovalConfig { groups, policies };
        let sop = authoring_policy_sop();
        zeroclaw_runtime::sop::save_sop(&sops_dir, &sop).unwrap();

        let mut engine = SopEngine::new(SopConfig {
            approval,
            ..SopConfig::default()
        })
        .with_approval_broker(Arc::new(ApprovalBroker::disabled()));
        engine.set_sops_for_test(vec![sop]);
        let action = engine
            .start_run(
                "deploy",
                SopEvent {
                    source: SopTriggerSource::Manual,
                    topic: None,
                    payload: None,
                    timestamp: now_iso8601(),
                },
            )
            .unwrap();
        let run_id = match action {
            SopRunAction::WaitApproval { run_id, .. } => run_id,
            other => panic!("expected WaitApproval, got {other:?}"),
        };

        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        config.sop.sops_dir = Some(sops_dir.to_string_lossy().into_owned());
        let mut state = crate::api::test_state(config);
        state.sop_engine = Some(Arc::new(Mutex::new(engine)));
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[first_member.to_string(), second_member.to_string()],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));

        let resp = handle_sop_decide(
            State(state.clone()),
            bearer(first_member),
            Path(("deploy".to_string(), run_id.clone())),
            Json(serde_json::json!("approve")),
        )
        .await;

        assert_eq!(
            resp.status(),
            StatusCode::ACCEPTED,
            "the first quorum member should leave the run pending"
        );
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(
            json.get("run_id").and_then(|value| value.as_str()),
            Some(run_id.as_str())
        );
        assert_eq!(
            json.get("sop_name").and_then(|value| value.as_str()),
            Some("deploy")
        );
        assert_eq!(
            json.get("waiting").and_then(|value| value.as_bool()),
            Some(true)
        );
        assert!(
            json.get("outcome").is_none(),
            "pending quorum responses must keep the RunOverlay shape, got {json:?}"
        );
    }

    #[tokio::test]
    async fn authoring_decide_rejects_run_id_from_different_sop_before_broker_resolution() {
        let token = "member-token";
        let tmp = tempfile::tempdir().unwrap();
        let sops_dir = tmp.path().join("sops");
        let sop_a = authoring_checkpoint_sop("deploy-a");
        let sop_b = authoring_checkpoint_sop("deploy-b");
        zeroclaw_runtime::sop::save_sop(&sops_dir, &sop_a).unwrap();
        zeroclaw_runtime::sop::save_sop(&sops_dir, &sop_b).unwrap();

        let mut engine = SopEngine::new(SopConfig::default());
        engine.set_sops_for_test(vec![sop_a, sop_b]);
        let action = engine
            .start_run(
                "deploy-b",
                SopEvent {
                    source: SopTriggerSource::Manual,
                    topic: None,
                    payload: None,
                    timestamp: now_iso8601(),
                },
            )
            .unwrap();
        let run_id = match action {
            SopRunAction::CheckpointWait { run_id, .. } => run_id,
            other => panic!("expected CheckpointWait, got {other:?}"),
        };

        let mut config = zeroclaw_config::schema::Config {
            config_path: tmp.path().join("config.toml"),
            ..zeroclaw_config::schema::Config::default()
        };
        config.sop.sops_dir = Some(sops_dir.to_string_lossy().into_owned());
        let mut state = crate::api::test_state(config);
        state.sop_engine = Some(Arc::new(Mutex::new(engine)));
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[token.to_string()],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));

        let resp = handle_sop_decide(
            State(state.clone()),
            bearer(token),
            Path(("deploy-a".to_string(), run_id.clone())),
            Json(serde_json::json!("approve")),
        )
        .await;

        assert_eq!(
            resp.status(),
            StatusCode::BAD_REQUEST,
            "a path SOP must not resolve a run owned by another SOP"
        );
        let guard = state.sop_engine.as_ref().unwrap().lock().unwrap();
        let run = guard.get_run(&run_id).expect("deploy-b run remains active");
        assert_eq!(run.sop_name, "deploy-b");
        assert_eq!(run.status, SopRunStatus::PausedCheckpoint);
        assert!(
            !guard
                .run_events(&run_id)
                .unwrap_or_default()
                .iter()
                .any(|event| event.kind == "gate_resolved"),
            "mismatched authoring decision must not append a gate_resolved row"
        );
    }

    fn authoring_running_sop(name: &str) -> Sop {
        Sop {
            name: name.into(),
            description: "t".into(),
            version: "1.0.0".into(),
            priority: SopPriority::Normal,
            execution_mode: SopExecutionMode::Auto,
            triggers: vec![SopTrigger::Manual],
            steps: vec![SopStep {
                number: 1,
                title: "step".into(),
                kind: SopStepKind::Execute,
                requires_confirmation: false,
                ..SopStep::default()
            }],
            cooldown_secs: 0,
            max_concurrent: 1,
            location: None,
            deterministic: false,
            agent: None,
            admission_policy: SopAdmissionPolicy::Parallel,
            max_pending_approvals: 0,
            decision: None,
        }
    }

    /// Build a gateway `AppState` whose SOP engine holds a plain ACTIVE run
    /// (no approval gate), paired to `token`.
    fn authoring_state_with_running_run(token: &str) -> (AppState, String) {
        let sop = authoring_running_sop("deploy");
        let mut engine = SopEngine::new(SopConfig::default());
        engine.set_sops_for_test(vec![sop]);
        let action = engine
            .start_run(
                "deploy",
                SopEvent {
                    source: SopTriggerSource::Manual,
                    topic: None,
                    payload: None,
                    timestamp: now_iso8601(),
                },
            )
            .unwrap();
        let run_id = match action {
            SopRunAction::ExecuteStep { run_id, .. } => run_id,
            other => panic!("expected ExecuteStep, got {other:?}"),
        };

        let mut state = crate::api::test_state(zeroclaw_config::schema::Config::default());
        state.sop_engine = Some(Arc::new(Mutex::new(engine)));
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[token.to_string()],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        (state, run_id)
    }

    fn run_status(state: &AppState, run_id: &str) -> Option<SopRunStatus> {
        state
            .sop_engine
            .as_ref()
            .unwrap()
            .lock()
            .unwrap()
            .get_run(run_id)
            .map(|r| r.status)
    }

    #[tokio::test]
    async fn authoring_cancel_active_run_returns_requested_and_keeps_it_active() {
        let token = "cancel-token";
        let (state, run_id) = authoring_state_with_running_run(token);

        let resp = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            bearer(token),
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;

        assert_eq!(resp.status(), StatusCode::ACCEPTED);
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["status"], "cancel_requested");
        assert_eq!(json["run"]["status"], "cancel_requested");
        assert_eq!(json["run"]["active"], true);
        assert_eq!(json["already_terminal"], false);
        assert_eq!(json["run_id"], run_id.as_str());

        assert_eq!(
            run_status(&state, &run_id),
            Some(SopRunStatus::CancelRequested)
        );
        assert!(
            state
                .sop_engine
                .as_ref()
                .unwrap()
                .lock()
                .unwrap()
                .active_runs()
                .contains_key(&run_id),
            "a cancellation request must retain the active run and its claim"
        );
        let events = state
            .sop_engine
            .as_ref()
            .unwrap()
            .lock()
            .unwrap()
            .run_events(&run_id)
            .unwrap();
        let requested = events
            .iter()
            .find(|event| event.kind == "run_cancel_requested")
            .unwrap();
        let expected_actor = format!("gateway:{}", PairingGuard::token_hash(token));
        assert_eq!(requested.actor.as_deref(), Some(expected_actor.as_str()));
    }

    #[tokio::test]
    async fn authoring_cancel_is_idempotent_on_a_second_request() {
        let token = "cancel-token";
        let (state, run_id) = authoring_state_with_running_run(token);

        let first = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            bearer(token),
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;
        assert_eq!(first.status(), StatusCode::ACCEPTED);

        let second = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            bearer(token),
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::from(serde_json::to_vec(&serde_json::json!({ "reason": "again" })).unwrap()),
        )
        .await;

        assert_eq!(
            second.status(),
            StatusCode::ACCEPTED,
            "a repeat cancellation request must be idempotent"
        );
        let body = second.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["status"], "cancel_requested");
        assert_eq!(json["already_terminal"], false);
    }

    #[tokio::test]
    async fn authoring_cancel_rejects_unauthenticated_request() {
        let token = "cancel-token";
        let (state, run_id) = authoring_state_with_running_run(token);

        let resp = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            HeaderMap::new(),
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;

        assert_eq!(resp.status(), StatusCode::UNAUTHORIZED);
        assert_eq!(
            run_status(&state, &run_id),
            Some(SopRunStatus::Running),
            "an unauthenticated cancel attempt must not touch the run"
        );
    }

    #[tokio::test]
    async fn authoring_cancel_fails_closed_remotely_when_pairing_is_disabled() {
        let (mut state, run_id) = authoring_state_with_running_run("unused");
        state.pairing = Arc::new(PairingGuard::new(
            false,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));

        let remote = handle_sop_cancel(
            State(state.clone()),
            remote_peer(),
            HeaderMap::new(),
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;
        assert_eq!(remote.status(), StatusCode::FORBIDDEN);
        assert_eq!(
            run_status(&state, &run_id),
            Some(SopRunStatus::Running),
            "a remote unauthenticated request must not mutate the run"
        );

        let loopback = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            HeaderMap::new(),
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;
        assert_eq!(loopback.status(), StatusCode::ACCEPTED);
        assert_eq!(
            run_status(&state, &run_id),
            Some(SopRunStatus::CancelRequested),
            "loopback-only access may remain unpaired"
        );
    }

    #[tokio::test]
    async fn authoring_cancel_rejects_remote_client_behind_trusted_loopback_proxy() {
        let (mut state, run_id) = authoring_state_with_running_run("unused");
        state.pairing = Arc::new(PairingGuard::new(
            false,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.trust_forwarded_headers = true;
        let mut headers = HeaderMap::new();
        headers.insert("x-forwarded-for", HeaderValue::from_static("203.0.113.17"));

        let response = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            headers,
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;

        assert_eq!(response.status(), StatusCode::FORBIDDEN);
        assert_eq!(run_status(&state, &run_id), Some(SopRunStatus::Running));
    }

    #[tokio::test]
    async fn authoring_cancel_rejects_forwarded_loopback_with_loopback_peer() {
        let (mut state, run_id) = authoring_state_with_running_run("unused");
        state.pairing = Arc::new(PairingGuard::new(
            false,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.trust_forwarded_headers = true;
        let mut headers = HeaderMap::new();
        headers.insert("x-forwarded-for", HeaderValue::from_static("127.0.0.1"));

        let response = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            headers,
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;

        assert_eq!(response.status(), StatusCode::FORBIDDEN);
        assert_eq!(run_status(&state, &run_id), Some(SopRunStatus::Running));
    }

    #[tokio::test]
    async fn authoring_cancel_rejects_forwarded_loopback_with_remote_peer() {
        let (mut state, run_id) = authoring_state_with_running_run("unused");
        state.pairing = Arc::new(PairingGuard::new(
            false,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.trust_forwarded_headers = true;
        let mut headers = HeaderMap::new();
        headers.insert("x-forwarded-for", HeaderValue::from_static("127.0.0.1"));

        let response = handle_sop_cancel(
            State(state.clone()),
            remote_peer(),
            headers,
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;

        assert_eq!(response.status(), StatusCode::FORBIDDEN);
        assert_eq!(run_status(&state, &run_id), Some(SopRunStatus::Running));
    }

    #[tokio::test]
    async fn authoring_cancel_allows_direct_loopback_with_trust_and_no_forwarded_header() {
        let (mut state, run_id) = authoring_state_with_running_run("unused");
        state.pairing = Arc::new(PairingGuard::new(
            false,
            &[],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));
        state.trust_forwarded_headers = true;

        let response = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            HeaderMap::new(),
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;

        assert_eq!(response.status(), StatusCode::ACCEPTED);
        assert_eq!(
            run_status(&state, &run_id),
            Some(SopRunStatus::CancelRequested),
        );
    }

    #[tokio::test]
    async fn authoring_cancel_unknown_run_returns_404() {
        let token = "cancel-token";
        let (state, _run_id) = authoring_state_with_running_run(token);

        let resp = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            bearer(token),
            Path(("deploy".to_string(), "nonexistent".to_string())),
            Bytes::new(),
        )
        .await;

        assert_eq!(resp.status(), StatusCode::NOT_FOUND);
    }

    #[tokio::test]
    async fn authoring_cancel_rejects_run_id_from_different_sop() {
        let token = "cancel-token";
        let sop_a = authoring_running_sop("deploy-a");
        let sop_b = authoring_running_sop("deploy-b");
        let mut engine = SopEngine::new(SopConfig::default());
        engine.set_sops_for_test(vec![sop_a, sop_b]);
        let action = engine
            .start_run(
                "deploy-b",
                SopEvent {
                    source: SopTriggerSource::Manual,
                    topic: None,
                    payload: None,
                    timestamp: now_iso8601(),
                },
            )
            .unwrap();
        let run_id = match action {
            SopRunAction::ExecuteStep { run_id, .. } => run_id,
            other => panic!("expected ExecuteStep, got {other:?}"),
        };

        let mut state = crate::api::test_state(zeroclaw_config::schema::Config::default());
        state.sop_engine = Some(Arc::new(Mutex::new(engine)));
        state.pairing = Arc::new(PairingGuard::new(
            true,
            &[token.to_string()],
            zeroclaw_config::pairing::PairingCodePolicy::default(),
        ));

        let resp = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            bearer(token),
            Path(("deploy-a".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;

        assert_eq!(
            resp.status(),
            StatusCode::BAD_REQUEST,
            "a path SOP must not cancel a run owned by another SOP"
        );
        assert_eq!(
            run_status(&state, &run_id),
            Some(SopRunStatus::Running),
            "a mismatched-SOP cancel attempt must not touch the run"
        );
    }

    #[tokio::test]
    async fn authoring_cancel_rejects_malformed_json_body() {
        let token = "cancel-token";
        let (state, run_id) = authoring_state_with_running_run(token);

        let resp = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            bearer(token),
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::from_static(b"{not json"),
        )
        .await;

        assert_eq!(resp.status(), StatusCode::BAD_REQUEST);
        assert_eq!(
            run_status(&state, &run_id),
            Some(SopRunStatus::Running),
            "a malformed cancel body must not touch the run"
        );
    }

    #[tokio::test]
    async fn authoring_cancel_a_gated_run_frees_it_regardless_of_approval_policy() {
        let member = "member-token";
        let outsider = "outsider-token";
        let (_tmp, state, run_id) = authoring_state_with_policied_gate(member, outsider);

        // Cancellation is an operator kill switch, not a gate-clearing decision:
        // even a caller that is not a member of the policy's required group can
        // stop the run. `authoring_decide_enforces_broker_policy_membership`
        // proves the same caller cannot clear this gate via decide.
        let resp = handle_sop_cancel(
            State(state.clone()),
            loopback_peer(),
            bearer(outsider),
            Path(("deploy".to_string(), run_id.clone())),
            Bytes::new(),
        )
        .await;

        assert_eq!(resp.status(), StatusCode::OK);
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["status"], "cancelled");
        assert_eq!(json["already_terminal"], false);
        assert_eq!(run_status(&state, &run_id), Some(SopRunStatus::Cancelled));
    }
}
